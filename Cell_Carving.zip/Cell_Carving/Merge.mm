//
//  Merge.m
//  Cell_Carving
//
//  Created by Masahiko Sato on 2015-12-15.
//
//

#import "Merge.h"

@implementation Merge

-(void)mergeExtendTrack{
    try{
        
        errorNoHold = 0;
        subCompletionFlag2 = 1;
        
        int maxPointDimX = 0;
        int maxPointDimY = 0;
        int minPointDimX = 1000000;
        int minPointDimY = 1000000;
        
        for (int counter1 = 0; counter1 < referenceLineCount/2; counter1++){
            if (maxPointDimX < arrayReferenceLine [counter1*2]) maxPointDimX = arrayReferenceLine [counter1*2];
            if (minPointDimX > arrayReferenceLine [counter1*2]) minPointDimX = arrayReferenceLine [counter1*2];
            if (maxPointDimY < arrayReferenceLine [counter1*2+1]) maxPointDimY = arrayReferenceLine [counter1*2+1];
            if (minPointDimY > arrayReferenceLine [counter1*2+1]) minPointDimY = arrayReferenceLine [counter1*2+1];
        }
        
        int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
        int verticalLength = (maxPointDimY-minPointDimY)/2*2;
        int dimension = 0;
        
        if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
        if (horizontalLength < verticalLength) dimension = verticalLength+30;
        
        dimension = (dimension/2)*2;
        
        int horizontalStart2 = minPointDimX-(dimension-horizontalLength)/2;
        int verticalStart2 = minPointDimY-(dimension-verticalLength)/2;
        
        int horizontalLength2 = (maxPointDimX-minPointDimX)/2*2;
        int verticalLength2 = (maxPointDimY-minPointDimY)/2*2;
        int dimension2 = 0;
        int dimension2A = 0;
        int dimension2B = 0;
        
        if (horizontalLength2 >= verticalLength2) dimension2 = horizontalLength2+10;
        if (horizontalLength2 < verticalLength2) dimension2 = verticalLength2+10;
        
        dimension2A = (dimension2/2)*5;
        dimension2B = dimension2A+20;
        
        int horizontalStart2A = minPointDimX-(dimension2A-horizontalLength2)/2;
        int verticalStart2A = minPointDimY-(dimension2A-verticalLength2)/2;
        int horizontalStart2B = minPointDimX-(dimension2B-horizontalLength2)/2;
        int verticalStart2B = minPointDimY-(dimension2B-verticalLength2)/2;
        
        //cout<<horizontalStart2<<" "<<verticalStart2<<" "<<dimension<<" hol-ver-dim"<<endl;
        
        errorNoHold = 1;
        int **connectivityMapTemp3 = new int *[dimension+1];
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            errorNoHold = 2;
            connectivityMapTemp3 [counter1] = new int [dimension+1];
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp3 [counterY][counterX] = 0;
        }
        
        for (int counter1 = 0; counter1 < referenceLineCount/2; counter1++){
            if (arrayReferenceLine [counter1*2]-horizontalStart2 >= 0 && arrayReferenceLine [counter1*2]-horizontalStart2 < dimension && arrayReferenceLine [counter1*2+1]-verticalStart2 >= 0 && arrayReferenceLine [counter1*2+1]-verticalStart2 < dimension) connectivityMapTemp3 [arrayReferenceLine [counter1*2+1]-verticalStart2][arrayReferenceLine [counter1*2]-horizontalStart2] = 1;
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp3 [counterA][counterB];
        //	cout<<" connectivityMapTemp3 "<<counterA<<endl;
        //}
        
        //------Fill inside------
        errorNoHold = 3;
        int *connectAnalysisX = new int [dimension*4];
        errorNoHold = 4;
        int *connectAnalysisY = new int [dimension*4];
        errorNoHold = 5;
        int *connectAnalysisTempX = new int [dimension*4];
        errorNoHold = 6;
        int *connectAnalysisTempY = new int [dimension*4];
        
        int connectivityNumber = -3;
        int connectAnalysisCount = 0;
        int terminationFlag = 0;
        int connectAnalysisTempCount = 0;
        int xSource = 0;
        int ySource = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMapTemp3 [counterY][counterX] == 0){
                    connectivityNumber = connectivityNumber+2;
                    connectAnalysisCount = 0;
                    
                    if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMapTemp3 [counterY][counterX] = connectivityNumber;
                    if (counterY-1 >= 0 && connectivityMapTemp3 [counterY-1][counterX] == 0){
                        connectivityMapTemp3 [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension && connectivityMapTemp3 [counterY][counterX+1] == 0){
                        connectivityMapTemp3 [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && connectivityMapTemp3 [counterY+1][counterX] == 0){
                        connectivityMapTemp3 [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && connectivityMapTemp3 [counterY][counterX-1] == 0){
                        connectivityMapTemp3 [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && connectivityMapTemp3 [ySource-1][xSource] == 0){
                                    connectivityMapTemp3 [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension && connectivityMapTemp3 [ySource][xSource+1] == 0){
                                    connectivityMapTemp3 [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && connectivityMapTemp3 [ySource+1][xSource] == 0){
                                    connectivityMapTemp3 [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && connectivityMapTemp3 [ySource][xSource-1] == 0){
                                    connectivityMapTemp3 [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        delete [] connectAnalysisX;
        delete [] connectAnalysisY;
        delete [] connectAnalysisTempX;
        delete [] connectAnalysisTempY;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMapTemp3 [counterY][counterX] == -1) connectivityMapTemp3 [counterY][counterX] = 0;
                else connectivityMapTemp3 [counterY][counterX] = 1;
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp3 [counterA][counterB];
        //    cout<<" connectivityMapTemp3 "<<counterA<<endl;
        //}
        
        int startY = 0;
        int endY = 0;
        int startX = 0;
        int endX = 0;
        
        //=========B
        errorNoHold = 7;
        int *findReviseConnect = new int [1000];
        for (int counter2 = 0; counter2 < 1000; counter2++) findReviseConnect [counter2] = 0;
        
        errorNoHold = 8;
        int **rangeMatrixA = new int *[dimension2A+4];
        
        for (int counter2 = 0; counter2 < dimension2A+4; counter2++){
            errorNoHold = 9;
            rangeMatrixA [counter2] = new int [dimension2A+4];
        }
        
        errorNoHold = 10;
        int **rangeMatrixB = new int *[dimension2B+4];
        
        for (int counter2 = 0; counter2 < dimension2B+4; counter2++){
            errorNoHold = 11;
            rangeMatrixB [counter2] = new int [dimension2B+4];
        }
        
        errorNoHold = 12;
        int *connectAnalysisXA = new int [dimension2A*4];
        errorNoHold = 13;
        int *connectAnalysisYA = new int [dimension2A*4];
        errorNoHold = 14;
        int *connectAnalysisTempXA = new int [dimension2A*4];
        errorNoHold = 15;
        int *connectAnalysisTempYA = new int [dimension2A*4];
        
        errorNoHold = 16;
        int *connectAnalysisXB = new int [dimension2B*4];
        errorNoHold = 17;
        int *connectAnalysisYB = new int [dimension2B*4];
        errorNoHold = 18;
        int *connectAnalysisTempXB = new int [dimension2B*4];
        errorNoHold = 19;
        int *connectAnalysisTempYB = new int [dimension2B*4];
        
        int freePixelFind = 0;
        int processConnectPosition = 0;
        int processConnectPosition2 = 0;
        int maxConnectRevise = 0;
        int findReviseConnectLimit = 1000;
        int connectivityNumberA = 0;
        int connectivityNumberB = 0;
        int connectTemp = 0;
        int maxConnect = 0;
        int processConnectNo = 0;
        int findFlag = 0;
        int cutOffFinal = 0;
        
        for (int counter2 = cutStatusDic; counter2 < 240; counter2 = counter2+10){ //====DIC
            for (int counterY = 0; counterY < dimension2A; counterY++){
                for (int counterX = 0; counterX < dimension2A; counterX++){
                    if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                        if (sourceImage [mapPositionPointer][(counterY+verticalStart2A)*imageDimension+counterX+horizontalStart2A] == 100) rangeMatrixA [counterY][counterX] = 0;
                        else if (sourceImage [mapPositionPointer][(counterY+verticalStart2A)*imageDimension+counterX+horizontalStart2A] < counter2) rangeMatrixA [counterY][counterX] = 0;
                        else rangeMatrixA [counterY][counterX] = -150;
                        
                        if (counterY+verticalStart2A-verticalStart2 >= 0 && counterY+verticalStart2A-verticalStart2 < dimension && counterX+horizontalStart2A-horizontalStart2 >= 0 && counterX+horizontalStart2A-horizontalStart2 < dimension){
                            if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] != 0 && connectivityMapTemp3 [counterY+verticalStart2A-verticalStart2][counterX+horizontalStart2A-horizontalStart2] != 1){
                                rangeMatrixA [counterY][counterX] = 0;
                            }
                        }
                    }
                    else rangeMatrixA [counterY][counterX] = 0;
                }
            }
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                        if (sourceImage [mapPositionPointer][(counterY+verticalStart2B)*imageDimension+counterX+horizontalStart2B] == 100) rangeMatrixB [counterY][counterX] = 0;
                        else if (sourceImage [mapPositionPointer][(counterY+verticalStart2B)*imageDimension+counterX+horizontalStart2B] < counter2) rangeMatrixB [counterY][counterX] = 0;
                        else rangeMatrixB [counterY][counterX] = -150;
                        
                        if (counterY+verticalStart2B-verticalStart2 >= 0 && counterY+verticalStart2B-verticalStart2 < dimension && counterX+horizontalStart2B-horizontalStart2 >= 0 && counterX+horizontalStart2B-horizontalStart2 < dimension){
                            if (revisedWorkingMap [counterY+verticalStart2B][counterX+horizontalStart2B] != 0 && connectivityMapTemp3 [counterY+verticalStart2B-verticalStart2][counterX+horizontalStart2B-horizontalStart2] != 1){
                                rangeMatrixB [counterY][counterX] = 0;
                            }
                        }
                    }
                    else rangeMatrixB [counterY][counterX] = 0;
                }
            }
            
            //for (int counterA = 0; counterA < dimension2A; counterA++){
            //    for (int counterB = 0; counterB < dimension2A; counterB++) cout<<" "<<rangeMatrixA [counterA][counterB];
            //    cout<<" rangeMatrixA "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < dimension2B; counterA++){
            //    for (int counterB = 0; counterB < dimension2B; counterB++) cout<<" "<<rangeMatrixB [counterA][counterB];
            //    cout<<" rangeMatrixB "<<counterA<<endl;
            //}
            
            //-------MapA--------
            connectivityNumberA = 0;
            
            for (int counterY = 0; counterY < dimension2A; counterY++){
                for (int counterX = 0; counterX < dimension2A; counterX++){
                    if (rangeMatrixA [counterY][counterX] == -150){
                        connectivityNumberA++;
                        rangeMatrixA [counterY][counterX] = connectivityNumberA;
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixA [counterY-1][counterX-1] == -150){
                            rangeMatrixA [counterY-1][counterX-1] = connectivityNumberA;
                            connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && rangeMatrixA [counterY-1][counterX] == -150){
                            rangeMatrixA [counterY-1][counterX] = connectivityNumberA;
                            connectAnalysisXA [connectAnalysisCount] = counterX, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && counterX+1 < dimension2A && rangeMatrixA [counterY-1][counterX+1] == -150){
                            rangeMatrixA [counterY-1][counterX+1] = connectivityNumberA;
                            connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension2A && rangeMatrixA [counterY][counterX+1] == -150){
                            rangeMatrixA [counterY][counterX+1] = connectivityNumberA;
                            connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2A && counterX+1 < dimension2A && rangeMatrixA [counterY+1][counterX+1] == -150){
                            rangeMatrixA [counterY+1][counterX+1] = connectivityNumberA;
                            connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2A && rangeMatrixA [counterY+1][counterX] == -150){
                            rangeMatrixA [counterY+1][counterX] = connectivityNumberA;
                            connectAnalysisXA [connectAnalysisCount] = counterX, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2A && counterX-1 >= 0 && rangeMatrixA [counterY+1][counterX-1] == -150){
                            rangeMatrixA [counterY+1][counterX-1] = connectivityNumberA;
                            connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && rangeMatrixA [counterY][counterX-1] == -150){
                            rangeMatrixA [counterY][counterX-1] = connectivityNumberA;
                            connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                    xSource = connectAnalysisXA [counter3], ySource = connectAnalysisYA [counter3];
                                    
                                    if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrixA [ySource-1][xSource-1] == -150){
                                        rangeMatrixA [ySource-1][xSource-1] = connectivityNumberA;
                                        connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && rangeMatrixA [ySource-1][xSource] == -150){
                                        rangeMatrixA [ySource-1][xSource] = connectivityNumberA;
                                        connectAnalysisTempXA [connectAnalysisTempCount] = xSource, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && xSource+1 < dimension2A && rangeMatrixA [ySource-1][xSource+1] == -150){
                                        rangeMatrixA [ySource-1][xSource+1] = connectivityNumberA;
                                        connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension2A && rangeMatrixA [ySource][xSource+1] == -150){
                                        rangeMatrixA [ySource][xSource+1] = connectivityNumberA;
                                        connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 > dimension2A && xSource+1 < dimension2A && rangeMatrixA [ySource+1][xSource+1] == -150){
                                        rangeMatrixA [ySource+1][xSource+1] = connectivityNumberA;
                                        connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension2A && rangeMatrixA [ySource+1][xSource] == -150){
                                        rangeMatrixA [ySource+1][xSource] = connectivityNumberA;
                                        connectAnalysisTempXA [connectAnalysisTempCount] = xSource, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension2A && xSource-1 >= 0 && rangeMatrixA [ySource+1][xSource-1] == -150){
                                        rangeMatrixA [ySource+1][xSource-1] = connectivityNumberA;
                                        connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && rangeMatrixA [ySource][xSource-1] == -150){
                                        rangeMatrixA [ySource][xSource-1] = connectivityNumberA;
                                        connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                    connectAnalysisXA [counter3] = connectAnalysisTempXA [counter3], connectAnalysisYA [counter3] = connectAnalysisTempYA [counter3];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //------Determine number of pixels------
            errorNoHold = 20;
            int *connectedPixels = new int [connectivityNumberA+50];
            
            for (int counter3 = 0; counter3 <= connectivityNumberA; counter3++) connectedPixels [counter3] = 0;
            
            for (int counterY = 0; counterY < dimension2A; counterY++){
                for (int counterX = 0; counterX < dimension2A; counterX++){
                    if (rangeMatrixA [counterY][counterX] != 0) connectedPixels [rangeMatrixA [counterY][counterX]]++;
                }
            }
            
            //------Map up-date------
            connectTemp = 1;
            
            for (int counter3 = 1; counter3 <= connectivityNumberA; counter3++){
                if (connectedPixels [counter3] < 10) connectedPixels [counter3] = 0;
                else{
                    
                    connectedPixels [counter3] = connectTemp;
                    connectTemp++;
                }
            }
            
            maxConnect = 0;
            maxConnectRevise = 0;
            
            for (int counterY = 0; counterY < dimension2A; counterY++){
                for (int counterX = 0; counterX < dimension2A; counterX++){
                    if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                        if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A];
                        
                        if ((connectTemp = rangeMatrixA [counterY][counterX]) != 0) rangeMatrixA [counterY][counterX] = connectedPixels [connectTemp];
                        else rangeMatrixA [counterY][counterX] = 0;
                        
                        if (rangeMatrixA [counterY][counterX] > maxConnect) maxConnect = rangeMatrixA [counterY][counterX];
                    }
                }
            }
            
            delete [] connectedPixels;
            
            errorNoHold = 21;
            int *findConnectNo = new int [maxConnect+5];
            for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo [counter3] = 0;
            
            if (maxConnectRevise+10 > findReviseConnectLimit){
                delete [] findReviseConnect;
                errorNoHold = 22;
                findReviseConnect = new int [maxConnectRevise+50];
                findReviseConnectLimit = maxConnectRevise+50;
            }
            
            for (int counter3 = 0; counter3 < maxConnectRevise+5; counter3++) findReviseConnect [counter3] = 0;
            
            for (int counterY = 0; counterY < dimension2A; counterY++){
                for (int counterX = 0; counterX < dimension2A; counterX++){
                    if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension && counterY+verticalStart2A-verticalStart2 >= 0 && counterY+verticalStart2A-verticalStart2 < dimension && counterX+horizontalStart2A-horizontalStart2 >= 0 && counterX+horizontalStart2A-horizontalStart2 < dimension){
                        if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] != 0 && connectivityMapTemp3 [counterY+verticalStart2A-verticalStart2][counterX+horizontalStart2A-horizontalStart2] == 1){
                            if (rangeMatrixA [counterY][counterX] != 0) findConnectNo [rangeMatrixA [counterY][counterX]]++;
                        }
                    }
                }
            }
            
            processConnectNo = 0;
            processConnectPosition = 0;
            
            for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
                if (findConnectNo [counter3] > processConnectNo){
                    processConnectNo = findConnectNo [counter3];
                    processConnectPosition = counter3;
                }
            }
            
            if (processConnectPosition != 0){
                freePixelFind = 0;
                
                for (int counterY = 0; counterY < dimension2A; counterY++){
                    for (int counterX = 0; counterX < dimension2A; counterX++){
                        if (rangeMatrixA [counterY][counterX] == processConnectPosition){
                            if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                                if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] != 0){
                                    findReviseConnect [revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A]]++;
                                }
                                
                                if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] == 0) freePixelFind = 1;
                            }
                        }
                    }
                }
                
                //--------MapB---------
                connectivityNumberB = 0;
                
                for (int counterY = 0; counterY < dimension2B; counterY++){
                    for (int counterX = 0; counterX < dimension2B; counterX++){
                        if (rangeMatrixB [counterY][counterX] == -150){
                            connectivityNumberB++;
                            rangeMatrixB [counterY][counterX] = connectivityNumberB;
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixB [counterY-1][counterX-1] == -150){
                                rangeMatrixB [counterY-1][counterX-1] = connectivityNumberB;
                                connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && rangeMatrixB [counterY-1][counterX] == -150){
                                rangeMatrixB [counterY-1][counterX] = connectivityNumberB;
                                connectAnalysisXB [connectAnalysisCount] = counterX, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && counterX+1 < dimension2B && rangeMatrixB [counterY-1][counterX+1] == -150){
                                rangeMatrixB [counterY-1][counterX+1] = connectivityNumberB;
                                connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension2B && rangeMatrixB [counterY][counterX+1] == -150){
                                rangeMatrixB [counterY][counterX+1] = connectivityNumberB;
                                connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension2B && counterX+1 < dimension2B && rangeMatrixB [counterY+1][counterX+1] == -150){
                                rangeMatrixB [counterY+1][counterX+1] = connectivityNumberB;
                                connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension2B && rangeMatrixB [counterY+1][counterX] == -150){
                                rangeMatrixB [counterY+1][counterX] = connectivityNumberB;
                                connectAnalysisXB [connectAnalysisCount] = counterX, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension2B && counterX-1 >= 0 && rangeMatrixB [counterY+1][counterX-1] == -150){
                                rangeMatrixB [counterY+1][counterX-1] = connectivityNumberB;
                                connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && rangeMatrixB [counterY][counterX-1] == -150){
                                rangeMatrixB [counterY][counterX-1] = connectivityNumberB;
                                connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                        xSource = connectAnalysisXB [counter3], ySource = connectAnalysisYB [counter3];
                                        
                                        if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrixB [ySource-1][xSource-1] == -150){
                                            rangeMatrixB [ySource-1][xSource-1] = connectivityNumberB;
                                            connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && rangeMatrixB [ySource-1][xSource] == -150){
                                            rangeMatrixB [ySource-1][xSource] = connectivityNumberB;
                                            connectAnalysisTempXB [connectAnalysisTempCount] = xSource, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && xSource+1 < dimension2B && rangeMatrixB [ySource-1][xSource+1] == -150){
                                            rangeMatrixB [ySource-1][xSource+1] = connectivityNumberB;
                                            connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension2B && rangeMatrixB [ySource][xSource+1] == -150){
                                            rangeMatrixB [ySource][xSource+1] = connectivityNumberB;
                                            connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 > dimension2B && xSource+1 < dimension2B && rangeMatrixB [ySource+1][xSource+1] == -150){
                                            rangeMatrixB [ySource+1][xSource+1] = connectivityNumberB;
                                            connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension2B && rangeMatrixB [ySource+1][xSource] == -150){
                                            rangeMatrixB [ySource+1][xSource] = connectivityNumberB;
                                            connectAnalysisTempXB [connectAnalysisTempCount] = xSource, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension2B && xSource-1 >= 0 && rangeMatrixB [ySource+1][xSource-1] == -150){
                                            rangeMatrixB [ySource+1][xSource-1] = connectivityNumberB;
                                            connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && rangeMatrixB [ySource][xSource-1] == -150){
                                            rangeMatrixB [ySource][xSource-1] = connectivityNumberB;
                                            connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                        connectAnalysisXB [counter3] = connectAnalysisTempXB [counter3], connectAnalysisYB [counter3] = connectAnalysisTempYB [counter3];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //------Determine number of pixels------
                errorNoHold = 23;
                connectedPixels = new int [connectivityNumberB+50];
                
                for (int counter3 = 0; counter3 <= connectivityNumberB; counter3++) connectedPixels [counter3] = 0;
                
                for (int counterY = 0; counterY < dimension2B; counterY++){
                    for (int counterX = 0; counterX < dimension2B; counterX++){
                        if (rangeMatrixB [counterY][counterX] != 0) connectedPixels [rangeMatrixB [counterY][counterX]]++;
                    }
                }
                
                //------Map up-date------
                connectTemp = 1;
                
                for (int counter3 = 1; counter3 <= connectivityNumberB; counter3++){
                    if (connectedPixels [counter3] < 10) connectedPixels [counter3] = 0;
                    else{
                        
                        connectedPixels [counter3] = connectTemp;
                        connectTemp++;
                    }
                }
                
                maxConnect = 0;
                
                for (int counterY = 0; counterY < dimension2B; counterY++){
                    for (int counterX = 0; counterX < dimension2B; counterX++){
                        if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                            if ((connectTemp = rangeMatrixB [counterY][counterX]) != 0) rangeMatrixB [counterY][counterX] = connectedPixels [connectTemp];
                            else rangeMatrixB [counterY][counterX] = 0;
                            
                            if (rangeMatrixB [counterY][counterX] > maxConnect) maxConnect = rangeMatrixB [counterY][counterX];
                        }
                    }
                }
                
                delete [] connectedPixels;
                
                errorNoHold = 24;
                int *findConnectNo2 = new int [maxConnect+5];
                for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo2 [counter3] = 0;
                
                for (int counterY = 0; counterY < dimension2B; counterY++){
                    for (int counterX = 0; counterX < dimension2B; counterX++){
                        if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension && counterY+verticalStart2B-verticalStart2 >= 0 && counterY+verticalStart2B-verticalStart2 < dimension && counterX+horizontalStart2B-horizontalStart2 >= 0 && counterX+horizontalStart2B-horizontalStart2 < dimension){
                            if (revisedWorkingMap [counterY+verticalStart2B][counterX+horizontalStart2B] != 0 && connectivityMapTemp3 [counterY+verticalStart2B-verticalStart2][counterX+horizontalStart2B-horizontalStart2] == 1){
                                if (rangeMatrixB [counterY][counterX] != 0) findConnectNo2 [rangeMatrixB [counterY][counterX]]++;
                            }
                        }
                    }
                }
                
                processConnectNo = 0;
                processConnectPosition2 = 0;
                
                for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
                    if (findConnectNo2 [counter3] > processConnectNo){
                        processConnectNo = findConnectNo2 [counter3];
                        processConnectPosition2 = counter3;
                    }
                }
                
                if (processConnectPosition2 != 0){
                    for (int counterY = 0; counterY < dimension2A; counterY++){
                        for (int counterX = 0; counterX < dimension2A; counterX++){
                            if ((counterY+verticalStart2A)-verticalStart2B >= 0 && (counterY+verticalStart2A)-verticalStart2B < +dimension2B && (counterX+horizontalStart2A)-horizontalStart2B >= 0 && (counterX+horizontalStart2A)-horizontalStart2B < dimension2B){
                                rangeMatrixB [(counterY+verticalStart2A)-verticalStart2B][(counterX+horizontalStart2A)-horizontalStart2B] = 0;
                            }
                        }
                    }
                    
                    findFlag = 0;
                    
                    for (int counterY = 0; counterY < dimension2B; counterY++){
                        for (int counterX = 0; counterX < dimension2B; counterX++){
                            if (rangeMatrixB [counterY][counterX] == processConnectPosition2){
                                findFlag = 1;
                                break;
                            }
                        }
                    }
                    
                    if (findFlag == 0){
                        cutOffFinal = counter2;
                        
                        delete [] findConnectNo2;
                        delete [] findConnectNo;
                        break;
                    }
                }
                else{
                    
                    if (counter2 != 20) cutOffFinal = counter2-10;
                    else cutOffFinal = 0;
                    
                    delete [] findConnectNo2;
                    delete [] findConnectNo;
                    break;
                }
                
                delete [] findConnectNo2;
            }
            else{
                
                if (counter2 != 20) cutOffFinal = counter2-10;
                else cutOffFinal = 0;
                
                delete [] findConnectNo;
                break;
            }
            
            delete [] findConnectNo;
        }
        
        delete [] connectAnalysisXA;
        delete [] connectAnalysisYA;
        delete [] connectAnalysisTempXA;
        delete [] connectAnalysisTempYA;
        
        delete [] connectAnalysisXB;
        delete [] connectAnalysisYB;
        delete [] connectAnalysisTempXB;
        delete [] connectAnalysisTempYB;
        
        for (int counter2 = 0; counter2 < dimension2A+4; counter2++){
            delete [] rangeMatrixA [counter2];
        }
        
        delete [] rangeMatrixA;
        
        for (int counter2 = 0; counter2 < dimension2B+4; counter2++){
            delete [] rangeMatrixB [counter2];
        }
        
        delete [] rangeMatrixB;
        
        if (cutOffFinal != 0 && freePixelFind == 1){
            int extendConnectCount = 0;
            
            for (int counter1 = 1; counter1 < maxConnectRevise+5; counter1++){
                if (findReviseConnect [counter1] != 0) extendConnectCount++;
            }
            
            errorNoHold = 25;
            int *extendConnectList = new int [extendConnectCount*2+4];
            extendConnectCount = 0;
            
            for (int counter1 = 1; counter1 < maxConnectRevise+5; counter1++){
                if (findReviseConnect [counter1] != 0){
                    extendConnectList [extendConnectCount] = counter1, extendConnectCount++;
                    extendConnectList [extendConnectCount] = 0, extendConnectCount++;
                }
            }
            
            extendConnectList [extendConnectCount] = maxConnectRevise+1, extendConnectCount++;
            extendConnectList [extendConnectCount] = 0, extendConnectCount++;
            
            int connectFind = 0;
            
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                connectFind = 0;
                
                for (int counter2 = 0; counter2 < extendConnectCount/2; counter2++){
                    if (extendConnectList [counter2*2] == arrayTimeSelected [counter1*10+8]) connectFind = 1;
                }
                
                if (connectFind == 1){
                    for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                        if (arrayPositionRevise [counter2*7+3] == arrayTimeSelected [counter1*10+8]){
                            if (maxPointDimX < arrayPositionRevise [counter2*7]) maxPointDimX = arrayPositionRevise [counter2*7];
                            if (minPointDimX > arrayPositionRevise [counter2*7]) minPointDimX = arrayPositionRevise [counter2*7];
                            if (maxPointDimY < arrayPositionRevise [counter2*7+1]) maxPointDimY = arrayPositionRevise [counter2*7+1];
                            if (minPointDimY > arrayPositionRevise [counter2*7+1]) minPointDimY = arrayPositionRevise [counter2*7+1];
                        }
                        else{
                            
                            break;
                        }
                    }
                }
            }
            
            horizontalLength = (maxPointDimX-minPointDimX)/2*2;
            verticalLength = (maxPointDimY-minPointDimY)/2*2;
            int dimension3 = 0;
            
            if (horizontalLength >= verticalLength) dimension3 = horizontalLength+30;
            if (horizontalLength < verticalLength) dimension3 = verticalLength+30;
            
            dimension3 = (dimension3/2)*5;
            
            int horizontalStart3 = minPointDimX-(dimension3-horizontalLength)/2;
            int verticalStart3 = minPointDimY-(dimension3-verticalLength)/2;
            
            //=======CC
            errorNoHold = 26;
            int **rangeMatrix = new int *[dimension3+4];
            
            for (int counter2 = 0; counter2 < dimension3+4; counter2++){
                errorNoHold = 27;
                rangeMatrix [counter2] = new int [dimension3+4];
            }
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (counterY+verticalStart3 >= 0 && counterY+verticalStart3 < imageDimension && counterX+horizontalStart3 >= 0 && counterX+horizontalStart3 < imageDimension){
                        if (sourceImage [mapPositionPointer][(counterY+verticalStart3)*imageDimension+counterX+horizontalStart3] == 100) rangeMatrix [counterY][counterX] = 0;
                        else if (sourceImage [mapPositionPointer][(counterY+verticalStart3)*imageDimension+counterX+horizontalStart3] < cutOffFinal) rangeMatrix [counterY][counterX] = 0;
                        else rangeMatrix [counterY][counterX] = -150;
                        
                        if (counterY+verticalStart3-verticalStart2 >= 0 && counterY+verticalStart3-verticalStart2 < dimension && counterX+horizontalStart3-horizontalStart2 >= 0 && counterX+horizontalStart3-horizontalStart2 < dimension){
                            if (revisedWorkingMap [counterY+verticalStart3][counterX+horizontalStart3] != 0 && connectivityMapTemp3 [counterY+verticalStart3-verticalStart2][counterX+horizontalStart3-horizontalStart2] != 1){
                                rangeMatrix [counterY][counterX] = 0;
                            }
                        }
                    }
                    else rangeMatrix [counterY][counterX] = 0;
                }
            }
            
            errorNoHold = 28;
            connectAnalysisX = new int [dimension3*4];
            errorNoHold = 29;
            connectAnalysisY = new int [dimension3*4];
            errorNoHold = 30;
            connectAnalysisTempX = new int [dimension3*4];
            errorNoHold = 31;
            connectAnalysisTempY = new int [dimension3*4];
            
            connectivityNumber = 0;
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (rangeMatrix [counterY][counterX] == -150){
                        connectivityNumber++;
                        rangeMatrix [counterY][counterX] = connectivityNumber;
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrix [counterY-1][counterX-1] == -150){
                            rangeMatrix [counterY-1][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && rangeMatrix [counterY-1][counterX] == -150){
                            rangeMatrix [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && counterX+1 < dimension3 && rangeMatrix [counterY-1][counterX+1] == -150){
                            rangeMatrix [counterY-1][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension3 && rangeMatrix [counterY][counterX+1] == -150){
                            rangeMatrix [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension3 && counterX+1 < dimension3 && rangeMatrix [counterY+1][counterX+1] == -150){
                            rangeMatrix [counterY+1][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension3 && rangeMatrix [counterY+1][counterX] == -150){
                            rangeMatrix [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension3 && counterX-1 >= 0 && rangeMatrix [counterY+1][counterX-1] == -150){
                            rangeMatrix [counterY+1][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && rangeMatrix [counterY][counterX-1] == -150){
                            rangeMatrix [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                    xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                    
                                    if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrix [ySource-1][xSource-1] == -150){
                                        rangeMatrix [ySource-1][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && rangeMatrix [ySource-1][xSource] == -150){
                                        rangeMatrix [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && xSource+1 < dimension3 && rangeMatrix [ySource-1][xSource+1] == -150){
                                        rangeMatrix [ySource-1][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension3 && rangeMatrix [ySource][xSource+1] == -150){
                                        rangeMatrix [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 > dimension3 && xSource+1 < dimension3 && rangeMatrix [ySource+1][xSource+1] == -150){
                                        rangeMatrix [ySource+1][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension3 && rangeMatrix [ySource+1][xSource] == -150){
                                        rangeMatrix [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension3 && xSource-1 >= 0 && rangeMatrix [ySource+1][xSource-1] == -150){
                                        rangeMatrix [ySource+1][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && rangeMatrix [ySource][xSource-1] == -150){
                                        rangeMatrix [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                    connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //------Determine number of pixels------
            errorNoHold = 32;
            int *connectedPixels = new int [connectivityNumber+50];
            
            for (int counter3 = 0; counter3 <= connectivityNumber; counter3++) connectedPixels [counter3] = 0;
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (rangeMatrix [counterY][counterX] != 0) connectedPixels [rangeMatrix [counterY][counterX]]++;
                }
            }
            
            //------Map up-date------
            connectTemp = 1;
            
            for (int counter3 = 1; counter3 <= connectivityNumber; counter3++){
                if (connectedPixels [counter3] < 10) connectedPixels [counter3] = 0;
                else{
                    
                    connectedPixels [counter3] = connectTemp;
                    connectTemp++;
                }
            }
            
            maxConnect = 0;
            maxConnectRevise = 0;
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (counterY+verticalStart3 >= 0 && counterY+verticalStart3 < imageDimension && counterX+horizontalStart3 >= 0 && counterX+horizontalStart3 < imageDimension){
                        if (revisedWorkingMap [counterY+verticalStart3][counterX+horizontalStart3] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart3][counterX+horizontalStart3];
                        
                        if ((connectTemp = rangeMatrix [counterY][counterX]) != 0) rangeMatrix [counterY][counterX] = connectedPixels [connectTemp];
                        else rangeMatrix [counterY][counterX] = 0;
                        
                        if (rangeMatrix [counterY][counterX] > maxConnect) maxConnect = rangeMatrix [counterY][counterX];
                    }
                }
            }
            
            delete [] connectedPixels;
            
            errorNoHold = 33;
            int *findConnectNo = new int [maxConnect+5];
            for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo [counter3] = 0;
            
            if (maxConnectRevise+10 > findReviseConnectLimit){
                delete [] findReviseConnect;
                errorNoHold = 34;
                findReviseConnect = new int [maxConnectRevise+50];
            }
            
            for (int counter3 = 0; counter3 < maxConnectRevise+5; counter3++) findReviseConnect [counter3] = 0;
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (counterY+verticalStart3 >= 0 && counterY+verticalStart3 < imageDimension && counterX+horizontalStart3 >= 0 && counterX+horizontalStart3 < imageDimension && counterY+verticalStart3-verticalStart2 >= 0 && counterY+verticalStart3-verticalStart2 < dimension && counterX+horizontalStart3-horizontalStart2 >= 0 && counterX+horizontalStart3-horizontalStart2 < dimension){
                        if (revisedWorkingMap [counterY+verticalStart3][counterX+horizontalStart3] != 0 && connectivityMapTemp3 [counterY+verticalStart3-verticalStart2][counterX+horizontalStart3-horizontalStart2] == 1){
                            if (rangeMatrix [counterY][counterX] != 0) findConnectNo [rangeMatrix [counterY][counterX]]++;
                        }
                    }
                }
            }
            
            processConnectNo = 0;
            processConnectPosition = 0;
            
            for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
                if (findConnectNo [counter3] > processConnectNo){
                    processConnectNo = findConnectNo [counter3];
                    processConnectPosition = counter3;
                }
            }
            
            //========CC
            errorNoHold = 35;
            int **connectivityMapTemp = new int *[dimension3+1];
            errorNoHold = 36;
            int **connectivityMapTemp2 = new int *[dimension3+1];
            errorNoHold = 37;
            int **connectivityMapTemp4 = new int *[dimension3+1];
            
            for (int counter1 = 0; counter1 < dimension3+1; counter1++){
                errorNoHold = 38;
                connectivityMapTemp [counter1] = new int [dimension3+1];
                errorNoHold = 39;
                connectivityMapTemp2 [counter1] = new int [dimension3+1];
                errorNoHold = 40;
                connectivityMapTemp4 [counter1] = new int [dimension3+1];
            }
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    connectivityMapTemp [counterY][counterX] = 0;
                    connectivityMapTemp4 [counterY][counterX] = 0;
                }
            }
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (rangeMatrix [counterY][counterX] == processConnectPosition) connectivityMapTemp [counterY][counterX] = -1;
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
            //	cout<<" connectivityMapTemp "<<counterA<<endl;
            //}
            
            if (minPointDimY-30 >= 0) startY = minPointDimY-30;
            else startY = 0;
            
            if (maxPointDimY+30 < imageDimension) endY = maxPointDimY+31;
            else endY = imageDimension;
            
            if (minPointDimX-30 >= 0) startX = minPointDimX-30;
            else startX = 0;
            
            if (maxPointDimX+30 < imageDimension) endX = maxPointDimX+31;
            else endX = imageDimension;
            
            for (int counterY = startY; counterY < endY; counterY++){
                for (int counterX = startX; counterX < endX; counterX++){
                    connectFind = 0;
                    
                    for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                        if (extendConnectList [counter1*2] == revisedWorkingMap [counterY][counterX]) connectFind = 1;
                    }
                    
                    if (connectFind == 1){
                        if (counterY-verticalStart3 > 0 && counterY-verticalStart3 < dimension3 && counterX-horizontalStart3 > 0 && counterX-horizontalStart3 < dimension3)
                            connectivityMapTemp [counterY-verticalStart3][counterX-horizontalStart3] = revisedWorkingMap [counterY][counterX];
                    }
                }
            }
            
            for (int counter1 = 0; counter1 < referenceLineCount/2; counter1++){
                if (arrayReferenceLine [counter1*2]-horizontalStart3 >= 0 && arrayReferenceLine [counter1*2]-horizontalStart3 < dimension3 && arrayReferenceLine [counter1*2+1]-verticalStart3 >= 0 && arrayReferenceLine [counter1*2+1]-verticalStart3 < dimension3) connectivityMapTemp4 [arrayReferenceLine [counter1*2+1]-verticalStart3][arrayReferenceLine [counter1*2]-horizontalStart3] = 1;
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp4 [counterA][counterB];
            //	cout<<" connectivityMapTemp4 "<<counterA<<endl;
            //}
            
            connectivityNumber = -3;
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (connectivityMapTemp4 [counterY][counterX] == 0){
                        connectivityNumber = connectivityNumber+2;
                        connectAnalysisCount = 0;
                        
                        if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMapTemp4 [counterY][counterX] = connectivityNumber;
                        if (counterY-1 >= 0 && connectivityMapTemp4 [counterY-1][counterX] == 0){
                            connectivityMapTemp4 [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension3 && connectivityMapTemp4 [counterY][counterX+1] == 0){
                            connectivityMapTemp4 [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension3 && connectivityMapTemp4 [counterY+1][counterX] == 0){
                            connectivityMapTemp4 [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && connectivityMapTemp4 [counterY][counterX-1] == 0){
                            connectivityMapTemp4 [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && connectivityMapTemp4 [ySource-1][xSource] == 0){
                                        connectivityMapTemp4 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension3 && connectivityMapTemp4 [ySource][xSource+1] == 0){
                                        connectivityMapTemp4 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension3 && connectivityMapTemp4 [ySource+1][xSource] == 0){
                                        connectivityMapTemp4 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMapTemp4 [ySource][xSource-1] == 0){
                                        connectivityMapTemp4 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (connectivityMapTemp4 [counterY][counterX] < 0) connectivityMapTemp4 [counterY][counterX] = 0;
                    else connectivityMapTemp4 [counterY][counterX] = 1;
                }
            }
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (connectivityMapTemp4 [counterY][counterX] == 1) connectivityMapTemp [counterY][counterX] = maxConnectRevise+1;
                }
            }
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    connectivityMapTemp2 [counterY][counterX] = connectivityMapTemp [counterY][counterX];
                }
            }
            
            extendConnectList [extendConnectCount] = maxConnectRevise+1, extendConnectCount++;
            extendConnectList [extendConnectCount] = 0, extendConnectCount++;
            
            terminationFlag = 0;
            int startOrder = 0;
            int findFreePoint = 0;
            int connectNo = 0;
            int remainingCheck = 0;
            
            do{
                
                for (int counter1 = startOrder; counter1 < extendConnectCount/2; counter1++){
                    connectNo = extendConnectList [counter1*2];
                    
                    if (extendConnectList [counter1*2+1] == 0){
                        findFreePoint = 0;
                        
                        for (int counterY = 0; counterY < dimension3; counterY++){
                            for (int counterX = 0; counterX < dimension3; counterX++){
                                if (connectivityMapTemp [counterY][counterX] == connectNo){
                                    if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] == -1){
                                        connectivityMapTemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == -1){
                                        connectivityMapTemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterY-1 >= 0 && counterX+1 < dimension3 && connectivityMapTemp [counterY-1][counterX+1] == -1){
                                        connectivityMapTemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterX+1 < dimension3 && connectivityMapTemp [counterY][counterX+1] == -1){
                                        connectivityMapTemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterY+1 < dimension3 && counterX+1 < dimension3 && connectivityMapTemp [counterY+1][counterX+1] == -1){
                                        connectivityMapTemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterY+1 < dimension3 && connectivityMapTemp [counterY+1][counterX] == -1){
                                        connectivityMapTemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterY+1 < dimension3 && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] == -1){
                                        connectivityMapTemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == -1){
                                        connectivityMapTemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                    }
                                }
                            }
                        }
                        
                        for (int counterY = 0; counterY < dimension3; counterY++){
                            for (int counterX = 0; counterX < dimension3; counterX++) connectivityMapTemp [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                        }
                        
                        if (findFreePoint == 0) extendConnectList [counter1*2+1] = 1;
                    }
                }
                
                for (int counter1 = 0; counter1 < startOrder; counter1++){
                    connectNo = extendConnectList [counter1*2];
                    
                    if (extendConnectList [counter1*2+1] == 0){
                        findFreePoint = 0;
                        
                        for (int counterY = 0; counterY < dimension3; counterY++){
                            for (int counterX = 0; counterX < dimension3; counterX++){
                                if (connectivityMapTemp [counterY][counterX] == connectNo){
                                    if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] == -1){
                                        connectivityMapTemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == -1){
                                        connectivityMapTemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterY-1 >= 0 && counterX+1 < dimension3 && connectivityMapTemp [counterY-1][counterX+1] == -1){
                                        connectivityMapTemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterX+1 < dimension3 && connectivityMapTemp [counterY][counterX+1] == processConnectPosition){
                                        connectivityMapTemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterY+1 < dimension3 && counterX+1 < dimension3 && connectivityMapTemp [counterY+1][counterX+1] == -1){
                                        connectivityMapTemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterY+1 < dimension3 && connectivityMapTemp [counterY+1][counterX] == -1){
                                        connectivityMapTemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterY+1 < dimension3 && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] == -1){
                                        connectivityMapTemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == -1){
                                        connectivityMapTemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                    }
                                }
                            }
                        }
                        
                        for (int counterY = 0; counterY < dimension3; counterY++){
                            for (int counterX = 0; counterX < dimension3; counterX++) connectivityMapTemp [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                        }
                        
                        if (findFreePoint == 0) extendConnectList [counter1*2+1] = 1;
                    }
                }
                
                remainingCheck = 0;
                
                for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                    if (extendConnectList [counter1*2+1] == 0) remainingCheck = 1;
                }
                
                if (remainingCheck == 0) terminationFlag = 1;
                
                startOrder++;
                
                if (startOrder == extendConnectCount/2) startOrder = 0;
                
            } while (terminationFlag == 0);
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (connectivityMapTemp [counterY][counterX] == maxConnectRevise+1) connectivityMapTemp2 [counterY][counterX] = 1;
                    else{
                        
                        connectivityMapTemp2 [counterY][counterX] = 0;
                        connectivityMapTemp [counterY][counterX] = 0;
                    }
                }
            }
            
            //-------Zero Fill-------
            errorNoHold = 41;
            int **connectivityUpdate5 = new int *[dimension3+4];
            
            for (int counter1 = 0; counter1 < dimension3+4; counter1++){
                errorNoHold = 42;
                connectivityUpdate5 [counter1] = new int [dimension3+4];
            }
            
            for (int counterX = 0; counterX < dimension3+4; counterX++){
                for (int counterY = 0; counterY < dimension3+4; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
            }
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = connectivityMapTemp2 [counterY][counterX];
            }
            
            connectivityNumber = 0;
            
            for (int counterY2 = 0; counterY2 < dimension3+2; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension3+2; counterX2++){
                    if (connectivityUpdate5 [counterY2][counterX2] == 0){
                        connectivityNumber--;
                        connectAnalysisCount = 0;
                        
                        connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                        
                        if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                            connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                        }
                        if (counterX2+1 < dimension3+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                            connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        if (counterY2+1 < dimension3+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                            connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                        }
                        if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                            connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                        connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension3+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                        connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension3+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                        connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                        connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension3+2; counterA++){
            //	for (int counterB = 0; counterB < dimension3+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
            //	cout<<" connectivityUpdate5 "<<counterA<<endl;
            //}
            
            int connectTemp2 = 0;
            
            if (connectivityNumber < -1){
                errorNoHold = 43;
                int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                
                for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
                
                for (int counterY2 = 0; counterY2 < dimension3+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension3+2; counterX2++){
                        connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                        
                        if (connectTemp2 < -1){
                            connectTemp2 = connectTemp2*-1;
                            
                            if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2-1 >= 0 && counterX2+1 < dimension3+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterX2+1 < dimension3+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension3+2 && counterX2+1 < dimension3+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension3+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension3+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                        }
                    }
                }
                
                int zeroFillFlag = 0;
                
                for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                    if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
                }
                
                //for (int counter3 = 1; counter3 <= connectivityNumber*-1; counter3++){
                //    cout<<counter3<<" "<<connectCheckArray [counter3*2]<<" "<<connectCheckArray [counter3*2+1]<<" connectCheckArray"<<endl;
                //}
                
                //for (int counterA = 0; counterA < dimension3+2; counterA++){
                //    for (int counterB = 0; counterB < dimension3+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                //    cout<<" connectivityUpdate5 "<<counterA<<endl;
                //}
                
                if (zeroFillFlag == 1){
                    for (int counterY2 = 0; counterY2 < dimension3+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension3+2; counterX2++){
                            connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                            
                            if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                        }
                    }
                    
                    for (int counterY2 = 0; counterY2 < dimension3+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension3+2; counterX2++){
                            if (connectivityUpdate5 [counterY2][counterX2] > 0) connectivityMapTemp2 [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                        }
                    }
                }
                
                delete [] connectCheckArray;
            }
            
            for (int counter1 = 0; counter1 < dimension3+4; counter1++) delete [] connectivityUpdate5 [counter1];
            
            delete [] connectivityUpdate5;
            
            //------Connectivity analysis, For Zero------
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] != 0){
                        if (counterX+1 < dimension3 && connectivityMapTemp2 [counterY][counterX+1] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                        else if (counterY+1 < dimension3 && connectivityMapTemp2 [counterY+1][counterX] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                        else if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                        else if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                    }
                }
            }
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] > 0) connectivityMapTemp2 [counterY][counterX] = 0;
                    if (connectivityMapTemp2 [counterY][counterX] < 0) connectivityMapTemp2 [counterY][counterX] = 1;
                }
            }
            
            connectivityNumber = 0;
            
            for (int counterY2 = 0; counterY2 < dimension3; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension3; counterX2++){
                    if (connectivityMapTemp2 [counterY2][counterX2] == 0){
                        connectivityNumber--;
                        connectAnalysisCount = 0;
                        
                        connectivityMapTemp2 [counterY2][counterX2] = connectivityNumber;
                        
                        if (counterY2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2] == 0){
                            connectivityMapTemp2 [counterY2-1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                        }
                        if (counterX2+1 < dimension3 && connectivityMapTemp2 [counterY2][counterX2+1] == 0){
                            connectivityMapTemp2 [counterY2][counterX2+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        if (counterY2+1 < dimension3 && connectivityMapTemp2 [counterY2+1][counterX2] == 0){
                            connectivityMapTemp2 [counterY2+1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                        }
                        if (counterX2-1 >= 0 && connectivityMapTemp2 [counterY2][counterX2-1] == 0){
                            connectivityMapTemp2 [counterY2][counterX2-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                        connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension3 && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                        connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension3 && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                        connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                        connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            delete [] connectAnalysisX;
            delete [] connectAnalysisY;
            delete [] connectAnalysisTempX;
            delete [] connectAnalysisTempY;
            
            //------Determine number of pixels------
            connectivityNumber = connectivityNumber*-1;
            
            errorNoHold = 44;
            connectedPixels = new int [connectivityNumber+50];
            
            for (int counter1 = 0; counter1 <= connectivityNumber; counter1++) connectedPixels [counter1] = 0;
            
            for (int counterY2 = 0; counterY2 < dimension3; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension3; counterX2++){
                    if (connectivityMapTemp2 [counterY2][counterX2] < -1 && connectivityMapTemp [counterY2][counterX2] != 0){
                        connectedPixels [connectivityMapTemp2 [counterY2][counterX2]*-1]++;
                    }
                }
            }
            
            errorNoHold = 45;
            int **newConnectivityMapTemp = new int *[dimension3+4];
            for (int counter1 = 0; counter1 < dimension3+4; counter1++){
                errorNoHold = 46;
                newConnectivityMapTemp [counter1] = new int [dimension3+4];
            }
            
            for (int counterY = 0; counterY < dimension3+4; counterY++){
                for (int counterX = 0; counterX < dimension3+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
            }
            
            int largestConnect = 0;
            int largestConnectNo = 0;
            
            for (int counter1 = 2; counter1 <= connectivityNumber; counter1++){
                if (connectedPixels [counter1] > largestConnect){
                    largestConnect = connectedPixels [counter1];
                    largestConnectNo = counter1;
                }
            }
            
            for (int counterY2 = 0; counterY2 < dimension3; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension3; counterX2++){
                    if (connectivityMapTemp2 [counterY2][counterX2] == largestConnectNo*-1){
                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                            connectivityMapTemp2 [counterY2-1][counterX2-1] = 0;
                        }
                        if (counterY2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                            connectivityMapTemp2 [counterY2-1][counterX2] = 0;
                        }
                        if (counterY2-1 >= 0 && counterX2+1 < dimension3 && connectivityMapTemp2 [counterY2-1][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                            connectivityMapTemp2 [counterY2-1][counterX2+1] = 0;
                        }
                        if (counterX2+1 < dimension3 && connectivityMapTemp2 [counterY2][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                            connectivityMapTemp2 [counterY2][counterX2+1] = 0;
                        }
                        if (counterY2+1 < dimension3 && counterX2+1 < dimension3 && connectivityMapTemp2 [counterY2+1][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                            connectivityMapTemp2 [counterY2+1][counterX2+1] = 0;
                        }
                        if (counterY2+1 < dimension3 && connectivityMapTemp2 [counterY2+1][counterX2] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                            connectivityMapTemp2 [counterY2+1][counterX2] = 0;
                        }
                        if (counterY2+1 < dimension3 && counterX2-1 >= 0 && connectivityMapTemp2 [counterY2+1][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                            connectivityMapTemp2 [counterY2+1][counterX2-1] = 0;
                        }
                        if (counterX2-1 >= 0 && connectivityMapTemp2 [counterY2][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                            connectivityMapTemp2 [counterY2][counterX2-1] = 0;
                        }
                    }
                }
            }
            
            delete [] connectedPixels;
            
            int xPositionTempStart = 0;
            int yPositionTempStart = 0;
            int lineSize = 0;
            
            for (int counterY2 = 0; counterY2 < dimension3; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension3; counterX2++){
                    if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                        connectivityMapTemp2 [counterY2][counterX2] = 1;
                        xPositionTempStart = counterX2;
                        yPositionTempStart = counterY2;
                        lineSize++;
                    }
                    else connectivityMapTemp2 [counterY2][counterX2] = 0;
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
            //	cout<<" connectivityMapTemp2 "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < dimension3+4; counter1++) delete [] newConnectivityMapTemp [counter1];
            delete [] newConnectivityMapTemp;
            
            int constructedLineCount = 0;
            
            errorNoHold = 47;
            int *arrayNewLines = new int [lineSize*2+50];
            
            connectivityMapTemp2 [yPositionTempStart][xPositionTempStart] = -1;
            arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart3, constructedLineCount++;
            arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart3, constructedLineCount++;
            
            do{
                
                findFlag = 0;
                terminationFlag = 0;
                
                if (xPositionTempStart+1 < dimension3){
                    if (connectivityMapTemp2 [yPositionTempStart][xPositionTempStart+1] == 1){
                        connectivityMapTemp2 [yPositionTempStart][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart3, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart3, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart+1 < dimension3 && yPositionTempStart+1 < dimension3 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                        connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart3, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart3, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (yPositionTempStart+1 < dimension3 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart] == 1){
                        connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart3, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart3, constructedLineCount++;
                        yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension3 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                        connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart3, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart3, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart][xPositionTempStart-1] == 1){
                        connectivityMapTemp2 [yPositionTempStart][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart3, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart3, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                        connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart3, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart3, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart] == 1){
                        connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart3, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart3, constructedLineCount++;
                        yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart+1 < dimension3 && yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                        connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart3, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart3, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                    }
                }
                
            } while (terminationFlag == 1);
            
            delete [] arrayReferenceLine;
            arrayReferenceLine = new int [constructedLineCount+10];
            
            referenceLineCount = 0;
            
            for (int counter1 = 0; counter1 < constructedLineCount/2; counter1++){
                arrayReferenceLine [referenceLineCount] = arrayNewLines [counter1*2], referenceLineCount++;
                arrayReferenceLine [referenceLineCount] = arrayNewLines [counter1*2+1], referenceLineCount++;
            }
            
            delete [] arrayNewLines;
            delete [] extendConnectList;
            
            for (int counter1 = 0; counter1 < dimension3+1; counter1++){
                delete [] connectivityMapTemp [counter1];
                delete [] connectivityMapTemp2 [counter1];
                delete [] connectivityMapTemp4 [counter1];
            }
            
            delete [] connectivityMapTemp;
            delete [] connectivityMapTemp2;
            delete [] connectivityMapTemp4;
            
            for (int counter2 = 0; counter2 < dimension3+4; counter2++){
                delete [] rangeMatrix [counter2];
            }
            
            delete [] rangeMatrix;
            
            delete [] findConnectNo;
        }
        
        delete [] findReviseConnect;
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++) delete [] connectivityMapTemp3 [counter1];
        delete [] connectivityMapTemp3;
        
        errorNoHold = 0;
        subCompletionFlag2 = 0;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingMerge01 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"Merge-mergeExtendTrack"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
        
        subCompletionFlag2 = 0;
    }
}

-(void)mergeExtendTrackCurrent{
    try{
        
        errorNoHold = 0;
        subCompletionFlag2 = 1;
        
        int maxPointDimX = 0;
        int maxPointDimY = 0;
        int minPointDimX = 1000000;
        int minPointDimY = 1000000;
        
        for (int counter1 = 0; counter1 < referenceLineCount/2; counter1++){
            if (maxPointDimX < arrayReferenceLine [counter1*2]) maxPointDimX = arrayReferenceLine [counter1*2];
            if (minPointDimX > arrayReferenceLine [counter1*2]) minPointDimX = arrayReferenceLine [counter1*2];
            if (maxPointDimY < arrayReferenceLine [counter1*2+1]) maxPointDimY = arrayReferenceLine [counter1*2+1];
            if (minPointDimY > arrayReferenceLine [counter1*2+1]) minPointDimY = arrayReferenceLine [counter1*2+1];
        }
        
        int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
        int verticalLength = (maxPointDimY-minPointDimY)/2*2;
        int dimension = 0;
        
        if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
        if (horizontalLength < verticalLength) dimension = verticalLength+30;
        
        dimension = (dimension/2)*2;
        
        int horizontalStart2 = minPointDimX-(dimension-horizontalLength)/2;
        int verticalStart2 = minPointDimY-(dimension-verticalLength)/2;
        
        int horizontalLength2 = (maxPointDimX-minPointDimX)/2*2;
        int verticalLength2 = (maxPointDimY-minPointDimY)/2*2;
        int dimension2 = 0;
        int dimension2A = 0;
        int dimension2B = 0;
        
        if (horizontalLength2 >= verticalLength2) dimension2 = horizontalLength2+10;
        if (horizontalLength2 < verticalLength2) dimension2 = verticalLength2+10;
        
        dimension2A = (dimension2/2)*5;
        dimension2B = dimension2A+20;
        
        int horizontalStart2A = minPointDimX-(dimension2A-horizontalLength2)/2;
        int verticalStart2A = minPointDimY-(dimension2A-verticalLength2)/2;
        int horizontalStart2B = minPointDimX-(dimension2B-horizontalLength2)/2;
        int verticalStart2B = minPointDimY-(dimension2B-verticalLength2)/2;
        
        //cout<<horizontalStart2<<" "<<verticalStart2<<" "<<dimension<<" hol-ver-dim"<<endl;
        
        errorNoHold = 48;
        int **connectivityMapTemp3 = new int *[dimension+1];
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            errorNoHold = 49;
            connectivityMapTemp3 [counter1] = new int [dimension+1];
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp3 [counterY][counterX] = 0;
        }
        
        for (int counter1 = 0; counter1 < referenceLineCount/2; counter1++){
            if (arrayReferenceLine [counter1*2]-horizontalStart2 >= 0 && arrayReferenceLine [counter1*2]-horizontalStart2 < dimension && arrayReferenceLine [counter1*2+1]-verticalStart2 >= 0 && arrayReferenceLine [counter1*2+1]-verticalStart2 < dimension) connectivityMapTemp3 [arrayReferenceLine [counter1*2+1]-verticalStart2][arrayReferenceLine [counter1*2]-horizontalStart2] = 1;
        }
        
        //------Fill inside------
        errorNoHold = 50;
        int *connectAnalysisX = new int [dimension*4];
        errorNoHold = 51;
        int *connectAnalysisY = new int [dimension*4];
        errorNoHold = 52;
        int *connectAnalysisTempX = new int [dimension*4];
        errorNoHold = 53;
        int *connectAnalysisTempY = new int [dimension*4];
        
        int connectivityNumber = -3;
        int connectAnalysisCount = 0;
        int terminationFlag = 0;
        int connectAnalysisTempCount = 0;
        int xSource = 0;
        int ySource = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMapTemp3 [counterY][counterX] == 0){
                    connectivityNumber = connectivityNumber+2;
                    connectAnalysisCount = 0;
                    
                    if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMapTemp3 [counterY][counterX] = connectivityNumber;
                    if (counterY-1 >= 0 && connectivityMapTemp3 [counterY-1][counterX] == 0){
                        connectivityMapTemp3 [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension && connectivityMapTemp3 [counterY][counterX+1] == 0){
                        connectivityMapTemp3 [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && connectivityMapTemp3 [counterY+1][counterX] == 0){
                        connectivityMapTemp3 [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && connectivityMapTemp3 [counterY][counterX-1] == 0){
                        connectivityMapTemp3 [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && connectivityMapTemp3 [ySource-1][xSource] == 0){
                                    connectivityMapTemp3 [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension && connectivityMapTemp3 [ySource][xSource+1] == 0){
                                    connectivityMapTemp3 [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && connectivityMapTemp3 [ySource+1][xSource] == 0){
                                    connectivityMapTemp3 [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && connectivityMapTemp3 [ySource][xSource-1] == 0){
                                    connectivityMapTemp3 [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        delete [] connectAnalysisX;
        delete [] connectAnalysisY;
        delete [] connectAnalysisTempX;
        delete [] connectAnalysisTempY;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMapTemp3 [counterY][counterX] == -1) connectivityMapTemp3 [counterY][counterX] = 0;
                else connectivityMapTemp3 [counterY][counterX] = 1;
            }
        }
        
        int startY = 0;
        int endY = 0;
        int startX = 0;
        int endX = 0;
        
        //=========B
        errorNoHold = 54;
        int *findReviseConnect = new int [1000];
        for (int counter2 = 0; counter2 < 1000; counter2++) findReviseConnect [counter2] = 0;
        
        errorNoHold = 55;
        int **rangeMatrixA = new int *[dimension2A+4];
        
        for (int counter2 = 0; counter2 < dimension2A+4; counter2++){
            errorNoHold = 56;
            rangeMatrixA [counter2] = new int [dimension2A+4];
        }
        
        errorNoHold = 57;
        int **rangeMatrixB = new int *[dimension2B+4];
        
        for (int counter2 = 0; counter2 < dimension2B+4; counter2++){
            errorNoHold = 58;
            rangeMatrixB [counter2] = new int [dimension2B+4];
        }
        
        errorNoHold = 59;
        int *connectAnalysisXA = new int [dimension2A*4];
        errorNoHold = 60;
        int *connectAnalysisYA = new int [dimension2A*4];
        errorNoHold = 61;
        int *connectAnalysisTempXA = new int [dimension2A*4];
        errorNoHold = 62;
        int *connectAnalysisTempYA = new int [dimension2A*4];
        
        errorNoHold = 63;
        int *connectAnalysisXB = new int [dimension2B*4];
        errorNoHold = 64;
        int *connectAnalysisYB = new int [dimension2B*4];
        errorNoHold = 65;
        int *connectAnalysisTempXB = new int [dimension2B*4];
        errorNoHold = 66;
        int *connectAnalysisTempYB = new int [dimension2B*4];
        
        int freePixelFind = 0;
        int processConnectPosition = 0;
        int processConnectPosition2 = 0;
        int maxConnectRevise = 0;
        int findReviseConnectLimit = 1000;
        int connectivityNumberA = 0;
        int connectivityNumberB = 0;
        int connectTemp = 0;
        int maxConnect = 0;
        int processConnectNo = 0;
        int findFlag = 0;
        int cutOffFinal = 0;
        
        for (int counter2 = cutStatusDic; counter2 < 240; counter2 = counter2+10){ //====DIC
            for (int counterY = 0; counterY < dimension2A; counterY++){
                for (int counterX = 0; counterX < dimension2A; counterX++){
                    if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                        if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2A)*imageDimension+counterX+horizontalStart2A] == 100) rangeMatrixA [counterY][counterX] = 0;
                        else if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2A)*imageDimension+counterX+horizontalStart2A] < counter2) rangeMatrixA [counterY][counterX] = 0;
                        else rangeMatrixA [counterY][counterX] = -150;
                        
                        if (counterY+verticalStart2A-verticalStart2 >= 0 && counterY+verticalStart2A-verticalStart2 < dimension && counterX+horizontalStart2A-horizontalStart2 >= 0 && counterX+horizontalStart2A-horizontalStart2 < dimension){
                            if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] != 0 && connectivityMapTemp3 [counterY+verticalStart2A-verticalStart2][counterX+horizontalStart2A-horizontalStart2] != 1){
                                rangeMatrixA [counterY][counterX] = 0;
                            }
                        }
                    }
                    else rangeMatrixA [counterY][counterX] = 0;
                }
            }
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                        if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2B)*imageDimension+counterX+horizontalStart2B] == 100) rangeMatrixB [counterY][counterX] = 0;
                        else if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2B)*imageDimension+counterX+horizontalStart2B] < counter2) rangeMatrixB [counterY][counterX] = 0;
                        else rangeMatrixB [counterY][counterX] = -150;
                        
                        if (counterY+verticalStart2B-verticalStart2 >= 0 && counterY+verticalStart2B-verticalStart2 < dimension && counterX+horizontalStart2B-horizontalStart2 >= 0 && counterX+horizontalStart2B-horizontalStart2 < dimension){
                            if (revisedWorkingMap [counterY+verticalStart2B][counterX+horizontalStart2B] != 0 && connectivityMapTemp3 [counterY+verticalStart2B-verticalStart2][counterX+horizontalStart2B-horizontalStart2] != 1){
                                rangeMatrixB [counterY][counterX] = 0;
                            }
                        }
                    }
                    else rangeMatrixB [counterY][counterX] = 0;
                }
            }
            
            //-------MapA--------
            connectivityNumberA = 0;
            
            for (int counterY = 0; counterY < dimension2A; counterY++){
                for (int counterX = 0; counterX < dimension2A; counterX++){
                    if (rangeMatrixA [counterY][counterX] == -150){
                        connectivityNumberA++;
                        rangeMatrixA [counterY][counterX] = connectivityNumberA;
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixA [counterY-1][counterX-1] == -150){
                            rangeMatrixA [counterY-1][counterX-1] = connectivityNumberA;
                            connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && rangeMatrixA [counterY-1][counterX] == -150){
                            rangeMatrixA [counterY-1][counterX] = connectivityNumberA;
                            connectAnalysisXA [connectAnalysisCount] = counterX, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && counterX+1 < dimension2A && rangeMatrixA [counterY-1][counterX+1] == -150){
                            rangeMatrixA [counterY-1][counterX+1] = connectivityNumberA;
                            connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension2A && rangeMatrixA [counterY][counterX+1] == -150){
                            rangeMatrixA [counterY][counterX+1] = connectivityNumberA;
                            connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2A && counterX+1 < dimension2A && rangeMatrixA [counterY+1][counterX+1] == -150){
                            rangeMatrixA [counterY+1][counterX+1] = connectivityNumberA;
                            connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2A && rangeMatrixA [counterY+1][counterX] == -150){
                            rangeMatrixA [counterY+1][counterX] = connectivityNumberA;
                            connectAnalysisXA [connectAnalysisCount] = counterX, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2A && counterX-1 >= 0 && rangeMatrixA [counterY+1][counterX-1] == -150){
                            rangeMatrixA [counterY+1][counterX-1] = connectivityNumberA;
                            connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && rangeMatrixA [counterY][counterX-1] == -150){
                            rangeMatrixA [counterY][counterX-1] = connectivityNumberA;
                            connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                    xSource = connectAnalysisXA [counter3], ySource = connectAnalysisYA [counter3];
                                    
                                    if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrixA [ySource-1][xSource-1] == -150){
                                        rangeMatrixA [ySource-1][xSource-1] = connectivityNumberA;
                                        connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && rangeMatrixA [ySource-1][xSource] == -150){
                                        rangeMatrixA [ySource-1][xSource] = connectivityNumberA;
                                        connectAnalysisTempXA [connectAnalysisTempCount] = xSource, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && xSource+1 < dimension2A && rangeMatrixA [ySource-1][xSource+1] == -150){
                                        rangeMatrixA [ySource-1][xSource+1] = connectivityNumberA;
                                        connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension2A && rangeMatrixA [ySource][xSource+1] == -150){
                                        rangeMatrixA [ySource][xSource+1] = connectivityNumberA;
                                        connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 > dimension2A && xSource+1 < dimension2A && rangeMatrixA [ySource+1][xSource+1] == -150){
                                        rangeMatrixA [ySource+1][xSource+1] = connectivityNumberA;
                                        connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension2A && rangeMatrixA [ySource+1][xSource] == -150){
                                        rangeMatrixA [ySource+1][xSource] = connectivityNumberA;
                                        connectAnalysisTempXA [connectAnalysisTempCount] = xSource, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension2A && xSource-1 >= 0 && rangeMatrixA [ySource+1][xSource-1] == -150){
                                        rangeMatrixA [ySource+1][xSource-1] = connectivityNumberA;
                                        connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && rangeMatrixA [ySource][xSource-1] == -150){
                                        rangeMatrixA [ySource][xSource-1] = connectivityNumberA;
                                        connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                    connectAnalysisXA [counter3] = connectAnalysisTempXA [counter3], connectAnalysisYA [counter3] = connectAnalysisTempYA [counter3];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //------Determine number of pixels------
            errorNoHold = 67;
            int *connectedPixels = new int [connectivityNumberA+50];
            
            for (int counter3 = 0; counter3 <= connectivityNumberA; counter3++) connectedPixels [counter3] = 0;
            
            for (int counterY = 0; counterY < dimension2A; counterY++){
                for (int counterX = 0; counterX < dimension2A; counterX++){
                    if (rangeMatrixA [counterY][counterX] != 0) connectedPixels [rangeMatrixA [counterY][counterX]]++;
                }
            }
            
            //------Map up-date------
            connectTemp = 1;
            
            for (int counter3 = 1; counter3 <= connectivityNumberA; counter3++){
                if (connectedPixels [counter3] < 10) connectedPixels [counter3] = 0;
                else{
                    
                    connectedPixels [counter3] = connectTemp;
                    connectTemp++;
                }
            }
            
            maxConnect = 0;
            maxConnectRevise = 0;
            
            for (int counterY = 0; counterY < dimension2A; counterY++){
                for (int counterX = 0; counterX < dimension2A; counterX++){
                    if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                        if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A];
                        if ((connectTemp = rangeMatrixA [counterY][counterX]) != 0) rangeMatrixA [counterY][counterX] = connectedPixels [connectTemp];
                        else rangeMatrixA [counterY][counterX] = 0;
                        if (rangeMatrixA [counterY][counterX] > maxConnect) maxConnect = rangeMatrixA [counterY][counterX];
                    }
                }
            }
            
            delete [] connectedPixels;
            
            errorNoHold = 68;
            int *findConnectNo = new int [maxConnect+5];
            for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo [counter3] = 0;
            
            if (maxConnectRevise+10 > findReviseConnectLimit){
                delete [] findReviseConnect;
                errorNoHold = 69;
                findReviseConnect = new int [maxConnectRevise+50];
                findReviseConnectLimit = maxConnectRevise+50;
            }
            
            for (int counter3 = 0; counter3 < maxConnectRevise+5; counter3++) findReviseConnect [counter3] = 0;
            
            for (int counterY = 0; counterY < dimension2A; counterY++){
                for (int counterX = 0; counterX < dimension2A; counterX++){
                    if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension && counterY+verticalStart2A-verticalStart2 >= 0 && counterY+verticalStart2A-verticalStart2 < dimension && counterX+horizontalStart2A-horizontalStart2 >= 0 && counterX+horizontalStart2A-horizontalStart2 < dimension){
                        if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] != 0 && connectivityMapTemp3 [counterY+verticalStart2A-verticalStart2][counterX+horizontalStart2A-horizontalStart2] == 1){
                            if (rangeMatrixA [counterY][counterX] != 0) findConnectNo [rangeMatrixA [counterY][counterX]]++;
                        }
                    }
                }
            }
            
            processConnectNo = 0;
            processConnectPosition = 0;
            
            for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
                if (findConnectNo [counter3] > processConnectNo){
                    processConnectNo = findConnectNo [counter3];
                    processConnectPosition = counter3;
                }
            }
            
            if (processConnectPosition != 0){
                freePixelFind = 0;
                
                for (int counterY = 0; counterY < dimension2A; counterY++){
                    for (int counterX = 0; counterX < dimension2A; counterX++){
                        if (rangeMatrixA [counterY][counterX] == processConnectPosition){
                            if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                                if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] != 0){
                                    findReviseConnect [revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A]]++;
                                }
                                
                                if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] == 0) freePixelFind = 1;
                            }
                        }
                    }
                }
                
                //--------MapB---------
                connectivityNumberB = 0;
                
                for (int counterY = 0; counterY < dimension2B; counterY++){
                    for (int counterX = 0; counterX < dimension2B; counterX++){
                        if (rangeMatrixB [counterY][counterX] == -150){
                            connectivityNumberB++;
                            rangeMatrixB [counterY][counterX] = connectivityNumberB;
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixB [counterY-1][counterX-1] == -150){
                                rangeMatrixB [counterY-1][counterX-1] = connectivityNumberB;
                                connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && rangeMatrixB [counterY-1][counterX] == -150){
                                rangeMatrixB [counterY-1][counterX] = connectivityNumberB;
                                connectAnalysisXB [connectAnalysisCount] = counterX, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && counterX+1 < dimension2B && rangeMatrixB [counterY-1][counterX+1] == -150){
                                rangeMatrixB [counterY-1][counterX+1] = connectivityNumberB;
                                connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension2B && rangeMatrixB [counterY][counterX+1] == -150){
                                rangeMatrixB [counterY][counterX+1] = connectivityNumberB;
                                connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension2B && counterX+1 < dimension2B && rangeMatrixB [counterY+1][counterX+1] == -150){
                                rangeMatrixB [counterY+1][counterX+1] = connectivityNumberB;
                                connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension2B && rangeMatrixB [counterY+1][counterX] == -150){
                                rangeMatrixB [counterY+1][counterX] = connectivityNumberB;
                                connectAnalysisXB [connectAnalysisCount] = counterX, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension2B && counterX-1 >= 0 && rangeMatrixB [counterY+1][counterX-1] == -150){
                                rangeMatrixB [counterY+1][counterX-1] = connectivityNumberB;
                                connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && rangeMatrixB [counterY][counterX-1] == -150){
                                rangeMatrixB [counterY][counterX-1] = connectivityNumberB;
                                connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                        xSource = connectAnalysisXB [counter3], ySource = connectAnalysisYB [counter3];
                                        
                                        if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrixB [ySource-1][xSource-1] == -150){
                                            rangeMatrixB [ySource-1][xSource-1] = connectivityNumberB;
                                            connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && rangeMatrixB [ySource-1][xSource] == -150){
                                            rangeMatrixB [ySource-1][xSource] = connectivityNumberB;
                                            connectAnalysisTempXB [connectAnalysisTempCount] = xSource, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && xSource+1 < dimension2B && rangeMatrixB [ySource-1][xSource+1] == -150){
                                            rangeMatrixB [ySource-1][xSource+1] = connectivityNumberB;
                                            connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension2B && rangeMatrixB [ySource][xSource+1] == -150){
                                            rangeMatrixB [ySource][xSource+1] = connectivityNumberB;
                                            connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 > dimension2B && xSource+1 < dimension2B && rangeMatrixB [ySource+1][xSource+1] == -150){
                                            rangeMatrixB [ySource+1][xSource+1] = connectivityNumberB;
                                            connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension2B && rangeMatrixB [ySource+1][xSource] == -150){
                                            rangeMatrixB [ySource+1][xSource] = connectivityNumberB;
                                            connectAnalysisTempXB [connectAnalysisTempCount] = xSource, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension2B && xSource-1 >= 0 && rangeMatrixB [ySource+1][xSource-1] == -150){
                                            rangeMatrixB [ySource+1][xSource-1] = connectivityNumberB;
                                            connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && rangeMatrixB [ySource][xSource-1] == -150){
                                            rangeMatrixB [ySource][xSource-1] = connectivityNumberB;
                                            connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                        connectAnalysisXB [counter3] = connectAnalysisTempXB [counter3], connectAnalysisYB [counter3] = connectAnalysisTempYB [counter3];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //------Determine number of pixels------
                errorNoHold = 70;
                connectedPixels = new int [connectivityNumberB+50];
                
                for (int counter3 = 0; counter3 <= connectivityNumberB; counter3++) connectedPixels [counter3] = 0;
                
                for (int counterY = 0; counterY < dimension2B; counterY++){
                    for (int counterX = 0; counterX < dimension2B; counterX++){
                        if (rangeMatrixB [counterY][counterX] != 0) connectedPixels [rangeMatrixB [counterY][counterX]]++;
                    }
                }
                
                //------Map up-date------
                connectTemp = 1;
                
                for (int counter3 = 1; counter3 <= connectivityNumberB; counter3++){
                    if (connectedPixels [counter3] < 10) connectedPixels [counter3] = 0;
                    else{
                        
                        connectedPixels [counter3] = connectTemp;
                        connectTemp++;
                    }
                }
                
                maxConnect = 0;
                
                for (int counterY = 0; counterY < dimension2B; counterY++){
                    for (int counterX = 0; counterX < dimension2B; counterX++){
                        if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                            if ((connectTemp = rangeMatrixB [counterY][counterX]) != 0) rangeMatrixB [counterY][counterX] = connectedPixels [connectTemp];
                            else rangeMatrixB [counterY][counterX] = 0;
                            
                            if (rangeMatrixB [counterY][counterX] > maxConnect) maxConnect = rangeMatrixB [counterY][counterX];
                        }
                    }
                }
                
                delete [] connectedPixels;
                
                errorNoHold = 71;
                int *findConnectNo2 = new int [maxConnect+5];
                for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo2 [counter3] = 0;
                
                for (int counterY = 0; counterY < dimension2B; counterY++){
                    for (int counterX = 0; counterX < dimension2B; counterX++){
                        if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension && counterY+verticalStart2B-verticalStart2 >= 0 && counterY+verticalStart2B-verticalStart2 < dimension && counterX+horizontalStart2B-horizontalStart2 >= 0 && counterX+horizontalStart2B-horizontalStart2 < dimension){
                            if (revisedWorkingMap [counterY+verticalStart2B][counterX+horizontalStart2B] != 0 && connectivityMapTemp3 [counterY+verticalStart2B-verticalStart2][counterX+horizontalStart2B-horizontalStart2] == 1){
                                if (rangeMatrixB [counterY][counterX] != 0) findConnectNo2 [rangeMatrixB [counterY][counterX]]++;
                            }
                        }
                    }
                }
                
                processConnectNo = 0;
                processConnectPosition2 = 0;
                
                for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
                    if (findConnectNo2 [counter3] > processConnectNo){
                        processConnectNo = findConnectNo2 [counter3];
                        processConnectPosition2 = counter3;
                    }
                }
                
                if (processConnectPosition2 != 0){
                    for (int counterY = 0; counterY < dimension2A; counterY++){
                        for (int counterX = 0; counterX < dimension2A; counterX++){
                            if ((counterY+verticalStart2A)-verticalStart2B >= 0 && (counterY+verticalStart2A)-verticalStart2B < +dimension2B && (counterX+horizontalStart2A)-horizontalStart2B >= 0 && (counterX+horizontalStart2A)-horizontalStart2B < dimension2B){
                                rangeMatrixB [(counterY+verticalStart2A)-verticalStart2B][(counterX+horizontalStart2A)-horizontalStart2B] = 0;
                            }
                        }
                    }
                    
                    findFlag = 0;
                    
                    for (int counterY = 0; counterY < dimension2B; counterY++){
                        for (int counterX = 0; counterX < dimension2B; counterX++){
                            if (rangeMatrixB [counterY][counterX] == processConnectPosition2){
                                findFlag = 1;
                                break;
                            }
                        }
                    }
                    
                    if (findFlag == 0){
                        cutOffFinal = counter2;
                        
                        delete [] findConnectNo;
                        delete [] findConnectNo2;
                        break;
                    }
                }
                else{
                    
                    if (counter2 != 20) cutOffFinal = counter2-10;
                    else cutOffFinal = 0;
                    
                    delete [] findConnectNo;
                    delete [] findConnectNo2;
                    break;
                }
                
                delete [] findConnectNo2;
            }
            else{
                
                if (counter2 != 20) cutOffFinal = counter2-10;
                else cutOffFinal = 0;
                
                delete [] findConnectNo;
                break;
            }
            
            delete [] findConnectNo;
        }
        
        delete [] connectAnalysisXA;
        delete [] connectAnalysisYA;
        delete [] connectAnalysisTempXA;
        delete [] connectAnalysisTempYA;
        
        delete [] connectAnalysisXB;
        delete [] connectAnalysisYB;
        delete [] connectAnalysisTempXB;
        delete [] connectAnalysisTempYB;
        
        for (int counter2 = 0; counter2 < dimension2A+4; counter2++){
            delete [] rangeMatrixA [counter2];
        }
        
        delete [] rangeMatrixA;
        
        for (int counter2 = 0; counter2 < dimension2B+4; counter2++){
            delete [] rangeMatrixB [counter2];
        }
        
        delete [] rangeMatrixB;
        
        if (cutOffFinal != 0 && freePixelFind == 1){
            int extendConnectCount = 0;
            
            for (int counter1 = 1; counter1 < maxConnectRevise+5; counter1++){
                if (findReviseConnect [counter1] != 0) extendConnectCount++;
            }
            
            errorNoHold = 72;
            int *extendConnectList = new int [extendConnectCount*2+4];
            extendConnectCount = 0;
            
            for (int counter1 = 1; counter1 < maxConnectRevise+5; counter1++){
                if (findReviseConnect [counter1] != 0){
                    extendConnectList [extendConnectCount] = counter1, extendConnectCount++;
                    extendConnectList [extendConnectCount] = 0, extendConnectCount++;
                }
            }
            
            extendConnectList [extendConnectCount] = maxConnectRevise+1, extendConnectCount++;
            extendConnectList [extendConnectCount] = 0, extendConnectCount++;
            
            int connectFind = 0;
            
            for (int counter1 = 0; counter1 < timeSelectedCurrentCount/10; counter1++){
                connectFind = 0;
                
                for (int counter2 = 0; counter2 < extendConnectCount/2; counter2++){
                    if (extendConnectList [counter2*2] == arrayTimeSelectedCurrent [counter1*10+8]) connectFind = 1;
                }
                
                if (connectFind == 1){
                    for (int counter2 = arrayTimeSelectedCurrent [counter1*10+2]; counter2 < positionReviseCurrentCount/7; counter2++){
                        if (arrayPositionReviseCurrent [counter2*7+3] == arrayTimeSelectedCurrent [counter1*10+8]){
                            if (maxPointDimX < arrayPositionReviseCurrent [counter2*7]) maxPointDimX = arrayPositionReviseCurrent [counter2*7];
                            if (minPointDimX > arrayPositionReviseCurrent [counter2*7]) minPointDimX = arrayPositionReviseCurrent [counter2*7];
                            if (maxPointDimY < arrayPositionReviseCurrent [counter2*7+1]) maxPointDimY = arrayPositionReviseCurrent [counter2*7+1];
                            if (minPointDimY > arrayPositionReviseCurrent [counter2*7+1]) minPointDimY = arrayPositionReviseCurrent [counter2*7+1];
                        }
                        else{
                            
                            break;
                        }
                    }
                }
            }
            
            horizontalLength = (maxPointDimX-minPointDimX)/2*2;
            verticalLength = (maxPointDimY-minPointDimY)/2*2;
            int dimension3 = 0;
            
            if (horizontalLength >= verticalLength) dimension3 = horizontalLength+30;
            if (horizontalLength < verticalLength) dimension3 = verticalLength+30;
            
            dimension3 = (dimension3/2)*5;
            
            int horizontalStart3 = minPointDimX-(dimension3-horizontalLength)/2;
            int verticalStart3 = minPointDimY-(dimension3-verticalLength)/2;
            
            //=======CC
            errorNoHold = 73;
            int **rangeMatrix = new int *[dimension3+4];
            
            for (int counter2 = 0; counter2 < dimension3+4; counter2++){
                errorNoHold = 74;
                rangeMatrix [counter2] = new int [dimension3+4];
            }
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (counterY+verticalStart3 >= 0 && counterY+verticalStart3 < imageDimension && counterX+horizontalStart3 >= 0 && counterX+horizontalStart3 < imageDimension){
                        if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart3)*imageDimension+counterX+horizontalStart3] == 100) rangeMatrix [counterY][counterX] = 0;
                        else if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart3)*imageDimension+counterX+horizontalStart3] < cutOffFinal) rangeMatrix [counterY][counterX] = 0;
                        else rangeMatrix [counterY][counterX] = -150;
                        
                        if (counterY+verticalStart3-verticalStart2 >= 0 && counterY+verticalStart3-verticalStart2 < dimension && counterX+horizontalStart3-horizontalStart2 >= 0 && counterX+horizontalStart3-horizontalStart2 < dimension){
                            if (revisedWorkingMap [counterY+verticalStart3][counterX+horizontalStart3] != 0 && connectivityMapTemp3 [counterY+verticalStart3-verticalStart2][counterX+horizontalStart3-horizontalStart2] != 1){
                                rangeMatrix [counterY][counterX] = 0;
                            }
                        }
                    }
                    else rangeMatrix [counterY][counterX] = 0;
                }
            }
            
            errorNoHold = 75;
            connectAnalysisX = new int [dimension3*4];
            errorNoHold = 76;
            connectAnalysisY = new int [dimension3*4];
            errorNoHold = 77;
            connectAnalysisTempX = new int [dimension3*4];
            errorNoHold = 78;
            connectAnalysisTempY = new int [dimension3*4];
            
            connectivityNumber = 0;
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (rangeMatrix [counterY][counterX] == -150){
                        connectivityNumber++;
                        rangeMatrix [counterY][counterX] = connectivityNumber;
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrix [counterY-1][counterX-1] == -150){
                            rangeMatrix [counterY-1][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && rangeMatrix [counterY-1][counterX] == -150){
                            rangeMatrix [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && counterX+1 < dimension3 && rangeMatrix [counterY-1][counterX+1] == -150){
                            rangeMatrix [counterY-1][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension3 && rangeMatrix [counterY][counterX+1] == -150){
                            rangeMatrix [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension3 && counterX+1 < dimension3 && rangeMatrix [counterY+1][counterX+1] == -150){
                            rangeMatrix [counterY+1][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension3 && rangeMatrix [counterY+1][counterX] == -150){
                            rangeMatrix [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension3 && counterX-1 >= 0 && rangeMatrix [counterY+1][counterX-1] == -150){
                            rangeMatrix [counterY+1][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && rangeMatrix [counterY][counterX-1] == -150){
                            rangeMatrix [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                    xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                    
                                    if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrix [ySource-1][xSource-1] == -150){
                                        rangeMatrix [ySource-1][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && rangeMatrix [ySource-1][xSource] == -150){
                                        rangeMatrix [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && xSource+1 < dimension3 && rangeMatrix [ySource-1][xSource+1] == -150){
                                        rangeMatrix [ySource-1][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension3 && rangeMatrix [ySource][xSource+1] == -150){
                                        rangeMatrix [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 > dimension3 && xSource+1 < dimension3 && rangeMatrix [ySource+1][xSource+1] == -150){
                                        rangeMatrix [ySource+1][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension3 && rangeMatrix [ySource+1][xSource] == -150){
                                        rangeMatrix [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension3 && xSource-1 >= 0 && rangeMatrix [ySource+1][xSource-1] == -150){
                                        rangeMatrix [ySource+1][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && rangeMatrix [ySource][xSource-1] == -150){
                                        rangeMatrix [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                    connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //------Determine number of pixels------
            errorNoHold = 79;
            int *connectedPixels = new int [connectivityNumber+50];
            
            for (int counter3 = 0; counter3 <= connectivityNumber; counter3++) connectedPixels [counter3] = 0;
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (rangeMatrix [counterY][counterX] != 0) connectedPixels [rangeMatrix [counterY][counterX]]++;
                }
            }
            
            //------Map up-date------
            connectTemp = 1;
            
            for (int counter3 = 1; counter3 <= connectivityNumber; counter3++){
                if (connectedPixels [counter3] < 10) connectedPixels [counter3] = 0;
                else{
                    
                    connectedPixels [counter3] = connectTemp;
                    connectTemp++;
                }
            }
            
            maxConnect = 0;
            maxConnectRevise = 0;
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (counterY+verticalStart3 >= 0 && counterY+verticalStart3 < imageDimension && counterX+horizontalStart3 >= 0 && counterX+horizontalStart3 < imageDimension){
                        if (revisedWorkingMap [counterY+verticalStart3][counterX+horizontalStart3] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart3][counterX+horizontalStart3];
                        if ((connectTemp = rangeMatrix [counterY][counterX]) != 0) rangeMatrix [counterY][counterX] = connectedPixels [connectTemp];
                        else rangeMatrix [counterY][counterX] = 0;
                        if (rangeMatrix [counterY][counterX] > maxConnect) maxConnect = rangeMatrix [counterY][counterX];
                    }
                }
            }
            
            delete [] connectedPixels;
            
            errorNoHold = 80;
            int *findConnectNo = new int [maxConnect+5];
            for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo [counter3] = 0;
            
            if (maxConnectRevise+10 > findReviseConnectLimit){
                delete [] findReviseConnect;
                errorNoHold = 81;
                findReviseConnect = new int [maxConnectRevise+50];
            }
            
            for (int counter3 = 0; counter3 < maxConnectRevise+5; counter3++) findReviseConnect [counter3] = 0;
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (counterY+verticalStart3 >= 0 && counterY+verticalStart3 < imageDimension && counterX+horizontalStart3 >= 0 && counterX+horizontalStart3 < imageDimension && counterY+verticalStart3-verticalStart2 >= 0 && counterY+verticalStart3-verticalStart2 < dimension && counterX+horizontalStart3-horizontalStart2 >= 0 && counterX+horizontalStart3-horizontalStart2 < dimension){
                        if (revisedWorkingMap [counterY+verticalStart3][counterX+horizontalStart3] != 0 && connectivityMapTemp3 [counterY+verticalStart3-verticalStart2][counterX+horizontalStart3-horizontalStart2] == 1){
                            if (rangeMatrix [counterY][counterX] != 0) findConnectNo [rangeMatrix [counterY][counterX]]++;
                        }
                    }
                }
            }
            
            processConnectNo = 0;
            processConnectPosition = 0;
            
            for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
                if (findConnectNo [counter3] > processConnectNo){
                    processConnectNo = findConnectNo [counter3];
                    processConnectPosition = counter3;
                }
            }
            
            //========CC
            errorNoHold = 82;
            int **connectivityMapTemp = new int *[dimension3+1];
            errorNoHold = 83;
            int **connectivityMapTemp2 = new int *[dimension3+1];
            errorNoHold = 84;
            int **connectivityMapTemp4 = new int *[dimension3+1];
            
            for (int counter1 = 0; counter1 < dimension3+1; counter1++){
                errorNoHold = 85;
                connectivityMapTemp [counter1] = new int [dimension3+1];
                errorNoHold = 86;
                connectivityMapTemp2 [counter1] = new int [dimension3+1];
                errorNoHold = 87;
                connectivityMapTemp4 [counter1] = new int [dimension3+1];
            }
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    connectivityMapTemp [counterY][counterX] = 0;
                    connectivityMapTemp4 [counterY][counterX] = 0;
                }
            }
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (rangeMatrix [counterY][counterX] == processConnectPosition) connectivityMapTemp [counterY][counterX] = -1;
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
            //	cout<<" connectivityMapTemp "<<counterA<<endl;
            //}
            
            if (minPointDimY-30 >= 0) startY = minPointDimY-30;
            else startY = 0;
            
            if (maxPointDimY+30 < imageDimension) endY = maxPointDimY+31;
            else endY = imageDimension;
            
            if (minPointDimX-30 >= 0) startX = minPointDimX-30;
            else startX = 0;
            
            if (maxPointDimX+30 < imageDimension) endX = maxPointDimX+31;
            else endX = imageDimension;
            
            for (int counterY = startY; counterY < endY; counterY++){
                for (int counterX = startX; counterX < endX; counterX++){
                    connectFind = 0;
                    
                    for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                        if (extendConnectList [counter1*2] == revisedWorkingMap [counterY][counterX]) connectFind = 1;
                    }
                    
                    if (connectFind == 1){
                        if (counterY-verticalStart3 > 0 && counterY-verticalStart3 < dimension3 && counterX-horizontalStart3 > 0 && counterX-horizontalStart3 < dimension3)
                            connectivityMapTemp [counterY-verticalStart3][counterX-horizontalStart3] = revisedWorkingMap [counterY][counterX];
                    }
                }
            }
            
            for (int counter1 = 0; counter1 < referenceLineCount/2; counter1++){
                if (arrayReferenceLine [counter1*2]-horizontalStart3 >= 0 && arrayReferenceLine [counter1*2]-horizontalStart3 < dimension3 && arrayReferenceLine [counter1*2+1]-verticalStart3 >= 0 && arrayReferenceLine [counter1*2+1]-verticalStart3 < dimension3) connectivityMapTemp4 [arrayReferenceLine [counter1*2+1]-verticalStart3][arrayReferenceLine [counter1*2]-horizontalStart3] = 1;
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp4 [counterA][counterB];
            //	cout<<" connectivityMapTemp4 "<<counterA<<endl;
            //}
            
            connectivityNumber = -3;
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (connectivityMapTemp4 [counterY][counterX] == 0){
                        connectivityNumber = connectivityNumber+2;
                        connectAnalysisCount = 0;
                        
                        if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMapTemp4 [counterY][counterX] = connectivityNumber;
                        if (counterY-1 >= 0 && connectivityMapTemp4 [counterY-1][counterX] == 0){
                            connectivityMapTemp4 [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension3 && connectivityMapTemp4 [counterY][counterX+1] == 0){
                            connectivityMapTemp4 [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension3 && connectivityMapTemp4 [counterY+1][counterX] == 0){
                            connectivityMapTemp4 [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && connectivityMapTemp4 [counterY][counterX-1] == 0){
                            connectivityMapTemp4 [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && connectivityMapTemp4 [ySource-1][xSource] == 0){
                                        connectivityMapTemp4 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension3 && connectivityMapTemp4 [ySource][xSource+1] == 0){
                                        connectivityMapTemp4 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension3 && connectivityMapTemp4 [ySource+1][xSource] == 0){
                                        connectivityMapTemp4 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMapTemp4 [ySource][xSource-1] == 0){
                                        connectivityMapTemp4 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (connectivityMapTemp4 [counterY][counterX] < 0) connectivityMapTemp4 [counterY][counterX] = 0;
                    else connectivityMapTemp4 [counterY][counterX] = 1;
                }
            }
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (connectivityMapTemp4 [counterY][counterX] == 1) connectivityMapTemp [counterY][counterX] = maxConnectRevise+1;
                }
            }
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    connectivityMapTemp2 [counterY][counterX] = connectivityMapTemp [counterY][counterX];
                }
            }
            
            extendConnectList [extendConnectCount] = maxConnectRevise+1, extendConnectCount++;
            extendConnectList [extendConnectCount] = 0, extendConnectCount++;
            
            terminationFlag = 0;
            int startOrder = 0;
            int findFreePoint = 0;
            int connectNo = 0;
            int remainingCheck = 0;
            
            do{
                
                for (int counter1 = startOrder; counter1 < extendConnectCount/2; counter1++){
                    connectNo = extendConnectList [counter1*2];
                    
                    if (extendConnectList [counter1*2+1] == 0){
                        findFreePoint = 0;
                        
                        for (int counterY = 0; counterY < dimension3; counterY++){
                            for (int counterX = 0; counterX < dimension3; counterX++){
                                if (connectivityMapTemp [counterY][counterX] == connectNo){
                                    if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] == -1){
                                        connectivityMapTemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == -1){
                                        connectivityMapTemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterY-1 >= 0 && counterX+1 < dimension3 && connectivityMapTemp [counterY-1][counterX+1] == -1){
                                        connectivityMapTemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterX+1 < dimension3 && connectivityMapTemp [counterY][counterX+1] == -1){
                                        connectivityMapTemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterY+1 < dimension3 && counterX+1 < dimension3 && connectivityMapTemp [counterY+1][counterX+1] == -1){
                                        connectivityMapTemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterY+1 < dimension3 && connectivityMapTemp [counterY+1][counterX] == -1){
                                        connectivityMapTemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterY+1 < dimension3 && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] == -1){
                                        connectivityMapTemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == -1){
                                        connectivityMapTemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                    }
                                }
                            }
                        }
                        
                        for (int counterY = 0; counterY < dimension3; counterY++){
                            for (int counterX = 0; counterX < dimension3; counterX++) connectivityMapTemp [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                        }
                        
                        if (findFreePoint == 0) extendConnectList [counter1*2+1] = 1;
                    }
                }
                
                for (int counter1 = 0; counter1 < startOrder; counter1++){
                    connectNo = extendConnectList [counter1*2];
                    
                    if (extendConnectList [counter1*2+1] == 0){
                        findFreePoint = 0;
                        
                        for (int counterY = 0; counterY < dimension3; counterY++){
                            for (int counterX = 0; counterX < dimension3; counterX++){
                                if (connectivityMapTemp [counterY][counterX] == connectNo){
                                    if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] == -1){
                                        connectivityMapTemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == -1){
                                        connectivityMapTemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterY-1 >= 0 && counterX+1 < dimension3 && connectivityMapTemp [counterY-1][counterX+1] == -1){
                                        connectivityMapTemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterX+1 < dimension3 && connectivityMapTemp [counterY][counterX+1] == processConnectPosition){
                                        connectivityMapTemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterY+1 < dimension3 && counterX+1 < dimension3 && connectivityMapTemp [counterY+1][counterX+1] == -1){
                                        connectivityMapTemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterY+1 < dimension3 && connectivityMapTemp [counterY+1][counterX] == -1){
                                        connectivityMapTemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterY+1 < dimension3 && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] == -1){
                                        connectivityMapTemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                    }
                                    if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == -1){
                                        connectivityMapTemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                    }
                                }
                            }
                        }
                        
                        for (int counterY = 0; counterY < dimension3; counterY++){
                            for (int counterX = 0; counterX < dimension3; counterX++) connectivityMapTemp [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                        }
                        
                        if (findFreePoint == 0) extendConnectList [counter1*2+1] = 1;
                    }
                }
                
                remainingCheck = 0;
                
                for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                    if (extendConnectList [counter1*2+1] == 0) remainingCheck = 1;
                }
                
                if (remainingCheck == 0) terminationFlag = 1;
                
                startOrder++;
                
                if (startOrder == extendConnectCount/2) startOrder = 0;
                
            } while (terminationFlag == 0);
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (connectivityMapTemp [counterY][counterX] == maxConnectRevise+1) connectivityMapTemp2 [counterY][counterX] = 1;
                    else{
                        
                        connectivityMapTemp2 [counterY][counterX] = 0;
                        connectivityMapTemp [counterY][counterX] = 0;
                    }
                }
            }
            
            //-------Zero Fill-------
            errorNoHold = 88;
            int **connectivityUpdate5 = new int *[dimension3+4];
            
            for (int counter1 = 0; counter1 < dimension3+4; counter1++){
                errorNoHold = 89;
                connectivityUpdate5 [counter1] = new int [dimension3+4];
            }
            
            for (int counterX = 0; counterX < dimension3+4; counterX++){
                for (int counterY = 0; counterY < dimension3+4; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
            }
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = connectivityMapTemp2 [counterY][counterX];
            }
            
            connectivityNumber = 0;
            
            for (int counterY2 = 0; counterY2 < dimension3+2; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension3+2; counterX2++){
                    if (connectivityUpdate5 [counterY2][counterX2] == 0){
                        connectivityNumber--;
                        connectAnalysisCount = 0;
                        
                        connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                        
                        if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                            connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                        }
                        if (counterX2+1 < dimension3+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                            connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        if (counterY2+1 < dimension3+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                            connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                        }
                        if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                            connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                        connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension3+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                        connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension3+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                        connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                        connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension3+2; counterA++){
            //	for (int counterB = 0; counterB < dimension3+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
            //	cout<<" connectivityUpdate5 "<<counterA<<endl;
            //}
            
            int connectTemp2 = 0;
            
            if (connectivityNumber < -1){
                errorNoHold = 90;
                int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                
                for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
                
                for (int counterY2 = 0; counterY2 < dimension3+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension3+2; counterX2++){
                        connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                        
                        if (connectTemp2 < -1){
                            connectTemp2 = connectTemp2*-1;
                            
                            if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2-1 >= 0 && counterX2+1 < dimension3+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterX2+1 < dimension3+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension3+2 && counterX2+1 < dimension3+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension3+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension3+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                        }
                    }
                }
                
                int zeroFillFlag = 0;
                
                for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                    if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
                }
                
                //for (int counter3 = 1; counter3 <= connectivityNumber*-1; counter3++){
                //    cout<<counter3<<" "<<connectCheckArray [counter3*2]<<" "<<connectCheckArray [counter3*2+1]<<" connectCheckArray"<<endl;
                //}
                
                //for (int counterA = 0; counterA < dimension3+2; counterA++){
                //    for (int counterB = 0; counterB < dimension3+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                //    cout<<" connectivityUpdate5 "<<counterA<<endl;
                //}
                
                if (zeroFillFlag == 1){
                    for (int counterY2 = 0; counterY2 < dimension3+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension3+2; counterX2++){
                            connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                            
                            if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                        }
                    }
                    
                    for (int counterY2 = 0; counterY2 < dimension3+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension3+2; counterX2++){
                            if (connectivityUpdate5 [counterY2][counterX2] > 0) connectivityMapTemp2 [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                        }
                    }
                }
                
                delete [] connectCheckArray;
            }
            
            for (int counter1 = 0; counter1 < dimension3+4; counter1++) delete [] connectivityUpdate5 [counter1];
            
            delete [] connectivityUpdate5;
            
            //------Connectivity analysis, For Zero------
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] != 0){
                        if (counterX+1 < dimension3 && connectivityMapTemp2 [counterY][counterX+1] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                        else if (counterY+1 < dimension3 && connectivityMapTemp2 [counterY+1][counterX] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                        else if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                        else if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                    }
                }
            }
            
            for (int counterY = 0; counterY < dimension3; counterY++){
                for (int counterX = 0; counterX < dimension3; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] > 0) connectivityMapTemp2 [counterY][counterX] = 0;
                    if (connectivityMapTemp2 [counterY][counterX] < 0) connectivityMapTemp2 [counterY][counterX] = 1;
                }
            }
            
            connectivityNumber = 0;
            
            for (int counterY2 = 0; counterY2 < dimension3; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension3; counterX2++){
                    if (connectivityMapTemp2 [counterY2][counterX2] == 0){
                        connectivityNumber--;
                        connectAnalysisCount = 0;
                        
                        connectivityMapTemp2 [counterY2][counterX2] = connectivityNumber;
                        
                        if (counterY2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2] == 0){
                            connectivityMapTemp2 [counterY2-1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                        }
                        if (counterX2+1 < dimension3 && connectivityMapTemp2 [counterY2][counterX2+1] == 0){
                            connectivityMapTemp2 [counterY2][counterX2+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        if (counterY2+1 < dimension3 && connectivityMapTemp2 [counterY2+1][counterX2] == 0){
                            connectivityMapTemp2 [counterY2+1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                        }
                        if (counterX2-1 >= 0 && connectivityMapTemp2 [counterY2][counterX2-1] == 0){
                            connectivityMapTemp2 [counterY2][counterX2-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                        connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension3 && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                        connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension3 && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                        connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                        connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            delete [] connectAnalysisX;
            delete [] connectAnalysisY;
            delete [] connectAnalysisTempX;
            delete [] connectAnalysisTempY;
            
            //------Determine number of pixels------
            connectivityNumber = connectivityNumber*-1;
            
            errorNoHold = 91;
            connectedPixels = new int [connectivityNumber+50];
            
            for (int counter1 = 0; counter1 <= connectivityNumber; counter1++) connectedPixels [counter1] = 0;
            
            for (int counterY2 = 0; counterY2 < dimension3; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension3; counterX2++){
                    if (connectivityMapTemp2 [counterY2][counterX2] < -1 && connectivityMapTemp [counterY2][counterX2] != 0){
                        connectedPixels [connectivityMapTemp2 [counterY2][counterX2]*-1]++;
                    }
                }
            }
            
            errorNoHold = 92;
            int **newConnectivityMapTemp = new int *[dimension3+4];
            for (int counter1 = 0; counter1 < dimension3+4; counter1++){
                errorNoHold = 93;
                newConnectivityMapTemp [counter1] = new int [dimension3+4];
            }
            
            for (int counterY = 0; counterY < dimension3+4; counterY++){
                for (int counterX = 0; counterX < dimension3+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
            }
            
            int largestConnect = 0;
            int largestConnectNo = 0;
            
            for (int counter1 = 2; counter1 <= connectivityNumber; counter1++){
                if (connectedPixels [counter1] > largestConnect){
                    largestConnect = connectedPixels [counter1];
                    largestConnectNo = counter1;
                }
            }
            
            for (int counterY2 = 0; counterY2 < dimension3; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension3; counterX2++){
                    if (connectivityMapTemp2 [counterY2][counterX2] == largestConnectNo*-1){
                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                            connectivityMapTemp2 [counterY2-1][counterX2-1] = 0;
                        }
                        if (counterY2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                            connectivityMapTemp2 [counterY2-1][counterX2] = 0;
                        }
                        if (counterY2-1 >= 0 && counterX2+1 < dimension3 && connectivityMapTemp2 [counterY2-1][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                            connectivityMapTemp2 [counterY2-1][counterX2+1] = 0;
                        }
                        if (counterX2+1 < dimension3 && connectivityMapTemp2 [counterY2][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                            connectivityMapTemp2 [counterY2][counterX2+1] = 0;
                        }
                        if (counterY2+1 < dimension3 && counterX2+1 < dimension3 && connectivityMapTemp2 [counterY2+1][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                            connectivityMapTemp2 [counterY2+1][counterX2+1] = 0;
                        }
                        if (counterY2+1 < dimension3 && connectivityMapTemp2 [counterY2+1][counterX2] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                            connectivityMapTemp2 [counterY2+1][counterX2] = 0;
                        }
                        if (counterY2+1 < dimension3 && counterX2-1 >= 0 && connectivityMapTemp2 [counterY2+1][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                            connectivityMapTemp2 [counterY2+1][counterX2-1] = 0;
                        }
                        if (counterX2-1 >= 0 && connectivityMapTemp2 [counterY2][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                            connectivityMapTemp2 [counterY2][counterX2-1] = 0;
                        }
                    }
                }
            }
            
            delete [] connectedPixels;
            
            int xPositionTempStart = 0;
            int yPositionTempStart = 0;
            int lineSize = 0;
            
            for (int counterY2 = 0; counterY2 < dimension3; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension3; counterX2++){
                    if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                        connectivityMapTemp2 [counterY2][counterX2] = 1;
                        
                        xPositionTempStart = counterX2;
                        yPositionTempStart = counterY2;
                        lineSize++;
                    }
                    else connectivityMapTemp2 [counterY2][counterX2] = 0;
                }
            }
            
            for (int counter1 = 0; counter1 < dimension3+4; counter1++) delete [] newConnectivityMapTemp [counter1];
            delete [] newConnectivityMapTemp;
            
            int constructedLineCount = 0;
            
            errorNoHold = 94;
            int *arrayNewLines = new int [lineSize*2+50];
            
            connectivityMapTemp2 [yPositionTempStart][xPositionTempStart] = -1;
            arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart3, constructedLineCount++;
            arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart3, constructedLineCount++;
            
            do{
                
                findFlag = 0;
                terminationFlag = 0;
                
                if (xPositionTempStart+1 < dimension3){
                    if (connectivityMapTemp2 [yPositionTempStart][xPositionTempStart+1] == 1){
                        connectivityMapTemp2 [yPositionTempStart][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart3, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart3, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart+1 < dimension3 && yPositionTempStart+1 < dimension3 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                        connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart3, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart3, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (yPositionTempStart+1 < dimension3 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart] == 1){
                        connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart3, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart3, constructedLineCount++;
                        yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension3 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                        connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart3, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart3, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart][xPositionTempStart-1] == 1){
                        connectivityMapTemp2 [yPositionTempStart][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart3, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart3, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                        connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart3, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart3, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart] == 1){
                        connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart3, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart3, constructedLineCount++;
                        yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart+1 < dimension3 && yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                        connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart3, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart3, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                    }
                }
                
            } while (terminationFlag == 1);
            
            delete [] arrayReferenceLine;
            errorNoHold = 95;
            arrayReferenceLine = new int [constructedLineCount+10];
            
            referenceLineCount = 0;
            
            for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                arrayReferenceLine [referenceLineCount] = arrayNewLines [counter2*2], referenceLineCount++;
                arrayReferenceLine [referenceLineCount] = arrayNewLines [counter2*2+1], referenceLineCount++;
            }
            
            delete [] arrayNewLines;
            delete [] extendConnectList;
            
            for (int counter1 = 0; counter1 < dimension3+1; counter1++){
                delete [] connectivityMapTemp [counter1];
                delete [] connectivityMapTemp2 [counter1];
                delete [] connectivityMapTemp4 [counter1];
            }
            
            delete [] connectivityMapTemp;
            delete [] connectivityMapTemp2;
            delete [] connectivityMapTemp4;
            
            for (int counter2 = 0; counter2 < dimension3+4; counter2++){
                delete [] rangeMatrix [counter2];
            }
            
            delete [] rangeMatrix;
            
            delete [] findConnectNo;
        }
        
        delete [] findReviseConnect;
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++) delete [] connectivityMapTemp3 [counter1];
        delete [] connectivityMapTemp3;
        
        errorNoHold = 0;
        subCompletionFlag2 = 0;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingMerge02 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"Merge-mergeExtendTrackCurrent"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
        
        subCompletionFlag2 = 0;
    }
}

-(int)lineExtendTrackType2:(int)groupNoMerge :(int)processType{
    //=====expandType == 2: Expand Lineage lines, exclude area that overlap with existing area=======
    
    //for (int counterA = 0; counterA < expandLineFluorescentDataCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandLineFluorescentData [counterA*4+counterB];
    //    cout<<" expandLineFluorescentData "<<counterA<<endl;
    //}
    
    int processResults = 0;
    
    try{
        try{
            
            errorNoHold = 0;
            int errorCheckThrow = 0;
            subCompletionFlag2 = 1;
            
            int maxPointDimX = 0;
            int maxPointDimY = 0;
            int minPointDimX = 1000000;
            int minPointDimY = 1000000;
            
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                if (arrayTimeSelected [counter1*10+8] == groupNoMerge){
                    for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                        if (arrayPositionRevise [counter2*7+3] == groupNoMerge){
                            if (maxPointDimX < arrayPositionRevise [counter2*7]) maxPointDimX = arrayPositionRevise [counter2*7];
                            if (minPointDimX > arrayPositionRevise [counter2*7]) minPointDimX = arrayPositionRevise [counter2*7];
                            if (maxPointDimY < arrayPositionRevise [counter2*7+1]) maxPointDimY = arrayPositionRevise [counter2*7+1];
                            if (minPointDimY > arrayPositionRevise [counter2*7+1]) minPointDimY = arrayPositionRevise [counter2*7+1];
                        }
                        else{
                            
                            break;
                        }
                    }
                }
            }
            
            int horizontalLength2 = (maxPointDimX-minPointDimX)/2*2;
            int verticalLength2 = (maxPointDimY-minPointDimY)/2*2;
            int dimension2 = 0;
            int dimension2A = 0;
            int dimension2B = 0;
            
            if (horizontalLength2 >= verticalLength2) dimension2 = horizontalLength2+10;
            if (horizontalLength2 < verticalLength2) dimension2 = verticalLength2+10;
            
            dimension2A = (dimension2/2)*5;
            dimension2B = dimension2A+20;
            
            int horizontalStart2A = minPointDimX-(dimension2A-horizontalLength2)/2;
            int verticalStart2A = minPointDimY-(dimension2A-verticalLength2)/2;
            int horizontalStart2B = minPointDimX-(dimension2B-horizontalLength2)/2;
            int verticalStart2B = minPointDimY-(dimension2B-verticalLength2)/2;
            
            int startY = 0;
            int endY = 0;
            int startX = 0;
            int endX = 0;
            
            //=========B
            errorNoHold = 96;
            int *findReviseConnect = new int [1000];
            for (int counter2 = 0; counter2 < 1000; counter2++) findReviseConnect [counter2] = 0;
            
            errorNoHold = 97;
            int **rangeMatrixA = new int *[dimension2A+4];
            
            for (int counter2 = 0; counter2 < dimension2A+4; counter2++){
                errorNoHold = 98;
                rangeMatrixA [counter2] = new int [dimension2A+4];
            }
            
            errorNoHold = 99;
            int **rangeMatrixB = new int *[dimension2B+4];
            
            for (int counter2 = 0; counter2 < dimension2B+4; counter2++){
                errorNoHold = 100;
                rangeMatrixB [counter2] = new int [dimension2B+4];
            }
            
            errorNoHold = 101;
            int *connectAnalysisXA = new int [dimension2A*4];
            errorNoHold = 102;
            int *connectAnalysisYA = new int [dimension2A*4];
            errorNoHold = 103;
            int *connectAnalysisTempXA = new int [dimension2A*4];
            errorNoHold = 104;
            int *connectAnalysisTempYA = new int [dimension2A*4];
            
            errorNoHold = 105;
            int *connectAnalysisXB = new int [dimension2B*4];
            errorNoHold = 106;
            int *connectAnalysisYB = new int [dimension2B*4];
            errorNoHold = 107;
            int *connectAnalysisTempXB = new int [dimension2B*4];
            errorNoHold = 108;
            int *connectAnalysisTempYB = new int [dimension2B*4];
            
            int freePixelFind = 0;
            int processConnectPosition = 0;
            int processConnectPosition2 = 0;
            int maxConnectRevise = 0;
            int findReviseConnectLimit = 1000;
            int connectivityNumberA = 0;
            int connectivityNumberB = 0;
            int connectAnalysisCount = 0;
            int terminationFlag = 0;
            int connectAnalysisTempCount = 0;
            int xSource = 0;
            int ySource = 0;
            int connectTemp = 0;
            int maxConnect = 0;
            int processConnectNo = 0;
            int findFlag = 0;
            int cutOffFinal = 0;
            
            for (int counter2 = cutStatusFluorescent; counter2 < 240; counter2 = counter2+10){ //====FLU
                for (int counterY = 0; counterY < dimension2A; counterY++){
                    for (int counterX = 0; counterX < dimension2A; counterX++){
                        if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                            if (sourceImage [mapPositionPointer][(counterY+verticalStart2A)*imageDimension+counterX+horizontalStart2A] == 100) rangeMatrixA [counterY][counterX] = 0;
                            else if (sourceImage [mapPositionPointer][(counterY+verticalStart2A)*imageDimension+counterX+horizontalStart2A] < counter2) rangeMatrixA [counterY][counterX] = 0;
                            else rangeMatrixA [counterY][counterX] = -150;
                            
                            if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] != 0 && revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] != groupNoMerge) rangeMatrixA [counterY][counterX] = 0;
                        }
                        else rangeMatrixA [counterY][counterX] = 0;
                    }
                }
                
                for (int counterY = 0; counterY < dimension2B; counterY++){
                    for (int counterX = 0; counterX < dimension2B; counterX++){
                        if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                            if (sourceImage [mapPositionPointer][(counterY+verticalStart2B)*imageDimension+counterX+horizontalStart2B] == 100) rangeMatrixB [counterY][counterX] = 0;
                            else if (sourceImage [mapPositionPointer][(counterY+verticalStart2B)*imageDimension+counterX+horizontalStart2B] < counter2) rangeMatrixB [counterY][counterX] = 0;
                            else rangeMatrixB [counterY][counterX] = -150;
                            
                            if (revisedWorkingMap [counterY+verticalStart2B][counterX+horizontalStart2B] != 0 && revisedWorkingMap [counterY+verticalStart2B][counterX+horizontalStart2B] != groupNoMerge) rangeMatrixB [counterY][counterX] = 0;
                        }
                        else rangeMatrixB [counterY][counterX] = 0;
                    }
                }
                
                //-------MapA--------
                connectivityNumberA = 0;
                
                for (int counterY = 0; counterY < dimension2A; counterY++){
                    for (int counterX = 0; counterX < dimension2A; counterX++){
                        if (rangeMatrixA [counterY][counterX] == -150){
                            connectivityNumberA++;
                            rangeMatrixA [counterY][counterX] = connectivityNumberA;
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixA [counterY-1][counterX-1] == -150){
                                rangeMatrixA [counterY-1][counterX-1] = connectivityNumberA;
                                connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && rangeMatrixA [counterY-1][counterX] == -150){
                                rangeMatrixA [counterY-1][counterX] = connectivityNumberA;
                                connectAnalysisXA [connectAnalysisCount] = counterX, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && counterX+1 < dimension2A && rangeMatrixA [counterY-1][counterX+1] == -150){
                                rangeMatrixA [counterY-1][counterX+1] = connectivityNumberA;
                                connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension2A && rangeMatrixA [counterY][counterX+1] == -150){
                                rangeMatrixA [counterY][counterX+1] = connectivityNumberA;
                                connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension2A && counterX+1 < dimension2A && rangeMatrixA [counterY+1][counterX+1] == -150){
                                rangeMatrixA [counterY+1][counterX+1] = connectivityNumberA;
                                connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension2A && rangeMatrixA [counterY+1][counterX] == -150){
                                rangeMatrixA [counterY+1][counterX] = connectivityNumberA;
                                connectAnalysisXA [connectAnalysisCount] = counterX, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension2A && counterX-1 >= 0 && rangeMatrixA [counterY+1][counterX-1] == -150){
                                rangeMatrixA [counterY+1][counterX-1] = connectivityNumberA;
                                connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && rangeMatrixA [counterY][counterX-1] == -150){
                                rangeMatrixA [counterY][counterX-1] = connectivityNumberA;
                                connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                        xSource = connectAnalysisXA [counter3], ySource = connectAnalysisYA [counter3];
                                        
                                        if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrixA [ySource-1][xSource-1] == -150){
                                            rangeMatrixA [ySource-1][xSource-1] = connectivityNumberA;
                                            connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && rangeMatrixA [ySource-1][xSource] == -150){
                                            rangeMatrixA [ySource-1][xSource] = connectivityNumberA;
                                            connectAnalysisTempXA [connectAnalysisTempCount] = xSource, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && xSource+1 < dimension2A && rangeMatrixA [ySource-1][xSource+1] == -150){
                                            rangeMatrixA [ySource-1][xSource+1] = connectivityNumberA;
                                            connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension2A && rangeMatrixA [ySource][xSource+1] == -150){
                                            rangeMatrixA [ySource][xSource+1] = connectivityNumberA;
                                            connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 > dimension2A && xSource+1 < dimension2A && rangeMatrixA [ySource+1][xSource+1] == -150){
                                            rangeMatrixA [ySource+1][xSource+1] = connectivityNumberA;
                                            connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension2A && rangeMatrixA [ySource+1][xSource] == -150){
                                            rangeMatrixA [ySource+1][xSource] = connectivityNumberA;
                                            connectAnalysisTempXA [connectAnalysisTempCount] = xSource, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension2A && xSource-1 >= 0 && rangeMatrixA [ySource+1][xSource-1] == -150){
                                            rangeMatrixA [ySource+1][xSource-1] = connectivityNumberA;
                                            connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && rangeMatrixA [ySource][xSource-1] == -150){
                                            rangeMatrixA [ySource][xSource-1] = connectivityNumberA;
                                            connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                        connectAnalysisXA [counter3] = connectAnalysisTempXA [counter3], connectAnalysisYA [counter3] = connectAnalysisTempYA [counter3];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //------Determine number of pixels------
                errorNoHold = 109;
                int *connectedPixels = new int [connectivityNumberA+50];
                
                for (int counter3 = 0; counter3 <= connectivityNumberA; counter3++) connectedPixels [counter3] = 0;
                
                for (int counterY = 0; counterY < dimension2A; counterY++){
                    for (int counterX = 0; counterX < dimension2A; counterX++){
                        if (rangeMatrixA [counterY][counterX] != 0) connectedPixels [rangeMatrixA [counterY][counterX]]++;
                    }
                }
                
                //------Map up-date------
                connectTemp = 1;
                
                for (int counter3 = 1; counter3 <= connectivityNumberA; counter3++){
                    if (connectedPixels [counter3] < 10) connectedPixels [counter3] = 0;
                    else{
                        
                        connectedPixels [counter3] = connectTemp;
                        connectTemp++;
                    }
                }
                
                maxConnect = 0;
                maxConnectRevise = 0;
                
                for (int counterY = 0; counterY < dimension2A; counterY++){
                    for (int counterX = 0; counterX < dimension2A; counterX++){
                        if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                            if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A];
                            
                            if ((connectTemp = rangeMatrixA [counterY][counterX]) != 0) rangeMatrixA [counterY][counterX] = connectedPixels [connectTemp];
                            else rangeMatrixA [counterY][counterX] = 0;
                            
                            if (rangeMatrixA [counterY][counterX] > maxConnect) maxConnect = rangeMatrixA [counterY][counterX];
                        }
                    }
                }
                
                delete [] connectedPixels;
                
                errorNoHold = 110;
                int *findConnectNo = new int [maxConnect+5];
                for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo [counter3] = 0;
                
                if (maxConnectRevise+10 > findReviseConnectLimit){
                    delete [] findReviseConnect;
                    errorNoHold = 111;
                    findReviseConnect = new int [maxConnectRevise+50];
                    findReviseConnectLimit = maxConnectRevise+50;
                }
                
                for (int counter3 = 0; counter3 < maxConnectRevise+5; counter3++) findReviseConnect [counter3] = 0;
                
                for (int counterY = 0; counterY < dimension2A; counterY++){
                    for (int counterX = 0; counterX < dimension2A; counterX++){
                        if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                            if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] == groupNoMerge){
                                if (rangeMatrixA [counterY][counterX] != 0) findConnectNo [rangeMatrixA [counterY][counterX]]++;
                            }
                        }
                    }
                }
                
                processConnectNo = 0;
                processConnectPosition = 0;
                
                for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
                    if (findConnectNo [counter3] > processConnectNo){
                        processConnectNo = findConnectNo [counter3];
                        processConnectPosition = counter3;
                    }
                }
                
                if (processConnectPosition != 0){
                    freePixelFind = 0;
                    
                    for (int counterY = 0; counterY < dimension2A; counterY++){
                        for (int counterX = 0; counterX < dimension2A; counterX++){
                            if (rangeMatrixA [counterY][counterX] == processConnectPosition){
                                if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                                    if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] != 0){
                                        findReviseConnect [revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A]]++;
                                    }
                                    
                                    if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] == 0) freePixelFind = 1;
                                }
                            }
                        }
                    }
                    
                    //--------MapB---------
                    connectivityNumberB = 0;
                    
                    for (int counterY = 0; counterY < dimension2B; counterY++){
                        for (int counterX = 0; counterX < dimension2B; counterX++){
                            if (rangeMatrixB [counterY][counterX] == -150){
                                connectivityNumberB++;
                                rangeMatrixB [counterY][counterX] = connectivityNumberB;
                                connectAnalysisCount = 0;
                                
                                if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixB [counterY-1][counterX-1] == -150){
                                    rangeMatrixB [counterY-1][counterX-1] = connectivityNumberB;
                                    connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterY-1 >= 0 && rangeMatrixB [counterY-1][counterX] == -150){
                                    rangeMatrixB [counterY-1][counterX] = connectivityNumberB;
                                    connectAnalysisXB [connectAnalysisCount] = counterX, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterY-1 >= 0 && counterX+1 < dimension2B && rangeMatrixB [counterY-1][counterX+1] == -150){
                                    rangeMatrixB [counterY-1][counterX+1] = connectivityNumberB;
                                    connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterX+1 < dimension2B && rangeMatrixB [counterY][counterX+1] == -150){
                                    rangeMatrixB [counterY][counterX+1] = connectivityNumberB;
                                    connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimension2B && counterX+1 < dimension2B && rangeMatrixB [counterY+1][counterX+1] == -150){
                                    rangeMatrixB [counterY+1][counterX+1] = connectivityNumberB;
                                    connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimension2B && rangeMatrixB [counterY+1][counterX] == -150){
                                    rangeMatrixB [counterY+1][counterX] = connectivityNumberB;
                                    connectAnalysisXB [connectAnalysisCount] = counterX, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimension2B && counterX-1 >= 0 && rangeMatrixB [counterY+1][counterX-1] == -150){
                                    rangeMatrixB [counterY+1][counterX-1] = connectivityNumberB;
                                    connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterX-1 >= 0 && rangeMatrixB [counterY][counterX-1] == -150){
                                    rangeMatrixB [counterY][counterX-1] = connectivityNumberB;
                                    connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                            xSource = connectAnalysisXB [counter3], ySource = connectAnalysisYB [counter3];
                                            
                                            if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrixB [ySource-1][xSource-1] == -150){
                                                rangeMatrixB [ySource-1][xSource-1] = connectivityNumberB;
                                                connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (ySource-1 >= 0 && rangeMatrixB [ySource-1][xSource] == -150){
                                                rangeMatrixB [ySource-1][xSource] = connectivityNumberB;
                                                connectAnalysisTempXB [connectAnalysisTempCount] = xSource, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (ySource-1 >= 0 && xSource+1 < dimension2B && rangeMatrixB [ySource-1][xSource+1] == -150){
                                                rangeMatrixB [ySource-1][xSource+1] = connectivityNumberB;
                                                connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension2B && rangeMatrixB [ySource][xSource+1] == -150){
                                                rangeMatrixB [ySource][xSource+1] = connectivityNumberB;
                                                connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 > dimension2B && xSource+1 < dimension2B && rangeMatrixB [ySource+1][xSource+1] == -150){
                                                rangeMatrixB [ySource+1][xSource+1] = connectivityNumberB;
                                                connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension2B && rangeMatrixB [ySource+1][xSource] == -150){
                                                rangeMatrixB [ySource+1][xSource] = connectivityNumberB;
                                                connectAnalysisTempXB [connectAnalysisTempCount] = xSource, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension2B && xSource-1 >= 0 && rangeMatrixB [ySource+1][xSource-1] == -150){
                                                rangeMatrixB [ySource+1][xSource-1] = connectivityNumberB;
                                                connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && rangeMatrixB [ySource][xSource-1] == -150){
                                                rangeMatrixB [ySource][xSource-1] = connectivityNumberB;
                                                connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                            connectAnalysisXB [counter3] = connectAnalysisTempXB [counter3], connectAnalysisYB [counter3] = connectAnalysisTempYB [counter3];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    //------Determine number of pixels------
                    errorNoHold = 112;
                    connectedPixels = new int [connectivityNumberB+50];
                    
                    for (int counter3 = 0; counter3 <= connectivityNumberB; counter3++) connectedPixels [counter3] = 0;
                    
                    for (int counterY = 0; counterY < dimension2B; counterY++){
                        for (int counterX = 0; counterX < dimension2B; counterX++){
                            if (rangeMatrixB [counterY][counterX] != 0) connectedPixels [rangeMatrixB [counterY][counterX]]++;
                        }
                    }
                    
                    //------Map up-date------
                    connectTemp = 1;
                    
                    for (int counter3 = 1; counter3 <= connectivityNumberB; counter3++){
                        if (connectedPixels [counter3] < 10) connectedPixels [counter3] = 0;
                        else{
                            
                            connectedPixels [counter3] = connectTemp;
                            connectTemp++;
                        }
                    }
                    
                    maxConnect = 0;
                    
                    for (int counterY = 0; counterY < dimension2B; counterY++){
                        for (int counterX = 0; counterX < dimension2B; counterX++){
                            if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                                if ((connectTemp = rangeMatrixB [counterY][counterX]) != 0) rangeMatrixB [counterY][counterX] = connectedPixels [connectTemp];
                                else rangeMatrixB [counterY][counterX] = 0;
                                
                                if (rangeMatrixB [counterY][counterX] > maxConnect) maxConnect = rangeMatrixB [counterY][counterX];
                            }
                        }
                    }
                    
                    delete [] connectedPixels;
                    
                    errorNoHold = 113;
                    int *findConnectNo2 = new int [maxConnect+5];
                    for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo2 [counter3] = 0;
                    
                    for (int counterY = 0; counterY < dimension2B; counterY++){
                        for (int counterX = 0; counterX < dimension2B; counterX++){
                            if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                                if (revisedWorkingMap [counterY+verticalStart2B][counterX+horizontalStart2B] == groupNoMerge){
                                    if (rangeMatrixB [counterY][counterX] != 0) findConnectNo2 [rangeMatrixB [counterY][counterX]]++;
                                }
                            }
                        }
                    }
                    
                    processConnectNo = 0;
                    processConnectPosition2 = 0;
                    
                    for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
                        if (findConnectNo2 [counter3] > processConnectNo){
                            processConnectNo = findConnectNo2 [counter3];
                            processConnectPosition2 = counter3;
                        }
                    }
                    
                    if (processConnectPosition2 != 0){
                        for (int counterY = 0; counterY < dimension2A; counterY++){
                            for (int counterX = 0; counterX < dimension2A; counterX++){
                                if ((counterY+verticalStart2A)-verticalStart2B >= 0 && (counterY+verticalStart2A)-verticalStart2B < +dimension2B && (counterX+horizontalStart2A)-horizontalStart2B >= 0 && (counterX+horizontalStart2A)-horizontalStart2B < dimension2B){
                                    rangeMatrixB [(counterY+verticalStart2A)-verticalStart2B][(counterX+horizontalStart2A)-horizontalStart2B] = 0;
                                }
                            }
                        }
                        
                        findFlag = 0;
                        
                        for (int counterY = 0; counterY < dimension2B; counterY++){
                            for (int counterX = 0; counterX < dimension2B; counterX++){
                                if (rangeMatrixB [counterY][counterX] == processConnectPosition2){
                                    findFlag = 1;
                                    break;
                                }
                            }
                        }
                        
                        if (findFlag == 0){
                            cutOffFinal = counter2;
                            
                            delete [] findConnectNo2;
                            delete [] findConnectNo;
                            break;
                        }
                    }
                    else{
                        
                        if (counter2 != 20) cutOffFinal = counter2-10;
                        else cutOffFinal = 0;
                        
                        delete [] findConnectNo2;
                        delete [] findConnectNo;
                        break;
                    }
                    
                    delete [] findConnectNo2;
                }
                else{
                    
                    if (counter2 != 20) cutOffFinal = counter2-10;
                    else cutOffFinal = 0;
                    
                    delete [] findConnectNo;
                    break;
                }
                
                delete [] findConnectNo;
            }
            
            delete [] connectAnalysisXA;
            delete [] connectAnalysisYA;
            delete [] connectAnalysisTempXA;
            delete [] connectAnalysisTempYA;
            
            delete [] connectAnalysisXB;
            delete [] connectAnalysisYB;
            delete [] connectAnalysisTempXB;
            delete [] connectAnalysisTempYB;
            
            for (int counter2 = 0; counter2 < dimension2A+4; counter2++){
                delete [] rangeMatrixA [counter2];
            }
            
            delete [] rangeMatrixA;
            
            for (int counter2 = 0; counter2 < dimension2B+4; counter2++){
                delete [] rangeMatrixB [counter2];
            }
            
            delete [] rangeMatrixB;
            
            if (cutOffFinal != 0 && freePixelFind == 1){
                int extendConnectCount = 0;
                
                for (int counter1 = 1; counter1 < maxConnectRevise+1; counter1++){
                    if (findReviseConnect [counter1] != 0) extendConnectCount++;
                }
                
                errorNoHold = 114;
                int *extendConnectList = new int [extendConnectCount*2+1];
                extendConnectCount = 0;
                
                for (int counter1 = 1; counter1 < maxConnectRevise+1; counter1++){
                    if (findReviseConnect [counter1] != 0){
                        extendConnectList [extendConnectCount] = counter1, extendConnectCount++;
                        extendConnectList [extendConnectCount] = 0, extendConnectCount++;
                    }
                }
                
                int connectFind = 0;
                
                for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                    connectFind = 0;
                    
                    for (int counter2 = 0; counter2 < extendConnectCount/2; counter2++){
                        if (extendConnectList [counter2*2] == arrayTimeSelected [counter1*10+8]) connectFind = 1;
                    }
                    
                    if (connectFind == 1){
                        for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                            if (arrayPositionRevise [counter2*7+3] == arrayTimeSelected [counter1*10+8]){
                                if (maxPointDimX < arrayPositionRevise [counter2*7]) maxPointDimX = arrayPositionRevise [counter2*7];
                                if (minPointDimX > arrayPositionRevise [counter2*7]) minPointDimX = arrayPositionRevise [counter2*7];
                                if (maxPointDimY < arrayPositionRevise [counter2*7+1]) maxPointDimY = arrayPositionRevise [counter2*7+1];
                                if (minPointDimY > arrayPositionRevise [counter2*7+1]) minPointDimY = arrayPositionRevise [counter2*7+1];
                            }
                            else{
                                
                                break;
                            }
                        }
                    }
                }
                
                for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                    for (int counter2 = 0; counter2 < expandLineFluorescentCount/4; counter2++){
                        if (expandLineFluorescent [counter2*4+2] == extendConnectList [counter1*2]){
                            if (maxPointDimX < expandLineFluorescent [counter2*4]) maxPointDimX = expandLineFluorescent [counter2*4];
                            if (minPointDimX > expandLineFluorescent [counter2*4]) minPointDimX = expandLineFluorescent [counter2*4];
                            if (maxPointDimY < expandLineFluorescent [counter2*4+1]) maxPointDimY = expandLineFluorescent [counter2*4+1];
                            if (minPointDimY > expandLineFluorescent [counter2*4+1]) minPointDimY = expandLineFluorescent [counter2*4+1];
                        }
                    }
                }
                
                int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                int verticalLength = (maxPointDimY-minPointDimY)/2*2;
                int dimension = 0;
                
                if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
                if (horizontalLength < verticalLength) dimension = verticalLength+30;
                
                dimension = (dimension/2)*5;
                
                int horizontalStart2 = minPointDimX-(dimension-horizontalLength)/2;
                int verticalStart2 = minPointDimY-(dimension-verticalLength)/2;
                
                //=======CC
                errorNoHold = 115;
                int **rangeMatrix = new int *[dimension+4];
                
                for (int counter2 = 0; counter2 < dimension+4; counter2++){
                    errorNoHold = 116;
                    rangeMatrix [counter2] = new int [dimension+4];
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                            if (sourceImage [mapPositionPointer][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] == 100) rangeMatrix [counterY][counterX] = 0;
                            else if (sourceImage [mapPositionPointer][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] < cutOffFinal) rangeMatrix [counterY][counterX] = 0;
                            else rangeMatrix [counterY][counterX] = -150;
                            
                            if (revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2] != 0 && revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2] != groupNoMerge) rangeMatrix [counterY][counterX] = 0;
                        }
                        else rangeMatrix [counterY][counterX] = 0;
                    }
                }
                
                errorNoHold = 117;
                int *connectAnalysisX = new int [dimension*4];
                errorNoHold = 118;
                int *connectAnalysisY = new int [dimension*4];
                errorNoHold = 119;
                int *connectAnalysisTempX = new int [dimension*4];
                errorNoHold = 120;
                int *connectAnalysisTempY = new int [dimension*4];
                
                int connectivityNumber = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (rangeMatrix [counterY][counterX] == -150){
                            connectivityNumber++;
                            rangeMatrix [counterY][counterX] = connectivityNumber;
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrix [counterY-1][counterX-1] == -150){
                                rangeMatrix [counterY-1][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && rangeMatrix [counterY-1][counterX] == -150){
                                rangeMatrix [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && counterX+1 < dimension && rangeMatrix [counterY-1][counterX+1] == -150){
                                rangeMatrix [counterY-1][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension && rangeMatrix [counterY][counterX+1] == -150){
                                rangeMatrix [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && counterX+1 < dimension && rangeMatrix [counterY+1][counterX+1] == -150){
                                rangeMatrix [counterY+1][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && rangeMatrix [counterY+1][counterX] == -150){
                                rangeMatrix [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && counterX-1 >= 0 && rangeMatrix [counterY+1][counterX-1] == -150){
                                rangeMatrix [counterY+1][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && rangeMatrix [counterY][counterX-1] == -150){
                                rangeMatrix [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                        xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                        
                                        if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrix [ySource-1][xSource-1] == -150){
                                            rangeMatrix [ySource-1][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && rangeMatrix [ySource-1][xSource] == -150){
                                            rangeMatrix [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && xSource+1 < dimension && rangeMatrix [ySource-1][xSource+1] == -150){
                                            rangeMatrix [ySource-1][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension && rangeMatrix [ySource][xSource+1] == -150){
                                            rangeMatrix [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 > dimension && xSource+1 < dimension && rangeMatrix [ySource+1][xSource+1] == -150){
                                            rangeMatrix [ySource+1][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && rangeMatrix [ySource+1][xSource] == -150){
                                            rangeMatrix [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && xSource-1 >= 0 && rangeMatrix [ySource+1][xSource-1] == -150){
                                            rangeMatrix [ySource+1][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && rangeMatrix [ySource][xSource-1] == -150){
                                            rangeMatrix [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                        connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //------Determine number of pixels------
                errorNoHold = 121;
                int *connectedPixels = new int [connectivityNumber+50];
                
                for (int counter3 = 0; counter3 <= connectivityNumber; counter3++) connectedPixels [counter3] = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (rangeMatrix [counterY][counterX] != 0) connectedPixels [rangeMatrix [counterY][counterX]]++;
                    }
                }
                
                //------Map up-date------
                connectTemp = 1;
                
                for (int counter3 = 1; counter3 <= connectivityNumber; counter3++){
                    if (connectedPixels [counter3] < 10) connectedPixels [counter3] = 0;
                    else{
                        
                        connectedPixels [counter3] = connectTemp;
                        connectTemp++;
                    }
                }
                
                maxConnect = 0;
                maxConnectRevise = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                            if (revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2];
                            
                            if ((connectTemp = rangeMatrix [counterY][counterX]) != 0) rangeMatrix [counterY][counterX] = connectedPixels [connectTemp];
                            else rangeMatrix [counterY][counterX] = 0;
                            
                            if (rangeMatrix [counterY][counterX] > maxConnect) maxConnect = rangeMatrix [counterY][counterX];
                        }
                    }
                }
                
                delete [] connectedPixels;
                
                errorNoHold = 122;
                int *findConnectNo = new int [maxConnect+5];
                for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo [counter3] = 0;
                
                if (maxConnectRevise+10 > findReviseConnectLimit){
                    delete [] findReviseConnect;
                    errorNoHold = 123;
                    findReviseConnect = new int [maxConnectRevise+50];
                }
                
                for (int counter3 = 0; counter3 < maxConnectRevise+5; counter3++) findReviseConnect [counter3] = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                            if (revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2] == groupNoMerge){
                                if (rangeMatrix [counterY][counterX] != 0) findConnectNo [rangeMatrix [counterY][counterX]]++;
                            }
                        }
                    }
                }
                
                processConnectNo = 0;
                processConnectPosition = 0;
                
                for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
                    if (findConnectNo [counter3] > processConnectNo){
                        processConnectNo = findConnectNo [counter3];
                        processConnectPosition = counter3;
                    }
                }
                //========CC
                
                errorNoHold = 124;
                int **connectivityMapTemp = new int *[dimension+1];
                errorNoHold = 125;
                int **connectivityMapTemp2 = new int *[dimension+1];
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    errorNoHold = 126;
                    connectivityMapTemp [counter1] = new int [dimension+1];
                    errorNoHold = 127;
                    connectivityMapTemp2 [counter1] = new int [dimension+1];
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = 0;
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (rangeMatrix [counterY][counterX] == processConnectPosition) connectivityMapTemp [counterY][counterX] = -1;
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                // 	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
                //	cout<<" connectivityMapTemp "<<counterA<<endl;
                //}
                
                if (minPointDimY-30 >= 0) startY = minPointDimY-30;
                else startY = 0;
                
                if (maxPointDimY+30 < imageDimension) endY = maxPointDimY+31;
                else endY = imageDimension;
                
                if (minPointDimX-30 >= 0) startX = minPointDimX-30;
                else startX = 0;
                
                if (maxPointDimX+30 < imageDimension) endX = maxPointDimX+31;
                else endX = imageDimension;
                
                for (int counterY = startY; counterY < endY; counterY++){
                    for (int counterX = startX; counterX < endX; counterX++){
                        connectFind = 0;
                        
                        for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                            if (extendConnectList [counter1*2] == revisedWorkingMap [counterY][counterX]) connectFind = 1;
                        }
                        
                        if (connectFind == 1){
                            if (counterY-verticalStart2 > 0 && counterX-horizontalStart2 > 0) connectivityMapTemp [counterY-verticalStart2][counterX-horizontalStart2] = revisedWorkingMap [counterY][counterX];
                        }
                    }
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp2 [counterY][counterX] = connectivityMapTemp [counterY][counterX];
                }
                
                terminationFlag = 0;
                int startOrder = 0;
                int findFreePoint = 0;
                int connectNo = 0;
                int remainingCheck = 0;
                
                do{
                    
                    for (int counter1 = startOrder; counter1 < extendConnectCount/2; counter1++){
                        connectNo = extendConnectList [counter1*2];
                        
                        if (extendConnectList [counter1*2+1] == 0){
                            findFreePoint = 0;
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (connectivityMapTemp [counterY][counterX] == connectNo){
                                        if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] == -1){
                                            connectivityMapTemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == -1){
                                            connectivityMapTemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMapTemp [counterY-1][counterX+1] == -1){
                                            connectivityMapTemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == -1){
                                            connectivityMapTemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterY+1 < dimension && counterX+1 < dimension && connectivityMapTemp [counterY+1][counterX+1] == -1){
                                            connectivityMapTemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == -1){
                                            connectivityMapTemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] == -1){
                                            connectivityMapTemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == -1){
                                            connectivityMapTemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                        }
                                    }
                                }
                            }
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                            }
                            
                            if (findFreePoint == 0) extendConnectList [counter1*2+1] = 1;
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < startOrder; counter1++){
                        connectNo = extendConnectList [counter1*2];
                        
                        if (extendConnectList [counter1*2+1] == 0){
                            findFreePoint = 0;
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (connectivityMapTemp [counterY][counterX] == connectNo){
                                        if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] == -1){
                                            connectivityMapTemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == -1){
                                            connectivityMapTemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMapTemp [counterY-1][counterX+1] == -1){
                                            connectivityMapTemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == -1){
                                            connectivityMapTemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterY+1 < dimension && counterX+1 < dimension && connectivityMapTemp [counterY+1][counterX+1] == -1){
                                            connectivityMapTemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == -1){
                                            connectivityMapTemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] == -1){
                                            connectivityMapTemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == -1){
                                            connectivityMapTemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                        }
                                    }
                                }
                            }
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                            }
                            
                            if (findFreePoint == 0) extendConnectList [counter1*2+1] = 1;
                        }
                    }
                    
                    remainingCheck = 0;
                    
                    for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                        if (extendConnectList [counter1*2+1] == 0) remainingCheck = 1;
                    }
                    
                    if (remainingCheck == 0) terminationFlag = 1;
                    
                    startOrder++;
                    
                    if (startOrder == extendConnectCount/2) startOrder = 0;
                    
                } while (terminationFlag == 0);
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
                //    cout<<" connectivityMapTemp "<<counterA<<endl;
                //}
                
                errorNoHold = 128;
                int **connectivityMapHold = new int *[dimension+1];
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    errorNoHold = 129;
                    connectivityMapHold [counter1] = new int [dimension+1];
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapTemp [counterY][counterX] == groupNoMerge) connectivityMapTemp2 [counterY][counterX] = 1;
                        else connectivityMapTemp2 [counterY][counterX] = 0;
                        
                        connectivityMapHold [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                    }
                }
                
                //-------Zero Fill-------
                errorNoHold = 130;
                int **connectivityUpdate5 = new int *[dimension+4];
                
                for (int counter1 = 0; counter1 < dimension+4; counter1++){
                    errorNoHold = 131;
                    connectivityUpdate5 [counter1] = new int [dimension+4];
                }
                
                for (int counterX = 0; counterX < dimension+4; counterX++){
                    for (int counterY = 0; counterY < dimension+4; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = connectivityMapTemp2 [counterY][counterX];
                }
                
                connectivityNumber = 0;
                
                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                        if (connectivityUpdate5 [counterY2][counterX2] == 0){
                            connectivityNumber--;
                            connectAnalysisCount = 0;
                            
                            connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                            
                            if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                                connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                            }
                            if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                            }
                            if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                            }
                            if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                        xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                        
                                        if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                            connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                            connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                            connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                            connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                        connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < dimension+2; counterA++){
                //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                //	cout<<" connectivityUpdate5 "<<counterA<<endl;
                //}
                
                int connectTemp2 = 0;
                
                if (connectivityNumber < -1){
                    errorNoHold = 132;
                    int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                    
                    for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                            connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                            
                            if (connectTemp2 < -1){
                                connectTemp2 = connectTemp2*-1;
                                
                                if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                            }
                        }
                    }
                    
                    int zeroFillFlag = 0;
                    
                    for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                        if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
                    }
                    
                    //for (int counter3 = 1; counter3 <= connectivityNumber*-1; counter3++){
                    //    cout<<counter3<<" "<<connectCheckArray [counter3*2]<<" "<<connectCheckArray [counter3*2+1]<<" connectCheckArray"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < dimension+2; counterA++){
                    //    for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                    //    cout<<" connectivityUpdate5 "<<counterA<<endl;
                    //}
                    
                    if (zeroFillFlag == 1){
                        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                                
                                if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                            }
                        }
                        
                        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                if (connectivityUpdate5 [counterY2][counterX2] > 0){
                                    connectivityMapTemp2 [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                                    connectivityMapHold [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                                }
                            }
                        }
                    }
                    
                    delete [] connectCheckArray;
                }
                
                for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] connectivityUpdate5 [counter1];
                
                delete [] connectivityUpdate5;
                //---------
                
                //for (int counterA = 0; counterA < expandLineFluorescentCount/4; counterA++){
                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandLineFluorescent [counterA*4+counterB];
                //    cout<<" expandLineFluorescent "<<counterA<<endl;
                //}
                
                int connectExtend = 0;
                int connectivityNumber2 = 0;
                int largestConnect = 0;
                int largestConnectNo = 0;
                int xPositionTempStart = 0;
                int yPositionTempStart = 0;
                int lineSize = 0;
                int constructedLineCount = 0;
                int expandLineFluorescentTempCount = 0;
                int pixelValueTemp = 0;
                int pixelAreaTemp = 0;
                int expandDataTempCount2 = 0;
                double averageArea = 0;
                
                for (int counter1 = 1; counter1 <= fluorescentEntryCount; counter1++){
                    errorNoHold = 133;
                    int **connectivityMapTemp4 = new int *[dimension+1];
                    for (int counter2 = 0; counter2 < dimension+1; counter2++){
                        errorNoHold = 134;
                        connectivityMapTemp4 [counter2] = new int [dimension+1];
                    }
                    
                    if (counter1 > 1){
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp2 [counterY][counterX] = connectivityMapHold [counterY][counterX];
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < extendConnectCount/2; counter2++){
                        if (extendConnectList [counter2*2] != groupNoMerge){
                            connectExtend = extendConnectList [counter2*2];
                            findFlag = 0;
                            
                            for (int counter3 = 0; counter3 < expandLineFluorescentCount/4; counter3++){
                                if (expandLineFluorescent [counter3*4+2] == connectExtend && expandLineFluorescent [counter3*4+3] == counter1){
                                    findFlag = 1;
                                    break;
                                }
                            }
                            
                            if (findFlag == 1){
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp4 [counterY][counterX] = 0;
                                }
                                
                                for (int counter3 = 0; counter3 < expandLineFluorescentCount/4; counter3++){
                                    if (expandLineFluorescent [counter3*4+2] == connectExtend && expandLineFluorescent [counter3*4+3] == counter1){
                                        if (expandLineFluorescent [counter3*4+1]-verticalStart2 > 0 && expandLineFluorescent [counter3*4]-horizontalStart2 > 0) connectivityMapTemp4 [expandLineFluorescent [counter3*4+1]-verticalStart2][expandLineFluorescent [counter3*4]-horizontalStart2] = 1;
                                    }
                                }
                                
                                connectivityNumber2 = -3;
                                
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++){
                                        if (connectivityMapTemp4 [counterY][counterX] == 0){
                                            connectivityNumber2 = connectivityNumber2+2;
                                            connectivityMapTemp4 [counterY][counterX] = connectivityNumber2;
                                            
                                            connectAnalysisCount = 0;
                                            
                                            if (counterY-1 >= 0 && connectivityMapTemp4 [counterY-1][counterX] == 0){
                                                connectivityMapTemp4 [counterY-1][counterX] = connectivityNumber2;
                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                            }
                                            if (counterX+1 < dimension && connectivityMapTemp4 [counterY][counterX+1] == 0){
                                                connectivityMapTemp4 [counterY][counterX+1] = connectivityNumber2;
                                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                            }
                                            if (counterY+1 < dimension && connectivityMapTemp4 [counterY+1][counterX] == 0){
                                                connectivityMapTemp4 [counterY+1][counterX] = connectivityNumber2;
                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                            }
                                            if (counterX-1 >= 0 && connectivityMapTemp4 [counterY][counterX-1] == 0){
                                                connectivityMapTemp4 [counterY][counterX-1] = connectivityNumber2;
                                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                            }
                                            
                                            if (connectAnalysisCount != 0){
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    connectAnalysisTempCount = 0;
                                                    
                                                    for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                        xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                        
                                                        if (ySource-1 >= 0 && connectivityMapTemp4 [ySource-1][xSource] == 0){
                                                            connectivityMapTemp4 [ySource-1][xSource] = connectivityNumber2;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource+1 < dimension && connectivityMapTemp4 [ySource][xSource+1] == 0){
                                                            connectivityMapTemp4 [ySource][xSource+1] = connectivityNumber2;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                        if (ySource+1 < dimension && connectivityMapTemp4 [ySource+1][xSource] == 0){
                                                            connectivityMapTemp4 [ySource+1][xSource] = connectivityNumber2;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource-1 >= 0 && connectivityMapTemp4 [ySource][xSource-1] == 0){
                                                            connectivityMapTemp4 [ySource][xSource-1] = connectivityNumber2;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                    }
                                                    
                                                    for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                        connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                    }
                                                    
                                                    connectAnalysisCount = connectAnalysisTempCount;
                                                    
                                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                                    
                                                } while (terminationFlag == 1);
                                            }
                                        }
                                    }
                                }
                                
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++){
                                        if (connectivityMapTemp4 [counterY][counterX] > 0 && connectivityMapTemp2 [counterY][counterX] == 1) connectivityMapTemp2 [counterY][counterX] = 0;
                                    }
                                }
                            }
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < dimension+1; counter2++) delete [] connectivityMapTemp4 [counter2];
                    delete [] connectivityMapTemp4;
                    
                    //------Connectivity analysis, For Zero------
                    connectivityNumber = -3;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp2 [counterY][counterX] == 0){
                                connectivityNumber = connectivityNumber+2;
                                connectivityMapTemp2 [counterY][counterX] = connectivityNumber;
                                
                                connectAnalysisCount = 0;
                                
                                if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0){
                                    connectivityMapTemp2 [counterY-1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0){
                                    connectivityMapTemp2 [counterY][counterX+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0){
                                    connectivityMapTemp2 [counterY+1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0){
                                    connectivityMapTemp2 [counterY][counterX-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                            xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                            
                                            if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                                connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                                connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                                connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                                connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                            connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    //------Remove connectivity groups, which attach edge, extract inner part of Linked Line------
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp2 [counterY][counterX] == -1) connectivityMapTemp2 [counterY][counterX] = 0;
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp2 [counterY][counterX] != 0){
                                if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                                else if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                                else if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                                else if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp2 [counterY][counterX] > 0) connectivityMapTemp2 [counterY][counterX] = 0;
                            if (connectivityMapTemp2 [counterY][counterX] < 0) connectivityMapTemp2 [counterY][counterX] = 1;
                        }
                    }
                    
                    connectivityNumber = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (connectivityMapTemp2 [counterY2][counterX2] == 0){
                                connectivityNumber--;
                                connectAnalysisCount = 0;
                                
                                connectivityMapTemp2 [counterY2][counterX2] = connectivityNumber;
                                
                                if (counterY2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2] == 0){
                                    connectivityMapTemp2 [counterY2-1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                }
                                if (counterX2+1 < dimension && connectivityMapTemp2 [counterY2][counterX2+1] == 0){
                                    connectivityMapTemp2 [counterY2][counterX2+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                if (counterY2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2] == 0){
                                    connectivityMapTemp2 [counterY2+1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                }
                                if (counterX2-1 >= 0 && connectivityMapTemp2 [counterY2][counterX2-1] == 0){
                                    connectivityMapTemp2 [counterY2][counterX2-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                            xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                            
                                            if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                                connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                                connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                                connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                                connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                            connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    //------Determine number of pixels------
                    connectivityNumber = connectivityNumber*-1;
                    
                    errorNoHold = 135;
                    connectedPixels = new int [connectivityNumber+50];
                    
                    for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPixels [counter2] = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (connectivityMapTemp2 [counterY2][counterX2] < -1) connectedPixels [connectivityMapTemp2 [counterY2][counterX2]*-1]++;
                        }
                    }
                    
                    errorNoHold = 136;
                    int **newConnectivityMapTemp = new int *[dimension+4];
                    for (int counter2 = 0; counter2 < dimension+4; counter2++){
                        errorNoHold = 137;
                        newConnectivityMapTemp [counter2] = new int [dimension+4];
                    }
                    
                    for (int counterY = 0; counterY < dimension+4; counterY++){
                        for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
                    }
                    
                    largestConnect = 0;
                    largestConnectNo = 0;
                    
                    for (int counter2 = 2; counter2 <= connectivityNumber; counter2++){
                        if (connectedPixels [counter2] > largestConnect){
                            largestConnect = connectedPixels [counter2];
                            largestConnectNo = counter2;
                        }
                    }
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (connectivityMapTemp2 [counterY2][counterX2] == largestConnectNo*-1){
                                if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2-1] == 1){
                                    newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                                    connectivityMapTemp2 [counterY2-1][counterX2-1] = 0;
                                }
                                if (counterY2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2] == 1){
                                    newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                                    connectivityMapTemp2 [counterY2-1][counterX2] = 0;
                                }
                                if (counterY2-1 >= 0 && counterX2+1 < dimension && connectivityMapTemp2 [counterY2-1][counterX2+1] == 1){
                                    newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                                    connectivityMapTemp2 [counterY2-1][counterX2+1] = 0;
                                }
                                if (counterX2+1 < dimension && connectivityMapTemp2 [counterY2][counterX2+1] == 1){
                                    newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                                    connectivityMapTemp2 [counterY2][counterX2+1] = 0;
                                }
                                if (counterY2+1 < dimension && counterX2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2+1] == 1){
                                    newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                                    connectivityMapTemp2 [counterY2+1][counterX2+1] = 0;
                                }
                                if (counterY2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2] == 1){
                                    newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                                    connectivityMapTemp2 [counterY2+1][counterX2] = 0;
                                }
                                if (counterY2+1 < dimension && counterX2-1 >= 0 && connectivityMapTemp2 [counterY2+1][counterX2-1] == 1){
                                    newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                                    connectivityMapTemp2 [counterY2+1][counterX2-1] = 0;
                                }
                                if (counterX2-1 >= 0 && connectivityMapTemp2 [counterY2][counterX2-1] == 1){
                                    newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                                    connectivityMapTemp2 [counterY2][counterX2-1] = 0;
                                }
                            }
                        }
                    }
                    
                    delete [] connectedPixels;
                    
                    xPositionTempStart = 0;
                    yPositionTempStart = 0;
                    lineSize = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                                connectivityMapTemp2 [counterY2][counterX2] = 1;
                                
                                xPositionTempStart = counterX2;
                                yPositionTempStart = counterY2;
                                lineSize++;
                            }
                            else connectivityMapTemp2 [counterY2][counterX2] = 0;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < dimension+4; counter2++) delete [] newConnectivityMapTemp [counter2];
                    delete [] newConnectivityMapTemp;
                    
                    constructedLineCount = 0;
                    
                    errorNoHold = 138;
                    int *arrayNewLines = new int [lineSize*2+50];
                    
                    connectivityMapTemp2 [yPositionTempStart][xPositionTempStart] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart2, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart2, constructedLineCount++;
                    
                    do{
                        
                        findFlag = 0;
                        terminationFlag = 0;
                        
                        if (xPositionTempStart+1 < dimension){
                            if (connectivityMapTemp2 [yPositionTempStart][xPositionTempStart+1] == 1){
                                connectivityMapTemp2 [yPositionTempStart][xPositionTempStart+1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart2, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart2, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                            if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                                connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart2, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart2, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (yPositionTempStart+1 < dimension && findFlag == 0){
                            if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart] == 1){
                                connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart2, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart2, constructedLineCount++;
                                yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                            if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                                connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart2, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart2, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (xPositionTempStart-1 >= 0 && findFlag == 0){
                            if (connectivityMapTemp2 [yPositionTempStart][xPositionTempStart-1] == 1){
                                connectivityMapTemp2 [yPositionTempStart][xPositionTempStart-1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart2, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart2, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                            if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                                connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart2, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart2, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (yPositionTempStart-1 >= 0 && findFlag == 0){
                            if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart] == 1){
                                connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart2, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart2, constructedLineCount++;
                                yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                            if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                                connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart2, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart2, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                            }
                        }
                        
                    } while (terminationFlag == 1);
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp2 [counterY][counterX] == -1) connectivityMapTemp2 [counterY][counterX] = 1;
                        }
                    }
                    
                    connectivityNumber = -3;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp2 [counterY][counterX] == 0){
                                connectivityNumber = connectivityNumber+2;
                                connectivityMapTemp2 [counterY][counterX] = connectivityNumber;
                                
                                connectAnalysisCount = 0;
                                
                                if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0){
                                    connectivityMapTemp2 [counterY-1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0){
                                    connectivityMapTemp2 [counterY][counterX+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0){
                                    connectivityMapTemp2 [counterY+1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0){
                                    connectivityMapTemp2 [counterY][counterX-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                            xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                            
                                            if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                                connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                                connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                                connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                                connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                            connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp2 [counterY][counterX] == -1) connectivityMapTemp2 [counterY][counterX] = 0;
                        }
                    }
                    
                    errorNoHold = 139;
                    int *expandLineFluorescentTemp = new int [expandLineFluorescentCount+50];
                    expandLineFluorescentTempCount = 0;
                    
                    for (int counter2 = 0; counter2 < expandLineFluorescentCount/4; counter2++){
                        if (expandLineFluorescent [counter2*4+2] != groupNoMerge || expandLineFluorescent [counter2*4+3] != counter1){
                            expandLineFluorescentTemp [expandLineFluorescentTempCount] = expandLineFluorescent [counter2*4], expandLineFluorescentTempCount++;
                            expandLineFluorescentTemp [expandLineFluorescentTempCount] = expandLineFluorescent [counter2*4+1], expandLineFluorescentTempCount++;
                            expandLineFluorescentTemp [expandLineFluorescentTempCount] = expandLineFluorescent [counter2*4+2], expandLineFluorescentTempCount++;
                            expandLineFluorescentTemp [expandLineFluorescentTempCount] = expandLineFluorescent [counter2*4+3], expandLineFluorescentTempCount++;
                        }
                    }
                    
                    expandLineFluorescentCount = 0;
                    for (int counter2 = 0; counter2 < expandLineFluorescentTempCount; counter2++) expandLineFluorescent [expandLineFluorescentCount] = expandLineFluorescentTemp [counter2], expandLineFluorescentCount++;
                    
                    delete [] expandLineFluorescentTemp;
                    
                    for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                        if (expandLineFluorescentCount+20 > expandLineFluorescentLimit){
                            [self expandLineFluorescentUpDate];
                            if (errorNoHold != 0){
                                errorNoHold = errorNoHold+2000;
                                throw errorCheckThrow;
                            }
                        }
                        
                        expandLineFluorescent [expandLineFluorescentCount] = arrayNewLines [counter2*2], expandLineFluorescentCount++;
                        expandLineFluorescent [expandLineFluorescentCount] = arrayNewLines [counter2*2+1], expandLineFluorescentCount++;
                        expandLineFluorescent [expandLineFluorescentCount] = groupNoMerge, expandLineFluorescentCount++;
                        
                        if (processType == 0) expandLineFluorescent [expandLineFluorescentCount] = counter1, expandLineFluorescentCount++;
                        else if (processType == 1) expandLineFluorescent [expandLineFluorescentCount] = counter1+3, expandLineFluorescentCount++;
                    }
                    
                    delete [] arrayNewLines;
                    
                    pixelValueTemp = 0;
                    pixelAreaTemp = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp2 [counterY][counterX] != 0){
                                if (counter1 == 1){
                                    if (fluorescentCutOff1 >= fluorescentMap1 [counterX+horizontalStart2][counterX+horizontalStart2]) pixelValueTemp = pixelValueTemp+fluorescentMap1 [counterY+verticalStart2][counterX+horizontalStart2];
                                    pixelAreaTemp++;
                                }
                                if (counter1 == 2){
                                    if (fluorescentCutOff2 >= fluorescentMap2 [counterX+horizontalStart2][counterX+horizontalStart2]) pixelValueTemp = pixelValueTemp+fluorescentMap2 [counterY+verticalStart2][counterX+horizontalStart2];
                                    pixelAreaTemp++;
                                }
                                if (counter1 == 3){
                                    if (fluorescentCutOff3 >= fluorescentMap3 [counterX+horizontalStart2][counterX+horizontalStart2]) pixelValueTemp = pixelValueTemp+fluorescentMap3 [counterY+verticalStart2][counterX+horizontalStart2];
                                    pixelAreaTemp++;
                                }
                                if (counter1 == 4){
                                    if (fluorescentCutOff4 >= fluorescentMap4 [counterX+horizontalStart2][counterX+horizontalStart2]) pixelValueTemp = pixelValueTemp+fluorescentMap4 [counterY+verticalStart2][counterX+horizontalStart2];
                                    pixelAreaTemp++;
                                }
                                if (counter1 == 5){
                                    if (fluorescentCutOff5 >= fluorescentMap5 [counterX+horizontalStart2][counterX+horizontalStart2]) pixelValueTemp = pixelValueTemp+fluorescentMap5 [counterY+verticalStart2][counterX+horizontalStart2];
                                    pixelAreaTemp++;
                                }
                                if (counter1 == 6){
                                    if (fluorescentCutOff6 >= fluorescentMap6 [counterX+horizontalStart2][counterX+horizontalStart2]) pixelValueTemp = pixelValueTemp+fluorescentMap6 [counterY+verticalStart2][counterX+horizontalStart2];
                                    pixelAreaTemp++;
                                }
                            }
                        }
                    }
                    
                    errorNoHold = 140;
                    int *arrayExpandDataTemp2 = new int [expandLineFluorescentDataCount+50];
                    expandDataTempCount2 = 0;
                    
                    for (int counter2 = 0; counter2 < expandLineFluorescentDataCount/4; counter2++){
                        if (expandLineFluorescentData [counter2*4] != groupNoMerge || expandLineFluorescentData [counter2*4+1] != counter1){
                            arrayExpandDataTemp2 [expandDataTempCount2] = expandLineFluorescentData [counter2*4], expandDataTempCount2++;
                            arrayExpandDataTemp2 [expandDataTempCount2] = expandLineFluorescentData [counter2*4+1], expandDataTempCount2++;
                            arrayExpandDataTemp2 [expandDataTempCount2] = expandLineFluorescentData [counter2*4+2], expandDataTempCount2++;
                            arrayExpandDataTemp2 [expandDataTempCount2] = expandLineFluorescentData [counter2*4+3], expandDataTempCount2++;
                        }
                    }
                    
                    expandLineFluorescentDataCount = 0;
                    for (int counter2 = 0; counter2 < expandDataTempCount2; counter2++) expandLineFluorescentData [expandLineFluorescentDataCount] = arrayExpandDataTemp2 [counter2], expandLineFluorescentDataCount++;
                    
                    delete [] arrayExpandDataTemp2;
                    
                    averageArea = pixelValueTemp/(double)pixelAreaTemp;
                    
                    if (expandLineFluorescentDataCount+20 > expandLineFluorescentDataLimit){
                        [self expandLineFluorescentDataUpDate];
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                    }
                    
                    expandLineFluorescentData [expandLineFluorescentDataCount] = groupNoMerge, expandLineFluorescentDataCount++;
                    
                    if (processType == 0) expandLineFluorescentData [expandLineFluorescentDataCount] = counter1, expandLineFluorescentDataCount++;
                    else  if (processType == 1) expandLineFluorescentData [expandLineFluorescentDataCount] = counter1+3, expandLineFluorescentDataCount++;
                    
                    expandLineFluorescentData [expandLineFluorescentDataCount] = (int)averageArea, expandLineFluorescentDataCount++;
                    expandLineFluorescentData [expandLineFluorescentDataCount] = pixelAreaTemp, expandLineFluorescentDataCount++;
                }
                
                delete [] extendConnectList;
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    delete [] connectivityMapTemp [counter1];
                    delete [] connectivityMapTemp2 [counter1];
                    delete [] connectivityMapHold [counter1];
                }
                
                delete [] connectivityMapTemp;
                delete [] connectivityMapTemp2;
                delete [] connectivityMapHold;
                
                delete [] connectAnalysisX;
                delete [] connectAnalysisY;
                delete [] connectAnalysisTempX;
                delete [] connectAnalysisTempY;
                
                for (int counter2 = 0; counter2 < dimension+4; counter2++){
                    delete [] rangeMatrix [counter2];
                }
                
                delete [] rangeMatrix;
                
                delete [] findConnectNo;
            }
            else processResults = 1;
            
            delete [] findReviseConnect;
            
            //for (int counterA = 0; counterA < expandLineFluorescentDataCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandLineFluorescentData [counterA*4+counterB];
            //    cout<<" expandLineFluorescentData "<<counterA<<endl;
            //}
            
            errorNoHold = 0;
            subCompletionFlag2 = 0;
        }
        catch (int errorCheckThrow){
            if (errorNoHold == 0) errorNoHold = 1000;
            
            subCompletionFlag2 = 0;
        }
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingMerge03 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"Merge-lineExtendTrackType2"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
        
        subCompletionFlag2 = 0;
    }
    
    return processResults;
}

-(int)lineExtendTrackTypeCurrent2:(int)groupNoMerge{
    //=====expandType == 2: Expand Lineage lines, exclude area that overlap with existing area=======
    
    //for (int counterA = 0; counterA < expandLineFluorescentDataCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandLineFluorescentData [counterA*4+counterB];
    //    cout<<" expandLineFluorescentData "<<counterA<<endl;
    //}
    
    int processResults = 0;
    
    try{
        try{
            
            errorNoHold = 0;
            int errorCheckThrow = 0;
            subCompletionFlag2 = 1;
            
            int maxPointDimX = 0;
            int maxPointDimY = 0;
            int minPointDimX = 1000000;
            int minPointDimY = 1000000;
            
            for (int counter1 = 0; counter1 < timeSelectedCurrentCount/10; counter1++){
                if (arrayTimeSelectedCurrent [counter1*10+8] == groupNoMerge){
                    for (int counter2 = arrayTimeSelectedCurrent [counter1*10+2]; counter2 < positionReviseCurrentCount/7; counter2++){
                        if (arrayPositionReviseCurrent [counter2*7+3] == groupNoMerge){
                            if (maxPointDimX < arrayPositionReviseCurrent [counter2*7]) maxPointDimX = arrayPositionReviseCurrent [counter2*7];
                            if (minPointDimX > arrayPositionReviseCurrent [counter2*7]) minPointDimX = arrayPositionReviseCurrent [counter2*7];
                            if (maxPointDimY < arrayPositionReviseCurrent [counter2*7+1]) maxPointDimY = arrayPositionReviseCurrent [counter2*7+1];
                            if (minPointDimY > arrayPositionReviseCurrent [counter2*7+1]) minPointDimY = arrayPositionReviseCurrent [counter2*7+1];
                        }
                        else{
                            
                            break;
                        }
                    }
                }
            }
            
            int startY = 0;
            int endY = 0;
            int startX = 0;
            int endX = 0;
            
            int horizontalLength2 = (maxPointDimX-minPointDimX)/2*2;
            int verticalLength2 = (maxPointDimY-minPointDimY)/2*2;
            int dimension2 = 0;
            int dimension2A = 0;
            int dimension2B = 0;
            
            if (horizontalLength2 >= verticalLength2) dimension2 = horizontalLength2+10;
            if (horizontalLength2 < verticalLength2) dimension2 = verticalLength2+10;
            
            dimension2A = (dimension2/2)*5;
            dimension2B = dimension2A+20;
            
            int horizontalStart2A = minPointDimX-(dimension2A-horizontalLength2)/2;
            int verticalStart2A = minPointDimY-(dimension2A-verticalLength2)/2;
            int horizontalStart2B = minPointDimX-(dimension2B-horizontalLength2)/2;
            int verticalStart2B = minPointDimY-(dimension2B-verticalLength2)/2;
            
            //=========B
            errorNoHold = 141;
            int *findReviseConnect = new int [1000];
            for (int counter2 = 0; counter2 < 1000; counter2++) findReviseConnect [counter2] = 0;
            
            errorNoHold = 142;
            int **rangeMatrixA = new int *[dimension2A+4];
            
            for (int counter2 = 0; counter2 < dimension2A+4; counter2++){
                errorNoHold = 143;
                rangeMatrixA [counter2] = new int [dimension2A+4];
            }
            
            errorNoHold = 144;
            int **rangeMatrixB = new int *[dimension2B+4];
            
            for (int counter2 = 0; counter2 < dimension2B+4; counter2++){
                errorNoHold = 145;
                rangeMatrixB [counter2] = new int [dimension2B+4];
            }
            
            errorNoHold = 146;
            int *connectAnalysisXA = new int [dimension2A*4];
            errorNoHold = 147;
            int *connectAnalysisYA = new int [dimension2A*4];
            errorNoHold = 148;
            int *connectAnalysisTempXA = new int [dimension2A*4];
            errorNoHold = 149;
            int *connectAnalysisTempYA = new int [dimension2A*4];
            
            errorNoHold = 150;
            int *connectAnalysisXB = new int [dimension2B*4];
            errorNoHold = 151;
            int *connectAnalysisYB = new int [dimension2B*4];
            errorNoHold = 152;
            int *connectAnalysisTempXB = new int [dimension2B*4];
            errorNoHold = 153;
            int *connectAnalysisTempYB = new int [dimension2B*4];
            
            int freePixelFind = 0;
            int processConnectPosition = 0;
            int processConnectPosition2 = 0;
            int maxConnectRevise = 0;
            int findReviseConnectLimit = 1000;
            int connectivityNumberA = 0;
            int connectivityNumberB = 0;
            int connectAnalysisCount = 0;
            int terminationFlag = 0;
            int connectAnalysisTempCount = 0;
            int xSource = 0;
            int ySource = 0;
            int connectTemp = 0;
            int maxConnect = 0;
            int processConnectNo = 0;
            int findFlag = 0;
            int cutOffFinal = 0;
            
            for (int counter2 = cutStatusFluorescent; counter2 < 240; counter2 = counter2+10){ //====Fluo
                for (int counterY = 0; counterY < dimension2A; counterY++){
                    for (int counterX = 0; counterX < dimension2A; counterX++){
                        if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                            if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2A)*imageDimension+counterX+horizontalStart2A] == 100) rangeMatrixA [counterY][counterX] = 0;
                            else if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2A)*imageDimension+counterX+horizontalStart2A] < counter2) rangeMatrixA [counterY][counterX] = 0;
                            else rangeMatrixA [counterY][counterX] = -150;
                            
                            if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] != 0 && revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] != groupNoMerge) rangeMatrixA [counterY][counterX] = 0;
                        }
                        else rangeMatrixA [counterY][counterX] = 0;
                    }
                }
                
                for (int counterY = 0; counterY < dimension2B; counterY++){
                    for (int counterX = 0; counterX < dimension2B; counterX++){
                        if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                            if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2B)*imageDimension+counterX+horizontalStart2B] == 100) rangeMatrixB [counterY][counterX] = 0;
                            else if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2B)*imageDimension+counterX+horizontalStart2B] < counter2) rangeMatrixB [counterY][counterX] = 0;
                            else rangeMatrixB [counterY][counterX] = -150;
                            
                            if (revisedWorkingMap [counterY+verticalStart2B][counterX+horizontalStart2B] != 0 && revisedWorkingMap [counterY+verticalStart2B][counterX+horizontalStart2B] != groupNoMerge) rangeMatrixB [counterY][counterX] = 0;
                        }
                        else rangeMatrixB [counterY][counterX] = 0;
                    }
                }
                
                //-------MapA--------
                connectivityNumberA = 0;
                
                for (int counterY = 0; counterY < dimension2A; counterY++){
                    for (int counterX = 0; counterX < dimension2A; counterX++){
                        if (rangeMatrixA [counterY][counterX] == -150){
                            connectivityNumberA++;
                            rangeMatrixA [counterY][counterX] = connectivityNumberA;
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixA [counterY-1][counterX-1] == -150){
                                rangeMatrixA [counterY-1][counterX-1] = connectivityNumberA;
                                connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && rangeMatrixA [counterY-1][counterX] == -150){
                                rangeMatrixA [counterY-1][counterX] = connectivityNumberA;
                                connectAnalysisXA [connectAnalysisCount] = counterX, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && counterX+1 < dimension2A && rangeMatrixA [counterY-1][counterX+1] == -150){
                                rangeMatrixA [counterY-1][counterX+1] = connectivityNumberA;
                                connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension2A && rangeMatrixA [counterY][counterX+1] == -150){
                                rangeMatrixA [counterY][counterX+1] = connectivityNumberA;
                                connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension2A && counterX+1 < dimension2A && rangeMatrixA [counterY+1][counterX+1] == -150){
                                rangeMatrixA [counterY+1][counterX+1] = connectivityNumberA;
                                connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension2A && rangeMatrixA [counterY+1][counterX] == -150){
                                rangeMatrixA [counterY+1][counterX] = connectivityNumberA;
                                connectAnalysisXA [connectAnalysisCount] = counterX, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension2A && counterX-1 >= 0 && rangeMatrixA [counterY+1][counterX-1] == -150){
                                rangeMatrixA [counterY+1][counterX-1] = connectivityNumberA;
                                connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && rangeMatrixA [counterY][counterX-1] == -150){
                                rangeMatrixA [counterY][counterX-1] = connectivityNumberA;
                                connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                        xSource = connectAnalysisXA [counter3], ySource = connectAnalysisYA [counter3];
                                        
                                        if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrixA [ySource-1][xSource-1] == -150){
                                            rangeMatrixA [ySource-1][xSource-1] = connectivityNumberA;
                                            connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && rangeMatrixA [ySource-1][xSource] == -150){
                                            rangeMatrixA [ySource-1][xSource] = connectivityNumberA;
                                            connectAnalysisTempXA [connectAnalysisTempCount] = xSource, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && xSource+1 < dimension2A && rangeMatrixA [ySource-1][xSource+1] == -150){
                                            rangeMatrixA [ySource-1][xSource+1] = connectivityNumberA;
                                            connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension2A && rangeMatrixA [ySource][xSource+1] == -150){
                                            rangeMatrixA [ySource][xSource+1] = connectivityNumberA;
                                            connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 > dimension2A && xSource+1 < dimension2A && rangeMatrixA [ySource+1][xSource+1] == -150){
                                            rangeMatrixA [ySource+1][xSource+1] = connectivityNumberA;
                                            connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension2A && rangeMatrixA [ySource+1][xSource] == -150){
                                            rangeMatrixA [ySource+1][xSource] = connectivityNumberA;
                                            connectAnalysisTempXA [connectAnalysisTempCount] = xSource, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension2A && xSource-1 >= 0 && rangeMatrixA [ySource+1][xSource-1] == -150){
                                            rangeMatrixA [ySource+1][xSource-1] = connectivityNumberA;
                                            connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && rangeMatrixA [ySource][xSource-1] == -150){
                                            rangeMatrixA [ySource][xSource-1] = connectivityNumberA;
                                            connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                        connectAnalysisXA [counter3] = connectAnalysisTempXA [counter3], connectAnalysisYA [counter3] = connectAnalysisTempYA [counter3];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //------Determine number of pixels------
                errorNoHold = 154;
                int *connectedPixels = new int [connectivityNumberA+50];
                
                for (int counter3 = 0; counter3 <= connectivityNumberA; counter3++) connectedPixels [counter3] = 0;
                
                for (int counterY = 0; counterY < dimension2A; counterY++){
                    for (int counterX = 0; counterX < dimension2A; counterX++){
                        if (rangeMatrixA [counterY][counterX] != 0) connectedPixels [rangeMatrixA [counterY][counterX]]++;
                    }
                }
                
                //------Map up-date------
                connectTemp = 1;
                
                for (int counter3 = 1; counter3 <= connectivityNumberA; counter3++){
                    if (connectedPixels [counter3] < 10) connectedPixels [counter3] = 0;
                    else{
                        
                        connectedPixels [counter3] = connectTemp;
                        connectTemp++;
                    }
                }
                
                maxConnect = 0;
                maxConnectRevise = 0;
                
                for (int counterY = 0; counterY < dimension2A; counterY++){
                    for (int counterX = 0; counterX < dimension2A; counterX++){
                        if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                            if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A];
                            
                            if ((connectTemp = rangeMatrixA [counterY][counterX]) != 0) rangeMatrixA [counterY][counterX] = connectedPixels [connectTemp];
                            else rangeMatrixA [counterY][counterX] = 0;
                            
                            if (rangeMatrixA [counterY][counterX] > maxConnect) maxConnect = rangeMatrixA [counterY][counterX];
                        }
                    }
                }
                
                delete [] connectedPixels;
                
                errorNoHold = 155;
                int *findConnectNo = new int [maxConnect+5];
                for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo [counter3] = 0;
                
                if (maxConnectRevise+10 > findReviseConnectLimit){
                    delete [] findReviseConnect;
                    errorNoHold = 156;
                    findReviseConnect = new int [maxConnectRevise+50];
                    findReviseConnectLimit = maxConnectRevise+50;
                }
                
                for (int counter3 = 0; counter3 < maxConnectRevise+5; counter3++) findReviseConnect [counter3] = 0;
                
                for (int counterY = 0; counterY < dimension2A; counterY++){
                    for (int counterX = 0; counterX < dimension2A; counterX++){
                        if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                            if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] == groupNoMerge){
                                if (rangeMatrixA [counterY][counterX] != 0) findConnectNo [rangeMatrixA [counterY][counterX]]++;
                            }
                        }
                    }
                }
                
                processConnectNo = 0;
                processConnectPosition = 0;
                
                for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
                    if (findConnectNo [counter3] > processConnectNo){
                        processConnectNo = findConnectNo [counter3];
                        processConnectPosition = counter3;
                    }
                }
                
                if (processConnectPosition != 0){
                    freePixelFind = 0;
                    
                    for (int counterY = 0; counterY < dimension2A; counterY++){
                        for (int counterX = 0; counterX < dimension2A; counterX++){
                            if (rangeMatrixA [counterY][counterX] == processConnectPosition){
                                if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                                    if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] != 0){
                                        findReviseConnect [revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A]]++;
                                    }
                                    
                                    if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] == 0) freePixelFind = 1;
                                }
                            }
                        }
                    }
                    
                    //--------MapB---------
                    connectivityNumberB = 0;
                    
                    for (int counterY = 0; counterY < dimension2B; counterY++){
                        for (int counterX = 0; counterX < dimension2B; counterX++){
                            if (rangeMatrixB [counterY][counterX] == -150){
                                connectivityNumberB++;
                                rangeMatrixB [counterY][counterX] = connectivityNumberB;
                                connectAnalysisCount = 0;
                                
                                if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixB [counterY-1][counterX-1] == -150){
                                    rangeMatrixB [counterY-1][counterX-1] = connectivityNumberB;
                                    connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterY-1 >= 0 && rangeMatrixB [counterY-1][counterX] == -150){
                                    rangeMatrixB [counterY-1][counterX] = connectivityNumberB;
                                    connectAnalysisXB [connectAnalysisCount] = counterX, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterY-1 >= 0 && counterX+1 < dimension2B && rangeMatrixB [counterY-1][counterX+1] == -150){
                                    rangeMatrixB [counterY-1][counterX+1] = connectivityNumberB;
                                    connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterX+1 < dimension2B && rangeMatrixB [counterY][counterX+1] == -150){
                                    rangeMatrixB [counterY][counterX+1] = connectivityNumberB;
                                    connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimension2B && counterX+1 < dimension2B && rangeMatrixB [counterY+1][counterX+1] == -150){
                                    rangeMatrixB [counterY+1][counterX+1] = connectivityNumberB;
                                    connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimension2B && rangeMatrixB [counterY+1][counterX] == -150){
                                    rangeMatrixB [counterY+1][counterX] = connectivityNumberB;
                                    connectAnalysisXB [connectAnalysisCount] = counterX, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimension2B && counterX-1 >= 0 && rangeMatrixB [counterY+1][counterX-1] == -150){
                                    rangeMatrixB [counterY+1][counterX-1] = connectivityNumberB;
                                    connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterX-1 >= 0 && rangeMatrixB [counterY][counterX-1] == -150){
                                    rangeMatrixB [counterY][counterX-1] = connectivityNumberB;
                                    connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                            xSource = connectAnalysisXB [counter3], ySource = connectAnalysisYB [counter3];
                                            
                                            if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrixB [ySource-1][xSource-1] == -150){
                                                rangeMatrixB [ySource-1][xSource-1] = connectivityNumberB;
                                                connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (ySource-1 >= 0 && rangeMatrixB [ySource-1][xSource] == -150){
                                                rangeMatrixB [ySource-1][xSource] = connectivityNumberB;
                                                connectAnalysisTempXB [connectAnalysisTempCount] = xSource, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (ySource-1 >= 0 && xSource+1 < dimension2B && rangeMatrixB [ySource-1][xSource+1] == -150){
                                                rangeMatrixB [ySource-1][xSource+1] = connectivityNumberB;
                                                connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension2B && rangeMatrixB [ySource][xSource+1] == -150){
                                                rangeMatrixB [ySource][xSource+1] = connectivityNumberB;
                                                connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 > dimension2B && xSource+1 < dimension2B && rangeMatrixB [ySource+1][xSource+1] == -150){
                                                rangeMatrixB [ySource+1][xSource+1] = connectivityNumberB;
                                                connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension2B && rangeMatrixB [ySource+1][xSource] == -150){
                                                rangeMatrixB [ySource+1][xSource] = connectivityNumberB;
                                                connectAnalysisTempXB [connectAnalysisTempCount] = xSource, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension2B && xSource-1 >= 0 && rangeMatrixB [ySource+1][xSource-1] == -150){
                                                rangeMatrixB [ySource+1][xSource-1] = connectivityNumberB;
                                                connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && rangeMatrixB [ySource][xSource-1] == -150){
                                                rangeMatrixB [ySource][xSource-1] = connectivityNumberB;
                                                connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                            connectAnalysisXB [counter3] = connectAnalysisTempXB [counter3], connectAnalysisYB [counter3] = connectAnalysisTempYB [counter3];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    //------Determine number of pixels------
                    errorNoHold = 157;
                    connectedPixels = new int [connectivityNumberB+50];
                    
                    for (int counter3 = 0; counter3 <= connectivityNumberB; counter3++) connectedPixels [counter3] = 0;
                    
                    for (int counterY = 0; counterY < dimension2B; counterY++){
                        for (int counterX = 0; counterX < dimension2B; counterX++){
                            if (rangeMatrixB [counterY][counterX] != 0) connectedPixels [rangeMatrixB [counterY][counterX]]++;
                        }
                    }
                    
                    //------Map up-date------
                    connectTemp = 1;
                    
                    for (int counter3 = 1; counter3 <= connectivityNumberB; counter3++){
                        if (connectedPixels [counter3] < 10) connectedPixels [counter3] = 0;
                        else{
                            
                            connectedPixels [counter3] = connectTemp;
                            connectTemp++;
                        }
                    }
                    
                    maxConnect = 0;
                    
                    for (int counterY = 0; counterY < dimension2B; counterY++){
                        for (int counterX = 0; counterX < dimension2B; counterX++){
                            if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                                if ((connectTemp = rangeMatrixB [counterY][counterX]) != 0) rangeMatrixB [counterY][counterX] = connectedPixels [connectTemp];
                                else rangeMatrixB [counterY][counterX] = 0;
                                
                                if (rangeMatrixB [counterY][counterX] > maxConnect) maxConnect = rangeMatrixB [counterY][counterX];
                            }
                        }
                    }
                    
                    delete [] connectedPixels;
                    
                    errorNoHold = 158;
                    int *findConnectNo2 = new int [maxConnect+5];
                    for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo2 [counter3] = 0;
                    
                    for (int counterY = 0; counterY < dimension2B; counterY++){
                        for (int counterX = 0; counterX < dimension2B; counterX++){
                            if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                                if (revisedWorkingMap [counterY+verticalStart2B][counterX+horizontalStart2B] == groupNoMerge){
                                    if (rangeMatrixB [counterY][counterX] != 0) findConnectNo2 [rangeMatrixB [counterY][counterX]]++;
                                }
                            }
                        }
                    }
                    
                    processConnectNo = 0;
                    processConnectPosition2 = 0;
                    
                    for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
                        if (findConnectNo2 [counter3] > processConnectNo){
                            processConnectNo = findConnectNo2 [counter3];
                            processConnectPosition2 = counter3;
                        }
                    }
                    
                    if (processConnectPosition2 != 0){
                        for (int counterY = 0; counterY < dimension2A; counterY++){
                            for (int counterX = 0; counterX < dimension2A; counterX++){
                                if ((counterY+verticalStart2A)-verticalStart2B >= 0 && (counterY+verticalStart2A)-verticalStart2B < +dimension2B && (counterX+horizontalStart2A)-horizontalStart2B >= 0 && (counterX+horizontalStart2A)-horizontalStart2B < dimension2B){
                                    rangeMatrixB [(counterY+verticalStart2A)-verticalStart2B][(counterX+horizontalStart2A)-horizontalStart2B] = 0;
                                }
                            }
                        }
                        
                        findFlag = 0;
                        
                        for (int counterY = 0; counterY < dimension2B; counterY++){
                            for (int counterX = 0; counterX < dimension2B; counterX++){
                                if (rangeMatrixB [counterY][counterX] == processConnectPosition2){
                                    findFlag = 1;
                                    break;
                                }
                            }
                        }
                        
                        if (findFlag == 0){
                            cutOffFinal = counter2;
                            
                            delete [] findConnectNo;
                            delete [] findConnectNo2;
                            break;
                        }
                    }
                    else{
                        
                        if (counter2 != 20) cutOffFinal = counter2-10;
                        else cutOffFinal = 0;
                        
                        delete [] findConnectNo;
                        delete [] findConnectNo2;
                        break;
                    }
                    
                    delete [] findConnectNo2;
                }
                else{
                    
                    if (counter2 != 20) cutOffFinal = counter2-10;
                    else cutOffFinal = 0;
                    
                    delete [] findConnectNo;
                    break;
                }
                
                delete [] findConnectNo;
            }
            
            delete [] connectAnalysisXA;
            delete [] connectAnalysisYA;
            delete [] connectAnalysisTempXA;
            delete [] connectAnalysisTempYA;
            
            delete [] connectAnalysisXB;
            delete [] connectAnalysisYB;
            delete [] connectAnalysisTempXB;
            delete [] connectAnalysisTempYB;
            
            for (int counter2 = 0; counter2 < dimension2A+4; counter2++){
                delete [] rangeMatrixA [counter2];
            }
            
            delete [] rangeMatrixA;
            
            for (int counter2 = 0; counter2 < dimension2B+4; counter2++){
                delete [] rangeMatrixB [counter2];
            }
            
            delete [] rangeMatrixB;
            
            if (cutOffFinal != 0 && freePixelFind == 1){
                int extendConnectCount = 0;
                
                for (int counter1 = 1; counter1 < maxConnectRevise+1; counter1++){
                    if (findReviseConnect [counter1] != 0) extendConnectCount++;
                }
                
                errorNoHold = 159;
                int *extendConnectList = new int [extendConnectCount*2+1];
                extendConnectCount = 0;
                
                for (int counter1 = 1; counter1 < maxConnectRevise+1; counter1++){
                    if (findReviseConnect [counter1] != 0){
                        extendConnectList [extendConnectCount] = counter1, extendConnectCount++;
                        extendConnectList [extendConnectCount] = 0, extendConnectCount++;
                    }
                }
                
                int connectFind = 0;
                
                for (int counter1 = 0; counter1 < timeSelectedCurrentCount/10; counter1++){
                    connectFind = 0;
                    
                    for (int counter2 = 0; counter2 < extendConnectCount/2; counter2++){
                        if (extendConnectList [counter2*2] == arrayTimeSelectedCurrent [counter1*10+8]) connectFind = 1;
                    }
                    
                    if (connectFind == 1){
                        for (int counter2 = arrayTimeSelectedCurrent [counter1*10+2]; counter2 < positionReviseCurrentCount/7; counter2++){
                            if (arrayPositionReviseCurrent [counter2*7+3] == arrayTimeSelectedCurrent [counter1*10+8]){
                                if (maxPointDimX < arrayPositionReviseCurrent [counter2*7]) maxPointDimX = arrayPositionReviseCurrent [counter2*7];
                                if (minPointDimX > arrayPositionReviseCurrent [counter2*7]) minPointDimX = arrayPositionReviseCurrent [counter2*7];
                                if (maxPointDimY < arrayPositionReviseCurrent [counter2*7+1]) maxPointDimY = arrayPositionReviseCurrent [counter2*7+1];
                                if (minPointDimY > arrayPositionReviseCurrent [counter2*7+1]) minPointDimY = arrayPositionReviseCurrent [counter2*7+1];
                            }
                            else{
                                
                                break;
                            }
                        }
                    }
                }
                
                for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                    for (int counter2 = 0; counter2 < expandLineFluorescentCurrentCount/4; counter2++){
                        if (expandLineFluorescentCurrent [counter2*4+2] == extendConnectList [counter1*2]){
                            if (maxPointDimX < expandLineFluorescentCurrent [counter2*4]) maxPointDimX = expandLineFluorescentCurrent [counter2*4];
                            if (minPointDimX > expandLineFluorescentCurrent [counter2*4]) minPointDimX = expandLineFluorescentCurrent [counter2*4];
                            if (maxPointDimY < expandLineFluorescentCurrent [counter2*4+1]) maxPointDimY = expandLineFluorescentCurrent [counter2*4+1];
                            if (minPointDimY > expandLineFluorescentCurrent [counter2*4+1]) minPointDimY = expandLineFluorescentCurrent [counter2*4+1];
                        }
                    }
                }
                
                //for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                //    cout<<extendConnectList [counter1*2]<<"  "<<extendConnectList [counter1*2+1]<<" extendConnectList"<<endl;
                //}
                
                int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                int verticalLength = (maxPointDimY-minPointDimY)/2*2;
                int dimension = 0;
                
                if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
                if (horizontalLength < verticalLength) dimension = verticalLength+30;
                
                dimension = (dimension/2)*5;
                
                int horizontalStart2 = minPointDimX-(dimension-horizontalLength)/2;
                int verticalStart2 = minPointDimY-(dimension-verticalLength)/2;
                
                //=======CC
                errorNoHold = 160;
                int **rangeMatrix = new int *[dimension+4];
                
                for (int counter2 = 0; counter2 < dimension+4; counter2++){
                    errorNoHold = 161;
                    rangeMatrix [counter2] = new int [dimension+4];
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                            if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] == 100) rangeMatrix [counterY][counterX] = 0;
                            else if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] < cutOffFinal) rangeMatrix [counterY][counterX] = 0;
                            else rangeMatrix [counterY][counterX] = -150;
                            
                            if (revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2] != 0 && revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2] != groupNoMerge) rangeMatrix [counterY][counterX] = 0;
                        }
                        else rangeMatrix [counterY][counterX] = 0;
                    }
                }
                
                errorNoHold = 162;
                int *connectAnalysisX = new int [dimension*4];
                errorNoHold = 163;
                int *connectAnalysisY = new int [dimension*4];
                errorNoHold = 164;
                int *connectAnalysisTempX = new int [dimension*4];
                errorNoHold = 165;
                int *connectAnalysisTempY = new int [dimension*4];
                
                int connectivityNumber = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (rangeMatrix [counterY][counterX] == -150){
                            connectivityNumber++;
                            rangeMatrix [counterY][counterX] = connectivityNumber;
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrix [counterY-1][counterX-1] == -150){
                                rangeMatrix [counterY-1][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && rangeMatrix [counterY-1][counterX] == -150){
                                rangeMatrix [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && counterX+1 < dimension && rangeMatrix [counterY-1][counterX+1] == -150){
                                rangeMatrix [counterY-1][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension && rangeMatrix [counterY][counterX+1] == -150){
                                rangeMatrix [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && counterX+1 < dimension && rangeMatrix [counterY+1][counterX+1] == -150){
                                rangeMatrix [counterY+1][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && rangeMatrix [counterY+1][counterX] == -150){
                                rangeMatrix [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && counterX-1 >= 0 && rangeMatrix [counterY+1][counterX-1] == -150){
                                rangeMatrix [counterY+1][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && rangeMatrix [counterY][counterX-1] == -150){
                                rangeMatrix [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                        xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                        
                                        if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrix [ySource-1][xSource-1] == -150){
                                            rangeMatrix [ySource-1][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && rangeMatrix [ySource-1][xSource] == -150){
                                            rangeMatrix [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && xSource+1 < dimension && rangeMatrix [ySource-1][xSource+1] == -150){
                                            rangeMatrix [ySource-1][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension && rangeMatrix [ySource][xSource+1] == -150){
                                            rangeMatrix [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 > dimension && xSource+1 < dimension && rangeMatrix [ySource+1][xSource+1] == -150){
                                            rangeMatrix [ySource+1][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && rangeMatrix [ySource+1][xSource] == -150){
                                            rangeMatrix [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && xSource-1 >= 0 && rangeMatrix [ySource+1][xSource-1] == -150){
                                            rangeMatrix [ySource+1][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && rangeMatrix [ySource][xSource-1] == -150){
                                            rangeMatrix [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                        connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //------Determine number of pixels------
                errorNoHold = 166;
                int *connectedPixels = new int [connectivityNumber+50];
                
                for (int counter3 = 0; counter3 <= connectivityNumber; counter3++) connectedPixels [counter3] = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (rangeMatrix [counterY][counterX] != 0) connectedPixels [rangeMatrix [counterY][counterX]]++;
                    }
                }
                
                //------Map up-date------
                connectTemp = 1;
                
                for (int counter3 = 1; counter3 <= connectivityNumber; counter3++){
                    if (connectedPixels [counter3] < 10) connectedPixels [counter3] = 0;
                    else{
                        
                        connectedPixels [counter3] = connectTemp;
                        connectTemp++;
                    }
                }
                
                maxConnect = 0;
                maxConnectRevise = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                            if (revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2];
                            
                            if ((connectTemp = rangeMatrix [counterY][counterX]) != 0) rangeMatrix [counterY][counterX] = connectedPixels [connectTemp];
                            else rangeMatrix [counterY][counterX] = 0;
                            
                            if (rangeMatrix [counterY][counterX] > maxConnect) maxConnect = rangeMatrix [counterY][counterX];
                        }
                    }
                }
                
                delete [] connectedPixels;
                
                errorNoHold = 167;
                int *findConnectNo = new int [maxConnect+5];
                for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo [counter3] = 0;
                
                if (maxConnectRevise+10 > findReviseConnectLimit){
                    delete [] findReviseConnect;
                    errorNoHold = 168;
                    findReviseConnect = new int [maxConnectRevise+50];
                }
                
                for (int counter3 = 0; counter3 < maxConnectRevise+5; counter3++) findReviseConnect [counter3] = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                            if (revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2] == groupNoMerge){
                                if (rangeMatrix [counterY][counterX] != 0) findConnectNo [rangeMatrix [counterY][counterX]]++;
                            }
                        }
                    }
                }
                
                processConnectNo = 0;
                processConnectPosition = 0;
                
                for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
                    if (findConnectNo [counter3] > processConnectNo){
                        processConnectNo = findConnectNo [counter3];
                        processConnectPosition = counter3;
                    }
                }
                //========CC
                
                errorNoHold = 169;
                int **connectivityMapTemp = new int *[dimension+1];
                errorNoHold = 170;
                int **connectivityMapTemp2 = new int *[dimension+1];
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    errorNoHold = 171;
                    connectivityMapTemp [counter1] = new int [dimension+1];
                    errorNoHold = 172;
                    connectivityMapTemp2 [counter1] = new int [dimension+1];
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = 0;
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (rangeMatrix [counterY][counterX] == processConnectPosition){
                            connectivityMapTemp [counterY][counterX] = -1;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                // 	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
                //	cout<<" connectivityMapTemp "<<counterA<<endl;
                //}
                
                if (minPointDimY-30 >= 0) startY = minPointDimY-30;
                else startY = 0;
                
                if (maxPointDimY+30 < imageDimension) endY = maxPointDimY+31;
                else endY = imageDimension;
                
                if (minPointDimX-30 >= 0) startX = minPointDimX-30;
                else startX = 0;
                
                if (maxPointDimX+30 < imageDimension) endX = maxPointDimX+31;
                else endX = imageDimension;
                
                for (int counterY = startY; counterY < endY; counterY++){
                    for (int counterX = startX; counterX < endX; counterX++){
                        connectFind = 0;
                        
                        for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                            if (extendConnectList [counter1*2] == revisedMapCurrent [counterY][counterX]) connectFind = 1;
                        }
                        
                        if (connectFind == 1){
                            if (counterY-verticalStart2 > 0 && counterX-horizontalStart2 > 0) connectivityMapTemp [counterY-verticalStart2][counterX-horizontalStart2] = revisedMapCurrent [counterY][counterX];
                        }
                    }
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp2 [counterY][counterX] = connectivityMapTemp [counterY][counterX];
                }
                
                terminationFlag = 0;
                int startOrder = 0;
                int findFreePoint = 0;
                int connectNo = 0;
                int remainingCheck = 0;
                
                do{
                    
                    for (int counter1 = startOrder; counter1 < extendConnectCount/2; counter1++){
                        connectNo = extendConnectList [counter1*2];
                        
                        if (extendConnectList [counter1*2+1] == 0){
                            findFreePoint = 0;
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (connectivityMapTemp [counterY][counterX] == connectNo){
                                        if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] == -1){
                                            connectivityMapTemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == -1){
                                            connectivityMapTemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMapTemp [counterY-1][counterX+1] == -1){
                                            connectivityMapTemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == -1){
                                            connectivityMapTemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterY+1 < dimension && counterX+1 < dimension && connectivityMapTemp [counterY+1][counterX+1] == -1){
                                            connectivityMapTemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == -1){
                                            connectivityMapTemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] == -1){
                                            connectivityMapTemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == -1){
                                            connectivityMapTemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                        }
                                    }
                                }
                            }
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                            }
                            
                            if (findFreePoint == 0) extendConnectList [counter1*2+1] = 1;
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < startOrder; counter1++){
                        connectNo = extendConnectList [counter1*2];
                        
                        if (extendConnectList [counter1*2+1] == 0){
                            findFreePoint = 0;
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (connectivityMapTemp [counterY][counterX] == connectNo){
                                        if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] == -1){
                                            connectivityMapTemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == -1){
                                            connectivityMapTemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMapTemp [counterY-1][counterX+1] == -1){
                                            connectivityMapTemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == -1){
                                            connectivityMapTemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterY+1 < dimension && counterX+1 < dimension && connectivityMapTemp [counterY+1][counterX+1] == -1){
                                            connectivityMapTemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == -1){
                                            connectivityMapTemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] == -1){
                                            connectivityMapTemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                        }
                                        if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == -1){
                                            connectivityMapTemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                        }
                                    }
                                }
                            }
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                            }
                            
                            if (findFreePoint == 0) extendConnectList [counter1*2+1] = 1;
                        }
                    }
                    
                    remainingCheck = 0;
                    
                    for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                        if (extendConnectList [counter1*2+1] == 0) remainingCheck = 1;
                    }
                    
                    if (remainingCheck == 0) terminationFlag = 1;
                    
                    startOrder++;
                    
                    if (startOrder == extendConnectCount/2) startOrder = 0;
                    
                } while (terminationFlag == 0);
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
                //    cout<<" connectivityMapTemp "<<counterA<<endl;
                //}
                
                errorNoHold = 173;
                int **connectivityMapHold = new int *[dimension+1];
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    errorNoHold = 174;
                    connectivityMapHold [counter1] = new int [dimension+1];
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapTemp [counterY][counterX] == groupNoMerge) connectivityMapTemp2 [counterY][counterX] = 1;
                        else connectivityMapTemp2 [counterY][counterX] = 0;
                        
                        connectivityMapHold [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                    }
                }
                
                //-------Zero Fill-------
                errorNoHold = 175;
                int **connectivityUpdate5 = new int *[dimension+4];
                
                for (int counter1 = 0; counter1 < dimension+4; counter1++){
                    errorNoHold = 176;
                    connectivityUpdate5 [counter1] = new int [dimension+4];
                }
                
                for (int counterX = 0; counterX < dimension+4; counterX++){
                    for (int counterY = 0; counterY < dimension+4; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = connectivityMapTemp2 [counterY][counterX];
                }
                
                connectivityNumber = 0;
                
                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                        if (connectivityUpdate5 [counterY2][counterX2] == 0){
                            connectivityNumber--;
                            connectAnalysisCount = 0;
                            
                            connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                            
                            if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                                connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                            }
                            if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                            }
                            if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                            }
                            if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                        xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                        
                                        if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                            connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                            connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                            connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                            connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                        connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < dimension+2; counterA++){
                //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                //	cout<<" connectivityUpdate5 "<<counterA<<endl;
                //}
                
                int connectTemp2 = 0;
                
                if (connectivityNumber < -1){
                    errorNoHold = 177;
                    int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                    
                    for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                            connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                            
                            if (connectTemp2 < -1){
                                connectTemp2 = connectTemp2*-1;
                                
                                if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                            }
                        }
                    }
                    
                    int zeroFillFlag = 0;
                    
                    for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                        if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
                    }
                    
                    //for (int counter3 = 1; counter3 <= connectivityNumber*-1; counter3++){
                    //    cout<<counter3<<" "<<connectCheckArray [counter3*2]<<" "<<connectCheckArray [counter3*2+1]<<" connectCheckArray"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < dimension+2; counterA++){
                    //    for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                    //    cout<<" connectivityUpdate5 "<<counterA<<endl;
                    //}
                    
                    if (zeroFillFlag == 1){
                        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                                
                                if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                            }
                        }
                        
                        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                if (connectivityUpdate5 [counterY2][counterX2] > 0){
                                    connectivityMapTemp2 [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                                    connectivityMapHold [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                                }
                            }
                        }
                    }
                    
                    delete [] connectCheckArray;
                }
                
                for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] connectivityUpdate5 [counter1];
                
                delete [] connectivityUpdate5;
                //---------
                
                int connectivityNumber2 = 0;
                int largestConnect = 0;
                int largestConnectNo = 0;
                int xPositionTempStart = 0;
                int yPositionTempStart = 0;
                int lineSize = 0;
                int constructedLineCount = 0;
                int expandLineFluorescentTempCount = 0;
                int pixelValueTemp = 0;
                int pixelAreaTemp = 0;
                int expandDataTempCount2 = 0;
                
                for (int counter1 = 1; counter1 <= fluorescentEntryCount; counter1++){
                    errorNoHold = 178;
                    int **connectivityMapTemp4 = new int *[dimension+1];
                    for (int counter2 = 0; counter2 < dimension+1; counter2++){
                        errorNoHold = 179;
                        connectivityMapTemp4 [counter2] = new int [dimension+1];
                    }
                    
                    if (counter1 > 1){
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp2 [counterY][counterX] = connectivityMapHold [counterY][counterX];
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < extendConnectCount/2; counter2++){
                        if (extendConnectList [counter2*2] != groupNoMerge){
                            findFlag = 0;
                            
                            for (int counter3 = 0; counter3 < expandLineFluorescentCurrentCount/4; counter3++){
                                if (expandLineFluorescentCurrent [counter3*4+2] == extendConnectList [counter2*2] && expandLineFluorescentCurrent [counter3*4+3] == counter1){
                                    findFlag = 1;
                                    break;
                                }
                            }
                            
                            if (findFlag == 1){
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp4 [counterY][counterX] = 0;
                                }
                                
                                for (int counter3 = 0; counter3 < expandLineFluorescentCurrentCount/4; counter3++){
                                    if (expandLineFluorescentCurrent [counter3*4+2] == extendConnectList [counter2*2] && expandLineFluorescentCurrent [counter3*4+3] == counter1){
                                        if (expandLineFluorescentCurrent [counter3*4+1]-verticalStart2 > 0 && expandLineFluorescentCurrent [counter3*4]-horizontalStart2 > 0) connectivityMapTemp4 [expandLineFluorescentCurrent [counter3*4+1]-verticalStart2][expandLineFluorescentCurrent [counter3*4]-horizontalStart2] = 1;
                                    }
                                }
                                
                                connectivityNumber2 = -3;
                                
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++){
                                        if (connectivityMapTemp4 [counterY][counterX] == 0){
                                            connectivityNumber2 = connectivityNumber2+2;
                                            connectivityMapTemp4 [counterY][counterX] = connectivityNumber2;
                                            
                                            connectAnalysisCount = 0;
                                            
                                            if (counterY-1 >= 0 && connectivityMapTemp4 [counterY-1][counterX] == 0){
                                                connectivityMapTemp4 [counterY-1][counterX] = connectivityNumber2;
                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                            }
                                            if (counterX+1 < dimension && connectivityMapTemp4 [counterY][counterX+1] == 0){
                                                connectivityMapTemp4 [counterY][counterX+1] = connectivityNumber2;
                                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                            }
                                            if (counterY+1 < dimension && connectivityMapTemp4 [counterY+1][counterX] == 0){
                                                connectivityMapTemp4 [counterY+1][counterX] = connectivityNumber2;
                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                            }
                                            if (counterX-1 >= 0 && connectivityMapTemp4 [counterY][counterX-1] == 0){
                                                connectivityMapTemp4 [counterY][counterX-1] = connectivityNumber2;
                                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                            }
                                            
                                            if (connectAnalysisCount != 0){
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    connectAnalysisTempCount = 0;
                                                    
                                                    for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                        xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                        
                                                        if (ySource-1 >= 0 && connectivityMapTemp4 [ySource-1][xSource] == 0){
                                                            connectivityMapTemp4 [ySource-1][xSource] = connectivityNumber2;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource+1 < dimension && connectivityMapTemp4 [ySource][xSource+1] == 0){
                                                            connectivityMapTemp4 [ySource][xSource+1] = connectivityNumber2;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                        if (ySource+1 < dimension && connectivityMapTemp4 [ySource+1][xSource] == 0){
                                                            connectivityMapTemp4 [ySource+1][xSource] = connectivityNumber2;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource-1 >= 0 && connectivityMapTemp4 [ySource][xSource-1] == 0){
                                                            connectivityMapTemp4 [ySource][xSource-1] = connectivityNumber2;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                    }
                                                    
                                                    for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                        connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                    }
                                                    
                                                    connectAnalysisCount = connectAnalysisTempCount;
                                                    
                                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                                    
                                                } while (terminationFlag == 1);
                                            }
                                        }
                                    }
                                }
                                
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++){
                                        if (connectivityMapTemp4 [counterY][counterX] > 0 && connectivityMapTemp2 [counterY][counterX] == 1) connectivityMapTemp2 [counterY][counterX] = 0;
                                    }
                                }
                            }
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < dimension+1; counter2++) delete [] connectivityMapTemp4 [counter2];
                    delete [] connectivityMapTemp4;
                    
                    //------Connectivity analysis, For Zero------
                    connectivityNumber = -3;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp2 [counterY][counterX] == 0){
                                connectivityNumber = connectivityNumber+2;
                                connectivityMapTemp2 [counterY][counterX] = connectivityNumber;
                                
                                connectAnalysisCount = 0;
                                
                                if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0){
                                    connectivityMapTemp2 [counterY-1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0){
                                    connectivityMapTemp2 [counterY][counterX+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0){
                                    connectivityMapTemp2 [counterY+1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0){
                                    connectivityMapTemp2 [counterY][counterX-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                            xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                            
                                            if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                                connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                                connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                                connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                                connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                            connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    //------Remove connectivity groups, which attach edge, extract inner part of Linked Line------
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp2 [counterY][counterX] == -1) connectivityMapTemp2 [counterY][counterX] = 0;
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp2 [counterY][counterX] != 0){
                                if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                                else if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                                else if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                                else if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp2 [counterY][counterX] > 0) connectivityMapTemp2 [counterY][counterX] = 0;
                            if (connectivityMapTemp2 [counterY][counterX] < 0) connectivityMapTemp2 [counterY][counterX] = 1;
                        }
                    }
                    
                    connectivityNumber = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (connectivityMapTemp2 [counterY2][counterX2] == 0){
                                connectivityNumber--;
                                connectAnalysisCount = 0;
                                
                                connectivityMapTemp2 [counterY2][counterX2] = connectivityNumber;
                                
                                if (counterY2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2] == 0){
                                    connectivityMapTemp2 [counterY2-1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                }
                                if (counterX2+1 < dimension && connectivityMapTemp2 [counterY2][counterX2+1] == 0){
                                    connectivityMapTemp2 [counterY2][counterX2+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                if (counterY2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2] == 0){
                                    connectivityMapTemp2 [counterY2+1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                }
                                if (counterX2-1 >= 0 && connectivityMapTemp2 [counterY2][counterX2-1] == 0){
                                    connectivityMapTemp2 [counterY2][counterX2-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                            xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                            
                                            if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                                connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                                connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                                connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                                connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                            connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    //------Determine number of pixels------
                    connectivityNumber = connectivityNumber*-1;
                    
                    errorNoHold = 180;
                    connectedPixels = new int [connectivityNumber+50];
                    
                    for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPixels [counter2] = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (connectivityMapTemp2 [counterY2][counterX2] < -1){
                                connectedPixels [connectivityMapTemp2 [counterY2][counterX2]*-1]++;
                            }
                        }
                    }
                    
                    errorNoHold = 181;
                    int **newConnectivityMapTemp = new int *[dimension+4];
                    for (int counter2 = 0; counter2 < dimension+4; counter2++){
                        errorNoHold = 182;
                        newConnectivityMapTemp [counter2] = new int [dimension+4];
                    }
                    
                    for (int counterY = 0; counterY < dimension+4; counterY++){
                        for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
                    }
                    
                    largestConnect = 0;
                    largestConnectNo = 0;
                    
                    for (int counter2 = 2; counter2 <= connectivityNumber; counter2++){
                        if (connectedPixels [counter2] > largestConnect){
                            largestConnect = connectedPixels [counter2];
                            largestConnectNo = counter2;
                        }
                    }
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (connectivityMapTemp2 [counterY2][counterX2] == largestConnectNo*-1){
                                if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2-1] == 1){
                                    newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                                    connectivityMapTemp2 [counterY2-1][counterX2-1] = 0;
                                }
                                if (counterY2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2] == 1){
                                    newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                                    connectivityMapTemp2 [counterY2-1][counterX2] = 0;
                                }
                                if (counterY2-1 >= 0 && counterX2+1 < dimension && connectivityMapTemp2 [counterY2-1][counterX2+1] == 1){
                                    newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                                    connectivityMapTemp2 [counterY2-1][counterX2+1] = 0;
                                }
                                if (counterX2+1 < dimension && connectivityMapTemp2 [counterY2][counterX2+1] == 1){
                                    newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                                    connectivityMapTemp2 [counterY2][counterX2+1] = 0;
                                }
                                if (counterY2+1 < dimension && counterX2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2+1] == 1){
                                    newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                                    connectivityMapTemp2 [counterY2+1][counterX2+1] = 0;
                                }
                                if (counterY2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2] == 1){
                                    newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                                    connectivityMapTemp2 [counterY2+1][counterX2] = 0;
                                }
                                if (counterY2+1 < dimension && counterX2-1 >= 0 && connectivityMapTemp2 [counterY2+1][counterX2-1] == 1){
                                    newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                                    connectivityMapTemp2 [counterY2+1][counterX2-1] = 0;
                                }
                                if (counterX2-1 >= 0 && connectivityMapTemp2 [counterY2][counterX2-1] == 1){
                                    newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                                    connectivityMapTemp2 [counterY2][counterX2-1] = 0;
                                }
                            }
                        }
                    }
                    
                    delete [] connectedPixels;
                    
                    xPositionTempStart = 0;
                    yPositionTempStart = 0;
                    lineSize = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                                connectivityMapTemp2 [counterY2][counterX2] = 1;
                                xPositionTempStart = counterX2;
                                yPositionTempStart = counterY2;
                                lineSize++;
                            }
                            else connectivityMapTemp2 [counterY2][counterX2] = 0;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < dimension+4; counter2++) delete [] newConnectivityMapTemp [counter2];
                    delete [] newConnectivityMapTemp;
                    
                    constructedLineCount = 0;
                    
                    errorNoHold = 183;
                    int *arrayNewLines = new int [lineSize*2+50];
                    
                    connectivityMapTemp2 [yPositionTempStart][xPositionTempStart] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart2, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart2, constructedLineCount++;
                    
                    do{
                        
                        findFlag = 0;
                        terminationFlag = 0;
                        
                        if (xPositionTempStart+1 < dimension){
                            if (connectivityMapTemp2 [yPositionTempStart][xPositionTempStart+1] == 1){
                                connectivityMapTemp2 [yPositionTempStart][xPositionTempStart+1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart2, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart2, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                            if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                                connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart2, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart2, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (yPositionTempStart+1 < dimension && findFlag == 0){
                            if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart] == 1){
                                connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart2, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart2, constructedLineCount++;
                                yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                            if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                                connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart2, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart2, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (xPositionTempStart-1 >= 0 && findFlag == 0){
                            if (connectivityMapTemp2 [yPositionTempStart][xPositionTempStart-1] == 1){
                                connectivityMapTemp2 [yPositionTempStart][xPositionTempStart-1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart2, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart2, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                            if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                                connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart2, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart2, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (yPositionTempStart-1 >= 0 && findFlag == 0){
                            if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart] == 1){
                                connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart2, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart2, constructedLineCount++;
                                yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                            if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                                connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart2, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart2, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                            }
                        }
                        
                    } while (terminationFlag == 1);
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp2 [counterY][counterX] == -1) connectivityMapTemp2 [counterY][counterX] = 1;
                        }
                    }
                    
                    connectivityNumber = -3;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp2 [counterY][counterX] == 0){
                                connectivityNumber = connectivityNumber+2;
                                connectivityMapTemp2 [counterY][counterX] = connectivityNumber;
                                
                                connectAnalysisCount = 0;
                                
                                if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0){
                                    connectivityMapTemp2 [counterY-1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0){
                                    connectivityMapTemp2 [counterY][counterX+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0){
                                    connectivityMapTemp2 [counterY+1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0){
                                    connectivityMapTemp2 [counterY][counterX-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                            xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                            
                                            if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                                connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                                connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                                connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                                connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                            connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp2 [counterY][counterX] == -1) connectivityMapTemp2 [counterY][counterX] = 0;
                        }
                    }
                    
                    errorNoHold = 184;
                    int *expandLineFluorescentTemp = new int [expandLineFluorescentCurrentCount+50];
                    expandLineFluorescentTempCount = 0;
                    
                    for (int counter2 = 0; counter2 < expandLineFluorescentCurrentCount/4; counter2++){
                        if (expandLineFluorescentCurrent [counter2*4+2] != groupNoMerge || expandLineFluorescentCurrent [counter2*4+3] != counter1){
                            expandLineFluorescentTemp [expandLineFluorescentTempCount] = expandLineFluorescentCurrent [counter2*4], expandLineFluorescentTempCount++;
                            expandLineFluorescentTemp [expandLineFluorescentTempCount] = expandLineFluorescentCurrent [counter2*4+1], expandLineFluorescentTempCount++;
                            expandLineFluorescentTemp [expandLineFluorescentTempCount] = expandLineFluorescentCurrent [counter2*4+2], expandLineFluorescentTempCount++;
                            expandLineFluorescentTemp [expandLineFluorescentTempCount] = expandLineFluorescentCurrent [counter2*4+3], expandLineFluorescentTempCount++;
                        }
                    }
                    
                    expandLineFluorescentCurrentCount = 0;
                    for (int counter2 = 0; counter2 < expandLineFluorescentTempCount; counter2++) expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = expandLineFluorescentTemp [counter2], expandLineFluorescentCurrentCount++;
                    
                    delete [] expandLineFluorescentTemp;
                    
                    for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                        if (expandLineFluorescentCurrentCount+20 > expandLineFluorescentCurrentLimit){
                            [self expandLineFluorescentCurrentUpDate];
                            if (errorNoHold != 0){
                                errorNoHold = errorNoHold+2000;
                                throw errorCheckThrow;
                            }
                        }
                        
                        expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = arrayNewLines [counter2*2], expandLineFluorescentCurrentCount++;
                        expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = arrayNewLines [counter2*2+1], expandLineFluorescentCurrentCount++;
                        expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = groupNoMerge, expandLineFluorescentCurrentCount++;
                        expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = counter1, expandLineFluorescentCurrentCount++;
                    }
                    
                    delete [] arrayNewLines;
                    
                    pixelValueTemp = 0;
                    pixelAreaTemp = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp2 [counterY][counterX] != 0){
                                if (counter1 == 1) pixelValueTemp = pixelValueTemp+fluorescentMapCurrent1 [counterY+verticalStart2][counterX+horizontalStart2], pixelAreaTemp++;
                                if (counter1 == 2) pixelValueTemp = pixelValueTemp+fluorescentMapCurrent2 [counterY+verticalStart2][counterX+horizontalStart2], pixelAreaTemp++;
                                if (counter1 == 3) pixelValueTemp = pixelValueTemp+fluorescentMapCurrent3 [counterY+verticalStart2][counterX+horizontalStart2], pixelAreaTemp++;
                                if (counter1 == 4) pixelValueTemp = pixelValueTemp+fluorescentMapCurrent4 [counterY+verticalStart2][counterX+horizontalStart2], pixelAreaTemp++;
                                if (counter1 == 5) pixelValueTemp = pixelValueTemp+fluorescentMapCurrent5 [counterY+verticalStart2][counterX+horizontalStart2], pixelAreaTemp++;
                                if (counter1 == 6) pixelValueTemp = pixelValueTemp+fluorescentMapCurrent6 [counterY+verticalStart2][counterX+horizontalStart2], pixelAreaTemp++;
                            }
                        }
                    }
                    
                    errorNoHold = 185;
                    int *arrayExpandDataTemp2 = new int [expandLineFluorescentDataCurrentCount+50];
                    expandDataTempCount2 = 0;
                    
                    for (int counter2 = 0; counter2 < expandLineFluorescentDataCurrentCount/4; counter2++){
                        if (expandLineFluorescentDataCurrent [counter2*4] != groupNoMerge || expandLineFluorescentDataCurrent [counter2*4+1] != counter1){
                            arrayExpandDataTemp2 [expandDataTempCount2] = expandLineFluorescentDataCurrent [counter2*4], expandDataTempCount2++;
                            arrayExpandDataTemp2 [expandDataTempCount2] = expandLineFluorescentDataCurrent [counter2*4+1], expandDataTempCount2++;
                            arrayExpandDataTemp2 [expandDataTempCount2] = expandLineFluorescentDataCurrent [counter2*4+2], expandDataTempCount2++;
                            arrayExpandDataTemp2 [expandDataTempCount2] = expandLineFluorescentDataCurrent [counter2*4+3], expandDataTempCount2++;
                        }
                    }
                    
                    expandLineFluorescentDataCurrentCount = 0;
                    for (int counter2 = 0; counter2 < expandDataTempCount2; counter2++) expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = arrayExpandDataTemp2 [counter2], expandLineFluorescentDataCurrentCount++;
                    
                    delete [] arrayExpandDataTemp2;
                    
                    double averageArea = pixelValueTemp/(double)pixelAreaTemp;
                    
                    if (expandLineFluorescentDataCurrentCount+20 > expandLineFluorescentDataCurrentLimit){
                        [self expandLineFluorescentDataCurrentUpDate];
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                    }
                    
                    expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = groupNoMerge, expandLineFluorescentDataCurrentCount++;
                    expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = counter1, expandLineFluorescentDataCurrentCount++;
                    expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = (int)averageArea, expandLineFluorescentDataCurrentCount++;
                    expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = pixelAreaTemp, expandLineFluorescentDataCurrentCount++;
                }
                
                delete [] extendConnectList;
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    delete [] connectivityMapTemp [counter1];
                    delete [] connectivityMapTemp2 [counter1];
                    delete [] connectivityMapHold [counter1];
                }
                
                delete [] connectivityMapTemp;
                delete [] connectivityMapTemp2;
                delete [] connectivityMapHold;
                
                delete [] connectAnalysisX;
                delete [] connectAnalysisY;
                delete [] connectAnalysisTempX;
                delete [] connectAnalysisTempY;
                
                for (int counter2 = 0; counter2 < dimension+4; counter2++){
                    delete [] rangeMatrix [counter2];
                }
                
                delete [] rangeMatrix;
                
                delete [] findConnectNo;
            }
            else processResults = 1;
            
            delete [] findReviseConnect;
            
            errorNoHold = 0;
            subCompletionFlag2 = 0;
        }
        catch (int errorCheckThrow){
            if (errorNoHold == 0) errorNoHold = 1000;
            
            subCompletionFlag2 = 0;
        }
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingMerge04 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"Merge-lineExtendTrackTypeCurrent2"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
        
        subCompletionFlag2 = 0;
    }
    
    return processResults;
}

-(void)expandLineFluorescentUpDate{
    try{
        
        errorNoHold = 0;
        
        int *arrayUpDate = new int [expandLineFluorescentCount+10];
        
        for (int counter1 = 0; counter1 < expandLineFluorescentCount; counter1++) arrayUpDate [counter1] = expandLineFluorescent [counter1];
        
        delete [] expandLineFluorescent;
        expandLineFluorescent = new int [expandLineFluorescentLimit*4+10000];
        expandLineFluorescentLimit = expandLineFluorescentLimit*4+10000;
        
        for (int counter1 = 0; counter1 < expandLineFluorescentCount; counter1++) expandLineFluorescent [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
        
        expandLineFluorescentSizeHold = expandLineFluorescentLimit*4+10000;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingMerge05 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"Merge-expandLineFluorescentUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

-(void)expandLineFluorescentDataUpDate{
    try{
        
        errorNoHold = 0;
        
        int *arrayUpDate = new int [expandLineFluorescentDataCount+10];
        
        for (int counter1 = 0; counter1 < expandLineFluorescentDataCount; counter1++) arrayUpDate [counter1] = expandLineFluorescentData [counter1];
        
        delete [] expandLineFluorescentData;
        expandLineFluorescentData = new int [expandLineFluorescentDataLimit*4+10000];
        expandLineFluorescentDataLimit = expandLineFluorescentDataLimit*4+10000;
        
        for (int counter1 = 0; counter1 < expandLineFluorescentDataCount; counter1++) expandLineFluorescentData [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
        
        expandLineFluorescentDataSizeHold = expandLineFluorescentDataLimit*4+10000;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingMerge06 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"Merge-expandLineFluorescentDataUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

-(void)expandLineFluorescentCurrentUpDate{
    try{
        
        errorNoHold = 0;
        int *arrayUpDate = new int [expandLineFluorescentCurrentCount+10];
        
        for (int counter1 = 0; counter1 < expandLineFluorescentCurrentCount; counter1++) arrayUpDate [counter1] = expandLineFluorescentCurrent [counter1];
        
        delete [] expandLineFluorescentCurrent;
        expandLineFluorescentCurrent = new int [expandLineFluorescentCurrentLimit*4+10000];
        expandLineFluorescentCurrentLimit = expandLineFluorescentCurrentLimit*4+10000;
        
        for (int counter1 = 0; counter1 < expandLineFluorescentCurrentCount; counter1++) expandLineFluorescentCurrent [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
        
        expandLineFluorescentCurrentSizeHold = expandLineFluorescentCurrentLimit*4+10000;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingMerge07 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"Merge-expandLineFluorescentCurrentUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

-(void)expandLineFluorescentDataCurrentUpDate{
    try{
        
        errorNoHold = 0;
        
        int *arrayUpDate = new int [expandLineFluorescentDataCurrentCount+10];
        
        for (int counter1 = 0; counter1 < expandLineFluorescentDataCurrentCount; counter1++) arrayUpDate [counter1] = expandLineFluorescentDataCurrent [counter1];
        
        delete [] expandLineFluorescentDataCurrent;
        expandLineFluorescentDataCurrent = new int [expandLineFluorescentDataCurrentLimit*4+10000];
        expandLineFluorescentDataCurrentLimit = expandLineFluorescentDataCurrentLimit*4+10000;
        
        for (int counter1 = 0; counter1 < expandLineFluorescentDataCurrentCount; counter1++) expandLineFluorescentDataCurrent [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
        
        expandLineFluorescentDataCurrentSizeHold = expandLineFluorescentDataCurrentLimit*4+10000;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingMerge08 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"Merge-expandLineFluorescentDataCurrentUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

@end
