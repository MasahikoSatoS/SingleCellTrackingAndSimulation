//
//  OverlapCheck.h
//  Cell_Carving
//
//  Created by Masahiko Sato on 2015-05-20.
//
//

#ifndef OVERLAPCHECK_H
#define OVERLAPCHECK_H
#import "Controller.h" 
#endif

@interface OverlapCheck : NSObject{
}

-(void)overlapCheckMain :(int)cutOffAdjust;

@end
