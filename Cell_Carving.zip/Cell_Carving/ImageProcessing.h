//
// ImageProcessing.h
// cell_carving
//
// Created by Masahiko Sato on 10/07/11.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#ifndef IMAGEPROCESSING_H
#define IMAGEPROCESSING_H
#import "Controller.h"
#endif

@interface ImageProcessing : NSObject{
    id targetTrack;
    id targetTrack2;
    id tableInterpretation;
    id trackingSetCurrent;
    id areaCut;
    id areaCutCurrent;
    id trackingDataSave;
    id trackingSet;
    id generateInterpretTable;
    id newLineSet;
    id overlapCheck;
}

-(id)init;
-(void)dealloc;
-(void)referenceLineCountUpDate;
-(void)eventSequenceUpDate;
-(int)primaryAddition;
-(int)primarySubt;
-(int)secondaryAddition;
-(int)secondarySubt;
-(void)fileHandlingUpDate;
-(void)fluorescentProcess;
-(void)fluorescentProcess2;

@end
