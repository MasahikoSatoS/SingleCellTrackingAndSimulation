//
// SourceDisplay.h
// cell_carving
//
// Created by Masahiko Sato on 10/07/11.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#ifndef SOURCEDISPLAY_H
#define SOURCEDISPLAY_H
#import "Controller.h"
#endif

@interface SourceDisplay : NSView{
    NSImage *cellImage;
    IBOutlet NSWindow *sourceImageDisplay;
}

-(void)dealloc;

@end
