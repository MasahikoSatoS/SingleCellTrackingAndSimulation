//
//  TargetTrack2.m
//  Cell_Carving
//
//  Created by Masahiko Sato on 2015-04-01.
//
//

#import "TargetTrack2.h"

@implementation TargetTrack2

-(int)targetTrackProcess :(int)forceSet{
    //cout<<roundStatus<<" Round"<<endl;
    
    //for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrevious [counterA*6+counterB];
    //	cout<<" arrayCellTrackingPrevious "<<counterA<<endl;
    //}
    
    //for (int counterA = 0; counterA < trackAreaSize; counterA++){
    //	for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingCurrentMap [counterA][counterB];
    //	cout<<" arrayCellTrackingCurrentMap "<<counterA<<endl;
    //}
    
    //for (int counterA = 0; counterA < trackAreaSize; counterA++){
    //    for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingPreviousMap [counterA][counterB];
    //    cout<<" arrayCellTrackingPreviousMap "<<counterA<<endl;
    //}
    
    //for (int counterA = 0; counterA < cellTrackingCurrentCount/6; counterA++){
    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrent [counterA*6+counterB];
    //    cout<<" arrayCellTrackingCurrent "<<counterA<<endl;
    //}
    
    //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
    //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
    //}
    
    //------Target Set------
    targetPointerTrack = 0;
    
    try{
        try{
            
            errorNoHold = 0;
            int errorCheckThrow = 0;
            subCompletionFlag = 1;
            
            for (int counter1 = 0; counter1 < xyPositionCenterPreviousCount/6; counter1++){
                if (arrayXYPositionCenterPrevious [counter1*6+5] == 1){
                    targetPointerTrack = arrayXYPositionCenterPrevious [counter1*6+4];
                }
            }
            
            if (targetPointerTrack != 0){
                //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < cellTrackingCurrentCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrent [counterA*6+counterB];
                //	cout<<" arrayCellTrackingCurrent "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
                //    cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
                //}
                
                //cout<<targetPointer<<" TARG1"<<endl;
                
                //for (int counterA = 0; counterA < cellTrackingPreviousAssCount/6; counterA++){
                // 	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPreviousAss [counterA*6+counterB];
                //	cout<<" arrayCellTrackingPreviousAss "<<counterA<<endl;
                //}
                
                //------Number of lines------
                int lineNumberPrevious = cellTrackingPreviousAssCount/6;
                int lineNumberCurrent = cellTrackingCurrentAssCount/6;
                
                //cout<<lineNumberPrevious<<" "<<lineNumberCurrent<<" Prev_Curr_LineNo"<<endl;
                
                //------Previous Data, total pix, average------
                errorNoHold = 1;
                arrayPreviousTableTrack = new int [lineNumberPrevious*2+10];
                errorNoHold = 2;
                arrayPreviousTableTrackTotal = new double [lineNumberPrevious+5];
                errorNoHold = 3;
                arrayPreviousAverageTrack = new double [lineNumberPrevious+5];
                
                for (int counter1 = 1; counter1 < lineNumberPrevious+5; counter1++){
                    arrayPreviousTableTrack [counter1*2] = 0;
                    arrayPreviousTableTrack [counter1*2+1] = counter1;
                    arrayPreviousTableTrackTotal [counter1] = 0;
                    arrayPreviousAverageTrack [counter1] = 0;
                }
                
                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                        if (arrayCellTrackingPreviousMap [counterY][counterX] > 0){
                            arrayPreviousTableTrack [arrayCellTrackingPreviousMap [counterY][counterX]*2]++;
                            
                            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                arrayPreviousTableTrackTotal [arrayCellTrackingPreviousMap [counterY][counterX]] = arrayPreviousTableTrackTotal [arrayCellTrackingPreviousMap [counterY][counterX]]+sourceImage [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                            }
                        }
                    }
                }
                
                for (int counter1 = 1; counter1 < lineNumberPrevious+1; counter1++){
                    if (arrayPreviousTableTrack [counter1*2] > 10) arrayPreviousAverageTrack [counter1] = arrayPreviousTableTrackTotal [counter1]/(double)arrayPreviousTableTrack [counter1*2];
                    else{
                        
                        arrayPreviousAverageTrack [counter1] = 0;
                        arrayPreviousTableTrack [counter1*2] = 0;
                    }
                }
                
                //------Remove "Below" pix from Connect Pre Map------
                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                        if (arrayCellTrackingPreviousMap [counterY][counterX] > 0 && arrayPreviousTableTrack [arrayCellTrackingPreviousMap [counterY][counterX]*2] == 0) arrayCellTrackingPreviousMap [counterY][counterX] = 0;
                    }
                }
                
                //for (int counterA = 1; counterA < lineNumberPrevious+1; counterA ++){
                //    cout<<" TotalPoint "<<arrayPreviousTableTrack [counterA*2]<<" ConnectNO "<<arrayPreviousTableTrack [counterA*2+1];
                //    cout<<" TotalValue "<<arrayPreviousTableTrackTotal [counterA]<<" Average "<<arrayPreviousAverageTrack [counterA];
                //    cout<<" PreTable First"<<endl;
                //}
                
                //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                //  for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingPreviousMap [counterA][counterB];
                //   cout<<" arrayCellTrackingPreviousMap "<<counterA<<endl;
                //}
                
                //------Current Data, total pix, average, SD calculation------
                errorNoHold = 4;
                arrayCurrentTableTrack = new int [lineNumberCurrent*2+10];
                errorNoHold = 5;
                arrayCurrentTableTrackTotal = new double [lineNumberCurrent+5];
                errorNoHold = 6;
                arrayCurrentAverageTrack = new double [lineNumberCurrent+5];
                errorNoHold = 7;
                double *currentSD = new double [lineNumberCurrent+5];
                errorNoHold = 8;
                int *currentTotalForSD = new int [lineNumberCurrent+5];
                
                for (int counter1 = 1; counter1 < lineNumberCurrent+5; counter1++){
                    arrayCurrentTableTrack [counter1*2] = 0;
                    arrayCurrentTableTrack [counter1*2+1] = counter1;
                    arrayCurrentTableTrackTotal [counter1] = 0;
                    arrayCurrentAverageTrack [counter1] = 0;
                    currentTotalForSD [counter1] = 0;
                    currentSD [counter1] = 0;
                }
                
                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                        if (arrayCellTrackingCurrentMap [counterY][counterX] != 0){
                            arrayCurrentTableTrack [arrayCellTrackingCurrentMap [counterY][counterX]*2]++;
                            
                            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                arrayCurrentTableTrackTotal [arrayCellTrackingCurrentMap [counterY][counterX]] = arrayCurrentTableTrackTotal [arrayCellTrackingCurrentMap [counterY][counterX]]+sourceImage [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                            }
                        }
                    }
                }
                
                for (int counter1 = 1; counter1 < lineNumberCurrent+1; counter1++){
                    if (arrayCurrentTableTrack [counter1*2] != 0) arrayCurrentAverageTrack [counter1] = arrayCurrentTableTrackTotal [counter1]/(double)arrayCurrentTableTrack [counter1*2];
                    else arrayCurrentAverageTrack [counter1] = 0;
                }
                
                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                        if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                            if (arrayCellTrackingCurrentMap [counterY][counterX] != 0) currentTotalForSD [arrayCellTrackingCurrentMap [counterY][counterX]] = currentTotalForSD [arrayCellTrackingCurrentMap [counterY][counterX]]+(int)((double)sourceImage [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]-arrayCurrentAverageTrack [arrayCellTrackingCurrentMap [counterY][counterX]])*(int)((double)sourceImage [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]-arrayCurrentAverageTrack [arrayCellTrackingCurrentMap [counterY][counterX]]);
                        }
                    }
                }
                
                //for (int counterA = 1; counterA < lineNumberCurrent+1; counterA++){
                //	cout<<" TotalPoint "<<arrayCurrentTableTrack [counterA*2]<<" ConnectNO "<<arrayCurrentTableTrack [counterA*2+1];
                //    cout<<" TotalValue "<<arrayCurrentTableTrackTotal [counterA]<<" Average "<<arrayCurrentTableTrackTotal [counterA];
                //    cout<<" CurTable First"<<endl;
                //}
                
                for (int counter1 = 1; counter1 < lineNumberCurrent+1; counter1++){
                    if (arrayCurrentAverageTrack [counter1] != 0) currentSD [counter1] = sqrt(currentTotalForSD [counter1]/(double)(arrayCurrentTableTrack [counter1*2]-1));
                    else currentSD [counter1] = 0;
                }
                
                //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                //    for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingCurrentMap [counterA][counterB];
                //    cout<<" arrayCellTrackingCurrentMap "<<counterA<<endl;
                //}
                
                //for (int counterA = 1; counterA < lineNumberCurrent+1; counterA++) cout<<counterA<<" "<<currentSD [counterA]<<" CP"<<endl;
                
                //------Remove area below 150 and low SD: put "0" in Current Table------
                
                if (forceSet == 0){
                    for (int counter1 = 1; counter1 < lineNumberCurrent+1; counter1++){
                        if (currentSD [counter1] < 10 && arrayCurrentAverageTrack [counter1] > 90 && arrayCurrentAverageTrack [counter1] < 110) arrayCurrentTableTrack [counter1*2] = 0;
                        if (arrayCurrentTableTrack [counter1*2] < 10) arrayCurrentTableTrack [counter1*2] = 0;
                    }
                }
                else{
                    
                    for (int counter1 = 1; counter1 < lineNumberCurrent+1; counter1++){
                        if (arrayCurrentTableTrack [counter1*2] < 10) arrayCurrentTableTrack [counter1*2] = 0;
                    }
                }
                
                //------Remove "Below" pixels from Connect Map------
                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                        if (arrayCurrentTableTrack [arrayCellTrackingCurrentMap [counterY][counterX]*2] == 0) arrayCellTrackingCurrentMap [counterY][counterX] = 0;
                    }
                }
                
                //------Overlap Set------
                errorNoHold = 9;
                int **overlapData = new int *[lineNumberPrevious+1];
                errorNoHold = 10;
                int **overlapIntensity = new int *[lineNumberPrevious+1];
                errorNoHold = 11;
                int **overlapPercent = new int *[lineNumberPrevious+1];
                
                for (int counter1 = 0; counter1 < lineNumberPrevious+1; counter1++){
                    errorNoHold = 12;
                    overlapData [counter1] = new int [lineNumberCurrent+1];
                    errorNoHold = 13;
                    overlapIntensity [counter1] = new int [lineNumberCurrent+1];
                    errorNoHold = 14;
                    overlapPercent [counter1] = new int [lineNumberCurrent+1];
                }
                
                for (int counterY = 0; counterY < lineNumberPrevious+1; counterY++){
                    for (int counterX = 0; counterX < lineNumberCurrent+1; counterX++){
                        overlapData [counterY][counterX] = 0;
                        overlapIntensity [counterY][counterX] = 0;
                        overlapPercent [counterY][counterX] = 0;
                    }
                }
                
                //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                //    for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingCurrentMap [counterA][counterB];
                //    cout<<" arrayCellTrackingCurrentMap "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                //    for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingPreviousMap [counterA][counterB];
                //    cout<<" arrayCellTrackingPreviousMap "<<counterA<<endl;
                //}
                
                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                        if (arrayCellTrackingPreviousMap [counterY][counterX] > 0 && arrayCellTrackingCurrentMap [counterY][counterX] > 0){
                            overlapData [arrayCellTrackingPreviousMap [counterY][counterX]][arrayCellTrackingCurrentMap [counterY][counterX]]++;
                            
                            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                overlapIntensity [arrayCellTrackingPreviousMap [counterY][counterX]][arrayCellTrackingCurrentMap [counterY][counterX]] = overlapIntensity [arrayCellTrackingPreviousMap [counterY][counterX]][arrayCellTrackingCurrentMap [counterY][counterX]]+sourceImage [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                            }
                        }
                    }
                }
                
                for (int counterY = 1; counterY < lineNumberPrevious+1; counterY++){
                    for (int counterX = 1; counterX < lineNumberCurrent+1; counterX++){
                        if (overlapData [counterY][counterX] > 0 && arrayPreviousTableTrack [counterY*2] > 0){
                            overlapIntensity [counterY][counterX] = (int)(overlapIntensity [counterY][counterX]/(double)overlapData [counterY][counterX]);
                        }
                        
                        if (overlapData [counterY][counterX] > 0 && arrayPreviousTableTrack [counterY*2] > 0){
                            overlapPercent [counterY][counterX] = (int)(overlapData [counterY][counterX]/(double)arrayPreviousTableTrack [counterY*2]*100);
                        }
                    }
                }
                
                maxTargetEntryTrack = 0;
                int dataTemp2 = 0;
                
                for (int counterY = 1; counterY < lineNumberPrevious+1; counterY++){
                    dataTemp2 = 0;
                    
                    for (int counterX = 1; counterX < lineNumberCurrent+1; counterX++){
                        if (overlapData [counterY][counterX] != 0 && arrayCurrentTableTrack [counterX*2] > 0) dataTemp2++;
                    }
                    
                    if (dataTemp2 > maxTargetEntryTrack) maxTargetEntryTrack = dataTemp2;
                }
                
                //cout<<p_variablesSet -> _maxTargetEntry<<" MaxTarget2"<<endl;
                
                //for (int counterA = 1; counterA < lineNumberPrevious+1; counterA++){
                //    for (int counterB = 1; counterB < lineNumberCurrent+1; counterB++) cout<<" "<<overlapData [counterA][counterB];
                //    cout<<" overlapData "<<counterA<<endl;
                //}
                
                //for (int counterA = 1; counterA < lineNumberPrevious+1; counterA++){
                //    for (int counterB = 1; counterB < lineNumberCurrent+1; counterB++) cout<<" "<<overlapIntensity [counterA][counterB];
                //    cout<<" overlapIntensity "<<counterA<<endl;
                //}
                
                //for (int counterA = 1; counterA < lineNumberPrevious+1; counterA++){
                //    for (int counterB = 1; counterB < lineNumberCurrent+1; counterB++) cout<<" "<<overlapPercent [counterA][counterB];
                //    cout<<" overlapPercent "<<counterA<<endl;
                //}
                
                int maxEntryTemp = maxTargetEntryTrack;
                
                if (maxEntryTemp != 0){
                    //------Sort Current based on area------
                    errorNoHold = 15;
                    int **overlapNumber2 = new int *[lineNumberPrevious+1];
                    errorNoHold = 16;
                    int **overlapData2 = new int *[lineNumberPrevious+1];
                    errorNoHold = 17;
                    int **overlapIntensity2 = new int *[lineNumberPrevious+1];
                    errorNoHold = 18;
                    int **overlapPercent2 = new int *[lineNumberPrevious+1];
                    
                    for (int counter1 = 0; counter1 < lineNumberPrevious+1; counter1++){
                        errorNoHold = 19;
                        overlapNumber2 [counter1] = new int [maxEntryTemp+1];
                        errorNoHold = 20;
                        overlapData2 [counter1] = new int [maxEntryTemp+1];
                        errorNoHold = 21;
                        overlapIntensity2 [counter1] = new int [maxEntryTemp+1];
                        errorNoHold = 22;
                        overlapPercent2 [counter1] = new int [maxEntryTemp+1];
                    }
                    
                    for (int counterY = 1; counterY < lineNumberPrevious+1; counterY++){
                        for (int counterX = 0; counterX < maxEntryTemp+1; counterX++){
                            overlapNumber2 [counterY][counterX] = 0;
                            overlapData2 [counterY][counterX] = 0;
                            overlapIntensity2 [counterY][counterX] = 0;
                            overlapPercent2 [counterY][counterX] = 0;
                        }
                    }
                    
                    int entryCount = 0;
                    int terminationFlag1 = 0;
                    int sortFindFlag = 0;
                    int overlapMax = 0;
                    int overlapCount = 0;
                    
                    //------Sort------
                    for (int counter1 = 1; counter1 < lineNumberPrevious+1; counter1++){
                        entryCount = 0;
                        
                        do{
                            
                            terminationFlag1 = 1;
                            sortFindFlag = 0;
                            overlapMax = 0;
                            overlapCount = 0;
                            
                            for (int counter2 = 1; counter2 < lineNumberCurrent+1; counter2++){
                                if (overlapMax < overlapPercent [counter1][counter2] && overlapPercent [counter1][counter2] != 0){
                                    overlapMax = overlapPercent [counter1][counter2];
                                    overlapCount = counter2;
                                    sortFindFlag = 1;
                                }
                            }
                            
                            if (sortFindFlag == 1){
                                overlapNumber2 [counter1][entryCount] = overlapCount;
                                overlapData2 [counter1][entryCount] = overlapData [counter1][overlapCount];
                                overlapIntensity2 [counter1][entryCount] = overlapIntensity [counter1][overlapCount];
                                overlapPercent2 [counter1][entryCount] = overlapMax;
                                overlapPercent [counter1][overlapCount] = 0;
                                entryCount++;
                            }
                            else terminationFlag1 = 0;
                            
                        } while (terminationFlag1 == 1);
                    }
                    
                    //for (int counterA = 1; counterA < lineNumberPrevious+1; counterA++){
                    //    for (int counterB = 0; counterB < maxEntryTemp; counterB++){
                    //        cout<<counterA<<" "<<counterB<<" Area2 "<<overlapData2 [counterA][counterB]<<" Intensity "<<overlapIntensity2 [counterA][counterB];
                    //        cout<<" Percent "<<overlapPercent2 [counterA][counterB]<<" Number "<<overlapNumber2 [counterA][counterB]<<" Overlap First4"<<endl;
                    //    }
                    //}
                    
                    //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                    //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                    //}
                    
                    //------Sort Result Verification------
                    errorNoHold = 23;
                    int *numberTemp = new int [maxEntryTemp+1];
                    errorNoHold = 24;
                    int *overlapDataTemp = new int [maxEntryTemp+1];
                    errorNoHold = 25;
                    int *overlapIntensityTemp = new int [maxEntryTemp+1];
                    errorNoHold = 26;
                    int *overlapPercentTemp = new int [maxEntryTemp+1];
                    
                    int connectPrevious = 0;
                    int passFlag = 0;
                    int passFlag2 = 0;
                    int newMainNumber = 0;
                    int mainNumberCount = 0;
                    int connectPrevious2 = 0;
                    
                    for (int counterY = 1; counterY < lineNumberPrevious+1; counterY++){
                        connectPrevious = overlapNumber2 [counterY][0];
                        passFlag = 0;
                        
                        if (arrayPreviousAverageTrack [counterY] > cutOff2){
                            if (arrayCurrentAverageTrack [connectPrevious] > cutOff2 && arrayCurrentTableTrack [connectPrevious*2] > arrayPreviousTableTrack [counterY*2]*0.6 && arrayCurrentTableTrack [connectPrevious*2] <= arrayPreviousTableTrack [counterY*2]*1.4){
                                passFlag = 1;
                            }
                        }
                        if (arrayPreviousAverageTrack [counterY] <= cutOff2 && arrayPreviousAverageTrack [counterY] > cutOff4){
                            if (arrayCurrentAverageTrack [connectPrevious] <= cutOff2 && arrayCurrentAverageTrack [connectPrevious] > cutOff4 && arrayCurrentTableTrack [connectPrevious*2] > arrayPreviousTableTrack [counterY*2]*0.6 && arrayCurrentTableTrack [connectPrevious*2] <= arrayPreviousTableTrack [counterY*2]*1.4){
                                passFlag = 1;
                            }
                            if (arrayCurrentAverageTrack [connectPrevious] <= cutOff4 && arrayCurrentTableTrack [connectPrevious*2] > arrayPreviousTableTrack [counterY*2]*0.8 && arrayCurrentTableTrack [connectPrevious*2] <= arrayPreviousTableTrack [counterY*2]*1.4){
                                passFlag = 1;
                            }
                            if (arrayCurrentAverageTrack [connectPrevious] > cutOff2 && arrayCurrentTableTrack [connectPrevious*2] > arrayPreviousTableTrack [counterY*2]*0.6 && arrayCurrentTableTrack [connectPrevious*2] <= arrayPreviousTableTrack [counterY*2]*1.2){
                                passFlag = 1;
                            }
                        }
                        if (arrayPreviousAverageTrack [counterY] <= 190){
                            if (arrayCurrentAverageTrack [connectPrevious] <= cutOff2 && arrayCurrentAverageTrack [connectPrevious] > cutOff4 && arrayCurrentTableTrack [connectPrevious*2] > arrayPreviousTableTrack [counterY*2]*0.6 && arrayCurrentTableTrack [connectPrevious*2] <= arrayPreviousTableTrack [counterY*2]*1.3){
                                passFlag = 1;
                            }
                            if (arrayCurrentAverageTrack [connectPrevious] <= cutOff4 && arrayCurrentTableTrack [connectPrevious*2] > arrayPreviousTableTrack [counterY*2]*0.6 && arrayCurrentTableTrack [connectPrevious*2] <= arrayPreviousTableTrack [counterY*2]*1.4){
                                passFlag = 1;
                            }
                            if (arrayCurrentAverageTrack [connectPrevious] > cutOff2 && arrayCurrentTableTrack [connectPrevious*2] > arrayPreviousTableTrack [counterY*2]*0.4 && arrayCurrentTableTrack [connectPrevious*2] <= arrayPreviousTableTrack [counterY*2]){
                                passFlag = 1;
                            }
                        }
                        
                        if (passFlag == 0){
                            passFlag2 = 0;
                            newMainNumber = 0;
                            mainNumberCount = 0;
                            
                            for (int counterX = 0; counterX < maxEntryTemp; counterX++){
                                if (overlapNumber2 [counterY][counterX] != 0){
                                    connectPrevious2 = overlapNumber2 [counterY][counterX];
                                    mainNumberCount = counterX;
                                    
                                    if (arrayPreviousAverageTrack [counterY] > cutOff2){
                                        if (arrayCurrentAverageTrack [connectPrevious2] > cutOff2 && arrayCurrentTableTrack [connectPrevious2*2] > arrayPreviousTableTrack [counterY*2]*0.6 && arrayCurrentTableTrack [connectPrevious2*2] <= arrayPreviousTableTrack [counterY*2]*1.4){
                                            passFlag2 = 1, newMainNumber = connectPrevious2;
                                            break;
                                        }
                                    }
                                    if (arrayPreviousAverageTrack [counterY] <= cutOff2 && arrayPreviousAverageTrack [counterY] > cutOff4){
                                        if (arrayCurrentAverageTrack [connectPrevious2] <= cutOff2 && arrayCurrentAverageTrack [connectPrevious2] > cutOff4 && arrayCurrentTableTrack [connectPrevious2*2] > arrayPreviousTableTrack [counterY*2]*0.6 && arrayCurrentTableTrack [connectPrevious2*2] <= arrayPreviousTableTrack [counterY*2]*1.4){
                                            passFlag2 = 1, newMainNumber = connectPrevious2;
                                            break;
                                        }
                                        if (arrayCurrentAverageTrack [connectPrevious2] <= cutOff4 && arrayCurrentTableTrack [connectPrevious2*2] > arrayPreviousTableTrack [counterY*2]*0.8 && arrayCurrentTableTrack [connectPrevious2*2] <= arrayPreviousTableTrack [counterY*2]*1.4){
                                            passFlag2 = 1, newMainNumber = connectPrevious2;
                                            break;
                                        }
                                        if (arrayCurrentAverageTrack [connectPrevious2] > cutOff2 && arrayCurrentTableTrack [connectPrevious2*2] > arrayPreviousTableTrack [counterY*2]*0.6 && arrayCurrentTableTrack [connectPrevious2*2] <= arrayPreviousTableTrack [counterY*2]*1.2){
                                            passFlag2 = 1, newMainNumber = connectPrevious2;
                                            break;
                                        }
                                    }
                                    if (arrayPreviousAverageTrack [counterY] <= cutOff4){
                                        if (arrayCurrentAverageTrack [connectPrevious2] <= cutOff2 && arrayCurrentAverageTrack [connectPrevious2] > cutOff4 && arrayCurrentTableTrack [connectPrevious2*2] > arrayPreviousTableTrack [counterY*2]*0.6 && arrayCurrentTableTrack [connectPrevious2*2] <= arrayPreviousTableTrack [counterY*2]*1.3){
                                            passFlag2 = 1, newMainNumber = connectPrevious2;
                                            break;
                                        }
                                        if (arrayCurrentAverageTrack [connectPrevious2] <= cutOff4 && arrayCurrentTableTrack [connectPrevious2*2] > arrayPreviousTableTrack [counterY*2]*0.6 && arrayCurrentTableTrack [connectPrevious2*2] <= arrayPreviousTableTrack [counterY*2]*1.4){
                                            passFlag2 = 1, newMainNumber = connectPrevious2;
                                            break;
                                        }
                                        if (arrayCurrentAverageTrack [connectPrevious2] > cutOff2 && arrayCurrentTableTrack [connectPrevious2*2] > arrayPreviousTableTrack [counterY*2]*0.4 && arrayCurrentTableTrack [connectPrevious2*2] <= arrayPreviousTableTrack [counterY*2]){
                                            passFlag2 = 1, newMainNumber = connectPrevious2;
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            if (passFlag2 == 1){
                                for (int counterX = 0; counterX < maxEntryTemp; counterX++){
                                    numberTemp [counterX] = 0;
                                    overlapDataTemp [counterX] = 0;
                                    overlapIntensityTemp [counterX] = 0;
                                    overlapPercentTemp [counterX] = 0;
                                }
                                
                                for (int counterX = 0; counterX < maxEntryTemp; counterX++){
                                    if (newMainNumber != overlapNumber2 [counterY][counterX]){
                                        numberTemp [counterX] = overlapNumber2 [counterY][counterX];
                                        overlapDataTemp [counterX] = overlapData2 [counterY][counterX];
                                        overlapIntensityTemp [counterX] = overlapIntensity2 [counterY][counterX];
                                        overlapPercentTemp [counterX] = overlapPercent2 [counterY][counterX];
                                    }
                                }
                                
                                overlapNumber2 [counterY][0] = overlapNumber2 [counterY][mainNumberCount];
                                overlapData2 [counterY][0] = overlapData2 [counterY][mainNumberCount];
                                overlapIntensity2 [counterY][0] = overlapIntensity2 [counterY][mainNumberCount];
                                overlapPercent2 [counterY][0] = overlapPercent2 [counterY][mainNumberCount];
                                entryCount = 1;
                                
                                for (int counterX = 0; counterX < maxEntryTemp; counterX++){
                                    if (numberTemp [counterX] != 0){
                                        overlapNumber2 [counterY][entryCount] = numberTemp [counterX];
                                        overlapData2 [counterY][entryCount] = overlapDataTemp [counterX];
                                        overlapIntensity2 [counterY][entryCount] = overlapIntensityTemp [counterX];
                                        overlapPercent2 [counterY][entryCount] = overlapPercentTemp [counterX];
                                        entryCount++;
                                    }
                                }
                            }
                        }
                    }
                    
                    delete [] numberTemp;
                    delete [] overlapDataTemp;
                    delete [] overlapIntensityTemp;
                    delete [] overlapPercentTemp;
                    
                    //for (int counterA = 1; counterA < lineNumberPrevious+1; counterA++){
                    //	for (int counterB = 0; counterB < maxTargetEntry; counterB++){
                    //		cout<<counterA<<" "<<counterB<<" Area2 "<<overlapData2 [counterA][counterB]<<" Intensity "<<overlapIntensity2 [counterA][counterB]<<endl;
                    //        cout<<" Percent "<<overlapPercent2 [counterA][counterB]<<" Number "<<overlapNumber2 [counterA][counterB]<<" Overlap First5"<<endl;
                    //	}
                    //}
                    
                    errorNoHold = 27;
                    arrayOverlapNumberTrack = new int [lineNumberPrevious*maxEntryTemp*3+10];
                    int overlapNumberCount = 0;
                    errorNoHold = 28;
                    arrayOverlapPixelAreaTrack = new int [lineNumberPrevious*maxEntryTemp*3+10];
                    int overlapPixelAreaCount = 0;
                    errorNoHold = 29;
                    arrayOverlapPixelIntensityTrack = new int [lineNumberPrevious*maxEntryTemp*3+10];
                    int overlapPixelIntensityCount = 0;
                    errorNoHold = 30;
                    arrayOverlapPercentTrack = new int [lineNumberPrevious*maxEntryTemp*3+10];
                    int overlapPercentCount = 0;
                    
                    for (int counterY = 1; counterY < lineNumberPrevious+1; counterY++){
                        entryCount = 1;
                        
                        arrayOverlapNumberTrack [overlapNumberCount] = counterY, overlapNumberCount++;
                        arrayOverlapNumberTrack [overlapNumberCount] = 0, overlapNumberCount++;
                        arrayOverlapNumberTrack [overlapNumberCount] = overlapNumber2 [counterY][0], overlapNumberCount++;
                        
                        arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = counterY, overlapPixelAreaCount++;
                        arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = 0, overlapPixelAreaCount++;
                        arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = overlapData2 [counterY][0], overlapPixelAreaCount++;
                        
                        arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = counterY, overlapPixelIntensityCount++;
                        arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = 0, overlapPixelIntensityCount++;
                        arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = overlapIntensity2 [counterY][0], overlapPixelIntensityCount++;
                        
                        arrayOverlapPercentTrack [overlapPercentCount] = counterY, overlapPercentCount++;
                        arrayOverlapPercentTrack [overlapPercentCount] = 0, overlapPercentCount++;
                        arrayOverlapPercentTrack [overlapPercentCount] = overlapPercent2 [counterY][0], overlapPercentCount++;
                        
                        for (int counterX = 1; counterX < maxEntryTemp; counterX++){
                            if (overlapNumber2 [counterY][counterX] > 0 && overlapData2 [counterY][counterX] > 10 && arrayCurrentTableTrack [overlapNumber2 [counterY][counterX]*2] > 0 && arrayCurrentTableTrack [overlapNumber2 [counterY][counterX]*2+1] > 0){
                                arrayOverlapNumberTrack [overlapNumberCount] = counterY, overlapNumberCount++;
                                arrayOverlapNumberTrack [overlapNumberCount] = entryCount, overlapNumberCount++;
                                arrayOverlapNumberTrack [overlapNumberCount] = overlapNumber2 [counterY][counterX], overlapNumberCount++;
                                
                                arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = counterY, overlapPixelAreaCount++;
                                arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = entryCount, overlapPixelAreaCount++;
                                arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = overlapData2 [counterY][counterX], overlapPixelAreaCount++;
                                
                                arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = counterY, overlapPixelIntensityCount++;
                                arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = entryCount, overlapPixelIntensityCount++;
                                arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = overlapIntensity2 [counterY][counterX], overlapPixelIntensityCount++;
                                
                                arrayOverlapPercentTrack [overlapPercentCount] = counterY, overlapPercentCount++;
                                arrayOverlapPercentTrack [overlapPercentCount] = entryCount, overlapPercentCount++;
                                arrayOverlapPercentTrack [overlapPercentCount] = overlapPercent2 [counterY][counterX], overlapPercentCount++;
                                
                                entryCount++;
                            }
                        }
                    }
                    
                    overlapNumberCountTrack = overlapNumberCount;
                    overlapPixelAreaCountTrack = overlapPixelAreaCount;
                    overlapPixelIntensityCountTrack = overlapPixelIntensityCount;
                    overlapPercentCountTrack = overlapPercentCount;
                    
                    //for (int counterA = 0; counterA < overlapNumberCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapNumberTrack [counterA*3+counterB];
                    //    cout<<" arrayOverlapNumberTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < overlapPixelAreaCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelAreaTrack [counterA*3+counterB];
                    //    cout<<" arrayOverlapPixelAreaTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < overlapPixelIntensityCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelIntensityTrack [counterA*3+counterB];
                    //    cout<<" arrayOverlapPixelIntensityTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < overlapPercentCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPercent [counterA*3+counterB];
                    //	cout<<" arrayOverlapPercent "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < lineNumberPrevious+1; counter1++){
                        delete [] overlapNumber2 [counter1];
                        delete [] overlapData2 [counter1];
                        delete [] overlapIntensity2 [counter1];
                        delete [] overlapPercent2 [counter1];
                    }
                    
                    delete [] overlapNumber2;
                    delete [] overlapData2;
                    delete [] overlapIntensity2;
                    delete [] overlapPercent2;
                    
                    //------Gravity center------
                    //*********1. X position, 2. Y position, 3. Total pix, 4. Average, 5. Connect No, 6. Target*********
                    
                    errorNoHold = 31;
                    int *arrayCellTrackingCurrentTemp2 = new int [xyPositionCenterCurrentCount+50];
                    int cellTrackingCurrentTempCount2 = 0;
                    
                    for (int counter1 = 0; counter1 < xyPositionCenterCurrentCount/6; counter1++){
                        if (arrayCurrentTableTrack [arrayXYPositionCenterCurrent [counter1*6+4]*2] != 0){
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterCurrent [counter1*6], cellTrackingCurrentTempCount2++;
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterCurrent [counter1*6+1], cellTrackingCurrentTempCount2++;
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterCurrent [counter1*6+2], cellTrackingCurrentTempCount2++;
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterCurrent [counter1*6+3], cellTrackingCurrentTempCount2++;
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterCurrent [counter1*6+4], cellTrackingCurrentTempCount2++;
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterCurrent [counter1*6+5], cellTrackingCurrentTempCount2++;
                        }
                    }
                    
                    if (xyPositionCenterCurrentStatus == 0){
                        errorNoHold = 32;
                        arrayXYPositionCenterCurrent = new int [cellTrackingCurrentTempCount2*3+50];
                        xyPositionCenterCurrentCount = 0;
                        xyPositionCenterCurrentStatus = 1;
                        xyPositionCenterCurrentSizeHold = cellTrackingCurrentTempCount2*3+50;
                    }
                    else if (xyPositionCenterCurrentStatus == 1 && xyPositionCenterCurrentSizeHold < cellTrackingCurrentTempCount2){
                        delete [] arrayXYPositionCenterCurrent;
                        
                        errorNoHold = 33;
                        arrayXYPositionCenterCurrent = new int [cellTrackingCurrentTempCount2*3+50];
                        xyPositionCenterCurrentCount = 0;
                        xyPositionCenterCurrentSizeHold = cellTrackingCurrentTempCount2*3+50;
                    }
                    else xyPositionCenterCurrentCount = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingCurrentTempCount2; counter1++) arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = arrayCellTrackingCurrentTemp2 [counter1], xyPositionCenterCurrentCount++;
                    
                    delete [] arrayCellTrackingCurrentTemp2;
                    
                    errorNoHold = 34;
                    arrayCellTrackingCurrentTemp2 = new int [xyPositionCenterPreviousCount+50];
                    cellTrackingCurrentTempCount2 = 0;
                    
                    for (int counter1 = 0; counter1 < xyPositionCenterPreviousCount/6; counter1++){
                        if (arrayPreviousTableTrack [arrayXYPositionCenterPrevious [counter1*6+4]*2] != 0){
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterPrevious [counter1*6], cellTrackingCurrentTempCount2++;
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterPrevious [counter1*6+1], cellTrackingCurrentTempCount2++;
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterPrevious [counter1*6+2], cellTrackingCurrentTempCount2++;
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterPrevious [counter1*6+3], cellTrackingCurrentTempCount2++;
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterPrevious [counter1*6+4], cellTrackingCurrentTempCount2++;
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterPrevious [counter1*6+5], cellTrackingCurrentTempCount2++;
                        }
                    }
                    
                    if (xyPositionCenterPreviousStatus == 0){
                        errorNoHold = 35;
                        arrayXYPositionCenterPrevious = new int [cellTrackingCurrentTempCount2*3+100];
                        xyPositionCenterPreviousCount = 0;
                        xyPositionCenterPreviousStatus = 1;
                        xyPositionCenterPreviousSizeHold = cellTrackingCurrentTempCount2*3+100;
                    }
                    else if (xyPositionCenterPreviousStatus == 1 && xyPositionCenterPreviousSizeHold < cellTrackingCurrentTempCount2){
                        delete [] arrayXYPositionCenterPrevious;
                        
                        errorNoHold = 36;
                        arrayXYPositionCenterPrevious = new int [cellTrackingCurrentTempCount2*3+100];
                        xyPositionCenterPreviousCount = 0;
                        xyPositionCenterPreviousSizeHold = cellTrackingCurrentTempCount2*3+100;
                    }
                    else xyPositionCenterPreviousCount = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingCurrentTempCount2; counter1++) arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = arrayCellTrackingCurrentTemp2 [counter1], xyPositionCenterPreviousCount++;
                    
                    delete [] arrayCellTrackingCurrentTemp2;
                    
                    //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
                    //	cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                    //	cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingCurrentCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrent [counterA*6+counterB];
                    //	cout<<" arrayCellTrackingCurrent "<<counterA<<endl;
                    //}
                    
                    //------Line Data------
                    errorNoHold = 37;
                    int *arrayCellTrackingTemp = new int [cellTrackingCurrentCount+50], cellTrackingTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingCurrentCount/6; counter1++){
                        if (arrayCurrentTableTrack [arrayCellTrackingCurrent [counter1*6+3]*2] != 0){
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingCurrent [counter1*6], cellTrackingTempCount++;
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingCurrent [counter1*6+1], cellTrackingTempCount++;
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingCurrent [counter1*6+2], cellTrackingTempCount++;
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingCurrent [counter1*6+3], cellTrackingTempCount++;
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingCurrent [counter1*6+4], cellTrackingTempCount++;
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingCurrent [counter1*6+5], cellTrackingTempCount++;
                        }
                    }
                    
                    cellTrackingCurrentCount = 0;
                    for (int counter1 = 0; counter1 < cellTrackingTempCount; counter1++) arrayCellTrackingCurrent [cellTrackingCurrentCount] = arrayCellTrackingTemp [counter1], cellTrackingCurrentCount++;
                    
                    delete [] arrayCellTrackingTemp;
                    errorNoHold = 38;
                    arrayCellTrackingTemp = new int [cellTrackingPreviousCount+50];
                    cellTrackingTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingPreviousCount/6; counter1++){
                        if (arrayPreviousTableTrack [arrayCellTrackingPrevious [counter1*6+3]*2] != 0){
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingPrevious [counter1*6], cellTrackingTempCount++;
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingPrevious [counter1*6+1], cellTrackingTempCount++;
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingPrevious [counter1*6+2], cellTrackingTempCount++;
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingPrevious [counter1*6+3], cellTrackingTempCount++;
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingPrevious [counter1*6+4], cellTrackingTempCount++;
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingPrevious [counter1*6+5], cellTrackingTempCount++;
                        }
                    }
                    
                    cellTrackingPreviousCount = 0;
                    for (int counter1 = 0; counter1 < cellTrackingTempCount; counter1++) arrayCellTrackingPrevious [cellTrackingPreviousCount] = arrayCellTrackingTemp [counter1], cellTrackingPreviousCount++;
                    
                    delete [] arrayCellTrackingTemp;
                    
                    //for (int counterA = 0; counterA < overlapPixelIntensityCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelIntensityTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapPixelIntensityTrack "<<counterA<<endl;
                    //}
                    
                    // for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrevious [counterA*6+counterB];
                    // 	cout<<" arrayCellTrackingPrevious "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingCurrentCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrent [counterA*6+counterB];
                    //	cout<<" arrayCellTrackingCurrent "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 1; counterA < lineNumberCurrent+1; counterA++){
                    //	cout<<" TotalPoint "<<arrayCurrentTableTrack [counterA*2]<<" ConnectNO "<<arrayCurrentTableTrack [counterA*2+1];
                    //   cout<<" TotalValue "<<arrayCurrentTableTrackTotal [counterA]<<" Average "<<arrayCurrentTableTrackTotal [counterA];
                    //    cout<<" CurTable First3"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < groupInfoCurrentCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayGroupInfoCurrent [counterA*3+counterB];
                    //	cout<<" arrayGroupInfoCurrent "<<counterA<<endl;
                    //}
                    
                    int findNumber = 0;
                    int findCount = 0;
                    int largestArea = 0;
                    int largestCount = 0;
                    
                    for (int counter1 = 1; counter1 < groupInfoCurrentCount/3+1; counter1++){ //-------If current Table entry is "0", removing (making 0) of corresponding group list------
                        if (arrayCurrentTableTrack [counter1*2] == 0){
                            if (arrayGroupInfoCurrent [counter1*3] < 0) arrayGroupInfoCurrent [counter1*3] = 0; //-----If it < 0 (attached sub), make it 0-----
                            else{
                                
                                findNumber = 0;
                                findCount = 0;
                                
                                for (int counter2 = 1; counter2 < groupInfoCurrentCount/3+1; counter2++){
                                    if (arrayGroupInfoCurrent [counter2*3] == arrayGroupInfoCurrent [counter1*3]*-1){
                                        findCount = counter2;
                                        findNumber++;
                                    }
                                }
                                
                                if (findNumber == 1){
                                    arrayGroupInfoCurrent [counter1*3] = 0;
                                    arrayGroupInfoCurrent [findCount*3] = arrayGroupInfoCurrent [findCount*3]*-1; //-----If it > 0, and found one additional < -1, making 0 that correspond to > 0, and < 0 makes > 0 -----
                                }
                                if (findNumber > 1){ //------If there are more than one < 0, search largest one----
                                    largestArea = 0;
                                    largestCount = 0;
                                    
                                    for (int counter2 = 1; counter2 < groupInfoCurrentCount/3+1; counter2++){
                                        if (arrayGroupInfoCurrent [counter2*3] == arrayGroupInfoCurrent [counter1*3]*-1){
                                            if (largestArea < arrayCurrentTableTrack [counter2*2]){
                                                largestArea = arrayCurrentTableTrack [counter2*2];
                                                largestCount = counter2;
                                            }
                                        }
                                    }
                                    
                                    arrayGroupInfoCurrent [counter1*3] = 0; //-----Make > 0 to 0
                                    arrayGroupInfoCurrent [largestCount*3] = arrayGroupInfoCurrent [largestCount*3]*-1; //------Make largest < 0 to > 0----------
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < groupInfoCurrentCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayGroupInfoCurrent [counterA*3+counterB];
                    //	cout<<" arrayGroupInfoCurrent "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < overlapPixelIntensityCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelIntensityTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapPixelIntensityTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                    //	cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                    //}
                    
                    if (roundStatus == 2){
                        string cellLineageExtract = cellLineageNoHold.substr(1);
                        string cellNumberExtract = cellNoHold.substr(1);
                        int cellLineageTempInt = atoi(cellLineageExtract.c_str());
                        int cellNumberTempInt = atoi(cellNumberExtract.c_str());
                        
                        eventSequenceCount = 0;
                        
                        int occupyCheck = 0;
                        
                        for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                            if (imageNumberInt >= arrayLineageStartEnd [counter1*8+5] && imageNumberInt <= arrayLineageStartEnd [counter1*8+7] && cellLineageTempInt == arrayLineageStartEnd [counter1*8] && cellNumberTempInt == arrayLineageStartEnd [counter1*8+1]){
                                for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                                    if (arrayLineageData [counter2*8+2] == imageNumberInt){
                                        arrayEventSequence [0] = arrayLineageData [counter2*8+2], eventSequenceCount++;
                                        arrayEventSequence [1] = arrayLineageData [counter2*8+3], eventSequenceCount++;
                                        arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++;
                                        arrayEventSequence [eventSequenceCount] = cellNumberTempInt, eventSequenceCount++;
                                        break;
                                    }
                                }
                            }
                            if (occupyCheck == 1){
                                break;
                            }
                        }
                        
                        for (int counter1 = 1; counter1 < groupInfoPreviousCount/5+1; counter1++){ //------If previous Table is O, modify Group table, if "0" correspond to "1, 2, 3", search -1, -2 etc, then, change to 1, 2, 3.
                            if (arrayPreviousTableTrack [counter1*2] == 0){
                                if (arrayGroupInfoPrevious [counter1*5] < 0) arrayGroupInfoPrevious [counter1*5] = 0;
                                else{
                                    
                                    findNumber = 0;
                                    findCount = 0;
                                    
                                    for (int counter2 = 1; counter2 < groupInfoPreviousCount/5+1; counter2++){
                                        if (arrayGroupInfoPrevious [counter2*5] == arrayGroupInfoPrevious [counter1*5]*-1){
                                            findCount = counter2;
                                            findNumber++;
                                        }
                                    }
                                    
                                    if (findNumber == 1){
                                        arrayGroupInfoPrevious [counter1*5] = 0;
                                        arrayGroupInfoPrevious [findCount*5] = arrayGroupInfoPrevious [findCount*5]*-1;
                                    }
                                    if (findNumber > 1){
                                        largestArea = 0;
                                        largestCount = 0;
                                        
                                        for (int counter2 = 1; counter2 < groupInfoPreviousCount/5+1; counter2++){
                                            if (arrayGroupInfoPrevious [counter2*5] == arrayGroupInfoPrevious [counter1*5]*-1){
                                                if (largestArea < arrayPreviousTableTrack [counter2*2]){
                                                    largestArea = arrayPreviousTableTrack [counter2*2];
                                                    largestCount = counter2;
                                                }
                                            }
                                        }
                                        
                                        arrayGroupInfoPrevious [counter1*5] = 0;
                                        arrayGroupInfoPrevious [largestCount*5] = arrayGroupInfoPrevious [largestCount*5]*-1;
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < groupInfoPreviousCount/5; counterA++){
                        //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayGroupInfoPrevious [counterA*5+counterB];
                        //    cout<<" arrayGroupInfoPrevious "<<counterA<<endl;
                        //}
                        
                        int findCellStatus = 0;
                        int findLingNo = 0;
                        
                        for (int counter1 = 0; counter1 < connectNoHoldCount; counter1++){
                            for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                                if ((arrayTimeSelected [counter2*10] == 7 || arrayTimeSelected [counter2*10] == 1) && arrayTimeSelected [counter2*10+8] == connectNoHold [counter1]){
                                    findLingNo = arrayTimeSelected [counter2*10+9];
                                    
                                    if (arrayTimeSelected [counter2*10] == 7) findCellStatus = 1;
                                    else if (arrayTimeSelected [counter2*10] == 1) findCellStatus = 2;
                                    break;
                                }
                            }
                            
                            if (findLingNo != 0){
                                if (findCellStatus == 1) arrayGroupInfoPrevious [counter1*5+4] = 2000; //------Done------
                                else if (findCellStatus == 2) arrayGroupInfoPrevious [counter1*5+4] = 1001; //------Done------
                            }
                        }
                    }
                    
                    // for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                    //	cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                    // }
                    
                    if (roundStatus > 2){
                        //for (int counterA = 0; counterA < groupInfoPreviousCount/5; counterA++){
                        //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayGroupInfoPrevious [counterA*5+counterB];
                        //    cout<<" arrayGroupInfoPrevious "<<counterA<<endl;
                        //}
                        
                        for (int counter1 = 0; counter1 < groupInfoPreviousCount/5; counter1++){
                            arrayGroupInfoPrevious [counter1*5+4] = -1;
                        }
                        
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (arrayCellTrackingTable [counter1*15] == roundStatus-1){
                                for (int counter2 = 0; counter2 < connectNoHoldCount; counter2++){
                                    if (connectNoHold [counter2] == arrayCellTrackingTable [counter1*15+10]){
                                        arrayGroupInfoPrevious [counter2*5+3] = arrayCellTrackingTable [counter1*15+8];
                                        arrayGroupInfoPrevious [counter2*5+4] = arrayCellTrackingTable [counter1*15+14];
                                        break;
                                    }
                                }
                            }
                        }
                        
                        int findFlag = 0;
                        int findCellStatus = 0;
                        
                        for (int counter1 = 0; counter1 < groupInfoPreviousCount/5; counter1++){
                            if (arrayGroupInfoPrevious [counter1*5+4] == -1){
                                findFlag = 0;
                                findCellStatus = 0;
                                
                                for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                                    if ((arrayTimeSelected [counter2*10] == 7 || arrayTimeSelected [counter2*10] == 1) && arrayTimeSelected [counter2*10+8] == connectNoHold [counter1]){
                                        findFlag = 1;
                                        
                                        if (arrayTimeSelected [counter2*10] == 7) findCellStatus = 1;
                                        else if (arrayTimeSelected [counter2*10] == 1) findCellStatus = 2;
                                        break;
                                    }
                                }
                                
                                if (findFlag == 1){
                                    if (findCellStatus == 1) arrayGroupInfoPrevious [counter1*5+4] = 2000; //------Done------
                                    else if (findCellStatus == 2){
                                        if (connectNoHold [counter1] == targetConnectInitial){
                                            for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                                                if (arrayCellTrackingTable [counter2*15] == roundStatus-2 && arrayCellTrackingTable [counter2*15+7] == 1){
                                                    if (arrayCellTrackingTable [counter2*15+14] == 2000) arrayGroupInfoPrevious [counter1*5+4] = 2000;
                                                    else arrayGroupInfoPrevious [counter1*5+4] = arrayCellTrackingTable [counter2*15+14]+1;
                                                    
                                                    break;
                                                }
                                            }
                                        }
                                        else arrayGroupInfoPrevious [counter1*5+4] = 1001; //------Done------
                                    }
                                }
                                else arrayGroupInfoPrevious [counter1*5+4] = 1;
                            }
                        }
                        
                        int groupInvert = 0;
                        
                        for (int counter2 = 0; counter2 < groupInfoPreviousCount/5; counter2++){
                            if (targetPointerTrack == counter2+1 && arrayGroupInfoPrevious [counter2*5] < 0) groupInvert = arrayGroupInfoPrevious [counter2*5]*-1;
                        }
                        
                        if (groupInvert != 0){
                            for (int counter2 = 0; counter2 < groupInfoPreviousCount/5; counter2++){
                                if (targetPointerTrack == counter2+1 && arrayGroupInfoPrevious [counter2*5] < 0) arrayGroupInfoPrevious [counter2*5] = groupInvert;
                                else if (arrayGroupInfoPrevious [counter2*5] == groupInvert) arrayGroupInfoPrevious [counter2*5] = groupInvert*-1;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < groupInfoPreviousCount/5; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayGroupInfoPrevious [counterA*5+counterB];
                    //    cout<<" arrayGroupInfoPrevious5 "<<counterA<<endl;
                    //}
                    
                    //cout<<targetPointer<<"   Target"<<endl;
                    
                    //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
                    //    cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                    //	cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                    //  for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingCurrentMap [counterA][counterB];
                    // cout<<" arrayCellTrackingCurrentMap "<<counterA<<endl;
                    //}
                    
                    //cout<<p_variablesSet ->_targetPointer<<" Target_Current3"<<endl;
                    
                    //for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrevious [counterA*6+counterB];
                    //    cout<<" arrayCellTrackingPrevious "<<counterA<<endl;
                    // }
                    
                    //==========Previous Process==========
                    int roundTwo = 2;
                    
                    if (forceSet == 0){
                        targetPrevious = [[TargetPrevious alloc] init];
                        [targetPrevious targetPreviousMain:roundTwo];
                        
                        do{
                        } while (subCompletionFlag2 == 1);
                        
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                    }
                    
                    //cout<<p_variablesSet ->_targetPointer<<" Target_Current7"<<endl;
                    
                    //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
                    //	cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                    //	cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                    //   for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingCurrentMap [counterA][counterB];
                    //   cout<<" arrayCellTrackingCurrentMap "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < groupInfoCurrentCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayGroupInfoCurrent [counterA*3+counterB];
                    //    cout<<" arrayGroupInfoCurrent "<<counterA<<endl;
                    // }
                    
                    //for (int counterA = 0; counterA < groupInfoPreviousCount/5; counterA++){
                    //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayGroupInfoPrevious [counterA*5+counterB];
                    //	cout<<" arrayGroupInfoPrevious "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingCurrentCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrent [counterA*6+counterB];
                    //	cout<<" arrayCellTrackingCurrent "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrevious [counterA*6+counterB];
                    //	cout<<" arrayCellTrackingPrevious "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingCurrentAssCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrentAss [counterA*6+counterB];
                    // 	cout<<" arrayCellTrackingCurrentAss "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingPreviousAssCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPreviousAss [counterA*6+counterB];
                    //	cout<<" arrayCellTrackingPreviousAss "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < p_variablesSet ->_overlapNumberCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapNumberTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapNumberTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < p_variablesSet ->_overlapPixelIntensityCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelIntensityTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapPixelIntensityTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < p_variablesSet ->_overlapPixelAreaCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelAreaTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapPixelAreaTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < p_variablesSet ->_overlapPercentCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPercentTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapPercentTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                    //    for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingPreviousMap [counterA][counterB];
                    //    cout<<" arrayCellTrackingPreviousMap "<<counterA<<endl;
                    //}
                    
                    //==========Current process==========
                    errorNoHold = 39;
                    arrayNoMergeTableTrack = new int [500];
                    noMergeTableCountTrack = 0;
                    noMergeTableLimitTrack = 500;
                    
                    if (forceSet == 0){
                        targetCurrent = [[TargetCurrent alloc] init];
                        [targetCurrent targetCurrentMain:roundTwo];
                        
                        do{
                        } while (subCompletionFlag2 == 1);
                        
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                    }
                    
                    //========Read data==========
                    //------Current, Previous line number set------
                    int lineNumberPrevious2 = cellTrackingPreviousAssCount/6;
                    int lineNumberCurrent2 = cellTrackingCurrentAssCount/6;
                    
                    //cout<<lineNumberPrevious2<<" "<<lineNumberCurrent2<<" Prev_Curr_LineNo.Last"<<endl;
                    
                    //------Overlap Table------
                    errorNoHold = 40;
                    int **overlapTable = new int *[lineNumberPrevious2+5];
                    for (int counter1 = 0; counter1 < lineNumberPrevious2+5; counter1++){
                        errorNoHold = 41;
                        overlapTable [counter1] = new int [lineNumberCurrent2+5];
                    }
                    
                    for (int counterY = 0; counterY < lineNumberPrevious2+5; counterY++){
                        for (int counterX = 0; counterX < lineNumberCurrent2+5; counterX++) overlapTable [counterY][counterX] = 0;
                    }
                    
                    for (int counter1 = 0; counter1 < overlapPixelAreaCountTrack/3; counter1++){
                        if (arrayOverlapNumberTrack [counter1*3+2] != 0) overlapTable [arrayOverlapNumberTrack [counter1*3]][arrayOverlapNumberTrack [counter1*3+2]] = arrayOverlapPixelAreaTrack [counter1*3+2];
                    }
                    
                    //for (int counterA = 1; counterA < lineNumberPrevious2+1; counterA++){
                    //	for (int counterB = 1; counterB < lineNumberCurrent2+1; counterB++){
                    //      cout<< counterA<<" "<< counterB<<" "<<overlapTable [counterA][counterB]<<" overlapTable"<<endl;
                    //	}
                    //}
                    
                    //------No Merge Table------
                    errorNoHold = 42;
                    int **noMergeTable = new int *[lineNumberPrevious2+5];
                    for (int counter1 = 0; counter1 < lineNumberPrevious2+5; counter1++){
                        errorNoHold = 43;
                        noMergeTable [counter1] = new int [lineNumberCurrent2+5];
                    }
                    
                    for (int counterY = 0; counterY < lineNumberPrevious2+5; counterY++){
                        for (int counterX = 0; counterX < lineNumberCurrent2+5; counterX++) noMergeTable [counterY][counterX] = 0;
                    }
                    
                    for (int counter1 = 1; counter1 < noMergeTableCountTrack/2+1; counter1++){
                        noMergeTable [arrayNoMergeTableTrack [(counter1-1)*2]][arrayNoMergeTableTrack [(counter1-1)*2+1]] = 1;
                    }
                    
                    //for (int counterA = 1; counterA < lineNumberPrevious2+1; counterA++){
                    //    for (int counterB = 1; counterB < lineNumberCurrent2+1; counterB++){
                    //        if (noMergeTable [counterA][counterB] > 0) cout<<counterA<<" "<<counterB<<" "<<noMergeTable [counterA][counterB]<<" noMergeTable"<<endl;
                    //    }
                    //}
                    
                    //==========Current connect Number update===========
                    errorNoHold = 44;
                    int *connectedPixels = new int [lineNumberCurrent2+5];
                    
                    for (int counter1 = 0; counter1 < lineNumberCurrent2+5; counter1++) connectedPixels [counter1] = 0;
                    
                    for (int counterY = 0; counterY < trackAreaSize; counterY++){
                        for (int counterX = 0; counterX < trackAreaSize; counterX++){
                            if (arrayCellTrackingCurrentMap [counterY][counterX] != 0) connectedPixels [arrayCellTrackingCurrentMap [counterY][counterX]]++;
                        }
                    }
                    
                    //for (int counterA = 1; counterA < lineNumberCurrent2+1; counterA++) cout<<counterA<<" "<<connectedPixels [counterA] <<" Connect_Current_Value"<<endl;
                    
                    int counterTemp = 1;
                    
                    for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                        if (connectedPixels [counter1] > 10) connectedPixels [counter1] = counterTemp, counterTemp++;
                        else connectedPixels [counter1] = 0;
                    }
                    
                    //for (int counterA = 1; counterA < lineNumberCurrent2+1; counterA++) cout<<counterA<<" "<<connectedPixels [counterA] <<" Connect_Current_adjust"<<endl;
                    
                    //------Current Map Update------
                    for (int counterY = 0; counterY < trackAreaSize; counterY++){
                        for (int counterX = 0; counterX < trackAreaSize; counterX++){
                            if (arrayCellTrackingCurrentMap [counterY][counterX] != 0) arrayCellTrackingCurrentMap [counterY][counterX] = connectedPixels [arrayCellTrackingCurrentMap [counterY][counterX]];
                            else arrayCellTrackingCurrentMap [counterY][counterX] = 0;
                        }
                    }
                    
                    //------Current Overlap Table Update------
                    errorNoHold = 45;
                    int **overlapTableNew = new int *[lineNumberPrevious2+5];
                    for (int counter1 = 0; counter1 < lineNumberPrevious2+5; counter1++){
                        errorNoHold = 46;
                        overlapTableNew [counter1] = new int [lineNumberCurrent2+5];
                    }
                    
                    for (int counterY = 0; counterY < lineNumberPrevious2+5; counterY++){
                        for (int counterX = 0; counterX < lineNumberCurrent2+5; counterX++) overlapTableNew [counterY][counterX] = 0;
                    }
                    
                    for (int counterY = 1; counterY < lineNumberPrevious2+1; counterY++){
                        for (int counterX = 1; counterX < lineNumberCurrent2+1; counterX++){
                            if (overlapTable [counterY][counterX] > 0){
                                counterTemp = connectedPixels [counterX];
                                overlapTableNew [counterY][counterTemp] = overlapTable [counterY][counterX];
                            }
                        }
                    }
                    
                    //for (int counterA = 1; counterA < lineNumberPrevious2+1; counterA++){
                    //    for (int counterB = 1; counterB < lineNumberCurrent2+1; counterB++){
                    //        cout<< counterA<<" "<< counterB<<" "<<overlapTableNew [counterA][counterB]<<" OVER_Last_adjust"<<endl;
                    //    }
                    //}
                    
                    //------Current No Merge Table Adjust------
                    errorNoHold = 47;
                    int **noMergeTableNew = new int *[lineNumberPrevious2+5];
                    for (int counter1 = 0; counter1 < lineNumberPrevious2+5; counter1++){
                        errorNoHold = 48;
                        noMergeTableNew [counter1] = new int [lineNumberCurrent2+5];
                    }
                    
                    for (int counterY = 0; counterY < lineNumberPrevious2+5; counterY++){
                        for (int counterX = 0; counterX < lineNumberCurrent2+5; counterX++) noMergeTableNew [counterY][counterX] = 0;
                    }
                    
                    for (int counterY = 1; counterY < lineNumberPrevious2+1; counterY++){
                        for (int counterX = 1; counterX < lineNumberCurrent2+1; counterX++){
                            if (noMergeTable [counterY][counterX] == 1){
                                counterTemp = connectedPixels [counterX];
                                noMergeTableNew [counterY][counterTemp] = 1;
                            }
                        }
                    }
                    
                    //for (int counterA = 1; counterA < lineNumberPrevious2+1; counterA++){
                    //	for (int counterB = 1; counterB < lineNumberCurrent2+1; counterB++){
                    //		if (noMergeTableNew [counterA][counterB] > 0) cout<<counterA<<" "<<counterB<<" "<<noMergeTableNew [counterA][counterB]<<" Merge_Last_Adjust1"<<endl;
                    //	}
                    //}
                    
                    //------Gravity centre update------
                    for (int counter1 = 0; counter1 < xyPositionCenterCurrentCount/6; counter1++){
                        if (arrayXYPositionCenterCurrent [counter1*6+4] != 0){
                            counterTemp = arrayXYPositionCenterCurrent [counter1*6+4];
                            arrayXYPositionCenterCurrent [counter1*6+4] = connectedPixels [counterTemp];
                        }
                    }
                    
                    int counterMax = xyPositionCenterCurrentCount/6;
                    xyPositionCenterCurrentCount = 0;
                    
                    for (int counter1 = 0; counter1 < counterMax; counter1++){
                        if (arrayXYPositionCenterCurrent [counter1*6+4] != 0){
                            arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = arrayXYPositionCenterCurrent [counter1*6], xyPositionCenterCurrentCount++;
                            arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = arrayXYPositionCenterCurrent [counter1*6+1], xyPositionCenterCurrentCount++;
                            arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = arrayXYPositionCenterCurrent [counter1*6+2], xyPositionCenterCurrentCount++;
                            arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = arrayXYPositionCenterCurrent [counter1*6+3], xyPositionCenterCurrentCount++;
                            arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = arrayXYPositionCenterCurrent [counter1*6+4], xyPositionCenterCurrentCount++;
                            arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = arrayXYPositionCenterCurrent [counter1*6+5], xyPositionCenterCurrentCount++;
                        }
                    }
                    
                    //cout<<p_variablesSet ->_targetPointer<<" Target_Current"<<endl;
                    
                    //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
                    //	cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                    //	cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                    //}
                    
                    //------Tracking line data update------
                    for (int counter1 = 0; counter1 < cellTrackingCurrentCount/6; counter1++){
                        counterTemp = arrayCellTrackingCurrent [counter1*6+3];
                        arrayCellTrackingCurrent [counter1*6+3] = connectedPixels [counterTemp];
                    }
                    
                    //------Done and Mitosis status extract------
                    errorNoHold = 49;
                    int *doneMitosis = new int [lineNumberPrevious2*2+10];
                    
                    for (int counter1 = 0; counter1 < lineNumberPrevious2+5; counter1++){
                        doneMitosis [counter1*2] = 0;
                        doneMitosis [counter1*2+1] = 0;
                    }
                    
                    for (int counter1 = 0; counter1 < groupInfoPreviousCount/5; counter1++){
                        doneMitosis [(counter1+1)*2] = arrayGroupInfoPrevious [counter1*5+3];
                        doneMitosis [(counter1+1)*2+1] = arrayGroupInfoPrevious [counter1*5+4];
                    }
                    
                    for (int counter1 = 0; counter1 < lineNumberPrevious2+5; counter1++){
                        delete [] overlapTable [counter1];
                        delete [] noMergeTable [counter1];
                    }
                    
                    delete [] overlapTable;
                    delete [] noMergeTable;
                    delete [] connectedPixels;
                    
                    //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                    //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                    //}
                    
                    //==========Tracking Table Entry==========
                    if (cellTrackingRelStatus == 0){
                        errorNoHold = 50;
                        arrayCellTrackingRel = new int [xyPositionCenterPreviousCount*6+xyPositionCenterCurrentCount*6+50];
                        cellTrackingRelCount = 0;
                        cellTrackingRelStatus = 1;
                        cellTrackingRelSizeHold = xyPositionCenterPreviousCount*6+xyPositionCenterCurrentCount*6+50;
                    }
                    else if (cellTrackingRelStatus == 1 && cellTrackingRelSizeHold < xyPositionCenterPreviousCount*3+xyPositionCenterCurrentCount*3){
                        delete [] arrayCellTrackingRel;
                        
                        errorNoHold = 51;
                        arrayCellTrackingRel = new int [xyPositionCenterPreviousCount*6+xyPositionCenterCurrentCount*6+50];
                        cellTrackingRelCount = 0;
                        cellTrackingRelStatus = 1;
                        cellTrackingRelSizeHold = xyPositionCenterPreviousCount*6+xyPositionCenterCurrentCount*6+50;
                    }
                    else cellTrackingRelCount = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingRelSizeHold; counter1++) arrayCellTrackingRel [counter1] = 0;
                    
                    int nextEntryNumber = 0;
                    int nextNumberCount = 0;
                    
                    //------Previous Entry------
                    for (int counter1 = 0; counter1 < xyPositionCenterPreviousCount/6; counter1++){
                        arrayCellTrackingRel [cellTrackingRelCount] = roundStatus-1, cellTrackingRelCount++; //------Round number------
                        arrayCellTrackingRel [cellTrackingRelCount] = imageNumberInt, cellTrackingRelCount++; //------Image number------
                        arrayCellTrackingRel [cellTrackingRelCount] = connectNoHold [arrayXYPositionCenterPrevious [counter1*6+4]-1], cellTrackingRelCount++; //------Connect number------
                        arrayCellTrackingRel [cellTrackingRelCount] = arrayXYPositionCenterPrevious [counter1*6], cellTrackingRelCount++; //------X position------
                        arrayCellTrackingRel [cellTrackingRelCount] = arrayXYPositionCenterPrevious [counter1*6+1], cellTrackingRelCount++; //------Y position------
                        arrayCellTrackingRel [cellTrackingRelCount] = arrayXYPositionCenterPrevious [counter1*6+2], cellTrackingRelCount++; //------Area------
                        arrayCellTrackingRel [cellTrackingRelCount] = arrayXYPositionCenterPrevious [counter1*6+3], cellTrackingRelCount++; //------Intensity------
                        
                        if (targetPointerTrack == arrayXYPositionCenterPrevious [counter1*6+4]) arrayCellTrackingRel [cellTrackingRelCount] = 1, cellTrackingRelCount++; //------Target------
                        else arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Target------
                        
                        arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Mitosis Status------
                        
                        errorNoHold = 52;
                        int *listOfDivision = new int [lineNumberCurrent2+5];
                        nextEntryNumber = 0;
                        
                        for (int counter2 = 0; counter2 < lineNumberCurrent2+5; counter2++) listOfDivision [counter2] = 0;
                        
                        for (int counter2 = 1; counter2 < lineNumberCurrent2+1; counter2++){
                            if (overlapTableNew [arrayXYPositionCenterPrevious [counter1*6+4]][counter2] != 0) listOfDivision [nextEntryNumber] = counter2, nextEntryNumber++;
                        }
                        
                        for (int counter2 = 1; counter2 < lineNumberCurrent2+1; counter2++){
                            if (noMergeTableNew [arrayXYPositionCenterPrevious [counter1*6+4]][counter2] != 0) listOfDivision [nextEntryNumber] = counter2, nextEntryNumber++;
                        }
                        
                        arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Div/Fuse/Check (add at Table Interpretation)------
                        
                        if (nextEntryNumber > 0){
                            nextNumberCount = 0;
                            
                            for (int counter2 = 0; counter2 < nextEntryNumber; counter2++){
                                if (nextNumberCount == 2){
                                    nextNumberCount = 1;
                                    arrayCellTrackingRel [cellTrackingRelCount] = roundStatus-1, cellTrackingRelCount++; //------Round number------
                                    arrayCellTrackingRel [cellTrackingRelCount] = imageNumberInt, cellTrackingRelCount++; //------Image number------
                                    arrayCellTrackingRel [cellTrackingRelCount] = connectNoHold [arrayXYPositionCenterPrevious [counter1*6+4]-1], cellTrackingRelCount++; //------Connect number------
                                    arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------X position------
                                    arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Y position------
                                    arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Area------
                                    arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Intensity------
                                    arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Target------
                                    arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Mitosis Status------
                                    arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Divide/Fuse/Check------
                                    arrayCellTrackingRel [cellTrackingRelCount] = listOfDivision [counter2], cellTrackingRelCount++; //------Next1------
                                }
                                else if (nextNumberCount == 0){
                                    arrayCellTrackingRel [cellTrackingRelCount] = listOfDivision [counter2], cellTrackingRelCount++; //------Next1------
                                    nextNumberCount++;
                                }
                                else if (nextNumberCount == 1){
                                    arrayCellTrackingRel [cellTrackingRelCount] = listOfDivision [counter2], cellTrackingRelCount++; //------Next2------
                                    arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Previous1------
                                    arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Previous2------
                                    arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Done------
                                    nextNumberCount++;
                                }
                            }
                            
                            if (nextNumberCount == 0 || nextNumberCount == 1){
                                arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Next2------
                                arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Previous1------
                                arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Previous2------
                                arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Done------
                            }
                        }
                        else if (nextEntryNumber == 0){
                            arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Next1------
                            arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Next2------
                            arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Previous1------
                            arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Previous2------
                            arrayCellTrackingRel [cellTrackingRelCount] = 0, cellTrackingRelCount++; //------Done------
                        }
                        
                        delete [] listOfDivision;
                    }
                    
                    //for (int counterA = 0; counterA < groupInfoPreviousCount/5; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayGroupInfoPrevious [counterA*5+counterB];
                    //    cout<<" arrayGroupInfoPrevious "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingRelCount/15; counterA++){
                    //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingRel [counterA*15+counterB];
                    //    cout<<" arrayCellTrackingRel "<<counterA<<endl;
                    //}
                    
                    int doneEntryCount = 1;
                    
                    for (int counter1 = 0; counter1 < cellTrackingRelCount/15; counter1++){
                        if (arrayCellTrackingRel [counter1*15+3] != 0){
                            if (doneMitosis [doneEntryCount*2+1] != 0){
                                arrayCellTrackingRel [counter1*15+14] = doneMitosis [doneEntryCount*2+1];
                                doneEntryCount++;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < timeSelectedCurrentCount/10; counterA++){
                    //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelectedCurrent [counterA*10+counterB];
                    //	cout<<" arrayTimeSelectedCurrent "<<counterA<<endl;
                    //}
                    
                    //------Current connect, original connect no get------
                    int maxConnectNumberList = timeSelectedCurrentCount/10;
                    
                    errorNoHold = 53;
                    int **connectNoGet = new int *[maxConnectNumberList+1];
                    errorNoHold = 54;
                    int **connectNoGet2 = new int *[maxConnectNumberList+1];
                    
                    for (int counter1 = 0; counter1 < maxConnectNumberList+1; counter1++){
                        errorNoHold = 55;
                        connectNoGet [counter1] = new int [lineNumberCurrent2+1];
                        errorNoHold = 56;
                        connectNoGet2 [counter1] = new int [lineNumberCurrent2+1];
                    }
                    
                    for (int counter1 = 0; counter1 < maxConnectNumberList+1; counter1++){
                        for (int counter2 = 0; counter2 < lineNumberCurrent2+1; counter2++){
                            connectNoGet [counter1][counter2] = 0;
                            connectNoGet2 [counter1][counter2] = 0;
                        }
                    }
                    
                    for (int counterY = 0; counterY < trackAreaSize; counterY++){
                        for (int counterX = 0; counterX < trackAreaSize; counterX++){
                            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && arrayCellTrackingCurrentMap [counterY][counterX] != 0){
                                if (revisedMapCurrent [counterY+verticalStart][counterX+horizontalStart] != 0){
                                    connectNoGet [revisedMapCurrent [counterY+verticalStart][counterX+horizontalStart]][arrayCellTrackingCurrentMap [counterY][counterX]]++;
                                    connectNoGet2 [revisedMapCurrent [counterY+verticalStart][counterX+horizontalStart]][arrayCellTrackingCurrentMap [counterY][counterX]]++;
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 1; counterA < maxConnectNumberList+1; counterA++){
                    //	for (int counterB = 1; counterB < lineNumberCurrent2+1; counterB++) cout<<" "<<connectNoGet2 [counterA][counterB];
                    //	cout<<" connectNoGet2 "<<counterA<<endl;
                    //}
                    
                    errorNoHold = 57;
                    int *connectNoGetList = new int [lineNumberCurrent2*2+5];
                    for (int counter1 = 0; counter1 < lineNumberCurrent2*2+5; counter1++) connectNoGetList [counter1] = 0;
                    
                    int largestConnect = 0;
                    int largestConnectPosition = 0;
                    int secondConnect = 0;
                    int secondConnectPosition = 0;
                    
                    for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                        largestConnect = 0;
                        largestConnectPosition = 0;
                        
                        for (int counter2 = 1; counter2 < maxConnectNumberList+1; counter2++){
                            if (connectNoGet [counter2][counter1] > largestConnect){
                                largestConnect = connectNoGet [counter2][counter1];
                                largestConnectPosition = counter2;
                            }
                        }
                        
                        connectNoGet [largestConnectPosition][counter1] = 0;
                        
                        secondConnect = 0;
                        secondConnectPosition = 0;
                        
                        for (int counter2 = 1; counter2 < maxConnectNumberList+1; counter2++){
                            if (connectNoGet [counter2][counter1] > secondConnect){
                                secondConnect = connectNoGet [counter2][counter1];
                                secondConnectPosition = counter2;
                            }
                        }
                        
                        connectNoGetList [counter1*2] = largestConnectPosition;
                        connectNoGetList [counter1*2+1] = secondConnectPosition;
                    }
                    
                    for (int counter1 = 0; counter1 < maxConnectNumberList+1; counter1++) delete [] connectNoGet [counter1];
                    delete [] connectNoGet;
                    
                    //for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                    //    cout<<counter1<<" "<<connectNoGetList [counter1*2]<<" "<<connectNoGetList [counter1*2+1]<<" connectGroup"<<endl;
                    //}
                    
                    //=======Next find=======
                    errorNoHold = 58;
                    int *connectNextTargetGet = new int [maxConnectNumberList+1];
                    errorNoHold = 59;
                    int *connectNextTargetForAttach = new int [maxConnectNumberList+1];
                    errorNoHold = 60;
                    int *connectNextAttachGet = new int [maxConnectNumberList+1];
                    errorNoHold = 61;
                    int *connectNextAll = new int [maxConnectNumberList+1];
                    
                    int previousTargetArea = 0;
                    
                    for (int counter1 = 0; counter1 < maxConnectNumberList+1; counter1++){
                        connectNextTargetGet [counter1] = 0;
                        connectNextTargetForAttach [counter1] = 0;
                        connectNextAttachGet [counter1] = 0;
                        connectNextAll [counter1] = 0;
                    }
                    
                    for (int counterY = 0; counterY < trackAreaSize; counterY++){
                        for (int counterX = 0; counterX < trackAreaSize; counterX++){
                            if (arrayCellTrackingPreviousMap [counterY][counterX] == targetPointerTrack){
                                previousTargetArea++;
                                
                                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && arrayCellTrackingCurrentMap [counterY][counterX] != 0){
                                    if (revisedMapCurrent [counterY+verticalStart][counterX+horizontalStart] != 0){
                                        connectNextTargetGet [revisedMapCurrent [counterY+verticalStart][counterX+horizontalStart]]++; //-------Hold Connect No-------
                                        connectNextTargetForAttach [revisedMapCurrent [counterY+verticalStart][counterX+horizontalStart]]++; //------Hold Tracking Map connect no----
                                    }
                                }
                            }
                            
                            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && arrayCellTrackingCurrentMap [counterY][counterX] != 0){
                                if (revisedMapCurrent [counterY+verticalStart][counterX+horizontalStart] != 0){
                                    connectNextAll [revisedMapCurrent [counterY+verticalStart][counterX+horizontalStart]]++; //-------Hold Connect No-------
                                }
                            }
                        }
                    }
                    
                    //for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                    //   if (connectNextTargetGet [counter1] != 0) cout<<counter1<<" "<<connectNextTargetGet [counter1]<<" "<<" connectNextTargetGet"<<endl;
                    //}
                    
                    for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                        if (connectNextTargetGet [counter1] != 0){
                            for (int counter2 = 0; counter2 < connectLineageRelCurrentCount/6; counter2++){
                                if (arrayConnectLineageRelCurrent [counter2*6+1] == counter1){
                                    connectNextTargetGet [counter1] = 0;
                                    break;
                                }
                            }
                        }
                        
                        if (connectNextTargetGet [counter1] != 0 && connectNextTargetGet [counter1] < mitosisAreaHold && gravityCentreMoveLimitFlag == 0){
                            connectNextTargetGet [counter1] = 0;
                        }
                    }
                    
                    errorNoHold = 62;
                    int *nextTargetList = new int [lineNumberCurrent2+1];
                    
                    for (int counter1 = 0; counter1 < lineNumberCurrent2+1; counter1++){
                        nextTargetList [counter1] = 0;
                    }
                    
                    for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                        if (connectNextTargetGet [counter1] != 0){
                            for (int counter3 = 1; counter3 < lineNumberCurrent2+1; counter3++){
                                if (connectNoGet2 [counter1][counter3] != 0) nextTargetList [counter3] = connectNextTargetGet [counter1];
                            }
                        }
                    }
                    
                    //for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                    //    cout<<counter1<<" "<<nextTargetList [counter1]<<" nextTargetList"<<endl;
                    //}
                    
                    int largestNextTarget = 0;
                    int largestNextCount = 0;
                    int numberOfNextTarget = 0;
                    
                    for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                        if (nextTargetList [counter1] > largestNextTarget){
                            largestNextTarget = nextTargetList [counter1];
                            largestNextCount = counter1;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
                    //    cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
                    //}
                    
                    //cout<< largestNextTarget<<" "<<largestNextCount<<" "<<previousTargetArea<<" Area"<<endl;
                    
                    //for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                    //    cout<<counter1<<" "<<nextTargetList [counter1]<<" nextTargetList"<<endl;
                    //}
                    
                    for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                        if (nextTargetList [counter1] < largestNextTarget*0.10) nextTargetList [counter1] = 0; //========MD
                        if (nextTargetList [counter1] != 0) numberOfNextTarget++;
                    }
                    
                    //=======Next Attach check========
                    int mainOverlapConnectNo = 0;
                    int secondConnectNo = 0;
                    int mainOverlapArea = 0;
                    int firstArea = 0;
                    int secondArea = 0;
                    
                    //----------Find Main Overlap group in Current-----------
                    for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                        if (connectNextTargetForAttach [counter1] > mainOverlapArea){
                            mainOverlapArea = connectNextTargetForAttach [counter1];
                            mainOverlapConnectNo = counter1;
                        }
                    }
                    
                    //----------Find attached connect with Main Overlap group in Current, connect No in the main map--------
                    for (int counterY = 0; counterY < trackAreaSize; counterY++){
                        for (int counterX = 0; counterX < trackAreaSize; counterX++){
                            if (mainOverlapConnectNo != 0 && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && revisedMapCurrent [counterY+verticalStart][counterX+horizontalStart] == mainOverlapConnectNo){
                                firstArea++;
                                
                                if (counterY-1+verticalStart >= 0 && counterX-1+horizontalStart >= 0 && revisedMapCurrent [counterY-1+verticalStart][counterX-1+horizontalStart] != 0 && revisedMapCurrent [counterY-1+verticalStart][counterX-1+horizontalStart] != mainOverlapConnectNo){
                                    connectNextAttachGet [revisedMapCurrent [counterY-1+verticalStart][counterX-1+horizontalStart]]++;
                                }
                                if (counterY-1+verticalStart >= 0 && revisedMapCurrent [counterY-1+verticalStart][counterX+horizontalStart] != 0 && revisedMapCurrent [counterY-1+verticalStart][counterX+horizontalStart] != mainOverlapConnectNo){
                                    connectNextAttachGet [revisedMapCurrent [counterY-1+verticalStart][counterX+horizontalStart]]++;
                                }
                                if (counterY-1+verticalStart >= 0 && counterX+1+horizontalStart < imageDimension && revisedMapCurrent [counterY-1+verticalStart][counterX+1+horizontalStart] != 0 && revisedMapCurrent [counterY-1+verticalStart][counterX+1+horizontalStart] != mainOverlapConnectNo){
                                    connectNextAttachGet [revisedMapCurrent [counterY-1+verticalStart][counterX+1+horizontalStart]]++;
                                }
                                if (counterX+1+horizontalStart < imageDimension && revisedMapCurrent [counterY+verticalStart][counterX+1+horizontalStart] != 0 && revisedMapCurrent [counterY+verticalStart][counterX+1+horizontalStart] != mainOverlapConnectNo) {
                                    connectNextAttachGet [revisedMapCurrent [counterY+verticalStart][counterX+1+horizontalStart]]++;
                                }
                                if (counterY+1+verticalStart < imageDimension && counterX+1+horizontalStart < imageDimension && revisedMapCurrent [counterY+1+verticalStart][counterX+1+horizontalStart] != 0 && revisedMapCurrent [counterY+1+verticalStart][counterX+1+horizontalStart] != mainOverlapConnectNo){
                                    connectNextAttachGet [revisedMapCurrent [counterY+1+verticalStart][counterX+1+horizontalStart]]++;
                                }
                                if (counterY+1+verticalStart < imageDimension && revisedMapCurrent [counterY+1+verticalStart][counterX+horizontalStart] != 0 && revisedMapCurrent [counterY+1+verticalStart][counterX+horizontalStart] != mainOverlapConnectNo){
                                    connectNextAttachGet [revisedMapCurrent [counterY+1+verticalStart][counterX+horizontalStart]]++;
                                }
                                if (counterY+1+verticalStart < imageDimension && counterX-1+horizontalStart >= 0 && revisedMapCurrent [counterY+1+verticalStart][counterX-1+horizontalStart] != 0 && revisedMapCurrent [counterY+1+verticalStart][counterX-1+horizontalStart] != mainOverlapConnectNo){
                                    connectNextAttachGet [revisedMapCurrent [counterY+1+verticalStart][counterX-1+horizontalStart]]++;
                                }
                                if (counterX-1+horizontalStart >= 0 && revisedMapCurrent [counterY+verticalStart][counterX-1+horizontalStart] != 0 && revisedMapCurrent [counterY+verticalStart][counterX-1+horizontalStart] != mainOverlapConnectNo){
                                    connectNextAttachGet [revisedMapCurrent [counterY+verticalStart][counterX-1+horizontalStart]]++;
                                }
                            }
                        }
                    }
                    
                    //for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                    //    cout<<counter1<<" "<<connectNextAttachGet [counter1]<<" "<<" connectNextAttachGet"<<endl;
                    //}
                    
                    for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                        if (connectNextAttachGet [counter1] != 0){
                            for (int counter2 = 0; counter2 < connectLineageRelCurrentCount/6; counter2++){
                                if (arrayConnectLineageRelCurrent [counter2*6+1] == counter1){
                                    connectNextAttachGet [counter1] = 0;
                                    break;
                                }
                            }
                        }
                        
                        if (connectNextAttachGet [counter1] < 10) connectNextAttachGet [counter1] = 0;
                    }
                    
                    //for (int counterA = 0; counterA < gravityCenterRevCurrentCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRevCurrent [counterA*6+counterB];
                    //    cout<<" arrayGravityCenterRevCurrent "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                        if (connectNextAttachGet [counter1] != 0){
                            if (secondArea < arrayGravityCenterRevCurrent [(counter1-1)*6+2]){
                                secondArea = arrayGravityCenterRevCurrent [(counter1-1)*6+2];
                                secondConnectNo = counter1;
                            }
                        }
                    }
                    
                    int mitosisStatus = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (arrayCellTrackingTable [counter1*15] == roundStatus-1 && arrayCellTrackingTable [counter1*15+7] == 1){
                            mitosisStatus = arrayCellTrackingTable [counter1*15+8];
                            break;
                        }
                    }
                    
                    //--------Not overlapped second candidate check------
                    if (mitosisStatus == 5){
                        int xPositionPrevious = 0;
                        int yPositionPrevious = 0;
                        
                        for (int counter1 = 0; counter1 < xyPositionCenterPreviousCount/6; counter1++){
                            if (arrayXYPositionCenterPrevious [counter1*6+5] == 1){
                                xPositionPrevious = arrayXYPositionCenterPrevious [counter1*6];
                                yPositionPrevious = arrayXYPositionCenterPrevious [counter1*6+1];
                                break;
                            }
                        }
                        
                        errorNoHold = 63;
                        int *nextTargetListConnectNo = new int [lineNumberCurrent2+10];
                        errorNoHold = 64;
                        int *nextTargetListArea = new int [lineNumberCurrent2+10];
                        
                        for (int counter1 = 0; counter1 < lineNumberCurrent2+1; counter1++){
                            nextTargetListArea [counter1] = 0;
                            nextTargetListConnectNo [counter1] = 0;
                        }
                        
                        for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                            if (connectNextAll [counter1] != 0){
                                for (int counter3 = 1; counter3 < lineNumberCurrent2+1; counter3++){
                                    if (connectNoGet2 [counter1][counter3] != 0){
                                        nextTargetListConnectNo [counter3] = counter1;
                                        nextTargetListArea [counter3] = connectNextAll [counter1];
                                    }
                                }
                            }
                        }
                        
                        //for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                        //    cout<<counter1<<" "<<nextTargetListConnectNo [counter1]<<" "<<" nextTargetListConnectNo"<<endl;
                        //}
                        
                        int xPosition = 0;
                        int yPosition = 0;
                        int shortestConnectCount = 0;
                        double lengthFromTarget = 0;
                        double shortestConnect = 10000;
                        
                        for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                            if (nextTargetList [counter1] == 0 && nextTargetListConnectNo [counter1] != 0){
                                if (nextTargetList [largestNextCount]*(double)0.9 < nextTargetListArea [counter1] && nextTargetList [largestNextCount]*(double)1.1 > nextTargetListArea [counter1]){
                                    xPosition = arrayXYPositionCenterCurrent [(counter1-1)*6];
                                    yPosition = arrayXYPositionCenterCurrent [(counter1-1)*6+1];
                                    
                                    lengthFromTarget = (int)(sqrt((xPositionPrevious-xPosition)*(xPositionPrevious-xPosition)+(yPositionPrevious-yPosition)*(yPositionPrevious-yPosition)));
                                    
                                    if (lengthFromTarget < divisionDistanceHold){
                                        if (shortestConnect > lengthFromTarget){
                                            shortestConnect = lengthFromTarget;
                                            shortestConnectCount = counter1;
                                        }
                                    }
                                }
                            }
                        }
                        
                        if (shortestConnect != 10000){
                            nextTargetList [shortestConnectCount] = nextTargetListConnectNo [shortestConnectCount];
                            numberOfNextTarget++;
                        }
                        
                        delete [] nextTargetListConnectNo;
                    }
                    
                    //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
                    //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
                    //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
                    //    cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingCurrentCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrent [counterA*6+counterB];
                    //	cout<<" arrayCellTrackingCurrent "<<counterA<<endl;
                    //}
                    
                    //cout<<mitosisStatus<<" "<<largestNextCount<<" Next"<<endl;
                    
                    //========Div check============
                    int selectCandidatesCount = 0;
                    int remainingCount = 0;
                    
                    if (mitosisStatus == 5 && numberOfNextTarget > 1){
                        errorNoHold = 65;
                        int *refLineTemp = new int [cellTrackingCurrentCount];
                        int refLineTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < cellTrackingCurrentCount/6; counter1++){
                            if (arrayCellTrackingCurrent [counter1*6+3] == largestNextCount){
                                refLineTemp [refLineTempCount] = arrayCellTrackingCurrent [counter1*6], refLineTempCount++;
                                refLineTemp [refLineTempCount] = arrayCellTrackingCurrent [counter1*6+1], refLineTempCount++;
                                refLineTemp [refLineTempCount] = arrayCellTrackingCurrent [counter1*6+2], refLineTempCount++;
                                refLineTemp [refLineTempCount] = arrayCellTrackingCurrent [counter1*6+3], refLineTempCount++;
                                refLineTemp [refLineTempCount] = arrayCellTrackingCurrent [counter1*6+4], refLineTempCount++;
                                refLineTemp [refLineTempCount] = arrayCellTrackingCurrent [counter1*6+5], refLineTempCount++;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < refLineTempCount/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<refLineTemp [counterA*6+counterB];
                        //    cout<<" refLineTemp "<<counterA<<endl;
                        //}
                        
                        int targetLength = 0;
                        int maxPointDimX = 0;
                        int maxPointDimY = 0;
                        int minPointDimX = 1000000;
                        int minPointDimY = 1000000;
                        
                        for (int counter1 = 0; counter1 < refLineTempCount/6; counter1++){
                            if (maxPointDimX < refLineTemp [counter1*6]) maxPointDimX = refLineTemp [counter1*6];
                            if (minPointDimX > refLineTemp [counter1*6]) minPointDimX = refLineTemp [counter1*6];
                            if (maxPointDimY < refLineTemp [counter1*6+1]) maxPointDimY = refLineTemp [counter1*6+1];
                            if (minPointDimY > refLineTemp [counter1*6+1]) minPointDimY = refLineTemp [counter1*6+1];
                        }
                        
                        int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                        int verticalLength = (maxPointDimY-minPointDimY)/2*2;
                        int dimension = 0;
                        
                        if (horizontalLength >= verticalLength){
                            dimension = horizontalLength+30;
                            targetLength = maxPointDimX-minPointDimX;
                        }
                        
                        if (horizontalLength < verticalLength){
                            dimension = verticalLength+30;
                            targetLength = maxPointDimY-minPointDimY;
                        }
                        
                        dimension = (dimension/2)*2;
                        
                        int horizontalStart2 = minPointDimX-(dimension-horizontalLength)/2;
                        int verticalStart2 = minPointDimY-(dimension-verticalLength)/2;
                        
                        errorNoHold = 66;
                        int **connectivitySourceTemp = new int *[dimension+4];
                        errorNoHold = 67;
                        int **connectivityMapCut7 = new int *[dimension+4];
                        errorNoHold = 68;
                        int **connectivityMapCut6 = new int *[dimension+4];
                        errorNoHold = 69;
                        int **connectivityMapCut5 = new int *[dimension+4];
                        errorNoHold = 70;
                        int **connectivityMapCut4 = new int *[dimension+4];
                        errorNoHold = 71;
                        int **connectivityUpdate5 = new int *[dimension+4];
                        
                        for (int counter1 = 0; counter1 < dimension+4; counter1++){
                            errorNoHold = 72;
                            connectivitySourceTemp [counter1] = new int [dimension+4];
                            errorNoHold = 73;
                            connectivityMapCut7 [counter1] = new int [dimension+4];
                            errorNoHold = 74;
                            connectivityMapCut6 [counter1] = new int [dimension+4];
                            errorNoHold = 75;
                            connectivityMapCut5 [counter1] = new int [dimension+4];
                            errorNoHold = 76;
                            connectivityMapCut4 [counter1] = new int [dimension+4];
                            errorNoHold = 77;
                            connectivityUpdate5 [counter1] = new int [dimension+4];
                        }
                        
                        for (int counterY = 0; counterY < dimension+4; counterY++){
                            for (int counterX = 0; counterX < dimension+4; counterX++){
                                connectivitySourceTemp [counterY][counterX] = 0;
                                connectivityMapCut7 [counterY][counterX] = 0;
                                connectivityMapCut6 [counterY][counterX] = 0;
                                connectivityMapCut5 [counterY][counterX] = 0;
                                connectivityMapCut4 [counterY][counterX] = 0;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < refLineTempCount/6; counter1++){
                            connectivitySourceTemp [refLineTemp [counter1*6+1]-verticalStart2][refLineTemp [counter1*6]-horizontalStart2] = 1;
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivitySourceTemp [counterA][counterB];
                        //	cout<<" connectivitySourceTemp "<<counterA<<endl;
                        //}
                        
                        //------Connectivity analysis, For Zero------
                        errorNoHold = 78;
                        int *connectAnalysisX = new int [(dimension+2)*4];
                        errorNoHold = 79;
                        int *connectAnalysisY = new int [(dimension+2)*4];
                        errorNoHold = 80;
                        int *connectAnalysisTempX = new int [(dimension+2)*4];
                        errorNoHold = 81;
                        int *connectAnalysisTempY = new int [(dimension+2)*4];
                        
                        int connectivityNumber = -3;
                        int connectAnalysisCount = 0;
                        int terminationFlag = 0;
                        int connectAnalysisTempCount = 0;
                        int xSource = 0;
                        int ySource = 0;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (connectivitySourceTemp [counterY][counterX] == 0){
                                    connectivityNumber = connectivityNumber+2;
                                    connectivitySourceTemp [counterY][counterX] = connectivityNumber;
                                    
                                    connectAnalysisCount = 0;
                                    
                                    if (counterY-1 >= 0 && connectivitySourceTemp [counterY-1][counterX] == 0){
                                        connectivitySourceTemp [counterY-1][counterX] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                    }
                                    if (counterX+1 < dimension && connectivitySourceTemp [counterY][counterX+1] == 0){
                                        connectivitySourceTemp [counterY][counterX+1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    if (counterY+1 < dimension && connectivitySourceTemp [counterY+1][counterX] == 0){
                                        connectivitySourceTemp [counterY+1][counterX] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                    }
                                    if (counterX-1 >= 0 && connectivitySourceTemp [counterY][counterX-1] == 0){
                                        connectivitySourceTemp [counterY][counterX-1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    
                                    if (connectAnalysisCount != 0){
                                        do{
                                            
                                            terminationFlag = 1;
                                            connectAnalysisTempCount = 0;
                                            
                                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                                
                                                if (ySource-1 >= 0 && connectivitySourceTemp [ySource-1][xSource] == 0){
                                                    connectivitySourceTemp [ySource-1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (xSource+1 < dimension && connectivitySourceTemp [ySource][xSource+1] == 0){
                                                    connectivitySourceTemp [ySource][xSource+1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 < dimension && connectivitySourceTemp [ySource+1][xSource] == 0){
                                                    connectivitySourceTemp [ySource+1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (xSource-1 >= 0 && connectivitySourceTemp [ySource][xSource-1] == 0){
                                                    connectivitySourceTemp [ySource][xSource-1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                            }
                                            
                                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                            }
                                            
                                            connectAnalysisCount = connectAnalysisTempCount;
                                            
                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                    }
                                }
                            }
                        }
                        
                        //------Remove connectivity groups, which attach edge, extract inner part of Linked Line------
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (connectivitySourceTemp [counterY][counterX] == -1) connectivitySourceTemp [counterY][counterX] = 0;
                            }
                        }
                        
                        // for (int counterA = 0; counterA < dimension; counterA++){
                        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivitySourceTemp [counterA][counterB];
                        // 	cout<<" connectivitySourceTemp "<<counterA<<endl;
                        // }
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                                    if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] > cutOff7 && sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] != 100) connectivityMapCut7 [counterY][counterX] = sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2];
                                    else connectivityMapCut7 [counterY][counterX] = 0;
                                    
                                    if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] > cutOff6 && sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] != 100) connectivityMapCut6 [counterY][counterX] = sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2];
                                    else connectivityMapCut6 [counterY][counterX] = 0;
                                    
                                    if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] > cutOff5 && sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] != 100) connectivityMapCut5 [counterY][counterX] = sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2];
                                    else connectivityMapCut5 [counterY][counterX] = 0;
                                    
                                    if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] > cutOff4 && sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] != 100) connectivityMapCut4 [counterY][counterX] = sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2];
                                    else connectivityMapCut4 [counterY][counterX] = 0;
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut7 [counterA][counterB];
                        //	cout<<" connectivityMapCut7 "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut6 [counterA][counterB];
                        //	cout<<" connectivityMapCut6 "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut5 [counterA][counterB];
                        //	cout<<" connectivityMapCut5 "<<counterA<<endl;
                        //}
                        
                        int totalCount7 = 0;
                        int totalCount6 = 0;
                        int totalCount5 = 0;
                        int totalCount4 = 0;
                        int totalValue7 = 0;
                        int totalValue6 = 0;
                        int totalValue5 = 0;
                        int totalValue4 = 0;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (connectivitySourceTemp [counterY][counterX] == 1 && connectivityMapCut7 [counterY][counterX] != 0){
                                    totalCount7++;
                                    totalValue7 = totalValue7+connectivityMapCut7 [counterY][counterX];
                                }
                                
                                if (connectivitySourceTemp [counterY][counterX] == 1 && connectivityMapCut6 [counterY][counterX] != 0){
                                    totalCount6++;
                                    totalValue6 = totalValue6+connectivityMapCut6 [counterY][counterX];
                                }
                                
                                if (connectivitySourceTemp [counterY][counterX] == 1 && connectivityMapCut5 [counterY][counterX] != 0){
                                    totalCount5++;
                                    totalValue5 = totalValue5+connectivityMapCut5 [counterY][counterX];
                                }
                                
                                if (connectivitySourceTemp [counterY][counterX] == 1 && connectivityMapCut4 [counterY][counterX] != 0){
                                    totalCount4++;
                                    totalValue4 = totalValue4+connectivityMapCut4 [counterY][counterX];
                                }
                            }
                        }
                        
                        int targetValue = 0;
                        int targetArea = 0;
                        
                        if (totalCount7 == 0){
                            if (totalCount6 == 0){
                                if (totalCount5 == 0){
                                    targetValue = (int)(totalValue4/(double)totalCount4);
                                    targetArea = totalCount4;
                                }
                                else if (totalCount4 > totalCount5*0.8){
                                    targetValue = (int)(totalValue4/(double)totalCount4);
                                    targetArea = totalCount4;
                                }
                                else{
                                    
                                    targetValue = (int)(totalValue5/(double)totalCount5);
                                    targetArea = totalCount5;
                                }
                            }
                            else if (totalCount5 > totalCount6*0.8){
                                targetValue = (int)(totalValue5/(double)totalCount5);
                                targetArea = totalCount5;
                            }
                            else{
                                
                                targetValue = (int)(totalValue6/(double)totalCount6);
                                targetArea = totalCount6;
                            }
                        }
                        else if (totalCount6 > totalCount7*0.8){
                            targetValue = (int)(totalValue7/(double)totalCount7);
                            targetArea = totalCount7;
                        }
                        else{
                            
                            targetValue = (int)(totalValue6/(double)totalCount6);
                            targetArea = totalCount6;
                        }
                        
                        for (int counter1 = 0; counter1 < dimension+4; counter1++){
                            delete [] connectivitySourceTemp [counter1];
                            delete [] connectivityMapCut7 [counter1];
                            delete [] connectivityMapCut6 [counter1];
                            delete [] connectivityMapCut5 [counter1];
                            delete [] connectivityMapCut4 [counter1];
                            delete [] connectivityUpdate5 [counter1];
                        }
                        
                        delete [] connectivitySourceTemp;
                        delete [] connectivityMapCut7;
                        delete [] connectivityMapCut6;
                        delete [] connectivityMapCut5;
                        delete [] connectivityMapCut4;
                        delete [] connectivityUpdate5;
                        
                        delete [] connectAnalysisX;
                        delete [] connectAnalysisY;
                        delete [] connectAnalysisTempX;
                        delete [] connectAnalysisTempY;
                        
                        errorNoHold = 82;
                        int *selectCandidates = new int [lineNumberCurrent2*3+4];
                        int matchFind = 0;
                        int refValue = 0;
                        int refArea = 0;
                        int refLength = 0;
                        int otherCandidatesFind = 0;
                        
                        for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                            if (counter1 != largestNextCount && connectNoGetList [counter1*2] != 0){
                                matchFind = 0;
                                
                                for (int counter2 = 0; counter2 < connectLineageRelCurrentCount/6; counter2++){
                                    if (arrayConnectLineageRelCurrent [counter2*6+1] == connectNoGetList [counter1*2]){
                                        matchFind = 1;
                                        break;
                                    }
                                }
                                
                                if (matchFind == 0){
                                    refLineTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < cellTrackingCurrentCount/6; counter2++){
                                        if (arrayCellTrackingCurrent [counter2*6+3] == counter1){
                                            refLineTemp [refLineTempCount] = arrayCellTrackingCurrent [counter2*6], refLineTempCount++;
                                            refLineTemp [refLineTempCount] = arrayCellTrackingCurrent [counter2*6+1], refLineTempCount++;
                                            refLineTemp [refLineTempCount] = arrayCellTrackingCurrent [counter2*6+2], refLineTempCount++;
                                            refLineTemp [refLineTempCount] = arrayCellTrackingCurrent [counter2*6+3], refLineTempCount++;
                                            refLineTemp [refLineTempCount] = arrayCellTrackingCurrent [counter2*6+4], refLineTempCount++;
                                            refLineTemp [refLineTempCount] = arrayCellTrackingCurrent [counter2*6+5], refLineTempCount++;
                                        }
                                    }
                                    
                                    maxPointDimX = 0;
                                    maxPointDimY = 0;
                                    minPointDimX = 1000000;
                                    minPointDimY = 1000000;
                                    
                                    for (int counter2 = 0; counter2 < refLineTempCount/6; counter2++){
                                        if (maxPointDimX < refLineTemp [counter2*6]) maxPointDimX = refLineTemp [counter2*6];
                                        if (minPointDimX > refLineTemp [counter2*6]) minPointDimX = refLineTemp [counter2*6];
                                        if (maxPointDimY < refLineTemp [counter2*6+1]) maxPointDimY = refLineTemp [counter2*6+1];
                                        if (minPointDimY > refLineTemp [counter2*6+1]) minPointDimY = refLineTemp [counter2*6+1];
                                    }
                                    
                                    horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                                    verticalLength = (maxPointDimY-minPointDimY)/2*2;
                                    dimension = 0;
                                    
                                    if (horizontalLength >= verticalLength){
                                        dimension = horizontalLength+30;
                                        refLength = maxPointDimX-minPointDimX;
                                    }
                                    if (horizontalLength < verticalLength){
                                        dimension = verticalLength+30;
                                        refLength = maxPointDimY-minPointDimY;
                                    }
                                    
                                    dimension = (dimension/2)*2;
                                    
                                    horizontalStart2 = minPointDimX-(dimension-horizontalLength)/2;
                                    verticalStart2 = minPointDimY-(dimension-verticalLength)/2;
                                    
                                    errorNoHold = 82;
                                    connectivitySourceTemp = new int *[dimension+4];
                                    errorNoHold = 84;
                                    connectivityMapCut7 = new int *[dimension+4];
                                    errorNoHold = 85;
                                    connectivityMapCut6 = new int *[dimension+4];
                                    errorNoHold = 86;
                                    connectivityMapCut5 = new int *[dimension+4];
                                    errorNoHold = 87;
                                    connectivityMapCut4 = new int *[dimension+4];
                                    errorNoHold = 88;
                                    connectivityUpdate5 = new int *[dimension+4];
                                    
                                    for (int counter2 = 0; counter2 < dimension+4; counter2++){
                                        errorNoHold = 89;
                                        connectivitySourceTemp [counter2] = new int [dimension+4];
                                        errorNoHold = 90;
                                        connectivityMapCut7 [counter2] = new int [dimension+4];
                                        errorNoHold = 91;
                                        connectivityMapCut6 [counter2] = new int [dimension+4];
                                        errorNoHold = 92;
                                        connectivityMapCut5 [counter2] = new int [dimension+4];
                                        errorNoHold = 93;
                                        connectivityMapCut4 [counter2] = new int [dimension+4];
                                        errorNoHold = 94;
                                        connectivityUpdate5 [counter2] = new int [dimension+4];
                                    }
                                    
                                    for (int counterY = 0; counterY < dimension+4; counterY++){
                                        for (int counterX = 0; counterX < dimension+4; counterX++){
                                            connectivitySourceTemp [counterY][counterX] = 0;
                                            connectivityMapCut7 [counterY][counterX] = 0;
                                            connectivityMapCut6 [counterY][counterX] = 0;
                                            connectivityMapCut5 [counterY][counterX] = 0;
                                            connectivityMapCut4 [counterY][counterX] = 0;
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < refLineTempCount/6; counter2++){
                                        connectivitySourceTemp [refLineTemp [counter2*6+1]-verticalStart2][refLineTemp [counter2*6]-horizontalStart2] = 1;
                                    }
                                    
                                    //------Connectivity analysis, For Zero------
                                    errorNoHold = 95;
                                    connectAnalysisX = new int [(dimension+2)*4];
                                    errorNoHold = 96;
                                    connectAnalysisY = new int [(dimension+2)*4];
                                    errorNoHold = 97;
                                    connectAnalysisTempX = new int [(dimension+2)*4];
                                    errorNoHold = 98;
                                    connectAnalysisTempY = new int [(dimension+2)*4];
                                    
                                    connectivityNumber = -3;
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (connectivitySourceTemp [counterY][counterX] == 0){
                                                connectivityNumber = connectivityNumber+2;
                                                connectivitySourceTemp [counterY][counterX] = connectivityNumber;
                                                
                                                connectAnalysisCount = 0;
                                                
                                                if (counterY-1 >= 0 && connectivitySourceTemp [counterY-1][counterX] == 0){
                                                    connectivitySourceTemp [counterY-1][counterX] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                }
                                                if (counterX+1 < dimension && connectivitySourceTemp [counterY][counterX+1] == 0){
                                                    connectivitySourceTemp [counterY][counterX+1] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                }
                                                if (counterY+1 < dimension && connectivitySourceTemp [counterY+1][counterX] == 0){
                                                    connectivitySourceTemp [counterY+1][counterX] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                }
                                                if (counterX-1 >= 0 && connectivitySourceTemp [counterY][counterX-1] == 0){
                                                    connectivitySourceTemp [counterY][counterX-1] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                }
                                                
                                                if (connectAnalysisCount != 0){
                                                    do{
                                                        
                                                        terminationFlag = 1;
                                                        connectAnalysisTempCount = 0;
                                                        
                                                        for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                            xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                            
                                                            if (ySource-1 >= 0 && connectivitySourceTemp [ySource-1][xSource] == 0){
                                                                connectivitySourceTemp [ySource-1][xSource] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                            }
                                                            if (xSource+1 < dimension && connectivitySourceTemp [ySource][xSource+1] == 0){
                                                                connectivitySourceTemp [ySource][xSource+1] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                            }
                                                            if (ySource+1 < dimension && connectivitySourceTemp [ySource+1][xSource] == 0){
                                                                connectivitySourceTemp [ySource+1][xSource] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                            }
                                                            if (xSource-1 >= 0 && connectivitySourceTemp [ySource][xSource-1] == 0){
                                                                connectivitySourceTemp [ySource][xSource-1] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                            }
                                                        }
                                                        
                                                        for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                            connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                                        }
                                                        
                                                        connectAnalysisCount = connectAnalysisTempCount;
                                                        
                                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                                        
                                                    } while (terminationFlag == 1);
                                                }
                                            }
                                        }
                                    }
                                    
                                    //------Remove connectivity groups, which attach edge, extract inner part of Linked Line------
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (connectivitySourceTemp [counterY][counterX] == -1) connectivitySourceTemp [counterY][counterX] = 0;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < dimension; counterA++){
                                    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivitySourceTemp [counterA][counterB];
                                    //	cout<<"connectivitySourceTemp  "<<counterA<<endl;
                                    //}
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                                                if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] > cutOff7 && sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] != 100) connectivityMapCut7 [counterY][counterX] = sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2];
                                                else connectivityMapCut7 [counterY][counterX] = 0;
                                                
                                                if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] > cutOff6 && sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] != 100) connectivityMapCut6 [counterY][counterX] = sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2];
                                                else connectivityMapCut6 [counterY][counterX] = 0;
                                                
                                                if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] > cutOff5 && sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] != 100) connectivityMapCut5 [counterY][counterX] = sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2];
                                                else connectivityMapCut5 [counterY][counterX] = 0;
                                                
                                                if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] > cutOff4 && sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] != 100) connectivityMapCut4 [counterY][counterX] = sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2];
                                                else connectivityMapCut4 [counterY][counterX] = 0;
                                            }
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < dimension; counterA++){
                                    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut7 [counterA][counterB];
                                    //	cout<<" connectivityMapCut7 "<<counterA<<endl;
                                    //}
                                    
                                    //for (int counterA = 0; counterA < dimension; counterA++){
                                    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut6 [counterA][counterB];
                                    //	cout<<" connectivityMapCut6 "<<counterA<<endl;
                                    //}
                                    
                                    //for (int counterA = 0; counterA < dimension; counterA++){
                                    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut5 [counterA][counterB];
                                    //	cout<<" connectivityMapCut5 "<<counterA<<endl;
                                    //}
                                    
                                    totalCount7 = 0;
                                    totalCount6 = 0;
                                    totalCount5 = 0;
                                    totalCount4 = 0;
                                    totalValue7 = 0;
                                    totalValue6 = 0;
                                    totalValue5 = 0;
                                    totalValue4 = 0;
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (connectivitySourceTemp [counterY][counterX] == 1 && connectivityMapCut7 [counterY][counterX] != 0){
                                                totalCount7++;
                                                totalValue7 = totalValue7+connectivityMapCut7 [counterY][counterX];
                                            }
                                            
                                            if (connectivitySourceTemp [counterY][counterX] == 1 && connectivityMapCut6 [counterY][counterX] != 0){
                                                totalCount6++;
                                                totalValue6 = totalValue6+connectivityMapCut6 [counterY][counterX];
                                            }
                                            
                                            if (connectivitySourceTemp [counterY][counterX] == 1 && connectivityMapCut5 [counterY][counterX] != 0){
                                                totalCount5++;
                                                totalValue5 = totalValue5+connectivityMapCut5 [counterY][counterX];
                                            }
                                            
                                            if (connectivitySourceTemp [counterY][counterX] == 1 && connectivityMapCut4 [counterY][counterX] != 0){
                                                totalCount4++;
                                                totalValue4 = totalValue4+connectivityMapCut4 [counterY][counterX];
                                            }
                                        }
                                    }
                                    
                                    if (totalCount7 == 0){
                                        if (totalCount6 == 0){
                                            if (totalCount5 == 0){
                                                refValue = (int)(totalValue4/(double)totalCount4);
                                                refArea = totalCount4;
                                                
                                                for (int counterY = 0; counterY < dimension; counterY++){
                                                    for (int counterX = 0; counterX < dimension; counterX++){
                                                        connectivityMapCut6 [counterY][counterX] = connectivityMapCut4 [counterY][counterX];
                                                    }
                                                }
                                            }
                                            else if (totalCount4 > totalCount5*0.8){
                                                refValue = (int)(totalValue4/(double)totalCount4);
                                                refArea = totalCount4;
                                                
                                                for (int counterY = 0; counterY < dimension; counterY++){
                                                    for (int counterX = 0; counterX < dimension; counterX++){
                                                        connectivityMapCut6 [counterY][counterX] = connectivityMapCut4 [counterY][counterX];
                                                    }
                                                }
                                            }
                                            else{
                                                
                                                refValue = (int)(totalValue5/(double)totalCount5);
                                                refArea = totalCount5;
                                                
                                                for (int counterY = 0; counterY < dimension; counterY++){
                                                    for (int counterX = 0; counterX < dimension; counterX++){
                                                        connectivityMapCut6 [counterY][counterX] = connectivityMapCut5 [counterY][counterX];
                                                    }
                                                }
                                            }
                                        }
                                        else if (totalCount5 > totalCount6*0.8){
                                            refValue = (int)(totalValue5/(double)totalCount5);
                                            refArea = totalCount5;
                                            
                                            for (int counterY = 0; counterY < dimension; counterY++){
                                                for (int counterX = 0; counterX < dimension; counterX++){
                                                    connectivityMapCut6 [counterY][counterX] = connectivityMapCut5 [counterY][counterX];
                                                }
                                            }
                                        }
                                        else{
                                            
                                            refValue = (int)(totalValue6/(double)totalCount6);
                                            refArea = totalCount4;
                                        }
                                    }
                                    else if (totalCount6 > totalCount7*0.8){
                                        refValue = (int)(totalValue7/(double)totalCount7);
                                        refArea = totalCount7;
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                connectivityMapCut6 [counterY][counterX] = connectivityMapCut7 [counterY][counterX];
                                            }
                                        }
                                    }
                                    else{
                                        
                                        refValue = (int)(totalValue7/(double)totalCount7);
                                        refArea = totalCount7;
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                connectivityMapCut6 [counterY][counterX] = connectivityMapCut7 [counterY][counterX];
                                            }
                                        }
                                    }
                                    
                                    //cout<<refValue<<" "<<refArea<<" "<<connectNoGetList [counter1*2]<<" "<<targetArea*mitosisRelativeLowHold<<" "<<targetArea*mitosisRelativeHighHold<<" "<<targetValue-50<<" "<<targetValue+50<<" "<<targetArea<<" "<<mitosisRelativeLowHold<<" "<<mitosisRelativeHighHold<<" parameters"<<endl;
                                    
                                    if (refArea > targetArea*mitosisRelativeLowHold && refArea < targetArea*mitosisRelativeHighHold && refValue > targetValue-50 && refValue < targetValue+50){  //========MD
                                        otherCandidatesFind = 0;
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension && connectivityMapCut6 [counterY][counterX] > 0 && putativeMapStatus == 1 && putativeMap [counterY+verticalStart2][counterX+horizontalStart2] < 0){
                                                    otherCandidatesFind++;
                                                }
                                            }
                                        }
                                        
                                        selectCandidates [selectCandidatesCount] = counter1, selectCandidatesCount++;
                                        selectCandidates [selectCandidatesCount] = refLength, selectCandidatesCount++;
                                        selectCandidates [selectCandidatesCount] = otherCandidatesFind, selectCandidatesCount++;
                                    }
                                    
                                    for (int counter2 = 0; counter2 < dimension+4; counter2++){
                                        delete [] connectivitySourceTemp [counter2];
                                        delete [] connectivityMapCut7 [counter2];
                                        delete [] connectivityMapCut6 [counter2];
                                        delete [] connectivityMapCut5 [counter2];
                                        delete [] connectivityMapCut4 [counter2];
                                        delete [] connectivityUpdate5 [counter2];
                                    }
                                    
                                    delete [] connectivitySourceTemp;
                                    delete [] connectivityMapCut7;
                                    delete [] connectivityMapCut6;
                                    delete [] connectivityMapCut5;
                                    delete [] connectivityMapCut4;
                                    delete [] connectivityUpdate5;
                                    
                                    delete [] connectAnalysisX;
                                    delete [] connectAnalysisY;
                                    delete [] connectAnalysisTempX;
                                    delete [] connectAnalysisTempY;
                                }
                            }
                        }
                        
                        if (selectCandidatesCount != 0){
                            int xPositionTarget = arrayXYPositionCenterCurrent [(largestNextCount-1)*6];
                            int yPositionTarget = arrayXYPositionCenterCurrent [(largestNextCount-1)*6+1];
                            int xPosition = 0;
                            int yPosition = 0;
                            int lengthFromTarget = 0;
                            
                            for (int counter1 = 0; counter1 < selectCandidatesCount/3; counter1++){
                                if (selectCandidates [counter1*3+2] != 0) selectCandidates [counter1*3] = 0;
                            }
                            
                            for (int counter1 = 0; counter1 < selectCandidatesCount/3; counter1++){ //=======Cut off at distance======
                                if (selectCandidates [counter1*3] != 0){
                                    xPosition = arrayXYPositionCenterCurrent [(selectCandidates [counter1*3]-1)*6];
                                    yPosition = arrayXYPositionCenterCurrent [(selectCandidates [counter1*3]-1)*6+1];
                                    
                                    lengthFromTarget = (int)(sqrt((xPositionTarget-xPosition)*(xPositionTarget-xPosition)+(yPositionTarget-yPosition)*(yPositionTarget-yPosition)));
                                    
                                    if (lengthFromTarget > targetLength*3 || lengthFromTarget > divisionDistanceHold){
                                        selectCandidates [counter1*3] = 0;
                                    }
                                }
                            }
                            
                            remainingCount = 0;
                            
                            for (int counter1 = 0; counter1 < selectCandidatesCount/3; counter1++){
                                if (selectCandidates [counter1*3] != 0) remainingCount++;
                            }
                            
                            if (remainingCount == 0){
                                for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                                    if (counter1 != largestNextCount) nextTargetList [counter1] = 0;
                                }
                            }
                            else{
                                
                                for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                                    if (counter1 != largestNextCount) nextTargetList [counter1] = 0;
                                }
                                
                                for (int counter1 = 0; counter1 < selectCandidatesCount/3; counter1++){
                                    if (selectCandidates [counter1*3] != 0){
                                        nextTargetList [selectCandidates [counter1*3]] = 100;
                                    }
                                }
                            }
                        }
                        
                        delete [] refLineTemp;
                        delete [] selectCandidates;
                    }
                    
                    //cout<<mitosisStatus<<" "<<numberOfNextTarget<<" "<<selectCandidatesCount<<" "<<mainOverlapArea<<" "<<previousTargetArea*0.75<<" "<<firstArea+secondArea<<" "<<jumpAllFlag<<" EnterData"<<endl;
                    
                    int areaExpansionLevel = 0;
                    
                    if (connectExpandFlag == 1) areaExpansionLevel = firstArea;
                    else if (connectExpandFlag == 2) areaExpansionLevel = firstArea+secondArea;
                    
                    if (connectExpandFlag != 0 && ((mitosisStatus == 5 && remainingCount == 0 && mainOverlapArea != 0) || (mitosisStatus != 5 && mainOverlapArea != 0))){
                        if (numberOfNextTarget == 0 || (previousTargetArea*0.75 >= mainOverlapArea && areaExpansionLevel > mainOverlapArea)){
                            errorNoHold = 99;
                            int **arrayCellTrackingCurrentMapTemp1 = new int *[trackAreaSize+2];
                            errorNoHold = 100;
                            int **arrayCellTrackingCurrentMapTemp2 = new int *[trackAreaSize+2];
                            
                            for (int counter1 = 0; counter1 < trackAreaSize+2; counter1++){
                                errorNoHold = 101;
                                arrayCellTrackingCurrentMapTemp1 [counter1] = new int [trackAreaSize+2];
                                errorNoHold = 102;
                                arrayCellTrackingCurrentMapTemp2 [counter1] = new int [trackAreaSize+2];
                            }
                            
                            for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                    arrayCellTrackingCurrentMapTemp1 [counterY][counterX] = 0;
                                    arrayCellTrackingCurrentMapTemp2 [counterY][counterX] = 0;
                                }
                            }
                            
                            for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && ((mainOverlapConnectNo != 0 && revisedMapCurrent [counterY+verticalStart][counterX+horizontalStart] == mainOverlapConnectNo) || (secondConnectNo != 0 && revisedMapCurrent [counterY+verticalStart][counterX+horizontalStart] == secondConnectNo))){
                                        arrayCellTrackingCurrentMapTemp1 [counterY][counterX] = 2;
                                        arrayCellTrackingCurrentMapTemp2 [counterY][counterX] = 2;
                                    }
                                    
                                    if (arrayCellTrackingPreviousMap [counterY][counterX] == targetPointerTrack && arrayCellTrackingCurrentMap [counterY][counterX] != 0){
                                        arrayCellTrackingCurrentMapTemp1 [counterY][counterX] = 1;
                                        arrayCellTrackingCurrentMapTemp2 [counterY][counterX] = 1;
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                            //    for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingCurrentMapTemp1 [counterA][counterB];
                            //    cout<<" arrayCellTrackingCurrentMapTemp1 "<<counterA<<endl;
                            //}
                            
                            int expandLimit = 0;
                            
                            if (previousTargetArea <= areaExpansionLevel*0.5) expandLimit = (int)(areaExpansionLevel*0.5);
                            else expandLimit = previousTargetArea*2;
                            
                            int findFreePoint = 0;
                            int findFreePointAccumulation = 0;
                            int terminationFlag = 0;
                            
                            do{
                                
                                findFreePoint = 0;
                                
                                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                        if (arrayCellTrackingCurrentMapTemp1 [counterY][counterX] == 1){
                                            
                                            if (counterY-1 >= 0 && counterX-1 >= 0 && arrayCellTrackingCurrentMapTemp2 [counterY-1][counterX-1] == 2){
                                                findFreePoint++;
                                                arrayCellTrackingCurrentMapTemp2 [counterY-1][counterX-1] = 1;
                                            }
                                            if (counterY-1 >= 0 && arrayCellTrackingCurrentMapTemp2 [counterY-1][counterX] == 2){
                                                findFreePoint = 1;
                                                arrayCellTrackingCurrentMapTemp2 [counterY-1][counterX] = 1;
                                            }
                                            if (counterY-1 >= 0 && counterX+1 < trackAreaSize && arrayCellTrackingCurrentMapTemp2 [counterY-1][counterX+1] == 2){
                                                findFreePoint++;
                                                arrayCellTrackingCurrentMapTemp2 [counterY-1][counterX+1] = 1;
                                            }
                                            if (counterX+1 < trackAreaSize && arrayCellTrackingCurrentMapTemp2 [counterY][counterX+1] == 2){
                                                findFreePoint++;
                                                arrayCellTrackingCurrentMapTemp2 [counterY][counterX+1] = 1;
                                            }
                                            if (counterY+1 < trackAreaSize && counterX+1 < trackAreaSize && arrayCellTrackingCurrentMapTemp2 [counterY+1][counterX+1] == 2){
                                                findFreePoint++;
                                                arrayCellTrackingCurrentMapTemp2 [counterY+1][counterX+1] = 1;
                                            }
                                            if (counterY+1 < trackAreaSize && arrayCellTrackingCurrentMapTemp2 [counterY+1][counterX] == 2){
                                                findFreePoint++;
                                                arrayCellTrackingCurrentMapTemp2 [counterY+1][counterX] = 1;
                                            }
                                            if (counterY+1 < trackAreaSize && counterX-1 >= 0 && arrayCellTrackingCurrentMapTemp2 [counterY+1][counterX-1] == 2){
                                                findFreePoint++;
                                                arrayCellTrackingCurrentMapTemp2 [counterY+1][counterX-1] = 1;
                                            }
                                            if (counterX-1 >= 0 && arrayCellTrackingCurrentMapTemp2 [counterY][counterX-1] == 2){
                                                findFreePoint++;
                                                arrayCellTrackingCurrentMapTemp2 [counterY][counterX-1] = 1;
                                            }
                                        }
                                    }
                                }
                                
                                findFreePointAccumulation = findFreePointAccumulation+findFreePoint;
                                
                                if (findFreePoint == 0 || expandLimit < findFreePointAccumulation) terminationFlag = 1;
                                else{
                                    
                                    for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                        for (int counterX = 0; counterX < trackAreaSize; counterX++) arrayCellTrackingCurrentMapTemp1 [counterY][counterX] = arrayCellTrackingCurrentMapTemp2 [counterY][counterX];
                                    }
                                }
                                
                            } while (terminationFlag == 0);
                            
                            //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                            //    for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingCurrentMapTemp1 [counterA][counterB];
                            //    cout<<" arrayCellTrackingCurrentMapTemp1 "<<counterA<<endl;
                            //}
                            
                            for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                    if (arrayCellTrackingCurrentMapTemp1 [counterY][counterX] == 2) arrayCellTrackingCurrentMapTemp1 [counterY][counterX] = 0;
                                }
                            }
                            
                            //-------Zero Fill-------
                            errorNoHold = 103;
                            int *connectAnalysisX = new int [trackAreaSize*4];
                            errorNoHold = 104;
                            int *connectAnalysisY = new int [trackAreaSize*4];
                            errorNoHold = 105;
                            int *connectAnalysisTempX = new int [trackAreaSize*4];
                            errorNoHold = 106;
                            int *connectAnalysisTempY = new int [trackAreaSize*4];
                            
                            errorNoHold = 107;
                            int **connectivityUpdate5 = new int *[trackAreaSize+4];
                            
                            for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++){
                                errorNoHold = 108;
                                connectivityUpdate5 [counter1] = new int [trackAreaSize+4];
                            }
                            
                            for (int counterX = 0; counterX < trackAreaSize+4; counterX++){
                                for (int counterY = 0; counterY < trackAreaSize+4; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
                            }
                            
                            for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                for (int counterX = 0; counterX < trackAreaSize; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = arrayCellTrackingCurrentMapTemp1 [counterY][counterX];
                            }
                            
                            int connectivityNumber = 0;
                            int connectAnalysisCount = 0;
                            int connectAnalysisTempCount = 0;
                            int xSource = 0;
                            int ySource = 0;
                            
                            for (int counterY2 = 0; counterY2 < trackAreaSize+2; counterY2++){
                                for (int counterX2 = 0; counterX2 < trackAreaSize+2; counterX2++){
                                    if (connectivityUpdate5 [counterY2][counterX2] == 0){
                                        connectivityNumber--;
                                        connectAnalysisCount = 0;
                                        
                                        connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                                        
                                        if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                                            connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                        }
                                        if (counterX2+1 < trackAreaSize+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                            connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                        }
                                        if (counterY2+1 < trackAreaSize+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                            connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                        }
                                        if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                            connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                        }
                                        
                                        if (connectAnalysisCount != 0){
                                            do{
                                                
                                                terminationFlag = 1;
                                                connectAnalysisTempCount = 0;
                                                
                                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                                    
                                                    if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                                        connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                    }
                                                    if (xSource+1 < trackAreaSize+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                                        connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                    }
                                                    if (ySource+1 < trackAreaSize+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                                        connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                    }
                                                    if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                                        connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                    }
                                                }
                                                
                                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                                }
                                                
                                                connectAnalysisCount = connectAnalysisTempCount;
                                                
                                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                                
                                            } while (terminationFlag == 1);
                                        }
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < trackAreaSize+2; counterA++){
                            //	for (int counterB = 0; counterB < trackAreaSize+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                            //	cout<<" connectivityUpdate5 "<<counterA<<endl;
                            //}
                            
                            int connectTemp2 = 0;
                            
                            if (connectivityNumber < -1){
                                errorNoHold = 109;
                                int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                                
                                for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
                                
                                for (int counterY2 = 0; counterY2 < trackAreaSize+2; counterY2++){
                                    for (int counterX2 = 0; counterX2 < trackAreaSize+2; counterX2++){
                                        connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                                        
                                        if (connectTemp2 < -1){
                                            connectTemp2 = connectTemp2*-1;
                                            
                                            if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                            }
                                            if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                            }
                                            if (counterY2-1 >= 0 && counterX2+1 < trackAreaSize+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                            }
                                            if (counterX2+1 < trackAreaSize+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                            }
                                            if (counterY2+1 < trackAreaSize+2 && counterX2+1 < trackAreaSize+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                            }
                                            if (counterY2+1 < trackAreaSize+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                            }
                                            if (counterY2+1 < trackAreaSize+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                            }
                                            if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                            }
                                        }
                                    }
                                }
                                
                                int zeroFillFlag = 0;
                                
                                for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                                    if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
                                }
                                
                                if (zeroFillFlag == 1){
                                    for (int counterY2 = 0; counterY2 < trackAreaSize+2; counterY2++){
                                        for (int counterX2 = 0; counterX2 < trackAreaSize+2; counterX2++){
                                            connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                                            
                                            if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                                        }
                                    }
                                    
                                    for (int counterY2 = 0; counterY2 < trackAreaSize+2; counterY2++){
                                        for (int counterX2 = 0; counterX2 < trackAreaSize+2; counterX2++){
                                            if (connectivityUpdate5 [counterY2][counterX2] > 0) arrayCellTrackingCurrentMapTemp1 [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                                        }
                                    }
                                }
                                
                                delete [] connectCheckArray;
                            }
                            
                            for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++) delete [] connectivityUpdate5 [counter1];
                            
                            delete [] connectivityUpdate5;
                            
                            //------Connectivity analysis, For Zero------
                            for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                    if (arrayCellTrackingCurrentMapTemp1 [counterY][counterX] != 0){
                                        if (counterX+1 < trackAreaSize && arrayCellTrackingCurrentMapTemp1 [counterY][counterX+1] == 0) arrayCellTrackingCurrentMapTemp1 [counterY][counterX] = -1;
                                        else if (counterY+1 < trackAreaSize && arrayCellTrackingCurrentMapTemp1 [counterY+1][counterX] == 0) arrayCellTrackingCurrentMapTemp1 [counterY][counterX] = -1;
                                        else if (counterX-1 >= 0 && arrayCellTrackingCurrentMapTemp1 [counterY][counterX-1] == 0) arrayCellTrackingCurrentMapTemp1 [counterY][counterX] = -1;
                                        else if (counterY-1 >= 0 && arrayCellTrackingCurrentMapTemp1 [counterY-1][counterX] == 0) arrayCellTrackingCurrentMapTemp1 [counterY][counterX] = -1;
                                    }
                                }
                            }
                            
                            for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                    if (arrayCellTrackingCurrentMapTemp1 [counterY][counterX] > 0) arrayCellTrackingCurrentMapTemp1 [counterY][counterX] = 0;
                                    if (arrayCellTrackingCurrentMapTemp1 [counterY][counterX] < 0) arrayCellTrackingCurrentMapTemp1 [counterY][counterX] = 1;
                                }
                            }
                            
                            connectivityNumber = 0;
                            
                            for (int counterY2 = 0; counterY2 < trackAreaSize; counterY2++){
                                for (int counterX2 = 0; counterX2 < trackAreaSize; counterX2++){
                                    if (arrayCellTrackingCurrentMapTemp1 [counterY2][counterX2] == 0){
                                        connectivityNumber--;
                                        connectAnalysisCount = 0;
                                        
                                        arrayCellTrackingCurrentMapTemp1 [counterY2][counterX2] = connectivityNumber;
                                        
                                        if (counterY2-1 >= 0 && arrayCellTrackingCurrentMapTemp1 [counterY2-1][counterX2] == 0){
                                            arrayCellTrackingCurrentMapTemp1 [counterY2-1][counterX2] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                        }
                                        if (counterX2+1 < trackAreaSize && arrayCellTrackingCurrentMapTemp1 [counterY2][counterX2+1] == 0){
                                            arrayCellTrackingCurrentMapTemp1 [counterY2][counterX2+1] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                        }
                                        if (counterY2+1 < trackAreaSize && arrayCellTrackingCurrentMapTemp1 [counterY2+1][counterX2] == 0){
                                            arrayCellTrackingCurrentMapTemp1 [counterY2+1][counterX2] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                        }
                                        if (counterX2-1 >= 0 && arrayCellTrackingCurrentMapTemp1 [counterY2][counterX2-1] == 0){
                                            arrayCellTrackingCurrentMapTemp1 [counterY2][counterX2-1] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                        }
                                        
                                        if (connectAnalysisCount != 0){
                                            do{
                                                
                                                terminationFlag = 1;
                                                connectAnalysisTempCount = 0;
                                                
                                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                                    
                                                    if (ySource-1 >= 0 && arrayCellTrackingCurrentMapTemp1 [ySource-1][xSource] == 0){
                                                        arrayCellTrackingCurrentMapTemp1 [ySource-1][xSource] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                    }
                                                    if (xSource+1 < trackAreaSize && arrayCellTrackingCurrentMapTemp1 [ySource][xSource+1] == 0){
                                                        arrayCellTrackingCurrentMapTemp1 [ySource][xSource+1] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                    }
                                                    if (ySource+1 < trackAreaSize && arrayCellTrackingCurrentMapTemp1 [ySource+1][xSource] == 0){
                                                        arrayCellTrackingCurrentMapTemp1 [ySource+1][xSource] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                    }
                                                    if (xSource-1 >= 0 && arrayCellTrackingCurrentMapTemp1 [ySource][xSource-1] == 0){
                                                        arrayCellTrackingCurrentMapTemp1 [ySource][xSource-1] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                    }
                                                }
                                                
                                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                                }
                                                
                                                connectAnalysisCount = connectAnalysisTempCount;
                                                
                                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                                
                                            } while (terminationFlag == 1);
                                        }
                                    }
                                }
                            }
                            
                            delete [] connectAnalysisX;
                            delete [] connectAnalysisY;
                            delete [] connectAnalysisTempX;
                            delete [] connectAnalysisTempY;
                            
                            //------Determine number of pixels------
                            connectivityNumber = connectivityNumber*-1;
                            
                            errorNoHold = 110;
                            connectedPixels = new int [connectivityNumber+50];
                            
                            for (int counter1 = 0; counter1 <= connectivityNumber; counter1++) connectedPixels [counter1] = 0;
                            
                            for (int counterY2 = 0; counterY2 < trackAreaSize; counterY2++){
                                for (int counterX2 = 0; counterX2 < trackAreaSize; counterX2++){
                                    if (arrayCellTrackingCurrentMapTemp1 [counterY2][counterX2] < -1){
                                        connectedPixels [arrayCellTrackingCurrentMapTemp1 [counterY2][counterX2]*-1]++;
                                    }
                                }
                            }
                            
                            errorNoHold = 111;
                            int **newConnectivityMapTemp = new int *[trackAreaSize+4];
                            
                            for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++){
                                errorNoHold = 112;
                                newConnectivityMapTemp [counter1] = new int [trackAreaSize+4];
                            }
                            
                            for (int counterY = 0; counterY < trackAreaSize+4; counterY++){
                                for (int counterX = 0; counterX < trackAreaSize+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
                            }
                            
                            largestConnect = 0;
                            int largestConnectNo = 0;
                            
                            for (int counter1 = 2; counter1 <= connectivityNumber; counter1++){
                                if (connectedPixels [counter1] > largestConnect){
                                    largestConnect = connectedPixels [counter1];
                                    largestConnectNo = counter1;
                                }
                            }
                            
                            for (int counterY2 = 0; counterY2 < trackAreaSize; counterY2++){
                                for (int counterX2 = 0; counterX2 < trackAreaSize; counterX2++){
                                    if (arrayCellTrackingCurrentMapTemp1 [counterY2][counterX2] == largestConnectNo*-1){
                                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && arrayCellTrackingCurrentMapTemp1 [counterY2-1][counterX2-1] == 1){
                                            newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                                            arrayCellTrackingCurrentMapTemp1 [counterY2-1][counterX2-1] = 0;
                                        }
                                        if (counterY2-1 >= 0 && arrayCellTrackingCurrentMapTemp1 [counterY2-1][counterX2] == 1){
                                            newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                                            arrayCellTrackingCurrentMapTemp1 [counterY2-1][counterX2] = 0;
                                        }
                                        if (counterY2-1 >= 0 && counterX2+1 < trackAreaSize && arrayCellTrackingCurrentMapTemp1 [counterY2-1][counterX2+1] == 1){
                                            newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                                            arrayCellTrackingCurrentMapTemp1 [counterY2-1][counterX2+1] = 0;
                                        }
                                        if (counterX2+1 < trackAreaSize && arrayCellTrackingCurrentMapTemp1 [counterY2][counterX2+1] == 1){
                                            newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                                            arrayCellTrackingCurrentMapTemp1 [counterY2][counterX2+1] = 0;
                                        }
                                        if (counterY2+1 < trackAreaSize && counterX2+1 < trackAreaSize && arrayCellTrackingCurrentMapTemp1 [counterY2+1][counterX2+1] == 1){
                                            newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                                            arrayCellTrackingCurrentMapTemp1 [counterY2+1][counterX2+1] = 0;
                                        }
                                        if (counterY2+1 < trackAreaSize && arrayCellTrackingCurrentMapTemp1 [counterY2+1][counterX2] == 1){
                                            newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                                            arrayCellTrackingCurrentMapTemp1 [counterY2+1][counterX2] = 0;
                                        }
                                        if (counterY2+1 < trackAreaSize && counterX2-1 >= 0 && arrayCellTrackingCurrentMapTemp1 [counterY2+1][counterX2-1] == 1){
                                            newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                                            arrayCellTrackingCurrentMapTemp1 [counterY2+1][counterX2-1] = 0;
                                        }
                                        if (counterX2-1 >= 0 && arrayCellTrackingCurrentMapTemp1 [counterY2][counterX2-1] == 1){
                                            newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                                            arrayCellTrackingCurrentMapTemp1 [counterY2][counterX2-1] = 0;
                                        }
                                    }
                                }
                            }
                            
                            delete [] connectedPixels;
                            
                            int xPositionTempStart = 0;
                            int yPositionTempStart = 0;
                            int lineSize = 0;
                            
                            for (int counterY2 = 0; counterY2 < trackAreaSize; counterY2++){
                                for (int counterX2 = 0; counterX2 < trackAreaSize; counterX2++){
                                    if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                                        arrayCellTrackingCurrentMapTemp1 [counterY2][counterX2] = 1;
                                        
                                        xPositionTempStart = counterX2;
                                        yPositionTempStart = counterY2;
                                        lineSize++;
                                    }
                                    else arrayCellTrackingCurrentMapTemp1 [counterY2][counterX2] = 0;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++) delete [] newConnectivityMapTemp [counter1];
                            delete [] newConnectivityMapTemp;
                            
                            int constructedLineCount = 0;
                            int findFlag = 0;
                            
                            errorNoHold = 113;
                            int *arrayNewLines = new int [lineSize*2+50];
                            
                            arrayCellTrackingCurrentMapTemp1 [yPositionTempStart][xPositionTempStart] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                            
                            do{
                                
                                findFlag = 0;
                                terminationFlag = 0;
                                
                                if (xPositionTempStart+1 < trackAreaSize){
                                    if (arrayCellTrackingCurrentMapTemp1 [yPositionTempStart][xPositionTempStart+1] == 1){
                                        arrayCellTrackingCurrentMapTemp1 [yPositionTempStart][xPositionTempStart+1] = -1;
                                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                                        xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                    }
                                }
                                if (xPositionTempStart+1 < trackAreaSize && yPositionTempStart+1 < trackAreaSize && findFlag == 0){
                                    if (arrayCellTrackingCurrentMapTemp1 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                                        arrayCellTrackingCurrentMapTemp1 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                    }
                                }
                                if (yPositionTempStart+1 < trackAreaSize && findFlag == 0){
                                    if (arrayCellTrackingCurrentMapTemp1 [yPositionTempStart+1][xPositionTempStart] == 1){
                                        arrayCellTrackingCurrentMapTemp1 [yPositionTempStart+1][xPositionTempStart] = -1;
                                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                                        yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                    }
                                }
                                if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < trackAreaSize && findFlag == 0){
                                    if (arrayCellTrackingCurrentMapTemp1 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                                        arrayCellTrackingCurrentMapTemp1 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                    }
                                }
                                if (xPositionTempStart-1 >= 0 && findFlag == 0){
                                    if (arrayCellTrackingCurrentMapTemp1 [yPositionTempStart][xPositionTempStart-1] == 1){
                                        arrayCellTrackingCurrentMapTemp1 [yPositionTempStart][xPositionTempStart-1] = -1;
                                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                                        xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                    }
                                }
                                if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                                    if (arrayCellTrackingCurrentMapTemp1 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                                        arrayCellTrackingCurrentMapTemp1 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                    }
                                }
                                if (yPositionTempStart-1 >= 0 && findFlag == 0){
                                    if (arrayCellTrackingCurrentMapTemp1 [yPositionTempStart-1][xPositionTempStart] == 1){
                                        arrayCellTrackingCurrentMapTemp1 [yPositionTempStart-1][xPositionTempStart] = -1;
                                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                                        yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                    }
                                }
                                if (xPositionTempStart+1 < trackAreaSize && yPositionTempStart-1 >= 0 && findFlag == 0){
                                    if (arrayCellTrackingCurrentMapTemp1 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                                        arrayCellTrackingCurrentMapTemp1 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                                    }
                                }
                                
                            } while (terminationFlag == 1);
                            
                            for (int counter1 = 0; counter1 < maxConnectNumberList+1; counter1++){
                                connectNextTargetGet [counter1] = 0;
                            }
                            
                            for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                    if (arrayCellTrackingPreviousMap [counterY][counterX] == targetPointerTrack){
                                        if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && arrayCellTrackingCurrentMapTemp1 [counterY][counterX] != 0){
                                            if (revisedMapCurrent [counterY+verticalStart][counterX+horizontalStart] != 0){
                                                connectNextTargetGet [revisedMapCurrent [counterY+verticalStart][counterX+horizontalStart]]++; //-------Hold Connect No-------
                                            }
                                        }
                                    }
                                }
                            }
                            
                            //for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                            //    if (connectNextTargetGet [counter1] != 0) cout<<counter1<<" "<<connectNextTargetGet [counter1]<<" "<<" connectNextTargetGet"<<endl;
                            //}
                            
                            for (int counter1 = 0; counter1 < lineNumberCurrent2+1; counter1++){
                                nextTargetList [counter1] = 0;
                            }
                            
                            for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                                if (connectNextTargetGet [counter1] != 0){
                                    for (int counter3 = 1; counter3 < lineNumberCurrent2+1; counter3++){
                                        if (connectNoGet2 [counter1][counter3] != 0) nextTargetList [counter3] = connectNextTargetGet [counter1];
                                    }
                                }
                            }
                            
                            largestNextTarget = 0;
                            largestNextCount = 0;
                            
                            for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                                if (nextTargetList [counter1] > largestNextTarget){
                                    largestNextTarget = nextTargetList [counter1];
                                    largestNextCount = counter1;
                                }
                            }
                            
                            for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                                if (counter1 != largestNextCount){
                                    nextTargetList [counter1] = 0;
                                }
                            }
                            
                            errorNoHold = 114;
                            int *arrayCellTrackingCurrentTemp = new int [cellTrackingCurrentCount+constructedLineCount*3+50];
                            int  cellTrackingCurrentTempCount = 0;
                            
                            //for (int counterA = 0; counterA < cellTrackingCurrentCount/6; counterA++){
                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrent [counterA*6+counterB];
                            //    cout<<" arrayCellTrackingCurrent "<<counterA<<endl;
                            //}
                            
                            for (int counter2 = 0; counter2 < cellTrackingCurrentCount/6; counter2++){
                                if (arrayCellTrackingCurrent [counter2*6+3] != largestNextCount){
                                    arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter2*6], cellTrackingCurrentTempCount++;
                                    arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter2*6+1], cellTrackingCurrentTempCount++;
                                    arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter2*6+2], cellTrackingCurrentTempCount++;
                                    arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter2*6+3], cellTrackingCurrentTempCount++;
                                    arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter2*6+4], cellTrackingCurrentTempCount++;
                                    arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter2*6+5], cellTrackingCurrentTempCount++;
                                }
                            }
                            
                            for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayNewLines [counter2*2], cellTrackingCurrentTempCount++;
                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayNewLines [counter2*2+1], cellTrackingCurrentTempCount++;
                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 0, cellTrackingCurrentTempCount++;
                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = largestNextCount, cellTrackingCurrentTempCount++;
                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 0, cellTrackingCurrentTempCount++;
                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 0, cellTrackingCurrentTempCount++;
                            }
                            
                            if (cellTrackingCurrentStatus == 0){
                                errorNoHold = 115;
                                arrayCellTrackingCurrent = new int [cellTrackingCurrentTempCount*3+50];
                                cellTrackingCurrentCount = 0;
                                cellTrackingCurrentStatus = 1;
                                cellTrackingCurrentSizeHold = cellTrackingCurrentTempCount*3+50;
                            }
                            else if (cellTrackingCurrentStatus == 1 && cellTrackingCurrentSizeHold < cellTrackingCurrentTempCount){
                                delete [] arrayCellTrackingCurrent;
                                
                                errorNoHold = 116;
                                arrayCellTrackingCurrent = new int [cellTrackingCurrentTempCount*3+50];
                                cellTrackingCurrentCount = 0;
                                cellTrackingCurrentSizeHold = cellTrackingCurrentTempCount*3+50;
                            }
                            else cellTrackingCurrentCount = 0;
                            
                            for (int counter2 = 0; counter2 < cellTrackingCurrentTempCount; counter2++) arrayCellTrackingCurrent [cellTrackingCurrentCount] = arrayCellTrackingCurrentTemp [counter2], cellTrackingCurrentCount++;
                            
                            delete [] arrayCellTrackingCurrentTemp;
                            delete [] arrayNewLines;
                            delete [] arrayCellTrackingCurrentMapTemp1;
                            delete [] arrayCellTrackingCurrentMapTemp2;
                        }
                        else{
                            
                            for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                                if (counter1 != largestNextCount) nextTargetList [counter1] = 0;
                            }
                        }
                    }
                    else if (mainOverlapArea == 0 && jumpAllFlag == 1){
                        int xPositionPrevious = 0;
                        int yPositionPrevious = 0;
                        
                        for (int counter1 = 0; counter1 < xyPositionCenterPreviousCount/6; counter1++){
                            if (arrayXYPositionCenterPrevious [counter1*6+5] == 1){
                                xPositionPrevious = arrayXYPositionCenterPrevious [counter1*6];
                                yPositionPrevious = arrayXYPositionCenterPrevious [counter1*6+1];
                                break;
                            }
                        }
                        
                        if (xPositionPrevious != 0 && yPositionPrevious != 0){
                            for (int counter1 = 0; counter1 < maxConnectNumberList+1; counter1++){
                                connectNextTargetGet [counter1] = 0;
                            }
                            
                            for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && arrayCellTrackingCurrentMap [counterY][counterX] != 0){
                                        if (revisedMapCurrent [counterY+verticalStart][counterX+horizontalStart] != 0){
                                            connectNextTargetGet [revisedMapCurrent [counterY+verticalStart][counterX+horizontalStart]]++; //-------Hold Connect No: area-------
                                        }
                                    }
                                }
                            }
                            
                            errorNoHold = 117;
                            int *nextTargetListConnectNo = new int [lineNumberCurrent2+10];
                            
                            for (int counter1 = 0; counter1 < lineNumberCurrent2+1; counter1++){
                                nextTargetList [counter1] = 0;
                                nextTargetListConnectNo [counter1] = 0;
                            }
                            
                            for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                                if (connectNextTargetGet [counter1] != 0){
                                    for (int counter3 = 1; counter3 < lineNumberCurrent2+1; counter3++){
                                        if (connectNoGet2 [counter1][counter3] != 0){
                                            nextTargetListConnectNo [counter3] = counter1;
                                        }
                                    }
                                }
                            }
                            
                            for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                                if (connectNextTargetGet [counter1] != 0){
                                    for (int counter2 = 0; counter2 < connectLineageRelCurrentCount/6; counter2++){
                                        if (arrayConnectLineageRelCurrent [counter2*6+1] == counter1){
                                            connectNextTargetGet [counter1] = 0;
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                                if (connectNextTargetGet [counter1] != 0){
                                    for (int counter3 = 1; counter3 < lineNumberCurrent2+1; counter3++){
                                        if (connectNoGet2 [counter1][counter3] != 0){
                                            nextTargetList [counter3] = connectNextTargetGet [counter1];
                                        }
                                    }
                                }
                            }
                            
                            int cellNoInt = atoi(cellLineageNoHold.substr(1).c_str());
                            int lingNoInt = atoi(cellNoHold.substr(1).c_str());
                            int distanceLimit = 0;
                            int totalDistanceCount = 0;
                            double totalDistance = 0;
                            double lengthFromTarget = 0;
                            
                            for (int counter1 = lineageDataCount/8-1; counter1 >= 0; counter1--){
                                if (arrayLineageData [counter1*8+5] == cellNoInt && arrayLineageData [counter1*8+5] == lingNoInt && counter1-1 >= 0 && arrayLineageData [(counter1-1)*8+5] == cellNoInt && arrayLineageData [(counter1-1)*8+5]){
                                    lengthFromTarget = (int)(sqrt((arrayLineageData [counter1*8]-arrayLineageData [(counter1-1)*8])*(arrayLineageData [counter1*8]-arrayLineageData [(counter1-1)*8])+(arrayLineageData [counter1*8+1]-arrayLineageData [(counter1-1)*8+1])*(arrayLineageData [counter1*8+1]-arrayLineageData [(counter1-1)*8+1])));
                                    totalDistance = totalDistance+lengthFromTarget;
                                    totalDistanceCount++;
                                }
                            }
                            
                            if (totalDistanceCount >= 10){
                                distanceLimit = (int)((totalDistance/(double)totalDistanceCount)*1.5);
                                
                                if (distanceLimit > divisionDistanceHold*2) distanceLimit = divisionDistanceHold;
                            }
                            else distanceLimit = divisionDistanceHold; //*****Distance check DIV distance x 2, if this parameter is not suitable, make a separate parameter****
                            
                            int xPosition = 0;
                            int yPosition = 0;
                            
                            errorNoHold = 118;
                            double *listLength = new double [lineNumberCurrent2+10];
                            
                            for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++) listLength [counter1] = 0;
                            
                            for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                                if (nextTargetList [counter1] != 0){
                                    xPosition = arrayXYPositionCenterCurrent [(counter1-1)*6];
                                    yPosition = arrayXYPositionCenterCurrent [(counter1-1)*6+1];
                                    
                                    lengthFromTarget = (int)(sqrt((xPositionPrevious-xPosition)*(xPositionPrevious-xPosition)+(yPositionPrevious-yPosition)*(yPositionPrevious-yPosition)));
                                    listLength [counter1] = lengthFromTarget;
                                    
                                    if (lengthFromTarget > distanceLimit){
                                        nextTargetList [counter1] = 0;
                                        listLength [counter1] = 0;
                                    }
                                }
                            }
                            
                            int remainingCount2 = 0;
                            
                            for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                                if (nextTargetList [counter1] != 0) remainingCount2++;
                            }
                            
                            if (remainingCount2 >= 1){
                                errorNoHold = 119;
                                int *attachConnectNo = new int [10];
                                int attachFindFlag = 0;
                                
                                //--------Check whether candidates attaches with no assigned connect--------
                                for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                                    if (nextTargetListConnectNo [counter1] != 0){
                                        attachFindFlag = 0;
                                        
                                        for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                            for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && revisedMapCurrent [counterY+verticalStart][counterX+horizontalStart] == nextTargetListConnectNo [counter1]){
                                                    for (int counter2 = 0; counter2 < 8; counter2++) attachConnectNo [counter2] = 0;
                                                    
                                                    if (counterY-1+verticalStart >= 0 && counterX-1+horizontalStart >= 0 && revisedMapCurrent [counterY-1+verticalStart][counterX-1+horizontalStart] != 0 && revisedMapCurrent [counterY-1+verticalStart][counterX-1+horizontalStart] != nextTargetListConnectNo [counter1]){
                                                        attachConnectNo [0] = revisedMapCurrent [counterY-1+verticalStart][counterX-1+horizontalStart];
                                                    }
                                                    if (counterY-1+verticalStart >= 0 && revisedMapCurrent [counterY-1+verticalStart][counterX+horizontalStart] != 0 && revisedMapCurrent [counterY-1+verticalStart][counterX+horizontalStart] != nextTargetListConnectNo [counter1]){
                                                        attachConnectNo [1] = revisedMapCurrent [counterY-1+verticalStart][counterX+horizontalStart];
                                                    }
                                                    if (counterY-1+verticalStart >= 0 && counterX+1+horizontalStart < imageDimension && revisedMapCurrent [counterY-1+verticalStart][counterX+1+horizontalStart] != 0 && revisedMapCurrent [counterY-1+verticalStart][counterX+1+horizontalStart] != nextTargetListConnectNo [counter1]){
                                                        attachConnectNo [2] = revisedMapCurrent [counterY-1+verticalStart][counterX+1+horizontalStart];
                                                    }
                                                    if (counterX+1+horizontalStart < imageDimension && revisedMapCurrent [counterY+verticalStart][counterX+1+horizontalStart] != 0 && revisedMapCurrent [counterY+verticalStart][counterX+1+horizontalStart] != nextTargetListConnectNo [counter1]) {
                                                        attachConnectNo [3] = revisedMapCurrent [counterY+verticalStart][counterX+1+horizontalStart];
                                                    }
                                                    if (counterY+1+verticalStart < imageDimension && counterX+1+horizontalStart < imageDimension && revisedMapCurrent [counterY+1+verticalStart][counterX+1+horizontalStart] != 0 && revisedMapCurrent [counterY+1+verticalStart][counterX+1+horizontalStart] != nextTargetListConnectNo [counter1]){
                                                        attachConnectNo [4] = revisedMapCurrent [counterY+1+verticalStart][counterX+1+horizontalStart];
                                                    }
                                                    if (counterY+1+verticalStart < imageDimension && revisedMapCurrent [counterY+1+verticalStart][counterX+horizontalStart] != 0 && revisedMapCurrent [counterY+1+verticalStart][counterX+horizontalStart] != nextTargetListConnectNo [counter1]){
                                                        attachConnectNo [5] = revisedMapCurrent [counterY+1+verticalStart][counterX+horizontalStart];
                                                    }
                                                    if (counterY+1+verticalStart < imageDimension && counterX-1+horizontalStart >= 0 && revisedMapCurrent [counterY+1+verticalStart][counterX-1+horizontalStart] != 0 && revisedMapCurrent [counterY+1+verticalStart][counterX-1+horizontalStart] != nextTargetListConnectNo [counter1]){
                                                        attachConnectNo [6] = revisedMapCurrent [counterY+1+verticalStart][counterX-1+horizontalStart];
                                                    }
                                                    if (counterX-1+horizontalStart >= 0 && revisedMapCurrent [counterY+verticalStart][counterX-1+horizontalStart] != 0 && revisedMapCurrent [counterY+verticalStart][counterX-1+horizontalStart] != nextTargetListConnectNo [counter1]){
                                                        attachConnectNo [7] = revisedMapCurrent [counterY+verticalStart][counterX-1+horizontalStart];
                                                    }
                                                    
                                                    for (int counter2 = 0; counter2 < 8; counter2++){
                                                        if (attachConnectNo [counter2] != 0){
                                                            for (int counter3 = 1; counter3 < lineNumberCurrent2+1; counter3++){
                                                                if (nextTargetListConnectNo [counter3] == attachConnectNo [counter2]){
                                                                    if (nextTargetList [counter3] == 0){
                                                                        attachFindFlag = 1;
                                                                        nextTargetList [counter1] = 0;
                                                                        nextTargetListConnectNo [counter1] = 0;
                                                                        listLength [counter1] = 0;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                if (attachFindFlag == 1){
                                                    break;
                                                }
                                            }
                                            
                                            if (attachFindFlag == 1){
                                                break;
                                            }
                                        }
                                    }
                                }
                                
                                delete [] attachConnectNo;
                                
                                remainingCount2 = 0;
                                
                                for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                                    if (nextTargetList [counter1] != 0) remainingCount2++;
                                }
                                
                                //for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                                //    cout<<counter1<<" "<<nextTargetList [counter1]<<" "<<listLength [counter1]<<" nextTargetList2"<<endl;
                                //}
                                
                                if (remainingCount2 > 1){
                                    double findShortest = 10000;
                                    int findShortestCount = 0;
                                    
                                    for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                                        if (listLength [counter1] != 0 && listLength [counter1] < findShortest){
                                            findShortest = listLength [counter1];
                                            findShortestCount = counter1;
                                        }
                                    }
                                    
                                    for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                                        if (counter1 != findShortestCount) nextTargetList [counter1] = 0;
                                    }
                                }
                            }
                            
                            delete [] listLength;
                            delete [] nextTargetListConnectNo;
                        }
                    }
                    else if (remainingCount == 0){
                        for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                            if (counter1 != largestNextCount) nextTargetList [counter1] = 0;
                        }
                    }
                    
                    delete [] connectNextAttachGet;
                    delete [] connectNextTargetForAttach;
                    delete [] connectNextAll;
                    
                    //for (int counterA = 0; counterA < cellTrackingRelCount/15; counterA++){
                    //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingRel [counterA*15+counterB];
                    //    cout<<" arrayCellTrackingRel "<<counterA<<endl;
                    //}
                    
                    errorNoHold = 120;
                    int *arrayCellTrackingRelTemp = new int [cellTrackingRelCount*2];
                    int cellTrackingRelTempCount = 0;
                    
                    int connectNo = 0;
                    int extensionData2 = 0;
                    int noOfNext2 = 0;
                    int targetStatus = 0;
                    int noOfNextValueCount = 0;
                    int matchFind = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingRelCount/15; counter1++){
                        if (connectNo != arrayCellTrackingRel [counter1*15+2]){
                            connectNo = arrayCellTrackingRel [counter1*15+2];
                            
                            extensionData2 = 0;
                            noOfNext2 = 0;
                            targetStatus = 0;
                            
                            for (int counter2 = 0; counter2 < cellTrackingRelCount/15; counter2++){
                                if (arrayCellTrackingRel [counter2*15+2] == connectNo && extensionData2 == 0){
                                    if (arrayCellTrackingRel [counter2*15+10] != 0) noOfNext2++;
                                    if (arrayCellTrackingRel [counter2*15+11] != 0) noOfNext2++;
                                    if (arrayCellTrackingRel [counter2*15+7] == 1) targetStatus = 1;
                                    
                                    extensionData2 = 1;
                                }
                                else if (arrayCellTrackingRel [counter2*15+2] == connectNo && extensionData2 != 0){
                                    if (arrayCellTrackingRel [counter2*15+10] != 0) noOfNext2++;
                                    if (arrayCellTrackingRel [counter2*15+11] != 0) noOfNext2++;
                                }
                            }
                            
                            if (noOfNext2 != 0){
                                if (targetStatus != 1){
                                    errorNoHold = 121;
                                    int *noOfNextValue = new int [noOfNext2+10];
                                    noOfNextValueCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < noOfNext2+10; counter2++) noOfNextValue [counter2] = 0;
                                    
                                    extensionData2 = 0;
                                    
                                    for (int counter2 = 0; counter2 < cellTrackingRelCount/15; counter2++){
                                        if (arrayCellTrackingRel [counter2*15+2] == connectNo && extensionData2 == 0){
                                            if (arrayCellTrackingRel [counter2*15+10] != 0){
                                                matchFind = 0;
                                                
                                                for (int counter3 = 1; counter3 < lineNumberCurrent2+1; counter3++){
                                                    if (nextTargetList [counter3] != 0 && arrayCellTrackingRel [counter2*15+10] == nextTargetList [counter3]){
                                                        matchFind = 1;
                                                    }
                                                }
                                                
                                                if (matchFind == 0) noOfNextValue [noOfNextValueCount] = arrayCellTrackingRel [counter2*15+10], noOfNextValueCount++;
                                            }
                                            
                                            if (arrayCellTrackingRel [counter2*15+11] != 0){
                                                matchFind = 0;
                                                
                                                for (int counter3 = 1; counter3 < lineNumberCurrent2+1; counter3++){
                                                    if (nextTargetList [counter3] != 0 && arrayCellTrackingRel [counter2*15+11] == nextTargetList [counter3]){
                                                        matchFind = 1;
                                                    }
                                                }
                                                
                                                if (matchFind == 0) noOfNextValue [noOfNextValueCount] = arrayCellTrackingRel [counter2*15+10], noOfNextValueCount++;
                                            }
                                            
                                            extensionData2 = 1;
                                        }
                                        else if (arrayCellTrackingRel [counter2*15+2] == connectNo && extensionData2 != 0){
                                            if (arrayCellTrackingRel [counter2*15+10] != 0){
                                                matchFind = 0;
                                                
                                                for (int counter3 = 1; counter3 < lineNumberCurrent2+1; counter3++){
                                                    if (nextTargetList [counter3] != 0 && arrayCellTrackingRel [counter2*15+10] == nextTargetList [counter3]){
                                                        matchFind = 1;
                                                    }
                                                }
                                                
                                                if (matchFind == 0) noOfNextValue [noOfNextValueCount] = arrayCellTrackingRel [counter2*15+10], noOfNextValueCount++;
                                            }
                                            
                                            if (arrayCellTrackingRel [counter2*15+11] != 0){
                                                matchFind = 0;
                                                
                                                for (int counter3 = 1; counter3 < lineNumberCurrent2+1; counter3++){
                                                    if (nextTargetList [counter3] != 0 && arrayCellTrackingRel [counter2*15+11] == nextTargetList [counter3]){
                                                        matchFind = 1;
                                                    }
                                                }
                                                
                                                if (matchFind == 0) noOfNextValue [noOfNextValueCount] = arrayCellTrackingRel [counter2*15+10], noOfNextValueCount++;
                                            }
                                        }
                                    }
                                    
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+1], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+2], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+3], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+4], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+5], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+6], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+7], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+8], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+9], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = noOfNextValue [0], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = noOfNextValue [1], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+12], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+13], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+14], cellTrackingRelTempCount++;
                                    
                                    if (noOfNextValueCount > 2){
                                        for (int counter2 = 1; counter2 < noOfNextValueCount/2+2; counter2++){
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15], cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+1], cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+2], cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = noOfNextValue [counter2*2], cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = noOfNextValue [counter2*2+1], cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+12], cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+13], cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+14], cellTrackingRelTempCount++;
                                            
                                            if (noOfNextValue [(counter2+1)*2] == 0){
                                                break;
                                            }
                                        }
                                    }
                                    
                                    delete [] noOfNextValue;
                                }
                                else{
                                    
                                    errorNoHold = 122;
                                    int *noOfNextValue = new int [noOfNext2+10];
                                    noOfNextValueCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < noOfNext2+10; counter2++) noOfNextValue [counter2] = 0;
                                    
                                    for (int counter2 = 1; counter2 < lineNumberCurrent2+1; counter2++){
                                        if (nextTargetList [counter2] != 0) noOfNextValue [noOfNextValueCount] = counter2, noOfNextValueCount++;
                                    }
                                    
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+1], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+2], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+3], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+4], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+5], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+6], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 1, cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+8], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+9], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = noOfNextValue [0], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = noOfNextValue [1], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+12], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+13], cellTrackingRelTempCount++;
                                    arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+14], cellTrackingRelTempCount++;
                                    
                                    if (noOfNextValueCount > 2){
                                        for (int counter2 = 1; counter2 < noOfNextValueCount/2+2; counter2++){
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15], cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+1], cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+2], cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = noOfNextValue [counter2*2], cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = noOfNextValue [counter2*2+1], cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+12], cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+13], cellTrackingRelTempCount++;
                                            arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+14], cellTrackingRelTempCount++;
                                            
                                            if (noOfNextValue [(counter2+1)*2] == 0){
                                                break;
                                            }
                                        }
                                    }
                                    
                                    delete [] noOfNextValue;
                                }
                            }
                            else{
                                
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15], cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+1], cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+2], cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+3], cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+4], cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+5], cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+6], cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+7], cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+8], cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+9], cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+10], cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+11], cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+12], cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+13], cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayCellTrackingRel [counter1*15+14], cellTrackingRelTempCount++;
                            }
                        }
                    }
                    
                    cellTrackingRelCount = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingRelTempCount; counter1++) arrayCellTrackingRel [cellTrackingRelCount] = arrayCellTrackingRelTemp [counter1], cellTrackingRelCount++;
                    
                    delete [] arrayCellTrackingRelTemp;
                    
                    //for (int counterA = 0; counterA < cellTrackingRelCount/15; counterA++){
                    //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingRel [counterA*15+counterB];
                    //    cout<<" arrayCellTrackingRel "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
                    //    cout<<" xyPositionCenterCurrentCount "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < maxConnectNumberList+1; counter1++) delete [] connectNoGet2 [counter1];
                    delete [] connectNoGet2;
                    
                    delete [] connectNextTargetGet;
                    
                    errorNoHold = 123;
                    arrayCellTrackingRelTemp = new int [xyPositionCenterCurrentCount*3+50];
                    cellTrackingRelTempCount = 0;
                    int previousNoCount = 0;
                    int numberOfPreviousEntry = 0;
                    int targetTemp = 0;
                    
                    //------Current Entry------
                    for (int counter1 = 0; counter1 < xyPositionCenterCurrentCount/6; counter1++){
                        arrayCellTrackingRelTemp [cellTrackingRelTempCount] = roundStatus, cellTrackingRelTempCount++; //------Round number------
                        arrayCellTrackingRelTemp [cellTrackingRelTempCount] = imageNumberInt+1, cellTrackingRelTempCount++; //------Image number------
                        arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayXYPositionCenterCurrent [counter1*6+4], cellTrackingRelTempCount++; //------Connect number------
                        arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayXYPositionCenterCurrent [counter1*6], cellTrackingRelTempCount++; //------X position------
                        arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayXYPositionCenterCurrent [counter1*6+1], cellTrackingRelTempCount++; //------Y position------
                        arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayXYPositionCenterCurrent [counter1*6+2], cellTrackingRelTempCount++; //------Area------
                        arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayXYPositionCenterCurrent [counter1*6+3], cellTrackingRelTempCount++; //------Intensity------
                        
                        previousNoCount = 0;
                        
                        for (int counter2 = 0; counter2 < cellTrackingRelCount/15; counter2++){
                            if (arrayCellTrackingRel [counter2*15+10] == arrayXYPositionCenterCurrent [counter1*6+4]) previousNoCount++;
                            if (arrayCellTrackingRel [counter2*15+11] == arrayXYPositionCenterCurrent [counter1*6+4]) previousNoCount++;
                        }
                        
                        errorNoHold = 124;
                        int *prevNoTemp = new int [cellTrackingRelCount/15+5];
                        
                        for (int counter2 = 0; counter2 < cellTrackingRelCount/15+5; counter2++) prevNoTemp [counter2] = 0;
                        
                        entryCount = 0;
                        
                        for (int counter2 = 0; counter2 < cellTrackingRelCount/15; counter2++){
                            if (arrayCellTrackingRel [counter2*15+3] != 0) entryCount++;
                            if (arrayCellTrackingRel [counter2*15+10] == arrayXYPositionCenterCurrent [counter1*6+4]) prevNoTemp [entryCount] = 1;
                            if (arrayCellTrackingRel [counter2*15+11] == arrayXYPositionCenterCurrent [counter1*6+4]) prevNoTemp [entryCount] = 1;
                        }
                        
                        numberOfPreviousEntry = 0;
                        
                        for (int counter2 = 1; counter2 < cellTrackingRelCount/15+5; counter2++){
                            if (prevNoTemp [counter2] != 0) numberOfPreviousEntry++;
                        }
                        
                        errorNoHold = 125;
                        int *listOfFusion = new int [numberOfPreviousEntry+5];
                        int listOfFusionCount = 0;
                        
                        for (int counter2 = 0; counter2 < numberOfPreviousEntry+5; counter2++) listOfFusion [counter2] = 0;
                        
                        for (int counter2 = 1; counter2 < cellTrackingRelCount/15+5; counter2++){
                            if (prevNoTemp [counter2] != 0) listOfFusion [listOfFusionCount] = counter2, listOfFusionCount++;
                        }
                        
                        //for (int counter2 = 0; counter2 < numberOfPreviousEntry; counter2++){
                        //    cout<<counter2<<" "<<listOfFusion [counter2*2] <<" "<<listOfFusion [counter2*2+1] <<" listOfFusion"<<endl;
                        //}
                        
                        delete [] prevNoTemp;
                        
                        targetTemp = 0;
                        
                        if (nextTargetList [arrayXYPositionCenterCurrent [counter1*6+4]] != 0) targetTemp = 1;
                        
                        if (targetTemp == 0) arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++; //------Target------
                        else arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 1, cellTrackingRelTempCount++; //------Target------
                        
                        arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++; //------Mitosis status------
                        arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++; //------Div/fuse/Check------
                        arrayCellTrackingRelTemp [cellTrackingRelTempCount] = connectNoGetList [arrayXYPositionCenterCurrent [counter1*6+4]*2], cellTrackingRelTempCount++; //------Original Connect1------
                        arrayCellTrackingRelTemp [cellTrackingRelTempCount] = connectNoGetList [arrayXYPositionCenterCurrent [counter1*6+4]*2+1], cellTrackingRelTempCount++; //------Original Connect2------
                        arrayCellTrackingRelTemp [cellTrackingRelTempCount] = listOfFusion [0], cellTrackingRelTempCount++; //------Previous1------
                        arrayCellTrackingRelTemp [cellTrackingRelTempCount] = listOfFusion [1], cellTrackingRelTempCount++; //------Previous2------
                        arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++; //------Done------
                        
                        if (listOfFusionCount > 2){
                            for (int counter2 = 1; counter2 < listOfFusionCount/2+2; counter2++){
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = roundStatus, cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = imageNumberInt+1, cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = arrayXYPositionCenterCurrent [counter1*6+4], cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = listOfFusion [counter2*2], cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = listOfFusion [counter2*2+1], cellTrackingRelTempCount++;
                                arrayCellTrackingRelTemp [cellTrackingRelTempCount] = 0, cellTrackingRelTempCount++;
                                
                                if (listOfFusion [(counter2+1)*2] == 0){
                                    break;
                                }
                            }
                        }
                        
                        delete [] listOfFusion;
                    }
                    
                    for (int counter1 = 0; counter1 < cellTrackingRelTempCount; counter1++) arrayCellTrackingRel [cellTrackingRelCount] = arrayCellTrackingRelTemp [counter1], cellTrackingRelCount++;
                    
                    delete [] arrayCellTrackingRelTemp;
                    
                    //for (int counterA = 0; counterA < cellTrackingRelCount/15; counterA++){
                    //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingRel [counterA*15+counterB];
                    //    cout<<" arrayCellTrackingRel "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingCurrentCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrent [counterA*6+counterB];
                    //    cout<<" arrayCellTrackingCurrent "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < lineNumberPrevious2+5; counter1++){
                        delete [] overlapTableNew [counter1];
                        delete [] noMergeTableNew [counter1];
                    }
                    
                    delete [] overlapTableNew;
                    delete [] noMergeTableNew;
                    delete [] doneMitosis;
                    
                    delete [] arrayOverlapNumberTrack;
                    delete [] arrayOverlapPixelAreaTrack;
                    delete [] arrayOverlapPixelIntensityTrack;
                    delete [] arrayOverlapPercentTrack;
                    delete [] arrayNoMergeTableTrack;
                    
                    delete [] connectNoGetList;
                    delete [] nextTargetList;
                }
                else trackHoldFlag = 4000; //===========Loading error============
                
                for (int counter1 = 0; counter1 < lineNumberPrevious+1; counter1++){
                    delete [] overlapData [counter1];
                    delete [] overlapIntensity [counter1];
                    delete [] overlapPercent [counter1];
                }
                
                delete [] overlapData;
                delete [] overlapIntensity;
                delete [] overlapPercent;
                
                delete [] arrayPreviousTableTrack;
                delete [] arrayPreviousTableTrackTotal;
                delete [] arrayPreviousAverageTrack;
                
                delete [] arrayCurrentTableTrack;
                delete [] arrayCurrentTableTrackTotal;
                delete [] arrayCurrentAverageTrack;
                delete [] currentSD;
                delete [] currentTotalForSD;
            }
            else trackHoldFlag = 3000;
            
            errorNoHold = 0;
            subCompletionFlag = 0;
        }
        catch (int errorCheckThrow){
            if (errorNoHold == 0) errorNoHold = 1000;
            
            subCompletionFlag = 0;
        }
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingTargetTrack2 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"TargetTrack2"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
        
        subCompletionFlag = 0;
    }
    
    return targetPointerTrack;
}

@end
