//
// AreaCut.h
// Cell_Carving
//
// Created by Masahiko Sato on 31/12/13.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#ifndef AREACUT_H
#define AREACUT_H
#import "Controller.h"
#endif

@interface AreaCut : NSObject{
    int horizontalStart2; //Horizontal start
    int verticalStart2; //Vertical start
    int connectNoTemp; //Connect No. temp
    
    id merge;
}

-(int)circleCut:(int)targetCellStatus :(int)cutOffAdjust :(int)processPreviousType;
-(int)areaProcess:(int)type :(int)dimensionCut :(int)valueTemp :(int)targetCellStatus;
-(void)positionRevSelectedUpDate;
-(void)gravityCenterRevUpDate;
-(void)associateDataUpDate;
-(void)timeSelectedUpDate;
-(void)connectLineageRelUpDate;
-(void)expandLineFluorescentUpDate;
-(void)expandLineFluorescentDataUpDate;

@end
