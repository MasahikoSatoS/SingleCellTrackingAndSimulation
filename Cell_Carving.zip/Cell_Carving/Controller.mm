//
// Controller.mm
// cell_carving
//
// Created by Masahiko Sato on 10/07/11.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#import "Controller.h"

//------Mitosis Pattern library---------
int *arrayMitosisPattern;
int mitosisPatternCount;
int mitosisPatternStatus;
int mitosisPatternSizeHold;
int lastPatternNumber;

//------Basic Information---------
int firstCommunication;
int imageNumberInt;
int imageDimension;
int xGravityCenter;
int yGravityCenter;
int roundStatus;
int mitosisStatusHold;

int *arrayLineageStartEnd;
int lineageStartEndCount;
int lineageStartEndStatus;
int lineageStartEndSizeHold;

int *arrayLineageData;
int lineageDataCount;
int lineageDataStatus;
int lineageDataSizeHold;

string *arrayTreatmentStatus;
int treatmentStatusCount;
int maxTimePoint;
int timeOneHold;
int timeEndHold;
int ifStartHold;
int imageEndHold;
int timeEventEntryHold;
int eventTypeEntryHold;
int exitRequest;
int retryFlag;
int retryInfoHold;
int trackingLimit;
int outsideSettingFlag;
int blankDisplay;
int blankDisplayCount;
string analysisImageName;
string analysisID;
string treatmentNameHold;
string cellLineageNoHold;
string cellNoHold;
int cellStatusLoading;
int targetCellStatus;

int gravityCenterXHold1;
int gravityCenterYHold1;
int gravityAverageHold1;
int gravityCellNo1;

int gravityCenterXCurrentHold1;
int gravityCenterYCurrentHold1;
int gravityAverageCurrentHold1;
int gravityCellNoCurrent1;
int gravityCenterXCurrentHold2;
int gravityCenterYCurrentHold2;
int gravityAverageCurrentHold2;
int gravityCellNoCurrent2;
int gravityCenterXCurrentHold3;
int gravityCenterYCurrentHold3;
int gravityAverageCurrentHold3;
int gravityCellNoCurrent3;
int gravityCenterXCurrentHold4;
int gravityCenterYCurrentHold4;
int gravityAverageCurrentHold4;
int gravityCellNoCurrent4;
int gravityCenterEntryType;
double averageHold;
double averageCurrentHold;

int optionalShiftPercent;
int optionalShiftOrientation;
int *arrayOptionalLineData;
int optionalLineDataCount;
int optionalLineDataLimit;

uint8_t *fileReadArray;
int tifImageColorGray;

//-------TargetTrack--------
int trackAreaSize;
int horizontalStart;
int verticalStart;

//-------Previous Whole data array-------
int *arrayTimeSelected;
int timeSelectedCount;
int timeSelectedLimit;
int timeSelectedStatus;
int timeSelectedSizeHold;

int *arrayConnectLineageRel;
int connectLineageRelCount;
int connectLineageRelLimit;
int connectLineageRelStatus;
int connectLineageRelSizeHold;

int *arrayEventSequence;
int eventSequenceCount;
int eventSequenceLimit;
int eventSequenceStatus;

int *arrayPositionRevise;
int positionReviseCount;
int positionReviseLimit;
int positionReviseAddition;
int positionReviseStatus;
int positionReviseSizeHold;

int *arrayGravityCenterRev;
int gravityCenterRevCount;
int gravityCenterRevLimit;
int gravityCenterRevStatus;
int gravityCenterRevSizeHold;

int *arrayAssociatedData;
int associatedDataCount;
int associatedDataLimit;
int associatedDataStatus;
int associatedDataSizeHold;

int *arrayMitosisParameter;
int mitosisParameterCount;
int mitosisParameterLimit;
int mitosisParameterStatus;

//-------Previous Whole Image array-------
int **revisedMap;
int **revisedWorkingMap;
int mapLoadingStatusPrev;
int revisedMapSizeHold;

int **sourceImage;
int **connectMap200;
int **connectMap220;
int **connectMap240;
int **connectMapA;
int **connectMapB;
int **connectMapC;
int **connectMapD;

int *imageNoHoldMain;
int mapEntryTotal;
int mapPositionPointer;
int mapPositionPointerCurrent;
int mapPositionPointerHold;
int verticalPositionHold;
int trackingCheckInterval;
int mainMapLoadStatus;
string currentTreatmentNameHold;

//-------Previous Selected data array--------
int *arrayCellTrackingPrevious;
int cellTrackingPreviousCount;
int cellTrackingPreviousStatus;
int cellTrackingPreviousSizeHold;

int *arrayCellTrackingPreviousAss;
int cellTrackingPreviousAssCount;
int cellTrackingPreviousAssStatus;
int cellTrackingPreviousAssSizeHold;

int *arrayXYPositionCenterPrevious;
int xyPositionCenterPreviousCount;
int xyPositionCenterPreviousStatus;
int xyPositionCenterPreviousSizeHold;

//------Previous Selected Image array--------
int **arrayCellTrackingPreviousMap;
int sectionMapLoadingStatusPrev;
int cellTrackingPreviousMapSizeHold;

//-------Current Whole Data array-------
int *arrayTimeSelectedCurrent;
int timeSelectedCurrentCount;
int timeSelectedCurrentLimit;
int timeSelectedCurrentStatus;
int timeSelectedCurrentSizeHold;

int *arrayConnectLineageRelCurrent;
int connectLineageRelCurrentCount;
int connectLineageRelCurrentLimit;
int connectLineageRelCurrentStatus;
int connectLineageRelCurrentSizeHold;

int *arrayPositionReviseCurrent;
int positionReviseCurrentCount;
int positionReviseCurrentLimit;
int positionReviseCurrentAddition;
int positionReviseCurrentStatus;
int positionReviseCurrentSizeHold;

int *arrayGravityCenterRevCurrent;
int gravityCenterRevCurrentCount;
int gravityCenterRevCurrentLimit;
int gravityCenterRevCurrentStatus;
int gravityCenterRevCurrentSizeHold;

int *arrayAssociatedDataCurr;
int associatedDataCurrCount;
int associatedDataCurrLimit;
int associatedDataCurrStatus;
int associatedDataCurrSizeHold;

//-------Current Whole Image array-------
int **revisedMapCurrent;
int mapLoadingStatus;
int revisedMapCurrentSizeHold;

//-------Current Selected data array-------
int *arrayCellTrackingCurrent;
int cellTrackingCurrentCount;
int cellTrackingCurrentStatus;
int cellTrackingCurrentSizeHold;

int *arrayCellTrackingCurrentAss;
int cellTrackingCurrentAssCount;
int cellTrackingCurrentAssStatus;
int cellTrackingCurrentAssSizeHold;

int *arrayXYPositionCenterCurrent;
int xyPositionCenterCurrentCount;
int xyPositionCenterCurrentStatus;
int xyPositionCenterCurrentSizeHold;

//-------Current Selected Image array-------
int **arrayCellTrackingCurrentMap;
int sectionMapLoadingStatus;
int cellTrackingCurrentMapSizeHold;

//-------Group Data-------
int *arrayGroupInfoCurrent;
int groupInfoCurrentCount;
int groupInfoCurrentStatus;
int groupInfoCurrentSizeHold;

int *arrayGroupInfoPrevious;
int groupInfoPreviousCount;
int groupInfoPreviousStatus;
int groupInfoPreviousSizeHold;

//-------Sequential tracking info---------
int *arrayCellTrackingTable;
int cellTrackingTableCount;
int cellTrackingTableLimit;
int cellTrackingTableStatus;
int cellTrackingTableSizeHold;

int *arrayAttachTable;
int cellAttachCount;
int cellAttachLimit;
int cellAttachStatus;

//------Area cut--------
int *arrayReferenceLine;
int referenceLineCount;
int referenceLineLimit;

int **connectivityMapCut;
int connectivityMapCutStatus;
int connectivityMapCutSizeHold;

int **internalZeroMap;
int internalZeroMapStatus;
int internalZeroMapSizeHold;

int **targetMap;
int targetMapStatus;
int targetMapSizeHold;

int fusionPartnerLine;
int fusionPartnerCellNo;
string cellNoHoldDiv1;
string cellNoHoldDiv2;
string cellNoHoldDiv3;
string cellNoHoldDiv4;

//------Table Result interpret---------
int trackHoldFlag;
int terminationInfo;

int *connectNoHold;
int connectNoHoldCount;
int connectNoHoldStatus;
int connectNoHoldSizeHold;

int targetConnectInitial;

int *arrayCellTrackingRel;
int cellTrackingRelCount;
int cellTrackingRelStatus;
int cellTrackingRelSizeHold;

string returnMessage;
string returnMessageTime;
string returnMessageExt;

int *arrayFusionPartner;

int fusionPartnerCount;
int fusionPartnerLimit;
int fusionPartnerStatus;

//------Image display--------
int *arrayDisplayData;
int displayDataCount;
int displayDataStatus;
int displayDataSizeHold;

int *arrayDisplayRel;
int displayRelCount;
int displayRelStatus;
int displayRelSizeHold;

int *arrayDisplayGravityCenter;
int displayGravityCenterCount;
int displayGravityCenterStatus;
int displayGravityCenterSizeHold;

int trackAreaSizeDisplay;
int xTrackingPosition;
int yTrackingPosition;
int xDisplayPosition;
int yDisplayPosition;

//------Fluorescent Map---------
int **fluorescentMap1;
int fluorescentMapStatus1;
int **fluorescentMap2;
int fluorescentMapStatus2;
int **fluorescentMap3;
int fluorescentMapStatus3;
int **fluorescentMap4;
int fluorescentMapStatus4;
int **fluorescentMap5;
int fluorescentMapStatus5;
int **fluorescentMap6;
int fluorescentMapStatus6;
int fluorescentMapSizeHold;

int **fluorescentMapCurrent1;
int fluorescentMapCurrentStatus1;
int **fluorescentMapCurrent2;
int fluorescentMapCurrentStatus2;
int **fluorescentMapCurrent3;
int fluorescentMapCurrentStatus3;
int **fluorescentMapCurrent4;
int fluorescentMapCurrentStatus4;
int **fluorescentMapCurrent5;
int fluorescentMapCurrentStatus5;
int **fluorescentMapCurrent6;
int fluorescentMapCurrentStatus6;
int fluorescentMapCurrentSizeHold;

int *expandLineFluorescent;
int expandLineFluorescentCount;
int expandLineFluorescentLimit;
int expandLineFluorescentStatus;
int expandLineFluorescentSizeHold;

int *expandLineFluorescentData;
int expandLineFluorescentDataCount;
int expandLineFluorescentDataLimit;
int expandLineFluorescentDataStatus;
int expandLineFluorescentDataSizeHold;

int *expandLineFluorescentCurrent;
int expandLineFluorescentCurrentCount;
int expandLineFluorescentCurrentLimit;
int expandLineFluorescentCurrentStatus;
int expandLineFluorescentCurrentSizeHold;

int *expandLineFluorescentDataCurrent;
int expandLineFluorescentDataCurrentCount;
int expandLineFluorescentDataCurrentLimit;
int expandLineFluorescentDataCurrentStatus;
int expandLineFluorescentDataCurrentSizeHold;

//------Fluorescent Option---------
int fluorescentCutOff1;
int fluorescentCutOff2;
int fluorescentCutOff3;
int fluorescentCutOff4;
int fluorescentCutOff5;
int fluorescentCutOff6;
int fluorescentCutOffCurrent1;
int fluorescentCutOffCurrent2;
int fluorescentCutOffCurrent3;
int fluorescentCutOffCurrent4;
int fluorescentCutOffCurrent5;
int fluorescentCutOffCurrent6;
int fluorescentNo1;
int fluorescentNo2;
int fluorescentNo3;
int fluorescentNo4;
int fluorescentNo5;
int fluorescentNo6;
int fluorescentEntryCount;
int *arrayFluorescentCutOff;
int fluorescentCutOffCount;
int fluorescentCutOffStatus;
int autoExpand;
int autoExpandLine;
string fluorescentName1;
string fluorescentName2;
string fluorescentName3;
string fluorescentName4;
string fluorescentName5;
string fluorescentName6;
string *arrayIFDataHold;
int fluorescentDetectionDisplay1;
int fluorescentDetectionDisplay2;

//--------DIC cut Off---------
int cutStatusDic;
int cutStatusFluorescent;
int cutOff1;
int cutOff2;
int cutOff3;
int cutOff4;
int cutOff5;
int cutOff6;
int cutOff7;

string pathNameString;
string trackingDataFolderPath;
string cellCurvingSettingPath;
string mitosisPatternPath;
string imageFolderPath;
string instractionCCPath;

//--------Overlap check array--------
int **putativeMap;
int putativeMapStatus;
int putativeMapSizeHold;

//--------Directory process---------
string *arrayFileHandling;
int fileHandlingCount;
int fileHandlingLimit;

//--------Mitosis/division parameter--------
double mitosisSDHold;
int mitosisValueHold;
int divisionDistanceHold;
int mitosisAreaHold;
double mitosisRelativeLowHold;
double mitosisRelativeHighHold;
int jumpAllFlag;
int connectExpandFlag;
int mapMergeStatus;
int percentOverlap;
int gravityCentreMoveLimitFlag;
int mitosisOffFlag;
int fusionMarkSetFlag;

//--------Error no----------
int errorNoHold;
int emergencyExit;
int trackingExitCount;
int sleepingCheck;
int sleepingPosition;

int subCompletionFlag;
int subCompletionFlag2;
int subCompletionFlag3;

int targetPointerTrack;
int maxTargetEntryTrack;
int *arrayPreviousTableTrack;
double *arrayPreviousTableTrackTotal;
double *arrayPreviousAverageTrack;
int *arrayCurrentTableTrack;
double *arrayCurrentTableTrackTotal;
double *arrayCurrentAverageTrack;
int *arrayOverlapNumberTrack;
int *arrayOverlapPixelAreaTrack;
int *arrayOverlapPixelIntensityTrack;
int *arrayOverlapPercentTrack;
int *arrayNoMergeTableTrack;
int overlapNumberCountTrack;
int overlapPixelAreaCountTrack;
int overlapPixelIntensityCountTrack;
int overlapPercentCountTrack;
int noMergeTableCountTrack;
int noMergeTableLimitTrack;

int statusAdditionalInfo;
int *arrayPartnerInfo;
int partnerInfoCount;

@implementation Controller

-(id)init{
    self = [super init];
    
    if (self != nil){
        [self userPathSet];
        
        mitosisPatternStatus = 0;
        mitosisPatternSizeHold = 0;
        
        firstCommunication = 0;
        imageNumberInt = 1;
        imageDimension = 0;
        mitosisStatusHold = 0;
        lineageStartEndStatus = 0;
        lineageDataStatus = 0;
        retryFlag = 0;
        outsideSettingFlag = 0;
        blankDisplay = 0;
        blankDisplayCount = 0;
        
        timeSelectedStatus = 0;
        connectLineageRelStatus = 0;
        positionReviseStatus = 0;
        gravityCenterRevStatus = 0;
        eventSequenceStatus = 0;
        associatedDataStatus = 0;
        mapLoadingStatusPrev = 0;
        sectionMapLoadingStatusPrev = 0;
        mitosisParameterStatus = 0;
        
        mapEntryTotal = 0;
        mapPositionPointer = 0;
        mapPositionPointerCurrent = 0;
        mapPositionPointerHold = 0;
        verticalPositionHold = 0;
        trackingCheckInterval = 0;
        mainMapLoadStatus = 0;
        
        cellTrackingPreviousStatus = 0;
        cellTrackingPreviousAssStatus = 0;
        xyPositionCenterPreviousStatus = 0;
        
        timeSelectedCurrentStatus = 0;
        connectLineageRelCurrentStatus = 0;
        positionReviseCurrentStatus = 0;
        gravityCenterRevCurrentStatus = 0;
        associatedDataCurrStatus = 0;
        mapLoadingStatus = 0;
        sectionMapLoadingStatus = 0;
        
        cellTrackingCurrentStatus = 0;
        cellTrackingCurrentAssStatus = 0;
        xyPositionCenterCurrentStatus = 0;
        
        groupInfoCurrentStatus = 0;
        groupInfoPreviousStatus = 0;
        
        cellTrackingTableStatus = 0;
        cellAttachStatus = 0;
        
        connectivityMapCutStatus = 0;
        internalZeroMapStatus = 0;
        targetMapStatus = 0;
        
        connectNoHoldStatus = 0;
        cellTrackingRelStatus = 0;
        fusionPartnerStatus = 0;
        
        displayDataStatus = 0;
        displayRelStatus = 0;
        displayGravityCenterStatus = 0;
        exitRequest = 0;
        
        fluorescentMapStatus1 = 0;
        fluorescentMapStatus2 = 0;
        fluorescentMapStatus3 = 0;
        fluorescentMapStatus4 = 0;
        fluorescentMapStatus5 = 0;
        fluorescentMapStatus6 = 0;
        fluorescentMapCurrentStatus1 = 0;
        fluorescentMapCurrentStatus2 = 0;
        fluorescentMapCurrentStatus3 = 0;
        fluorescentMapCurrentStatus4 = 0;
        fluorescentMapCurrentStatus5 = 0;
        fluorescentMapCurrentStatus6 = 0;
        expandLineFluorescentStatus = 0;
        expandLineFluorescentDataStatus = 0;
        expandLineFluorescentCurrentStatus = 0;
        expandLineFluorescentDataCurrentStatus = 0;
        
        fluorescentCutOff1 = 150;
        fluorescentCutOff2 = 150;
        fluorescentCutOff3 = 150;
        fluorescentCutOff4 = 150;
        fluorescentCutOff5 = 150;
        fluorescentCutOff6 = 150;
        fluorescentCutOffCurrent1 = 150;
        fluorescentCutOffCurrent2 = 150;
        fluorescentCutOffCurrent3 = 150;
        fluorescentCutOffCurrent4 = 150;
        fluorescentCutOffCurrent5 = 150;
        fluorescentCutOffCurrent6 = 150;
        fluorescentCutOffStatus = 0;
        
        cutStatusDic = 0;
        cutStatusFluorescent = 0;
        
        putativeMapStatus = 0;
        
        errorNoHold = 0;
        emergencyExit = 0;
        trackingExitCount = 0;
        sleepingCheck = 0;
        sleepingPosition = 0;
        
        backSaveOff = 0;
        backSaveCount = 0;
        
        subCompletionFlag = 0;
        subCompletionFlag2 = 0;
        subCompletionFlag3 = 0;
        
        restartCount = 100000; //=============Auto Save Point========(set 2000)======
        //Accuracy of file open somehow reduced when the processing continue. This may be related to smaller file size was fetched by fseek(fileSize, 0, SEEK_END). Thus, for large files, consistency of file size was checked, and other files, x2 size was set upon loading files.
    }
    
    return self;
}

-(void)userPathSet{
    NSString *currentDirectoryPathNSString = [[NSBundle mainBundle] bundlePath];
    string userPathNameString = [currentDirectoryPathNSString cStringUsingEncoding:NSUTF8StringEncoding];
    
    if (userPathNameString.length() == 0) exit (0);
    else if ((int)userPathNameString.find("/Users/") == -1) exit (0);
    else{
        
        string pathName2 = userPathNameString.substr((unsigned long)userPathNameString.find("/Users/")+7);
        pathNameString = pathName2.substr(0, (unsigned long)pathName2.find("/"));
    }
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [controllerWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    CGFloat displayX = 80;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [controllerWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
}

-(void)applicationDidFinishLaunching:(NSNotification*)notification{
    imageFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images";
    trackingDataFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"07_Cell_Tracking_Data";
    mitosisPatternPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/Mitosis.dat";
    instractionCCPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"CC_Instruction";
    
    [mitosisStatusDisplay setStringValue:@"nil"];
    [pixelNumberDisplay setStringValue:@"nil"];
    [timePoint setStringValue:@"nil"];
    [xPosition setStringValue:@"nil"];
    [yPosition setStringValue:@"nil"];
    [analysisNameAuto setStringValue:@"nil"];
    [analysisIDAuto setStringValue:@"nil"];
    [treatNameAuto setStringValue:@"nil"];
    [cellLingNoAuto setStringValue:@"nil"];
    [cellNoAuto setStringValue:@"nil"];
    
    //------Saved condition check------
    arrayTreatmentStatus = new string [200];
    treatmentStatusCount = 0;
    
    arrayIFDataHold = new string [450];
    
    arrayFileHandling = new string [100];
    fileHandlingCount = 0;
    fileHandlingLimit = 100;
    
    imageNoHoldMain = new int [110];
    
    for (int counter1 = 0; counter1 < 110; counter1++) imageNoHoldMain [counter1] = 0;
    
    basicArrayStatus = 1;
    
    [backSave setHidden:YES];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTermination object:self];
    controllerTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(processControl) userInfo:nil repeats:YES];
}

-(void)processControl{
    //------AutoRun controlle------
    if (firstCommunication == 6){ //------0. On, 1. Go next image, 2. Stop AM missing, 3. Done------
        firstCommunication = 2;
        
        try{
            try{
                
                errorNoHold = 0;
                int errorCheckThrow = 0;
                
                imageNumberInt++;
                
                for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                    if (imageNoHoldMain [counter1*2] == imageNumberInt) mapPositionPointer = counter1;
                    if (imageNoHoldMain [counter1*2] == imageNumberInt+1) mapPositionPointerCurrent = counter1;
                }
                
                roundStatus++;
                
                //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                //    cout<<" arrayTimeSelected "<<counterA+1<<endl;
                //}
                
                //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
                //    cout<<" arrayPositionRevise "<<counterA<<endl;
                // }
                
                // for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
                //     for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
                //     cout<<" arrayGravityCenterRev "<<counterA<<endl;
                // }
                
                int processTime = 2;
                int imageNo = 0;
                trackingSet = [[TrackingSet alloc] init];
                [trackingSet trackingSetMain:processTime:imageNo];
                
                do{
                } while(subCompletionFlag == 1);
                
                if (errorNoHold != 0) throw errorCheckThrow;
                
                int processType = 1;
                tableInterpretation = [[TableInterpretation alloc] init];
                [tableInterpretation interpretationFirst:processType];
                
                do{
                } while(subCompletionFlag3 == 1);
                
                if (errorNoHold != 0) throw errorCheckThrow;
                
                [pixelNumberDisplay setIntegerValue:trackAreaSizeDisplay];
                [xPosition setIntegerValue:xTrackingPosition];
                [yPosition setIntegerValue:yTrackingPosition];
                [timePoint setIntegerValue:imageNumberInt-1];
                
                //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
                //    cout<<" arrayEventSequence "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                    if (arrayEventSequence [counter1*4] == imageNumberInt-1 && arrayEventSequence [counter1*4+1] == 6) mitosisStatusHold = 1;
                }
                
                if (mitosisStatusHold == 1) [mitosisStatusDisplay setStringValue:@"Mitosis"];
                else [mitosisStatusDisplay setStringValue:@"nil"];
                
                firstCommunication = 7;
                errorNoHold = 0;
            }
            catch (int errorCheckThrow){
                emergencyExit = 1;
                firstCommunication = 20;
            }
        }
        catch (bad_alloc&){
            string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
            mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            time_t rawtime;
            struct tm * timeinfo;
            time (&rawtime);
            timeinfo = localtime ( &rawtime );
            
            int tsec = timeinfo -> tm_sec;
            int tmin = timeinfo -> tm_min;
            int thour = timeinfo -> tm_hour;
            int tday = timeinfo -> tm_mday;
            int tmon = timeinfo -> tm_mon;
            
            string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
            
            errorPath = errorPath+"/Cell_CarvingCont01 "+dateTime;
            
            ofstream oin2;
            oin2.open(errorPath.c_str(), ios::out);
            oin2<<"Controller"<<endl;
            oin2<<errorNoHold<<endl;
            oin2<<analysisImageName<<endl;
            oin2<<analysisID<<endl;
            oin2<<treatmentNameHold<<endl;
            oin2<<cellLineageNoHold<<endl;
            oin2<<cellNoHold<<endl;
            oin2<<dateTime<<endl;
            oin2<<"Bad allocation"<<endl;
            oin2.close();
            
            emergencyExit = 1;
            firstCommunication = 20;
            subCompletionFlag = 0;
        }
    }
    
    if (firstCommunication == 11){
        firstCommunication = 2;
        
        [pixelNumberDisplay setIntegerValue:trackAreaSizeDisplay];
        [xPosition setIntegerValue:xTrackingPosition];
        [yPosition setIntegerValue:yTrackingPosition];
        [timePoint setIntegerValue:imageNumberInt];
        
        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
            if (arrayEventSequence [counter1*4] == imageNumberInt && arrayEventSequence [counter1*4+1] == 6) mitosisStatusHold = 1;
        }
        
        if (mitosisStatusHold == 1) [mitosisStatusDisplay setStringValue:@"Mitosis"];
        else [mitosisStatusDisplay setStringValue:@"nil"];
        
        firstCommunication = 7;
    }
    
    if (firstCommunication == 0){
        ifstream fin;
        
        cellStatusLoading = 0;
        subCompletionFlag = 0;
        
        int instructionRRFlag = 0;
        string getString;
        string imageNoTemp;
        string imageNoCheckTemp;
        
        fin.open(instractionCCPath.c_str(), ios::in);
        if (fin.is_open()){ //This checks instructionCCPath. If the file is not found more than 10 count, display background image
            instructionRRFlag = 1;
            fin.close();
        }
        
        if (instructionRRFlag != 0){
            fin.open(instractionCCPath.c_str(), ios::in);
            
            if (!fin.is_open()){ //instructionCCPath reading. In the case that reading error occurs, wait 0.1 sec and try again
                usleep (100000);
                fin.open(instractionCCPath.c_str(), ios::in);
            }
            
            analysisImageName = "";
            analysisID = "";
            treatmentNameHold = "";
            cellLineageNoHold = "";
            cellNoHold = "";
            
            if (fin.is_open()){
                getline(fin, getString), analysisImageName = getString;
                getline(fin, getString), analysisID = getString;
                getline(fin, getString), treatmentNameHold = getString;
                getline(fin, getString), cellLineageNoHold = getString;
                getline(fin, getString), cellNoHold = getString;
                getline(fin, getString);
                
                if ((int)getString.find(":") != -1){
                    imageNoTemp = getString.substr(0, getString.find(":"));
                    imageNoCheckTemp = getString.substr(getString.find(":")+1);
                }
                
                imageNumberInt = atoi(imageNoTemp.c_str());
                
                if (imageNumberInt == atoi(imageNoCheckTemp.c_str())) cellStatusLoading = 1;
                
                getline(fin, getString), trackingLimit = atoi(getString.c_str());
                getline(fin, getString), trackingCheckInterval = atoi(getString.c_str());
                getline(fin, getString), mitosisSDHold = atof(getString.c_str());
                getline(fin, getString), mitosisValueHold = atoi(getString.c_str());
                getline(fin, getString), divisionDistanceHold = atoi(getString.c_str());
                getline(fin, getString), mitosisAreaHold = atoi(getString.c_str());
                getline(fin, getString), mitosisRelativeLowHold = atof(getString.c_str());
                getline(fin, getString), mitosisRelativeHighHold = atof(getString.c_str());
                getline(fin, getString), jumpAllFlag = atoi(getString.c_str());
                getline(fin, getString), connectExpandFlag = atoi(getString.c_str());
                getline(fin, getString), mapMergeStatus = atoi(getString.c_str());
                getline(fin, getString), percentOverlap = atoi(getString.c_str());
                getline(fin, getString), gravityCentreMoveLimitFlag = atoi(getString.c_str());
                getline(fin, getString), optionalShiftPercent = atoi(getString.c_str());
                getline(fin, getString), mitosisOffFlag = atoi(getString.c_str());
                getline(fin, getString), fusionMarkSetFlag = atoi(getString.c_str());
                fin.close();
                
                sleepingCheck = 1;
                sleepingPosition = 1;
            }
            
            //cout<<mitosisAreaHold <<" "<<mitosisRelativeLowHold<<" "<<mitosisRelativeHighHold<<" value"<<endl;
            //cout<<mitosisSDHold<<" "<<mitosisValueHold<<" "<<divisionDistanceHold<<" SD"<<endl;
            //cout<<treatmentNameHold<<" "<<cellLineageNoHold<<" "<<imageNumberInt<<" "<<cellNoHold<<" "<<mitosisStatusHold<<" "<<trackingLimit<<" Input"<<endl;
            
            if (trackingLimit > 0) trackingLimit = trackingLimit+imageNumberInt;
            
            blankDisplay = 0;
            blankDisplayCount = 0;
            
            if (treatmentNameHold != "Exit" && trackingExitCount < restartCount && analysisImageName != "" && analysisID != "" && treatmentNameHold != "" && cellLineageNoHold != "" && cellNoHold != ""){
                firstCommunication = 1;
                backSaveCount = 0;
            }
            else if (treatmentNameHold == "Exit"){
                remove(instractionCCPath.c_str());
                
                if (mitosisPatternStatus == 1) delete [] arrayMitosisPattern;
                if (lineageStartEndStatus == 1) delete [] arrayLineageStartEnd;
                if (lineageDataStatus == 1) delete [] arrayLineageData;
                
                if (basicArrayStatus == 1){
                    delete [] arrayIFDataHold;
                    delete [] arrayTreatmentStatus;
                    delete [] arrayFileHandling;
                    delete [] imageNoHoldMain;
                }
                
                if (fluorescentCutOffStatus == 1){
                    delete [] arrayFluorescentCutOff;
                    fluorescentCutOffCount = 0;
                    fluorescentCutOffStatus = 0;
                }
                
                if (fusionPartnerStatus == 1){
                    delete [] arrayFusionPartner;
                    fusionPartnerCount = 0;
                    fusionPartnerStatus = 0;
                }
                
                exit (0);
            }
            else if (trackingExitCount >= restartCount){
                returnMessage = "";
                firstCommunication = 3;
            }
        }
        
        blankDisplayCount++;
        
        if (blankDisplayCount > 50 && blankDisplay == 0){
            blankDisplay = 1;
            blankDisplayCount = 0;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSourceImage object:self];
        }
        else if (blankDisplayCount > 500 && blankDisplay == 1) blankDisplayCount = 0;
    }
    
    if (firstCommunication == 1){
        [backSave setHidden:NO];
        [backSave startAnimation:self];
        
        backSaveCount++;
        
        if (backSaveCount == 5){
            backSaveCount = 0;
            firstCommunication = 100;
        }
    }
    
    if (firstCommunication == 100){
        firstCommunication = 2;
        
        try{
            try{
                
                errorNoHold = 0;
                int errorCheckThrow = 0;
                sleepingPosition = 2;
                
                [analysisNameAuto setStringValue:[NSString stringWithUTF8String:analysisImageName.c_str()]];
                [analysisIDAuto setStringValue:[NSString stringWithUTF8String:analysisID.c_str()]];
                [treatNameAuto setStringValue:[NSString stringWithUTF8String:treatmentNameHold.c_str()]];
                [cellLingNoAuto setStringValue:[NSString stringWithUTF8String:cellLineageNoHold.c_str()]];
                [cellNoAuto setStringValue:[NSString stringWithUTF8String:cellNoHold.c_str()]];
                
                string connectAmendPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+analysisID+"_"+cellLineageNoHold+"_lineDataAmend";
                
                ifstream fin;
                
                long sizeForCopy = 0;
                struct stat sizeOfFile;
                
                if (stat(connectAmendPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    fin.open(connectAmendPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [25];
                        
                        errorNoHold = 1;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0){
                                errorNoHold = 1000;
                                throw errorCheckThrow;
                            }
                        }
                        
                        fin.close();
                        
                        errorNoHold = 2;
                        int *arrayDataAmendLine = new int [sizeForCopy+50];
                        int dataAmendLineCount = 0;
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++; //--3
                                finData [6] = uploadTemp [readPosition], readPosition++; //--4
                                finData [7] = uploadTemp [readPosition], readPosition++;
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [5] = finData [4]*256+finData [5];
                                finData [9] = finData [7]*65536+finData [8]*256+finData [9];
                                finData [12] = finData [10]*65536+finData [11]*256+finData [12];
                                
                                if (finData [1] == 0 && finData [3] == 0) stepCount = 3;
                                else{
                                    
                                    arrayDataAmendLine [dataAmendLineCount] = finData [1], dataAmendLineCount++;
                                    arrayDataAmendLine [dataAmendLineCount] = finData [3], dataAmendLineCount++;
                                    arrayDataAmendLine [dataAmendLineCount] = finData [5], dataAmendLineCount++;
                                    arrayDataAmendLine [dataAmendLineCount] = finData [6], dataAmendLineCount++;
                                    arrayDataAmendLine [dataAmendLineCount] = finData [9], dataAmendLineCount++;
                                    arrayDataAmendLine [dataAmendLineCount] = finData [12], dataAmendLineCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                        
                        //for (int counterA = 0; counterA < dataAmendLineCount/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayDataAmendLine [counterA*6+counterB];
                        //    cout<<" arrayDataAmendLine "<<counterA<<endl;
                        //}
                        
                        int maxPointDimX = 0;
                        int maxPointDimY = 0;
                        int minPointDimX = 1000000;
                        int minPointDimY = 1000000;
                        
                        for (int counter1 = 0; counter1 < dataAmendLineCount/6; counter1++){
                            if (maxPointDimX < arrayDataAmendLine [counter1*6+1]) maxPointDimX = arrayDataAmendLine [counter1*6+1];
                            if (minPointDimX > arrayDataAmendLine [counter1*6+1]) minPointDimX = arrayDataAmendLine [counter1*6+1];
                            if (maxPointDimY < arrayDataAmendLine [counter1*6+2]) maxPointDimY = arrayDataAmendLine [counter1*6+2];
                            if (minPointDimY > arrayDataAmendLine [counter1*6+2]) minPointDimY = arrayDataAmendLine [counter1*6+2];
                        }
                        
                        delete [] arrayDataAmendLine;
                        
                        //------Determine the dimension of cell------
                        horizontalStart = 0;
                        verticalStart = 0;
                        
                        int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                        int verticalLength = (maxPointDimY-minPointDimY)/2*2;
                        
                        if (horizontalLength >= verticalLength) trackAreaSize = horizontalLength+30;
                        if (horizontalLength < verticalLength) trackAreaSize = verticalLength+30;
                        
                        if (trackAreaSize > 0){
                            if (trackAreaSize < 128) trackAreaSize = 128;
                            else trackAreaSize = (trackAreaSize/2)*2;
                            
                            horizontalStart = minPointDimX-(trackAreaSize-horizontalLength)/2;
                            verticalStart = minPointDimY-(trackAreaSize-verticalLength)/2;
                            
                            string cutOffDataPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/OutlineSettingStatus";
                            
                            string getString;
                            
                            fin.open(cutOffDataPath.c_str(), ios::in);
                            
                            cutStatusDic = 30;
                            cutStatusFluorescent = 30;
                            
                            if (fin.is_open()){
                                getline(fin, getString);
                                
                                if (getString == "nil") cutStatusDic = 30;
                                else cutStatusDic = atoi(getString.c_str());
                                
                                getline(fin, getString);
                                
                                if (getString == "nil") cutStatusFluorescent = 30;
                                else cutStatusFluorescent = atoi(getString.c_str());
                                
                                fin.close();
                            }
                            
                            string savedDataPath = trackingDataFolderPath+"/*LineageTrackingCurrent.dat";
                            
                            fluorescentName1 = "";
                            fluorescentName2 = "";
                            fluorescentName3 = "";
                            fluorescentName4 = "";
                            fluorescentName5 = "";
                            fluorescentName6 = "";
                            fluorescentNo1 = 0;
                            fluorescentNo2 = 0;
                            fluorescentNo3 = 0;
                            fluorescentNo4 = 0;
                            fluorescentNo5 = 0;
                            fluorescentNo6 = 0;
                            fluorescentEntryCount = 0;
                            autoExpand = 0;
                            autoExpandLine = 0;
                            
                            if (horizontalLength > 0 && verticalLength > 0){
                                fin.open(savedDataPath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    getline(fin, getString);
                                    getline(fin, getString);
                                    getline(fin, getString), autoExpand = atoi(getString.c_str());
                                    getline(fin, getString), autoExpandLine = atoi(getString.c_str());
                                    getline(fin, getString);
                                    getline(fin, getString);
                                    getline(fin, getString);
                                    getline(fin, getString);
                                    getline(fin, getString), fluorescentEntryCount = atoi(getString.c_str());
                                    getline(fin, getString), fluorescentNo1 = atoi(getString.c_str());
                                    getline(fin, getString), fluorescentNo2 = atoi(getString.c_str());
                                    getline(fin, getString), fluorescentNo3 = atoi(getString.c_str());
                                    getline(fin, getString), fluorescentNo4 = atoi(getString.c_str());
                                    getline(fin, getString), fluorescentNo5 = atoi(getString.c_str());
                                    getline(fin, getString), fluorescentNo6 = atoi(getString.c_str());
                                    getline(fin, getString);
                                    
                                    //autoExpandLine = 0; //---------Inactivate Auto expand---------
                                    
                                    if (getString == "nil") fluorescentName1 = "";
                                    else fluorescentName1 = getString;
                                    
                                    getline(fin, getString);
                                    
                                    if (getString == "nil") fluorescentName2 = "";
                                    else fluorescentName2 = getString;
                                    
                                    getline(fin, getString);
                                    
                                    if (getString == "nil") fluorescentName3 = "";
                                    else fluorescentName3 = getString;
                                    
                                    getline(fin, getString);
                                    
                                    if (getString == "nil") fluorescentName4 = "";
                                    else fluorescentName4 = getString;
                                    
                                    getline(fin, getString);
                                    
                                    if (getString == "nil") fluorescentName5 = "";
                                    else fluorescentName5 = getString;
                                    
                                    getline(fin, getString);
                                    
                                    if (getString == "nil") fluorescentName6 = "";
                                    else fluorescentName6 = getString;
                                    
                                    treatmentStatusCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < 16; counter1++){
                                        getline(fin, getString);
                                        
                                        if (getString != "IFDATA"){
                                            arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                                            getline(fin, getString);
                                            arrayTreatmentStatus [treatmentStatusCount] = "0", treatmentStatusCount++;
                                            getline(fin, getString);
                                            arrayTreatmentStatus [treatmentStatusCount] = "0", treatmentStatusCount++;
                                            getline(fin, getString);
                                            arrayTreatmentStatus [treatmentStatusCount] = "0", treatmentStatusCount++;
                                            getline(fin, getString);
                                            arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                                            getline(fin, getString);
                                            arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                                            getline(fin, getString);
                                            arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                                            getline(fin, getString);
                                            arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                                            getline(fin, getString);
                                            arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                                        }
                                        else{
                                            
                                            break;
                                        }
                                    }
                                    
                                    //cout<<analysisImageName<<" "<<analysisID<<" "<<autoExpand<<" "<<autoExpandLine<<" "<<fluorescentEntryCount<<" "<<fluorescentNo1<<" "<<fluorescentNo2<<" "<<fluorescentNo3<<" LoadData"<<endl;
                                    
                                    for (int counter1 = 0; counter1 < 450; counter1++) arrayIFDataHold [counter1] = "nil";
                                    
                                    int ifDataHoldCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < 450; counter1 = counter1+15){
                                        getline(fin, getString);
                                        
                                        if (getString != "END"){
                                            arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                            getline(fin, getString);
                                            arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                            getline(fin, getString);
                                            arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                            getline(fin, getString);
                                            arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                            getline(fin, getString);
                                            arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                            getline(fin, getString);
                                            arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                            getline(fin, getString);
                                            arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                            getline(fin, getString);
                                            arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                            getline(fin, getString);
                                            arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                            getline(fin, getString);
                                            arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                            getline(fin, getString);
                                            arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                            getline(fin, getString);
                                            arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                            getline(fin, getString);
                                            arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                            getline(fin, getString);
                                            arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                            getline(fin, getString);
                                            arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                        }
                                        else{
                                            
                                            break;
                                        }
                                    }
                                    
                                    fin.close();
                                }
                                else{
                                    
                                    errorNoHold = 1001;
                                    throw errorCheckThrow;
                                }
                            }
                            else{
                                
                                errorNoHold = 1002;
                                throw errorCheckThrow;
                            }
                            
                            string maxPointString;
                            string timeOneString;
                            string timeEndString;
                            string ifStartString;
                            string imageEndString;
                            
                            for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
                                if (arrayTreatmentStatus [counter1*9] == treatmentNameHold){
                                    maxPointString = arrayTreatmentStatus [counter1*9+6];
                                    timeOneString = arrayTreatmentStatus [counter1*9+4];
                                    timeEndString = arrayTreatmentStatus [counter1*9+5];
                                    ifStartString = arrayTreatmentStatus [counter1*9+7];
                                    imageEndString = arrayTreatmentStatus [counter1*9+8];
                                    
                                    if (maxPointString == "nil") maxTimePoint = 0;
                                    else maxTimePoint = atoi(maxPointString.c_str());
                                    
                                    if (timeOneString == "nil") timeOneHold = 0;
                                    else timeOneHold = atoi(timeOneString.c_str());
                                    
                                    if (timeEndString == "nil") timeEndHold = 0;
                                    else timeEndHold = atoi(timeEndString.c_str());
                                    
                                    if (ifStartString == "nil") ifStartHold = 0;
                                    else ifStartHold = atoi(ifStartString.c_str());
                                    
                                    if (imageEndString == "nil") imageEndHold = 0;
                                    else imageEndHold = atoi(imageEndString.c_str());
                                    
                                    break;
                                }
                            }
                            
                            //------Fluorescent Cut Off data Read---------
                            string cutOffPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
                            
                            if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                                if (fluorescentCutOffStatus == 0){
                                    errorNoHold = 3;
                                    arrayFluorescentCutOff = new int [imageEndHold*7+50];
                                    fluorescentCutOffStatus = 1;
                                }
                                
                                for (int counter1 = 0; counter1 < imageEndHold*7; counter1++) arrayFluorescentCutOff [counter1] = 0;
                                
                                fluorescentCutOffCount = 0;
                                
                                fin.open (cutOffPath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    for (int counter1 = 0; counter1 < imageEndHold; counter1++){
                                        getline(fin, getString);
                                        
                                        if (getString != "End"){
                                            arrayFluorescentCutOff [fluorescentCutOffCount] = atoi(getString.c_str()), fluorescentCutOffCount++;
                                            getline(fin, getString);
                                            arrayFluorescentCutOff [fluorescentCutOffCount] = atoi(getString.c_str()), fluorescentCutOffCount++;
                                            getline(fin, getString);
                                            arrayFluorescentCutOff [fluorescentCutOffCount] = atoi(getString.c_str()), fluorescentCutOffCount++;
                                            getline(fin, getString);
                                            arrayFluorescentCutOff [fluorescentCutOffCount] = atoi(getString.c_str()), fluorescentCutOffCount++;
                                            getline(fin, getString);
                                            arrayFluorescentCutOff [fluorescentCutOffCount] = atoi(getString.c_str()), fluorescentCutOffCount++;
                                            getline(fin, getString);
                                            arrayFluorescentCutOff [fluorescentCutOffCount] = atoi(getString.c_str()), fluorescentCutOffCount++;
                                            getline(fin, getString);
                                            arrayFluorescentCutOff [fluorescentCutOffCount] = atoi(getString.c_str()), fluorescentCutOffCount++;
                                        }
                                        else{
                                            
                                            break;
                                        }
                                    }
                                    
                                    fin.close();
                                }
                                else{
                                    
                                    errorNoHold = 1003;
                                    throw errorCheckThrow;
                                }
                            }
                            else{
                                
                                if (fluorescentNo1 == 0){
                                    if (fluorescentCutOffStatus == 1){
                                        delete [] arrayFluorescentCutOff;
                                        fluorescentCutOffCount = 0;
                                        fluorescentCutOffStatus = 0;
                                    }
                                }
                                else{
                                    
                                    string extension = to_string(timeOneHold); //========Check timeEventEntryHold or time one
                                    
                                    if (extension.length() == 1) extension = "000"+extension;
                                    else if (extension.length() == 2) extension = "00"+extension;
                                    else if (extension.length() == 3) extension = "0"+extension;
                                    
                                    string extension2;
                                    
                                    if (fluorescentNo1 == 1) extension2 = "1";
                                    else if (fluorescentNo1 == 2) extension2 = "2";
                                    else if (fluorescentNo1 == 3) extension2 = "3";
                                    else if (fluorescentNo1 == 4) extension2 = "4";
                                    else if (fluorescentNo1 == 5) extension2 = "5";
                                    else if (fluorescentNo1 == 6) extension2 = "6";
                                    else if (fluorescentNo1 == 7) extension2 = "7";
                                    else if (fluorescentNo1 == 8) extension2 = "8";
                                    else if (fluorescentNo1 == 9) extension2 = "9";
                                    
                                    string firstColorImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+".tif";
                                    
                                    fin.open(firstColorImagePath.c_str(), ios::in);
                                    
                                    if (!fin.is_open()){
                                        firstColorImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+".bmp";
                                    }
                                    else fin.close();
                                    
                                    if (stat(firstColorImagePath.c_str(), &sizeOfFile) == 0){
                                        if (fluorescentCutOffStatus == 0){
                                            errorNoHold = 4;
                                            arrayFluorescentCutOff = new int [imageEndHold*7+50];
                                            fluorescentCutOffStatus = 1;
                                        }
                                        
                                        fluorescentCutOffCount = 0;
                                        
                                        arrayFluorescentCutOff [fluorescentCutOffCount] = timeOneHold, fluorescentCutOffCount++;
                                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                        
                                        ofstream oin;
                                        
                                        if (oin.is_open()){
                                            oin.open(cutOffPath.c_str(), ios::out);
                                            
                                            for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                                            
                                            oin<<"End"<<endl;
                                            oin.close();
                                        }
                                        else{
                                            
                                            oin.open(cutOffPath.c_str(), ios::out);
                                            
                                            for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                                            
                                            oin<<"End"<<endl;
                                            oin.close();
                                        }
                                    }
                                    else if (fluorescentCutOffStatus == 1){
                                        delete [] arrayFluorescentCutOff;
                                        fluorescentCutOffCount = 0;
                                        fluorescentCutOffStatus = 0;
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < fluorescentCutOffCount/4; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayFluorescentCutOff [counterA*4+counterB];
                            //     cout<<" arrayFluorescentCutOff "<<counterA<<endl;
                            //}
                            
                            //---------Mitosis Set array read---------
                            string mitosisStatusPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_MitosisData";
                            
                            long size1 = 0;
                            long size2 = 0;
                            int checkFlag = 0;
                            
                            for (int counter1 = 0; counter1 < 6; counter1++){
                                sizeForCopy = 0;
                                
                                if (stat(mitosisStatusPath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                if (sizeForCopy != 0){
                                    if (counter1 == 0) size1 = sizeForCopy;
                                    else if (counter1 == 1) size2 = sizeForCopy;
                                    else if (counter1 == 2){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                            break;
                                        }
                                        else{
                                            
                                            size1 = 0;
                                            size2 = 0;
                                            usleep (50000);
                                        }
                                    }
                                    else if (counter1 == 3) size1 = sizeForCopy;
                                    else if (counter1 == 4) size2 = sizeForCopy;
                                    else if (counter1 == 5){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                        }
                                    }
                                }
                            }
                            
                            if (stat(mitosisStatusPath.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                                errorNoHold = 1004;
                                throw errorCheckThrow;
                            }
                            
                            errorNoHold = 5;
                            if (mitosisParameterStatus == 1) delete [] arrayMitosisParameter;
                            arrayMitosisParameter = new int [sizeForCopy+50];
                            mitosisParameterCount = 0;
                            mitosisParameterLimit = (int)sizeForCopy+50;
                            mitosisParameterStatus = 1;
                            
                            string cellLineageExtract = cellLineageNoHold. substr(1);
                            int cellLineageExtractInt = atoi(cellLineageExtract.c_str());
                            string cellNoHoldExtract = cellNoHold. substr(1);
                            int cellNoHoldExtractInt = atoi(cellNoHoldExtract.c_str());
                            
                            if (checkFlag == 1){
                                fin.open(mitosisStatusPath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    string lingNoGet;
                                    string cellNoGet;
                                    string imageNoGet;
                                    string setTypeGet;
                                    
                                    int terminationFlag = 0;
                                    
                                    do{
                                        
                                        terminationFlag = 1;
                                        getline(fin, lingNoGet);
                                        
                                        if (lingNoGet == "" || mitosisParameterCount > sizeForCopy) terminationFlag = 0;
                                        else{
                                            
                                            getline(fin, cellNoGet);
                                            getline(fin, imageNoGet);
                                            getline(fin, setTypeGet);
                                            
                                            if (cellLineageExtractInt == atoi(lingNoGet.c_str()) && cellNoHoldExtractInt == atoi(cellNoGet.c_str())){
                                                arrayMitosisParameter [mitosisParameterCount] = atoi(lingNoGet.c_str()), mitosisParameterCount++;
                                                arrayMitosisParameter [mitosisParameterCount] = atoi(cellNoGet.c_str()), mitosisParameterCount++;
                                                arrayMitosisParameter [mitosisParameterCount] = atoi(imageNoGet.c_str()), mitosisParameterCount++;
                                                arrayMitosisParameter [mitosisParameterCount] = atoi(setTypeGet.c_str()), mitosisParameterCount++;
                                            }
                                            else terminationFlag = 0;
                                        }
                                        
                                    } while (terminationFlag == 1);
                                    
                                    fin.close();
                                }
                                else{
                                    
                                    errorNoHold = 1005;
                                    throw errorCheckThrow;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < mitosisParameterCount/4; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisParameter [counterA*4+counterB];
                            //    cout<<" arrayMitosisParameter "<<counterA<<endl;
                            //}
                            
                            //---------Mitosis Pattern Data Read--------
                            string mitosisPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/"+"Mitosis.dat";
                            sizeForCopy = 0;
                            
                            if (stat(mitosisPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                if (mitosisPatternStatus == 0){
                                    errorNoHold = 6;
                                    arrayMitosisPattern = new int [sizeForCopy+50];
                                    mitosisPatternCount = 0;
                                    mitosisPatternStatus = 1;
                                    mitosisPatternSizeHold = (int)sizeForCopy+50;
                                }
                                else if (mitosisPatternStatus == 1 && mitosisPatternSizeHold < sizeForCopy){
                                    delete [] arrayMitosisPattern;
                                    
                                    errorNoHold = 7;
                                    arrayMitosisPattern = new int [sizeForCopy+50];
                                    mitosisPatternCount = 0;
                                    mitosisPatternSizeHold = (int)sizeForCopy+50;
                                }
                                else mitosisPatternCount = 0;
                                
                                fin.open(mitosisPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    errorNoHold = 8;
                                    uploadTemp = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    fin.close();
                                    
                                    readPosition = 0;
                                    stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTemp [readPosition], readPosition++;
                                            finData [1] = uploadTemp [readPosition], readPosition++; //--2. Entry No
                                            finData [2] = uploadTemp [readPosition], readPosition++;
                                            finData [3] = uploadTemp [readPosition], readPosition++; //--5. X position
                                            finData [4] = uploadTemp [readPosition], readPosition++;
                                            finData [5] = uploadTemp [readPosition], readPosition++; //--8. Y position
                                            finData [6] = uploadTemp [readPosition], readPosition++;
                                            finData [7] = uploadTemp [readPosition], readPosition++; //--8. Y position
                                            
                                            finData [1] = finData [0]*256+finData [1];
                                            finData [3] = finData [2]*256+finData [3];
                                            finData [5] = finData [4]*256+finData [5];
                                            finData [7] = finData [6]*256+finData [7];
                                            
                                            if ((finData [1] == 0 && finData [3] == 0) || mitosisPatternCount > sizeForCopy) stepCount = 3;
                                            else{
                                                
                                                arrayMitosisPattern [mitosisPatternCount] = finData [1], mitosisPatternCount++;
                                                arrayMitosisPattern [mitosisPatternCount] = finData [3], mitosisPatternCount++;
                                                arrayMitosisPattern [mitosisPatternCount] = finData [5], mitosisPatternCount++;
                                                arrayMitosisPattern [mitosisPatternCount] = finData [7], mitosisPatternCount++;
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                    
                                    lastPatternNumber = arrayMitosisPattern [(mitosisPatternCount/4-1)*4];
                                    
                                    delete [] uploadTemp;
                                }
                                else{
                                    
                                    errorNoHold = 1006;
                                    throw errorCheckThrow;
                                }
                            }
                            
                            if (lastPatternNumber != 0){
                                string cutOffDataPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/OutlineSetting";
                                
                                cutOff1 = 240;
                                cutOff2 = 230;
                                cutOff3 = 220;
                                cutOff4 = 190;
                                cutOff5 = 160;
                                cutOff6 = 130;
                                cutOff7 = 90;
                                
                                fin.open(cutOffDataPath2.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    getline(fin, getString);
                                    getline(fin, getString);
                                    
                                    getline(fin, getString);
                                    if (getString == "nil") cutOff4 = atoi(getString.c_str());
                                    
                                    getline(fin, getString);
                                    if (getString == "nil") cutOff5 = atoi(getString.c_str());
                                    
                                    getline(fin, getString);
                                    if (getString == "nil") cutOff6 = atoi(getString.c_str());
                                    
                                    getline(fin, getString);
                                    if (getString == "nil") cutOff7 = atoi(getString.c_str());
                                    
                                    fin.close();
                                }
                                
                                int cutOffHigherRange = (int)((250-cutOff4)/(double)4);
                                
                                cutOff1 = cutOff4+cutOffHigherRange*3;
                                cutOff2 = cutOff4+cutOffHigherRange*2;
                                cutOff3 = cutOff4+cutOffHigherRange;
                                
                                int processTime = 1;
                                int imageNo = 0;
                                
                                if (trackingLimit == -2) imageNo = ifStartHold-1;
                                else imageNo = 0;
                                
                                //===========Image file update============
                                if (mapEntryTotal == 0){
                                    currentTreatmentNameHold = treatmentNameHold;
                                    
                                    string extension;
                                    
                                    unsigned long stripFirstAddress = 0;
                                    unsigned long stripByteCountAddress = 0;
                                    unsigned long nextAddress = 0;
                                    unsigned long headPosition = 0;
                                    unsigned long stripEntry = 0;
                                    
                                    double xPositionCV = 0;
                                    double yPositionCV = 0;
                                    
                                    int imageWidth = 0;
                                    int imageHeight = 0;
                                    int imageBit = 0; //Check 8, 16
                                    int imageCompression = 0; //Check 1
                                    int photoMetric = 0; //Check 0, 1, 2
                                    int endianType = 0;
                                    int samplePerPix = 0;
                                    int dataConversion [4];
                                    int numberOfLayers = 0;
                                    
                                    if (imageNo == 0) extension = to_string(imageNumberInt);
                                    else extension = to_string(imageNo);
                                    
                                    if (extension.length() == 1) extension = "000"+extension;
                                    else if (extension.length() == 2) extension = "00"+extension;
                                    else if (extension.length() == 3) extension = "0"+extension;
                                    
                                    string sourceImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+".tif";
                                    
                                    fin.open(sourceImagePath.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        tifImageColorGray = 0;
                                        
                                        size1 = 0;
                                        size2 = 0;
                                        checkFlag = 0;
                                        
                                        for (int counter1 = 0; counter1 < 6; counter1++){
                                            sizeForCopy = 0;
                                            
                                            if (stat(sourceImagePath.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                            }
                                            
                                            if (sizeForCopy != 0){
                                                if (counter1 == 0) size1 = sizeForCopy;
                                                else if (counter1 == 1) size2 = sizeForCopy;
                                                else if (counter1 == 2){
                                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                        checkFlag = 1;
                                                        break;
                                                    }
                                                    else{
                                                        
                                                        size1 = 0;
                                                        size2 = 0;
                                                        usleep (50000);
                                                    }
                                                }
                                                else if (counter1 == 3) size1 = sizeForCopy;
                                                else if (counter1 == 4) size2 = sizeForCopy;
                                                else if (counter1 == 5){
                                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                        checkFlag = 1;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (checkFlag == 0){
                                            errorNoHold = 1007;
                                            throw errorCheckThrow;
                                        }
                                        
                                        if (checkFlag == 1){
                                            errorNoHold = 9;
                                            fileReadArray = new uint8_t [sizeForCopy+50];
                                            fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                                            
                                            fin.read((char*)fileReadArray, sizeForCopy+50);
                                            fin.close();
                                            
                                            dataConversion [0] = fileReadArray [0];
                                            dataConversion [1] = fileReadArray [1];
                                            
                                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                            else if (dataConversion [0] == 73 && dataConversion [1] == 73) endianType = 0;
                                            
                                            headPosition = 0;
                                            
                                            if (endianType == 1){
                                                dataConversion [0] = fileReadArray [7];
                                                dataConversion [1] = fileReadArray [6];
                                                dataConversion [2] = fileReadArray [5];
                                                dataConversion [3] = fileReadArray [4];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            else if (endianType == 0){
                                                dataConversion [0] = fileReadArray [4];
                                                dataConversion [1] = fileReadArray [5];
                                                dataConversion [2] = fileReadArray [6];
                                                dataConversion [3] = fileReadArray [7];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            
                                            if (endianType == 1){
                                                tiffFileRead = [[TiffFileRead alloc] init];
                                                [tiffFileRead tiffReadLargeEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPositionCV:&yPositionCV:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                                
                                                if (photoMetric == 2) tifImageColorGray = 1;
                                                else if (photoMetric == 0) tifImageColorGray = 0;
                                                
                                                imageDimension = imageWidth;
                                            }
                                            else if (endianType == 0){
                                                tiffFileRead = [[TiffFileRead alloc] init];
                                                [tiffFileRead tiffReadSmallEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPositionCV:&yPositionCV:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                                
                                                if (photoMetric == 2) tifImageColorGray = 1;
                                                else if (photoMetric == 0) tifImageColorGray = 0;
                                                
                                                imageDimension = imageWidth;
                                            }
                                            
                                            delete [] fileReadArray;
                                        }
                                    }
                                    else{
                                        
                                        sourceImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+".bmp";
                                        
                                        int bitPosition = 0;
                                        imageDimension = 512;
                                        int bitData = 0;
                                        int verticalBit [4];
                                        
                                        fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            while ((bitData = fin.get()) != EOF){
                                                if (bitPosition == 22) verticalBit [0] = bitData;
                                                if (bitPosition == 23) verticalBit [1] = bitData;
                                                if (bitPosition == 24) verticalBit [2] = bitData;
                                                if (bitPosition == 25){
                                                    verticalBit [3] = bitData;
                                                    
                                                    imageDimension = verticalBit [3]*16777216+verticalBit [2]*65536+verticalBit [1]*256+verticalBit [0];
                                                    
                                                    break;
                                                }
                                                
                                                bitPosition++;
                                            }
                                            
                                            fin.close();
                                        }
                                        else{
                                            
                                            errorNoHold = 1008;
                                            throw errorCheckThrow;
                                        }
                                    }
                                    
                                    if (trackingLimit == -2){
                                        imageNoHoldMain [0] = ifStartHold-1;
                                        imageNoHoldMain [1] = 3;
                                        
                                        mapEntryTotal = 1;
                                        mapPositionPointer = 0;
                                        mapPositionPointerCurrent = -1;
                                        mainMapLoadStatus = 1;
                                        
                                        int imageSizeTotal = imageDimension*imageDimension+1;
                                        
                                        errorNoHold = 10;
                                        connectMap200 = new int *[mapEntryTotal];
                                        errorNoHold = 11;
                                        connectMap220 = new int *[mapEntryTotal];
                                        errorNoHold = 12;
                                        connectMap240 = new int *[mapEntryTotal];
                                        errorNoHold = 13;
                                        connectMapA = new int *[mapEntryTotal];
                                        errorNoHold = 14;
                                        connectMapB = new int *[mapEntryTotal];
                                        errorNoHold = 15;
                                        connectMapC = new int *[mapEntryTotal];
                                        errorNoHold = 16;
                                        connectMapD = new int *[mapEntryTotal];
                                        errorNoHold = 17;
                                        sourceImage = new int *[mapEntryTotal];
                                        
                                        for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                                            errorNoHold = 18;
                                            connectMap200 [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 19;
                                            connectMap220 [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 20;
                                            connectMap240 [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 21;
                                            connectMapA [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 22;
                                            connectMapB [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 23;
                                            connectMapC [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 24;
                                            connectMapD [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 25;
                                            sourceImage [counter1] = new int [imageSizeTotal];
                                        }
                                        
                                        imageFileUpLoad = [[ImageFileUpLoad alloc] init];
                                        [imageFileUpLoad fileUploadMain];
                                        
                                        do{
                                        } while(subCompletionFlag == 1);
                                        
                                        if (errorNoHold != 0){
                                            errorNoHold = errorNoHold+2000;
                                            throw errorCheckThrow;
                                        }
                                    }
                                    else if (trackingLimit == -1){
                                        imageNoHoldMain [0] = imageNumberInt;
                                        imageNoHoldMain [1] = 3;
                                        
                                        mapEntryTotal = 1;
                                        mapPositionPointer = 0;
                                        mapPositionPointerCurrent = -1;
                                        mainMapLoadStatus = 1;
                                        
                                        int imageSizeTotal = imageDimension*imageDimension+1;
                                        
                                        errorNoHold = 26;
                                        connectMap200 = new int *[mapEntryTotal];
                                        errorNoHold = 27;
                                        connectMap220 = new int *[mapEntryTotal];
                                        errorNoHold = 28;
                                        connectMap240 = new int *[mapEntryTotal];
                                        errorNoHold = 29;
                                        connectMapA = new int *[mapEntryTotal];
                                        errorNoHold = 30;
                                        connectMapB = new int *[mapEntryTotal];
                                        errorNoHold = 31;
                                        connectMapC = new int *[mapEntryTotal];
                                        errorNoHold = 32;
                                        connectMapD = new int *[mapEntryTotal];
                                        errorNoHold = 33;
                                        sourceImage = new int *[mapEntryTotal];
                                        
                                        for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                                            errorNoHold = 34;
                                            connectMap200 [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 35;
                                            connectMap220 [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 36;
                                            connectMap240 [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 37;
                                            connectMapA [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 38;
                                            connectMapB [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 39;
                                            connectMapC [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 40;
                                            connectMapD [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 44;
                                            sourceImage [counter1] = new int [imageSizeTotal];
                                        }
                                        
                                        imageFileUpLoad = [[ImageFileUpLoad alloc] init];
                                        [imageFileUpLoad fileUploadMain];
                                        
                                        do{
                                        } while(subCompletionFlag == 1);
                                        
                                        if (errorNoHold != 0){
                                            errorNoHold = errorNoHold+2000;
                                            throw errorCheckThrow;
                                        }
                                    }
                                    else{
                                        
                                        int imageMainEntryCount = 0;
                                        
                                        mapEntryTotal = trackingCheckInterval+1;
                                        
                                        for (int counter1 = imageNumberInt; counter1 <= imageNumberInt+trackingCheckInterval; counter1++){
                                            imageNoHoldMain [imageMainEntryCount] = counter1, imageMainEntryCount++;
                                            imageNoHoldMain [imageMainEntryCount] = 3, imageMainEntryCount++;
                                        }
                                        
                                        //for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                                        //    cout<<counter1<<" "<<imageNoHoldMain [counter1*2]<<" "<<imageNoHoldMain [counter1*2+1]<<" imageNoHoldMain"<<endl;
                                        //}
                                        
                                        mapPositionPointer = 0;
                                        mapPositionPointerCurrent = 1;
                                        mainMapLoadStatus = 1;
                                        
                                        int imageSizeTotal = imageDimension*imageDimension+1;
                                        
                                        errorNoHold = 42;
                                        connectMap200 = new int *[mapEntryTotal];
                                        errorNoHold = 43;
                                        connectMap220 = new int *[mapEntryTotal];
                                        errorNoHold = 44;
                                        connectMap240 = new int *[mapEntryTotal];
                                        errorNoHold = 45;
                                        connectMapA = new int *[mapEntryTotal];
                                        errorNoHold = 46;
                                        connectMapB = new int *[mapEntryTotal];
                                        errorNoHold = 47;
                                        connectMapC = new int *[mapEntryTotal];
                                        errorNoHold = 48;
                                        connectMapD = new int *[mapEntryTotal];
                                        errorNoHold = 49;
                                        sourceImage = new int *[mapEntryTotal];
                                        
                                        for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                                            errorNoHold = 50;
                                            connectMap200 [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 51;
                                            connectMap220 [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 52;
                                            connectMap240 [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 53;
                                            connectMapA [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 54;
                                            connectMapB [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 55;
                                            connectMapC [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 56;
                                            connectMapD [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 57;
                                            sourceImage [counter1] = new int [imageSizeTotal];
                                        }
                                        
                                        imageFileUpLoad = [[ImageFileUpLoad alloc] init];
                                        [imageFileUpLoad fileUploadMain];
                                        
                                        do{
                                        } while(subCompletionFlag == 1);
                                        
                                        if (errorNoHold != 0){
                                            errorNoHold = errorNoHold+2000;
                                            throw errorCheckThrow;
                                        }
                                    }
                                }
                                else if (mapEntryTotal != 0 && mapEntryTotal > trackingCheckInterval+1){
                                    for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                                        imageNoHoldMain [counter1*2] = 0;
                                        imageNoHoldMain [counter1*2+1] = 0;
                                    }
                                    
                                    for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                                        delete [] connectMap200 [counter1];
                                        delete [] connectMap220 [counter1];
                                        delete [] connectMap240 [counter1];
                                        delete [] connectMapA [counter1];
                                        delete [] connectMapB [counter1];
                                        delete [] connectMapC [counter1];
                                        delete [] connectMapD [counter1];
                                        delete [] sourceImage [counter1];
                                    }
                                    
                                    delete [] connectMap200;
                                    delete [] connectMap220;
                                    delete [] connectMap240;
                                    delete [] connectMapA;
                                    delete [] connectMapB;
                                    delete [] connectMapC;
                                    delete [] connectMapD;
                                    delete [] sourceImage;
                                    
                                    mapEntryTotal = trackingCheckInterval+1;
                                    int imageMainEntryCount = 0;
                                    
                                    for (int counter1 = imageNumberInt; counter1 <= imageNumberInt+trackingCheckInterval; counter1++){
                                        imageNoHoldMain [imageMainEntryCount] = counter1, imageMainEntryCount++;
                                        imageNoHoldMain [imageMainEntryCount] = 0, imageMainEntryCount++;
                                    }
                                    
                                    mapPositionPointer = 0;
                                    mapPositionPointerCurrent = 1;
                                    
                                    int imageSizeTotal = imageDimension*imageDimension+1;
                                    
                                    errorNoHold = 58;
                                    connectMap200 = new int *[mapEntryTotal];
                                    errorNoHold = 59;
                                    connectMap220 = new int *[mapEntryTotal];
                                    errorNoHold = 60;
                                    connectMap240 = new int *[mapEntryTotal];
                                    errorNoHold = 61;
                                    connectMapA = new int *[mapEntryTotal];
                                    errorNoHold = 62;
                                    connectMapB = new int *[mapEntryTotal];
                                    errorNoHold = 63;
                                    connectMapC = new int *[mapEntryTotal];
                                    errorNoHold = 64;
                                    connectMapD = new int *[mapEntryTotal];
                                    errorNoHold = 65;
                                    sourceImage = new int *[mapEntryTotal];
                                    
                                    for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                                        errorNoHold = 66;
                                        connectMap200 [counter1] = new int [imageSizeTotal];
                                        errorNoHold = 67;
                                        connectMap220 [counter1] = new int [imageSizeTotal];
                                        errorNoHold = 68;
                                        connectMap240 [counter1] = new int [imageSizeTotal];
                                        errorNoHold = 69;
                                        connectMapA [counter1] = new int [imageSizeTotal];
                                        errorNoHold = 70;
                                        connectMapB [counter1] = new int [imageSizeTotal];
                                        errorNoHold = 71;
                                        connectMapC [counter1] = new int [imageSizeTotal];
                                        errorNoHold = 72;
                                        connectMapD [counter1] = new int [imageSizeTotal];
                                        errorNoHold = 73;
                                        sourceImage [counter1] = new int [imageSizeTotal];
                                    }
                                    
                                    imageFileUpLoad = [[ImageFileUpLoad alloc] init];
                                    [imageFileUpLoad fileUploadMain];
                                    
                                    do{
                                    } while(subCompletionFlag == 1);
                                    
                                    if (errorNoHold != 0){
                                        errorNoHold = errorNoHold+2000;
                                        throw errorCheckThrow;
                                    }
                                }
                                else if (currentTreatmentNameHold != treatmentNameHold){
                                    for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                                        imageNoHoldMain [counter1*2] = 0;
                                        imageNoHoldMain [counter1*2+1] = 0;
                                    }
                                    
                                    for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                                        delete [] connectMap200 [counter1];
                                        delete [] connectMap220 [counter1];
                                        delete [] connectMap240 [counter1];
                                        delete [] connectMapA [counter1];
                                        delete [] connectMapB [counter1];
                                        delete [] connectMapC [counter1];
                                        delete [] connectMapD [counter1];
                                        delete [] sourceImage [counter1];
                                    }
                                    
                                    delete [] connectMap200;
                                    delete [] connectMap220;
                                    delete [] connectMap240;
                                    delete [] connectMapA;
                                    delete [] connectMapB;
                                    delete [] connectMapC;
                                    delete [] connectMapD;
                                    delete [] sourceImage;
                                    
                                    currentTreatmentNameHold = treatmentNameHold;
                                    
                                    string extension;
                                    
                                    if (imageNo == 0) extension = to_string(imageNumberInt);
                                    else extension = to_string(imageNo);
                                    
                                    if (extension.length() == 1) extension = "000"+extension;
                                    else if (extension.length() == 2) extension = "00"+extension;
                                    else if (extension.length() == 3) extension = "0"+extension;
                                    
                                    string sourceImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+".tif";
                                    
                                    fin.open(sourceImagePath.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        unsigned long stripFirstAddress = 0;
                                        unsigned long stripByteCountAddress = 0;
                                        unsigned long nextAddress = 0;
                                        unsigned long headPosition = 0;
                                        unsigned long stripEntry = 0;
                                        
                                        double xPositionCV = 0;
                                        double yPositionCV = 0;
                                        
                                        int imageWidth = 0;
                                        int imageHeight = 0;
                                        int imageBit = 0; //Check 8, 16
                                        int imageCompression = 0; //Check 1
                                        int photoMetric = 0; //Check 0, 1, 2
                                        int endianType = 0;
                                        int samplePerPix = 0;
                                        int dataConversion [4];
                                        int numberOfLayers = 0;
                                        
                                        tifImageColorGray = 0;
                                        
                                        size1 = 0;
                                        size2 = 0;
                                        checkFlag = 0;
                                        
                                        for (int counter1 = 0; counter1 < 6; counter1++){
                                            sizeForCopy = 0;
                                            
                                            if (stat(sourceImagePath.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                            }
                                            
                                            if (sizeForCopy != 0){
                                                if (counter1 == 0) size1 = sizeForCopy;
                                                else if (counter1 == 1) size2 = sizeForCopy;
                                                else if (counter1 == 2){
                                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                        checkFlag = 1;
                                                        break;
                                                    }
                                                    else{
                                                        
                                                        size1 = 0;
                                                        size2 = 0;
                                                        usleep (50000);
                                                    }
                                                }
                                                else if (counter1 == 3) size1 = sizeForCopy;
                                                else if (counter1 == 4) size2 = sizeForCopy;
                                                else if (counter1 == 5){
                                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                        checkFlag = 1;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (checkFlag == 0){
                                            errorNoHold = 1009;
                                            throw errorCheckThrow;
                                        }
                                        
                                        if (checkFlag == 1){
                                            errorNoHold = 74;
                                            fileReadArray = new uint8_t [sizeForCopy+50];
                                            fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                                            
                                            fin.read((char*)fileReadArray, sizeForCopy+50);
                                            fin.close();
                                            
                                            dataConversion [0] = fileReadArray [0];
                                            dataConversion [1] = fileReadArray [1];
                                            
                                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                            else endianType = 0;
                                            
                                            headPosition = 0;
                                            
                                            if (endianType == 1){
                                                dataConversion [0] = fileReadArray [7];
                                                dataConversion [1] = fileReadArray [6];
                                                dataConversion [2] = fileReadArray [5];
                                                dataConversion [3] = fileReadArray [4];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            else if (endianType == 0){
                                                dataConversion [0] = fileReadArray [4];
                                                dataConversion [1] = fileReadArray [5];
                                                dataConversion [2] = fileReadArray [6];
                                                dataConversion [3] = fileReadArray [7];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            
                                            if (endianType == 1){
                                                tiffFileRead = [[TiffFileRead alloc] init];
                                                [tiffFileRead tiffReadLargeEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPositionCV:&yPositionCV:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                                
                                                if (photoMetric == 2) tifImageColorGray = 1;
                                                else if (photoMetric == 0) tifImageColorGray = 0;
                                                
                                                imageDimension = imageWidth;
                                            }
                                            else if (endianType == 0){
                                                tiffFileRead = [[TiffFileRead alloc] init];
                                                [tiffFileRead tiffReadSmallEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPositionCV:&yPositionCV:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                                
                                                if (photoMetric == 2) tifImageColorGray = 1;
                                                else if (photoMetric == 0) tifImageColorGray = 0;
                                                
                                                imageDimension = imageWidth;
                                            }
                                            
                                            delete [] fileReadArray;
                                        }
                                    }
                                    else{
                                        
                                        sourceImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+".bmp";
                                        
                                        int bitPosition = 0;
                                        imageDimension = 512;
                                        int bitData = 0;
                                        int verticalBit [4];
                                        
                                        fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            while ((bitData = fin.get()) != EOF){
                                                if (bitPosition == 22) verticalBit [0] = bitData;
                                                if (bitPosition == 23) verticalBit [1] = bitData;
                                                if (bitPosition == 24) verticalBit [2] = bitData;
                                                if (bitPosition == 25){
                                                    verticalBit [3] = bitData;
                                                    
                                                    imageDimension = verticalBit [3]*16777216+verticalBit [2]*65536+verticalBit [1]*256+verticalBit [0];
                                                    
                                                    break;
                                                }
                                                
                                                bitPosition++;
                                            }
                                            
                                            fin.close();
                                        }
                                        else{
                                            
                                            errorNoHold = 1010;
                                            throw errorCheckThrow;
                                        }
                                    }
                                    
                                    if (trackingLimit == -2){
                                        imageNoHoldMain [0] = ifStartHold-1;
                                        imageNoHoldMain [1] = 3;
                                        
                                        mapEntryTotal = 1;
                                        mapPositionPointer = 0;
                                        mapPositionPointerCurrent = -1;
                                        mainMapLoadStatus = 1;
                                        
                                        int imageSizeTotal = imageDimension*imageDimension+1;
                                        
                                        errorNoHold = 75;
                                        connectMap200 = new int *[mapEntryTotal];
                                        errorNoHold = 76;
                                        connectMap220 = new int *[mapEntryTotal];
                                        errorNoHold = 77;
                                        connectMap240 = new int *[mapEntryTotal];
                                        errorNoHold = 78;
                                        connectMapA = new int *[mapEntryTotal];
                                        errorNoHold = 79;
                                        connectMapB = new int *[mapEntryTotal];
                                        errorNoHold = 80;
                                        connectMapC = new int *[mapEntryTotal];
                                        errorNoHold = 81;
                                        connectMapD = new int *[mapEntryTotal];
                                        errorNoHold = 82;
                                        sourceImage = new int *[mapEntryTotal];
                                        
                                        for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                                            errorNoHold = 83;
                                            connectMap200 [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 84;
                                            connectMap220 [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 85;
                                            connectMap240 [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 86;
                                            connectMapA [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 87;
                                            connectMapB [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 88;
                                            connectMapC [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 89;
                                            connectMapD [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 90;
                                            sourceImage [counter1] = new int [imageSizeTotal];
                                        }
                                        
                                        imageFileUpLoad = [[ImageFileUpLoad alloc] init];
                                        [imageFileUpLoad fileUploadMain];
                                        
                                        do{
                                        } while (subCompletionFlag == 1);
                                        
                                        if (errorNoHold != 0){
                                            errorNoHold = errorNoHold+2000;
                                            throw errorCheckThrow;
                                        }
                                    }
                                    else if (trackingLimit == -1){
                                        imageNoHoldMain [0] = imageNumberInt;
                                        imageNoHoldMain [1] = 3;
                                        
                                        mapEntryTotal = 1;
                                        mapPositionPointer = 0;
                                        mapPositionPointerCurrent = -1;
                                        mainMapLoadStatus = 1;
                                        
                                        int imageSizeTotal = imageDimension*imageDimension+1;
                                        
                                        errorNoHold = 91;
                                        connectMap200 = new int *[mapEntryTotal];
                                        errorNoHold = 92;
                                        connectMap220 = new int *[mapEntryTotal];
                                        errorNoHold = 93;
                                        connectMap240 = new int *[mapEntryTotal];
                                        errorNoHold = 94;
                                        connectMapA = new int *[mapEntryTotal];
                                        errorNoHold = 95;
                                        connectMapB = new int *[mapEntryTotal];
                                        errorNoHold = 96;
                                        connectMapC = new int *[mapEntryTotal];
                                        errorNoHold = 97;
                                        connectMapD = new int *[mapEntryTotal];
                                        errorNoHold = 98;
                                        sourceImage = new int *[mapEntryTotal];
                                        
                                        for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                                            errorNoHold = 99;
                                            connectMap200 [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 100;
                                            connectMap220 [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 101;
                                            connectMap240 [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 102;
                                            connectMapA [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 103;
                                            connectMapB [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 104;
                                            connectMapC [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 105;
                                            connectMapD [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 106;
                                            sourceImage [counter1] = new int [imageSizeTotal];
                                        }
                                        
                                        imageFileUpLoad = [[ImageFileUpLoad alloc] init];
                                        [imageFileUpLoad fileUploadMain];
                                        
                                        do{
                                        } while (subCompletionFlag == 1);
                                        
                                        if (errorNoHold != 0){
                                            errorNoHold = errorNoHold+2000;
                                            throw errorCheckThrow;
                                        }
                                    }
                                    else{
                                        
                                        mapEntryTotal = trackingCheckInterval+1;
                                        int imageMainEntryCount = 0;
                                        
                                        for (int counter1 = imageNumberInt; counter1 <= imageNumberInt+trackingCheckInterval; counter1++){
                                            imageNoHoldMain [imageMainEntryCount] = counter1, imageMainEntryCount++;
                                            imageNoHoldMain [imageMainEntryCount] = 3, imageMainEntryCount++;
                                        }
                                        
                                        mapPositionPointer = 0;
                                        mapPositionPointerCurrent = 1;
                                        
                                        int imageSizeTotal = imageDimension*imageDimension+1;
                                        
                                        errorNoHold = 107;
                                        connectMap200 = new int *[mapEntryTotal];
                                        errorNoHold = 108;
                                        connectMap220 = new int *[mapEntryTotal];
                                        errorNoHold = 109;
                                        connectMap240 = new int *[mapEntryTotal];
                                        errorNoHold = 110;
                                        connectMapA = new int *[mapEntryTotal];
                                        errorNoHold = 111;
                                        connectMapB = new int *[mapEntryTotal];
                                        errorNoHold = 112;
                                        connectMapC = new int *[mapEntryTotal];
                                        errorNoHold = 113;
                                        connectMapD = new int *[mapEntryTotal];
                                        errorNoHold = 114;
                                        sourceImage = new int *[mapEntryTotal];
                                        
                                        for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                                            errorNoHold = 115;
                                            connectMap200 [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 116;
                                            connectMap220 [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 117;
                                            connectMap240 [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 118;
                                            connectMapA [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 119;
                                            connectMapB [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 120;
                                            connectMapC [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 121;
                                            connectMapD [counter1] = new int [imageSizeTotal];
                                            errorNoHold = 122;
                                            sourceImage [counter1] = new int [imageSizeTotal];
                                        }
                                        
                                        imageFileUpLoad = [[ImageFileUpLoad alloc] init];
                                        [imageFileUpLoad fileUploadMain];
                                        
                                        do{
                                        } while (subCompletionFlag == 1);
                                        
                                        if (errorNoHold != 0){
                                            errorNoHold = errorNoHold+2000;
                                            throw errorCheckThrow;
                                        }
                                    }
                                }
                                else if (mapEntryTotal == trackingCheckInterval+1 && currentTreatmentNameHold == treatmentNameHold){
                                    //imageNoHoldMain [counter1*2+1] = 0; ---available
                                    //imageNoHoldMain [counter1*2+1] = 1; ---set
                                    //imageNoHoldMain [counter1*2+1] = 2; ---checked--change to 1 after file upload
                                    //imageNoHoldMain [counter1*2+1] = 3; ---read Position, set 1 after reading
                                    
                                    if (trackingLimit == -2){
                                        mapPositionPointer = 0;
                                        mapPositionPointerCurrent = -1;
                                        
                                        int imageFind = 0;
                                        
                                        for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                                            if (imageNoHoldMain [counter1*2] == ifStartHold-1){
                                                imageNoHoldMain [counter1*2+1] = 2;
                                                imageFind = 1;
                                                break;
                                            }
                                        }
                                        
                                        if (imageFind == 1){
                                            for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                                                if (imageNoHoldMain [counter1*2+1] != 2)imageNoHoldMain [counter1*2+1] = 0;
                                                
                                                if (imageNoHoldMain [counter1*2+1] == 2){
                                                    imageNoHoldMain [counter1*2+1] = 1;
                                                    mapPositionPointer = counter1;
                                                }
                                            }
                                        }
                                        else{
                                            
                                            imageNoHoldMain [0] = ifStartHold-1;
                                            imageNoHoldMain [1] = 3;
                                            
                                            for (int counter1 = 1; counter1 < mapEntryTotal; counter1++) imageNoHoldMain [counter1*2+1] = 0;
                                            
                                            imageFileUpLoad = [[ImageFileUpLoad alloc] init];
                                            [imageFileUpLoad fileUploadMain];
                                            
                                            if (errorNoHold != 0){
                                                errorNoHold = errorNoHold+2000;
                                                throw errorCheckThrow;
                                            }
                                        }
                                    }
                                    else if (trackingLimit == -1){
                                        mapPositionPointer = 0;
                                        mapPositionPointerCurrent = -1;
                                        
                                        int imageFind = 0;
                                        
                                        for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                                            if (imageNoHoldMain [counter1*2] == imageNumberInt){
                                                imageNoHoldMain [counter1*2+1] = 2;
                                                imageFind = 1;
                                                break;
                                            }
                                        }
                                        
                                        if (imageFind == 1){
                                            for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                                                if (imageNoHoldMain [counter1*2+1] != 2)imageNoHoldMain [counter1*2+1] = 0;
                                                
                                                if (imageNoHoldMain [counter1*2+1] == 2){
                                                    imageNoHoldMain [counter1*2+1] = 1;
                                                    mapPositionPointer = counter1;
                                                }
                                            }
                                        }
                                        else{
                                            
                                            imageNoHoldMain [0] = imageNumberInt;
                                            imageNoHoldMain [1] = 3;
                                            
                                            for (int counter1 = 1; counter1 < mapEntryTotal; counter1++) imageNoHoldMain [counter1*2+1] = 0;
                                            
                                            imageFileUpLoad = [[ImageFileUpLoad alloc] init];
                                            [imageFileUpLoad fileUploadMain];
                                            
                                            do{
                                            } while (subCompletionFlag == 1);
                                            
                                            if (errorNoHold != 0){
                                                errorNoHold = errorNoHold+2000;
                                                throw errorCheckThrow;
                                            }
                                        }
                                    }
                                    else{
                                        
                                        mapPositionPointer = 0;
                                        
                                        for (int counter1 = imageNumberInt; counter1 <= imageNumberInt+trackingCheckInterval; counter1++){
                                            for (int counter2 = 0; counter2 < mapEntryTotal; counter2++){
                                                if (imageNoHoldMain [counter2*2] == counter1){
                                                    imageNoHoldMain [counter2*2+1] = 2;
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        int findImagePoint = 0;
                                        int fileReadFlag = 0;
                                        
                                        for (int counter1 = imageNumberInt; counter1 <= imageNumberInt+trackingCheckInterval; counter1++){
                                            findImagePoint = 0;
                                            
                                            for (int counter2 = 0; counter2 < mapEntryTotal; counter2++){
                                                if (imageNoHoldMain [counter2*2] == counter1 && imageNoHoldMain [counter2*2+1] == 2){
                                                    findImagePoint = 1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findImagePoint == 0){
                                                for (int counter2 = 0; counter2 < mapEntryTotal; counter2++){
                                                    if (imageNoHoldMain [counter2*2+1] == 1){
                                                        imageNoHoldMain [counter2*2] = counter1;
                                                        imageNoHoldMain [counter2*2+1] = 3;
                                                        fileReadFlag = 1;
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (fileReadFlag == 0){
                                            for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                                                if (imageNoHoldMain [counter1*2+1] != 2) imageNoHoldMain [counter1*2+1] = 0;
                                                if (imageNoHoldMain [counter1*2+1] == 2) imageNoHoldMain [counter1*2+1] = 1;
                                            }
                                            
                                            for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                                                if (imageNoHoldMain [counter1*2] == imageNumberInt) mapPositionPointer = counter1;
                                                if (imageNoHoldMain [counter1*2] == imageNumberInt+1) mapPositionPointerCurrent = counter1;
                                            }
                                        }
                                        else{
                                            
                                            for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                                                if (imageNoHoldMain [counter1*2] == imageNumberInt) mapPositionPointer = counter1;
                                                if (imageNoHoldMain [counter1*2] == imageNumberInt+1) mapPositionPointerCurrent = counter1;
                                            }
                                            
                                            imageFileUpLoad = [[ImageFileUpLoad alloc] init];
                                            [imageFileUpLoad fileUploadMain];
                                            
                                            do{
                                            } while(subCompletionFlag == 1);
                                            
                                            if (errorNoHold != 0){
                                                errorNoHold = errorNoHold+2000;
                                                throw errorCheckThrow;
                                            }
                                        }
                                    }
                                }
                                
                                trackingSet = [[TrackingSet alloc] init];
                                int uploadCheck = [trackingSet trackingSetMain:processTime:imageNo];
                                
                                do{
                                } while(subCompletionFlag == 1);
                                
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                                
                                string extension = to_string(timeOneHold+10); //====First Round Image number check, need image no 11 if timeOne = 1=========
                                
                                if (extension.length() == 1) extension = "000"+extension;
                                else if (extension.length() == 2) extension = "00"+extension;
                                else if (extension.length() == 3) extension = "0"+extension;
                                
                                string connectDataPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+extension+"_"+analysisImageName+"_"+treatmentNameHold+"_MasterData";
                                
                                int processTimeTenCheck = 0;
                                
                                if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                                    processTimeTenCheck = 1;
                                }
                                
                                //--------Previous-Upload OK, start process--------
                                if (uploadCheck == 3 || (uploadCheck == 15 && processTimeTenCheck == 1)){
                                    int connectFindResult = 0;
                                    int processType = 1;
                                    tableInterpretation = [[TableInterpretation alloc] init];
                                    connectFindResult = [tableInterpretation interpretationFirst:processType];
                                    
                                    do{
                                    } while (subCompletionFlag3 == 1);
                                    
                                    if (errorNoHold != 0){
                                        errorNoHold = errorNoHold+2000;
                                        throw errorCheckThrow;
                                    }
                                    
                                    //for (int counterA = 0; counterA < groupInfoPreviousCount/5; counterA++){
                                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayGroupInfoPrevious [counterA*5+counterB];
                                    //    cout<<" arrayGroupInfoPrevious "<<counterA<<" "<<endl;
                                    //}
                                    
                                    if (connectFindResult == 1){
                                        connectDataPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageData";
                                        
                                        size1 = 0;
                                        size2 = 0;
                                        checkFlag = 0;
                                        
                                        for (int counter1 = 0; counter1 < 6; counter1++){
                                            sizeForCopy = 0;
                                            
                                            if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                            }
                                            
                                            if (sizeForCopy != 0){
                                                if (counter1 == 0) size1 = sizeForCopy;
                                                else if (counter1 == 1) size2 = sizeForCopy;
                                                else if (counter1 == 2){
                                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                        checkFlag = 1;
                                                        break;
                                                    }
                                                    else{
                                                        
                                                        size1 = 0;
                                                        size2 = 0;
                                                        usleep (50000);
                                                    }
                                                }
                                                else if (counter1 == 3) size1 = sizeForCopy;
                                                else if (counter1 == 4) size2 = sizeForCopy;
                                                else if (counter1 == 5){
                                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                        checkFlag = 1;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (checkFlag == 0){
                                            errorNoHold = 1011;
                                            throw errorCheckThrow;
                                        }
                                        
                                        if (checkFlag == 1){
                                            if (lineageDataStatus == 0){
                                                errorNoHold = 123;
                                                arrayLineageData = new int [sizeForCopy+50];
                                                lineageDataCount = 0;
                                                lineageDataStatus = 1;
                                                lineageDataSizeHold = (int)sizeForCopy+50;
                                            }
                                            else if (lineageDataStatus == 1 && lineageDataSizeHold < sizeForCopy){
                                                delete [] arrayLineageData;
                                                
                                                errorNoHold = 124;
                                                arrayLineageData = new int [sizeForCopy+50];
                                                lineageDataCount = 0;
                                                lineageDataSizeHold = (int)sizeForCopy+50;
                                            }
                                            else lineageDataCount = 0;
                                            
                                            fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                                            
                                            if (fin.is_open()){
                                                errorNoHold = 125;
                                                uploadTemp = new uint8_t [sizeForCopy+50];
                                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                                
                                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0 || (finData [0] = uploadTemp [sizeForCopy-21]) != 0 || (finData [0] = uploadTemp [sizeForCopy-22]) != 0 || (finData [0] = uploadTemp [sizeForCopy-23]) != 0 || (finData [0] = uploadTemp [sizeForCopy-24]) != 0 || (finData [0] = uploadTemp [sizeForCopy-25]) != 0){
                                                    usleep(50000);
                                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                                    
                                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0 || (finData [0] = uploadTemp [sizeForCopy-21]) != 0 || (finData [0] = uploadTemp [sizeForCopy-22]) != 0 || (finData [0] = uploadTemp [sizeForCopy-23]) != 0 || (finData [0] = uploadTemp [sizeForCopy-24]) != 0 || (finData [0] = uploadTemp [sizeForCopy-25]) != 0){
                                                        usleep(50000);
                                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                                        
                                                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0 || (finData [0] = uploadTemp [sizeForCopy-21]) != 0 || (finData [0] = uploadTemp [sizeForCopy-22]) != 0 || (finData [0] = uploadTemp [sizeForCopy-23]) != 0 || (finData [0] = uploadTemp [sizeForCopy-24]) != 0 || (finData [0] = uploadTemp [sizeForCopy-25]) != 0){
                                                            errorNoHold = 1012;
                                                            throw errorCheckThrow;
                                                        }
                                                    }
                                                }
                                                
                                                fin.close();
                                                
                                                readPosition = 0;
                                                stepCount = 0;
                                                
                                                do{
                                                    
                                                    if (stepCount == 0){
                                                        finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                                                        finData [1] = uploadTemp [readPosition], readPosition++;
                                                        finData [2] = uploadTemp [readPosition], readPosition++; //--2 X position
                                                        finData [3] = uploadTemp [readPosition], readPosition++; //--3 +-
                                                        finData [4] = uploadTemp [readPosition], readPosition++;
                                                        finData [5] = uploadTemp [readPosition], readPosition++; //--4 Y position
                                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                                        finData [7] = uploadTemp [readPosition], readPosition++; //--5 Time point
                                                        finData [8] = uploadTemp [readPosition], readPosition++; //--6 Event type
                                                        finData [9] = uploadTemp [readPosition], readPosition++; //--7 +-
                                                        finData [10] = uploadTemp [readPosition], readPosition++;
                                                        finData [11] = uploadTemp [readPosition], readPosition++;
                                                        finData [12] = uploadTemp [readPosition], readPosition++;
                                                        finData [13] = uploadTemp [readPosition], readPosition++; //--8 Next cell/fuse no
                                                        finData [14] = uploadTemp [readPosition], readPosition++; //--9 +-
                                                        finData [15] = uploadTemp [readPosition], readPosition++;
                                                        finData [16] = uploadTemp [readPosition], readPosition++;
                                                        finData [17] = uploadTemp [readPosition], readPosition++;
                                                        finData [18] = uploadTemp [readPosition], readPosition++; //--10 Cell no
                                                        finData [19] = uploadTemp [readPosition], readPosition++;
                                                        finData [20] = uploadTemp [readPosition], readPosition++;
                                                        finData [21] = uploadTemp [readPosition], readPosition++; //--11 Ling no
                                                        finData [22] = uploadTemp [readPosition], readPosition++;
                                                        finData [23] = uploadTemp [readPosition], readPosition++;
                                                        finData [24] = uploadTemp [readPosition], readPosition++; //--12 Ling no Fuse
                                                        
                                                        if (finData [0] == 1) finData [2] = (finData [1]*256+finData [2])*-1;
                                                        else finData [2] = finData [1]*256+finData [2];
                                                        
                                                        if (finData [3] == 1) finData [5] = (finData [4]*256+finData [5])*-1;
                                                        else finData [5] = finData [4]*256+finData [5];
                                                        
                                                        finData [7] = finData [6]*256+finData [7];
                                                        
                                                        if (finData [9] == 1) finData [13] = (finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13])*-1;
                                                        else finData [13] = finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13];
                                                        
                                                        if (finData [14] == 1) finData [18] = (finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18])*-1;
                                                        else finData [18] = finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18];
                                                        
                                                        finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                                                        finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                                                        
                                                        if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                                        else{
                                                            
                                                            arrayLineageData [lineageDataCount] = finData [2], lineageDataCount++;
                                                            arrayLineageData [lineageDataCount] = finData [5], lineageDataCount++;
                                                            arrayLineageData [lineageDataCount] = finData [7], lineageDataCount++;
                                                            arrayLineageData [lineageDataCount] = finData [8], lineageDataCount++;
                                                            arrayLineageData [lineageDataCount] = finData [13], lineageDataCount++;
                                                            arrayLineageData [lineageDataCount] = finData [18], lineageDataCount++;
                                                            arrayLineageData [lineageDataCount] = finData [21], lineageDataCount++;
                                                            arrayLineageData [lineageDataCount] = finData [24], lineageDataCount++;
                                                        }
                                                    }
                                                    
                                                } while (stepCount != 3);
                                                
                                                delete [] uploadTemp;
                                            }
                                            else{
                                                
                                                errorNoHold = 1013;
                                                throw errorCheckThrow;
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
                                        //    cout<<" arrayLineageData "<<counterA<<endl;
                                        //}
                                        
                                        string connectStartEndPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStartEnd";
                                        
                                        if (stat(connectStartEndPath.c_str(), &sizeOfFile) == -1){
                                            errorNoHold = 1014;
                                            throw errorCheckThrow;
                                        }
                                        
                                        if (stat(connectStartEndPath.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                            
                                            if (lineageStartEndStatus == 0){
                                                errorNoHold = 126;
                                                arrayLineageStartEnd = new int [sizeForCopy+50];
                                                lineageStartEndCount = 0;
                                                lineageStartEndStatus = 1;
                                                lineageStartEndSizeHold = (int)sizeForCopy+50;
                                            }
                                            else if (lineageStartEndStatus == 1 && lineageStartEndSizeHold < sizeForCopy){
                                                delete [] arrayLineageStartEnd;
                                                
                                                errorNoHold = 127;
                                                arrayLineageStartEnd = new int [sizeForCopy+50];
                                                lineageStartEndCount = 0;
                                                lineageStartEndSizeHold = (int)sizeForCopy+50;
                                            }
                                            else lineageStartEndCount = 0;
                                            
                                            fin.open(connectStartEndPath.c_str(), ios::in | ios::binary);
                                            
                                            if (fin.is_open()){
                                                errorNoHold = 128;
                                                char *uploadTemp2 = new char [sizeForCopy+50];
                                                fin.read((char*)uploadTemp2, sizeForCopy+50);
                                                fin.close();
                                                
                                                string dataString = "";
                                                readPosition = 0;
                                                
                                                do{
                                                    
                                                    if (uploadTemp2 [readPosition] != 10) dataString = dataString+uploadTemp2 [readPosition];
                                                    else if (dataString != "End"){
                                                        arrayLineageStartEnd [lineageStartEndCount] = atoi(dataString.c_str()), lineageStartEndCount++;
                                                        dataString = "";
                                                    }
                                                    
                                                    readPosition++;
                                                    
                                                    if ((long)readPosition > sizeForCopy){
                                                        break;
                                                    }
                                                    
                                                } while (dataString != "End");
                                                
                                                delete [] uploadTemp2;
                                                
                                                if (dataString != "End"){
                                                    errorNoHold = 1015;
                                                    throw errorCheckThrow;
                                                }
                                            }
                                            else{
                                                
                                                errorNoHold = 1016;
                                                throw errorCheckThrow;
                                            }
                                        }
                                        
                                        timeEventEntryHold = 0;
                                        eventTypeEntryHold = 0;
                                        
                                        for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                                            if (arrayLineageStartEnd [counter1*8] == cellLineageExtractInt && arrayLineageStartEnd [counter1*8+1] == cellNoHoldExtractInt){
                                                for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                                                    if (timeEventEntryHold == 0){
                                                        timeEventEntryHold = arrayLineageData [counter2*8+2];
                                                        eventTypeEntryHold = arrayLineageData [counter2*8+3];
                                                    }
                                                }
                                            }
                                        }
                                        
                                        for (int counter1 = 0; counter1 < mitosisParameterCount/4; counter1++){
                                            if (arrayMitosisParameter [counter1*4+3] == 10) mitosisStatusHold = 1;
                                        }
                                        
                                        if (mitosisStatusHold == 1) [mitosisStatusDisplay setStringValue:@"Mitosis"];
                                        else [mitosisStatusDisplay setStringValue:@"nil"];
                                        
                                        string connectClearPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold;
                                        
                                        string entry;
                                        string removeFilePath;
                                        
                                        DIR *dir;
                                        struct dirent *dent;
                                        
                                        dir = opendir(connectClearPath.c_str());
                                        
                                        if (dir != NULL){
                                            fileHandlingCount = 0;
                                            
                                            while ((dent = readdir(dir))){
                                                entry = dent -> d_name;
                                                
                                                if (fileHandlingCount+5 > fileHandlingLimit) [self fileHandlingUpDate];
                                                arrayFileHandling [fileHandlingCount] = entry, fileHandlingCount++;
                                            }
                                            
                                            closedir(dir);
                                            
                                            for (int counter1 = 0; counter1 < fileHandlingCount; counter1++){
                                                entry = arrayFileHandling [counter1];
                                                
                                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                                    int findFile1 = (int)entry.find("ConnectLineageRelTemp");
                                                    int findFile2 = (int)entry.find("CutTemp");
                                                    int findFile3 = (int)entry.find("GCCurrentTemp");
                                                    int findFile4 = (int)entry.find("MasterDataTemp");
                                                    int findFile5 = (int)entry.find("RevisedTempMap");
                                                    int findFile6 = (int)entry.find("StatusTemp");
                                                    int findFile7 = (int)entry.find("LinkDataTemp");
                                                    int findFile8 = (int)entry.find("ExtendAreaDataTemp");
                                                    int findFile9 = (int)entry.find("ExtendLineDataTemp");
                                                    int findFile10 = (int)entry.find("EventTemp");
                                                    int findFile11 = (int)entry.find("MitosisDataTemp");
                                                    int findFile12 = (int)entry.find("GCCenterInfo");
                                                    
                                                    if (findFile1 != -1 || findFile2 != -1 || findFile3 != -1 || findFile4 != -1 || findFile5 != -1 || findFile6 != -1 || findFile7 != -1 || findFile8 != -1 || findFile9 != -1 || findFile10 != -1 || findFile11 != -1 || findFile12 != -1){
                                                        removeFilePath = connectClearPath+"/"+entry;
                                                        remove (removeFilePath.c_str());
                                                    }
                                                }
                                            }
                                        }
                                        
                                        returnMessage = "";
                                        returnMessageExt = "";
                                        retryInfoHold = 0;
                                        outsideSettingFlag = 0;
                                        
                                        roundStatus = 2;
                                        firstCommunication = 7;
                                    }
                                    else{
                                        
                                        returnMessage = "";
                                        returnMessageTime = to_string(imageNumberInt);
                                        returnMessageExt = ""; //------Loading Error------
                                        
                                        emergencyExit = 1;
                                        firstCommunication = 20;
                                    }
                                }
                                else{
                                    
                                    if (uploadCheck == 15 && processTimeTenCheck == 0){
                                        returnMessage = "TT";
                                        returnMessageTime = to_string(imageNumberInt);
                                        returnMessageExt = "0"; //------Non Selected and less than 10 image no, ------
                                        
                                        firstCommunication = 3;
                                    }
                                    else if (uploadCheck != 3){
                                        returnMessage = "";
                                        returnMessageTime = "";
                                        returnMessageExt = ""; //------Loading Error------
                                        
                                        emergencyExit = 1;
                                        firstCommunication = 20;
                                    }
                                }
                            }
                            else{
                                
                                returnMessage = "MS";
                                returnMessageTime = "0";
                                returnMessageExt = "0"; //------At Least One Mitosis Data Need------
                                
                                emergencyExit = 1;
                                firstCommunication = 3;
                            }
                        }
                        else{
                            
                            remove (connectAmendPath.c_str());
                            
                            string extension = to_string(imageNumberInt);
                            
                            returnMessage = "AM";
                            returnMessageTime = extension;
                            returnMessageExt = "0"; //------Amend missing------
                            
                            firstCommunication = 3;
                        }
                    }
                    else{
                        
                        remove (connectAmendPath.c_str());
                        
                        string extension = to_string(imageNumberInt);
                        
                        returnMessage = "AM";
                        returnMessageTime = extension;
                        returnMessageExt = "0"; //------Amend missing------
                        
                        firstCommunication = 3;
                    }
                }
                else{
                    
                    remove (connectAmendPath.c_str());
                    
                    string extension = to_string(imageNumberInt);
                    
                    returnMessage = "AM";
                    returnMessageTime = extension;
                    returnMessageExt = "0"; //------Amend missing------
                    
                    firstCommunication = 3;
                }
                
                sleepingPosition = 2;
                errorNoHold = 0;
                backSaveOff = 1;
            }
            catch (int errorCheckThrow){
                if (errorNoHold >= 1000 && errorNoHold < 2000){
                    string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
                    mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    time_t rawtime;
                    struct tm * timeinfo;
                    time (&rawtime);
                    timeinfo = localtime ( &rawtime );
                    
                    int tsec = timeinfo -> tm_sec;
                    int tmin = timeinfo -> tm_min;
                    int thour = timeinfo -> tm_hour;
                    int tday = timeinfo -> tm_mday;
                    int tmon = timeinfo -> tm_mon;
                    
                    string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
                    
                    errorPath = errorPath+"/Cell_CarvingCont02 "+dateTime;
                    
                    ofstream oin2;
                    oin2.open(errorPath.c_str(), ios::out);
                    oin2<<"Controller"<<endl;
                    oin2<<errorNoHold<<endl;
                    oin2<<analysisImageName<<endl;
                    oin2<<analysisID<<endl;
                    oin2<<treatmentNameHold<<endl;
                    oin2<<cellLineageNoHold<<endl;
                    oin2<<cellNoHold<<endl;
                    oin2<<dateTime<<endl;
                    
                    if (errorNoHold == 1000) oin2<<"lineDataAmend reading error"<<endl;
                    else if (errorNoHold == 1001) oin2<<"LineageTrackingCurrent.dat reading error"<<endl;
                    else if (errorNoHold == 1002) oin2<<"Vertical/Horizontal dimension error"<<endl;
                    else if (errorNoHold == 1003) oin2<<"CutOffData reading error"<<endl;
                    else if (errorNoHold == 1004) oin2<<"MitosisData reading error"<<endl;
                    else if (errorNoHold == 1005) oin2<<"MitosisData open-error"<<endl;
                    else if (errorNoHold == 1006) oin2<<"Mitosis.dat open-error"<<endl;
                    else if (errorNoHold == 1007 || errorNoHold == 1009) oin2<<"STimage-tif reading error"<<endl;
                    else if (errorNoHold == 1008 || errorNoHold == 1010) oin2<<"STimage-bmp reading error"<<endl;
                    else if (errorNoHold == 1011) oin2<<"LineageData reading error"<<endl;
                    else if (errorNoHold == 1012) oin2<<"LineageData uploading error"<<endl;
                    else if (errorNoHold == 1013) oin2<<"LineageData open-error"<<endl;
                    else if (errorNoHold == 1014 || errorNoHold == 1016) oin2<<"LineageStartEnd open-error"<<endl;
                    else if (errorNoHold == 1015) oin2<<"LineageStartEnd reading error"<<endl;
                    oin2.close();
                    
                    backSaveOff = 1;
                }
                
                returnMessage = "";
                emergencyExit = 1;
                firstCommunication = 20;
                subCompletionFlag = 0;
            }
        }
        catch (bad_alloc&){
            string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
            mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            time_t rawtime;
            struct tm * timeinfo;
            time (&rawtime);
            timeinfo = localtime ( &rawtime );
            
            int tsec = timeinfo -> tm_sec;
            int tmin = timeinfo -> tm_min;
            int thour = timeinfo -> tm_hour;
            int tday = timeinfo -> tm_mday;
            int tmon = timeinfo -> tm_mon;
            
            string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
            
            errorPath = errorPath+"/Cell_CarvingCont03 "+dateTime;
            
            ofstream oin2;
            oin2.open(errorPath.c_str(), ios::out);
            oin2<<"Controller"<<endl;
            oin2<<errorNoHold<<endl;
            oin2<<analysisImageName<<endl;
            oin2<<analysisID<<endl;
            oin2<<treatmentNameHold<<endl;
            oin2<<cellLineageNoHold<<endl;
            oin2<<cellNoHold<<endl;
            oin2<<dateTime<<endl;
            oin2.close();
            
            backSaveOff = 1;
            returnMessage = "";
            emergencyExit = 1;
            firstCommunication = 20;
            subCompletionFlag = 0;
        }
    }
    
    if (firstCommunication >= 7 && firstCommunication < 10) firstCommunication++;
    if (firstCommunication == 10){
        firstCommunication = 2;
        
        if (trackingLimit > 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageProcessing object:self];
        }
        else if (trackingLimit == -1){
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageProcessingEnd object:self];
        }
        else if (trackingLimit == -2){
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageProcessingIF object:self];
        }
    }
    
    if (firstCommunication == 3){
        firstCommunication = 2;
        
        string instructionRRPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"RR_Instruction";
        string instructionRRTempPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"RR_InstructionTemp";
        
        int dataSetFlag = 0;
        
        if (exitRequest == 1 && returnMessage == ""){
            returnMessageTime = "0";
            returnMessage = "EX";
            returnMessageExt = "0";
        }
        
        if ((emergencyExit == 1 || emergencyExit == 2) && returnMessage == ""){
            returnMessageTime = "0";
            returnMessage = "EY";
            returnMessageExt = "0";
            exitRequest = 1;
        }
        else if (trackingExitCount >= restartCount && returnMessage == ""){
            returnMessageTime = "0";
            returnMessage = "EZ";
            returnMessageExt = "0";
            exitRequest = 1;
        }
        
        ofstream oin;
        
        for (int counter1 = 0; counter1 < 10; counter1++){
            oin.open(instructionRRTempPath.c_str(), ios::out);
            
            if (oin.is_open()){
                oin<<analysisImageName<<endl;
                oin<<analysisID<<endl;
                oin<<treatmentNameHold<<endl;
                oin<<cellLineageNoHold<<endl;
                oin<<cellNoHold<<endl;
                oin<<returnMessageTime<<endl;
                oin<<returnMessage<<endl;
                oin<<returnMessageExt<<endl;
                
                //cout<<analysisImageName<<" "<<analysisID<<" "<<treatmentNameHold<<" "<<cellLineageNoHold<<" "<<cellNoHold<<" "<<returnMessageTime<<" "<<returnMessage<<" "<<returnMessageExt<<" "<<fusionPartnerCount<<" return"<<endl;
                
                if (fusionPartnerCount != 0){
                    for (int counter2 = 0; counter2 < fusionPartnerCount/3; counter2++){
                        oin<<counter2+1<<endl;
                        oin<<arrayFusionPartner [counter2*3]<<endl;
                        oin<<arrayFusionPartner [counter2*3+1]<<endl;
                        oin<<arrayFusionPartner [counter2*3+2]<<endl;
                        
                        //cout<<arrayFusionPartner [counter1*3]<<" "<<arrayFusionPartner [counter1*3+1]<<" "<<arrayFusionPartner [counter1*3+2]<<" FusionPartner"<<endl;
                    }
                    
                    oin<<"ENDF"<<endl;
                }
                
                oin<<"END2"<<endl;
                oin.close();
                
                mitosisStatusHold = 0;
                
                [mitosisStatusDisplay setStringValue:@"nil"];
                
                ifstream fin;
                
                fin.open(instructionRRTempPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    fin.close();
                    
                    remove(instructionRRPath.c_str());
                    rename(instructionRRTempPath.c_str(), instructionRRPath.c_str());
                    remove(instractionCCPath.c_str());
                    
                    dataSetFlag = 1;
                    
                    sleepingCheck = 0;
                    sleepingPosition = 0;
                    
                    break;
                }
            }
        }
        
        if (fusionPartnerStatus == 1){
            delete [] arrayFusionPartner;
            fusionPartnerCount = 0;
            fusionPartnerStatus = 0;
        }
        
        if (dataSetFlag == 1 && exitRequest == 1){
            exit (0);
        }
        else if (dataSetFlag == 1) firstCommunication = 0;
        else if (dataSetFlag == 0){
            exit (0);
        }
    }
    
    if (firstCommunication == 4){
        firstCommunication = 2;
        
        //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
        //   for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
        //  cout<<" arrayEventSequence "<<counterA<<endl;
        //}
        
        try{
            
            errorNoHold = 0;
            int errorCheckThrow = 0;
            sleepingPosition = 3;
            
            string eventTempPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+analysisID+"_"+cellLineageNoHold+"_EventTemp";
            string extension;
            
            ofstream oin;
            
            if (eventSequenceCount != 0){
                oin.open(eventTempPath.c_str(), ios::out);
                
                if (oin.is_open()){
                    for (int counter1 = 0; counter1 < eventSequenceCount; counter1++){
                        int connectNumberTemp = arrayEventSequence [counter1];
                        extension = to_string(connectNumberTemp);
                        oin<<extension<<endl;
                    }
                    
                    oin<<"End"<<endl;
                    oin.close();
                }
                else{
                    
                    errorNoHold = 1010;
                    throw errorCheckThrow;
                }
            }
            
            string mitosisStatusPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+analysisID+"_"+cellLineageNoHold+"_MitosisDataTemp";
            
            if (mitosisParameterCount != 0){
                int findFlag = 0;
                
                for (int counter1 = 0; counter1 < mitosisParameterCount/4; counter1++){
                    if (findFlag == 0 && (arrayMitosisParameter [counter1*4+3] == 5)){
                        arrayMitosisParameter [counter1*4+3] = 10;
                        findFlag = 1;
                    }
                    else if (findFlag == 1) arrayMitosisParameter [counter1*4+3] = 0;
                }
                
                findFlag = 0;
                
                for (int counter1 = 0; counter1 < mitosisParameterCount/4; counter1++){
                    if (findFlag == 0 && (arrayMitosisParameter [counter1*4+3] == 8)){
                        arrayMitosisParameter [counter1*4+3] = 11;
                        findFlag = 1;
                    }
                    else if (findFlag == 1) arrayMitosisParameter [counter1*4+3] = 0;
                }
                
                //for (int counterA = 0; counterA < mitosisParameterCount/4; counterA++){
                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisParameter [counterA*4+counterB];
                //    cout<<" arrayMitosisParameter "<<counterA<<endl;
                //}
                
                oin.open(mitosisStatusPath.c_str(), ios::out);
                
                if (oin.is_open()){
                    for (int counter1 = 0; counter1 < mitosisParameterCount; counter1++) oin<<arrayMitosisParameter [counter1]<<endl;
                    oin.close();
                }
                else{
                    
                    errorNoHold = 1011;
                    throw errorCheckThrow;
                }
            }
            
            sleepingPosition = 4;
            cellAttachCount = 0;
            firstCommunication = 3;
            errorNoHold = 0;
        }
        catch (int errorCheckThrow){
            string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
            mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            time_t rawtime;
            struct tm * timeinfo;
            time (&rawtime);
            timeinfo = localtime ( &rawtime );
            
            int tsec = timeinfo -> tm_sec;
            int tmin = timeinfo -> tm_min;
            int thour = timeinfo -> tm_hour;
            int tday = timeinfo -> tm_mday;
            int tmon = timeinfo -> tm_mon;
            
            string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
            
            errorPath = errorPath+"/Cell_CarvingCont04 "+dateTime;
            
            ofstream oin2;
            oin2.open(errorPath.c_str(), ios::out);
            oin2<<"Controller"<<endl;
            oin2<<errorNoHold<<endl;
            oin2<<analysisImageName<<endl;
            oin2<<analysisID<<endl;
            oin2<<treatmentNameHold<<endl;
            oin2<<cellLineageNoHold<<endl;
            oin2<<cellNoHold<<endl;
            oin2<<dateTime<<endl;
            if (errorNoHold == 1010) oin2<<"EventTemp reading error"<<endl;
            if (errorNoHold == 1011) oin2<<"MitosisDataTemp reading error"<<endl;
            oin2.close();
            
            returnMessage = "";
            emergencyExit = 1;
            firstCommunication = 20;
            subCompletionFlag = 0;
        }
    }
    
    if (firstCommunication == 20){
        firstCommunication = 2;
        
        [self processStopMain];
        firstCommunication = 3;
    }
    
    if (sleepingCheck > 0 && sleepingCheck < 3000){
        sleepingCheck++;
    }
    else if (sleepingCheck >= 3000){
        sleepingCheck = 0;
        
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingCont05 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"Controller-Process not responding"<<endl;
        oin2<<sleepingPosition<<endl;
        oin2.close();
        
        returnMessage = "";
        emergencyExit = 1;
        firstCommunication = 20;
        subCompletionFlag = 0;
    }
    
    if (backSaveOff == 1){
        [backSave stopAnimation:self];
        [backSave setHidden:YES];
        
        backSaveCount++;
        
        if (backSaveCount == 5){
            backSaveCount = 0;
            backSaveOff = 0;
        }
    }
}

-(IBAction)processStopSub:(id)sender{
    [self processStopMain];
    
    firstCommunication = 3;
}

-(void)processStopMain{
    sleepingPosition = 5;
    
    if (emergencyExit == 0) exitRequest = 1;
    
    if (mitosisPatternStatus == 1) delete [] arrayMitosisPattern;
    if (lineageStartEndStatus == 1) delete [] arrayLineageStartEnd;
    if (lineageDataStatus == 1) delete [] arrayLineageData;
    
    if (basicArrayStatus == 1){
        delete [] arrayIFDataHold;
        delete [] arrayTreatmentStatus;
        delete [] imageNoHoldMain;
        delete [] arrayFileHandling;
    }
    
    if (fluorescentCutOffStatus == 1) delete [] arrayFluorescentCutOff;
    if (mitosisParameterStatus == 1) delete [] arrayMitosisParameter;
    if (expandLineFluorescentStatus == 1) delete [] expandLineFluorescent;
    if (expandLineFluorescentDataStatus == 1) delete [] expandLineFluorescentData;
    if (expandLineFluorescentCurrentStatus == 1) delete [] expandLineFluorescentCurrent;
    if (expandLineFluorescentDataCurrentStatus == 1) delete [] expandLineFluorescentDataCurrent;
    
    if (mainMapLoadStatus == 1){
        for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
            delete [] connectMap200 [counter1];
            delete [] connectMap220 [counter1];
            delete [] connectMap240 [counter1];
            delete [] connectMapA [counter1];
            delete [] connectMapB [counter1];
            delete [] connectMapC [counter1];
            delete [] connectMapD [counter1];
            delete [] sourceImage [counter1];
        }
        
        delete [] connectMap200;
        delete [] connectMap220;
        delete [] connectMap240;
        delete [] connectMapA;
        delete [] connectMapB;
        delete [] connectMapC;
        delete [] connectMapD;
        delete [] sourceImage;
    }
    
    if (positionReviseStatus == 1) delete [] arrayPositionRevise;
    if (timeSelectedStatus == 1) delete [] arrayTimeSelected;
    if (connectLineageRelStatus == 1) delete [] arrayConnectLineageRel;
    if (gravityCenterRevStatus == 1) delete [] arrayGravityCenterRev;
    if (eventSequenceStatus == 1) delete [] arrayEventSequence;
    if (associatedDataStatus == 1) delete [] arrayAssociatedData;
    if (cellTrackingPreviousStatus == 1) delete [] arrayCellTrackingPrevious;
    if (xyPositionCenterPreviousStatus == 1) delete [] arrayXYPositionCenterPrevious;
    if (cellTrackingPreviousAssStatus == 1) delete [] arrayCellTrackingPreviousAss;
    if (fusionPartnerStatus == 1) delete [] arrayFusionPartner;
    
    if (sectionMapLoadingStatusPrev == 1){
        for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++) delete [] arrayCellTrackingPreviousMap [counter1];
        delete [] arrayCellTrackingPreviousMap;
    }
    
    if (mapLoadingStatusPrev == 1){
        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
            delete [] revisedMap [counter1];
            delete [] revisedWorkingMap [counter1];
        }
        
        delete [] revisedMap;
        delete [] revisedWorkingMap;
    }
    
    if (timeSelectedCurrentStatus == 1) delete [] arrayTimeSelectedCurrent;
    if (positionReviseCurrentStatus == 1) delete [] arrayPositionReviseCurrent;
    if (gravityCenterRevCurrentStatus == 1) delete [] arrayGravityCenterRevCurrent;
    if (associatedDataCurrStatus == 1) delete [] arrayAssociatedDataCurr;
    if (connectLineageRelCurrentStatus == 1) delete [] arrayConnectLineageRelCurrent;
    if (cellTrackingCurrentStatus == 1) delete [] arrayCellTrackingCurrent;
    if (cellTrackingCurrentAssStatus == 1) delete [] arrayCellTrackingCurrentAss;
    if (xyPositionCenterCurrentStatus == 1) delete [] arrayXYPositionCenterCurrent;
    
    if (sectionMapLoadingStatus == 1){
        for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++) delete [] arrayCellTrackingCurrentMap [counter1];
        delete [] arrayCellTrackingCurrentMap;
    }
    
    if (mapLoadingStatus == 1){
        for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] revisedMapCurrent [counter1];
        delete [] revisedMapCurrent;
    }
    
    if (groupInfoPreviousStatus == 1) delete [] arrayGroupInfoPrevious;
    if (groupInfoCurrentStatus == 1) delete [] arrayGroupInfoCurrent;
    if (cellTrackingTableStatus == 1) delete [] arrayCellTrackingTable;
    
    if (connectivityMapCutStatus == 1){
        for (int counter1 = 0; counter1 < connectivityMapCutSizeHold+1; counter1++) delete [] connectivityMapCut [counter1];
        delete [] connectivityMapCut;
    }
    
    if (internalZeroMapStatus == 1){
        for (int counter1 = 0; counter1 < internalZeroMapSizeHold+1; counter1++) delete [] internalZeroMap [counter1];
        delete [] internalZeroMap;
    }
    
    if (targetMapStatus == 1){
        for (int counter1 = 0; counter1 < targetMapSizeHold+1; counter1++) delete [] targetMap [counter1];
        delete [] targetMap;
    }
    
    if (connectNoHoldStatus == 1) delete [] connectNoHold;
    if (cellTrackingRelStatus == 1) delete [] arrayCellTrackingRel;
    if (displayDataStatus == 1) delete [] arrayDisplayData;
    if (displayRelStatus == 1) delete [] arrayDisplayRel;
    if (displayGravityCenterStatus == 1) delete [] arrayDisplayGravityCenter;
    if (cellAttachStatus == 1) delete [] arrayAttachTable;
    
    if (fluorescentMapStatus1 == 1){
        for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap1 [counter1];
        delete [] fluorescentMap1;
    }
    
    if (fluorescentMapStatus2 == 1){
        for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap2 [counter1];
        delete [] fluorescentMap2;
    }
    
    if (fluorescentMapStatus3 == 1){
        for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap3 [counter1];
        delete [] fluorescentMap3;
    }
    
    if (fluorescentMapStatus4 == 1){
        for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap4 [counter1];
        delete [] fluorescentMap4;
    }
    
    if (fluorescentMapStatus5 == 1){
        for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap5 [counter1];
        delete [] fluorescentMap5;
    }
    
    if (fluorescentMapStatus6 == 1){
        for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap6 [counter1];
        delete [] fluorescentMap6;
    }
    
    if (fluorescentMapCurrentStatus1 == 1){
        for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMapCurrent1 [counter1];
        delete [] fluorescentMapCurrent1;
    }
    
    if (fluorescentMapCurrentStatus2 == 1){
        for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMapCurrent2 [counter1];
        delete [] fluorescentMapCurrent2;
    }
    
    if (fluorescentMapCurrentStatus3 == 1){
        for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMapCurrent3 [counter1];
        delete [] fluorescentMapCurrent3;
    }
    
    if (fluorescentMapCurrentStatus4 == 1){
        for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMapCurrent4 [counter1];
        delete [] fluorescentMapCurrent4;
    }
    
    if (fluorescentMapCurrentStatus5 == 1){
        for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMapCurrent5 [counter1];
        delete [] fluorescentMapCurrent5;
    }
    
    if (fluorescentMapCurrentStatus6 == 1){
        for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMapCurrent6 [counter1];
        delete [] fluorescentMapCurrent6;
    }
    
    if (putativeMapStatus == 1){
        for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] putativeMap [counter1];
        delete [] putativeMap;
    }
    
    basicArrayStatus = 0;
    mitosisPatternStatus = 0;
    lineageStartEndStatus = 0;
    lineageDataStatus = 0;
    fluorescentCutOffStatus = 0;
    fusionPartnerStatus = 0;
    mitosisParameterStatus = 0;
    expandLineFluorescentStatus = 0;
    expandLineFluorescentDataStatus = 0;
    expandLineFluorescentCurrentStatus = 0;
    expandLineFluorescentDataCurrentStatus = 0;
    mainMapLoadStatus = 0;
    positionReviseStatus = 0;
    timeSelectedStatus = 0;
    connectLineageRelStatus = 0;
    gravityCenterRevStatus = 0;
    eventSequenceStatus = 0;
    associatedDataStatus = 0;
    cellTrackingPreviousStatus = 0;
    xyPositionCenterPreviousStatus = 0;
    cellTrackingPreviousAssStatus = 0;
    sectionMapLoadingStatusPrev = 0;
    mapLoadingStatusPrev = 0;
    timeSelectedCurrentStatus = 0;
    positionReviseCurrentStatus = 0;
    gravityCenterRevCurrentStatus = 0;
    associatedDataCurrStatus = 0;
    connectLineageRelCurrentStatus = 0;
    cellTrackingCurrentStatus = 0;
    cellTrackingCurrentAssStatus = 0;
    xyPositionCenterCurrentStatus = 0;
    sectionMapLoadingStatus = 0;
    mapLoadingStatus = 0;
    groupInfoPreviousStatus = 0;
    groupInfoCurrentStatus = 0;
    cellTrackingTableStatus = 0;
    connectivityMapCutStatus = 0;
    internalZeroMapStatus = 0;
    targetMapStatus = 0;
    connectNoHoldStatus = 0;
    cellTrackingRelStatus = 0;
    displayDataStatus = 0;
    displayRelStatus = 0;
    displayGravityCenterStatus = 0;
    cellAttachStatus = 0;
    fluorescentMapStatus1 = 0;
    fluorescentMapStatus2 = 0;
    fluorescentMapStatus3 = 0;
    fluorescentMapStatus4 = 0;
    fluorescentMapStatus5 = 0;
    fluorescentMapStatus6 = 0;
    fluorescentMapCurrentStatus1 = 0;
    fluorescentMapCurrentStatus2 = 0;
    fluorescentMapCurrentStatus3 = 0;
    fluorescentMapCurrentStatus4 = 0;
    fluorescentMapCurrentStatus5 = 0;
    fluorescentMapCurrentStatus6 = 0;
    putativeMapStatus = 0;
    
    sleepingPosition = 6;
}

-(void)fileHandlingUpDate{
    try{
        
        errorNoHold = 0;
        string *arrayUpDate = new string [fileHandlingCount+10];
        
        for (int counter1 = 0; counter1 < fileHandlingCount; counter1++) arrayUpDate [counter1] = arrayFileHandling [counter1];
        
        delete [] arrayFileHandling;
        arrayFileHandling = new string [fileHandlingLimit+500];
        fileHandlingLimit = fileHandlingLimit+500;
        
        for (int counter1 = 0; counter1 < fileHandlingCount; counter1++) arrayFileHandling [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingCont06 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"Controller-fileHandlingUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

-(void)dealloc{
    if (controllerTimer) [controllerTimer invalidate];
}

@end
