//
//  GenerateInterpretTable.h
//  Cell_Carving
//
//  Created by Masahiko Sato on 2015-03-26.
//
//

#ifndef GENERATEINTERPRETTABLE_H
#define GENERATEINTERPRETTABLE_H
#import "Controller.h"
#endif

@interface GenerateInterpretTable : NSObject{
}

-(void)trackTableGenerate;


@end
