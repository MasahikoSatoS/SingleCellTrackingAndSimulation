//
// TableInterpretation.h
// cell_carving
//
// Created by Masahiko Sato on 13/06/19.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef TABLEINTERPRETATION_H
#define TABLEINTERPRETETION_H
#import "Controller.h"
#endif

@interface TableInterpretation : NSObject{
    id mitosisPattern;
}

-(int)interpretationFirst:(int)processType;
-(void)interpretationMain2;

@end
