//
// MitosisPattern.mm
// cell_carving
//
// Created by Masahiko Sato on 28/07/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "MitosisPattern.h"

@implementation MitosisPattern

-(double)mitosisPatternMain:(int)processTarget :(int)processType{
    double returnSD = 1000;
    
    try{
        
        errorNoHold = 0;
        subCompletionFlag2 = 1;
        
        if (mitosisPatternCount != 0){
            errorNoHold = 1;
            int **referenceMap = new int *[101];
            errorNoHold = 2;
            int **targetMapMitosis = new int *[101];
            
            for (int counter1 = 0; counter1 < 101; counter1++){
                errorNoHold = 3;
                referenceMap [counter1] = new int [101];
                errorNoHold = 4;
                targetMapMitosis[counter1] = new int [101];
            }
            
            for (int counter1 = 0; counter1 < 101; counter1++){
                for (int counter2 = 0; counter2 < 101; counter2++){
                    referenceMap[counter1][counter2] = 0;
                    targetMapMitosis[counter1][counter2] = 0;
                }
            }
            
            errorNoHold = 5;
            int *snapData = new int [1000];
            int snapDataCount = 0;
            int snapDataLimit = 1000;
            errorNoHold = 6;
            int *arrayMitosisRefData = new int [1000];
            int mitosisRefDataCount = 0;
            
            if (processType == 1){
                for (int counter1 = 0; counter1 < cellTrackingCurrentCount/6; counter1++){
                    if (arrayCellTrackingCurrent [counter1*6+3] == processTarget){
                        if (snapDataCount+10 > snapDataLimit){
                            errorNoHold = 7;
                            int *arrayUpDate = new int [snapDataCount+10];
                            
                            for (int counter2 = 0; counter2 < snapDataCount; counter2++) arrayUpDate [counter2] = snapData [counter2];
                            
                            delete [] snapData;
                            errorNoHold = 8;
                            snapData = new int [snapDataLimit+1000];
                            snapDataLimit = snapDataLimit+1000;
                            
                            for (int counter2 = 0; counter2 < snapDataCount; counter2++) snapData [counter2] = arrayUpDate [counter2];
                            delete [] arrayUpDate;
                        }
                        
                        snapData [snapDataCount] = arrayCellTrackingCurrent [counter1*6], snapDataCount++;
                        snapData [snapDataCount] = arrayCellTrackingCurrent [counter1*6+1], snapDataCount++;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrevious [counterA*6+counterB];
            //	cout<<" arrayCellTrackingPrevious "<<counterA<<endl;
            //}
            
            if (processType == 2){
                for (int counter1 = 0; counter1 < cellTrackingPreviousCount/6; counter1++){
                    if (arrayCellTrackingPrevious [counter1*6+3] == processTarget){
                        if (snapDataCount+10 > snapDataLimit){
                            errorNoHold = 9;
                            int *arrayUpDate = new int [snapDataCount+10];
                            
                            for (int counter2 = 0; counter2 < snapDataCount; counter2++) arrayUpDate [counter2] = snapData [counter2];
                            
                            delete [] snapData;
                            errorNoHold = 10;
                            snapData = new int [snapDataLimit+1000];
                            snapDataLimit = snapDataLimit+1000;
                            
                            for (int counter2 = 0; counter2 < snapDataCount; counter2++) snapData [counter2] = arrayUpDate [counter2];
                            delete [] arrayUpDate;
                        }
                        
                        snapData [snapDataCount] = arrayCellTrackingPrevious [counter1*6], snapDataCount++;
                        snapData [snapDataCount] = arrayCellTrackingPrevious [counter1*6+1], snapDataCount++;
                    }
                }
            }
            
            if (processType == 3){
                for (int counter1 = 0; counter1 < referenceLineCount/2; counter1++){
                    if (snapDataCount+10 > snapDataLimit){
                        errorNoHold = 11;
                        int *arrayUpDate = new int [snapDataCount+10];
                        
                        for (int counter2 = 0; counter2 < snapDataCount; counter2++) arrayUpDate [counter2] = snapData [counter2];
                        
                        delete [] snapData;
                        errorNoHold = 12;
                        snapData = new int [snapDataLimit+1000];
                        snapDataLimit = snapDataLimit+1000;
                        
                        for (int counter2 = 0; counter2 < snapDataCount; counter2++) snapData [counter2] = arrayUpDate [counter2];
                        delete [] arrayUpDate;
                    }
                    
                    snapData [snapDataCount] = arrayReferenceLine [counter1*2], snapDataCount++;
                    snapData [snapDataCount] = arrayReferenceLine [counter1*2+1], snapDataCount++;
                }
            }
            
            //-------Trimming outline Data---------
            int maxPointDimX = 0;
            int maxPointDimY = 0;
            int minPointDimX = 1000000;
            int minPointDimY = 1000000;
            
            for (int counter1 = 0; counter1 < snapDataCount/2; counter1++){
                if (maxPointDimX < snapData [counter1*2]) maxPointDimX = snapData [counter1*2];
                if (minPointDimX > snapData [counter1*2]) minPointDimX = snapData [counter1*2];
                if (maxPointDimY < snapData [counter1*2+1]) maxPointDimY = snapData [counter1*2+1];
                if (minPointDimY > snapData [counter1*2+1]) minPointDimY = snapData [counter1*2+1];
            }
            
            int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
            int verticalLength = (maxPointDimY-minPointDimY)/2*2;
            int dimension = 0;
            
            if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
            if (horizontalLength < verticalLength) dimension = verticalLength+30;
            
            dimension = (dimension/2)*2;
            
            int horizontalStart2 = minPointDimX-(dimension-horizontalLength)/2;
            int verticalStart2 = minPointDimY-(dimension-verticalLength)/2;
            
            errorNoHold = 13;
            int **connectivitySourceTemp = new int *[dimension+4];
            errorNoHold = 14;
            int **connectivityMapCut7 = new int *[dimension+4];
            errorNoHold = 15;
            int **connectivityMapCut6 = new int *[dimension+4];
            errorNoHold = 16;
            int **connectivityMapCut5 = new int *[dimension+4];
            errorNoHold = 17;
            int **connectivityMapCut4 = new int *[dimension+4];
            errorNoHold = 18;
            int **connectivityUpdate5 = new int *[dimension+4];
            
            for (int counter1 = 0; counter1 < dimension+4; counter1++){
                errorNoHold = 19;
                connectivitySourceTemp [counter1] = new int [dimension+4];
                errorNoHold = 20;
                connectivityMapCut7 [counter1] = new int [dimension+4];
                errorNoHold = 21;
                connectivityMapCut6 [counter1] = new int [dimension+4];
                errorNoHold = 22;
                connectivityMapCut5 [counter1] = new int [dimension+4];
                errorNoHold = 23;
                connectivityMapCut4 [counter1] = new int [dimension+4];
                errorNoHold = 24;
                connectivityUpdate5 [counter1] = new int [dimension+4];
            }
            
            for (int counterY = 0; counterY < dimension+4; counterY++){
                for (int counterX = 0; counterX < dimension+4; counterX++){
                    connectivitySourceTemp [counterY][counterX] = 0;
                    connectivityMapCut7 [counterY][counterX] = 0;
                    connectivityMapCut6 [counterY][counterX] = 0;
                    connectivityMapCut5 [counterY][counterX] = 0;
                    connectivityMapCut4 [counterY][counterX] = 0;
                }
            }
            
            for (int counter1 = 0; counter1 < snapDataCount/2; counter1++){
                connectivitySourceTemp [snapData [counter1*2+1]-verticalStart2][snapData [counter1*2]-horizontalStart2] = 1;
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivitySourceTemp [counterA][counterB];
            //	cout<<" connectivitySourceTemp "<<counterA<<endl;
            //}
            
            //------Connectivity analysis, For Zero------
            errorNoHold = 25;
            int *connectAnalysisX = new int [(dimension+2)*4];
            errorNoHold = 26;
            int *connectAnalysisY = new int [(dimension+2)*4];
            errorNoHold = 27;
            int *connectAnalysisTempX = new int [(dimension+2)*4];
            errorNoHold = 28;
            int *connectAnalysisTempY = new int [(dimension+2)*4];
            
            int connectivityNumber = -3;
            int connectAnalysisCount = 0;
            int terminationFlag = 0;
            int connectAnalysisTempCount = 0;
            int xSource = 0;
            int ySource = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivitySourceTemp [counterY][counterX] == 0){
                        connectivityNumber = connectivityNumber+2;
                        connectivitySourceTemp [counterY][counterX] = connectivityNumber;
                        
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && connectivitySourceTemp [counterY-1][counterX] == 0){
                            connectivitySourceTemp [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && connectivitySourceTemp [counterY][counterX+1] == 0){
                            connectivitySourceTemp [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && connectivitySourceTemp [counterY+1][counterX] == 0){
                            connectivitySourceTemp [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && connectivitySourceTemp [counterY][counterX-1] == 0){
                            connectivitySourceTemp [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && connectivitySourceTemp [ySource-1][xSource] == 0){
                                        connectivitySourceTemp [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && connectivitySourceTemp [ySource][xSource+1] == 0){
                                        connectivitySourceTemp [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && connectivitySourceTemp [ySource+1][xSource] == 0){
                                        connectivitySourceTemp [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivitySourceTemp [ySource][xSource-1] == 0){
                                        connectivitySourceTemp [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            int originalAreaSize = 0;
            
            //------Remove connectivity groups, which attach edge, extract inner part of Linked Line------
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivitySourceTemp [counterY][counterX] == -1) connectivitySourceTemp [counterY][counterX] = 0;
                    else originalAreaSize++;
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivitySourceTemp [counterA][counterB];
            //	cout<<"connectivitySourceTemp  "<<counterA<<endl;
            //}
            
            if (processType == 2 || processType == 3){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                            if (sourceImage [mapPositionPointer][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] > cutOff7 && sourceImage [mapPositionPointer][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] != 100) connectivityMapCut7 [counterY][counterX] = 1;
                            else connectivityMapCut7 [counterY][counterX] = 0;
                            
                            if (sourceImage [mapPositionPointer][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] > cutOff6 && sourceImage [mapPositionPointer][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] != 100) connectivityMapCut6 [counterY][counterX] = 1;
                            else connectivityMapCut6 [counterY][counterX] = 0;
                            
                            if (sourceImage [mapPositionPointer][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] > cutOff5 && sourceImage [mapPositionPointer][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] != 100) connectivityMapCut5 [counterY][counterX] = 1;
                            else connectivityMapCut5 [counterY][counterX] = 0;
                            
                            if (sourceImage [mapPositionPointer][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] > cutOff4 && sourceImage [mapPositionPointer][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] != 100) connectivityMapCut4 [counterY][counterX] = 1;
                            else connectivityMapCut4 [counterY][counterX] = 0;
                        }
                    }
                }
            }
            else if (processType == 1){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                            if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] > cutOff7 && sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] != 100) connectivityMapCut7 [counterY][counterX] = 1;
                            else connectivityMapCut7 [counterY][counterX] = 0;
                            
                            if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] > cutOff6 && sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] != 100) connectivityMapCut6 [counterY][counterX] = 1;
                            else connectivityMapCut6 [counterY][counterX] = 0;
                            
                            if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] > cutOff5 && sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] != 100) connectivityMapCut5 [counterY][counterX] = 1;
                            else connectivityMapCut5 [counterY][counterX] = 0;
                            
                            if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] > cutOff4 && sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] != 100) connectivityMapCut4 [counterY][counterX] = 1;
                            else connectivityMapCut4 [counterY][counterX] = 0;
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut7 [counterA][counterB];
            //	cout<<" connectivityMapCut7 "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut6 [counterA][counterB];
            //	cout<<" connectivityMapCut6 "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut5 [counterA][counterB];
            //	cout<<" connectivityMapCut5 "<<counterA<<endl;
            //}
            
            int totalCount7 = 0;
            int totalCount6 = 0;
            int totalCount5 = 0;
            int totalCount4 = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivitySourceTemp [counterY][counterX] == 1 && connectivityMapCut7 [counterY][counterX] != 0) totalCount7++;
                    else connectivityMapCut7 [counterY][counterX] = 0;
                    
                    if (connectivitySourceTemp [counterY][counterX] == 1 && connectivityMapCut6 [counterY][counterX] != 0) totalCount6++;
                    else connectivityMapCut6 [counterY][counterX] = 0;
                    
                    if (connectivitySourceTemp [counterY][counterX] == 1 && connectivityMapCut5 [counterY][counterX] != 0) totalCount5++;
                    else connectivityMapCut5 [counterY][counterX] = 0;
                    
                    if (connectivitySourceTemp [counterY][counterX] == 1 && connectivityMapCut4 [counterY][counterX] != 0) totalCount4++;
                    else connectivityMapCut4 [counterY][counterX] = 0;
                }
            }
            
            int lineTaken = 0;
            
            if (totalCount7 == 0){
                if (totalCount6 == 0){
                    if (totalCount5 == 0){
                        if (totalCount4 == 0) lineTaken = 0;
                        else lineTaken = 4;
                    }
                    else if (totalCount4 > totalCount5*0.8) lineTaken = 4;
                    else lineTaken = 5;
                }
                else if (totalCount5 > totalCount6*0.8) lineTaken = 5;
                else lineTaken = 6;
            }
            else if (totalCount6 > totalCount7*0.8) lineTaken = 7;
            else lineTaken = 6;
            
            if (lineTaken == 7){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        connectivityMapCut6 [counterY][counterX] = connectivityMapCut7 [counterY][counterX];
                    }
                }
            }
            else if (lineTaken == 5){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        connectivityMapCut6 [counterY][counterX] = connectivityMapCut5 [counterY][counterX];
                    }
                }
            }
            else if (lineTaken == 4){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        connectivityMapCut6 [counterY][counterX] = connectivityMapCut4 [counterY][counterX];
                    }
                }
            }
            
            int sourceAreaSize = 0;
            
            for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] connectivitySourceTemp [counter1];
            delete [] connectivitySourceTemp;
            
            if (lineTaken != 0){
                //-------Fill zero------
                for (int counterX = 0; counterX < dimension+2; counterX++){
                    for (int counterY = 0; counterY < dimension+2; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        connectivityUpdate5 [counterY+1][counterX+1] = connectivityMapCut6 [counterY][counterX];
                    }
                }
                
                connectivityNumber = 0;
                
                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                        if (connectivityUpdate5 [counterY2][counterX2] == 0){
                            connectivityNumber--;
                            connectAnalysisCount = 0;
                            
                            connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                            
                            if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                                connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                            }
                            if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                            }
                            if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                            }
                            if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                        xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                        
                                        if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                            connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                            connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                            connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                            connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                        connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < dimension+2; counterA++){
                //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                //cout<<" connectivityUpdate5 "<<counterA<<endl;
                //}
                
                int connectTemp2 = 0;
                
                if (connectivityNumber < -1){
                    errorNoHold = 29;
                    int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                    
                    for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                            connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                            
                            if (connectTemp2 < -1){
                                connectTemp2 = connectTemp2*-1;
                                
                                if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                            }
                        }
                    }
                    
                    int zeroFillFlag = 0;
                    
                    for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                        if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
                    }
                    
                    if (zeroFillFlag == 1){
                        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                                
                                if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                            }
                        }
                        
                        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                if (connectivityUpdate5 [counterY2][counterX2] > 0) connectivityMapCut6 [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                            }
                        }
                    }
                    
                    delete [] connectCheckArray;
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapCut6 [counterY][counterX] != 0){
                            if (counterX+1 < dimension && connectivityMapCut6 [counterY][counterX+1] == 0) connectivityMapCut6 [counterY][counterX] = -1;
                            else if (counterY+1 < dimension && connectivityMapCut6 [counterY+1][counterX] == 0) connectivityMapCut6 [counterY][counterX] = -1;
                            else if (counterX-1 >= 0 && connectivityMapCut6 [counterY][counterX-1] == 0) connectivityMapCut6 [counterY][counterX] = -1;
                            else if (counterY-1 >= 0 && connectivityMapCut6 [counterY-1][counterX] == 0) connectivityMapCut6 [counterY][counterX] = -1;
                        }
                    }
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapCut6 [counterY][counterX] > 0) connectivityMapCut6 [counterY][counterX] = 0;
                        if (connectivityMapCut6 [counterY][counterX] < 0) connectivityMapCut6 [counterY][counterX] = 1;
                    }
                }
                
                connectivityNumber = 0;
                
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                        if (connectivityMapCut6 [counterY2][counterX2] == 0){
                            connectivityNumber--;
                            connectAnalysisCount = 0;
                            
                            connectivityMapCut6 [counterY2][counterX2] = connectivityNumber;
                            
                            if (counterY2-1 >= 0 && connectivityMapCut6 [counterY2-1][counterX2] == 0){
                                connectivityMapCut6 [counterY2-1][counterX2] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                            }
                            if (counterX2+1 < dimension && connectivityMapCut6 [counterY2][counterX2+1] == 0){
                                connectivityMapCut6 [counterY2][counterX2+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                            }
                            if (counterY2+1 < dimension && connectivityMapCut6 [counterY2+1][counterX2] == 0){
                                connectivityMapCut6 [counterY2+1][counterX2] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                            }
                            if (counterX2-1 >= 0 && connectivityMapCut6 [counterY2][counterX2-1] == 0){
                                connectivityMapCut6 [counterY2][counterX2-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                        xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                        
                                        if (ySource-1 >= 0 && connectivityMapCut6 [ySource-1][xSource] == 0){
                                            connectivityMapCut6 [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension && connectivityMapCut6 [ySource][xSource+1] == 0){
                                            connectivityMapCut6 [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && connectivityMapCut6 [ySource+1][xSource] == 0){
                                            connectivityMapCut6 [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && connectivityMapCut6 [ySource][xSource-1] == 0){
                                            connectivityMapCut6 [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                        connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //------Determine number of pixels------
                connectivityNumber = connectivityNumber*-1;
                
                errorNoHold = 30;
                int *connectedPixels = new int [connectivityNumber+50];
                
                for (int counter1 = 0; counter1 < connectivityNumber+50; counter1++) connectedPixels [counter1] = 0;
                
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                        if (connectivityMapCut6 [counterY2][counterX2] < -1){
                            connectTemp2 = connectTemp2*-1;
                            connectedPixels [connectivityMapCut6 [counterY2][counterX2]*-1]++;
                        }
                    }
                }
                
                errorNoHold = 31;
                int **newConnectivityMapTemp = new int *[dimension+4];
                for (int counter1 = 0; counter1 < dimension+4; counter1++){
                    errorNoHold = 32;
                    newConnectivityMapTemp [counter1] = new int [dimension+4];
                }
                
                for (int counterY = 0; counterY < dimension+4; counterY++){
                    for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
                }
                
                int largestConnect = 0;
                int largestConnectNo = 0;
                
                for (int counter1 = 2; counter1 <= connectivityNumber; counter1++){
                    if (connectedPixels [counter1] > largestConnect){
                        largestConnect = connectedPixels [counter1];
                        largestConnectNo = counter1;
                    }
                }
                
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                        if (connectivityMapCut6 [counterY2][counterX2] == largestConnectNo*-1){
                            if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityMapCut6 [counterY2-1][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                                connectivityMapCut6 [counterY2-1][counterX2-1] = 0;
                            }
                            if (counterY2-1 >= 0 && connectivityMapCut6 [counterY2-1][counterX2] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                                connectivityMapCut6 [counterY2-1][counterX2] = 0;
                            }
                            if (counterY2-1 >= 0 && counterX2+1 < dimension && connectivityMapCut6 [counterY2-1][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                                connectivityMapCut6 [counterY2-1][counterX2+1] = 0;
                            }
                            if (counterX2+1 < dimension && connectivityMapCut6 [counterY2][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                                connectivityMapCut6 [counterY2][counterX2+1] = 0;
                            }
                            if (counterY2+1 < dimension && counterX2+1 < dimension && connectivityMapCut6 [counterY2+1][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                                connectivityMapCut6 [counterY2+1][counterX2+1] = 0;
                            }
                            if (counterY2+1 < dimension && connectivityMapCut6 [counterY2+1][counterX2] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                                connectivityMapCut6 [counterY2+1][counterX2] = 0;
                            }
                            if (counterY2+1 < dimension && counterX2-1 >= 0 && connectivityMapCut6 [counterY2+1][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                                connectivityMapCut6 [counterY2+1][counterX2-1] = 0;
                            }
                            if (counterX2-1 >= 0 && connectivityMapCut6 [counterY2][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                                connectivityMapCut6 [counterY2][counterX2-1] = 0;
                            }
                        }
                    }
                }
                
                delete [] connectedPixels;
                
                int xPositionTempStart = 0;
                int yPositionTempStart = 0;
                int lineSize = 0;
                
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                        if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                            connectivityMapCut6 [counterY2][counterX2] = 1;
                            xPositionTempStart = counterX2;
                            yPositionTempStart = counterY2;
                            lineSize++;
                        }
                        else connectivityMapCut6 [counterY2][counterX2] = 0;
                    }
                }
                
                for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] newConnectivityMapTemp [counter1];
                delete [] newConnectivityMapTemp;
                
                int constructedLineCount = 0;
                int findFlag = 0;
                
                errorNoHold = 33;
                int *arrayNewLines = new int [lineSize*2+50];
                
                connectivityMapCut6 [yPositionTempStart][xPositionTempStart] = -1;
                arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart2, constructedLineCount++;
                arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart2, constructedLineCount++;
                
                do{
                    
                    findFlag = 0;
                    terminationFlag = 0;
                    
                    if (xPositionTempStart+1 < dimension){
                        if (connectivityMapCut6 [yPositionTempStart][xPositionTempStart+1] == 1){
                            connectivityMapCut6 [yPositionTempStart][xPositionTempStart+1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart2, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart2, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                        if (connectivityMapCut6 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                            connectivityMapCut6 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart2, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart2, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    if (yPositionTempStart+1 < dimension && findFlag == 0){
                        if (connectivityMapCut6 [yPositionTempStart+1][xPositionTempStart] == 1){
                            connectivityMapCut6 [yPositionTempStart+1][xPositionTempStart] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart2, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart2, constructedLineCount++;
                            yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                        if (connectivityMapCut6 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                            connectivityMapCut6 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart2, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart2, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    if (xPositionTempStart-1 >= 0 && findFlag == 0){
                        if (connectivityMapCut6 [yPositionTempStart][xPositionTempStart-1] == 1){
                            connectivityMapCut6 [yPositionTempStart][xPositionTempStart-1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart2, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart2, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                        if (connectivityMapCut6 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                            connectivityMapCut6 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart2, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart2, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    if (yPositionTempStart-1 >= 0 && findFlag == 0){
                        if (connectivityMapCut6 [yPositionTempStart-1][xPositionTempStart] == 1){
                            connectivityMapCut6 [yPositionTempStart-1][xPositionTempStart] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart2, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart2, constructedLineCount++;
                            yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                        if (connectivityMapCut6 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                            connectivityMapCut6 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart2, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart2, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                        }
                    }
                    
                } while (terminationFlag == 1);
                
                //===========
                //int aa = arrayNewLines [0];
                //int bb = arrayNewLines [1];
                
                //int cc = arrayNewLines [(constructedLineCount/2-1)*2];
                //int dd = arrayNewLines [(constructedLineCount/2-1)*2+1];
                
                //int findLink = 0;
                
                //if (cc-1 == aa && dd-1 == bb) findLink = 1;
                //else  if (cc == aa && dd-1 == bb) findLink = 1;
                //else  if (cc+1 == aa && dd-1 == bb) findLink = 1;
                //else  if (cc+1 == aa && dd == bb) findLink = 1;
                //else  if (cc+1 == aa && dd+1 == bb) findLink = 1;
                //else  if (cc == aa && dd+1 == bb) findLink = 1;
                //else  if (cc-1 == aa && dd+1 == bb) findLink = 1;
                //else  if (cc-1 == aa && dd == bb) findLink = 1;
                
                //if (findLink == 0){
                //    for (int counterA = 0; counterA < dimension; counterA++){
                //        for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut6 [counterA][counterB];
                //        cout<<" connectivityMapCut6 "<<counterA<<endl;
                //    }
                //}
                
                //==========
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut6 [counterA][counterB];
                //    cout<<" connectivityMapCut6" <<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut5 [counterA][counterB];
                //    cout<<" connectivityMapCut5 "<<counterA<<endl;
                //}
                
                if (constructedLineCount >= 16){
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (connectivityMapCut6 [counterY2][counterX2] < 0) connectivityMapCut6 [counterY2][counterX2] = 1;
                        }
                    }
                    
                    connectivityNumber = -3;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapCut6 [counterY][counterX] == 0){
                                connectivityNumber = connectivityNumber+2;
                                connectAnalysisCount = 0;
                                
                                if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMapCut6 [counterY][counterX] = connectivityNumber;
                                
                                if (counterY-1 >= 0 && connectivityMapCut6 [counterY-1][counterX] == 0){
                                    connectivityMapCut6 [counterY-1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterX+1 < dimension && connectivityMapCut6 [counterY][counterX+1] == 0){
                                    connectivityMapCut6 [counterY][counterX+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimension && connectivityMapCut6 [counterY+1][counterX] == 0){
                                    connectivityMapCut6 [counterY+1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterX-1 >= 0 && connectivityMapCut6 [counterY][counterX-1] == 0){
                                    connectivityMapCut6 [counterY][counterX-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                            xSource = connectAnalysisX [counter1];
                                            ySource = connectAnalysisY [counter1];
                                            
                                            if (ySource-1 >= 0 && connectivityMapCut6 [ySource-1][xSource] == 0){
                                                connectivityMapCut6 [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && connectivityMapCut6 [ySource][xSource+1] == 0){
                                                connectivityMapCut6 [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && connectivityMapCut6 [ySource+1][xSource] == 0){
                                                connectivityMapCut6 [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && connectivityMapCut6 [ySource][xSource-1] == 0){
                                                connectivityMapCut6 [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapCut6 [counterY][counterX] == -1) connectivityMapCut6 [counterY][counterX] = 0;
                            else connectivityMapCut6 [counterY][counterX] = 1;
                        }
                    }
                    
                    int gravityCenter [3] = {0,0,0};
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapCut6 [counterY][counterX] == 1){
                                gravityCenter [0] = gravityCenter [0]+counterX;
                                gravityCenter [1] = gravityCenter [1]+counterY;
                                gravityCenter [2]++;
                            }
                        }
                    }
                    
                    int gravityX = (int)(gravityCenter [0]/(double)gravityCenter [2])+horizontalStart2;
                    int gravityY = (int)(gravityCenter [1]/(double)gravityCenter [2])+verticalStart2;
                    int targetDiffX = 50-gravityX;
                    int targetDiffY = 50-gravityY;
                    
                    snapDataCount = 0;
                    
                    for (int counter1 = 0; counter1 < constructedLineCount/2; counter1++){
                        if (snapDataCount+10 > snapDataLimit){
                            errorNoHold = 34;
                            int *arrayUpDate = new int [snapDataCount+10];
                            
                            for (int counter2 = 0; counter2 < snapDataCount; counter2++) arrayUpDate [counter2] = snapData [counter2];
                            
                            delete [] snapData;
                            errorNoHold = 35;
                            snapData = new int [snapDataLimit+1000];
                            snapDataLimit = snapDataLimit+1000;
                            
                            for (int counter2 = 0; counter2 < snapDataCount; counter2++) snapData [counter2] = arrayUpDate [counter2];
                            delete [] arrayUpDate;
                        }
                        
                        //cout<<gravityX+(arrayNewLines [counter1*2]-gravityX)+targetDiffX<<" "<<gravityY+(arrayNewLines [counter1*2+1]-gravityY)+targetDiffY<<" "<<snapDataCount<<" "<<snapDataLimit<<" Diff "<<endl;
                        
                        snapData [snapDataCount] = gravityX+(arrayNewLines [counter1*2]-gravityX)+targetDiffX, snapDataCount++;
                        snapData [snapDataCount] = gravityY+(arrayNewLines [counter1*2+1]-gravityY)+targetDiffY, snapDataCount++;
                    }
                    
                    sourceAreaSize = gravityCenter [2];
                    
                    if (snapDataCount != 0){
                        double maxRatio = 1;
                        double ratio = 1;
                        double longestLine = 0;
                        double constTempA = 0;
                        double constTempB = 0;
                        double referenceLine = 0;
                        
                        int dataTempX = 0;
                        int dataTempY = 0;
                        int longestX = 0;
                        int longestY = 0;
                        
                        for (int counter1 = 0; counter1 < snapDataCount/2; counter1++){
                            dataTempX = snapData [counter1*2];
                            dataTempY = snapData [counter1*2+1];
                            
                            if (dataTempX < 2 || dataTempX > 98 || dataTempY < 2 || dataTempY > 98){
                                longestLine = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                
                                if (dataTempX < 0 && dataTempY == 50){
                                    referenceLine = 48;
                                    ratio = longestLine/(double)referenceLine;
                                }
                                else if (dataTempX < 0 && dataTempY > 0 && dataTempY < 50){
                                    constTempA = (50-dataTempY)/(double)(50-dataTempX);
                                    constTempB = 50-constTempA*50;
                                    longestX = 2;
                                    longestY = (int)(constTempA*2+(double)constTempB);
                                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                    ratio = longestLine/(double)referenceLine;
                                }
                                else if (dataTempX < 0 && dataTempY < 0){
                                    longestX = 2;
                                    longestY = 2;
                                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                    ratio = longestLine/(double)referenceLine;
                                }
                                else if (dataTempX > 0 && dataTempX < 50 && dataTempY < 0){
                                    constTempA = (50-dataTempY)/(double)(50-dataTempX);
                                    constTempB = 50-constTempA*50;
                                    longestX = (int)((2-constTempB)/(double)constTempA);
                                    longestY = 2;
                                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                    ratio = longestLine/(double)referenceLine;
                                }
                                else if (dataTempX == 50 && dataTempY < 0){
                                    referenceLine = 48;
                                    ratio = longestLine/(double)referenceLine;
                                }
                                else if (dataTempX > 50 && dataTempX < 100 && dataTempY < 0){
                                    constTempA = (50-dataTempY)/(double)(50-dataTempX);
                                    constTempB = 50-constTempA*50;
                                    longestX = (int)((2-constTempB)/(double)constTempA);
                                    longestY = 2;
                                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                    ratio = longestLine/(double)referenceLine;
                                }
                                else if (dataTempX > 100 && dataTempY < 0){
                                    longestX = 98;
                                    longestY = 2;
                                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                    ratio = longestLine/(double)referenceLine;
                                }
                                else if (dataTempX > 100 && dataTempY > 0 && dataTempY < 50){
                                    constTempA = (50-dataTempY)/(double)(50-dataTempX);
                                    constTempB = 50-constTempA*50;
                                    longestX = 98;
                                    longestY = (int)(constTempA*98+constTempB);
                                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                    ratio = longestLine/(double)referenceLine;
                                }
                                else if (dataTempX == 50 && dataTempY > 100){
                                    referenceLine = 48;
                                    ratio = longestLine/(double)referenceLine;
                                }
                                else if (dataTempX > 100 && dataTempY > 50 && dataTempY < 100){
                                    constTempA = (50-dataTempY)/(double)(50-dataTempX);
                                    constTempB = 50-constTempA*50;
                                    longestX = 98;
                                    longestY = (int)(constTempA*98+constTempB);
                                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                    ratio = longestLine/(double)referenceLine;
                                }
                                else if (dataTempX > 100 && dataTempY > 100){
                                    longestX = 98;
                                    longestY = 98;
                                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                    ratio = longestLine/(double)referenceLine;
                                }
                                else if (dataTempX > 50 && dataTempX < 100 && dataTempY > 100){
                                    constTempA = (50-dataTempY)/(double)(50-dataTempX);
                                    constTempB = 50-constTempA*50;
                                    longestX = (int)((98-constTempB)/(double)constTempA);
                                    longestY = 98;
                                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                    ratio = longestLine/(double)referenceLine;
                                }
                                else if (dataTempX == 50 && dataTempY > 100){
                                    referenceLine = 48;
                                    ratio = longestLine/(double)referenceLine;
                                }
                                else if (dataTempX > 0 && dataTempX < 50 && dataTempY > 100){
                                    constTempA = (50-dataTempY)/(double)(50-dataTempX);
                                    constTempB = 50-constTempA*50;
                                    longestX = (int)((98-constTempB)/(double)constTempA);
                                    longestY = 98;
                                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                    ratio = longestLine/(double)referenceLine;
                                }
                                else if (dataTempX < 0 && dataTempY > 100){
                                    referenceLine = 48;
                                    ratio = longestLine/(double)referenceLine;
                                }
                                else if (dataTempX < 0 && dataTempY > 50 && dataTempY < 100){
                                    constTempA = (50-dataTempY)/(double)(50-dataTempX);
                                    constTempB = 50-constTempA*50;
                                    longestX = 2;
                                    longestY = (int)(2*constTempA+constTempB);
                                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                    ratio = longestLine/(double)referenceLine;
                                }
                                
                                if (maxRatio < ratio) maxRatio = ratio;
                            }
                        }
                        
                        errorNoHold = 36;
                        int *snapDataRevised = new int [snapDataCount+100];
                        int snapDataRevisdCount = 0;
                        
                        if (maxRatio > 1){
                            for (int counter1 = 0; counter1 < snapDataCount/2; counter1++){
                                dataTempX = snapData [counter1*2];
                                dataTempY = snapData [counter1*2+1];
                                
                                if (dataTempX < 50 && dataTempY == 50){
                                    dataTempX = 50-(int)((50-dataTempX)/(double)maxRatio);
                                    dataTempY = 50;
                                }
                                if (dataTempX < 50 && dataTempY < 50){
                                    dataTempX = 50-(int)((50-dataTempX)/(double)maxRatio);
                                    dataTempY = 50-(int)((50-dataTempY)/(double)maxRatio);
                                }
                                if (dataTempX == 50 && dataTempY < 50){
                                    dataTempX = 50;
                                    dataTempY = 50-(int)((50-dataTempY)/(double)maxRatio);
                                }
                                if (dataTempX > 50 && dataTempY < 50){
                                    dataTempX = 50+(int)((dataTempX-50)/(double)maxRatio);
                                    dataTempY = 50-(int)((50-dataTempY)/(double)maxRatio);
                                }
                                if (dataTempX == 50 && dataTempY > 50){
                                    dataTempX = 50+(int)((dataTempX-50)/(double)maxRatio);
                                    dataTempY = 50;
                                }
                                if (dataTempX > 50 && dataTempY > 50){
                                    dataTempX = 50+(int)((dataTempX-50)/(double)maxRatio);
                                    dataTempY = 50+(int)((dataTempY-50)/(double)maxRatio);
                                }
                                if (dataTempX > 50 && dataTempY == 50){
                                    dataTempX = 50;
                                    dataTempY = 50+(int)((dataTempY-50)/(double)maxRatio);
                                }
                                if (dataTempX < 50 && dataTempY > 50){
                                    dataTempX = 50-(int)((50-dataTempX)/(double)maxRatio);
                                    dataTempY = 50+(int)((dataTempY-50)/(double)maxRatio);
                                }
                                
                                snapDataRevised [snapDataRevisdCount] = dataTempX, snapDataRevisdCount++;
                                snapDataRevised [snapDataRevisdCount] = dataTempY, snapDataRevisdCount++;
                            }
                        }
                        else{
                            
                            for (int counter1 = 0; counter1 < snapDataCount/2; counter1++){
                                snapDataRevised [snapDataRevisdCount] = snapData [counter1*2], snapDataRevisdCount++;
                                snapDataRevised [snapDataRevisdCount] = snapData [counter1*2+1], snapDataRevisdCount++;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < snapDataRevisdCount/2; counterA++){
                        //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<snapDataRevised [counterA*2+counterB];
                        //    cout<<" snapDataRevise "<<counterA<<endl;
                        //}
                        
                        errorNoHold = 37;
                        int **duplicateRemoveMap = new int *[101];
                        for (int counter1 = 0; counter1 < 101; counter1++){
                            errorNoHold = 38;
                            duplicateRemoveMap [counter1] = new int [101];
                        }
                        
                        for (int counterY = 0; counterY < 101; counterY++){
                            for (int counterX = 0; counterX < 101; counterX++) duplicateRemoveMap [counterY][counterX] = 0;
                        }
                        
                        int tempX = 0;
                        int tempY = 0;
                        
                        for (int counter1 = 0; counter1 < snapDataRevisdCount/2; counter1++){
                            tempX = snapDataRevised [counter1*2];
                            tempY = snapDataRevised [counter1*2+1];
                            
                            if (tempX < 0) tempX = 0;
                            if (tempX > 100) tempX = 100;
                            if (tempY < 0) tempY = 0;
                            if (tempY > 100) tempY = 100;
                            
                            duplicateRemoveMap [tempY][tempX] = 1;
                        }
                        
                        //for (int counterA = 0; counterA < 100; counterA++){
                        //    for (int counterB = 0; counterB < 100; counterB++) cout<<" "<<duplicateRemoveMap [counterA][counterB];
                        //    cout<<" duplicateRemoveMap "<<counterA<<endl;
                        //}
                        
                        if (snapDataRevisdCount+50 > 1000){
                            delete [] arrayMitosisRefData;
                            errorNoHold = 39;
                            arrayMitosisRefData = new int [snapDataRevisdCount+50];
                        }
                        
                        for (int counterY = 0; counterY < 101; counterY++){
                            for (int counterX = 0; counterX < 101; counterX++){
                                if (duplicateRemoveMap [counterY][counterX] == 1){
                                    arrayMitosisRefData [mitosisRefDataCount] = counterX, mitosisRefDataCount++;
                                    arrayMitosisRefData [mitosisRefDataCount] = counterY, mitosisRefDataCount++;
                                }
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < 101; counter1++) delete [] duplicateRemoveMap [counter1];
                        delete [] duplicateRemoveMap;
                        
                        delete [] snapDataRevised;
                    }
                }
                
                delete [] arrayNewLines;
            }
            
            delete [] connectAnalysisX;
            delete [] connectAnalysisY;
            delete [] connectAnalysisTempX;
            delete [] connectAnalysisTempY;
            
            for (int counter1 = 0; counter1 < dimension+4; counter1++){
                delete [] connectivityMapCut7 [counter1];
                delete [] connectivityMapCut6 [counter1];
                delete [] connectivityMapCut5 [counter1];
                delete [] connectivityMapCut4 [counter1];
                delete [] connectivityUpdate5 [counter1];
            }
            
            delete [] connectivityMapCut7;
            delete [] connectivityMapCut6;
            delete [] connectivityMapCut5;
            delete [] connectivityMapCut4;
            delete [] connectivityUpdate5;
            
            delete [] snapData;
            
            int numberOfEntry = 0;
            
            if (mitosisRefDataCount != 0){
                numberOfEntry = mitosisRefDataCount/2;
                
                for (int counter1 = 0; counter1 < numberOfEntry; counter1++){
                    targetMapMitosis[arrayMitosisRefData [counter1*2+1]][arrayMitosisRefData [counter1*2]] = 1;
                }
                
                //for (int counterA = 0; counterA < 100; counterA++){
                //    for (int counterB = 0; counterB < 100; counterB++) cout<<" "<<targetMapMitosis [counterA][counterB];
                //    cout<<" targetMapMitosis "<<counterA<<endl;
                //}
                
                errorNoHold = 40;
                double *constA = new double [numberOfEntry+5];
                errorNoHold = 41;
                double *constB = new double [numberOfEntry+5];
                errorNoHold = 42;
                double *distanceTarget = new double [numberOfEntry+5];
                errorNoHold = 43;
                int *xDirection = new int [numberOfEntry+5];
                errorNoHold = 44;
                int *yDirection = new int [numberOfEntry+5];
                errorNoHold = 45;
                int *xDistance = new int [numberOfEntry+5];
                errorNoHold = 46;
                int *yDistance = new int [numberOfEntry+5];
                
                for (int counter1 = 0; counter1 < numberOfEntry; counter1++){
                    constA [counter1] = 0;
                    constB [counter1] = 0;
                    xDirection [counter1] = 0;
                    yDirection [counter1] = 0;
                    distanceTarget [counter1] = 0;
                    xDistance [counter1] = 0;
                    yDistance [counter1] = 0;
                }
                
                int dataTempX = 0;
                int dataTempY = 0;
                
                double constTempA = 0;
                double constTempB = 0;
                
                for (int counter1 = 0; counter1 < numberOfEntry; counter1++){
                    dataTempX = arrayMitosisRefData [counter1*2];
                    dataTempY = arrayMitosisRefData [counter1*2+1];
                    distanceTarget [counter1] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                    
                    if (dataTempX != 50){
                        constTempA = (50-dataTempY)/(double)(50-dataTempX);
                        constTempB = 50-constTempA*50;
                        constA [counter1] = constTempA;
                        constB [counter1] = constTempB;
                        
                        if (constTempB == 50 && dataTempX > 50){
                            xDirection [counter1] = 1;
                            yDirection [counter1] = 0;
                            xDistance [counter1] = dataTempX-50;
                            yDistance [counter1] = 0;
                        }
                        else if (constTempB == 50 && dataTempX < 50){
                            xDirection [counter1] = -1;
                            yDirection [counter1] = 0;
                            xDistance [counter1] = 50-dataTempX;
                            yDistance [counter1] = 0;
                        }
                        else if (constTempB != 50 && dataTempX > 50 && dataTempY > 50){
                            xDirection [counter1] = 1;
                            yDirection [counter1] = 1;
                            xDistance [counter1] = dataTempX-50;
                            yDistance [counter1] = dataTempY-50;
                        }
                        else if (constTempB != 50 && dataTempX < 50 && dataTempY > 50){
                            xDirection [counter1] = -1;
                            yDirection [counter1] = 1;
                            xDistance [counter1] = 50-dataTempX;
                            yDistance [counter1] = dataTempY-50;
                        }
                        else if (constTempB != 50 && dataTempX > 50 && dataTempY < 50){
                            xDirection [counter1] = 1;
                            yDirection [counter1] = -1;
                            xDistance [counter1] = dataTempX-50;
                            yDistance [counter1] = 50-dataTempY;
                        }
                        else if (constTempB != 50 && dataTempX < 50 && dataTempY < 50){
                            xDirection [counter1] = -1;
                            yDirection [counter1] = -1;
                            xDistance [counter1] = 50-dataTempX;
                            yDistance [counter1] = 50-dataTempY;
                        }
                    }
                    else{
                        
                        if (dataTempY < 50){
                            xDirection [counter1] = 0;
                            yDirection [counter1] = -1;
                            xDistance [counter1] = 0;
                            yDistance [counter1] = 50-dataTempY;
                        }
                        else if (dataTempY > 50){
                            xDirection [counter1] = 0;
                            yDirection [counter1] = 1;
                            xDistance [counter1] = 0;
                            yDistance [counter1] = dataTempY-50;
                        }
                    }
                }
                
                //for (int counter1 = 0; counter1 < numberOfEntry; counter1++){
                //    cout<<counter1<<" Dis "<<distanceTarget [counter1]<<" CA "<<constA [counter1]<<" CB "<<constB [counter1]<<endl;
                //    cout<<" xDir "<<xDirection [counter1]<<" yDir "<<yDirection [counter1]<<" xDis "<<xDistance [counter1]<<" yDis "<<yDistance [counter1]<<endl;
                //}
                
                errorNoHold = 47;
                double *distanceReference = new double [numberOfEntry+5];
                errorNoHold = 48;
                double *matchTagSD = new double [lastPatternNumber+1];
                errorNoHold = 49;
                double *matchRefSD = new double [lastPatternNumber+1];
                errorNoHold = 50;
                double *averageTag = new double [lastPatternNumber+1];
                errorNoHold = 51;
                double *averageRef = new double [lastPatternNumber+1];
                errorNoHold = 52;
                double *areaHold = new double [lastPatternNumber+1];
                
                for (int counter1 = 1; counter1 < lastPatternNumber+1; counter1++){
                    matchTagSD [counter1] = 0;
                    matchRefSD [counter1] = 0;
                    averageTag [counter1] = 0;
                    averageRef [counter1] = 0;
                }
                
                double totalValue = 0;
                double totalForSD = 0;
                double constTempRefA = 0;
                double constTempRefB = 0;
                
                int refEntryNumber = 0;
                int areaSize = 0;
                int findFlag = 0;
                int entryRefCount = 0;
                
                //------SD determination------
                for (int counter1 = 1; counter1 < lastPatternNumber+1; counter1++){
                    for (int counterX = 0; counterX < 100; counterX++){
                        for (int counterY = 0; counterY < 100; counterY++) referenceMap[counterX][counterY] = 0;
                    }
                    
                    refEntryNumber = 0;
                    areaSize = 0;
                    
                    for (int counter2 = 0; counter2 < mitosisPatternCount/4; counter2++){
                        if (counter1 == arrayMitosisPattern [counter2*4]){
                            referenceMap[arrayMitosisPattern [counter2*4+2]][arrayMitosisPattern [counter2*4+1]] = 1;
                            refEntryNumber++;
                            
                            areaSize = arrayMitosisPattern [counter2*4+3];
                        }
                    }
                    
                    areaHold [counter1] = areaSize;
                    
                    //for (int counterA = 0; counterA < 100; counterA++){
                    //    for (int counterB = 0; counterB < 100; counterB++) cout<<" "<<referenceMap [counterA][counterB];
                    //    cout<<" referenceMap "<<counterA<<endl;
                    //}
                    
                    //------TARG to REF------
                    for (int counter2 = 0; counter2 < numberOfEntry; counter2++) distanceReference [counter2] = 0;
                    
                    for (int counter2 = 0; counter2 < numberOfEntry; counter2++){
                        findFlag = 0;
                        
                        if (xDirection [counter2] == 0 && yDirection [counter2] == 1){
                            for (int counter3 = 51; counter3 < 99; counter3++){
                                if (referenceMap[counter3][50] == 1){
                                    distanceReference [counter2] = counter3-50;
                                    findFlag = 1;
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                for (int counter3 = 51; counter3 < 99; counter3++){
                                    if (referenceMap[counter3][49] == 1) findFlag = 1;
                                    else if (referenceMap[counter3][51] == 1) findFlag = 1;
                                    else if (referenceMap[counter3+1][50] == 1) findFlag = 1;
                                    else if (referenceMap[counter3-1][50] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceReference [counter2] = counter3-50;
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceReference [counter2] = 50;
                        }
                        else if (xDirection [counter2] == 0 && yDirection [counter2] == -1){
                            for (int counter3 = 49; counter3 > 0; counter3--){
                                if (referenceMap[counter3][50] == 1){
                                    distanceReference [counter2] = 50-counter3;
                                    findFlag = 1;
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                for (int counter3 = 49; counter3 > 0; counter3--){
                                    if (referenceMap[counter3][49] == 1) findFlag = 1;
                                    else if (referenceMap[counter3][51] == 1) findFlag = 1;
                                    else if (referenceMap[counter3-1][50] == 1) findFlag = 1;
                                    else if (referenceMap[counter3+1][50] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceReference [counter2] = 50-counter3;
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceReference [counter2] = 50;
                        }
                        else if (xDirection [counter2] == 1 && yDirection [counter2] == 0){
                            for (int counter3 = 51; counter3 < 99; counter3++){
                                if (referenceMap[50][counter3] == 1){
                                    distanceReference [counter2] = counter3-50;
                                    findFlag = 1;
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                for (int counter3 = 51; counter3 < 99; counter3++){
                                    if (referenceMap[49][counter3] == 1) findFlag = 1;
                                    else if (referenceMap[51][counter3] == 1) findFlag = 1;
                                    else if (referenceMap[50][counter3-1] == 1) findFlag = 1;
                                    else if (referenceMap[50][counter3+1] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceReference [counter2] = counter3-50;
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceReference [counter2] = 50;
                        }
                        else if (xDirection [counter2] == -1 && yDirection [counter2] == 0){
                            for (int counter3 = 49; counter3 > 0; counter3--){
                                if (referenceMap[50][counter3] == 1){
                                    distanceReference [counter2] = 50-counter3;
                                    findFlag = 1;
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                for (int counter3 = 49; counter3 > 0; counter3--){
                                    if (referenceMap[49][counter3] == 1) findFlag = 1;
                                    else if (referenceMap[51][counter3] == 1) findFlag = 1;
                                    else if (referenceMap[50][counter3-1] == 1) findFlag = 1;
                                    else if (referenceMap[50][counter3+1] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceReference [counter2] = 50-counter3;
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceReference [counter2] = 50;
                        }
                        else if (xDirection [counter2] == 1 && yDirection [counter2] == 1){
                            constTempA = constA [counter2];
                            constTempB = constB [counter2];
                            
                            if (xDistance [counter2] > yDistance [counter2]){
                                for (int counter3 = 51; counter3 < 99; counter3++){
                                    dataTempX = counter3;
                                    dataTempY = (int)(constTempA*dataTempX+constTempB);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" ++XY-A "<<referenceMap[dataTempY][dataTempX]<<endl;
                                    
                                    if (referenceMap[dataTempY][dataTempX] == 1){
                                        distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        findFlag = 1;
                                        
                                        //cout<<"DIS1++ "<<distanceReference [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                                
                                if (findFlag == 0){
                                    for (int counter3 = 51; counter3 < 99; counter3++){
                                        dataTempX = counter3;
                                        dataTempY = (int)(constTempA*dataTempX+constTempB);
                                        
                                        //cout<<dataTempX<<" "<<dataTempY<<" ++XY-A  "<<referenceMap[dataTempY][dataTempX]<<endl;
                                        
                                        if (referenceMap[dataTempY-1][dataTempX] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY+1][dataTempX] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY][dataTempX-1] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY][dataTempX+1] == 1) findFlag = 1;
                                        
                                        if (findFlag == 1){
                                            distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                            
                                            //cout<<"DIS2++ "<<distanceReference [counter2]<<endl;
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (findFlag == 0) distanceReference [counter2] = 50;
                            }
                            
                            if (xDistance [counter2] <= yDistance [counter2]){
                                for (int counter3 = 51; counter3 < 99; counter3++){
                                    dataTempY = counter3;
                                    dataTempX = (int)((dataTempY-constTempB)/(double)constTempA);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" ++XY-B "<<referenceMap[dataTempY][dataTempX]<<endl;
                                    
                                    if (referenceMap[dataTempY][dataTempX] == 1){
                                        distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        findFlag = 1;
                                        
                                        //cout<<"DIS3++ "<<distanceReference [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                                
                                if (findFlag == 0){
                                    for (int counter3 = 51; counter3 < 99; counter3++){
                                        dataTempY = counter3;
                                        dataTempX = (int)((dataTempY-constTempB)/(double)constTempA);
                                        
                                        //cout<<dataTempX<<" "<<dataTempY<<" ++XY-B "<<referenceMap[dataTempY][dataTempX]<<endl;
                                        
                                        if (referenceMap[dataTempY-1][dataTempX] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY+1][dataTempX] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY][dataTempX-1] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY][dataTempX+1] == 1) findFlag = 1;
                                        
                                        if (findFlag == 1){
                                            distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                            
                                            //cout<<"DIS4++ "<<distanceReference [counter2]<<endl;
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (findFlag == 0) distanceReference [counter2] = 50;
                            }
                        }
                        else if (xDirection [counter2] == 1 && yDirection [counter2] == -1){
                            constTempA = constA [counter2];
                            constTempB = constB [counter2];
                            
                            //cout<<constTempA<<" "<<constTempB<<" CONSTAB+- "<<xDistance [counter2]<<" "<<yDistance [counter2]<<endl;
                            
                            if (xDistance [counter2] > yDistance [counter2]){
                                for (int counter3 = 51; counter3 < 99; counter3++){
                                    dataTempX = counter3;
                                    dataTempY = (int)(constTempA*dataTempX+constTempB);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" +-XY-A "<<referenceMap[dataTempY][dataTempX]<<endl;
                                    
                                    if (referenceMap[dataTempY][dataTempX] == 1){
                                        distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        findFlag = 1;
                                        
                                        //cout<<"DIS5++ "<<distanceReference [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                                
                                if (findFlag == 0){
                                    for (int counter3 = 51; counter3 < 99; counter3++){
                                        dataTempX = counter3;
                                        dataTempY = (int)(constTempA*dataTempX+constTempB);
                                        
                                        //cout<<dataTempX<<" "<<dataTempY<<" +-XY-B "<<referenceMap[dataTempY][dataTempX]<<endl;
                                        
                                        if (referenceMap[dataTempY-1][dataTempX] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY+1][dataTempX] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY][dataTempX-1] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY][dataTempX+1] == 1) findFlag = 1;
                                        
                                        if (findFlag == 1){
                                            distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                            
                                            //cout<<"DIS6++ "<<distanceReference [counter2]<<endl;
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (findFlag == 0) distanceReference [counter2] = 50;
                            }
                            
                            if (xDistance [counter2] <= yDistance [counter2]){
                                for (int counter3 = 49; counter3 > 0; counter3--){
                                    dataTempY = counter3;
                                    dataTempX = (int)((dataTempY-constTempB)/(double)constTempA);
                                    
                                    //cout<<counter3<<" "<<dataTempX<<" "<<dataTempY<<" +-XY-B "<<referenceMap[dataTempY][dataTempX]<<endl;
                                    
                                    if (referenceMap[dataTempY][dataTempX] == 1){
                                        distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        findFlag = 1;
                                        
                                        //cout<<"DIS7++ "<<distanceReference [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                                
                                if (findFlag == 0){
                                    for (int counter3 = 49; counter3 > 0; counter3--){
                                        dataTempY = counter3;
                                        dataTempX = (int)((dataTempY-constTempB)/(double)constTempA);
                                        
                                        //cout<<dataTempX<<" "<<dataTempY<<" +-XY-A "<<referenceMap[dataTempY][dataTempX]<<endl;
                                        
                                        if (referenceMap[dataTempY-1][dataTempX] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY+1][dataTempX] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY][dataTempX-1] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY][dataTempX+1] == 1) findFlag = 1;
                                        
                                        if (findFlag == 1){
                                            distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                            
                                            //cout<<"DIS8++ "<<distanceReference [counter2]<<endl;
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (findFlag == 0) distanceReference [counter2] = 50;
                            }
                        }
                        else if (xDirection [counter2] == -1 && yDirection [counter2] == 1){
                            constTempA = constA [counter2];
                            constTempB = constB [counter2];
                            
                            //cout<<constTempA<<" "<<constTempB<<" CONSTAB-+ "<<xDistance [counter2]<<" "<<yDistance [counter2]<<endl;
                            
                            if (xDistance [counter2] > yDistance [counter2]){
                                for (int counter3 = 49; counter3 > 0; counter3--){
                                    dataTempX = counter3;
                                    dataTempY = (int)(constTempA*dataTempX+constTempB);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" -+XY-A "<<referenceMap[dataTempY][dataTempX]<<endl;
                                    
                                    if (referenceMap[dataTempY][dataTempX] == 1){
                                        distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        findFlag = 1;
                                        
                                        //cout<<"DIS9++ "<<distanceReference [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                                
                                if (findFlag == 0){
                                    
                                    //cout<<"redo-+"<<endl;
                                    
                                    for (int counter3 = 49; counter3 > 0; counter3--){
                                        dataTempX = counter3;
                                        dataTempY = (int)(constTempA*dataTempX+constTempB);
                                        
                                        //cout<<dataTempX<<" "<<dataTempY<<" +-XY-A "<<referenceMap[dataTempY][dataTempX]<<endl;
                                        
                                        if (referenceMap[dataTempY-1][dataTempX] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY+1][dataTempX] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY][dataTempX-1] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY][dataTempX+1] == 1) findFlag = 1;
                                        
                                        if (findFlag == 1){
                                            distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                            
                                            //cout<<"DIS10++ "<<distanceReference [counter2]<<endl;
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (findFlag == 0) distanceReference [counter2] = 50;
                            }
                            
                            if (xDistance [counter2] <= yDistance [counter2]){
                                for (int counter3 = 51; counter3 < 99; counter3++){
                                    dataTempY = counter3;
                                    dataTempX = (int)((dataTempY-constTempB)/(double)constTempA);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" -+XY-B "<<referenceMap[dataTempY][dataTempX]<<endl;
                                    
                                    if (referenceMap[dataTempY][dataTempX] == 1){
                                        distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        findFlag = 1;
                                        
                                        //cout<<"DIS11++ "<<distanceReference [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                                
                                if (findFlag == 0){
                                    
                                    //cout<<"redo-+"<<endl;
                                    
                                    for (int counter3 = 51; counter3 < 99; counter3++){
                                        dataTempY = counter3;
                                        dataTempX = (int)((dataTempY-constTempB)/(double)constTempA);
                                        
                                        //cout<<dataTempX<<" "<<dataTempY<<" +-XY-A "<<referenceMap[dataTempY][dataTempX]<<endl;
                                        
                                        if (referenceMap[dataTempY-1][dataTempX] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY+1][dataTempX] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY][dataTempX-1] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY][dataTempX+1] == 1) findFlag = 1;
                                        
                                        if (findFlag == 1){
                                            distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                            
                                            //cout<<"DIS12++ "<<distanceReference [counter2]<<endl;
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (findFlag == 0) distanceReference [counter2] = 50;
                            }
                        }
                        else if (xDirection [counter2] == -1 && yDirection [counter2] == -1){
                            constTempA = constA [counter2];
                            constTempB = constB [counter2];
                            
                            //cout<<constTempA<<" "<<constTempB<<" CONSTAB-- "<<xDistance [counter2]<<" "<<yDistance [counter2]<<endl;
                            
                            if (xDistance [counter2] > yDistance [counter2]){
                                for (int counter3 = 49; counter3 > 0; counter3--){
                                    dataTempX = counter3;
                                    dataTempY = (int)(constTempA*dataTempX+constTempB);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" --XY-A "<<referenceMap[dataTempY][dataTempX]<<endl;
                                    
                                    if (referenceMap[dataTempY][dataTempX] == 1){
                                        distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        findFlag = 1;
                                        
                                        //cout<<"DIS13++ "<<distanceReference [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                                
                                if (findFlag == 0){
                                    for (int counter3 = 49; counter3 > 0; counter3--){
                                        dataTempX = counter3;
                                        dataTempY = (int)(constTempA*dataTempX+constTempB);
                                        
                                        //cout<<dataTempX<<" "<<dataTempY<<" +-XY-A "<<referenceMap[dataTempY][dataTempX]<<endl;
                                        
                                        if (referenceMap[dataTempY-1][dataTempX] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY+1][dataTempX] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY][dataTempX-1] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY][dataTempX+1] == 1) findFlag = 1;
                                        
                                        if (findFlag == 1){
                                            distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                            
                                            //cout<<"DIS14++ "<<distanceReference [counter2]<<endl;
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (findFlag == 0) distanceReference [counter2] = 50;
                            }
                            
                            if (xDistance [counter2] <= yDistance [counter2]){
                                for (int counter3 = 49; counter3 > 0; counter3--){
                                    dataTempY = counter3;
                                    dataTempX = (int)((dataTempY-constTempB)/(double)constTempA);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" --XY-B "<<referenceMap[dataTempY][dataTempX]<<endl;
                                    
                                    if (referenceMap[dataTempY][dataTempX] == 1){
                                        distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        findFlag = 1;
                                        
                                        //cout<<"DIS15++ "<<distanceReference [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                                
                                if (findFlag == 0){
                                    for (int counter3 = 49; counter3 > 0; counter3--){
                                        dataTempY = counter3;
                                        dataTempX = (int)((dataTempY-constTempB)/(double)constTempA);
                                        
                                        //cout<<dataTempX<<" "<<dataTempY<<" +-XY-A "<<referenceMap[dataTempY][dataTempX]<<endl;
                                        
                                        if (referenceMap[dataTempY-1][dataTempX] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY+1][dataTempX] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY][dataTempX-1] == 1) findFlag = 1;
                                        else if (referenceMap[dataTempY][dataTempX+1] == 1) findFlag = 1;
                                        
                                        if (findFlag == 1){
                                            distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                            
                                            //cout<<"DIS16++ "<<distanceReference [counter2]<<endl;
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (findFlag == 0) distanceReference [counter2] = 50;
                            }
                        }
                    }
                    
                    //for (int counter2 = 0; counter2 < numberOfEntry; counter2++){
                    //	cout<<counter2<<" DisRef "<<distanceReference [counter2]<<" disTarg "<<distanceTarget [counter2]<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < numberOfEntry; counter2++){
                        if (distanceTarget [counter2] != 0) distanceReference [counter2] = distanceReference [counter2]/(double)distanceTarget [counter2];
                        
                        //cout<<counter2<<" DisRef "<<distanceReference [counter2]<<endl;
                    }
                    
                    totalValue = 0;
                    totalForSD = 0;
                    
                    for (int counter2 = 0; counter2 < numberOfEntry; counter2++) totalValue = totalValue+distanceReference [counter2];
                    
                    averageTag [counter1] = totalValue/(double)numberOfEntry;
                    
                    //cout<<"average "<<averageTag [counter1]<<" "<<numberOfEntry<<endl;
                    
                    for (int counter2 = 0; counter2 < numberOfEntry; counter2++){
                        totalForSD = totalForSD+(averageTag [counter1]-distanceReference [counter2])*(averageTag [counter1]-distanceReference [counter2]);
                    }
                    
                    matchTagSD [counter1] = sqrt(totalForSD/((double)(numberOfEntry-1)));
                    
                    //cout<<sqrt(totalForSD/((double)(numberOfEntry-1)))<<" "<<counter1<<" SD"<<endl;
                    
                    //------REF TO TARG------
                    errorNoHold = 53;
                    double *constRefA = new double [refEntryNumber+1];
                    errorNoHold = 54;
                    double *constRefB = new double [refEntryNumber+1];
                    errorNoHold = 55;
                    double *distanceEachRef = new double [refEntryNumber+1];
                    errorNoHold = 56;
                    int *xDirectionRef = new int [refEntryNumber+1];
                    errorNoHold = 57;
                    int *yDirectionRef = new int [refEntryNumber+1];
                    errorNoHold = 58;
                    int *xDistanceRef = new int [refEntryNumber+1];
                    errorNoHold = 59;
                    int *yDistanceRef = new int [refEntryNumber+1];
                    
                    for (int counter2 = 0; counter2 < refEntryNumber; counter2++){
                        constRefA [counter2] = 0;
                        constRefB [counter2] = 0;
                        xDirectionRef [counter2] = 0;
                        yDirectionRef [counter2] = 0;
                        distanceEachRef [counter2] = 0;
                        xDistanceRef [counter2] = 0;
                        yDistanceRef [counter2] = 0;
                    }
                    
                    entryRefCount = 0;
                    
                    for (int counter2 = 0; counter2 < mitosisPatternCount/4; counter2++){
                        if (counter1 == arrayMitosisPattern [counter2*4]){
                            dataTempX = arrayMitosisPattern [counter2*4+1];
                            dataTempY = arrayMitosisPattern [counter2*4+2];
                            distanceEachRef [entryRefCount] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                            
                            if (dataTempX != 50){
                                constTempRefA = (50-dataTempY)/(double)(50-dataTempX);
                                constTempRefB = 50-constTempRefA*50;
                                constRefA [entryRefCount] = constTempRefA;
                                constRefB [entryRefCount] = constTempRefB;
                                
                                if (constTempRefB == 50 && dataTempX > 50){
                                    xDirectionRef [entryRefCount] = 1;
                                    yDirectionRef [entryRefCount] = 0;
                                    xDistanceRef [entryRefCount] = dataTempX-50;
                                    yDistanceRef [entryRefCount] = 0;
                                }
                                if (constTempRefB == 50 && dataTempX < 50){
                                    xDirectionRef [entryRefCount] = -1;
                                    yDirectionRef [entryRefCount] = 0;
                                    xDistanceRef [entryRefCount] = 50-dataTempX;
                                    yDistanceRef [entryRefCount] = 0;
                                }
                                if (constTempRefB != 50 && dataTempX > 50 && dataTempY > 50){
                                    xDirectionRef [entryRefCount] = 1;
                                    yDirectionRef [entryRefCount] = 1;
                                    xDistanceRef [entryRefCount] = dataTempX-50;
                                    yDistanceRef [entryRefCount] = dataTempY-50;
                                }
                                if (constTempRefB != 50 && dataTempX < 50 && dataTempY > 50){
                                    xDirectionRef [entryRefCount] = -1;
                                    yDirectionRef [entryRefCount] = 1;
                                    xDistanceRef [entryRefCount] = 50-dataTempX;
                                    yDistanceRef [entryRefCount] = dataTempY-50;
                                }
                                if (constTempRefB != 50 && dataTempX > 50 && dataTempY < 50){
                                    xDirectionRef [entryRefCount] = 1;
                                    yDirectionRef [entryRefCount] = -1;
                                    xDistanceRef [entryRefCount] = dataTempX-50;
                                    yDistanceRef [entryRefCount] = 50-dataTempY;
                                }
                                if (constTempRefB != 50 && dataTempX < 50 && dataTempY < 50){
                                    xDirectionRef [entryRefCount] = -1;
                                    yDirectionRef [entryRefCount] = -1;
                                    xDistanceRef [entryRefCount] = 50-dataTempX;
                                    yDistanceRef [entryRefCount] = 50-dataTempY;
                                }
                            }
                            else{
                                
                                if (dataTempY < 50){
                                    xDirectionRef [entryRefCount] = 0;
                                    yDirectionRef [entryRefCount] = -1;
                                    xDistanceRef [entryRefCount] = 0;
                                    yDistanceRef [entryRefCount] = 50-dataTempY;
                                }
                                if (dataTempY > 50){
                                    xDirectionRef [entryRefCount] = 0;
                                    yDirectionRef [entryRefCount] = 1;
                                    xDistanceRef [entryRefCount] = 0;
                                    yDistanceRef [entryRefCount] = dataTempY-50;
                                }
                            }
                            
                            entryRefCount++;
                        }
                    }
                    
                    //for (int counter2 = 0; counter2 < refEntryNumber; counter2++){
                    //	cout<<counter2<<" DisRef "<<distanceEachRef [counter2]<<" CA "<<constRefA [counter2]<<" cB "<<constRefB [counter2]<<" xDir "<<xDirectionRef [counter2]<<" yDir "<<yDirectionRef [counter2] <<" xDis "<<xDistanceRef [counter2]<<" yDis "<<yDistanceRef [counter2]<<endl;
                    //}
                    
                    errorNoHold = 60;
                    double *distanceEachToTarget = new double [refEntryNumber+5];
                    
                    for (int counter2 = 0; counter2 < refEntryNumber; counter2++) distanceEachToTarget [counter2] = 0;
                    
                    for (int counter2 = 0; counter2 < refEntryNumber; counter2++){
                        findFlag = 0;
                        
                        if (xDirectionRef [counter2] == 0 && yDirectionRef [counter2] == 1){
                            for (int counter3 = 51; counter3 < 99; counter3++){
                                if (targetMapMitosis [counter3][50] == 1){
                                    distanceEachToTarget [counter2] = counter3-50;
                                    findFlag = 1;
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                for (int counter3 = 51; counter3 < 99; counter3++){
                                    if (targetMapMitosis [counter3][49] == 1) findFlag = 1;
                                    else if (targetMapMitosis [counter3][51] == 1) findFlag = 1;
                                    else if (targetMapMitosis [counter3+1][50] == 1) findFlag = 1;
                                    else if (targetMapMitosis [counter3-1][50] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceEachToTarget [counter2] = counter3-50;
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                        }
                        else if (xDirectionRef [counter2] == 0 && yDirectionRef [counter2] == -1){
                            for (int counter3 = 49; counter3 > 0; counter3--){
                                if (targetMapMitosis [counter3][50] == 1){
                                    distanceEachToTarget [counter2] = 50-counter3;
                                    findFlag = 1;
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                for (int counter3 = 49; counter3 > 0; counter3--){
                                    if (targetMapMitosis [counter3][49] == 1) findFlag = 1;
                                    else if (targetMapMitosis [counter3][51] == 1) findFlag = 1;
                                    else if (targetMapMitosis [counter3-1][50] == 1) findFlag = 1;
                                    else if (targetMapMitosis [counter3+1][50] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceEachToTarget [counter2] = 50-counter3;
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                        }
                        else if (xDirectionRef [counter2] == 1 && yDirectionRef [counter2] == 0){
                            for (int counter3 = 51; counter3 < 99; counter3++){
                                if (targetMapMitosis [50][counter3] == 1){
                                    distanceEachToTarget [counter2] = counter3-50;
                                    findFlag = 1;
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                for (int counter3 = 51; counter3 < 99; counter3++){
                                    if (targetMapMitosis [49][counter3] == 1) findFlag = 1;
                                    else if (targetMapMitosis [51][counter3] == 1) findFlag = 1;
                                    else if (targetMapMitosis [50][counter3-1] == 1) findFlag = 1;
                                    else if (targetMapMitosis [50][counter3+1] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceEachToTarget [counter2] = counter3-50;
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                        }
                        else if (xDirectionRef [counter2] == -1 && yDirectionRef [counter2] == 0){
                            for (int counter3 = 49; counter3 > 0; counter3--){
                                if (targetMapMitosis [50][counter3] == 1){
                                    distanceEachToTarget [counter2] = 50-counter3;
                                    findFlag = 1;
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                for (int counter3 = 49; counter3 > 0; counter3--){
                                    if (targetMapMitosis [49][counter3] == 1) findFlag = 1;
                                    else if (targetMapMitosis [51][counter3] == 1) findFlag = 1;
                                    else if (targetMapMitosis [50][counter3-1] == 1) findFlag = 1;
                                    else if (targetMapMitosis [50][counter3+1] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceEachToTarget [counter2] = 50-counter3;
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                        }
                        else if (xDirectionRef [counter2] == 1 && yDirectionRef [counter2] == 1){
                            constTempRefA = constRefA [counter2];
                            constTempRefB = constRefB [counter2];
                            
                            if (xDistanceRef [counter2] > yDistanceRef [counter2]){
                                for (int counter3 = 51; counter3 < 99; counter3++){
                                    dataTempX = counter3;
                                    dataTempY = (int)(constTempRefA*dataTempX+constTempRefB);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" ++XY-A "<<targetMapMitosis[dataTempY][dataTempX]<<endl;
                                    
                                    if (targetMapMitosis [dataTempY][dataTempX] == 1){
                                        distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        findFlag = 1;
                                        
                                        //cout<<"DIS1++ "<<distanceEachToTarget [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                                
                                if (findFlag == 0){
                                    for (int counter3 = 51; counter3 < 99; counter3++){
                                        dataTempX = counter3;
                                        dataTempY = (int)(constTempRefA*dataTempX+constTempRefB);
                                        
                                        if (targetMapMitosis [dataTempY-1][dataTempX] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY+1][dataTempX] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY][dataTempX-1] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY][dataTempX+1] == 1) findFlag = 1;
                                        
                                        if (findFlag == 1){
                                            distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                            
                                            //cout<<"DIS2++ "<<distanceEachToTarget [counter2]<<endl;
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                            }
                            
                            if (xDistanceRef [counter2] <= yDistanceRef [counter2]){
                                for (int counter3 = 51; counter3 < 99; counter3++){
                                    dataTempY = counter3;
                                    dataTempX = (int)((dataTempY-constTempRefB)/(double)constTempRefA);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" ++XY-B "<<targetMapMitosis[dataTempY][dataTempX]<<endl;
                                    
                                    if (targetMapMitosis [dataTempY][dataTempX] == 1){
                                        distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        findFlag = 1;
                                        
                                        //cout<<"DIS3++ "<<distanceEachToTarget [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                                
                                if (findFlag == 0){
                                    for (int counter3 = 51; counter3 < 99; counter3++){
                                        dataTempY = counter3;
                                        dataTempX = (int)((dataTempY-constTempRefB)/(double)constTempRefA);
                                        
                                        if (targetMapMitosis [dataTempY-1][dataTempX] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY+1][dataTempX] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY][dataTempX-1] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY][dataTempX+1] == 1) findFlag = 1;
                                        
                                        if (findFlag == 1){
                                            distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                            
                                            //cout<<"DIS4++ "<<distanceEachToTarget [counter2]<<endl;
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                            }
                        }
                        else if (xDirectionRef [counter2] == 1 && yDirectionRef [counter2] == -1){
                            constTempRefA = constRefA [counter2];
                            constTempRefB = constRefB [counter2];
                            
                            //cout<<constTempRefA<<" "<<constTempRefB<<" CONSTAB+- "<<xDistanceRef [counter2]<<" "<<yDistanceRef [counter2]<<endl;
                            
                            if (xDistanceRef [counter2] > yDistanceRef [counter2]){
                                for (int counter3 = 51; counter3 < 99; counter3++){
                                    dataTempX = counter3;
                                    dataTempY = (int)(constTempRefA*dataTempX+constTempRefB);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" +-XY-A "<<targetMapMitosis[dataTempY][dataTempX]<<endl;
                                    
                                    if (targetMapMitosis [dataTempY][dataTempX] == 1){
                                        distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        findFlag = 1;
                                        
                                        //cout<<"DIS5++ "<<distanceEachToTarget [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                                
                                if (findFlag == 0){
                                    for (int counter3 = 51; counter3 < 99; counter3++){
                                        dataTempX = counter3;
                                        dataTempY = (int)(constTempRefA*dataTempX+constTempRefB);
                                        
                                        //cout<<dataTempX<<" "<<dataTempY<<" +-XY-B "<<targetMapMitosis[dataTempY][dataTempX]<<endl;
                                        
                                        if (targetMapMitosis [dataTempY-1][dataTempX] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY+1][dataTempX] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY][dataTempX-1] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY][dataTempX+1] == 1) findFlag = 1;
                                        
                                        if (findFlag == 1){
                                            distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                            
                                            //cout<<"DIS6++ "<<distanceEachToTarget [counter2]<<endl;
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                            }
                            
                            if (xDistanceRef [counter2] <= yDistanceRef [counter2]){
                                for (int counter3 = 49; counter3 > 0; counter3--){
                                    dataTempY = counter3;
                                    dataTempX = (int)((dataTempY-constTempRefB)/(double)constTempRefA);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" +-XY-B "<<targetMapMitosis[dataTempY][dataTempX]<<endl;
                                    
                                    if (targetMapMitosis [dataTempY][dataTempX] == 1){
                                        distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        findFlag = 1;
                                        
                                        //cout<<"DIS7++ "<<distanceEachToTarget [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                                
                                if (findFlag == 0){
                                    for (int counter3 = 49; counter3 > 0; counter3--){
                                        dataTempY = counter3;
                                        dataTempX = (int)((dataTempY-constTempRefB)/(double)constTempRefA);
                                        
                                        if (targetMapMitosis [dataTempY-1][dataTempX] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY+1][dataTempX] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY][dataTempX-1] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY][dataTempX+1] == 1) findFlag = 1;
                                        
                                        if (findFlag == 1){
                                            distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                            
                                            //cout<<"DIS8++ "<<distanceEachToTarget [counter2]<<endl;
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                            }
                        }
                        else if (xDirectionRef [counter2] == -1 && yDirectionRef [counter2] == 1){
                            constTempRefA = constRefA [counter2];
                            constTempRefB = constRefB [counter2];
                            
                            //cout<<constTempRefA<<" "<<constTempRefB<<" CONSTAB-+ "<<xDistanceRef [counter2]<<" "<<yDistanceRef [counter2]<<endl;
                            
                            if (xDistanceRef [counter2] > yDistanceRef [counter2]){
                                for (int counter3 = 49; counter3 > 0; counter3--){
                                    dataTempX = counter3;
                                    dataTempY = (int)(constTempRefA*dataTempX+constTempRefB);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" -+XY-A "<<targetMapMitosis[dataTempY][dataTempX]<<endl;
                                    
                                    if (targetMapMitosis [dataTempY][dataTempX] == 1){
                                        distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        findFlag = 1;
                                        
                                        //cout<<"DIS9++ "<<distanceEachToTarget [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                                
                                if (findFlag == 0){
                                    
                                    //cout<<"redo-+"<<endl;
                                    
                                    for (int counter3 = 49; counter3 > 0; counter3--){
                                        dataTempX = counter3;
                                        dataTempY = (int)(constTempRefA*dataTempX+constTempRefB);
                                        
                                        if (targetMapMitosis [dataTempY-1][dataTempX] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY+1][dataTempX] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY][dataTempX-1] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY][dataTempX+1] == 1) findFlag = 1;
                                        
                                        if (findFlag == 1){
                                            distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                            
                                            //cout<<"DIS10++ "<<distanceEachToTarget [counter2]<<endl;
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                            }
                            
                            if (xDistanceRef [counter2] <= yDistanceRef [counter2]){
                                for (int counter3 = 51; counter3 < 99; counter3++){
                                    dataTempY = counter3;
                                    dataTempX = (int)((dataTempY-constTempRefB)/(double)constTempRefA);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" -+XY-B "<<targetMapMitosis[dataTempY][dataTempX]<<endl;
                                    
                                    if (targetMapMitosis [dataTempY][dataTempX] == 1){
                                        distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        findFlag = 1;
                                        
                                        //cout<<"DIS11++ "<<distanceEachToTarget [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                                
                                if (findFlag == 0){
                                    
                                    //cout<<"redo-+"<<endl;
                                    
                                    for (int counter3 = 51; counter3 < 99; counter3++){
                                        dataTempY = counter3;
                                        dataTempX = (int)((dataTempY-constTempRefB)/(double)constTempRefA);
                                        
                                        if (targetMapMitosis [dataTempY-1][dataTempX] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY+1][dataTempX] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY][dataTempX-1] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY][dataTempX+1] == 1) findFlag = 1;
                                        
                                        if (findFlag == 1){
                                            distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                            
                                            //cout<<"DIS12++ "<<distanceEachToTarget [counter2]<<endl;
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                            }
                        }
                        else if (xDirectionRef [counter2] == -1 && yDirectionRef [counter2] == -1){
                            constTempRefA = constRefA [counter2];
                            constTempRefB = constRefB [counter2];
                            
                            //cout<<constTempRefA<<" "<<constTempRefB<<" CONSTAB-- "<<xDistanceRef [counter2]<<" "<<yDistanceRef [counter2]<<endl;
                            
                            if (xDistanceRef [counter2] > yDistanceRef [counter2]){
                                for (int counter3 = 49; counter3 > 0; counter3--){
                                    dataTempX = counter3;
                                    dataTempY = (int)(constTempRefA*dataTempX+constTempRefB);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" --XY-A "<<targetMapMitosis[dataTempY][dataTempX]<<endl;
                                    
                                    if (targetMapMitosis [dataTempY][dataTempX] == 1){
                                        distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        findFlag = 1;
                                        
                                        //cout<<"DIS13++ "<<distanceEachToTarget [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                                
                                if (findFlag == 0){
                                    for (int counter3 = 49; counter3 > 0; counter3--){
                                        dataTempX = counter3;
                                        dataTempY = (int)(constTempRefA*dataTempX+constTempRefB);
                                        
                                        if (targetMapMitosis [dataTempY-1][dataTempX] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY+1][dataTempX] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY][dataTempX-1] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY][dataTempX+1] == 1) findFlag = 1;
                                        
                                        if (findFlag == 1){
                                            distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                            
                                            //cout<<"DIS14++ "<<distanceEachToTarget [counter2]<<endl;
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                            }
                            
                            if (xDistanceRef [counter2] <= yDistanceRef [counter2]){
                                for (int counter3 = 49; counter3 > 0; counter3--){
                                    dataTempY = counter3;
                                    dataTempX = (int)((dataTempY-constTempRefB)/(double)constTempRefA);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" --XY-B "<<targetMapMitosis[dataTempY][dataTempX]<<endl;
                                    
                                    if (targetMapMitosis [dataTempY][dataTempX] == 1){
                                        distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        findFlag = 1;
                                        
                                        //cout<<"DIS15++ "<<distanceEachToTarget [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                                
                                if (findFlag == 0){
                                    for (int counter3 = 49; counter3 > 0; counter3--){
                                        dataTempY = counter3;
                                        dataTempX = (int)((dataTempY-constTempRefB)/(double)constTempRefA);
                                        
                                        if (targetMapMitosis [dataTempY-1][dataTempX] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY+1][dataTempX] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY][dataTempX-1] == 1) findFlag = 1;
                                        else if (targetMapMitosis [dataTempY][dataTempX+1] == 1) findFlag = 1;
                                        
                                        if (findFlag == 1){
                                            distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                            
                                            //cout<<"DIS16++ "<<distanceEachToTarget [counter2]<<endl;
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                            }
                        }
                    }
                    
                    //for (int counter2 = 0; counter2 < refEntryNumber; counter2++){
                    //	cout<<counter2<<" DisRef2 "<<distanceEachRef [counter2]<<" disToTarg "<<distanceEachToTarget [counter2]<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < refEntryNumber; counter2++){
                        if (distanceEachRef [counter2] != 0){
                            distanceEachToTarget [counter2] = distanceEachToTarget [counter2]/(double)distanceEachRef [counter2];
                            
                            //cout<<counter2<<" DisRef3 "<<distanceEachToTarget [counter2]<<endl;
                        }
                    }
                    
                    totalValue = 0;
                    totalForSD = 0;
                    
                    for (int counter2 = 0; counter2 < refEntryNumber; counter2++) totalValue = totalValue+distanceEachToTarget [counter2];
                    
                    averageRef [counter1] = totalValue/(double)refEntryNumber;
                    
                    //cout<<"averageRef "<<averageRef[counter1]<<endl;
                    
                    for (int counter2 = 0; counter2 < refEntryNumber; counter2++){
                        totalForSD = totalForSD+(averageRef[counter1]-distanceEachToTarget [counter2])*(averageRef[counter1]-distanceEachToTarget [counter2]);
                    }
                    
                    matchRefSD [counter1] = sqrt(totalForSD/((double)(refEntryNumber-1)));
                    
                    delete [] distanceEachToTarget;
                    delete [] constRefA;
                    delete [] constRefB;
                    delete [] distanceEachRef;
                    delete [] xDirectionRef;
                    delete [] yDirectionRef;
                    delete [] xDistanceRef;
                    delete [] yDistanceRef;
                }
                
                delete [] constA;
                delete [] constB;
                delete [] distanceTarget;
                delete [] xDirection;
                delete [] yDirection;
                delete [] xDistance;
                delete [] yDistance;
                
                //------Return SD determination------
                errorNoHold = 61;
                double *resultsSD = new double [lastPatternNumber+1];
                errorNoHold = 62;
                double *resultsAverage = new double [lastPatternNumber+1];
                
                for (int counter1 = 1; counter1 < lastPatternNumber+1; counter1++){
                    resultsSD [counter1] = 0;
                    resultsAverage [counter1] = 0;
                }
                
                for (int counter1 = 1; counter1 < lastPatternNumber+1; counter1++){
                    
                    //cout<<counter1<<" "<<matchRefSD [counter1]<<" "<<matchTagSD [counter1]<<" "<<averageRef [counter1]<<" "<<averageTag [counter1]<<" avSDResult"<<endl;
                    
                    if (matchRefSD [counter1] != 0 && matchTagSD [counter1] != 0){
                        if (matchRefSD [counter1] < matchTagSD [counter1]){
                            resultsSD [counter1] = matchRefSD [counter1];
                            resultsAverage [counter1] = averageRef [counter1];
                        }
                        else{
                            
                            resultsSD [counter1] = matchTagSD [counter1];
                            resultsAverage [counter1] = averageTag [counter1];
                        }
                    }
                }
                
                double resultsSDWithArea = 1000;
                
                for (int counter1 = 1; counter1 < lastPatternNumber+1; counter1++){
                    if (originalAreaSize < areaHold [counter1]*5){
                        if (sourceAreaSize < areaHold [counter1]*2 && sourceAreaSize > areaHold [counter1]*0.5){
                            if (resultsAverage [counter1] < 1.25 && resultsAverage [counter1] > 0.75){
                                if (resultsSD [counter1] < resultsSDWithArea) resultsSDWithArea = resultsSD [counter1];
                            }
                        }
                    }
                }
                
                if (resultsSDWithArea == 1000) returnSD = 1000;
                else returnSD = resultsSDWithArea;
                
                //cout<<returnSD<<" RetSD"<<endl;
                
                delete [] distanceReference;
                delete [] matchTagSD;
                delete [] matchRefSD;
                delete [] averageTag;
                delete [] averageRef;
                delete [] resultsSD;
                delete [] resultsAverage;
                delete [] areaHold;
            }
            
            for (int counter1 = 0; counter1 < 101; counter1++){
                delete [] referenceMap [counter1];
                delete [] targetMapMitosis[counter1];
            }
            
            delete [] referenceMap;
            delete [] targetMapMitosis;
            
            delete [] arrayMitosisRefData;
        }
        
        errorNoHold = 0;
        subCompletionFlag2 = 0;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingMitosisPattern "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"MitosisPattern"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
        
        subCompletionFlag2 = 0;
    }
    
    return returnSD; //------Positive, non-cell death, negative cell death---------
}

@end
