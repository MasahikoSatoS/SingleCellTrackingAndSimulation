//
// SourceDisplay.mm
// cell_carving
//
// Created by Masahiko Sato on 10/07/11.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#import "SourceDisplay.h"

NSString *notificationToSourceImage = @"notoficationExecuteSourceImage";

@implementation SourceDisplay

- (id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self){
        cellImage = [[NSImage alloc] initWithContentsOfFile:@""];
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToSourceImage object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    int sizeCheck = 0;
    
    if (blankDisplay == 0){
        int imageSizeTotal = imageDimension*imageDimension;
        
        if (trackAreaSizeDisplay < 200){
            NSBitmapImageRep *bitmapReps;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:trackAreaSizeDisplay pixelsHigh:trackAreaSizeDisplay bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:trackAreaSizeDisplay bitsPerPixel:8];
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            for (int counter1 = 0; counter1 < trackAreaSizeDisplay; counter1++){
                for (int counter2 = 0; counter2 < trackAreaSizeDisplay; counter2++){
                    if ((counter1+verticalPositionHold)*imageDimension+counter2+xDisplayPosition < imageSizeTotal){
                        *bitmapData++ = (unsigned char)sourceImage [mapPositionPointerHold][(counter1+verticalPositionHold)*imageDimension+counter2+xDisplayPosition];
                    }
                    else *bitmapData++ = 150;
                }
            }
            
            cellImage = [[NSImage alloc] initWithSize:NSMakeSize(trackAreaSizeDisplay, trackAreaSizeDisplay)];
            [cellImage addRepresentation:bitmapReps];
        }
        else sizeCheck = 1;
    }
    else{
        
        string backgroundImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"Blank2.jpg";
        NSString *cellImageNSstring = [NSString stringWithCString:backgroundImagePath.c_str() encoding: NSASCIIStringEncoding];
        
        cellImage = [[NSImage alloc] initWithContentsOfFile:cellImageNSstring];
    }
    
    if (sizeCheck == 0) [self setNeedsDisplay:YES];
}

- (void)drawRect:(NSRect)rect{
    if (blankDisplay == 0){
        NSRect srcRect;
        srcRect.origin.x = 0;
        srcRect.origin.y = 0;
        srcRect.size = [cellImage size];
        [cellImage drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
        
        if (cellLineageNoHold != "" && cellNoHold != ""){
            string cellLineageExtract = cellLineageNoHold.substr(1);
            string cellNumberExtract = cellNoHold.substr(1);
            int cellLineageTempInt = atoi(cellLineageExtract.c_str());
            int cellNumberTempInt = atoi(cellNumberExtract.c_str());
            
            int connectNo = 0;
            
            for (int counter1 = 0; counter1 < displayRelCount/6; counter1++){
                if (arrayDisplayRel [counter1*6] == cellLineageTempInt && arrayDisplayRel [counter1*6+3] == cellNumberTempInt){
                    connectNo = arrayDisplayRel [counter1*6+1];
                    break;
                }
            }
            
            NSBezierPath *path3;
            [NSBezierPath setDefaultLineWidth:0.5];
            
            NSPoint positionAA;
            NSPoint positionBB;
            NSPoint positionCC;
            NSPoint positionDD;
            
            xDisplayPosition = xDisplayPosition+trackAreaSizeDisplay/2;
            yDisplayPosition = yDisplayPosition-trackAreaSizeDisplay/2;
            
            int xPointMarkTemp = 0;
            int yPointMarkTemp = 0;
            
            for (int counter1 = 0; counter1 < displayDataCount/7; counter1++){
                if (arrayDisplayData [counter1*7+3] == connectNo && arrayDisplayData [counter1*7+5] == 1){
                    xPointMarkTemp = (int)((arrayDisplayData [counter1*7]-(double)((xDisplayPosition-trackAreaSizeDisplay/(double)2)))*(double)(300/(double)trackAreaSizeDisplay));
                    yPointMarkTemp = (int)(((imageDimension-arrayDisplayData [counter1*7+1])-(yDisplayPosition-(double)(trackAreaSizeDisplay/(double)2)))*(double)(300/(double)trackAreaSizeDisplay));
                    
                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 300 && yPointMarkTemp >= 0 && yPointMarkTemp <= 300){
                        [[NSColor cyanColor] set];
                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, 2.0, 2.0)];
                        [path3 fill];
                    }
                }
                else if (arrayDisplayData [counter1*7+3] != connectNo && arrayDisplayData [counter1*7+5] == 1){
                    xPointMarkTemp = (int)((arrayDisplayData [counter1*7]-(xDisplayPosition-(double)(trackAreaSizeDisplay/(double)2)))*(double)(300/(double)trackAreaSizeDisplay));
                    yPointMarkTemp = (int)(((imageDimension-arrayDisplayData [counter1*7+1])-(yDisplayPosition-(double)(trackAreaSizeDisplay/(double)2)))*(double)(300/(double)trackAreaSizeDisplay));
                    
                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 300 && yPointMarkTemp >= 0 && yPointMarkTemp <= 300){
                        [[NSColor yellowColor] set];
                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, 2.0, 2.0)];
                        [path3 fill];
                    }
                }
                else if (arrayDisplayData [counter1*7+3] != connectNo && arrayDisplayData [counter1*7+5] == 0){
                    xPointMarkTemp = (int)((arrayDisplayData [counter1*7]-(xDisplayPosition-(double)(trackAreaSizeDisplay/(double)2)))*(double)(300/(double)trackAreaSizeDisplay));
                    yPointMarkTemp = (int)(((imageDimension-arrayDisplayData [counter1*7+1])-(yDisplayPosition-(double)(trackAreaSizeDisplay/(double)2)))*(double)(300/(double)trackAreaSizeDisplay));
                    
                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 300 && yPointMarkTemp >= 0 && yPointMarkTemp <= 300){
                        [[NSColor greenColor] set];
                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, 2.0, 2.0)];
                        [path3 fill];
                    }
                }
            }
            
            [[NSColor redColor] set];
            [NSBezierPath setDefaultLineWidth:2.0];
            
            for (int counter1 = 0; counter1 < displayGravityCenterCount/6; counter1++){
                if (arrayDisplayGravityCenter [counter1*6+4] == connectNo){
                    xPointMarkTemp = (int)((arrayDisplayGravityCenter [counter1*6]-(xDisplayPosition-(double)(trackAreaSizeDisplay/(double)2)))*(double)(300/(double)trackAreaSizeDisplay));
                    yPointMarkTemp = (int)(((imageDimension-arrayDisplayGravityCenter [counter1*6+1])-(yDisplayPosition-(double)(trackAreaSizeDisplay/(double)2)))*(double)(300/(double)trackAreaSizeDisplay));
                    
                    positionAA.x = xPointMarkTemp-5;
                    positionAA.y = yPointMarkTemp;
                    positionBB.x = xPointMarkTemp+5;
                    positionBB.y = yPointMarkTemp;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    positionCC.x = xPointMarkTemp;
                    positionCC.y = yPointMarkTemp-5;
                    positionDD.x = xPointMarkTemp;
                    positionDD.y = yPointMarkTemp+5;
                    [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                }
            }
        }
    }
    else{
        
        NSRect srcRect;
        srcRect.origin.x = 0;
        srcRect.origin.y = 0;
        srcRect.size = [cellImage size];
        
        [cellImage drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToSourceImage object:nil];
}

@end
