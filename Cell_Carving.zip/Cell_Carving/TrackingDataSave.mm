//
// TrackingDataSave.mm
// Cell_Carving
//
// Created by Masahiko Sato on 03/01/14.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#import "TrackingDataSave.h"

@implementation TrackingDataSave

-(void)trackingDataSaveTemp:(int)processType{
    try{
        try{
            
            errorNoHold = 0;
            int errorCheckThrow = 0;
            subCompletionFlag = 1;
            
            string extensionLineage;
            
            if (processType == 1) extensionLineage = to_string(imageNumberInt);
            else if (processType == 2) extensionLineage = to_string(imageNumberInt+1);
            else if (processType == 3) extensionLineage = to_string(imageNumberInt);
            
            if (extensionLineage.length() == 1) extensionLineage = "000"+extensionLineage;
            else if (extensionLineage.length() == 2) extensionLineage = "00"+extensionLineage;
            else if (extensionLineage.length() == 3) extensionLineage = "0"+extensionLineage;
            
            ofstream oin;
            
            int dataTemp = 0;
            int totalImageSize = imageDimension*imageDimension*4;
            
            if (processType == 1 || processType == 3){
                string connectDataTempPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_MasterDataTemp";
                
                if (positionReviseCount != 0){
                    int readBit [4];
                    long indexCount = 0;
                    
                    errorNoHold = 1;
                    char *writingArray = new char [(positionReviseCount/7+associatedDataCount/6+gravityCenterRevCount/6)*17+50];
                    
                    for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                        dataTemp = arrayPositionRevise [counter1*7];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        dataTemp = arrayPositionRevise [counter1*7+1];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        writingArray [indexCount] = (char)arrayPositionRevise [counter1*7+2], indexCount++;
                        
                        dataTemp = arrayPositionRevise [counter1*7+3];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = arrayPositionRevise [counter1*7+4];
                        
                        if (dataTemp < 0) dataTemp = dataTemp*-1, writingArray [indexCount] = 1, indexCount++;
                        else writingArray [indexCount] = 0, indexCount++;
                        
                        readBit [0] = dataTemp/16777216;
                        dataTemp = dataTemp%16777216;
                        readBit [1] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [2] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [3] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                        
                        writingArray [indexCount] = (char)arrayPositionRevise [counter1*7+5], indexCount++;
                        
                        dataTemp = arrayPositionRevise [counter1*7+6];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                    }
                    
                    for (int counter1 = 0; counter1 < 17; counter1++) writingArray [indexCount] = 0, indexCount++;
                    
                    for (int counter1 = 0; counter1 < associatedDataCount/6; counter1++){
                        dataTemp = arrayAssociatedData [counter1*6];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)arrayAssociatedData [counter1*6+1], indexCount++;
                        writingArray [indexCount] = (char)arrayAssociatedData [counter1*6+2], indexCount++;
                        
                        dataTemp = arrayAssociatedData [counter1*6+3];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = arrayAssociatedData [counter1*6+4];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        writingArray [indexCount] = (char)arrayAssociatedData [counter1*6+5], indexCount++;
                    }
                    
                    for (int counter1 = 0; counter1 < 11; counter1++) writingArray [indexCount] = 0, indexCount++;
                    
                    for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                        dataTemp = arrayGravityCenterRev [counter1*6];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        dataTemp = arrayGravityCenterRev [counter1*6+1];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        dataTemp = arrayGravityCenterRev [counter1*6+2];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)arrayGravityCenterRev [counter1*6+3], indexCount++;
                        
                        dataTemp = arrayGravityCenterRev [counter1*6+4];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)arrayGravityCenterRev [counter1*6+5], indexCount++;
                    }
                    
                    for (int counter1 = 0; counter1 < 11; counter1++) writingArray [indexCount] = 0, indexCount++;
                    
                    ofstream outfile (connectDataTempPath.c_str(), ofstream::binary);
                    
                    if (outfile.is_open()){
                        outfile.write ((char*)writingArray, indexCount);
                        outfile.close();
                    }
                    else{
                        
                        errorNoHold = 1000;
                        throw errorCheckThrow;
                    }
                    
                    delete [] writingArray;
                }
                
                string connectStatusTempPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_StatusTemp";
                
                //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                //	cout<<" arrayTimeSelected "<<counterA+1<<endl;
                //}
                
                //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
                //	cout<<" arrayGravityCenterRev "<<counterA<<endl;
                //}
                
                if (timeSelectedCount != 0){
                    errorNoHold = 2;
                    char *writingArray = new char [timeSelectedCount/10*19+20];
                    
                    long indexCount = 0;
                    int readBit [3];
                    int connectNumberTemp = 0;
                    
                    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                        writingArray [indexCount] = (char)arrayTimeSelected [counter1*10], indexCount++;
                        writingArray [indexCount] = 0, indexCount++;
                        writingArray [indexCount] = 0, indexCount++;
                        writingArray [indexCount] = 0, indexCount++;
                        
                        dataTemp = arrayTimeSelected [counter1*10+2];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = 0, indexCount++;
                        writingArray [indexCount] = 0, indexCount++;
                        
                        writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+4], indexCount++;
                        writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+5], indexCount++;
                        writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+6], indexCount++;
                        writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+7], indexCount++;
                        
                        dataTemp = arrayTimeSelected [counter1*10+8];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        if (arrayTimeSelected [counter1*10] == 3 || arrayTimeSelected [counter1*10] == 4) connectNumberTemp = 0;
                        else connectNumberTemp = arrayTimeSelected [counter1*10+9];
                        
                        dataTemp = connectNumberTemp;
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                    }
                    
                    for (int counter1 = 0; counter1 < 19; counter1++) writingArray [indexCount] = 0, indexCount++;
                    
                    ofstream outfile2 (connectStatusTempPath.c_str(), ofstream::binary);
                    
                    if (outfile2.is_open()){
                        outfile2.write ((char*) writingArray, indexCount);
                        outfile2.close();
                    }
                    else{
                        
                        errorNoHold = 1001;
                        throw errorCheckThrow;
                    }
                    
                    delete [] writingArray;
                }
                
                //------Connect lineage relation table save------
                string connectRelationTempPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_ConnectLineageRelTemp";
                
                //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
                //	cout<<" arrayConnectLineageRel "<<counterA<<endl;
                //}
                
                if (connectLineageRelCount != 0){
                    errorNoHold = 3;
                    char *writingArray = new char [connectLineageRelCount/6*16+16];
                    
                    long indexCount = 0;
                    int readBit [4];
                    
                    for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                        dataTemp = arrayConnectLineageRel [counter1*6];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = arrayConnectLineageRel [counter1*6+1];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = arrayConnectLineageRel [counter1*6+2];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        if (arrayConnectLineageRel [counter1*6+3] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = arrayConnectLineageRel [counter1*6+3]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = arrayConnectLineageRel [counter1*6+3];
                        }
                        
                        readBit [0] = dataTemp/16777216;
                        dataTemp = dataTemp%16777216;
                        readBit [1] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [2] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [3] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                        
                        writingArray [indexCount] = 0, indexCount++;
                        
                        writingArray [indexCount] = (char)arrayConnectLineageRel [counter1*6+5], indexCount++;
                    }
                    
                    for (int counter1 = 0; counter1 < 15; counter1++) writingArray [indexCount] = 0, indexCount++;
                    
                    ofstream outfile2 (connectRelationTempPath.c_str(), ofstream::binary);
                    
                    if (outfile2.is_open()){
                        outfile2.write ((char*) writingArray, indexCount);
                        outfile2.close();
                    }
                    else{
                        
                        errorNoHold = 1003;
                        throw errorCheckThrow;
                    }
                    
                    delete [] writingArray;
                }
                
                //------Save Revised Map------
                string revisedTempMapPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_RevisedTempMap";
                
                if (imageDimension != 0){
                    errorNoHold = 4;
                    char *dataHold = new char [totalImageSize];
                    int indexCount = 0;
                    int dataTemp2 = 0;
                    int entryCount = 0;
                    int readBit [4];
                    
                    for (int counterX = 0; counterX < imageDimension; counterX++){
                        for (int counterY = 0; counterY < imageDimension; counterY++){
                            dataTemp = revisedWorkingMap [counterX][counterY];
                            
                            if (counterY == 0) dataTemp2 = dataTemp, entryCount++;
                            else if (dataTemp != dataTemp2 || entryCount == 254 || counterY == imageDimension-1){
                                readBit [0] = dataTemp2/65536;
                                dataTemp2 = dataTemp2%65536;
                                readBit [1] = dataTemp2/256;
                                dataTemp2 = dataTemp2%256;
                                readBit [2] = dataTemp2;
                                
                                if (counterY == imageDimension-1){
                                    if (dataTemp != dataTemp2){
                                        dataHold [indexCount] = (char)readBit [0], indexCount++;
                                        dataHold [indexCount] = (char)readBit [1], indexCount++;
                                        dataHold [indexCount] = (char)readBit [2], indexCount++;
                                        dataHold [indexCount] = (char)entryCount, indexCount++;
                                        
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        entryCount = 1;
                                        
                                        dataHold [indexCount] = (char)readBit [0], indexCount++;
                                        dataHold [indexCount] = (char)readBit [1], indexCount++;
                                        dataHold [indexCount] = (char)readBit [2], indexCount++;
                                        dataHold [indexCount] = (char)entryCount, indexCount++;
                                    }
                                    else{
                                        
                                        entryCount++;
                                        
                                        dataHold [indexCount] = (char)readBit [0], indexCount++;
                                        dataHold [indexCount] = (char)readBit [1], indexCount++;
                                        dataHold [indexCount] = (char)readBit [2], indexCount++;
                                        dataHold [indexCount] = (char)entryCount, indexCount++;
                                    }
                                }
                                else{
                                    
                                    dataHold [indexCount] = (char)readBit [0], indexCount++;
                                    dataHold [indexCount] = (char)readBit [1], indexCount++;
                                    dataHold [indexCount] = (char)readBit [2], indexCount++;
                                    dataHold [indexCount] = (char)entryCount, indexCount++;
                                }
                                
                                if (counterY == imageDimension-1) entryCount = 0;
                                else entryCount = 1, dataTemp2 = dataTemp;
                            }
                            else entryCount++;
                        }
                    }
                    
                    ofstream outfile2 (revisedTempMapPath.c_str(), ofstream::binary);
                    
                    if (outfile2.is_open()){
                        outfile2.write(dataHold, totalImageSize);
                        outfile2.close();
                    }
                    else{
                        
                        errorNoHold = 1004;
                        throw errorCheckThrow;
                    }
                    
                    delete [] dataHold;
                }
                
                //for (int counterA = 0; counterA < 200; counterA++){
                //	for (int counterB = 0; counterB < 200; counterB++) cout<<" "<<revisedWorkingMap [counterA][counterB];
                //	cout<<" revisedWorkingMap "<<counterA<<endl;
                //}
                
                //------Gravity center info------
                string gcDataPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_GCCenterInfo";
                
                oin.open(gcDataPath.c_str(), ios::out);
                
                if (oin.is_open()){
                    oin<<gravityCenterXHold1<<endl;
                    oin<<gravityCenterYHold1<<endl;
                    oin<<gravityAverageHold1<<endl;
                    oin<<gravityCellNo1<<endl;
                    oin<<0<<endl;
                    oin<<0<<endl;
                    oin<<0<<endl;
                    oin<<0<<endl;
                    oin<<0<<endl;
                    oin<<0<<endl;
                    oin<<0<<endl;
                    oin<<0<<endl;
                    oin<<0<<endl;
                    oin<<0<<endl;
                    oin<<0<<endl;
                    oin<<0<<endl;
                    oin.close();
                }
                else{
                    
                    errorNoHold = 1005;
                    throw errorCheckThrow;
                }
                
                //for (int counterA = 0; counterA < expandLineFluorescentCount/4; counterA++){
                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandLineFluorescent [counterA*4+counterB];
                //    cout<<" expandLineFluorescent "<<counterA<<endl;
                //}
                
                if (fluorescentDetectionDisplay1 == 1){
                    //for (int counterA = 0; counterA < expandLineFluorescentCount/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandLineFluorescent [counterA*4+counterB];
                    //    cout<<" expandLineFluorescent "<<counterA<<endl;
                    //}
                    
                    string fluorescentExpandPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_ExtendLineDataTemp";
                    
                    if (expandLineFluorescentCount != 0){
                        int readBit [3];
                        long indexCount = 0;
                        errorNoHold = 5;
                        char *writingArray = new char [expandLineFluorescentCount*2+200];
                        
                        for (int counter1 = 0; counter1 < expandLineFluorescentCount/4; counter1++){
                            dataTemp = expandLineFluorescent [counter1*4];
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            dataTemp = expandLineFluorescent [counter1*4+1];
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            dataTemp = expandLineFluorescent [counter1*4+2];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            writingArray [indexCount] = (char)expandLineFluorescent [counter1*4+3], indexCount++;
                        }
                        
                        for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                        
                        ofstream outfile (fluorescentExpandPath.c_str(), ofstream::binary);
                        
                        if (outfile.is_open()){
                            outfile.write ((char*)writingArray, indexCount);
                            outfile.close();
                        }
                        else{
                            
                            errorNoHold = 1006;
                            throw errorCheckThrow;
                        }
                        
                        delete [] writingArray;
                    }
                    
                    string fluorescentExpandPath2 = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_ExtendAreaDataTemp";
                    
                    if (expandLineFluorescentDataCount != 0){
                        int readBit [3];
                        long indexCount = 0;
                        errorNoHold = 6;
                        char *writingArray = new char [expandLineFluorescentDataCount*2+20];
                        
                        for (int counter1 = 0; counter1 < expandLineFluorescentDataCount/4; counter1++){
                            dataTemp = expandLineFluorescentData [counter1*4];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            writingArray [indexCount] = (char)expandLineFluorescentData [counter1*4+1], indexCount++;
                            writingArray [indexCount] = (char)expandLineFluorescentData [counter1*4+2], indexCount++;
                            
                            dataTemp = expandLineFluorescentData [counter1*4+3];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                        }
                        
                        for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                        
                        ofstream outfile2 (fluorescentExpandPath2.c_str(), ofstream::binary);
                        
                        if (outfile2.is_open()){
                            outfile2.write ((char*)writingArray, indexCount);
                            outfile2.close();
                        }
                        else{
                            
                            errorNoHold = 1007;
                            throw errorCheckThrow;
                        }
                        
                        delete [] writingArray;
                    }
                }
            }
            else if (processType == 2){
                string cellLineageExtract = cellLineageNoHold.substr(1);
                string cellNumberExtract = cellNoHold.substr(1);
                int cellLineageTempInt = atoi(cellLineageExtract.c_str());
                int cellNumberTempInt = atoi(cellNumberExtract.c_str());
                
                for (int counter1 = 0; counter1 < connectLineageRelCurrentCount/6; counter1++){
                    if (arrayConnectLineageRelCurrent [counter1*6] == cellLineageTempInt && arrayConnectLineageRelCurrent [counter1*6+3] == cellNumberTempInt){
                        arrayConnectLineageRelCurrent [counter1*6+4] = 1;
                        break;
                    }
                }
                
                string connectDataTempPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_MasterDataTemp";
                
                if (positionReviseCurrentCount != 0){
                    int readBit [4];
                    long indexCount = 0;
                    
                    errorNoHold = 7;
                    char *writingArray = new char [(positionReviseCurrentCount/7+associatedDataCurrCount/6+gravityCenterRevCurrentCount/6)*17+50];
                    
                    for (int counter1 = 0; counter1 < positionReviseCurrentCount/7; counter1++){
                        dataTemp = arrayPositionReviseCurrent [counter1*7];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        dataTemp = arrayPositionReviseCurrent [counter1*7+1];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        writingArray [indexCount] = (char)arrayPositionReviseCurrent [counter1*7+2], indexCount++;
                        
                        dataTemp = arrayPositionReviseCurrent [counter1*7+3];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = arrayPositionReviseCurrent [counter1*7+4];
                        
                        if (dataTemp < 0) dataTemp = dataTemp*-1, writingArray [indexCount] = 1, indexCount++;
                        else writingArray [indexCount] = 0, indexCount++;
                        
                        readBit [0] = dataTemp/16777216;
                        dataTemp = dataTemp%16777216;
                        readBit [1] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [2] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [3] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                        
                        writingArray [indexCount] = (char)arrayPositionReviseCurrent [counter1*7+5], indexCount++;
                        
                        dataTemp = arrayPositionReviseCurrent [counter1*7+6];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                    }
                    
                    for (int counter1 = 0; counter1 < 17; counter1++) writingArray [indexCount] = 0, indexCount++;
                    
                    for (int counter1 = 0; counter1 < associatedDataCurrCount/6; counter1++){
                        dataTemp = arrayAssociatedDataCurr [counter1*6];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)arrayAssociatedDataCurr [counter1*6+1], indexCount++;
                        writingArray [indexCount] = (char)arrayAssociatedDataCurr [counter1*6+2], indexCount++;
                        
                        dataTemp = arrayAssociatedDataCurr [counter1*6+3];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = arrayAssociatedDataCurr [counter1*6+4];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        writingArray [indexCount] = (char)arrayAssociatedDataCurr [counter1*6+5], indexCount++;
                    }
                    
                    for (int counter1 = 0; counter1 < 11; counter1++) writingArray [indexCount] = 0, indexCount++;
                    
                    for (int counter1 = 0; counter1 < gravityCenterRevCurrentCount/6; counter1++){
                        dataTemp = arrayGravityCenterRevCurrent [counter1*6];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        dataTemp = arrayGravityCenterRevCurrent [counter1*6+1];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        dataTemp = arrayGravityCenterRevCurrent [counter1*6+2];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)arrayGravityCenterRevCurrent [counter1*6+3], indexCount++;
                        
                        dataTemp = arrayGravityCenterRevCurrent [counter1*6+4];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)arrayGravityCenterRevCurrent [counter1*6+5], indexCount++;
                    }
                    
                    for (int counter1 = 0; counter1 < 11; counter1++){
                        writingArray [indexCount] = 0, indexCount++;
                    }
                    
                    ofstream outfile (connectDataTempPath.c_str(), ofstream::binary);
                    
                    if (outfile.is_open()){
                        outfile.write ((char*)writingArray, indexCount);
                        outfile.close();
                    }
                    else{
                        
                        errorNoHold = 1008;
                        throw errorCheckThrow;
                    }
                    
                    delete [] writingArray;
                }
                
                string connectStatusTempPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_StatusTemp";
                
                //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
                //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
                //	cout<<" arrayPositionRevise "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                //	cout<<" arrayTimeSelected "<<counterA+1<<endl;
                //}
                
                //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
                //	cout<<" arrayGravityCenterRev "<<counterA<<endl;
                //}
                
                if (timeSelectedCurrentCount != 0){
                    errorNoHold = 8;
                    char *writingArray = new char [timeSelectedCurrentCount/10*19+20];
                    
                    long indexCount = 0;
                    int readBit [3];
                    int connectNumberTemp = 0;
                    
                    for (int counter1 = 0; counter1 < timeSelectedCurrentCount/10; counter1++){
                        writingArray [indexCount] = (char)arrayTimeSelectedCurrent [counter1*10], indexCount++;
                        writingArray [indexCount] = 0, indexCount++;
                        writingArray [indexCount] = 0, indexCount++;
                        writingArray [indexCount] = 0, indexCount++;
                        
                        dataTemp = arrayTimeSelectedCurrent [counter1*10+2];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = 0, indexCount++;
                        writingArray [indexCount] = 0, indexCount++;
                        
                        writingArray [indexCount] = (char)arrayTimeSelectedCurrent [counter1*10+4], indexCount++;
                        writingArray [indexCount] = (char)arrayTimeSelectedCurrent [counter1*10+5], indexCount++;
                        writingArray [indexCount] = (char)arrayTimeSelectedCurrent [counter1*10+6], indexCount++;
                        writingArray [indexCount] = (char)arrayTimeSelectedCurrent [counter1*10+7], indexCount++;
                        
                        dataTemp = arrayTimeSelectedCurrent [counter1*10+8];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        if (arrayTimeSelectedCurrent [counter1*10] == 3 || arrayTimeSelectedCurrent [counter1*10] == 4) connectNumberTemp = 0;
                        else connectNumberTemp = arrayTimeSelectedCurrent [counter1*10+9];
                        
                        dataTemp = connectNumberTemp;
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                    }
                    
                    for (int counter1 = 0; counter1 < 19; counter1++) writingArray [indexCount] = 0, indexCount++;
                    
                    ofstream outfile2 (connectStatusTempPath.c_str(), ofstream::binary);
                    
                    if (outfile2.is_open()){
                        outfile2.write ((char*) writingArray, indexCount);
                        outfile2.close();
                    }
                    else{
                        
                        errorNoHold = 1009;
                        throw errorCheckThrow;
                    }
                    
                    delete [] writingArray;
                }
                
                //------Connect lineage relation table save------
                string connectRelationTempPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_ConnectLineageRelTemp";
                
                //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
                //	cout<<" arrayConnectLineageRel "<<counterA<<endl;
                //}
                
                if (connectLineageRelCurrentCount != 0){
                    errorNoHold = 9;
                    char *writingArray = new char [connectLineageRelCurrentCount/6*16+16];
                    
                    long indexCount = 0;
                    int readBit [4];
                    
                    for (int counter1 = 0; counter1 < connectLineageRelCurrentCount/6; counter1++){
                        dataTemp = arrayConnectLineageRelCurrent [counter1*6];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = arrayConnectLineageRelCurrent [counter1*6+1];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = arrayConnectLineageRelCurrent [counter1*6+2];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        if (arrayConnectLineageRelCurrent [counter1*6+3] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = arrayConnectLineageRelCurrent [counter1*6+3]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = arrayConnectLineageRelCurrent [counter1*6+3];
                        }
                        
                        readBit [0] = dataTemp/16777216;
                        dataTemp = dataTemp%16777216;
                        readBit [1] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [2] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [3] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                        
                        writingArray [indexCount] = 0, indexCount++;
                        
                        writingArray [indexCount] = (char)arrayConnectLineageRelCurrent [counter1*6+5], indexCount++;
                    }
                    
                    for (int counter1 = 0; counter1 < 15; counter1++) writingArray [indexCount] = 0, indexCount++;
                    
                    ofstream outfile2 (connectRelationTempPath.c_str(), ofstream::binary);
                    
                    if (outfile2.is_open()){
                        outfile2.write ((char*) writingArray, indexCount);
                        outfile2.close();
                    }
                    else{
                        
                        errorNoHold = 1010;
                        throw errorCheckThrow;
                    }
                    
                    delete [] writingArray;
                }
                
                //------Save Revised Map------
                string revisedTempMapPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_RevisedTempMap";
                
                if (imageDimension != 0){
                    errorNoHold = 10;
                    char *dataHold = new char [totalImageSize];
                    int indexCount = 0;
                    int dataTemp2 = 0;
                    int entryCount = 0;
                    int readBit [4];
                    
                    for (int counterX = 0; counterX < imageDimension; counterX++){
                        for (int counterY = 0; counterY < imageDimension; counterY++){
                            dataTemp = revisedMapCurrent [counterX][counterY];
                            
                            if (counterY == 0) dataTemp2 = dataTemp, entryCount++;
                            else if (dataTemp != dataTemp2 || entryCount == 254 || counterY == imageDimension-1){
                                readBit [0] = dataTemp2/65536;
                                dataTemp2 = dataTemp2%65536;
                                readBit [1] = dataTemp2/256;
                                dataTemp2 = dataTemp2%256;
                                readBit [2] = dataTemp2;
                                
                                if (counterY == imageDimension-1){
                                    if (dataTemp != dataTemp2){
                                        dataHold [indexCount] = (char)readBit [0], indexCount++;
                                        dataHold [indexCount] = (char)readBit [1], indexCount++;
                                        dataHold [indexCount] = (char)readBit [2], indexCount++;
                                        dataHold [indexCount] = (char)entryCount, indexCount++;
                                        
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        entryCount = 1;
                                        
                                        dataHold [indexCount] = (char)readBit [0], indexCount++;
                                        dataHold [indexCount] = (char)readBit [1], indexCount++;
                                        dataHold [indexCount] = (char)readBit [2], indexCount++;
                                        dataHold [indexCount] = (char)entryCount, indexCount++;
                                    }
                                    else{
                                        
                                        entryCount++;
                                        
                                        dataHold [indexCount] = (char)readBit [0], indexCount++;
                                        dataHold [indexCount] = (char)readBit [1], indexCount++;
                                        dataHold [indexCount] = (char)readBit [2], indexCount++;
                                        dataHold [indexCount] = (char)entryCount, indexCount++;
                                    }
                                }
                                else{
                                    
                                    dataHold [indexCount] = (char)readBit [0], indexCount++;
                                    dataHold [indexCount] = (char)readBit [1], indexCount++;
                                    dataHold [indexCount] = (char)readBit [2], indexCount++;
                                    dataHold [indexCount] = (char)entryCount, indexCount++;
                                }
                                
                                if (counterY == imageDimension-1) entryCount = 0;
                                else entryCount = 1, dataTemp2 = dataTemp;
                            }
                            else entryCount++;
                        }
                    }
                    
                    ofstream outfile2 (revisedTempMapPath.c_str(), ofstream::binary);
                    
                    if (outfile2.is_open()){
                        outfile2.write(dataHold, totalImageSize);
                        outfile2.close();
                    }
                    else{
                        
                        errorNoHold = 1011;
                        throw errorCheckThrow;
                    }
                    
                    delete [] dataHold;
                }
                
                //for (int counterA = 0; counterA < 200; counterA++){
                //	for (int counterB = 0; counterB < 200; counterB++) cout<<" "<<revisedWorkingMap [counterA][counterB];
                //	cout<<" revisedWorkingMap "<<counterA<<endl;
                //}
                
                //------Gravity center info------
                string gcDataPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_GCCenterInfo";
                
                oin.open(gcDataPath.c_str(), ios::out);
                
                if (oin.is_open()){
                    oin<<gravityCenterXCurrentHold1<<endl;
                    oin<<gravityCenterYCurrentHold1<<endl;
                    oin<<gravityAverageCurrentHold1<<endl;
                    oin<<gravityCellNoCurrent1<<endl;
                    oin<<gravityCenterXCurrentHold2<<endl;
                    oin<<gravityCenterYCurrentHold2<<endl;
                    oin<<gravityAverageCurrentHold2<<endl;
                    oin<<gravityCellNoCurrent2<<endl;
                    oin<<gravityCenterXCurrentHold3<<endl;
                    oin<<gravityCenterYCurrentHold3<<endl;
                    oin<<gravityAverageCurrentHold3<<endl;
                    oin<<gravityCellNoCurrent3<<endl;
                    oin<<gravityCenterXCurrentHold4<<endl;
                    oin<<gravityCenterYCurrentHold4<<endl;
                    oin<<gravityAverageCurrentHold4<<endl;
                    oin<<gravityCellNoCurrent4<<endl;
                    oin.close();
                }
                else{
                    
                    errorNoHold = 1012;
                    throw errorCheckThrow;
                }
                
                //------Link Data Save------
                string linkDataPath;
                
                if (trackHoldFlag == 4){
                    linkDataPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_LinkDataTemp";
                    
                    oin.open(linkDataPath.c_str(), ios::out);
                    
                    if (oin.is_open()){
                        oin<<"BD"<<endl;
                        oin<<cellNoHoldDiv1<<endl;
                        oin<<cellNoHoldDiv2<<endl;
                        oin<<"nil"<<endl;
                        oin<<"nil"<<endl;
                        oin.close();
                    }
                    else{
                        
                        errorNoHold = 1013;
                        throw errorCheckThrow;
                    }
                }
                if (trackHoldFlag == 5){
                    linkDataPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_LinkDataTemp";
                    
                    oin.open(linkDataPath.c_str(), ios::out);
                    
                    if (oin.is_open()){
                        oin<<"TD"<<endl;
                        oin<<cellNoHoldDiv1<<endl;
                        oin<<cellNoHoldDiv2<<endl;
                        oin<<cellNoHoldDiv3<<endl;
                        oin<<"nil"<<endl;
                        oin.close();
                    }
                    else{
                        
                        errorNoHold = 1014;
                        throw errorCheckThrow;
                    }
                }
                if (trackHoldFlag == 6){
                    linkDataPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_LinkDataTemp";
                    
                    oin.open(linkDataPath.c_str(), ios::out);
                    
                    if (oin.is_open()){
                        oin<<"HD"<<endl;
                        oin<<cellNoHoldDiv1<<endl;
                        oin<<cellNoHoldDiv2<<endl;
                        oin<<cellNoHoldDiv3<<endl;
                        oin<<cellNoHoldDiv4<<endl;
                        oin.close();
                    }
                    else{
                        
                        errorNoHold = 1015;
                        throw errorCheckThrow;
                    }
                }
                
                if (trackHoldFlag == -1){
                    linkDataPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_LinkDataTemp";
                    
                    oin.open(linkDataPath.c_str(), ios::out);
                    
                    if (oin.is_open()){
                        oin<<"FU"<<endl;
                        oin<<fusionPartnerLine<<endl;
                        oin<<fusionPartnerCellNo<<endl;
                        oin<<imageNumberInt+1<<endl;
                        oin<<"nil"<<endl;
                        oin.close();
                    }
                    else{
                        
                        errorNoHold = 1016;
                        throw errorCheckThrow;
                    }
                }
                
                if (fluorescentDetectionDisplay2 == 1){
                    string fluorescentExpandPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_ExtendLineDataTemp";
                    
                    if (expandLineFluorescentCurrentCount != 0){
                        int readBit [3];
                        long indexCount = 0;
                        errorNoHold = 11;
                        char *writingArray = new char [expandLineFluorescentCurrentCount*2+200];
                        
                        for (int counter1 = 0; counter1 < expandLineFluorescentCurrentCount/4; counter1++){
                            dataTemp = expandLineFluorescentCurrent [counter1*4];
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            dataTemp = expandLineFluorescentCurrent [counter1*4+1];
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            dataTemp = expandLineFluorescentCurrent [counter1*4+2];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            writingArray [indexCount] = (char)expandLineFluorescentCurrent [counter1*4+3], indexCount++;
                        }
                        
                        for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                        
                        ofstream outfile (fluorescentExpandPath.c_str(), ofstream::binary);
                        
                        if (outfile.is_open()){
                            outfile.write ((char*)writingArray, indexCount);
                            outfile.close();
                        }
                        else{
                            
                            errorNoHold = 1017;
                            throw errorCheckThrow;
                        }
                        
                        delete [] writingArray;
                    }
                    
                    string fluorescentExpandPath2 = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_ExtendAreaDataTemp";
                    
                    if (expandLineFluorescentDataCurrentCount != 0){
                        int readBit [3];
                        long indexCount = 0;
                        errorNoHold = 12;
                        char *writingArray = new char [expandLineFluorescentDataCurrentCount*2+20];
                        
                        for (int counter1 = 0; counter1 < expandLineFluorescentDataCurrentCount/4; counter1++){
                            dataTemp = expandLineFluorescentDataCurrent [counter1*4];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            writingArray [indexCount] = (char)expandLineFluorescentDataCurrent [counter1*4+1], indexCount++;
                            writingArray [indexCount] = (char)expandLineFluorescentDataCurrent [counter1*4+2], indexCount++;
                            
                            dataTemp = expandLineFluorescentDataCurrent [counter1*4+3];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                        }
                        
                        for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                        
                        ofstream outfile2 (fluorescentExpandPath2.c_str(), ofstream::binary);
                        
                        if (outfile2.is_open()){
                            outfile2.write ((char*)writingArray, indexCount);
                            outfile2.close();
                        }
                        else{
                            
                            errorNoHold = 1018;
                            throw errorCheckThrow;
                        }
                        
                        delete [] writingArray;
                    }
                }
            }
            
            errorNoHold = 0;
            subCompletionFlag = 0;
        }
        catch (int errorCheckThrow){
            if (errorNoHold >= 1000){
                string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
                mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                time_t rawtime;
                struct tm * timeinfo;
                time (&rawtime);
                timeinfo = localtime ( &rawtime );
                
                int tsec = timeinfo -> tm_sec;
                int tmin = timeinfo -> tm_min;
                int thour = timeinfo -> tm_hour;
                int tday = timeinfo -> tm_mday;
                int tmon = timeinfo -> tm_mon;
                
                string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
                
                errorPath = errorPath+"/Cell_CarvingTrackingDataSave01 "+dateTime;
                
                ofstream oin2;
                oin2.open(errorPath.c_str(), ios::out);
                oin2<<"TrackingDataSave"<<endl;
                oin2<<errorNoHold<<endl;
                oin2<<analysisImageName<<endl;
                oin2<<analysisID<<endl;
                oin2<<treatmentNameHold<<endl;
                oin2<<cellLineageNoHold<<endl;
                oin2<<cellNoHold<<endl;
                oin2<<dateTime<<endl;
                
                if (errorNoHold == 1000) oin2<<"MasterDataTemp Save-error"<<endl;
                else if (errorNoHold == 1001) oin2<<"StatusTemp Save-error"<<endl;
                else if (errorNoHold == 1003) oin2<<"ConnectLineageRelTemp Save-error"<<endl;
                else if (errorNoHold == 1004) oin2<<"RevisedTempMap Save-error"<<endl;
                else if (errorNoHold == 1005) oin2<<"GCCenterInfo Save-error"<<endl;
                else if (errorNoHold == 1006) oin2<<"ExtendLineDataTemp Save-error"<<endl;
                else if (errorNoHold == 1007) oin2<<"ExtendAreaDataTemp Save-error"<<endl;
                else if (errorNoHold == 1008) oin2<<"MasterDataTemp Save-error"<<endl;
                else if (errorNoHold == 1009) oin2<<"StatusTemp Save-error"<<endl;
                else if (errorNoHold == 1010) oin2<<"ConnectLineageRelTemp Save-error"<<endl;
                else if (errorNoHold == 1011) oin2<<"RevisedTempMap Save-error"<<endl;
                else if (errorNoHold == 1012) oin2<<"GCCenterInfo Save-error"<<endl;
                else if (errorNoHold == 1013) oin2<<"LinkDataTemp Save-error"<<endl;
                else if (errorNoHold == 1014) oin2<<"LinkDataTemp Save-error"<<endl;
                else if (errorNoHold == 1015) oin2<<"LinkDataTemp Save-error"<<endl;
                else if (errorNoHold == 1016) oin2<<"LinkDataTemp Save-error"<<endl;
                else if (errorNoHold == 1017) oin2<<"ExtendLineDataTemp Save-error"<<endl;
                else if (errorNoHold == 1018) oin2<<"ExtendAreaDataTemp Save-error"<<endl;
                oin2.close();
                
                subCompletionFlag = 0;
            }
        }
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingTrackingDataSave02 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"TrackingDataSave"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
        
        subCompletionFlag = 0;
    }
}

@end
