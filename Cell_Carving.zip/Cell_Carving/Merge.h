//
//  Merge.h
//  Cell_Carving
//
//  Created by Masahiko Sato on 2015-12-15.
//
//

#ifndef MERGE_H
#define MERGE_H
#import "Controller.h"
#endif

@interface Merge : NSObject{
}

-(void)mergeExtendTrack;
-(void)mergeExtendTrackCurrent;
-(int)lineExtendTrackType2:(int)groupNoMerge :(int)processType;
-(int)lineExtendTrackTypeCurrent2:(int)groupNoMerge;
-(void)expandLineFluorescentUpDate;
-(void)expandLineFluorescentDataUpDate;
-(void)expandLineFluorescentCurrentUpDate;
-(void)expandLineFluorescentDataCurrentUpDate;

@end
