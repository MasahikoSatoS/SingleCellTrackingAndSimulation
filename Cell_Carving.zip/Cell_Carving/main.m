//
// main.m
// Cell_Carving
//
// Created by Masahiko Sato on 13/12/09.
// Copyright Masahiko Sato 2011-2013. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[]){
    return NSApplicationMain(argc, (const char **) argv);
}
