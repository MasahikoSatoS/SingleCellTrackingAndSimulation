//
//  AreaCutCurrent.h
//  Cell_Carving
//
//  Created by Masahiko Sato on 2015-04-17.
//
//

#ifndef AREACUTCURRENT_H
#define AREACUTCURRENT_H
#import "Controller.h"
#endif

@interface AreaCutCurrent : NSObject{
    int horizontalStart2; //Horizontal start
    int verticalStart2; //Vertical start
    
    id merge;
}

-(int)circleCut:(int)processType :(int)targetCellStatus :(int)cutOffAdjust;
-(int)areaProcess:(int)type :(int)dimension :(int)valueTemp :(int)targetCellStatus :(int)processType;
-(void)positionRevSelectedCurrUpDate;
-(void)gravityCenterRevCurrentUpDate;
-(void)associateDataCurrUpDate;
-(void)timeSelectedCurrentUpDate;
-(void)connectLineageRelCurrentUpDate;
-(void)expandLineFluorescentCurrentUpDate;
-(void)expandLineFluorescentDataCurrentUpDate;

@end
