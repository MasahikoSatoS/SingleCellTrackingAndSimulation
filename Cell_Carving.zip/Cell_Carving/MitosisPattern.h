//
// MitosisPattern.h
// cell_carving
//
// Created by Masahiko Sato on 28/07/13.
// Copyright 2013 Masahiko Sato. All rights reserved.
//

#ifndef MITOSISPATTERN_H
#define MITOSISPATTERN_H
#import "Controller.h"
#endif

@interface MitosisPattern : NSObject{
}

-(double)mitosisPatternMain:(int)processTarget :(int)processType;

@end
