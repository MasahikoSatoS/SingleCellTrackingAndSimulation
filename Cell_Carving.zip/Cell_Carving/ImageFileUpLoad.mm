//
//  ImageFileUpLoad.m
//  Cell_Carving
//
//  Created by Masahiko Sato on 2016-02-10.
//
//

#import "ImageFileUpLoad.h"

@implementation ImageFileUpLoad

-(void)fileUploadMain{
    try{
        try{
            
            errorNoHold = 0;
            int errorCheckThrow = 0;
            sleepingPosition = 7;
            subCompletionFlag = 1;
            
            ifstream fin;
            
            string extension;
            string connectPath;
            string sourceImagePath;
            
            long sizeForCopy = 0;
            long size1 = 0;
            long size2 = 0;
            int checkFlag = 0;
            int xDimensionCount = 0;
            int imageDimensionReadCount = 0;
            
            errorNoHold = 1;
            int *connectAnalysisX = new int [imageDimension*4];
            errorNoHold = 2;
            int *connectAnalysisY = new int [imageDimension*4];
            errorNoHold = 3;
            int *connectAnalysisTempX = new int [imageDimension*4];
            errorNoHold = 4;
            int *connectAnalysisTempY = new int [imageDimension*4];
            
            int connectivityNumber = 0;
            int connectAnalysisCount = 0;
            int terminationFlag = 0;
            int connectAnalysisTempCount = 0;
            int xSource = 0;
            int ySource = 0;
            int connectTemp = 0;
            int cutOffSet = 0;
            
            int dataConversion [4];
            int endianType = 0;
            int imageWidthEntry = 0;
            int value0 = 0;
            int value1 = 0;
            int value2 = 0;
            
            unsigned long headPosition = 0;
            
            struct stat sizeOfFile;
            
            errorNoHold = 5;
            int **rangeMatrix = new int *[imageDimension+4];
            
            for (int counter1 = 0; counter1 < imageDimension+4; counter1++){
                errorNoHold = 6;
                rangeMatrix [counter1] = new int [imageDimension+4];
            }
            
            for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                if (imageNoHoldMain [counter1*2+1] == 3){
                    if (ifStartHold != 0 && imageNoHoldMain [counter1*2] >= ifStartHold) extension = to_string(timeEndHold);
                    else extension = to_string(imageNoHoldMain [counter1*2]);
                    
                    if (extension.length() == 1) extension = "000"+extension;
                    else if (extension.length() == 2) extension = "00"+extension;
                    else if (extension.length() == 3) extension = "0"+extension;
                    
                    connectPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+extension+"_"+analysisImageName+"_"+treatmentNameHold+"_Map";
                    sourceImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+".tif";
                    
                    fin.open(connectPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        fin.open(sourceImagePath.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            size1 = 0;
                            size2 = 0;
                            checkFlag = 0;
                            
                            for (int counter2 = 0; counter2 < 6; counter2++){
                                sizeForCopy = 0;
                                
                                if (stat(sourceImagePath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                if (sizeForCopy != 0){
                                    if (counter2 == 0) size1 = sizeForCopy;
                                    else if (counter2 == 1) size2 = sizeForCopy;
                                    else if (counter2 == 2){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                            break;
                                        }
                                        else{
                                            
                                            size1 = 0;
                                            size2 = 0;
                                            usleep (50000);
                                        }
                                    }
                                    else if (counter2 == 3) size1 = sizeForCopy;
                                    else if (counter2 == 4) size2 = sizeForCopy;
                                    else if (counter2 == 5){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                        }
                                    }
                                }
                            }
                            
                            if (checkFlag == 0){
                                errorNoHold = 1000;
                                throw errorCheckThrow;
                            }
                            
                            if (checkFlag == 1){
                                imageWidthEntry = 0;
                                
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    fin.close();
                                    
                                    dataConversion [0] = uploadTemp [0];
                                    dataConversion [1] = uploadTemp [1];
                                    
                                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                    else endianType = 0;
                                    
                                    headPosition = 0;
                                    
                                    if (endianType == 1){
                                        dataConversion [0] = uploadTemp [7];
                                        dataConversion [1] = uploadTemp [6];
                                        dataConversion [2] = uploadTemp [5];
                                        dataConversion [3] = uploadTemp [4];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    else if (endianType == 0){
                                        dataConversion [0] = uploadTemp [4];
                                        dataConversion [1] = uploadTemp [5];
                                        dataConversion [2] = uploadTemp [6];
                                        dataConversion [3] = uploadTemp [7];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    
                                    imageDimensionReadCount = 0;
                                    
                                    if (tifImageColorGray == 0){
                                        for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                            sourceImage [counter1][imageDimensionReadCount] = uploadTemp [counter3], imageDimensionReadCount++;
                                            
                                            if (imageWidthEntry == imageDimension){
                                                imageDimensionReadCount = 0;
                                            }
                                        }
                                    }
                                    else if (tifImageColorGray == 1){
                                        for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                            value0 = uploadTemp [counter3];
                                            value1 = uploadTemp [counter3+1];
                                            value2 = uploadTemp [counter3+2];
                                            
                                            sourceImage [counter1][imageDimensionReadCount] = (int)((value0+value1+value2)/(double)3), imageDimensionReadCount++;
                                            
                                            if (imageWidthEntry == imageDimension){
                                                imageDimensionReadCount = 0;
                                            }
                                        }
                                    }
                                }
                                
                                delete [] uploadTemp;
                            }
                        }
                        else{
                            
                            sourceImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+".bmp";
                            
                            sizeForCopy = 0;
                            
                            if (stat(sourceImagePath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                errorNoHold = 7;
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    fin.close();
                                    
                                    imageDimensionReadCount = 0;
                                    
                                    for (int counter2 = imageDimension-1; counter2 >= 0; counter2--){
                                        for (int counter3 = 0; counter3 < imageDimension; counter3++){
                                            sourceImage [counter1][imageDimensionReadCount] = uploadTemp [1078+counter2*imageDimension+counter3], imageDimensionReadCount++;
                                        }
                                    }
                                }
                                else{
                                    
                                    errorNoHold = 1001;
                                    throw errorCheckThrow;
                                }
                                
                                delete [] uploadTemp;
                            }
                        }
                        
                        for (int counter2 = 1; counter2 <= 7; counter2++){
                            if (counter2 == 1) cutOffSet = cutOff1;
                            else if (counter2 == 2) cutOffSet = cutOff2;
                            else if (counter2 == 3) cutOffSet = cutOff3;
                            else if (counter2 == 4) cutOffSet = cutOff4;
                            else if (counter2 == 5) cutOffSet = cutOff5;
                            else if (counter2 == 6) cutOffSet = cutOff6;
                            else if (counter2 == 7) cutOffSet = cutOff7;
                            
                            for (int counterY = 0; counterY < imageDimension; counterY++){
                                for (int counterX = 0; counterX < imageDimension; counterX++){
                                    if (sourceImage [counter1][counterY*imageDimension+counterX] == 100) rangeMatrix [counterY][counterX] = 0;
                                    else if (sourceImage [counter1][counterY*imageDimension+counterX] < cutOffSet) rangeMatrix [counterY][counterX] = 0;
                                    else rangeMatrix [counterY][counterX] = -150;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < 100; counterA++){
                            //    for (int counterB = 0; counterB < 100; counterB++) cout<<" "<<rangeMatrix [counterA][counterB];
                            //    cout<<" rangeMatrix  "<<counterA<<endl;
                            //}
                            
                            connectivityNumber = 0;
                            
                            for (int counterY = 0; counterY < imageDimension; counterY++){
                                for (int counterX = 0; counterX < imageDimension; counterX++){
                                    if (rangeMatrix [counterY][counterX] == -150){
                                        connectivityNumber++;
                                        rangeMatrix [counterY][counterX] = connectivityNumber;
                                        connectAnalysisCount = 0;
                                        
                                        if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrix [counterY-1][counterX-1] == -150){
                                            rangeMatrix [counterY-1][counterX-1] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                        }
                                        if (counterY-1 >= 0 && rangeMatrix [counterY-1][counterX] == -150){
                                            rangeMatrix [counterY-1][counterX] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                        }
                                        if (counterY-1 >= 0 && counterX+1 < imageDimension && rangeMatrix [counterY-1][counterX+1] == -150){
                                            rangeMatrix [counterY-1][counterX+1] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                        }
                                        if (counterX+1 < imageDimension && rangeMatrix [counterY][counterX+1] == -150){
                                            rangeMatrix [counterY][counterX+1] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                        }
                                        if (counterY+1 < imageDimension && counterX+1 < imageDimension && rangeMatrix [counterY+1][counterX+1] == -150){
                                            rangeMatrix [counterY+1][counterX+1] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                        }
                                        if (counterY+1 < imageDimension && rangeMatrix [counterY+1][counterX] == -150){
                                            rangeMatrix [counterY+1][counterX] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                        }
                                        if (counterY+1 < imageDimension && counterX-1 >= 0 && rangeMatrix [counterY+1][counterX-1] == -150){
                                            rangeMatrix [counterY+1][counterX-1] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                        }
                                        if (counterX-1 >= 0 && rangeMatrix [counterY][counterX-1] == -150){
                                            rangeMatrix [counterY][counterX-1] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                        }
                                        
                                        if (connectAnalysisCount != 0){
                                            do{
                                                
                                                terminationFlag = 1;
                                                connectAnalysisTempCount = 0;
                                                
                                                for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                    xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                    
                                                    if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrix [ySource-1][xSource-1] == -150){
                                                        rangeMatrix [ySource-1][xSource-1] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                    }
                                                    if (ySource-1 >= 0 && rangeMatrix [ySource-1][xSource] == -150){
                                                        rangeMatrix [ySource-1][xSource] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                    }
                                                    if (ySource-1 >= 0 && xSource+1 < imageDimension && rangeMatrix [ySource-1][xSource+1] == -150){
                                                        rangeMatrix [ySource-1][xSource+1] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                    }
                                                    if (xSource+1 < imageDimension && rangeMatrix [ySource][xSource+1] == -150){
                                                        rangeMatrix [ySource][xSource+1] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                    }
                                                    if (ySource+1 > imageDimension && xSource+1 < imageDimension && rangeMatrix [ySource+1][xSource+1] == -150){
                                                        rangeMatrix [ySource+1][xSource+1] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                    }
                                                    if (ySource+1 < imageDimension && rangeMatrix [ySource+1][xSource] == -150){
                                                        rangeMatrix [ySource+1][xSource] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                    }
                                                    if (ySource+1 < imageDimension && xSource-1 >= 0 && rangeMatrix [ySource+1][xSource-1] == -150){
                                                        rangeMatrix [ySource+1][xSource-1] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                    }
                                                    if (xSource-1 >= 0 && rangeMatrix [ySource][xSource-1] == -150){
                                                        rangeMatrix [ySource][xSource-1] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                    }
                                                }
                                                
                                                for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                    connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                }
                                                
                                                connectAnalysisCount = connectAnalysisTempCount;
                                                
                                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                                
                                            } while (terminationFlag == 1);
                                        }
                                    }
                                }
                            }
                            
                            //------Determine number of pixels------
                            errorNoHold = 8;
                            int *connectedPixels = new int [connectivityNumber+50];
                            
                            for (int counter3 = 0; counter3 <= connectivityNumber; counter3++) connectedPixels [counter3] = 0;
                            
                            for (int counterY = 0; counterY < imageDimension; counterY++){
                                for (int counterX = 0; counterX < imageDimension; counterX++){
                                    if (rangeMatrix [counterY][counterX] != 0) connectedPixels [rangeMatrix [counterY][counterX]]++;
                                }
                            }
                            
                            //------Map up-date------
                            connectTemp = 1;
                            
                            for (int counter3 = 1; counter3 <= connectivityNumber; counter3++){
                                if (connectedPixels [counter3] < 10) connectedPixels [counter3] = 0;
                                else{
                                    
                                    connectedPixels [counter3] = connectTemp;
                                    connectTemp++;
                                }
                            }
                            
                            xDimensionCount = 0;
                            
                            for (int counterY = 0; counterY < imageDimension; counterY++){
                                for (int counterX = 0; counterX < imageDimension; counterX++){
                                    if ((connectTemp = rangeMatrix [counterY][counterX]) != 0) rangeMatrix [counterY][counterX] = connectedPixels [connectTemp];
                                    else rangeMatrix [counterY][counterX] = 0;
                                    
                                    if (counter2 == 1){
                                        connectMap240 [counter1][xDimensionCount] = rangeMatrix [counterY][counterX];
                                    }
                                    else if (counter2 == 2){
                                        connectMap220 [counter1][xDimensionCount] = rangeMatrix [counterY][counterX];
                                    }
                                    else if (counter2 == 3){
                                        connectMap200 [counter1][xDimensionCount] = rangeMatrix [counterY][counterX];
                                    }
                                    else if (counter2 == 4){
                                        connectMapA [counter1][xDimensionCount] = rangeMatrix [counterY][counterX];
                                    }
                                    else if (counter2 == 5){
                                        connectMapB [counter1][xDimensionCount] = rangeMatrix [counterY][counterX];
                                    }
                                    else if (counter2 == 6){
                                        connectMapC [counter1][xDimensionCount] = rangeMatrix [counterY][counterX];
                                    }
                                    else if (counter2 == 7){
                                        connectMapD [counter1][xDimensionCount] = rangeMatrix [counterY][counterX];
                                    }
                                    
                                    xDimensionCount++;
                                }
                            }
                            
                            delete [] connectedPixels;
                        }
                    }
                    else{
                        
                        imageNoHoldMain [counter1*2] = 0;
                        imageNoHoldMain [counter1*2+1] = 0;
                    }
                }
            }
            
            delete [] connectAnalysisX;
            delete [] connectAnalysisY;
            delete [] connectAnalysisTempX;
            delete [] connectAnalysisTempY;
            
            for (int counter1 = 0; counter1 < imageDimension+4; counter1++){
                delete [] rangeMatrix [counter1];
            }
            
            delete [] rangeMatrix;
            
            for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                if (imageNoHoldMain [counter1*2+1] == 2 || imageNoHoldMain [counter1*2+1] == 3) imageNoHoldMain [counter1*2+1] = 1;
            }
            
            sleepingPosition = 8;
            errorNoHold = 0;
            subCompletionFlag = 0;
        }
        catch (int errorCheckThrow){
            string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
            mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            time_t rawtime;
            struct tm * timeinfo;
            time (&rawtime);
            timeinfo = localtime ( &rawtime );
            
            int tsec = timeinfo -> tm_sec;
            int tmin = timeinfo -> tm_min;
            int thour = timeinfo -> tm_hour;
            int tday = timeinfo -> tm_mday;
            int tmon = timeinfo -> tm_mon;
            
            string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
            
            errorPath = errorPath+"/Cell_CarvingImageFileUp "+dateTime;
            
            ofstream oin2;
            oin2.open(errorPath.c_str(), ios::out);
            oin2<<"ImageFileUpLoad"<<endl;
            oin2<<errorNoHold<<endl;
            oin2<<analysisImageName<<endl;
            oin2<<analysisID<<endl;
            oin2<<treatmentNameHold<<endl;
            oin2<<cellLineageNoHold<<endl;
            oin2<<cellNoHold<<endl;
            oin2<<dateTime<<endl;
            
            if (errorNoHold == 1000) oin2<<"STimage-tif reading error"<<endl;
            else if (errorNoHold == 1001) oin2<<"STimage-bmp reading error"<<endl;
            oin2.close();
            
            if (errorNoHold == 0) errorNoHold = 1000;
            
            subCompletionFlag = 0;
        }
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingImageFileUp "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"ImageFileUpLoad"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
        
        subCompletionFlag = 0;
    }
}

@end
