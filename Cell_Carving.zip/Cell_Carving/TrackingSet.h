//
// TrackingSet.h
// Cell_Carving
//
// Created by Masahiko Sato on 12/12/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef TRACKINGSET_H
#define TRACKINGSET_H
#import "Controller.h"
#endif

@interface TrackingSet : NSObject{
    id tableInterpretation;
}

-(int)trackingSetMain:(int)processTime :(int)imageNo;
-(void)gravityCenterRevUpDate;
-(void)associatedDataUpDate;

@end
