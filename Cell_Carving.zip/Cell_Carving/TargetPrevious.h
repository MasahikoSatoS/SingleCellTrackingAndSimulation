//
// TargetPrevious.h
// cell_carving
//
// Created by Masahiko Sato on 13/06/04.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef TARGETPREVIOUS_H
#define TARGETPREVIOUS_H
#import "Controller.h"
#endif

@interface TargetPrevious : NSObject{
    id tableInterpretation;
}

-(void)targetPreviousMain:(int)roundTwo;

@end
