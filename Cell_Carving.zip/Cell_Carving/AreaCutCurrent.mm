//
//  AreaCutCurrent.m
//  Cell_Carving
//
//  Created by Masahiko Sato on 2015-04-17.
//
//

#import "AreaCutCurrent.h"

@implementation AreaCutCurrent

-(int)circleCut:(int)processType :(int)targetCellStatus :(int)cutOffAdjust{
    
    //------First circle process------
    int resultsType1 = 0;
    
    try{
        try{
            
            //for (int counterA = 0; counterA < timeSelectedCurrentCount/10; counterA++){
            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelectedCurrent [counterA*10+counterB];
            //    cout<<" arrayTimeSelectedCurrent "<<counterA<<endl;
            //}
            
            errorNoHold = 0;
            int errorCheckThrow = 0;
            subCompletionFlag = 1;
            
            string cellLineageExtract = cellLineageNoHold.substr(1);
            string cellNumberExtract = cellNoHold.substr(1);
            int cellLineageTempInt = atoi(cellLineageExtract.c_str());
            int cellNumberTempInt = atoi(cellNumberExtract.c_str());
            
            int connectNoCurrTemp = 0;
            
            for (int counter1 = 0; counter1 < connectLineageRelCurrentCount/6; counter1++){
                if (arrayConnectLineageRelCurrent [counter1*6] == cellLineageTempInt && arrayConnectLineageRelCurrent [counter1*6+3] == cellNumberTempInt){
                    connectNoCurrTemp = arrayConnectLineageRelCurrent [counter1*6+1];
                    arrayConnectLineageRelCurrent [counter1*6+4] = 1;
                    break;
                }
            }
            
            if (autoExpandLine == 1){
                merge = [[Merge alloc] init];
                [merge mergeExtendTrackCurrent];
                
                do{
                } while(subCompletionFlag2 == 1);
                
                if (errorNoHold != 0){
                    errorNoHold = errorNoHold+2000;
                    throw errorCheckThrow;
                }
            }
            
            int maxPointDimX = 0;
            int maxPointDimY = 0;
            int minPointDimX = 1000000;
            int minPointDimY = 1000000;
            
            for (int counter1 = 0; counter1 < referenceLineCount/2; counter1++){
                if (maxPointDimX < arrayReferenceLine [counter1*2]) maxPointDimX = arrayReferenceLine [counter1*2];
                if (minPointDimX > arrayReferenceLine [counter1*2]) minPointDimX = arrayReferenceLine [counter1*2];
                if (maxPointDimY < arrayReferenceLine [counter1*2+1]) maxPointDimY = arrayReferenceLine [counter1*2+1];
                if (minPointDimY > arrayReferenceLine [counter1*2+1]) minPointDimY = arrayReferenceLine [counter1*2+1];
            }
            
            if (processType == 1){
                for (int counter1 = 0; counter1 < positionReviseCurrentCount/7; counter1++){
                    if (arrayPositionReviseCurrent [counter1*7+4] == fusionPartnerCellNo && arrayPositionReviseCurrent [counter1*7+6] == fusionPartnerLine){
                        if (maxPointDimX < arrayPositionReviseCurrent [counter1*7]) maxPointDimX = arrayPositionReviseCurrent [counter1*7];
                        if (minPointDimX > arrayPositionReviseCurrent [counter1*7]) minPointDimX = arrayPositionReviseCurrent [counter1*7];
                        if (maxPointDimY < arrayPositionReviseCurrent [counter1*7+1]) maxPointDimY = arrayPositionReviseCurrent [counter1*7+1];
                        if (minPointDimY > arrayPositionReviseCurrent [counter1*7+1]) minPointDimY = arrayPositionReviseCurrent [counter1*7+1];
                    }
                }
            }
            
            int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
            int verticalLength = (maxPointDimY-minPointDimY)/2*2;
            int dimension = 0;
            
            if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
            if (horizontalLength < verticalLength) dimension = verticalLength+30;
            
            dimension = (dimension/2)*2;
            
            horizontalStart2 = minPointDimX-(dimension-horizontalLength)/2;
            verticalStart2 = minPointDimY-(dimension-verticalLength)/2;
            
            if (connectivityMapCutStatus == 0){
                errorNoHold = 1;
                connectivityMapCut = new int *[dimension+1];
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    errorNoHold = 2;
                    connectivityMapCut [counter1] = new int [dimension+1];
                }
                
                connectivityMapCutStatus = 1;
                connectivityMapCutSizeHold = dimension;
            }
            else if (connectivityMapCutStatus == 1 && 300 < connectivityMapCutSizeHold && 300 > dimension){
                for (int counter1 = 0; counter1 < connectivityMapCutSizeHold+1; counter1++) delete [] connectivityMapCut [counter1];
                delete [] connectivityMapCut;
                
                connectivityMapCutSizeHold = dimension;
                
                errorNoHold = 3;
                connectivityMapCut = new int *[dimension+1];
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    errorNoHold = 4;
                    connectivityMapCut [counter1] = new int [dimension+1];
                }
            }
            else if (connectivityMapCutStatus == 1 && connectivityMapCutSizeHold < dimension){
                for (int counter1 = 0; counter1 < connectivityMapCutSizeHold+1; counter1++) delete [] connectivityMapCut [counter1];
                delete [] connectivityMapCut;
                
                errorNoHold = 5;
                connectivityMapCut = new int *[dimension+1];
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    errorNoHold = 6;
                    connectivityMapCut [counter1] = new int [dimension+1];
                }
                
                connectivityMapCutSizeHold = dimension;
            }
            
            for (int counterY = 0; counterY < dimension+1; counterY++){
                for (int counterX = 0; counterX < dimension+1; counterX++) connectivityMapCut [counterY][counterX] = 0;
            }
            
            for (int counter1 = 0; counter1 < referenceLineCount/2; counter1++){
                //cout<<lineTempX<<" "<<lineTempY<<" "<<arrayReferenceLine [counter1*2]<<" "<<arrayReferenceLine [counter1*2+1]<<" arrayReferenceLine"<<endl;
                
                if (arrayReferenceLine [counter1*2]-horizontalStart2 >= 0 && arrayReferenceLine [counter1*2]-horizontalStart2 < dimension && arrayReferenceLine [counter1*2+1]-verticalStart2 >= 0 && arrayReferenceLine [counter1*2+1]-verticalStart2 < dimension) connectivityMapCut [arrayReferenceLine [counter1*2+1]-verticalStart2][arrayReferenceLine [counter1*2]-horizontalStart2] = 1;
            }
            
            if (processType == 1){
                for (int counter1 = 0; counter1 < positionReviseCurrentCount/7; counter1++){
                    if (arrayPositionReviseCurrent [counter1*7+4] == fusionPartnerCellNo && arrayPositionReviseCurrent [counter1*7+6] == fusionPartnerLine){
                        if (arrayPositionReviseCurrent [counter1*7]-horizontalStart2 >= 0 && arrayPositionReviseCurrent [counter1*7]-horizontalStart2 < dimension && arrayPositionReviseCurrent [counter1*7+1]-verticalStart2 >= 0 && arrayPositionReviseCurrent [counter1*7+1]-verticalStart2 < dimension) connectivityMapCut [arrayPositionReviseCurrent [counter1*7+1]-verticalStart2][arrayPositionReviseCurrent [counter1*7]-horizontalStart2] = 1;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut [counterA][counterB];
            //    cout<<" connectivityMapCut "<<counterA<<endl;
            //}
            
            //------Fill inside------
            errorNoHold = 7;
            int *connectAnalysisX = new int [dimension*4];
            errorNoHold = 8;
            int *connectAnalysisY = new int [dimension*4];
            errorNoHold = 9;
            int *connectAnalysisTempX = new int [dimension*4];
            errorNoHold = 10;
            int *connectAnalysisTempY = new int [dimension*4];
            
            int connectivityNumber = -3;
            int connectAnalysisCount = 0;
            int terminationFlag = 0;
            int connectAnalysisTempCount = 0;
            int xSource = 0;
            int ySource = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapCut [counterY][counterX] == 0){
                        connectivityNumber = connectivityNumber+2;
                        connectAnalysisCount = 0;
                        
                        if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMapCut [counterY][counterX] = connectivityNumber;
                        
                        if (counterY-1 >= 0 && connectivityMapCut [counterY-1][counterX] == 0){
                            connectivityMapCut [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && connectivityMapCut [counterY][counterX+1] == 0){
                            connectivityMapCut [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && connectivityMapCut [counterY+1][counterX] == 0){
                            connectivityMapCut [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && connectivityMapCut [counterY][counterX-1] == 0){
                            connectivityMapCut [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && connectivityMapCut [ySource-1][xSource] == 0){
                                        connectivityMapCut [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && connectivityMapCut [ySource][xSource+1] == 0){
                                        connectivityMapCut [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && connectivityMapCut [ySource+1][xSource] == 0){
                                        connectivityMapCut [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMapCut [ySource][xSource-1] == 0){
                                        connectivityMapCut [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            int areaCountCurrent = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapCut [counterY][counterX] == -1) connectivityMapCut [counterY][counterX] = 0;
                    else{
                        
                        connectivityMapCut [counterY][counterX] = 1;
                        areaCountCurrent++;
                    }
                }
            }
            
            if ((processType == 3 && areaCountCurrent < 100) || (processType != 3 && cutOffAdjust != -1  && areaCountCurrent < 100) || areaCountCurrent < 50){
                errorNoHold = 11;
                int **mapHoldTemp = new int *[dimension+1];
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    errorNoHold = 12;
                    mapHoldTemp [counter1] = new int [dimension+1];
                }
                
                int expansioDegree = 2;
                
                if (areaCountCurrent < 50) expansioDegree = 4;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        mapHoldTemp [counterY][counterX] = 0;
                    }
                }
                
                for (int counterY = 0; counterY < dimension-expansioDegree; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapCut [counterY][counterX] != 0) mapHoldTemp [counterY+expansioDegree][counterX] = 1;
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<mapHoldTemp [counterA][counterB];
                //    cout<<" mapHoldTemp "<<counterA<<endl;
                //}
                
                for (int counterY = expansioDegree; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapCut [counterY][counterX] != 0) mapHoldTemp [counterY-expansioDegree][counterX] = 1;
                    }
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension-expansioDegree; counterX++){
                        if (connectivityMapCut [counterY][counterX] != 0) mapHoldTemp [counterY][counterX+expansioDegree] = 1;
                    }
                }
                
                for (int counterY = expansioDegree; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapCut [counterY][counterX] != 0) mapHoldTemp [counterY][counterX-expansioDegree] = 1;
                    }
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (mapHoldTemp [counterY][counterX] != 0) connectivityMapCut [counterY][counterX] = -1;
                    }
                }
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++) delete [] mapHoldTemp [counter1];
                
                delete [] mapHoldTemp;
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut [counterA][counterB];
            //    cout<<" connectivityMapCut "<<counterA<<endl;
            //}
            
            int maxConnectNumberList = timeSelectedCurrentCount/10;
            
            errorNoHold = 13;
            int *overLapListTemp = new int [maxConnectNumberList+1];
            
            for (int counter1 = 0; counter1 < maxConnectNumberList+1; counter1++) overLapListTemp [counter1] = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension && connectivityMapCut [counterY][counterX] != 0){
                        if (revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2] != 0) overLapListTemp [revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2]]++;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
            //	cout<<" arrayPositionRevise "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //	cout<<" arrayTimeSelected "<<counterA<<endl;
            //}
            
            int endPosition = 0;
            
            for (int counter1 = 1; counter1 <= maxConnectNumberList; counter1++){
                if (overLapListTemp [counter1] != 0){
                    for (int counter2 = 0; counter2 < timeSelectedCurrentCount/10; counter2++){
                        if (arrayTimeSelectedCurrent [counter2*10] != 3 && arrayTimeSelectedCurrent [counter2*10] != 4){
                            if (counter2 == timeSelectedCurrentCount/10-1) endPosition = positionReviseCurrentCount/7-1;
                            else endPosition = arrayTimeSelectedCurrent [(counter2+1)*10+2]-1;
                            
                            if (arrayTimeSelectedCurrent [counter2*10+8] == counter1){
                                for (int counter3 = arrayTimeSelectedCurrent [counter2*10+2]; counter3 <= endPosition; counter3++){
                                    if (maxPointDimX < arrayPositionReviseCurrent [counter3*7]) maxPointDimX = arrayPositionReviseCurrent [counter3*7];
                                    if (minPointDimX > arrayPositionReviseCurrent [counter3*7]) minPointDimX = arrayPositionReviseCurrent [counter3*7];
                                    if (maxPointDimY < arrayPositionReviseCurrent [counter3*7+1]) maxPointDimY = arrayPositionReviseCurrent [counter3*7+1];
                                    if (minPointDimY > arrayPositionReviseCurrent [counter3*7+1]) minPointDimY = arrayPositionReviseCurrent [counter3*7+1];
                                }
                                
                                break;
                            }
                        }
                    }
                }
            }
            
            delete [] overLapListTemp;
            
            horizontalLength = (maxPointDimX-minPointDimX)/2*2;
            verticalLength = (maxPointDimY-minPointDimY)/2*2;
            dimension = 0;
            
            if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
            if (horizontalLength < verticalLength) dimension = verticalLength+30;
            
            dimension = (dimension/2)*2;
            
            horizontalStart2 = minPointDimX-(dimension-horizontalLength)/2;
            verticalStart2 = minPointDimY-(dimension-verticalLength)/2;
            
            if (connectivityMapCutStatus == 0){
                errorNoHold = 14;
                connectivityMapCut = new int *[dimension+1];
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    errorNoHold = 15;
                    connectivityMapCut [counter1] = new int [dimension+1];
                }
                
                connectivityMapCutStatus = 1;
                connectivityMapCutSizeHold = dimension;
            }
            else if (connectivityMapCutStatus == 1 && 300 < connectivityMapCutSizeHold && 300 > dimension){
                for (int counter1 = 0; counter1 < connectivityMapCutSizeHold+1; counter1++) delete [] connectivityMapCut [counter1];
                delete [] connectivityMapCut;
                
                connectivityMapCutSizeHold = dimension;
                
                errorNoHold = 16;
                connectivityMapCut = new int *[dimension+1];
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    errorNoHold = 17;
                    connectivityMapCut [counter1] = new int [dimension+1];
                }
            }
            else if (connectivityMapCutStatus == 1 && connectivityMapCutSizeHold < dimension){
                for (int counter1 = 0; counter1 < connectivityMapCutSizeHold+1; counter1++) delete [] connectivityMapCut [counter1];
                delete [] connectivityMapCut;
                
                errorNoHold = 18;
                connectivityMapCut = new int *[dimension+1];
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    errorNoHold = 19;
                    connectivityMapCut [counter1] = new int [dimension+1];
                }
                
                connectivityMapCutSizeHold = dimension;
            }
            
            if (internalZeroMapStatus == 0){
                errorNoHold = 20;
                internalZeroMap = new int *[dimension+1];
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    errorNoHold = 21;
                    internalZeroMap [counter1] = new int [dimension+1];
                }
                
                internalZeroMapStatus = 1;
                internalZeroMapSizeHold = dimension;
            }
            else if (internalZeroMapStatus == 1 && 300 < internalZeroMapSizeHold && 300 > dimension){
                for (int counter1 = 0; counter1 < internalZeroMapSizeHold+1; counter1++) delete [] internalZeroMap [counter1];
                delete [] internalZeroMap;
                
                internalZeroMapSizeHold = dimension;
                
                errorNoHold = 22;
                internalZeroMap = new int *[dimension+1];
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    internalZeroMap [counter1] = new int [dimension+1];
                }
            }
            else if (internalZeroMapStatus == 1 && internalZeroMapSizeHold < dimension){
                for (int counter1 = 0; counter1 < internalZeroMapSizeHold+1; counter1++) delete [] internalZeroMap [counter1];
                delete [] internalZeroMap;
                
                errorNoHold = 23;
                internalZeroMap = new int *[dimension+1];
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    errorNoHold = 24;
                    internalZeroMap [counter1] = new int [dimension+1];
                }
                
                internalZeroMapSizeHold = dimension;
            }
            
            if (targetMapStatus == 0){
                errorNoHold = 25;
                targetMap = new int *[dimension+1];
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    errorNoHold = 26;
                    targetMap [counter1] = new int [dimension+1];
                }
                
                targetMapStatus = 1;
                targetMapSizeHold = dimension;
            }
            else if (targetMapStatus == 1 && 300 < targetMapSizeHold && 300 > dimension){
                for (int counter1 = 0; counter1 < targetMapSizeHold+1; counter1++) delete [] targetMap [counter1];
                delete [] targetMap;
                
                targetMapSizeHold = dimension;
                
                errorNoHold = 27;
                targetMap = new int *[dimension+1];
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    errorNoHold = 28;
                    targetMap [counter1] = new int [dimension+1];
                }
            }
            else if (targetMapStatus == 1 && targetMapSizeHold < dimension){
                for (int counter1 = 0; counter1 < targetMapSizeHold+1; counter1++) delete [] targetMap [counter1];
                delete [] targetMap;
                
                errorNoHold = 29;
                targetMap = new int *[dimension+1];
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    errorNoHold = 30;
                    targetMap [counter1] = new int [dimension+1];
                }
                
                targetMapSizeHold = dimension;
            }
            
            for (int counterY = 0; counterY < dimension+1; counterY++){
                for (int counterX = 0; counterX < dimension+1; counterX++){
                    connectivityMapCut [counterY][counterX] = 0;
                    internalZeroMap [counterY][counterX] = 0;
                    targetMap [counterY][counterX] = 0;
                }
            }
            
            for (int counter1 = 0; counter1 < referenceLineCount/2; counter1++){
                //cout<<lineTempX<<" "<<lineTempY<<" "<<arrayReferenceLine [counter1*2]<<" "<<arrayReferenceLine [counter1*2+1]<<" arrayReferenceLine"<<endl;
                
                if (arrayReferenceLine [counter1*2]-horizontalStart2 >= 0 && arrayReferenceLine [counter1*2]-horizontalStart2 < dimension && arrayReferenceLine [counter1*2+1]-verticalStart2 >= 0 && arrayReferenceLine [counter1*2+1]-verticalStart2 < dimension) connectivityMapCut [arrayReferenceLine [counter1*2+1]-verticalStart2][arrayReferenceLine [counter1*2]-horizontalStart2] = 1;
            }
            
            if (processType == 1){
                for (int counter1 = 0; counter1 < positionReviseCurrentCount/7; counter1++){
                    if (arrayPositionReviseCurrent [counter1*7+4] == fusionPartnerCellNo && arrayPositionReviseCurrent [counter1*7+6] == fusionPartnerLine){
                        if (arrayPositionReviseCurrent [counter1*7]-horizontalStart2 >= 0 && arrayPositionReviseCurrent [counter1*7]-horizontalStart2 < dimension && arrayPositionReviseCurrent [counter1*7+1]-verticalStart2 >= 0 && arrayPositionReviseCurrent [counter1*7+1]-verticalStart2 < dimension) connectivityMapCut [arrayPositionReviseCurrent [counter1*7+1]-verticalStart2][arrayPositionReviseCurrent [counter1*7]-horizontalStart2] = 1;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut [counterA][counterB];
            //    cout<<" connectivityMapCut "<<counterA<<endl;
            //}
            
            delete [] connectAnalysisX;
            delete [] connectAnalysisY;
            delete [] connectAnalysisTempX;
            delete [] connectAnalysisTempY;
            
            //------Fill inside------
            errorNoHold = 31;
            connectAnalysisX = new int [(dimension+2)*4];
            errorNoHold = 32;
            connectAnalysisY = new int [(dimension+2)*4];
            errorNoHold = 33;
            connectAnalysisTempX = new int [(dimension+2)*4];
            errorNoHold = 34;
            connectAnalysisTempY = new int [(dimension+2)*4];
            
            connectivityNumber = -3;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapCut [counterY][counterX] == 0){
                        connectivityNumber = connectivityNumber+2;
                        connectAnalysisCount = 0;
                        
                        if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMapCut [counterY][counterX] = connectivityNumber;
                        
                        if (counterY-1 >= 0 && connectivityMapCut [counterY-1][counterX] == 0){
                            connectivityMapCut [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && connectivityMapCut [counterY][counterX+1] == 0){
                            connectivityMapCut [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && connectivityMapCut [counterY+1][counterX] == 0){
                            connectivityMapCut [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && connectivityMapCut [counterY][counterX-1] == 0){
                            connectivityMapCut [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && connectivityMapCut [ySource-1][xSource] == 0){
                                        connectivityMapCut [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && connectivityMapCut [ySource][xSource+1] == 0){
                                        connectivityMapCut [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && connectivityMapCut [ySource+1][xSource] == 0){
                                        connectivityMapCut [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMapCut [ySource][xSource-1] == 0){
                                        connectivityMapCut [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            areaCountCurrent = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapCut [counterY][counterX] == -1) connectivityMapCut [counterY][counterX] = 0;
                    else{
                        
                        connectivityMapCut [counterY][counterX] = -1;
                        areaCountCurrent++;
                    }
                }
            }
            
            if ((processType == 3 && areaCountCurrent < 100) || (processType != 3 && cutOffAdjust != -1  && areaCountCurrent < 100)){
                errorNoHold = 35;
                int **mapHoldTemp = new int *[dimension+1];
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    errorNoHold = 36;
                    mapHoldTemp [counter1] = new int [dimension+1];
                }
                
                int expansioDegree = 2;
                
                if (areaCountCurrent < 50) expansioDegree = 4;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        mapHoldTemp [counterY][counterX] = 0;
                    }
                }
                
                for (int counterY = 0; counterY < dimension-expansioDegree; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapCut [counterY][counterX] != 0) mapHoldTemp [counterY+expansioDegree][counterX] = 1;
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<mapHoldTemp [counterA][counterB];
                //    cout<<" mapHoldTemp "<<counterA<<endl;
                //}
                
                for (int counterY = expansioDegree; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapCut [counterY][counterX] != 0) mapHoldTemp [counterY-expansioDegree][counterX] = 1;
                    }
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension-expansioDegree; counterX++){
                        if (connectivityMapCut [counterY][counterX] != 0) mapHoldTemp [counterY][counterX+expansioDegree] = 1;
                    }
                }
                
                for (int counterY = expansioDegree; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapCut [counterY][counterX] != 0) mapHoldTemp [counterY][counterX-expansioDegree] = 1;
                    }
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (mapHoldTemp [counterY][counterX] != 0) connectivityMapCut [counterY][counterX] = -1;
                    }
                }
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++) delete [] mapHoldTemp [counter1];
                
                delete [] mapHoldTemp;
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<arrayCellTrackingPreviousMapTemp [counterA][counterB];
            //	cout<<" arrayCellTrackingPreviousMapTemp "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut [counterA][counterB];
            //    cout<<" connectivityMapCut "<<counterA<<endl;
            //}
            
            //---------Background image set----------
            errorNoHold = 37;
            int **rangeMatrix = new int *[dimension+4];
            
            for (int counter1 = 0; counter1 < dimension+4; counter1++){
                errorNoHold = 38;
                rangeMatrix [counter1] = new int [dimension+4];
            }
            
            connectivityNumber = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                        if (cutOffAdjust == -1){
                            if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] == 100) rangeMatrix [counterY][counterX] = 0;
                            else if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] < cutStatusDic) rangeMatrix [counterY][counterX] = 0;
                            else rangeMatrix [counterY][counterX] = -150;
                        }
                        else{
                            
                            if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] < cutOffAdjust) rangeMatrix [counterY][counterX] = 0;
                            else rangeMatrix [counterY][counterX] = -150;
                        }
                    }
                    else rangeMatrix [counterY][counterX] = 0;
                    
                    if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                        averageCurrentHold = averageCurrentHold+sourceImage [mapPositionPointer][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2];
                    }
                }
            }
            
            averageCurrentHold = averageCurrentHold/(double)(dimension*dimension);
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (rangeMatrix [counterY][counterX] == -150){
                        connectivityNumber++;
                        rangeMatrix [counterY][counterX] = connectivityNumber;
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrix [counterY-1][counterX-1] == -150){
                            rangeMatrix [counterY-1][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && rangeMatrix [counterY-1][counterX] == -150){
                            rangeMatrix [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && counterX+1 < dimension && rangeMatrix [counterY-1][counterX+1] == -150){
                            rangeMatrix [counterY-1][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && rangeMatrix [counterY][counterX+1] == -150){
                            rangeMatrix [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && counterX+1 < dimension && rangeMatrix [counterY+1][counterX+1] == -150){
                            rangeMatrix [counterY+1][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && rangeMatrix [counterY+1][counterX] == -150){
                            rangeMatrix [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && counterX-1 >= 0 && rangeMatrix [counterY+1][counterX-1] == -150){
                            rangeMatrix [counterY+1][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && rangeMatrix [counterY][counterX-1] == -150){
                            rangeMatrix [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                    xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                    
                                    if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrix [ySource-1][xSource-1] == -150){
                                        rangeMatrix [ySource-1][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && rangeMatrix [ySource-1][xSource] == -150){
                                        rangeMatrix [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && xSource+1 < dimension && rangeMatrix [ySource-1][xSource+1] == -150){
                                        rangeMatrix [ySource-1][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && rangeMatrix [ySource][xSource+1] == -150){
                                        rangeMatrix [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 > dimension && xSource+1 < dimension && rangeMatrix [ySource+1][xSource+1] == -150){
                                        rangeMatrix [ySource+1][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && rangeMatrix [ySource+1][xSource] == -150){
                                        rangeMatrix [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && xSource-1 >= 0 && rangeMatrix [ySource+1][xSource-1] == -150){
                                        rangeMatrix [ySource+1][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && rangeMatrix [ySource][xSource-1] == -150){
                                        rangeMatrix [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                    connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //------Determine number of pixels------
            errorNoHold = 39;
            int *connectedPixels = new int [connectivityNumber+50];
            
            for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPixels [counter2] = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (rangeMatrix [counterY][counterX] != 0) connectedPixels [rangeMatrix [counterY][counterX]]++;
                }
            }
            
            //------Map up-date------
            int connectTemp = 1;
            
            for (int counter2 = 1; counter2 <= connectivityNumber; counter2++){
                if (connectedPixels [counter2] < 10) connectedPixels [counter2] = 0;
                else{
                    
                    connectedPixels [counter2] = connectTemp;
                    connectTemp++;
                }
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if ((connectTemp = rangeMatrix [counterY][counterX]) != 0) rangeMatrix [counterY][counterX] = connectedPixels [connectTemp];
                    else rangeMatrix [counterY][counterX] = 0;
                }
            }
            
            delete [] connectedPixels;
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<rangeMatrix [counterA][counterB];
            //    cout<<" rangeMatrix "<<counterA<<endl;
            //}
            
            //--------Adjust with cut off image--------
            int areaExpande = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension && connectivityMapCut [counterY][counterX] != 0){
                        if (rangeMatrix [counterY][counterX] == 0) connectivityMapCut [counterY][counterX] = 0;
                        if (putativeMapStatus == 1 && putativeMap [counterY+verticalStart2][counterX+horizontalStart2] < 0) connectivityMapCut [counterY][counterX] = 0;
                        if (connectivityMapCut [counterY][counterX] != 0) areaExpande++;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut [counterA][counterB];
            //    cout<<" connectivityMapCut "<<counterA<<endl;
            //}
            
            connectivityNumber = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapCut [counterY][counterX] == -1){
                        connectivityNumber++;
                        connectAnalysisCount = 0;
                        
                        if (connectivityNumber >= 1) connectivityMapCut [counterY][counterX] = connectivityNumber;
                        
                        if (counterY-1 >= 0 && connectivityMapCut [counterY-1][counterX] == -1){
                            connectivityMapCut [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && connectivityMapCut [counterY][counterX+1] == -1){
                            connectivityMapCut [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && connectivityMapCut [counterY+1][counterX] == -1){
                            connectivityMapCut [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && connectivityMapCut [counterY][counterX-1] == -1){
                            connectivityMapCut [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && connectivityMapCut [ySource-1][xSource] == -1){
                                        connectivityMapCut [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && connectivityMapCut [ySource][xSource+1] == -1){
                                        connectivityMapCut [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && connectivityMapCut [ySource+1][xSource] == -1){
                                        connectivityMapCut [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMapCut [ySource][xSource-1] == -1){
                                        connectivityMapCut [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //   for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut [counterA][counterB];
            //    cout<<" connectivityMapCut "<<counterA<<endl;
            //}
            
            errorNoHold = 40;
            int *mainConnectFindList = new int [connectivityNumber+2];
            
            for (int counter1 = 0; counter1 < connectivityNumber+2; counter1++) mainConnectFindList [counter1] = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++) mainConnectFindList [connectivityMapCut [counterY][counterX]]++;
            }
            
            //for (int counter1 = 1; counter1 <= connectivityNumber; counter1++) cout<<mainConnectFindList [counter1]<<" mainConnectFindList"<<endl;
            
            int largestConnect = 0;
            int refConnectNo = 0;
            
            for (int counter1 = 1; counter1 < connectivityNumber+1; counter1++){
                if (mainConnectFindList [counter1] > largestConnect){
                    largestConnect = mainConnectFindList [counter1];
                    refConnectNo = counter1;
                }
            }
            
            delete [] mainConnectFindList;
            
            //cout<<refConnectNo<<" refNo "<<trackHoldFlag<<endl;
            
            if (refConnectNo != 0){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapCut [counterY][counterX] != 0 && connectivityMapCut [counterY][counterX] != refConnectNo) connectivityMapCut [counterY][counterX] = 0;
                        else if (connectivityMapCut [counterY][counterX] != 0) connectivityMapCut [counterY][counterX] = 1;
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut [counterA][counterB];
                //    cout<<" connectivityMapCut "<<counterA<<endl;
                //}
                
                //=======fill zero====
                errorNoHold = 41;
                int **connectivityUpdate5 = new int *[dimension+4];
                
                for (int counter1 = 0; counter1 < dimension+4; counter1++){
                    errorNoHold = 42;
                    connectivityUpdate5 [counter1] = new int [dimension+4];
                }
                
                //-------Zero Fill-------
                for (int counterX = 0; counterX < dimension+4; counterX++){
                    for (int counterY = 0; counterY < dimension+4; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = connectivityMapCut [counterY][counterX];
                }
                
                connectivityNumber = 0;
                
                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                        if (connectivityUpdate5 [counterY2][counterX2] == 0){
                            connectivityNumber--;
                            connectAnalysisCount = 0;
                            
                            connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                            
                            if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                                connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                            }
                            if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                            }
                            if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                            }
                            if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                        xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                        
                                        if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                            connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                            connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                            connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                            connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                        connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < dimension+2; counterA++){
                //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                //	cout<<" connectivityUpdate5 "<<counterA<<endl;
                //}
                
                int connectTemp2 = 0;
                
                if (connectivityNumber < -1){
                    errorNoHold = 43;
                    int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                    
                    for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                            connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                            
                            if (connectTemp2 < -1){
                                connectTemp2 = connectTemp2*-1;
                                
                                if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                            }
                        }
                    }
                    
                    int zeroFillFlag = 0;
                    
                    for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                        if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
                    }
                    
                    //for (int counter3 = 1; counter3 <= connectivityNumber*-1; counter3++){
                    //    cout<<counter3<<" "<<connectCheckArray [counter3*2]<<" "<<connectCheckArray [counter3*2+1]<<" connectCheckArray"<<endl;
                    //}
                    
                    if (zeroFillFlag == 1){
                        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                                
                                if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                            }
                        }
                        
                        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                if (connectivityUpdate5 [counterY2][counterX2] > 0) connectivityMapCut [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                            }
                        }
                    }
                    
                    delete [] connectCheckArray;
                }
                
                for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] connectivityUpdate5 [counter1];
                delete [] connectivityUpdate5;
                
            }
            else trackHoldFlag = 3000; //-----Lost Check------
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut [counterA][counterB];
            //    cout<<" connectivityMapCut "<<counterA<<endl;
            //}
            
            //cout<<trackHoldFlag<<" trackHold "<<processType<<endl;
            
            int fusionPartnerOriginalConnect = 0;
            
            if (trackHoldFlag != 3000){
                //------Overlap analysis------
                
                if (processType == 2 || processType == 3){
                    errorNoHold = 40;
                    
                    //int TEST [dimension][dimension];
                    
                    //for (int counterY = 0; counterY < dimension; counterY++){
                    //	for (int counterX = 0; counterX < dimension; counterX++) TEST [counterY][counterX] = 0;
                    //}
                    
                    //int TEST2 [dimension][dimension];
                    
                    //for (int counterY = 0; counterY < dimension; counterY++){
                    //	for (int counterX = 0; counterX < dimension; counterX++) TEST2 [counterY][counterX] = 0;
                    //}
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            //if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                            //    TEST [counterY][counterX] = revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2];
                            //}
                            
                            //if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                            //	TEST2 [counterY][counterX] = connectMapSelect [counterY+verticalStart2][counterX+horizontalStart2];
                            //}
                            
                            if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension && connectivityMapCut [counterY][counterX] != 0){
                                if (revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2] != 0){
                                    for (int counter1 = 0; counter1 < connectLineageRelCurrentCount/6; counter1++){
                                        if (arrayConnectLineageRelCurrent [counter1*6+1] == revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2] && arrayConnectLineageRelCurrent [counter1*6+4] == 0){
                                            connectivityMapCut [counterY][counterX] = 0;
                                            break;
                                        }
                                    }
                                }
                            }
                            else connectivityMapCut [counterY][counterX] = 0;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
                    // 	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
                    //	cout<<" arrayConnectLineageRel "<<counterA+1<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<TEST [counterA][counterB];
                    //	cout<<" TEST "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<TEST2 [counterA][counterB];
                    //	cout<<" TEST2 "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < maxConnectNumberList+1; counterA++){
                    //	cout<<counterA<<" "<<overlapList [counterA]<<" overlapList"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //     for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut [counterA][counterB];
                    //     cout<<" connectivityMapCut "<<counterA<<endl;
                    //}
                    
                    //======Internal zero check======
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) internalZeroMap [counterY][counterX] = connectivityMapCut [counterY][counterX];
                    }
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<internalZeroMap [counterA][counterB];
                    //    cout<<" internalZeroMap "<<counterA<<endl;
                    //}
                    
                    connectivityNumber = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (internalZeroMap [counterY2][counterX2] == 0){
                                connectivityNumber--;
                                connectAnalysisCount = 0;
                                
                                internalZeroMap [counterY2][counterX2] = connectivityNumber;
                                
                                if (counterY2-1 >= 0 && internalZeroMap [counterY2-1][counterX2] == 0){
                                    internalZeroMap [counterY2-1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                }
                                if (counterX2+1 < dimension && internalZeroMap [counterY2][counterX2+1] == 0){
                                    internalZeroMap [counterY2][counterX2+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                if (counterY2+1 < dimension && internalZeroMap [counterY2+1][counterX2] == 0){
                                    internalZeroMap [counterY2+1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                }
                                if (counterX2-1 >= 0 && internalZeroMap [counterY2][counterX2-1] == 0){
                                    internalZeroMap [counterY2][counterX2-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                            
                                            if (ySource-1 >= 0 && internalZeroMap [ySource-1][xSource] == 0){
                                                internalZeroMap [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && internalZeroMap [ySource][xSource+1] == 0){
                                                internalZeroMap [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && internalZeroMap [ySource+1][xSource] == 0){
                                                internalZeroMap [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && internalZeroMap [ySource][xSource-1] == 0){
                                                internalZeroMap [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<internalZeroMap [counterA][counterB];
                    //    cout<<" internalZeroMap "<<counterA<<endl;
                    //}
                    
                    //=====Internal zero map========
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (internalZeroMap [counterY][counterX] >= -1) internalZeroMap [counterY][counterX] = 0;
                        }
                    }
                }
                
                if (processType == 1){
                    //========= 1. Lineage No, 2. connect No, 3. image number, 4. cell no, 5. target (0: non-target, 1: target), 6. reserve=========
                    maxConnectNumberList = timeSelectedCurrentCount/10;
                    
                    errorNoHold = 44;
                    int *overlapList = new int [maxConnectNumberList+2];
                    errorNoHold = 45;
                    int *overlapList2 = new int [maxConnectNumberList+2];
                    errorNoHold = 46;
                    int *overlapList3 = new int [maxConnectNumberList+2];
                    
                    for (int counter1 = 0; counter1 < maxConnectNumberList+2; counter1++){
                        overlapList [counter1] = 0;
                        overlapList2 [counter1] = 0;
                        overlapList3 [counter1] = 0;
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension && connectivityMapCut [counterY][counterX] != 0){
                                overlapList [revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2]]++;
                            }
                        }
                    }
                    
                    //for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++) cout<<counter1<<" "<< overlapList [counter1] <<" overlapList"<<endl;
                    
                    int connectMatchFind = 0;
                    int cellNoMatchFind = 0;
                    
                    for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                        if (overlapList [counter1] != 0 && counter1 != cellLineageTempInt){
                            connectMatchFind = 0;
                            cellNoMatchFind = 0;
                            
                            for (int counter2 = 0; counter2 < connectLineageRelCurrentCount/6; counter2++){
                                if (arrayConnectLineageRelCurrent [counter2*6+1] == counter1 && arrayConnectLineageRelCurrent [counter2*6+4] != 1){
                                    connectMatchFind = arrayConnectLineageRelCurrent [counter2*6];
                                    cellNoMatchFind = arrayConnectLineageRelCurrent [counter2*6+3];
                                }
                            }
                            
                            if (connectMatchFind != 0){
                                overlapList2 [counter1] = connectMatchFind;
                                overlapList3 [counter1] = cellNoMatchFind;
                            }
                        }
                    }
                    
                    //for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                    //    cout<<counter1<<" "<< overlapList [counter1]<<" "<<overlapList2 [counter1] <<" "<<overlapList3 [counter1]<<" overlapList"<<endl;
                    //}
                    
                    int maxAreaConnect = 0;
                    int maxAreaCount = 0;
                    int maxAreaConnectCellNo = -1;
                    
                    for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                        if (overlapList2 [counter1] != 0){
                            if (overlapList [counter1] > maxAreaConnect){
                                maxAreaConnect = overlapList [counter1];
                                maxAreaCount = overlapList2 [counter1];
                                maxAreaConnectCellNo = overlapList3 [counter1];
                            }
                        }
                    }
                    
                    if (maxAreaCount == 0) trackHoldFlag = 3002; //------Fusion end check-------
                    else{
                        
                        fusionPartnerLine = maxAreaCount;
                        fusionPartnerCellNo = maxAreaConnectCellNo;
                        
                        for (int counter1 = 0; counter1 < connectLineageRelCurrentCount/6; counter1++){
                            if (arrayConnectLineageRel [counter1*6] == fusionPartnerLine && arrayConnectLineageRel [counter1*6+3] == fusionPartnerCellNo) fusionPartnerOriginalConnect = arrayConnectLineageRel [counter1*6+1];
                        }
                        
                        for (int counter1 = 0; counter1 < timeSelectedCurrentCount/10; counter1++){
                            arrayTimeSelectedCurrent [counter1*10+1] = 0;
                            arrayTimeSelectedCurrent [counter1*10+3] = 0;
                        }
                        
                        for (int counter1 = 0; counter1 < maxConnectNumberList+1; counter1++) overlapList [counter1] = 0;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension && connectivityMapCut [counterY][counterX] != 0){
                                    
                                    overlapList [revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2]]++;
                                    
                                    if (revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2] != 0){
                                        for (int counter1 = 0; counter1 < connectLineageRelCurrentCount/6; counter1++){
                                            if (arrayConnectLineageRelCurrent [counter1*6+1] == revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2] && arrayConnectLineageRelCurrent [counter1*6+4] == 0 && (arrayConnectLineageRelCurrent [counter1*6] != fusionPartnerLine || arrayConnectLineageRel [counter1*6+3] != fusionPartnerCellNo)){
                                                connectivityMapCut [counterY][counterX] = 0;
                                                overlapList [revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2]] = 0;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        
                        //for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++) cout<<counter1<<" "<< overlapList [counter1] <<" overlapList"<<endl;
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut [counterA][counterB];
                        //	cout<<" connectivityMapCut "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
                        //	cout<<" arrayLineageData "<<counterA<<endl;
                        //}
                        
                        //------Check whether fusion partner is occupied by other marks------
                        int occupyCheck = 0;
                        
                        for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                            if (fusionPartnerLine == arrayLineageStartEnd [counter1*8] && fusionPartnerCellNo == arrayLineageStartEnd [counter1*8+1]){
                                for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                                    if (arrayLineageData [counter2*8+2] == imageNumberInt+1 && (arrayLineageData [counter2*8+3] == 2 || arrayLineageData [counter2*8+3] == 10)){
                                        occupyCheck = 1;
                                        break;
                                    }
                                }
                            }
                            if (occupyCheck == 1){
                                break;
                            }
                        }
                        
                        //cout<<occupyCheck<<" OccupyCheck"<<endl;
                        
                        if (occupyCheck == 0){
                            fusionPartnerLine = 0;
                            fusionPartnerCellNo = -1;
                            
                            trackHoldFlag = 3003; //----Fusion Position occupy
                        }
                        else{
                            
                            //======Internal zero check======
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++) internalZeroMap [counterY][counterX] = connectivityMapCut [counterY][counterX];
                            }
                            
                            //for (int counterA = 0; counterA < dimension; counterA++){
                            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<internalZeroMap [counterA][counterB];
                            //    cout<<" internalZeroMap "<<counterA<<endl;
                            //}
                            
                            connectivityNumber = 0;
                            
                            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                    if (internalZeroMap [counterY2][counterX2] == 0){
                                        connectivityNumber--;
                                        connectAnalysisCount = 0;
                                        
                                        internalZeroMap [counterY2][counterX2] = connectivityNumber;
                                        
                                        if (counterY2-1 >= 0 && internalZeroMap [counterY2-1][counterX2] == 0){
                                            internalZeroMap [counterY2-1][counterX2] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                        }
                                        if (counterX2+1 < dimension && internalZeroMap [counterY2][counterX2+1] == 0){
                                            internalZeroMap [counterY2][counterX2+1] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                        }
                                        if (counterY2+1 < dimension && internalZeroMap [counterY2+1][counterX2] == 0){
                                            internalZeroMap [counterY2+1][counterX2] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                        }
                                        if (counterX2-1 >= 0 && internalZeroMap [counterY2][counterX2-1] == 0){
                                            internalZeroMap [counterY2][counterX2-1] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                        }
                                        
                                        if (connectAnalysisCount != 0){
                                            do{
                                                
                                                terminationFlag = 1;
                                                connectAnalysisTempCount = 0;
                                                
                                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                                    
                                                    if (ySource-1 >= 0 && internalZeroMap [ySource-1][xSource] == 0){
                                                        internalZeroMap [ySource-1][xSource] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                    }
                                                    if (xSource+1 < dimension && internalZeroMap [ySource][xSource+1] == 0){
                                                        internalZeroMap [ySource][xSource+1] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                    }
                                                    if (ySource+1 < dimension && internalZeroMap [ySource+1][xSource] == 0){
                                                        internalZeroMap [ySource+1][xSource] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                    }
                                                    if (xSource-1 >= 0 && internalZeroMap [ySource][xSource-1] == 0){
                                                        internalZeroMap [ySource][xSource-1] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                    }
                                                }
                                                
                                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                                }
                                                
                                                connectAnalysisCount = connectAnalysisTempCount;
                                                
                                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                                
                                            } while (terminationFlag == 1);
                                        }
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < dimension; counterA++){
                            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<internalZeroMap [counterA][counterB];
                            //    cout<<" internalZeroMap "<<counterA<<endl;
                            //}
                            
                            //=====Internal zero map========
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (internalZeroMap [counterY][counterX] >= -1) internalZeroMap [counterY][counterX] = 0;
                                }
                            }
                        }
                    }
                    
                    delete [] overlapList;
                    delete [] overlapList2;
                    delete [] overlapList3;
                }
                
                if (trackHoldFlag != 3002 && trackHoldFlag != 3003){
                    int type = 1;
                    int valueTemp = 1;
                    resultsType1 = [self areaProcess:type:dimension:valueTemp:targetCellStatus:processType]; //-----resultsType1: Hold target Connect
                    if (errorNoHold != 0){
                        errorNoHold = errorNoHold+2000;
                        throw errorCheckThrow;
                    }
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut [counterA][counterB];
                    //    cout<<" connectivityMapCut "<<counterA<<endl;
                    //}
                    
                    errorNoHold = 47;
                    int *connectNumber = new int [dimension*dimension+50]; //-------List connect val of each pix--------
                    int connectNumberCount = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension && connectivityMapCut [counterY][counterX] != 0 && revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2] != 0 && internalZeroMap [counterY][counterX] == 0) connectNumber [connectNumberCount] = revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2], connectNumberCount++;
                        }
                    }
                    
                    if (resultsType1 != 0){
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension && connectivityMapCut [counterY][counterX] != 0 && internalZeroMap [counterY][counterX] == 0) revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2] = connectivityMapCut [counterY][counterX];
                            }
                        }
                    }
                    
                    //for (int counter1 = 0; counter1 < connectNumberCount; counter1++){
                    //  cout<<counter1<<" "<<connectNumber [counter1]<<" connectNumber"<<endl;
                    //}
                    
                    //int **sourceImageTest = new int *[trackAreaSize+1]; //=======For check
                    
                    //for (int counter1 = 0; counter1 < trackAreaSize+1; counter1++){
                    //    sourceImageTest [counter1] = new int [trackAreaSize+1];
                    //}
                    
                    //for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    //    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                    //        sourceImageTest [counterY][counterX] = 0;
                    //    }
                    //}
                    
                    //for (int counterY = 0; counterY < imageDimension; counterY++){
                    //    for (int counterX = 0; counterX < imageDimension; counterX++){
                    //        if (counterY-verticalStart >= 0 && counterY-verticalStart < trackAreaSize && counterX-horizontalStart >= 0 && counterX-horizontalStart < trackAreaSize){
                    //            if (revisedMapCurrent [counterY][counterX] != 0){
                    //                sourceImageTest [counterY-verticalStart][counterX-horizontalStart] = revisedMapCurrent [counterY][counterX];
                    //            }
                    //        }
                    //    }
                    //}
                    
                    //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                    //    for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<sourceImageTest [counterA][counterB];
                    //    cout<<" sourceImageTest "<<counterA<<endl;
                    //}
                    
                    //for (int counter1 = 0; counter1 < trackAreaSize+1; counter1++){
                    //    delete [] sourceImageTest [counter1];
                    //}
                    
                    //delete [] sourceImageTest;
                    
                    if (resultsType1 != 0){
                        int numberOfRemaining = 0;
                        
                        errorNoHold = 48;
                        int *connectSort = new int [connectNumberCount+4]; //-------Keep first appeared connect no (0) and rests are (1)--------
                        errorNoHold = 49;
                        int *connectNumberList = new int [connectNumberCount+4];
                        
                        if (connectNumberCount != 0){
                            for (int counter1 = 0; counter1 < connectNumberCount+4; counter1++){
                                connectSort [counter1] = 0;
                                connectNumberList [counter1] = connectNumber [counter1];
                            }
                            
                            for (int counter1 = 0; counter1 < connectNumberCount-1; counter1++){
                                if (connectSort [counter1] == 0) valueTemp = connectNumberList [counter1];
                                
                                for (int counter2 = counter1+1; counter2 < connectNumberCount; counter2++){
                                    if (connectNumberList [counter2] == valueTemp) connectSort [counter2] = 1;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectNumberCount; counter1++){
                                if (connectSort [counter1] == 0) numberOfRemaining++;
                            }
                        }
                        
                        errorNoHold = 50;
                        int *connectProcessList = new int [numberOfRemaining+10]; //-----The list of connect group that will be processed (inc. one processed by Type1)------
                        
                        for (int counter1 = 0; counter1 < numberOfRemaining+10; counter1++) connectProcessList [counter1] = 0;
                        
                        if (connectNumberCount != 0){
                            int entryCount = 0; //------List of connect that to be processed------
                            
                            for (int counter1 = 0; counter1 < connectNumberCount; counter1++){
                                if (connectSort [counter1] == 0) connectProcessList [entryCount] = connectNumberList [counter1], entryCount++;
                            }
                        }
                        
                        //for (int counter1 = 0; counter1 < numberOfRemaining; counter1++){
                        //	cout<<counter1<<" "<<connectProcessList [counter1]<<" connectProcessList"<<endl;
                        //}
                        
                        delete [] connectSort;
                        delete [] connectNumberList;
                        
                        if (numberOfRemaining != 0){
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++) targetMap [counterY][counterX] = connectivityMapCut [counterY][counterX];
                            }
                            
                            int connectTemp2 = 0;
                            int zeroFillFlag = 0;
                            int maxConnectNumberList2 = 0;
                            int insideFind = 0;
                            int edgeCheck = 0;
                            
                            //for (int counterA = 0; counterA < gravityCenterRevCurrentCount/6; counterA++){
                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRevCurrent [counterA*6+counterB];
                            //    cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
                            //}
                            
                            for (int counter1 = 0; counter1 < numberOfRemaining; counter1++){
                                valueTemp = connectProcessList [counter1];
                                
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++) connectivityMapCut [counterY][counterX] = 0;
                                }
                                
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++){
                                        if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension && revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2] == valueTemp && rangeMatrix [counterY][counterX] != 0) connectivityMapCut [counterY][counterX] = revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2];
                                    }
                                }
                                
                                //========Zero fill=========
                                errorNoHold = 51;
                                int **connectivityUpdate5 = new int *[dimension+4];
                                
                                for (int counter2 = 0; counter2 < dimension+4; counter2++){
                                    errorNoHold = 52;
                                    connectivityUpdate5 [counter2] = new int [dimension+4];
                                }
                                
                                //-------Zero Fill-------
                                for (int counterX = 0; counterX < dimension+4; counterX++){
                                    for (int counterY = 0; counterY < dimension+4; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
                                }
                                
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = connectivityMapCut [counterY][counterX];
                                }
                                
                                connectivityNumber = 0;
                                
                                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                        if (connectivityUpdate5 [counterY2][counterX2] == 0){
                                            connectivityNumber--;
                                            connectAnalysisCount = 0;
                                            
                                            connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                                            
                                            if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                                                connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                            }
                                            if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                                connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                            }
                                            if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                                connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                            }
                                            if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                                connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                            }
                                            
                                            if (connectAnalysisCount != 0){
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    connectAnalysisTempCount = 0;
                                                    
                                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                        
                                                        if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                                            connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                                            connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                        if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                                            connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                                            connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                    }
                                                    
                                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                                    }
                                                    
                                                    connectAnalysisCount = connectAnalysisTempCount;
                                                    
                                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                                    
                                                } while (terminationFlag == 1);
                                            }
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < dimension+2; counterA++){
                                //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                                //	cout<<" connectivityUpdate5 "<<counterA<<endl;
                                //}
                                
                                if (connectivityNumber < -1){
                                    errorNoHold = 53;
                                    int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                                    
                                    for (int counter2 = 0; counter2 < connectivityNumber*-1*2+5; counter2++) connectCheckArray [counter2] = 0;
                                    
                                    for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                        for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                            connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                                            
                                            if (connectTemp2 < -1){
                                                connectTemp2 = connectTemp2*-1;
                                                
                                                if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                            }
                                        }
                                    }
                                    
                                    zeroFillFlag = 0;
                                    
                                    for (int counter2 = 2; counter2 <= connectivityNumber*-1; counter2++){
                                        if (connectCheckArray [counter2*2] != 0 && connectCheckArray [counter2*2+1] == 0) zeroFillFlag = 1;
                                    }
                                    
                                    if (zeroFillFlag == 1){
                                        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                                connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                                                
                                                if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                                            }
                                        }
                                        
                                        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                                if (connectivityUpdate5 [counterY2][counterX2] > 0) connectivityMapCut [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                                            }
                                        }
                                    }
                                    
                                    delete [] connectCheckArray;
                                }
                                
                                for (int counter2 = 0; counter2 < dimension+4; counter2++) delete [] connectivityUpdate5 [counter2];
                                
                                delete [] connectivityUpdate5;
                                
                                //======Inside check=====
                                errorNoHold = 54;
                                int **insideCheckMap = new int *[dimension+1];
                                
                                for (int counter2 = 0; counter2 < dimension+1; counter2++){
                                    errorNoHold = 55;
                                    insideCheckMap [counter2] = new int [dimension+1];
                                }
                                
                                for (int counterY = 0; counterY < dimension+1; counterY++){
                                    for (int counterX = 0; counterX < dimension+1; counterX++) insideCheckMap [counterY][counterX] = 0;
                                }
                                
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++){
                                        if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension && connectivityMapCut [counterY][counterX] != 0){
                                            insideCheckMap [counterY][counterX] = revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2];
                                        }
                                    }
                                }
                                
                                maxConnectNumberList2 = timeSelectedCurrentCount/10;
                                
                                errorNoHold = 56;
                                int *insideCheck = new int [maxConnectNumberList2*2+5];
                                
                                for (int counter2 = 0; counter2 < maxConnectNumberList2*2+5; counter2++) insideCheck [counter2] = 0;
                                
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++){
                                        if (connectivityMapCut [counterY][counterX] != 0 && insideCheckMap [counterY][counterX] != 0){
                                            insideCheck [insideCheckMap [counterY][counterX]*2]++;
                                        }
                                        else if (connectivityMapCut [counterY][counterX] == 0 && insideCheckMap [counterY][counterX] != 0){
                                            insideCheck [insideCheckMap [counterY][counterX]*2+1]++;
                                        }
                                        
                                        edgeCheck = 0;
                                        
                                        if (connectivityMapCut [counterY][counterX] != 0){
                                            if (counterY-1 >= 0 && connectivityMapCut [counterY-1][counterX] == 0) edgeCheck++;
                                            if (counterX+1 < dimension && connectivityMapCut [counterY][counterX+1] == 0) edgeCheck++;
                                            if (counterY+1 < dimension && connectivityMapCut [counterY+1][counterX] == 0) edgeCheck++;
                                            if (counterX-1 >= 0 && connectivityMapCut [counterY][counterX-1] == 0) edgeCheck++;
                                            
                                            if (edgeCheck != 0 && revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2] != 0){
                                                insideCheck [revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2]*2+1]++;
                                            }
                                        }
                                    }
                                }
                                
                                insideCheck [valueTemp*2] = 0;
                                
                                insideFind = 0;
                                
                                for (int counter2 = 1; counter2 <= maxConnectNumberList2; counter2++){
                                    if (insideCheck [counter2*2] != 0 && insideCheck [counter2*2+1] == 0) insideFind = 1;
                                    else if (insideCheck [counter2*2] != 0 && insideCheck [counter2*2+1] != 0) insideCheck [counter2*2] = 0;
                                }
                                
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++) internalZeroMap [counterY][counterX] = 0;
                                }
                                
                                if (insideFind == 1){
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (insideCheckMap [counterY][counterX] != 0){
                                                for (int counter2 = 1; counter2 <= maxConnectNumberList2; counter2++){
                                                    if (insideCheck [counter2*2] != 0 && insideCheckMap [counterY][counterX] == counter2){
                                                        internalZeroMap [counterY][counterX] = 1;
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                delete [] insideCheck;
                                
                                for (int counter2 = 0; counter2 < dimension+1; counter2++) delete [] insideCheckMap [counter2];
                                delete [] insideCheckMap;
                                
                                //for (int counterA = 0; counterA < dimension; counterA++){
                                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut [counterA][counterB];
                                //	cout<<" connectivityMapCut "<<counterA<<endl;
                                //}
                                
                                type = 2;
                                [self areaProcess:type:dimension:valueTemp:targetCellStatus:processType];
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                            }
                        }
                        
                        delete [] connectProcessList;
                    }
                    else trackHoldFlag = 3000; //------Fusion or lost------
                    
                    delete [] connectNumber;
                    
                    for (int counter1 = 0; counter1 < positionReviseCurrentCount/7; counter1++){
                        if (arrayPositionReviseCurrent [counter1*7+6] < 0) arrayPositionReviseCurrent [counter1*7+6] = arrayPositionReviseCurrent [counter1*7+6]*-1;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < positionReviseCurrentCount/7; counterA++){
            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionReviseCurrent [counterA*7+counterB];
            //	cout<<" arrayPositionReviseCurrent "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < timeSelectedCurrentCount/10; counterA++){
            //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelectedCurrent [counterA*10+counterB];
            //	cout<<" arrayTimeSelectedCurrent "<<counterA+1<<endl;
            //}
            
            //for (int counterA = 0; counterA < connectLineageRelCurrentCount/6; counterA++){
            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRelCurrent [counterA*6+counterB];
            //	cout<<" arrayConnectLineageRelCurrent "<<counterA+1<<endl;
            //}
            
            //int **sourceImageTest = new int *[trackAreaSize+1]; //=======For check
            
            //for (int counter1 = 0; counter1 < trackAreaSize+1; counter1++){
            //    sourceImageTest [counter1] = new int [trackAreaSize+1];
            //}
            
            //for (int counterY = 0; counterY < trackAreaSize; counterY++){
            //    for (int counterX = 0; counterX < trackAreaSize; counterX++){
            //        sourceImageTest [counterY][counterX] = 0;
            //    }
            //}
            
            //for (int counterY = 0; counterY < imageDimension; counterY++){
            //    for (int counterX = 0; counterX < imageDimension; counterX++){
            //        if (counterY-verticalStart >= 0 && counterY-verticalStart < trackAreaSize && counterX-horizontalStart >= 0 && counterX-horizontalStart < trackAreaSize){
            //            if (revisedWorkingMap [counterY][counterX] != 0){
            //                sourceImageTest [counterY-verticalStart][counterX-horizontalStart] = revisedWorkingMap [counterY][counterX];
            //            }
            //        }
            //    }
            //}
            
            //for (int counterA = 0; counterA < trackAreaSize; counterA++){
            //    for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<sourceImageTest [counterA][counterB];
            //    cout<<" sourceImageTest "<<counterA<<endl;
            //}
            
            //for (int counter1 = 0; counter1 < trackAreaSize+1; counter1++){
            //    delete [] sourceImageTest [counter1];
            //}
            
            //delete [] sourceImageTest;
            
            if (resultsType1 != 0 && fluorescentDetectionDisplay2 == 1){
                if (connectNoCurrTemp != 0){
                    errorNoHold = 57;
                    int *arrayExpandTemp = new int [expandLineFluorescentCurrentCount+50];
                    int expandTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < expandLineFluorescentCurrentCount/4; counter1++){
                        if (expandLineFluorescentCurrent [counter1*4+2] != connectNoCurrTemp){
                            arrayExpandTemp [expandTempCount] = expandLineFluorescentCurrent [counter1*4], expandTempCount++;
                            arrayExpandTemp [expandTempCount] = expandLineFluorescentCurrent [counter1*4+1], expandTempCount++;
                            arrayExpandTemp [expandTempCount] = expandLineFluorescentCurrent [counter1*4+2], expandTempCount++;
                            arrayExpandTemp [expandTempCount] = expandLineFluorescentCurrent [counter1*4+3], expandTempCount++;
                        }
                    }
                    
                    expandLineFluorescentCurrentCount = 0;
                    for (int counter1 = 0; counter1 < expandTempCount; counter1++) expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = arrayExpandTemp [counter1], expandLineFluorescentCurrentCount++;
                    
                    delete [] arrayExpandTemp;
                }
                
                //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
                //    cout<<" arrayConnectLineageRel "<<counterA<<endl;
                //}
                
                if (processType == 1){
                    errorNoHold = 58;
                    int *arrayExpandTemp4 = new int [expandLineFluorescentCurrentCount+50];
                    int expandTempCount4 = 0;
                    
                    for (int counter1 = 0; counter1 < expandLineFluorescentCurrentCount/4; counter1++){
                        if (expandLineFluorescentCurrent [counter1*4+2] != fusionPartnerOriginalConnect){
                            arrayExpandTemp4 [expandTempCount4] = expandLineFluorescentCurrent [counter1*4], expandTempCount4++;
                            arrayExpandTemp4 [expandTempCount4] = expandLineFluorescentCurrent [counter1*4+1], expandTempCount4++;
                            arrayExpandTemp4 [expandTempCount4] = expandLineFluorescentCurrent [counter1*4+2], expandTempCount4++;
                            arrayExpandTemp4 [expandTempCount4] = expandLineFluorescentCurrent [counter1*4+3], expandTempCount4++;
                        }
                    }
                    
                    expandLineFluorescentCurrentCount = 0;
                    for (int counter1 = 0; counter1 < expandTempCount4; counter1++) expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = arrayExpandTemp4 [counter1], expandLineFluorescentCurrentCount++;
                    
                    delete [] arrayExpandTemp4;
                }
                
                //for (int counterA = 0; counterA < expandLineFluorescentDataCount/4; counterA++){
                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandLineFluorescentData [counterA*4+counterB];
                //    cout<<" expandLineFluorescentData "<<counterA<<endl;
                //}
                
                if (connectNoCurrTemp != 0){
                    errorNoHold = 59;
                    int *arrayExpandDataTemp = new int [expandLineFluorescentDataCurrentCount+50];
                    int expandDataTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < expandLineFluorescentDataCurrentCount/4; counter1++){
                        if (expandLineFluorescentDataCurrent [counter1*4] != connectNoCurrTemp){
                            arrayExpandDataTemp [expandDataTempCount] = expandLineFluorescentDataCurrent [counter1*4], expandDataTempCount++;
                            arrayExpandDataTemp [expandDataTempCount] = expandLineFluorescentDataCurrent [counter1*4+1], expandDataTempCount++;
                            arrayExpandDataTemp [expandDataTempCount] = expandLineFluorescentDataCurrent [counter1*4+2], expandDataTempCount++;
                            arrayExpandDataTemp [expandDataTempCount] = expandLineFluorescentDataCurrent [counter1*4+3], expandDataTempCount++;
                        }
                    }
                    
                    expandLineFluorescentDataCurrentCount = 0;
                    for (int counter1 = 0; counter1 < expandDataTempCount; counter1++) expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = arrayExpandDataTemp [counter1], expandLineFluorescentDataCurrentCount++;
                    
                    delete [] arrayExpandDataTemp;
                }
                
                if (processType == 1){
                    errorNoHold = 60;
                    int *arrayExpandDataTemp4 = new int [expandLineFluorescentDataCurrentCount+50];
                    int expandDataTempCount4 = 0;
                    
                    for (int counter1 = 0; counter1 < expandLineFluorescentDataCurrentCount/4; counter1++){
                        if (expandLineFluorescentDataCurrent [counter1*4] != fusionPartnerOriginalConnect){
                            arrayExpandDataTemp4 [expandDataTempCount4] = expandLineFluorescentDataCurrent [counter1*4], expandDataTempCount4++;
                            arrayExpandDataTemp4 [expandDataTempCount4] = expandLineFluorescentDataCurrent [counter1*4+1], expandDataTempCount4++;
                            arrayExpandDataTemp4 [expandDataTempCount4] = expandLineFluorescentDataCurrent [counter1*4+2], expandDataTempCount4++;
                            arrayExpandDataTemp4 [expandDataTempCount4] = expandLineFluorescentDataCurrent [counter1*4+3], expandDataTempCount4++;
                        }
                    }
                    
                    expandLineFluorescentDataCurrentCount = 0;
                    for (int counter1 = 0; counter1 < expandDataTempCount4; counter1++) expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = arrayExpandDataTemp4 [counter1], expandLineFluorescentDataCurrentCount++;
                    
                    delete [] arrayExpandDataTemp4;
                }
                
                merge = [[Merge alloc] init];
                int returnData = [merge lineExtendTrackTypeCurrent2:resultsType1];
                
                do{
                } while (subCompletionFlag2 == 1);
                
                if (errorNoHold != 0){
                    errorNoHold = errorNoHold+2000;
                    throw errorCheckThrow;
                }
                
                if ((fluorescentDetectionDisplay2 == 1 && autoExpand == 0) || (fluorescentDetectionDisplay2 == 1 && autoExpand == 1 && returnData == 1)){
                    for (int counter1 = 0; counter1 < positionReviseCurrentCount/7; counter1++){
                        if (arrayPositionReviseCurrent [counter1*7+3] == resultsType1){
                            if (expandLineFluorescentCurrentCount+20 > expandLineFluorescentCurrentLimit){
                                [self expandLineFluorescentCurrentUpDate];
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                            }
                            
                            expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = arrayPositionReviseCurrent [counter1*7], expandLineFluorescentCurrentCount++;
                            expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = arrayPositionReviseCurrent [counter1*7+1], expandLineFluorescentCurrentCount++;
                            expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = resultsType1, expandLineFluorescentCurrentCount++;
                            expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = 1, expandLineFluorescentCurrentCount++;
                        }
                    }
                    
                    if (fluorescentEntryCount >= 2){
                        for (int counter1 = 0; counter1 < positionReviseCurrentCount/7; counter1++){
                            if (arrayPositionReviseCurrent [counter1*7+3] == resultsType1){
                                if (expandLineFluorescentCurrentCount+20 > expandLineFluorescentCurrentLimit){
                                    [self expandLineFluorescentCurrentUpDate];
                                    if (errorNoHold != 0){
                                        errorNoHold = errorNoHold+2000;
                                        throw errorCheckThrow;
                                    }
                                }
                                
                                expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = arrayPositionReviseCurrent [counter1*7], expandLineFluorescentCurrentCount++;
                                expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = arrayPositionReviseCurrent [counter1*7+1], expandLineFluorescentCurrentCount++;
                                expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = resultsType1, expandLineFluorescentCurrentCount++;
                                expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = 2, expandLineFluorescentCurrentCount++;
                            }
                        }
                    }
                    
                    if (fluorescentEntryCount >= 3){
                        for (int counter1 = 0; counter1 < positionReviseCurrentCount/7; counter1++){
                            if (arrayPositionReviseCurrent [counter1*7+3] == resultsType1){
                                if (expandLineFluorescentCurrentCount+20 > expandLineFluorescentCurrentLimit){
                                    [self expandLineFluorescentCurrentUpDate];
                                    if (errorNoHold != 0){
                                        errorNoHold = errorNoHold+2000;
                                        throw errorCheckThrow;
                                    }
                                }
                                
                                expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = arrayPositionReviseCurrent [counter1*7], expandLineFluorescentCurrentCount++;
                                expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = arrayPositionReviseCurrent [counter1*7+1], expandLineFluorescentCurrentCount++;
                                expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = resultsType1, expandLineFluorescentCurrentCount++;
                                expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = 3, expandLineFluorescentCurrentCount++;
                            }
                        }
                    }
                    
                    if (fluorescentEntryCount >= 4){
                        for (int counter1 = 0; counter1 < positionReviseCurrentCount/7; counter1++){
                            if (arrayPositionReviseCurrent [counter1*7+3] == resultsType1){
                                if (expandLineFluorescentCurrentCount+20 > expandLineFluorescentCurrentLimit){
                                    [self expandLineFluorescentCurrentUpDate];
                                    if (errorNoHold != 0){
                                        errorNoHold = errorNoHold+2000;
                                        throw errorCheckThrow;
                                    }
                                }
                                
                                expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = arrayPositionReviseCurrent [counter1*7], expandLineFluorescentCurrentCount++;
                                expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = arrayPositionReviseCurrent [counter1*7+1], expandLineFluorescentCurrentCount++;
                                expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = resultsType1, expandLineFluorescentCurrentCount++;
                                expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = 4, expandLineFluorescentCurrentCount++;
                            }
                        }
                    }
                    
                    if (fluorescentEntryCount >= 5){
                        for (int counter1 = 0; counter1 < positionReviseCurrentCount/7; counter1++){
                            if (arrayPositionReviseCurrent [counter1*7+3] == resultsType1){
                                if (expandLineFluorescentCurrentCount+20 > expandLineFluorescentCurrentLimit){
                                    [self expandLineFluorescentCurrentUpDate];
                                    if (errorNoHold != 0){
                                        errorNoHold = errorNoHold+2000;
                                        throw errorCheckThrow;
                                    }
                                }
                                
                                expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = arrayPositionReviseCurrent [counter1*7], expandLineFluorescentCurrentCount++;
                                expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = arrayPositionReviseCurrent [counter1*7+1], expandLineFluorescentCurrentCount++;
                                expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = resultsType1, expandLineFluorescentCurrentCount++;
                                expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = 5, expandLineFluorescentCurrentCount++;
                            }
                        }
                    }
                    
                    if (fluorescentEntryCount >= 6){
                        for (int counter1 = 0; counter1 < positionReviseCurrentCount/7; counter1++){
                            if (arrayPositionReviseCurrent [counter1*7+3] == resultsType1){
                                if (expandLineFluorescentCurrentCount+20 > expandLineFluorescentCurrentLimit){
                                    [self expandLineFluorescentCurrentUpDate];
                                    if (errorNoHold != 0){
                                        errorNoHold = errorNoHold+2000;
                                        throw errorCheckThrow;
                                    }
                                }
                                
                                expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = arrayPositionReviseCurrent [counter1*7], expandLineFluorescentCurrentCount++;
                                expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = arrayPositionReviseCurrent [counter1*7+1], expandLineFluorescentCurrentCount++;
                                expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = resultsType1, expandLineFluorescentCurrentCount++;
                                expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = 6, expandLineFluorescentCurrentCount++;
                            }
                        }
                    }
                    
                    int pixelValueTemp = 0;
                    int pixelAreaTemp = 0;
                    int pixelValueTemp2 = 0;
                    int pixelAreaTemp2 = 0;
                    int pixelValueTemp3 = 0;
                    int pixelAreaTemp3 = 0;
                    int pixelValueTemp4 = 0;
                    int pixelAreaTemp4 = 0;
                    int pixelValueTemp5 = 0;
                    int pixelAreaTemp5 = 0;
                    int pixelValueTemp6 = 0;
                    int pixelAreaTemp6 = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                                if (revisedMapCurrent [counterX+horizontalStart2][counterX+horizontalStart2] == resultsType1){
                                    if (fluorescentEntryCount >= 1){
                                        if (fluorescentCutOffCurrent1 >= fluorescentMapCurrent1 [counterX+horizontalStart2][counterX+horizontalStart2]) pixelValueTemp = pixelValueTemp+fluorescentMapCurrent1 [counterX+horizontalStart2][counterX+horizontalStart2];
                                        pixelAreaTemp++;
                                    }
                                    if (fluorescentEntryCount >= 2){
                                        if (fluorescentCutOffCurrent2 >= fluorescentMapCurrent2 [counterX+horizontalStart2][counterX+horizontalStart2]) pixelValueTemp2 = pixelValueTemp2+fluorescentMapCurrent2 [counterX+horizontalStart2][counterX+horizontalStart2];
                                        pixelAreaTemp2++;
                                    }
                                    if (fluorescentEntryCount >= 3){
                                        if (fluorescentCutOffCurrent3 >= fluorescentMapCurrent3 [counterX+horizontalStart2][counterX+horizontalStart2]) pixelValueTemp3 = pixelValueTemp3+fluorescentMapCurrent3 [counterX+horizontalStart2][counterX+horizontalStart2];
                                        pixelAreaTemp3++;
                                    }
                                    if (fluorescentEntryCount >= 4){
                                        if (fluorescentCutOffCurrent4 >= fluorescentMapCurrent4 [counterX+horizontalStart2][counterX+horizontalStart2]) pixelValueTemp4 = pixelValueTemp4+fluorescentMapCurrent4 [counterX+horizontalStart2][counterX+horizontalStart2];
                                        pixelAreaTemp4++;
                                    }
                                    if (fluorescentEntryCount >= 5){
                                        if (fluorescentCutOffCurrent5 >= fluorescentMapCurrent5 [counterX+horizontalStart2][counterX+horizontalStart2]) pixelValueTemp5 = pixelValueTemp5+fluorescentMapCurrent5 [counterX+horizontalStart2][counterX+horizontalStart2];
                                        pixelAreaTemp5++;
                                    }
                                    if (fluorescentEntryCount >= 6){
                                        if (fluorescentCutOffCurrent6 >= fluorescentMapCurrent6 [counterX+horizontalStart2][counterX+horizontalStart2]) pixelValueTemp6 = pixelValueTemp6+fluorescentMapCurrent6 [counterX+horizontalStart2][counterX+horizontalStart2];
                                        pixelAreaTemp6++;
                                    }
                                }
                            }
                        }
                    }
                    
                    double averageArea = pixelValueTemp/(double)pixelAreaTemp;
                    
                    if (expandLineFluorescentDataCurrentCount+20 > expandLineFluorescentDataCurrentLimit){
                        [self expandLineFluorescentDataCurrentUpDate];
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                    }
                    
                    expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = resultsType1, expandLineFluorescentDataCurrentCount++;
                    expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = 1, expandLineFluorescentDataCurrentCount++;
                    expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = (int)averageArea, expandLineFluorescentDataCurrentCount++;
                    expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = pixelAreaTemp, expandLineFluorescentDataCurrentCount++;
                    
                    if (fluorescentEntryCount >= 2){
                        averageArea = pixelValueTemp2/(double)pixelAreaTemp2;
                        
                        expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = resultsType1, expandLineFluorescentDataCurrentCount++;
                        expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = 2, expandLineFluorescentDataCurrentCount++;
                        expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = (int)averageArea, expandLineFluorescentDataCurrentCount++;
                        expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = pixelAreaTemp2, expandLineFluorescentDataCurrentCount++;
                    }
                    
                    if (fluorescentEntryCount >= 3){
                        averageArea = pixelValueTemp3/(double)pixelAreaTemp3;
                        
                        expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = resultsType1, expandLineFluorescentDataCurrentCount++;
                        expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = 3, expandLineFluorescentDataCurrentCount++;
                        expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = (int)averageArea, expandLineFluorescentDataCurrentCount++;
                        expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = pixelAreaTemp3, expandLineFluorescentDataCurrentCount++;
                    }
                    
                    if (fluorescentEntryCount >= 4){
                        averageArea = pixelValueTemp4/(double)pixelAreaTemp4;
                        
                        expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = resultsType1, expandLineFluorescentDataCurrentCount++;
                        expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = 4, expandLineFluorescentDataCurrentCount++;
                        expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = (int)averageArea, expandLineFluorescentDataCurrentCount++;
                        expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = pixelAreaTemp4, expandLineFluorescentDataCurrentCount++;
                    }
                    
                    if (fluorescentEntryCount >= 5){
                        averageArea = pixelValueTemp5/(double)pixelAreaTemp5;
                        
                        expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = resultsType1, expandLineFluorescentDataCurrentCount++;
                        expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = 5, expandLineFluorescentDataCurrentCount++;
                        expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = (int)averageArea, expandLineFluorescentDataCurrentCount++;
                        expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = pixelAreaTemp5, expandLineFluorescentDataCurrentCount++;
                    }
                    
                    if (fluorescentEntryCount >= 6){
                        averageArea = pixelValueTemp6/(double)pixelAreaTemp6;
                        
                        expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = resultsType1, expandLineFluorescentDataCurrentCount++;
                        expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = 6, expandLineFluorescentDataCurrentCount++;
                        expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = (int)averageArea, expandLineFluorescentDataCurrentCount++;
                        expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = pixelAreaTemp6, expandLineFluorescentDataCurrentCount++;
                    }
                }
            }
            
            delete [] connectAnalysisX;
            delete [] connectAnalysisY;
            delete [] connectAnalysisTempX;
            delete [] connectAnalysisTempY;
            
            for (int counter1 = 0; counter1 < dimension+4; counter1++){
                delete [] rangeMatrix [counter1];
            }
            
            delete [] rangeMatrix;
            
            errorNoHold = 0;
            subCompletionFlag = 0;
        }
        catch (int errorCheckThrow){
            if (errorNoHold == 0) errorNoHold = 1000;
            
            subCompletionFlag = 0;
        }
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingAreaCutCurrent01 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"AreaCutCurrent-circleCut"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
        
        subCompletionFlag = 0;
    }
    
    return resultsType1;
}

-(int)areaProcess:(int)type :(int)dimension :(int)valueTemp :(int)targetCellStatus :(int)processType{
    int results = 0;
    
    try{
        try{
            
            errorNoHold = 0;
            int errorCheckThrow = 0;
            
            int lineEntryNumber = 1;
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut [counterA][counterB];
            //    cout<<" connectivityMapCut "<<counterA<<endl;
            //}
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapCut [counterY][counterX] != 0) connectivityMapCut [counterY][counterX] = connectivityMapCut [counterY][counterX]*-1;
                }
            }
            
            errorNoHold = 61;
            int *connectAnalysisX = new int [dimension*4];
            errorNoHold = 62;
            int *connectAnalysisY = new int [dimension*4];
            errorNoHold = 63;
            int *connectAnalysisTempX = new int [dimension*4];
            errorNoHold = 64;
            int *connectAnalysisTempY = new int [dimension*4];
            
            int connectivityNumber = 0;
            int connectAnalysisCount = 0;
            int terminationFlag = 1;
            int connectAnalysisTempCount = 0;
            int xSource = 0;
            int ySource = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapCut [counterY][counterX] < 0){
                        connectivityNumber++;
                        connectivityMapCut [counterY][counterX] = connectivityNumber;
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapCut [counterY-1][counterX-1] < 0){
                            connectivityMapCut [counterY-1][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && connectivityMapCut [counterY-1][counterX] < 0){
                            connectivityMapCut [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMapCut [counterY-1][counterX+1] < 0){
                            connectivityMapCut [counterY-1][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && connectivityMapCut [counterY][counterX+1] < 0){
                            connectivityMapCut [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && counterX+1 < dimension && connectivityMapCut [counterY+1][counterX+1] < 0){
                            connectivityMapCut [counterY+1][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && connectivityMapCut [counterY+1][counterX] < 0){
                            connectivityMapCut [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMapCut [counterY+1][counterX-1] < 0){
                            connectivityMapCut [counterY+1][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && connectivityMapCut [counterY][counterX-1] < 0){
                            connectivityMapCut [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && xSource-1 >= 0 && connectivityMapCut [ySource-1][xSource-1] < 0){
                                        connectivityMapCut [ySource-1][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && connectivityMapCut [ySource-1][xSource] < 0){
                                        connectivityMapCut [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && xSource+1 < dimension && connectivityMapCut [ySource-1][xSource+1] < 0){
                                        connectivityMapCut [ySource-1][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && connectivityMapCut [ySource][xSource+1] < 0){
                                        connectivityMapCut [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 > dimension && xSource+1 < dimension && connectivityMapCut [ySource+1][xSource+1] < 0){
                                        connectivityMapCut [ySource+1][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && connectivityMapCut [ySource+1][xSource] < 0){
                                        connectivityMapCut [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && xSource-1 >= 0 && connectivityMapCut [ySource+1][xSource-1] < 0){
                                        connectivityMapCut [ySource+1][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMapCut [ySource][xSource-1] < 0){
                                        connectivityMapCut [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //------Determine number of pixels------
            errorNoHold = 65;
            int *connectedPixels = new int [connectivityNumber+50];
            
            for (int counter1 = 0; counter1 < connectivityNumber+50; counter1++) connectedPixels [counter1] = 0;
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapCut [counterY][counterX] != 0) connectedPixels [connectivityMapCut [counterY][counterX]]++;
                }
            }
            
            //------Map up-date------
            int connectTemp = 1;
            
            for (int counter1 = 1; counter1 <= connectivityNumber; counter1++){
                if (connectedPixels [counter1] < 10) connectedPixels [counter1] = 0;
                else{
                    
                    connectedPixels [counter1] = connectTemp;
                    connectTemp++;
                }
            }
            
            delete [] connectedPixels;
            
            int maxConnectivityNumber = 0;
            int newConnectLineNo = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapCut [counterY][counterX] > maxConnectivityNumber) maxConnectivityNumber = connectivityMapCut [counterY][counterX];
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut [counterA][counterB];
            //    cout<<" connectivityMapCut "<<counterA<<endl;
            //}
            
            errorNoHold = 66;
            int **outlineMap = new int *[dimension+1];
            errorNoHold = 67;
            int **outlineMap2 = new int *[dimension+1];
            errorNoHold = 68;
            int **outlineMap3 = new int *[dimension+1];
            
            for (int counter1 = 0; counter1 < dimension+1; counter1++){
                errorNoHold = 69;
                outlineMap [counter1] = new int [dimension+1];
                errorNoHold = 70;
                outlineMap2 [counter1] = new int [dimension+1];
                errorNoHold = 71;
                outlineMap3 [counter1] = new int [dimension+1];
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++) outlineMap3 [counterY][counterX] = 0;
            }
            
            errorNoHold = 72;
            int *outlineDataSet = new int [1000];
            int outlineDataSetCount = 0;
            int outlineDataSetLimit = 1000;
            int terminationFlag3 = 0;
            int largestConnect = 0;
            int largestConnectNo = 0;
            int xPositionTempStart = 0;
            int yPositionTempStart = 0;
            int lineSize = 0;
            int constructedLineCount = 0;
            int findFlag = 0;
            int terminationFlag2 = 0;
            
            for (int counter1 = 1; counter1 <= maxConnectivityNumber; counter1++){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapCut [counterY][counterX] == counter1) outlineMap [counterY][counterX] = 1;
                        else outlineMap [counterY][counterX] = 0;
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<outlineMap [counterA][counterB];
                //    cout<<" outlineMap "<<counterA<<endl;
                //}
                
                do{
                    
                    terminationFlag3 = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (outlineMap [counterY][counterX] != 0){
                                if (counterX+1 < dimension && outlineMap [counterY][counterX+1] == 0) outlineMap [counterY][counterX] = -1;
                                else if (counterY+1 < dimension && outlineMap [counterY+1][counterX] == 0) outlineMap [counterY][counterX] = -1;
                                else if (counterX-1 >= 0 && outlineMap [counterY][counterX-1] == 0) outlineMap [counterY][counterX] = -1;
                                else if (counterY-1 >= 0 && outlineMap [counterY-1][counterX] == 0) outlineMap [counterY][counterX] = -1;
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (outlineMap [counterY][counterX] > 0) outlineMap [counterY][counterX] = 0;
                            if (outlineMap [counterY][counterX] < 0) outlineMap [counterY][counterX] = 1;
                        }
                    }
                    
                    connectivityNumber = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (outlineMap [counterY2][counterX2] == 0){
                                connectivityNumber--;
                                connectAnalysisCount = 0;
                                
                                outlineMap [counterY2][counterX2] = connectivityNumber;
                                
                                if (counterY2-1 >= 0 && outlineMap [counterY2-1][counterX2] == 0){
                                    outlineMap [counterY2-1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                }
                                if (counterX2+1 < dimension && outlineMap [counterY2][counterX2+1] == 0){
                                    outlineMap [counterY2][counterX2+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                if (counterY2+1 < dimension && outlineMap [counterY2+1][counterX2] == 0){
                                    outlineMap [counterY2+1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                }
                                if (counterX2-1 >= 0 && outlineMap [counterY2][counterX2-1] == 0){
                                    outlineMap [counterY2][counterX2-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                            xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                            
                                            if (ySource-1 >= 0 && outlineMap [ySource-1][xSource] == 0){
                                                outlineMap [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && outlineMap [ySource][xSource+1] == 0){
                                                outlineMap [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && outlineMap [ySource+1][xSource] == 0){
                                                outlineMap [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && outlineMap [ySource][xSource-1] == 0){
                                                outlineMap [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                            connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    //------Determine number of pixels------
                    connectivityNumber = connectivityNumber*-1;
                    
                    errorNoHold = 73;
                    int *connectedPixels2 = new int [connectivityNumber+50];
                    
                    for (int counter2 = 0; counter2 < connectivityNumber+50; counter2++) connectedPixels2 [counter2] = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (outlineMap [counterY2][counterX2] < -1){
                                connectedPixels2 [outlineMap [counterY2][counterX2]*-1]++;
                            }
                        }
                    }
                    
                    largestConnect = 0;
                    largestConnectNo = 0;
                    
                    for (int counter2 = 2; counter2 <= connectivityNumber; counter2++){
                        if (connectedPixels2 [counter2] > largestConnect){
                            largestConnect = connectedPixels2 [counter2];
                            largestConnectNo = counter2;
                        }
                    }
                    
                    delete [] connectedPixels2;
                    
                    if (largestConnectNo == 0 || largestConnect < 20) terminationFlag3 = 1;
                    else{
                        
                        errorNoHold = 74;
                        int **newConnectivityMapTemp = new int *[dimension+4];
                        for (int counter2 = 0; counter2 < dimension+4; counter2++){
                            errorNoHold = 75;
                            newConnectivityMapTemp [counter2] = new int [dimension+4];
                        }
                        
                        for (int counterY = 0; counterY < dimension+4; counterY++){
                            for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
                        }
                        
                        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                if (outlineMap [counterY2][counterX2] == largestConnectNo*-1){
                                    if (counterY2-1 >= 0 && counterX2-1 >= 0 && outlineMap [counterY2-1][counterX2-1] == 1){
                                        newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                                        outlineMap [counterY2-1][counterX2-1] = 0;
                                    }
                                    if (counterY2-1 >= 0 && outlineMap [counterY2-1][counterX2] == 1){
                                        newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                                        outlineMap [counterY2-1][counterX2] = 0;
                                    }
                                    if (counterY2-1 >= 0 && counterX2+1 < dimension && outlineMap [counterY2-1][counterX2+1] == 1){
                                        newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                                        outlineMap [counterY2-1][counterX2+1] = 0;
                                    }
                                    if (counterX2+1 < dimension && outlineMap [counterY2][counterX2+1] == 1){
                                        newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                                        outlineMap [counterY2][counterX2+1] = 0;
                                    }
                                    if (counterY2+1 < dimension && counterX2+1 < dimension && outlineMap [counterY2+1][counterX2+1] == 1){
                                        newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                                        outlineMap [counterY2+1][counterX2+1] = 0;
                                    }
                                    if (counterY2+1 < dimension && outlineMap [counterY2+1][counterX2] == 1){
                                        newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                                        outlineMap [counterY2+1][counterX2] = 0;
                                    }
                                    if (counterY2+1 < dimension && counterX2-1 >= 0 && outlineMap [counterY2+1][counterX2-1] == 1){
                                        newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                                        outlineMap [counterY2+1][counterX2-1] = 0;
                                    }
                                    if (counterX2-1 >= 0 && outlineMap [counterY2][counterX2-1] == 1){
                                        newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                                        outlineMap [counterY2][counterX2-1] = 0;
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<newConnectivityMapTemp [counterA][counterB];
                        //    cout<<" newConnectivityMapTemp "<<counterA<<endl;
                        //}
                        
                        xPositionTempStart = 0;
                        yPositionTempStart = 0;
                        lineSize = 0;
                        
                        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension; counterX2++) outlineMap2 [counterY2][counterX2] = 0;
                        }
                        
                        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                                    outlineMap2 [counterY2][counterX2] = 1;
                                    
                                    xPositionTempStart = counterX2;
                                    yPositionTempStart = counterY2;
                                    lineSize++;
                                }
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < dimension+4; counter2++) delete [] newConnectivityMapTemp [counter2];
                        delete [] newConnectivityMapTemp;
                        
                        constructedLineCount = 0;
                        
                        errorNoHold = 76;
                        int *arrayNewLines = new int [lineSize*2+50];
                        
                        outlineMap2 [yPositionTempStart][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                        
                        do{
                            
                            findFlag = 0;
                            terminationFlag2 = 0;
                            
                            if (xPositionTempStart+1 < dimension){
                                if (outlineMap2 [yPositionTempStart][xPositionTempStart+1] == 1){
                                    outlineMap2 [yPositionTempStart][xPositionTempStart+1] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                    xPositionTempStart = xPositionTempStart+1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                                    outlineMap2 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                    xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (yPositionTempStart+1 < dimension && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart+1][xPositionTempStart] == 1){
                                    outlineMap2 [yPositionTempStart+1][xPositionTempStart] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                    yPositionTempStart = yPositionTempStart+1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                                    outlineMap2 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                    xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (xPositionTempStart-1 >= 0 && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart][xPositionTempStart-1] == 1){
                                    outlineMap2 [yPositionTempStart][xPositionTempStart-1] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                    xPositionTempStart = xPositionTempStart-1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                                    outlineMap2 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                    xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (yPositionTempStart-1 >= 0 && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart-1][xPositionTempStart] == 1){
                                    outlineMap2 [yPositionTempStart-1][xPositionTempStart] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                    yPositionTempStart = yPositionTempStart-1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                                    outlineMap2 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                    xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag2 = 1;
                                }
                            }
                            
                        } while (terminationFlag2 == 1);
                        
                        //===========
                        //int aa = arrayNewLines [0];
                        //int bb = arrayNewLines [1];
                        
                        //int cc = arrayNewLines [(constructedLineCount/2-1)*2];
                        //int dd = arrayNewLines [(constructedLineCount/2-1)*2+1];
                        
                        //int findLink = 0;
                        
                        //if (cc-1 == aa && dd-1 == bb) findLink = 1;
                        //else  if (cc == aa && dd-1 == bb) findLink = 1;
                        //else  if (cc+1 == aa && dd-1 == bb) findLink = 1;
                        //else  if (cc+1 == aa && dd == bb) findLink = 1;
                        //else  if (cc+1 == aa && dd+1 == bb) findLink = 1;
                        //else  if (cc == aa && dd+1 == bb) findLink = 1;
                        //else  if (cc-1 == aa && dd+1 == bb) findLink = 1;
                        //else  if (cc-1 == aa && dd == bb) findLink = 1;
                        
                        //if (findLink == 0){
                        //    for (int counterA = 0; counterA < dimension; counterA++){
                        //        for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<outlineMap2 [counterA][counterB];
                        //        cout<<" outlineMap2 "<<counterA<<endl;
                        //    }
                        //}
                        //==========
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3A [counterA][counterB];
                        //    cout<<" previousMap3A "<<counterA<<endl;
                        //}
                        
                        newConnectLineNo++;
                        
                        for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                            if (outlineDataSetCount+3 > outlineDataSetLimit){
                                errorNoHold = 77;
                                int *arrayUpDate = new int [outlineDataSetCount+10];
                                
                                for (int counter3 = 0; counter3 < outlineDataSetCount; counter3++) arrayUpDate [counter3] = outlineDataSet [counter3];
                                
                                delete [] outlineDataSet;
                                errorNoHold = 78;
                                outlineDataSet = new int [outlineDataSetLimit+5000];
                                outlineDataSetLimit = outlineDataSetLimit+5000;
                                
                                for (int counter3 = 0; counter3 < outlineDataSetCount; counter3++) outlineDataSet [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            outlineDataSet [outlineDataSetCount] = newConnectLineNo, outlineDataSetCount++; //------Vector no------
                            outlineDataSet [outlineDataSetCount] = arrayNewLines [counter2*2], outlineDataSetCount++; //------X position------
                            outlineDataSet [outlineDataSetCount] = arrayNewLines [counter2*2+1], outlineDataSetCount++; //------Y position------
                        }
                        
                        delete [] arrayNewLines;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (outlineMap2 [counterY][counterX] == -1) outlineMap2 [counterY][counterX] = outlineMap2 [counterY][counterX]*-1;
                            }
                        }
                        
                        connectivityNumber = -3;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (outlineMap2 [counterY][counterX] == 0){
                                    connectivityNumber = connectivityNumber+2;
                                    outlineMap2 [counterY][counterX] = connectivityNumber;
                                    
                                    connectAnalysisCount = 0;
                                    
                                    if (counterY-1 >= 0 && outlineMap2 [counterY-1][counterX] == 0){
                                        outlineMap2 [counterY-1][counterX] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                    }
                                    if (counterX+1 < dimension && outlineMap2 [counterY][counterX+1] == 0){
                                        outlineMap2 [counterY][counterX+1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    if (counterY+1 < dimension && outlineMap2 [counterY+1][counterX] == 0){
                                        outlineMap2 [counterY+1][counterX] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                    }
                                    if (counterX-1 >= 0 && outlineMap2 [counterY][counterX-1] == 0){
                                        outlineMap2 [counterY][counterX-1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    
                                    if (connectAnalysisCount != 0){
                                        do{
                                            
                                            terminationFlag = 1;
                                            connectAnalysisTempCount = 0;
                                            
                                            for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                
                                                if (ySource-1 >= 0 && outlineMap2 [ySource-1][xSource] == 0){
                                                    outlineMap2 [ySource-1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (xSource+1 < dimension && outlineMap2 [ySource][xSource+1] == 0){
                                                    outlineMap2 [ySource][xSource+1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 < dimension && outlineMap2 [ySource+1][xSource] == 0){
                                                    outlineMap2 [ySource+1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (xSource-1 >= 0 && outlineMap2 [ySource][xSource-1] == 0){
                                                    outlineMap2 [ySource][xSource-1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                            }
                                            
                                            for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                            }
                                            
                                            connectAnalysisCount = connectAnalysisTempCount;
                                            
                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                    }
                                }
                            }
                        }
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (outlineMap2 [counterY][counterX] == -1) outlineMap2 [counterY][counterX] = 0;
                                else outlineMap2 [counterY][counterX] = newConnectLineNo;
                            }
                        }
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (outlineMap2 [counterY][counterX] != 0){
                                    outlineMap [counterY][counterX] = 0;
                                    outlineMap3 [counterY][counterX] = outlineMap2 [counterY][counterX];
                                }
                                
                                if (outlineMap [counterY][counterX] != 0) outlineMap [counterY][counterX] = 0;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<outlineMap3 [counterA][counterB];
                        //    cout<<" outlineMap3 "<<counterA<<endl;
                        //}
                    }
                    
                } while (terminationFlag3 == 0);
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++) connectivityMapCut [counterY][counterX] = outlineMap3 [counterY][counterX];
            }
            
            for (int counter1 = 0; counter1 < dimension+1; counter1++){
                delete [] outlineMap [counter1];
                delete [] outlineMap2 [counter1];
                delete [] outlineMap3 [counter1];
            }
            
            delete [] outlineMap;
            delete [] outlineMap2;
            delete [] outlineMap3;
            
            //------Determine number of pixels------
            errorNoHold = 79;
            connectedPixels = new int [newConnectLineNo+50];
            
            for (int counter1 = 0; counter1 < newConnectLineNo+50; counter1++) connectedPixels [counter1] = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapCut [counterY][counterX] != 0) connectedPixels [connectivityMapCut [counterY][counterX]]++;
                }
            }
            
            //------Map up-date------
            errorNoHold = 80;
            int *pixNumberRef = new int [newConnectLineNo+2];
            
            for (int counter1 = 0; counter1 < newConnectLineNo+2; counter1++) pixNumberRef [counter1] = 0;
            
            int largestTargetConnect = 0;
            int targetEntryConnectNo = 0;
            
            for (int counter1 = 1; counter1 < newConnectLineNo+1; counter1++){
                if (connectedPixels [counter1] > largestTargetConnect){
                    largestTargetConnect = connectedPixels [counter1];
                    targetEntryConnectNo = counter1;
                }
            }
            
            delete [] connectAnalysisX;
            delete [] connectAnalysisY;
            delete [] connectAnalysisTempX;
            delete [] connectAnalysisTempY;
            
            if (type == 1 && newConnectLineNo == 0) trackHoldFlag = 3000; //-----Lost Check------
            else{
                
                results = 1;
                
                string cellLineageExtract = cellLineageNoHold.substr(1);
                int lineageAmendTemp = atoi(cellLineageExtract.c_str());
                string cellNoExtract = cellNoHold.substr(1);
                int cellAmendTemp = atoi(cellNoExtract.c_str());
                
                if (processType == 1){
                    lineageAmendTemp = fusionPartnerLine;
                    cellAmendTemp = fusionPartnerCellNo;
                }
                
                if (newConnectLineNo == 0 && type == 2){
                    errorNoHold = 81;
                    int *arrayTimeOneTemp = new int [positionReviseCurrentCount+50];
                    int timeOneTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < positionReviseCurrentCount/7; counter1++){
                        if (arrayPositionReviseCurrent [counter1*7+3] == valueTemp){
                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter1*7], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter1*7+1], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter1*7+2], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter1*7+3], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter1*7+4], timeOneTempCount++;
                            
                            if (arrayPositionReviseCurrent [counter1*7+5] == 0) arrayTimeOneTemp [timeOneTempCount] = 2, timeOneTempCount++;
                            else if (arrayPositionReviseCurrent [counter1*7+5] == 1) arrayTimeOneTemp [timeOneTempCount] = 3, timeOneTempCount++;
                            else arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter1*7+5], timeOneTempCount++;
                            
                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter1*7+6], timeOneTempCount++;
                        }
                        else{
                            
                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter1*7], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter1*7+1], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter1*7+2], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter1*7+3], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter1*7+4], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter1*7+5], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter1*7+6], timeOneTempCount++;
                        }
                    }
                    
                    positionReviseCurrentCount = 0;
                    for (int counter1 = 0; counter1 < timeOneTempCount; counter1++) arrayPositionReviseCurrent [positionReviseCurrentCount] = arrayTimeOneTemp [counter1], positionReviseCurrentCount++;
                    delete [] arrayTimeOneTemp;
                    
                    errorNoHold = 82;
                    arrayTimeOneTemp = new int [timeSelectedCurrentCount+50];
                    timeOneTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < timeSelectedCurrentCount/10; counter1++){
                        if (counter1+1 == valueTemp && arrayTimeSelectedCurrent [counter1*10] != 3 && arrayTimeSelectedCurrent [counter1*10] != 4){
                            if (arrayTimeSelectedCurrent [counter1*10] == 0) arrayTimeOneTemp [timeOneTempCount] = 3, timeOneTempCount++;
                            else if (arrayTimeSelectedCurrent [counter1*10] == 1 || arrayTimeSelectedCurrent [counter1*10] == 7 || arrayTimeSelectedCurrent [counter1*10] == 2) arrayTimeOneTemp [timeOneTempCount] = 4, timeOneTempCount++;
                            
                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter1*10+1], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter1*10+2], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = lineEntryNumber, timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter1*10+4], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter1*10+5], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter1*10+6], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter1*10+7], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter1*10+8], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter1*10+9], timeOneTempCount++;
                        }
                        else{
                            
                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter1*10], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter1*10+1], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter1*10+2], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter1*10+3], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter1*10+4], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter1*10+5], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter1*10+6], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter1*10+7], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter1*10+8], timeOneTempCount++;
                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter1*10+9], timeOneTempCount++;
                        }
                    }
                    
                    timeSelectedCurrentCount = 0;
                    
                    for (int counter1 = 0; counter1 < timeOneTempCount; counter1++) arrayTimeSelectedCurrent [timeSelectedCurrentCount] = arrayTimeOneTemp [counter1],timeSelectedCurrentCount++;
                    delete [] arrayTimeOneTemp;
                    
                    //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                    //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                    //	cout<<" arrayTimeSelected "<<counterA+1<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < positionReviseCurrentCount/7; counter1++){
                        if (arrayPositionReviseCurrent [counter1*7+6] == lineageAmendTemp && arrayPositionReviseCurrent [counter1*7+4] == cellAmendTemp){
                            arrayPositionReviseCurrent [counter1*7+6] = 0;
                            arrayPositionReviseCurrent [counter1*7+4] = -1;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
                    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
                    //	cout<<" arrayPositionRevise "<<counterA<<endl;
                    //}
                    
                    for (int counterY = 0; counterY < imageDimension; counterY++){
                        for (int counterX = 0; counterX < imageDimension; counterX++){
                            if (revisedMapCurrent [counterY][counterX] == valueTemp) revisedMapCurrent [counterY][counterX] = 0;
                        }
                    }
                }
                if (newConnectLineNo > 0){
                    int currentStatus = 0;
                    int entryCount = 0;
                    int gravityCenter1 [4];
                    int maxVectorNumber = arrayGravityCenterRevCurrent [(gravityCenterRevCurrentCount/6-1)*6+4];
                    int xGravityImageTemp = 0;
                    int yGravityImageTemp = 0;
                    int gravityX1 = 0;
                    int gravityY1 = 0;
                    int totalGravityCount = 0;
                    int averageIntensity = 0;
                    int timeOneTempCount = 0;
                    int lastConnectPosition = 0;
                    int connectLineageRelTempCount = 0;
                    
                    //for (int counter1 = 1; counter1 < maxConnectivityNumber+1; counter1++) cout<<counter1<<" "<<connectedPixels [counter1]<<" PixNo2"<<endl;
                    
                    for (int counter1 = 1; counter1 < newConnectLineNo+1; counter1++){
                        if (connectedPixels [counter1] != 0){
                            gravityCenter1 [0] = 0;
                            gravityCenter1 [1] = 0;
                            gravityCenter1 [2] = 0;
                            gravityCenter1 [3] = 0;
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (connectivityMapCut [counterY][counterX] == counter1){
                                        gravityCenter1 [0] = gravityCenter1 [0]+counterX;
                                        gravityCenter1 [1] = gravityCenter1 [1]+counterY;
                                        gravityCenter1 [2]++;
                                        
                                        xGravityImageTemp = counterX+horizontalStart2;
                                        yGravityImageTemp = counterY+verticalStart2;
                                        
                                        if (xGravityImageTemp > imageDimension) xGravityImageTemp = imageDimension-1;
                                        if (xGravityImageTemp < 0) xGravityImageTemp = 0;
                                        if (yGravityImageTemp > imageDimension) yGravityImageTemp = imageDimension-1;
                                        if (yGravityImageTemp < 0) yGravityImageTemp = 0;
                                        
                                        gravityCenter1 [3] = gravityCenter1 [3]+sourceImage [mapPositionPointer][yGravityImageTemp*imageDimension+xGravityImageTemp];
                                    }
                                }
                            }
                            
                            averageIntensity = (int)(gravityCenter1 [3]/(double)gravityCenter1 [2]);
                            
                            // cout<<gravityX1<<" "<<gravityY1<<" "<<averageIntensity<<" "<<entryCount<<" "<<type<<" GravityCenter"<<endl;
                            
                            //------First Connect Get and Set required data------
                            if (entryCount == 0){
                                entryCount = 1;
                                
                                if (type == 2){
                                    errorNoHold = 83;
                                    int *arrayTimeOneTemp = new int [timeSelectedCurrentCount+50];
                                    timeOneTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < timeSelectedCurrentCount/10; counter2++){
                                        if (counter2+1 == valueTemp && arrayTimeSelectedCurrent [counter2*10] != 3 && arrayTimeSelectedCurrent [counter2*10] != 4){
                                            if (arrayTimeSelectedCurrent [counter2*10] == 0) arrayTimeOneTemp [timeOneTempCount] = 3, timeOneTempCount++;
                                            else if (arrayTimeSelectedCurrent [counter2*10] == 1 || arrayTimeSelectedCurrent [counter2*10] == 7 || arrayTimeSelectedCurrent [counter2*10] == 2) arrayTimeOneTemp [timeOneTempCount] = 4, timeOneTempCount++;
                                            
                                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter2*10+1], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter2*10+2], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = lineEntryNumber, timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter2*10+4], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter2*10+5], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter2*10+6], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter2*10+7], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter2*10+8], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter2*10+9], timeOneTempCount++;
                                        }
                                        else{
                                            
                                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter2*10], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter2*10+1], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter2*10+2], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter2*10+3], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter2*10+4], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter2*10+5], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter2*10+6], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter2*10+7], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter2*10+8], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelectedCurrent [counter2*10+9], timeOneTempCount++;
                                        }
                                    }
                                    
                                    timeSelectedCurrentCount = 0;
                                    for (int counter2 = 0; counter2 < timeOneTempCount; counter2++) arrayTimeSelectedCurrent [timeSelectedCurrentCount] = arrayTimeOneTemp [counter2], timeSelectedCurrentCount++;
                                    delete [] arrayTimeOneTemp;
                                    
                                    errorNoHold = 84;
                                    arrayTimeOneTemp = new int [positionReviseCurrentCount+50];
                                    timeOneTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < positionReviseCurrentCount/7; counter2++){
                                        if (arrayPositionReviseCurrent [counter2*7+3] == valueTemp){
                                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter2*7], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter2*7+1], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter2*7+2], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter2*7+3], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter2*7+4], timeOneTempCount++;
                                            
                                            if (currentStatus == 0) currentStatus = arrayPositionReviseCurrent [counter2*7+5];
                                            
                                            if (currentStatus == 0) arrayTimeOneTemp [timeOneTempCount] = 2, timeOneTempCount++;
                                            else if (currentStatus == 1) arrayTimeOneTemp [timeOneTempCount] = 3, timeOneTempCount++;
                                            else arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter2*7+5], timeOneTempCount++;
                                            
                                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter2*7+6], timeOneTempCount++;
                                        }
                                        else{
                                            
                                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter2*7], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter2*7+1], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter2*7+2], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter2*7+3], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter2*7+4], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter2*7+5], timeOneTempCount++;
                                            arrayTimeOneTemp [timeOneTempCount] = arrayPositionReviseCurrent [counter2*7+6], timeOneTempCount++;
                                        }
                                    }
                                    
                                    positionReviseCurrentCount = 0;
                                    for (int counter2 = 0; counter2 < timeOneTempCount; counter2++) arrayPositionReviseCurrent [positionReviseCurrentCount] = arrayTimeOneTemp [counter2], positionReviseCurrentCount++;
                                    delete [] arrayTimeOneTemp;
                                    
                                    for (int counterY = 0; counterY < imageDimension; counterY++){
                                        for (int counterX = 0; counterX < imageDimension; counterX++){
                                            if (revisedMapCurrent [counterY][counterX] == valueTemp) revisedMapCurrent [counterY][counterX] = 0;
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < positionReviseCurrentCount/7; counter2++){
                                        if (arrayPositionReviseCurrent [counter2*7+6] == lineageAmendTemp && arrayPositionReviseCurrent [counter2*7+4] == cellAmendTemp){
                                            arrayPositionReviseCurrent [counter2*7+6] = 0;
                                            arrayPositionReviseCurrent [counter2*7+4] = -1;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < positionReviseCurrentCount/7; counterA++){
                                    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionReviseCurrent [counterA*7+counterB];
                                    //	cout<<" arrayPositionReviseCurrent "<<counterA<<endl;
                                    //}
                                }
                            }
                            
                            //------Process Connect pixels------
                            maxVectorNumber++;
                            pixNumberRef [counter1] = maxVectorNumber;
                            
                            if (type == 1 && counter1 == targetEntryConnectNo) results = maxVectorNumber; //----Return Vect No to process Fluorescent-------
                            
                            if (positionReviseCurrentCount+outlineDataSetCount*3 > positionReviseCurrentLimit){
                                positionReviseCurrentAddition = outlineDataSetCount*3;
                                [self positionRevSelectedCurrUpDate];
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                            }
                            
                            lastConnectPosition = positionReviseCurrentCount/7;
                            
                            for (int counter2 = 0; counter2 < outlineDataSetCount/3; counter2++){
                                if (outlineDataSet [counter2*3] == counter1){
                                    arrayPositionReviseCurrent [positionReviseCurrentCount] = outlineDataSet [counter2*3+1]+horizontalStart2, positionReviseCurrentCount++;
                                    arrayPositionReviseCurrent [positionReviseCurrentCount] = outlineDataSet [counter2*3+2]+verticalStart2, positionReviseCurrentCount++;
                                    
                                    if (outlineDataSet [counter2*3+2]+verticalStart2 >= 0 && outlineDataSet [counter2*3+2]+verticalStart2 < imageDimension && outlineDataSet [counter2*3+1]+horizontalStart2 >= 0 && outlineDataSet [counter2*3+1]+horizontalStart2 < imageDimension){
                                        arrayPositionReviseCurrent [positionReviseCurrentCount] = sourceImage [mapPositionPointer][(outlineDataSet [counter2*3+2]+verticalStart2)*imageDimension+outlineDataSet [counter2*3+1]+horizontalStart2], positionReviseCurrentCount++;
                                    }
                                    else arrayPositionReviseCurrent [positionReviseCurrentCount] = 100, positionReviseCurrentCount++;
                                    
                                    arrayPositionReviseCurrent [positionReviseCurrentCount] = maxVectorNumber, positionReviseCurrentCount++;
                                    arrayPositionReviseCurrent [positionReviseCurrentCount] = 0, positionReviseCurrentCount++;
                                    arrayPositionReviseCurrent [positionReviseCurrentCount] = 0, positionReviseCurrentCount++;
                                    arrayPositionReviseCurrent [positionReviseCurrentCount] = 0, positionReviseCurrentCount++;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
                            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
                            //	cout<<" arrayPositionRevise "<<counterA<<endl;
                            //}
                            
                            if (type == 2){
                                gravityX1 = 0;
                                gravityY1 = 0;
                                totalGravityCount = 0;
                                
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++){
                                        if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension && connectivityMapCut [counterY][counterX] == counter1 && targetMap [counterY][counterX] == 0 && internalZeroMap [counterY][counterX] == 0){
                                            revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2] = maxVectorNumber;
                                            
                                            gravityX1 = gravityX1+counterX+horizontalStart2;
                                            gravityY1 = gravityY1+counterY+verticalStart2;
                                            totalGravityCount++;
                                        }
                                    }
                                }
                                
                                gravityX1 = (int)(gravityX1/(double)totalGravityCount);
                                gravityY1 = (int)(gravityY1/(double)totalGravityCount);
                            }
                            else{
                                
                                gravityX1 = 0;
                                gravityY1 = 0;
                                totalGravityCount = 0;
                                
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++){
                                        if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension && connectivityMapCut [counterY][counterX] == counter1 && internalZeroMap [counterY][counterX] == 0){
                                            gravityX1 = gravityX1+counterX+horizontalStart2;
                                            gravityY1 = gravityY1+counterY+verticalStart2;
                                            totalGravityCount++;
                                        }
                                    }
                                }
                                
                                gravityX1 = (int)(gravityX1/(double)totalGravityCount);
                                gravityY1 = (int)(gravityY1/(double)totalGravityCount);
                            }
                            
                            //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
                            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionReviseCurrent [counterA*7+counterB];
                            //	cout<<" arrayPositionReviseCurrent "<<counterA<<endl;
                            //}
                            
                            if (type == 1 && counter1 == targetEntryConnectNo && processType != 3){
                                for (int counter2 = 0; counter2 < positionReviseCurrentCount/7; counter2++){
                                    if (arrayPositionReviseCurrent [counter2*7+3] == maxVectorNumber){
                                        arrayPositionReviseCurrent [counter2*7+6] = lineageAmendTemp*-1;
                                        arrayPositionReviseCurrent [counter2*7+5] = 1;
                                        arrayPositionReviseCurrent [counter2*7+4] = cellAmendTemp;
                                    }
                                }
                                
                                if (gravityCenterEntryType == 1){
                                    gravityCenterXCurrentHold1 = gravityX1;
                                    gravityCenterYCurrentHold1 = gravityY1;
                                    gravityAverageCurrentHold1 = averageIntensity;
                                    gravityCellNoCurrent1 = cellAmendTemp;
                                }
                                else if (gravityCenterEntryType == 2){
                                    gravityCenterXCurrentHold2 = gravityX1;
                                    gravityCenterYCurrentHold2 = gravityY1;
                                    gravityAverageCurrentHold2 = averageIntensity;
                                    gravityCellNoCurrent2 = cellAmendTemp;
                                }
                                else if (gravityCenterEntryType == 3){
                                    gravityCenterXCurrentHold3 = gravityX1;
                                    gravityCenterYCurrentHold3 = gravityY1;
                                    gravityAverageCurrentHold3 = averageIntensity;
                                    gravityCellNoCurrent3 = cellAmendTemp;
                                }
                                else if (gravityCenterEntryType == 4){
                                    gravityCenterXCurrentHold4 = gravityX1;
                                    gravityCenterYCurrentHold4 = gravityY1;
                                    gravityAverageCurrentHold4 = averageIntensity;
                                    gravityCellNoCurrent4 = cellAmendTemp;
                                }
                            }
                            
                            if (gravityCenterRevCurrentCount+6 > gravityCenterRevCurrentLimit){
                                [self gravityCenterRevCurrentUpDate];
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                            }
                            
                            arrayGravityCenterRevCurrent [gravityCenterRevCurrentCount] = gravityX1, gravityCenterRevCurrentCount++;
                            arrayGravityCenterRevCurrent [gravityCenterRevCurrentCount] = gravityY1, gravityCenterRevCurrentCount++;
                            arrayGravityCenterRevCurrent [gravityCenterRevCurrentCount] = gravityCenter1 [2], gravityCenterRevCurrentCount++;
                            arrayGravityCenterRevCurrent [gravityCenterRevCurrentCount] = averageIntensity, gravityCenterRevCurrentCount++;
                            arrayGravityCenterRevCurrent [gravityCenterRevCurrentCount] = maxVectorNumber, gravityCenterRevCurrentCount++;
                            arrayGravityCenterRevCurrent [gravityCenterRevCurrentCount] = 0, gravityCenterRevCurrentCount++;
                            
                            if (associatedDataCurrCount+1 > associatedDataCurrLimit){
                                [self associateDataCurrUpDate];
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                            }
                            
                            arrayAssociatedDataCurr [associatedDataCurrCount] = maxVectorNumber, associatedDataCurrCount++;
                            arrayAssociatedDataCurr [associatedDataCurrCount] = 0, associatedDataCurrCount++;
                            arrayAssociatedDataCurr [associatedDataCurrCount] = 0, associatedDataCurrCount++;
                            arrayAssociatedDataCurr [associatedDataCurrCount] = 0, associatedDataCurrCount++;
                            arrayAssociatedDataCurr [associatedDataCurrCount] = 0, associatedDataCurrCount++;
                            arrayAssociatedDataCurr [associatedDataCurrCount] = 0, associatedDataCurrCount++;
                            
                            if (timeSelectedCurrentCount+10 > timeSelectedCurrentLimit){
                                [self timeSelectedCurrentUpDate];
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                            }
                            
                            if (type == 1 && counter1 == targetEntryConnectNo && targetCellStatus != 2000 && processType != 3) arrayTimeSelectedCurrent [timeSelectedCurrentCount] = 1, timeSelectedCurrentCount++;
                            else if (type == 1 && counter1 == targetEntryConnectNo && targetCellStatus == 2000 && processType != 3) arrayTimeSelectedCurrent [timeSelectedCurrentCount] = 7, timeSelectedCurrentCount++;
                            else arrayTimeSelectedCurrent [timeSelectedCurrentCount] = 0, timeSelectedCurrentCount++;
                            
                            arrayTimeSelectedCurrent [timeSelectedCurrentCount] = lineEntryNumber, timeSelectedCurrentCount++;
                            arrayTimeSelectedCurrent [timeSelectedCurrentCount] = lastConnectPosition, timeSelectedCurrentCount++;
                            arrayTimeSelectedCurrent [timeSelectedCurrentCount] = 0, timeSelectedCurrentCount++;
                            arrayTimeSelectedCurrent [timeSelectedCurrentCount] = 0, timeSelectedCurrentCount++;
                            arrayTimeSelectedCurrent [timeSelectedCurrentCount] = 0, timeSelectedCurrentCount++;
                            arrayTimeSelectedCurrent [timeSelectedCurrentCount] = 0, timeSelectedCurrentCount++;
                            arrayTimeSelectedCurrent [timeSelectedCurrentCount] = 0, timeSelectedCurrentCount++;
                            arrayTimeSelectedCurrent [timeSelectedCurrentCount] = maxVectorNumber, timeSelectedCurrentCount++;
                            
                            if (type == 1 && counter1 == targetEntryConnectNo && processType != 3) arrayTimeSelectedCurrent [timeSelectedCurrentCount] = lineageAmendTemp, timeSelectedCurrentCount++;
                            else arrayTimeSelectedCurrent [timeSelectedCurrentCount] = 0, timeSelectedCurrentCount++;
                            
                            //for (int counterA = 0; counterA < timeSelectedCurrentCount/10; counterA++){
                            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelectedCurrent [counterA*10+counterB];
                            //    cout<<" arrayTimeSelectedCurrent "<<counterA<<endl;
                            //}
                            
                            if (type == 1 && counter1 == targetEntryConnectNo && processType != 3){
                                //========= 1. Lineage No, 2. connect No, 3. image number, 4. cell no, 5. target (0: non-target, 1: target), 6. reserve=========
                                
                                if (connectLineageRelCurrentCount+6 > connectLineageRelCurrentLimit){
                                    [self connectLineageRelCurrentUpDate];
                                    if (errorNoHold != 0){
                                        errorNoHold = errorNoHold+2000;
                                        throw errorCheckThrow;
                                    }
                                }
                                
                                if (connectLineageRelCurrentCount == 0){
                                    arrayConnectLineageRelCurrent [connectLineageRelCurrentCount] = lineageAmendTemp, connectLineageRelCurrentCount++;
                                    arrayConnectLineageRelCurrent [connectLineageRelCurrentCount] = timeSelectedCurrentCount/10, connectLineageRelCurrentCount++;
                                    arrayConnectLineageRelCurrent [connectLineageRelCurrentCount] = imageNumberInt, connectLineageRelCurrentCount++;
                                    arrayConnectLineageRelCurrent [connectLineageRelCurrentCount] = cellAmendTemp, connectLineageRelCurrentCount++;
                                    arrayConnectLineageRelCurrent [connectLineageRelCurrentCount] = 1, connectLineageRelCurrentCount++;
                                    arrayConnectLineageRelCurrent [connectLineageRelCurrentCount] = 0, connectLineageRelCurrentCount++;
                                }
                                else if (connectLineageRelCurrentCount > 0){
                                    errorNoHold = 85;
                                    int *arrayConnectLineageRelTemp = new int [connectLineageRelCurrentCount+50];
                                    connectLineageRelTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < connectLineageRelCurrentCount/6; counter2++){
                                        if (arrayConnectLineageRelCurrent [counter2*6] != lineageAmendTemp || arrayConnectLineageRelCurrent [counter2*6+3] != cellAmendTemp){
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRelCurrent [counter2*6], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRelCurrent [counter2*6+1], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRelCurrent [counter2*6+2], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRelCurrent [counter2*6+3], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = 0, connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRelCurrent [counter2*6+5], connectLineageRelTempCount++;
                                        }
                                    }
                                    
                                    arrayConnectLineageRelTemp [connectLineageRelTempCount] = lineageAmendTemp, connectLineageRelTempCount++;
                                    arrayConnectLineageRelTemp [connectLineageRelTempCount] = timeSelectedCurrentCount/10, connectLineageRelTempCount++;
                                    arrayConnectLineageRelTemp [connectLineageRelTempCount] = imageNumberInt, connectLineageRelTempCount++;
                                    arrayConnectLineageRelTemp [connectLineageRelTempCount] = cellAmendTemp, connectLineageRelTempCount++;
                                    arrayConnectLineageRelTemp [connectLineageRelTempCount] = 1, connectLineageRelTempCount++;
                                    arrayConnectLineageRelTemp [connectLineageRelTempCount] = 0, connectLineageRelTempCount++;
                                    
                                    connectLineageRelCurrentCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < connectLineageRelTempCount; counter2++) arrayConnectLineageRelCurrent [connectLineageRelCurrentCount] = arrayConnectLineageRelTemp [counter2], connectLineageRelCurrentCount++;
                                    
                                    delete [] arrayConnectLineageRelTemp;
                                    
                                    errorNoHold = 86;
                                    arrayConnectLineageRelTemp = new int [connectLineageRelCurrentCount+50];
                                    connectLineageRelTempCount = 0;
                                    
                                    for (int counter2 = 1; counter2 < maxVectorNumber+1; counter2++){
                                        for (int counter3 = 0; counter3 < connectLineageRelCurrentCount/6; counter3++){
                                            if (arrayConnectLineageRelCurrent [counter3*6+1] == counter2){
                                                arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRelCurrent [counter3*6], connectLineageRelTempCount++;
                                                arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRelCurrent [counter3*6+1], connectLineageRelTempCount++;
                                                arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRelCurrent [counter3*6+2], connectLineageRelTempCount++;
                                                arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRelCurrent [counter3*6+3], connectLineageRelTempCount++;
                                                arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRelCurrent [counter3*6+4], connectLineageRelTempCount++;
                                                arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRelCurrent [counter3*6+5], connectLineageRelTempCount++;
                                            }
                                        }
                                    }
                                    
                                    connectLineageRelCurrentCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < connectLineageRelTempCount; counter2++) arrayConnectLineageRelCurrent [connectLineageRelCurrentCount] = arrayConnectLineageRelTemp [counter2], connectLineageRelCurrentCount++;
                                    
                                    delete [] arrayConnectLineageRelTemp;
                                    
                                    //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
                                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
                                    //	cout<<" ConnectLineageRel "<<counterA+1<<" "<<counter1<<endl;
                                    //}
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < positionReviseCurrentCount/7; counterA++){
                    //    if (arrayPositionReviseCurrent [counterA*7+3] == 2675){
                    //        for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionReviseCurrent [counterA*7+counterB];
                    //        cout<<" arrayPositionReviseCurrent "<<counterA<<endl;
                    //    }
                    //}
                    
                    if (type == 1){
                        errorNoHold = 87;
                        int **mapTemp = new int *[dimension+1];
                        for (int counter1 = 0; counter1 < dimension+1; counter1++){
                            errorNoHold = 88;
                            mapTemp [counter1] = new int [dimension+1];
                        }
                        
                        for (int counterY = 0; counterY < dimension+1; counterY++){
                            for (int counterX = 0; counterX < dimension+1; counterX++) mapTemp [counterY][counterX] = 0;
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut [counterA][counterB];
                        //    cout<<" connectivityMapCut "<<counterA<<endl;
                        //}
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (connectivityMapCut [counterY][counterX] != 0){
                                    mapTemp [counterY][counterX] = pixNumberRef [connectivityMapCut [counterY][counterX]];
                                }
                            }
                        }
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                connectivityMapCut [counterY][counterX] = 0;
                                connectivityMapCut [counterY][counterX] = mapTemp [counterY][counterX];
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut [counterA][counterB];
                        //    cout<<" connectivityMapCut "<<counterA<<endl;
                        //}
                        
                        for (int counter1 = 0; counter1 < dimension+1; counter1++) delete [] mapTemp [counter1];
                        delete [] mapTemp;
                    }
                }
            }
            
            delete [] pixNumberRef;
            delete [] outlineDataSet;
            delete [] connectedPixels;
            
            errorNoHold = 0;
        }
        catch (int errorCheckThrow){
            if (errorNoHold == 0) errorNoHold = 1000;
        }
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingAreaCutCurrent02 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"AreaCutCurrent-areaProcess"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
    }
    
    return results;
}

-(void)positionRevSelectedCurrUpDate{
    try{
        
        errorNoHold = 0;
        
        int *arrayUpDate = new int [positionReviseCurrentCount+10];
        
        for (int counter1 = 0; counter1 < positionReviseCurrentCount; counter1++) arrayUpDate [counter1] = arrayPositionReviseCurrent [counter1];
        
        delete [] arrayPositionReviseCurrent;
        arrayPositionReviseCurrent = new int [positionReviseCurrentLimit*3+positionReviseCurrentAddition+5000];
        positionReviseCurrentLimit = positionReviseCurrentLimit*3+positionReviseCurrentAddition+5000;
        
        for (int counter1 = 0; counter1 < positionReviseCurrentCount; counter1++) arrayPositionReviseCurrent [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
        
        positionReviseCurrentSizeHold = positionReviseCurrentLimit*3+positionReviseCurrentAddition+5000;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingAreaCutCurrent03 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"AreaCutCurrent-positionRevSelectedCurrUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

-(void)gravityCenterRevCurrentUpDate{
    try{
        
        errorNoHold = 0;
        
        int *arrayUpDate = new int [gravityCenterRevCurrentCount+10];
        
        for (int counter1 = 0; counter1 < gravityCenterRevCurrentCount; counter1++) arrayUpDate [counter1] = arrayGravityCenterRevCurrent [counter1];
        
        delete [] arrayGravityCenterRevCurrent;
        arrayGravityCenterRevCurrent = new int [gravityCenterRevCurrentLimit*3+2000];
        gravityCenterRevCurrentLimit = gravityCenterRevCurrentLimit*3+2000;
        
        for (int counter1 = 0; counter1 < gravityCenterRevCurrentCount; counter1++) arrayGravityCenterRevCurrent [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
        
        gravityCenterRevCurrentCount = gravityCenterRevLimit*3+2000;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingAreaCutCurrent04 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"AreaCutCurrent-gravityCenterRevCurrentUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

-(void)timeSelectedCurrentUpDate{
    try{
        
        errorNoHold = 0;
        
        int *arrayUpDate = new int [timeSelectedCurrentCount+10];
        
        for (int counter1 = 0; counter1 < timeSelectedCurrentCount; counter1++) arrayUpDate [counter1] = arrayTimeSelectedCurrent [counter1];
        
        delete [] arrayTimeSelectedCurrent;
        arrayTimeSelectedCurrent = new int [timeSelectedCurrentLimit*3+2000];
        timeSelectedCurrentLimit = timeSelectedCurrentLimit*3+2000;
        
        for (int counter1 = 0; counter1 < timeSelectedCurrentCount; counter1++) arrayTimeSelectedCurrent [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
        
        timeSelectedCurrentSizeHold = timeSelectedCurrentLimit*3+2000;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingAreaCutCurrent05 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"AreaCutCurrent-timeSelectedCurrentUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

-(void)connectLineageRelCurrentUpDate{
    try{
        
        errorNoHold = 0;
        
        int *arrayUpDate = new int [connectLineageRelCurrentCount+10];
        
        for (int counter1 = 0; counter1 < connectLineageRelCurrentCount; counter1++) arrayUpDate [counter1] = arrayConnectLineageRelCurrent [counter1];
        
        delete [] arrayConnectLineageRelCurrent;
        arrayConnectLineageRelCurrent = new int [connectLineageRelCurrentLimit*3+500];
        connectLineageRelCurrentLimit = connectLineageRelCurrentLimit*3+500;
        
        for (int counter1 = 0; counter1 < connectLineageRelCurrentCount; counter1++) arrayConnectLineageRelCurrent [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
        
        connectLineageRelCurrentSizeHold = connectLineageRelCurrentLimit*3+500;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingAreaCutCurrent06 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"AreaCutCurrent-connectLineageRelCurrentUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

-(void)associateDataCurrUpDate{
    try{
        
        errorNoHold = 0;
        
        int *arrayUpDate = new int [associatedDataCurrCount+10];
        
        for (int counter1 = 0; counter1 < associatedDataCurrCount; counter1++) arrayUpDate [counter1] = arrayAssociatedDataCurr [counter1];
        
        delete [] arrayAssociatedDataCurr;
        arrayAssociatedDataCurr = new int [associatedDataCurrLimit*3+2000];
        associatedDataCurrLimit = associatedDataCurrLimit*3+2000;
        
        for (int counter1 = 0; counter1 < associatedDataCurrCount; counter1++) arrayAssociatedDataCurr [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
        
        associatedDataCurrSizeHold = associatedDataCurrLimit*3+2000;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingAreaCutCurrent07 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"AreaCutCurrent-associateDataCurrUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

-(void)expandLineFluorescentCurrentUpDate{
    try{
        
        errorNoHold = 0;
        
        int *arrayUpDate = new int [expandLineFluorescentCurrentCount+10];
        
        for (int counter1 = 0; counter1 < expandLineFluorescentCurrentCount; counter1++) arrayUpDate [counter1] = expandLineFluorescentCurrent [counter1];
        
        delete [] expandLineFluorescentCurrent;
        expandLineFluorescentCurrent = new int [expandLineFluorescentCurrentLimit*4+10000];
        expandLineFluorescentCurrentLimit = expandLineFluorescentCurrentLimit*4+10000;
        
        for (int counter1 = 0; counter1 < expandLineFluorescentCurrentCount; counter1++) expandLineFluorescentCurrent [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
        
        expandLineFluorescentCurrentSizeHold = expandLineFluorescentCurrentLimit*4+10000;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingAreaCutCurrent08 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"AreaCutCurrent-expandLineFluorescentCurrentUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

-(void)expandLineFluorescentDataCurrentUpDate{
    try{
        
        errorNoHold = 0;
        
        int *arrayUpDate = new int [expandLineFluorescentDataCurrentCount+10];
        
        for (int counter1 = 0; counter1 < expandLineFluorescentDataCurrentCount; counter1++) arrayUpDate [counter1] = expandLineFluorescentDataCurrent [counter1];
        
        delete [] expandLineFluorescentDataCurrent;
        expandLineFluorescentDataCurrent = new int [expandLineFluorescentDataCurrentLimit*4+10000];
        expandLineFluorescentDataCurrentLimit = expandLineFluorescentDataCurrentLimit*4+10000;
        
        for (int counter1 = 0; counter1 < expandLineFluorescentDataCurrentCount; counter1++) expandLineFluorescentDataCurrent [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
        
        expandLineFluorescentDataCurrentSizeHold = expandLineFluorescentDataCurrentLimit*4+10000;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingAreaCutCurrent09 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"AreaCutCurrent-expandLineFluorescentDataCurrentUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

@end
