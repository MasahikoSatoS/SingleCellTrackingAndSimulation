//
//  TerminationMonitor.m
//  Cell_Carving
//
//  Created by Masahiko Sato on 2014-05-26.
//
//

#import "TerminationMonitor.h"

NSString *notificationToTermination = @"notoficationExecuteTermination";

@implementation TerminationMonitor

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToTermination object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    commTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(processControl) userInfo:nil repeats:YES];
}

-(void)processControl{
    NSString *activeProcess;
    
    int mainControllerActive = 1;
    
    for (NSRunningApplication *currApp in [[NSWorkspace sharedWorkspace] runningApplications]){
        activeProcess = [currApp localizedName];
        
        if ([activeProcess isEqualToString:@"Cell_Tracking"]) mainControllerActive = 2;
    }
    
    if (mainControllerActive == 1){
        if (positionReviseStatus == 1) delete [] arrayPositionRevise;
        if (gravityCenterRevStatus == 1) delete [] arrayGravityCenterRev;
        if (associatedDataStatus == 1) delete [] arrayAssociatedData;
        if (timeSelectedStatus == 1) delete [] arrayTimeSelected;
        if (connectLineageRelStatus == 1) delete [] arrayConnectLineageRel;
        if (eventSequenceStatus == 1) delete [] arrayEventSequence;
        if (mapLoadingStatusPrev == 1){
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                delete [] revisedMap [counter1];
                delete [] revisedWorkingMap [counter1];
            }
            
            delete [] revisedMap;
            delete [] revisedWorkingMap;
        }
        
        if (mainMapLoadStatus == 1){
            for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                delete [] connectMap200 [counter1];
                delete [] connectMap220 [counter1];
                delete [] connectMap240 [counter1];
                delete [] connectMapA [counter1];
                delete [] connectMapB [counter1];
                delete [] connectMapC [counter1];
                delete [] connectMapD [counter1];
                delete [] sourceImage [counter1];
            }
            
            delete [] connectMap200;
            delete [] connectMap220;
            delete [] connectMap240;
            delete [] connectMapA;
            delete [] connectMapB;
            delete [] connectMapC;
            delete [] connectMapD;
            delete [] sourceImage;
        }
        
        if (cellTrackingPreviousStatus == 1) delete [] arrayCellTrackingPrevious;
        if (xyPositionCenterPreviousStatus == 1) delete [] arrayXYPositionCenterPrevious;
        if (cellTrackingPreviousAssStatus == 1) delete [] arrayCellTrackingPreviousAss;
        if (sectionMapLoadingStatusPrev == 1){
            for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++) delete [] arrayCellTrackingPreviousMap [counter1];
            delete [] arrayCellTrackingPreviousMap;
        }
        
        if (positionReviseCurrentStatus == 1) delete [] arrayPositionReviseCurrent;
        if (gravityCenterRevCurrentStatus == 1) delete [] arrayGravityCenterRevCurrent;
        if (associatedDataCurrStatus == 1) delete [] arrayAssociatedDataCurr;
        if (timeSelectedCurrentStatus == 1) delete [] arrayTimeSelectedCurrent;
        if (connectLineageRelCurrentStatus == 1) delete [] arrayConnectLineageRelCurrent;
        if (mapLoadingStatus == 1){
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] revisedMapCurrent [counter1];
            delete [] revisedMapCurrent;
        }
        
        if (cellTrackingCurrentStatus == 1) delete [] arrayCellTrackingCurrent;
        if (xyPositionCenterCurrentStatus == 1) delete [] arrayXYPositionCenterCurrent;
        if (cellTrackingCurrentAssStatus == 1) delete [] arrayCellTrackingCurrentAss;
        
        if (sectionMapLoadingStatus == 1){
            for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++) delete [] arrayCellTrackingCurrentMap [counter1];
            delete [] arrayCellTrackingCurrentMap;
        }
        
        if (groupInfoPreviousStatus == 1) delete [] arrayGroupInfoPrevious;
        if (groupInfoCurrentStatus == 1) delete [] arrayGroupInfoCurrent;
        if (cellTrackingTableStatus == 1) delete [] arrayCellTrackingTable;
        if (cellTrackingRelStatus == 1) delete [] arrayCellTrackingRel;
        if (displayDataStatus == 1) delete [] arrayDisplayData;
        if (displayRelStatus == 1) delete [] arrayDisplayRel;
        if (displayGravityCenterStatus == 1) delete [] arrayDisplayGravityCenter;
        if (cellAttachStatus == 1) delete [] arrayAttachTable;
        if (fusionPartnerStatus == 1) delete [] arrayFusionPartner;
        if (mitosisPatternStatus == 1) delete [] arrayMitosisPattern;
        if (lineageStartEndStatus == 1) delete [] arrayLineageStartEnd;
        if (lineageDataStatus == 1) delete [] arrayLineageData;
        
        delete [] arrayIFDataHold;
        delete [] arrayTreatmentStatus;
        delete [] imageNoHoldMain;
        delete [] arrayFileHandling;
        
        if (fluorescentCutOffStatus == 1) delete [] arrayFluorescentCutOff;
        if (mitosisParameterStatus == 1) delete [] arrayMitosisParameter;
        
        if (putativeMapStatus == 1){
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] putativeMap [counter1];
            delete [] putativeMap;
        }
        
        if (connectivityMapCutStatus == 1){
            for (int counter1 = 0; counter1 < connectivityMapCutSizeHold+1; counter1++) delete [] connectivityMapCut [counter1];
            delete [] connectivityMapCut;
        }
        
        if (internalZeroMapStatus == 1){
            for (int counter1 = 0; counter1 < internalZeroMapSizeHold+1; counter1++) delete [] internalZeroMap [counter1];
            delete [] internalZeroMap;
        }
        
        if (targetMapStatus == 1){
            for (int counter1 = 0; counter1 < targetMapSizeHold+1; counter1++) delete [] targetMap [counter1];
            delete [] targetMap;
        }
        
        exit (0);
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToTermination object:nil];
    if (commTimer) [commTimer invalidate];
}

@end
