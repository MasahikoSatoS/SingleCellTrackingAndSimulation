//
// TrackingSetCurrent.mm
// Cell_Carving
//
// Created by Masahiko Sato on 15/12/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "TrackingSetCurrent.h"

@implementation TrackingSetCurrent

-(void)trackingSetCurrentMain:(int)processTime{
    try{
        try{
            
            errorNoHold = 0;
            int errorCheckThrow = 0;
            sleepingPosition = 11;
            subCompletionFlag = 1;
            
            struct stat sizeOfFile;
            
            if (processTime == 1){
                ifstream fin;
                string extension = to_string(imageNumberInt+1);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                string connectDataPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+extension+"_"+analysisImageName+"_"+treatmentNameHold+"_MasterData";
                string connectDataRevPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                
                long sizeForCopy = 0;
                long sizeForCopy2 = 0;
                long size1 = 0;
                long size2 = 0;
                int checkFlag = 0;
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    sizeForCopy = 0;
                    
                    if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    else if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter1 == 0) size1 = sizeForCopy;
                        else if (counter1 == 1) size2 = sizeForCopy;
                        else if (counter1 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter1 == 3) size1 = sizeForCopy;
                        else if (counter1 == 4) size2 = sizeForCopy;
                        else if (counter1 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                if (checkFlag == 0){
                    errorNoHold = 1000;
                    throw errorCheckThrow;
                }
                
                positionReviseCurrentCount = 0;
                gravityCenterRevCurrentCount = 0;
                associatedDataCurrCount = 0;
                
                if (checkFlag == 1){
                    if (positionReviseCurrentStatus == 0){
                        errorNoHold = 1;
                        arrayPositionReviseCurrent = new int [sizeForCopy+50];
                        positionReviseCurrentCount = 0;
                        positionReviseCurrentStatus = 1;
                        positionReviseCurrentLimit = (int)sizeForCopy+50;
                        positionReviseCurrentSizeHold = (int)sizeForCopy+50;
                    }
                    else if (positionReviseCurrentStatus == 1 && positionReviseCurrentSizeHold < sizeForCopy){
                        delete [] arrayPositionReviseCurrent;
                        
                        errorNoHold = 2;
                        arrayPositionReviseCurrent = new int [sizeForCopy+50];
                        positionReviseCurrentCount = 0;
                        positionReviseCurrentLimit = (int)sizeForCopy+50;
                        positionReviseCurrentSizeHold = (int)sizeForCopy+50;
                    }
                    else positionReviseCurrentCount = 0;
                    
                    sizeForCopy2 = (long)(sizeForCopy*(double)0.1+50);
                    
                    if (gravityCenterRevCurrentStatus == 0){
                        errorNoHold = 3;
                        arrayGravityCenterRevCurrent = new int [sizeForCopy2+50];
                        gravityCenterRevCurrentCount = 0;
                        gravityCenterRevCurrentStatus = 1;
                        gravityCenterRevCurrentLimit = (int)sizeForCopy2+50;
                        gravityCenterRevCurrentSizeHold = (int)sizeForCopy2+50;
                    }
                    else if (gravityCenterRevCurrentStatus == 1 && gravityCenterRevCurrentSizeHold < sizeForCopy2){
                        delete [] arrayGravityCenterRevCurrent;
                        
                        errorNoHold = 4;
                        arrayGravityCenterRevCurrent = new int [sizeForCopy2+50];
                        gravityCenterRevCurrentCount = 0;
                        gravityCenterRevCurrentLimit = (int)sizeForCopy2+50;
                        gravityCenterRevCurrentSizeHold = (int)sizeForCopy2+50;
                    }
                    else gravityCenterRevCurrentCount = 0;
                    
                    if (associatedDataCurrStatus == 0){
                        errorNoHold = 5;
                        arrayAssociatedDataCurr = new int [sizeForCopy2+50];
                        associatedDataCurrCount = 0;
                        associatedDataCurrStatus = 1;
                        associatedDataCurrLimit = (int)sizeForCopy2+50;
                        associatedDataCurrSizeHold = (int)sizeForCopy2+50;
                    }
                    else if (associatedDataCurrStatus == 1 && associatedDataCurrSizeHold < sizeForCopy2){
                        delete [] arrayAssociatedDataCurr;
                        
                        errorNoHold = 6;
                        arrayAssociatedDataCurr = new int [sizeForCopy2+50];
                        associatedDataCurrCount = 0;
                        associatedDataCurrLimit = (int)sizeForCopy2+50;
                        associatedDataCurrSizeHold = (int)sizeForCopy2+50;
                    }
                    else associatedDataCurrCount = 0;
                    
                    //------Master Data upLoad------
                    fin.open(connectDataRevPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        int finData [17];
                        
                        errorNoHold = 7;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                    errorNoHold = 1001;
                                    throw errorCheckThrow;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--5
                                finData [13] = uploadTemp [readPosition], readPosition++; //--6
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++;
                                finData [16] = uploadTemp [readPosition], readPosition++; //--7
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                else{
                                    
                                    arrayPositionReviseCurrent [positionReviseCurrentCount] = finData [1], positionReviseCurrentCount++;
                                    arrayPositionReviseCurrent [positionReviseCurrentCount] = finData [3], positionReviseCurrentCount++;
                                    arrayPositionReviseCurrent [positionReviseCurrentCount] = finData [4], positionReviseCurrentCount++;
                                    arrayPositionReviseCurrent [positionReviseCurrentCount] = finData [7], positionReviseCurrentCount++;
                                    arrayPositionReviseCurrent [positionReviseCurrentCount] = finData [12], positionReviseCurrentCount++;
                                    arrayPositionReviseCurrent [positionReviseCurrentCount] = finData [13], positionReviseCurrentCount++;
                                    arrayPositionReviseCurrent [positionReviseCurrentCount] = finData [16], positionReviseCurrentCount++;
                                }
                            }
                            else if (stepCount == 1){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                finData [9] = finData [8]*256+finData [9];
                                
                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                else{
                                    
                                    if (associatedDataCurrCount+10 > associatedDataCurrLimit){
                                        [self associatedDataCurrUpDate];
                                        
                                        if (errorNoHold != 0){
                                            errorNoHold = errorNoHold+2000;
                                            throw errorCheckThrow;
                                        }
                                    }
                                    
                                    arrayAssociatedDataCurr [associatedDataCurrCount] = finData [2], associatedDataCurrCount++;
                                    arrayAssociatedDataCurr [associatedDataCurrCount] = finData [3], associatedDataCurrCount++;
                                    arrayAssociatedDataCurr [associatedDataCurrCount] = finData [4], associatedDataCurrCount++;
                                    arrayAssociatedDataCurr [associatedDataCurrCount] = finData [7], associatedDataCurrCount++;
                                    arrayAssociatedDataCurr [associatedDataCurrCount] = finData [9], associatedDataCurrCount++;
                                    arrayAssociatedDataCurr [associatedDataCurrCount] = finData [10], associatedDataCurrCount++;
                                }
                            }
                            else if (stepCount == 2){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                else{
                                    
                                    if (gravityCenterRevCurrentCount+10 > gravityCenterRevCurrentLimit){
                                        [self gravityCenterRevCurrentUpDate];
                                        
                                        if (errorNoHold != 0){
                                            errorNoHold = errorNoHold+2000;
                                            throw errorCheckThrow;
                                        }
                                    }
                                    
                                    arrayGravityCenterRevCurrent [gravityCenterRevCurrentCount] = finData [1], gravityCenterRevCurrentCount++;
                                    arrayGravityCenterRevCurrent [gravityCenterRevCurrentCount] = finData [3], gravityCenterRevCurrentCount++;
                                    arrayGravityCenterRevCurrent [gravityCenterRevCurrentCount] = finData [6], gravityCenterRevCurrentCount++;
                                    arrayGravityCenterRevCurrent [gravityCenterRevCurrentCount] = finData [7], gravityCenterRevCurrentCount++;
                                    arrayGravityCenterRevCurrent [gravityCenterRevCurrentCount] = finData [10], gravityCenterRevCurrentCount++;
                                    arrayGravityCenterRevCurrent [gravityCenterRevCurrentCount] = finData [11], gravityCenterRevCurrentCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                    }
                    else{
                        
                        fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            int finData [11];
                            
                            errorNoHold = 8;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                                        errorNoHold = 1002;
                                        throw errorCheckThrow;
                                    }
                                }
                            }
                            
                            fin.close();
                            
                            unsigned long readPosition = 0;
                            int stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [4] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--3
                                    finData [8] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [9] = uploadTemp [readPosition], readPosition++;
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                    else{
                                        
                                        arrayPositionReviseCurrent [positionReviseCurrentCount] = finData [1], positionReviseCurrentCount++; //------X position------
                                        arrayPositionReviseCurrent [positionReviseCurrentCount] = finData [3], positionReviseCurrentCount++; //------Y position------
                                        arrayPositionReviseCurrent [positionReviseCurrentCount] = finData [4], positionReviseCurrentCount++; //------Value------
                                        arrayPositionReviseCurrent [positionReviseCurrentCount] = finData [7], positionReviseCurrentCount++; //------Connect No------
                                        arrayPositionReviseCurrent [positionReviseCurrentCount] = 0, positionReviseCurrentCount++; //------Cell No------
                                        arrayPositionReviseCurrent [positionReviseCurrentCount] = 0, positionReviseCurrentCount++; //------Status------
                                        arrayPositionReviseCurrent [positionReviseCurrentCount] = 0, positionReviseCurrentCount++; //------Lineage no------
                                    }
                                }
                                else if (stepCount == 1){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++;
                                    finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                    finData [8] = uploadTemp [readPosition], readPosition++;
                                    finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                    finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                    
                                    finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                    finData [9] = finData [8]*256+finData [9];
                                    
                                    if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                    else{
                                        
                                        if (associatedDataCurrCount+1 > associatedDataCurrLimit){
                                            [self associatedDataCurrUpDate];
                                            
                                            if (errorNoHold != 0){
                                                errorNoHold = errorNoHold+2000;
                                                throw errorCheckThrow;
                                            }
                                        }
                                        
                                        arrayAssociatedDataCurr [associatedDataCurrCount] = finData [2], associatedDataCurrCount++;
                                        arrayAssociatedDataCurr [associatedDataCurrCount] = finData [3], associatedDataCurrCount++;
                                        arrayAssociatedDataCurr [associatedDataCurrCount] = finData [4], associatedDataCurrCount++;
                                        arrayAssociatedDataCurr [associatedDataCurrCount] = finData [7], associatedDataCurrCount++;
                                        arrayAssociatedDataCurr [associatedDataCurrCount] = finData [9], associatedDataCurrCount++;
                                        arrayAssociatedDataCurr [associatedDataCurrCount] = finData [10], associatedDataCurrCount++;
                                    }
                                }
                                else if (stepCount == 2){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [4] = uploadTemp [readPosition], readPosition++;
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                    finData [8] = uploadTemp [readPosition], readPosition++;
                                    finData [9] = uploadTemp [readPosition], readPosition++;
                                    finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                    finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                    else{
                                        
                                        if (gravityCenterRevCurrentCount+1 > gravityCenterRevCurrentLimit){
                                            [self gravityCenterRevCurrentUpDate];
                                            
                                            if (errorNoHold != 0){
                                                errorNoHold = errorNoHold+2000;
                                                throw errorCheckThrow;
                                            }
                                        }
                                        
                                        arrayGravityCenterRevCurrent [gravityCenterRevCurrentCount] = finData [1], gravityCenterRevCurrentCount++;
                                        arrayGravityCenterRevCurrent [gravityCenterRevCurrentCount] = finData [3], gravityCenterRevCurrentCount++;
                                        arrayGravityCenterRevCurrent [gravityCenterRevCurrentCount] = finData [6], gravityCenterRevCurrentCount++;
                                        arrayGravityCenterRevCurrent [gravityCenterRevCurrentCount] = finData [7], gravityCenterRevCurrentCount++;
                                        arrayGravityCenterRevCurrent [gravityCenterRevCurrentCount] = finData [10], gravityCenterRevCurrentCount++;
                                        arrayGravityCenterRevCurrent [gravityCenterRevCurrentCount] = 0, gravityCenterRevCurrentCount++;
                                    }
                                }
                                
                            } while (stepCount != 3);
                            
                            delete [] uploadTemp;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < gravityCenterRevCurrentCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRevCurrent [counterA*6+counterB];
                //	cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < positionReviseCurrentCount/7; counterA++){
                //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionReviseCurrent [counterA*7+counterB];
                //	cout<<" arrayPositionReviseCurrent "<<counterA<<endl;
                //}
                
                //------Masater Data Status UpLoad------
                string connectStatusDataPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
                
                sizeForCopy = 0;
                timeSelectedCurrentCount = 0;
                
                stat(connectStatusDataPath.c_str(), &sizeOfFile);
                
                if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy < gravityCenterRevCurrentCount*2) sizeForCopy = gravityCenterRevCurrentCount*2;
                
                fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    if (timeSelectedCurrentStatus == 0){
                        errorNoHold = 9;
                        arrayTimeSelectedCurrent = new int [sizeForCopy+50];
                        timeSelectedCurrentCount = 0;
                        timeSelectedCurrentStatus = 1;
                        timeSelectedCurrentLimit = (int)sizeForCopy+50;
                        timeSelectedCurrentSizeHold = (int)sizeForCopy+50;
                    }
                    else if (timeSelectedCurrentStatus == 1 && timeSelectedCurrentSizeHold < sizeForCopy){
                        delete [] arrayTimeSelectedCurrent;
                        
                        errorNoHold = 10;
                        arrayTimeSelectedCurrent = new int [sizeForCopy+50];
                        timeSelectedCurrentCount = 0;
                        timeSelectedCurrentLimit = (int)sizeForCopy+50;
                        timeSelectedCurrentSizeHold = (int)sizeForCopy+50;
                    }
                    else timeSelectedCurrentCount = 0;
                    int finData [19];
                    
                    errorNoHold = 11;
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                            errorNoHold = 1003;
                            throw errorCheckThrow;
                        }
                    }
                    
                    fin.close();
                    
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                            finData [7] = uploadTemp [readPosition], readPosition++;
                            finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                            finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                            finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                            finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                            finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                            finData [13] = uploadTemp [readPosition], readPosition++;
                            finData [14] = uploadTemp [readPosition], readPosition++;
                            finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                            finData [16] = uploadTemp [readPosition], readPosition++;
                            finData [17] = uploadTemp [readPosition], readPosition++;
                            finData [18] = uploadTemp [readPosition], readPosition++; //--11 Ling no
                            
                            finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            finData [8] = finData [7]*256+finData [8];
                            finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                            finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                            
                            if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                            else{
                                
                                arrayTimeSelectedCurrent [timeSelectedCurrentCount] = finData [0], timeSelectedCurrentCount++; //------Selected, removed, eliminated status------
                                arrayTimeSelectedCurrent [timeSelectedCurrentCount] = finData [3], timeSelectedCurrentCount++; //------When new line is created, enter line number which creates------
                                arrayTimeSelectedCurrent [timeSelectedCurrentCount] = finData [6], timeSelectedCurrentCount++; //------PositionRevise Start------
                                arrayTimeSelectedCurrent [timeSelectedCurrentCount] = finData [8], timeSelectedCurrentCount++; //------Cut line number------
                                arrayTimeSelectedCurrent [timeSelectedCurrentCount] = finData [9], timeSelectedCurrentCount++; //------X Start------
                                arrayTimeSelectedCurrent [timeSelectedCurrentCount] = finData [10], timeSelectedCurrentCount++; //------X End------
                                arrayTimeSelectedCurrent [timeSelectedCurrentCount] = finData [11], timeSelectedCurrentCount++; //------Y Start------
                                arrayTimeSelectedCurrent [timeSelectedCurrentCount] = finData [12], timeSelectedCurrentCount++; //------Y End------
                                arrayTimeSelectedCurrent [timeSelectedCurrentCount] = finData [15], timeSelectedCurrentCount++; //------Connect------
                                arrayTimeSelectedCurrent [timeSelectedCurrentCount] = finData [18], timeSelectedCurrentCount++; //------Lineage------
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    if (timeSelectedCurrentStatus == 0){
                        errorNoHold = 12;
                        arrayTimeSelectedCurrent = new int [gravityCenterRevCurrentCount*2+50];
                        timeSelectedCurrentCount = 0;
                        timeSelectedCurrentStatus = 1;
                        timeSelectedCurrentLimit = gravityCenterRevCurrentCount*2+50;
                        timeSelectedCurrentSizeHold = gravityCenterRevCurrentCount*2+50;
                    }
                    else if (timeSelectedCurrentStatus == 1 && timeSelectedCurrentSizeHold < gravityCenterRevCurrentCount){
                        delete [] arrayTimeSelectedCurrent;
                        
                        errorNoHold = 13;
                        arrayTimeSelectedCurrent = new int [gravityCenterRevCurrentCount*3+50];
                        timeSelectedCurrentCount = 0;
                        timeSelectedCurrentLimit = gravityCenterRevCurrentCount*2+50;
                        timeSelectedCurrentSizeHold = gravityCenterRevCurrentCount*2+50;
                    }
                    else timeSelectedCurrentCount = 0;
                    
                    for (int counter1 = 0; counter1 < gravityCenterRevCurrentCount/6; counter1++){ //------Counter number corresponds to connect No------
                        arrayTimeSelectedCurrent [timeSelectedCurrentCount] = 0, timeSelectedCurrentCount++; //------Selected, removed, eliminated status------
                        arrayTimeSelectedCurrent [timeSelectedCurrentCount] = 0, timeSelectedCurrentCount++; //------When new line is created, enter line number which creates------
                        arrayTimeSelectedCurrent [timeSelectedCurrentCount] = 0, timeSelectedCurrentCount++; //------Top position of each connect------
                        arrayTimeSelectedCurrent [timeSelectedCurrentCount] = 0, timeSelectedCurrentCount++; //------Cut line number------
                        arrayTimeSelectedCurrent [timeSelectedCurrentCount] = 0, timeSelectedCurrentCount++; //------X Start------
                        arrayTimeSelectedCurrent [timeSelectedCurrentCount] = 0, timeSelectedCurrentCount++; //------X End------
                        arrayTimeSelectedCurrent [timeSelectedCurrentCount] = 0, timeSelectedCurrentCount++; //------Y Start------
                        arrayTimeSelectedCurrent [timeSelectedCurrentCount] = 0, timeSelectedCurrentCount++; //------Y End------
                        arrayTimeSelectedCurrent [timeSelectedCurrentCount] = counter1+1, timeSelectedCurrentCount++; //------Connect------
                        arrayTimeSelectedCurrent [timeSelectedCurrentCount] = 0, timeSelectedCurrentCount++; //------Lineage------
                    }
                    
                    int valueTemp = 0;
                    
                    for (int counter1 = 0; counter1 < positionReviseCurrentCount/7; counter1++){
                        if (arrayPositionReviseCurrent [counter1*7+3] != valueTemp){
                            valueTemp = arrayPositionReviseCurrent [counter1*7+3];
                            arrayTimeSelectedCurrent [(valueTemp-1)*10+2] = counter1;
                            
                            if (arrayPositionReviseCurrent [counter1*7+5] == 0) arrayTimeSelectedCurrent [(valueTemp-1)*10] = 0;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < timeSelectedCurrentCount/10; counterA++){
                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelectedCurrent [counterA*10+counterB];
                //    cout<<" arrayTimeSelectedCurrent"<<counterA<<endl;
                //}
                
                string connectRelationPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
                
                sizeForCopy = 0;
                connectLineageRelCurrentCount = 0;
                
                stat(connectRelationPath.c_str(), &sizeOfFile);
                
                if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (connectLineageRelCurrentStatus == 0){
                        errorNoHold = 14;
                        arrayConnectLineageRelCurrent = new int [sizeForCopy+50];
                        connectLineageRelCurrentCount = 0;
                        connectLineageRelCurrentStatus = 1;
                        connectLineageRelCurrentLimit = (int)sizeForCopy+50;
                        connectLineageRelCurrentSizeHold = (int)sizeForCopy+50;
                    }
                    else if (connectLineageRelCurrentStatus == 1 && connectLineageRelCurrentSizeHold < sizeForCopy){
                        delete [] arrayConnectLineageRelCurrent;
                        
                        errorNoHold = 15;
                        arrayConnectLineageRelCurrent = new int [sizeForCopy+50];
                        connectLineageRelCurrentCount = 0;
                        connectLineageRelCurrentLimit = (int)sizeForCopy+50;
                        connectLineageRelCurrentSizeHold = (int)sizeForCopy+50;
                    }
                    else connectLineageRelCurrentCount = 0;
                    
                    fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [19];
                        
                        errorNoHold = 16;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                                errorNoHold = 1004;
                                throw errorCheckThrow;
                            }
                        }
                        
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1 Ling no
                                finData [3] = uploadTemp [readPosition], readPosition++;
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                                finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                                finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                                finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                                finData [7] = finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                else{
                                    
                                    arrayConnectLineageRelCurrent [connectLineageRelCurrentCount] = finData [2], connectLineageRelCurrentCount++;
                                    arrayConnectLineageRelCurrent [connectLineageRelCurrentCount] = finData [5], connectLineageRelCurrentCount++;
                                    arrayConnectLineageRelCurrent [connectLineageRelCurrentCount] = finData [7], connectLineageRelCurrentCount++;
                                    arrayConnectLineageRelCurrent [connectLineageRelCurrentCount] = finData [12], connectLineageRelCurrentCount++;
                                    arrayConnectLineageRelCurrent [connectLineageRelCurrentCount] = finData [13], connectLineageRelCurrentCount++;
                                    arrayConnectLineageRelCurrent [connectLineageRelCurrentCount] = finData [14], connectLineageRelCurrentCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                    }
                    else{
                        
                        errorNoHold = 1005;
                        throw errorCheckThrow;
                    }
                }
                else if (connectLineageRelCurrentStatus == 0){
                    arrayConnectLineageRelCurrent = new int [5000];
                    connectLineageRelCurrentCount = 0;
                    connectLineageRelCurrentStatus = 1;
                    connectLineageRelCurrentLimit = 5000;
                    connectLineageRelCurrentSizeHold = 5000;
                }
                else connectLineageRelCurrentCount = 0;
                
                //for (int counterA = 0; counterA < timeSelectedCurrentCount/10; counterA++){
                //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelectedCurrent [counterA*10+counterB];
                //	cout<<" arrayTimeSelectedCurrent "<<counterA<<endl;
                //}
                
                string mapPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+extension+"_"+analysisImageName+"_"+treatmentNameHold+"_Map";
                string revisedMapPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_RevisedMap";
                
                if (mapLoadingStatus == 0){
                    mapLoadingStatus = 1;
                    
                    errorNoHold = 17;
                    revisedMapCurrent = new int *[imageDimension+1];
                    
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 18;
                        revisedMapCurrent [counter1] = new int [imageDimension+1];
                    }
                    
                    revisedMapCurrentSizeHold = imageDimension;
                }
                else if (mapLoadingStatus == 1 && revisedMapCurrentSizeHold < imageDimension){
                    for (int counter1 = 0; counter1 < revisedMapCurrentSizeHold+1; counter1++) delete [] revisedMapCurrent [counter1];
                    delete [] revisedMapCurrent;
                    
                    errorNoHold = 19;
                    revisedMapCurrent = new int *[imageDimension+1];
                    
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 20;
                        revisedMapCurrent [counter1] = new int [imageDimension+1];
                    }
                    
                    revisedMapCurrentSizeHold = imageDimension;
                }
                
                int pixelData;
                int readBit [4];
                int yDimensionCount;
                int xDimensionCount;
                
                long sizeTotal = (long)(imageDimension*imageDimension*4);
                
                errorNoHold = 21;
                uint8_t *upload2 = new uint8_t [sizeTotal+50];
                
                //---------Revised Map----------
                fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    fin.read((char*)upload2, sizeTotal+1);
                    fin.close();
                    
                    yDimensionCount = 0;
                    xDimensionCount = 0;
                    
                    for (int counter1 = 0; counter1 < sizeTotal; counter1 = counter1+4){
                        readBit [0] = upload2[counter1];
                        readBit [1] = upload2[counter1+1];
                        readBit [2] = upload2[counter1+2];
                        readBit [3] = upload2[counter1+3];
                        
                        pixelData = readBit [0]*65536+readBit [1]*256+readBit [2];
                        
                        for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                            revisedMapCurrent [yDimensionCount][xDimensionCount] = pixelData, xDimensionCount++;
                        }
                        
                        if (xDimensionCount == imageDimension){
                            xDimensionCount = 0;
                            yDimensionCount++;
                            
                            if (yDimensionCount == imageDimension){
                                break;
                            }
                        }
                    }
                }
                else{
                    
                    fin.open(mapPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)upload2, sizeTotal+1);
                        fin.close();
                        
                        yDimensionCount = 0;
                        xDimensionCount = 0;
                        
                        for (int counter1 = 0; counter1 < sizeTotal; counter1 = counter1+4){
                            readBit [0] = upload2[counter1];
                            readBit [1] = upload2[counter1+1];
                            readBit [2] = upload2[counter1+2];
                            readBit [3] = upload2[counter1+3];
                            
                            pixelData = readBit [0]*65536+readBit [1]*256+readBit [2];
                            
                            for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                                revisedMapCurrent [yDimensionCount][xDimensionCount] = pixelData, xDimensionCount++;
                            }
                            
                            if (xDimensionCount == imageDimension){
                                xDimensionCount = 0;
                                yDimensionCount++;
                                
                                if (yDimensionCount == imageDimension){
                                    break;
                                }
                            }
                        }
                    }
                    else{
                        
                        errorNoHold = 1006;
                        throw errorCheckThrow;
                    }
                }
                
                delete [] upload2;
            }
            
            //for (int counterA = 0; counterA < 300; counterA++){
            //	for (int counterB = 0; counterB < 300; counterB++) cout<<" "<<revisedMapCurrent [counterA][counterB];
            //	cout<<" revisedMapCurrent "<<counterA<<endl;
            //}
            
            if (positionReviseCurrentCount == 0 || associatedDataCurrCount == 0 || gravityCenterRevCurrentCount == 0 || timeSelectedCurrentCount == 0 || associatedDataCurrCount/6 != timeSelectedCurrentCount/10 || gravityCenterRevCurrentCount/6 != timeSelectedCurrentCount/10){
                errorNoHold = 1007;
                throw errorCheckThrow;
            }
            else{
                
                if (processTime == 1){
                    if (sectionMapLoadingStatus == 0){
                        errorNoHold = 22;
                        arrayCellTrackingCurrentMap = new int *[trackAreaSize+4];
                        
                        for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++){
                            errorNoHold = 23;
                            arrayCellTrackingCurrentMap [counter1] = new int [trackAreaSize+4];
                        }
                        
                        sectionMapLoadingStatus = 1;
                        cellTrackingCurrentMapSizeHold = trackAreaSize;
                    }
                    else if (sectionMapLoadingStatus == 1 && 300 < cellTrackingCurrentMapSizeHold && 300 > trackAreaSize){
                        for (int counter1 = 0; counter1 < cellTrackingCurrentMapSizeHold+4; counter1++){
                            delete [] arrayCellTrackingCurrentMap [counter1];
                        }
                        
                        delete [] arrayCellTrackingCurrentMap;
                        
                        cellTrackingCurrentMapSizeHold = trackAreaSize;
                        
                        errorNoHold = 24;
                        arrayCellTrackingCurrentMap = new int *[trackAreaSize+4];
                        
                        for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++){
                            errorNoHold = 25;
                            arrayCellTrackingCurrentMap [counter1] = new int [trackAreaSize+4];
                        }
                    }
                    else if (sectionMapLoadingStatus == 1 && cellTrackingCurrentMapSizeHold < trackAreaSize){
                        for (int counter1 = 0; counter1 < cellTrackingCurrentMapSizeHold+4; counter1++){
                            delete [] arrayCellTrackingCurrentMap [counter1];
                        }
                        
                        delete [] arrayCellTrackingCurrentMap;
                        
                        cellTrackingCurrentMapSizeHold = trackAreaSize;
                        
                        errorNoHold = 26;
                        arrayCellTrackingCurrentMap = new int *[trackAreaSize+4];
                        
                        for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++){
                            errorNoHold = 27;
                            arrayCellTrackingCurrentMap [counter1] = new int [trackAreaSize+4];
                        }
                    }
                }
                
                if (cellTrackingCurrentStatus == 0){
                    errorNoHold = 28;
                    arrayCellTrackingCurrent = new int [positionReviseCurrentCount*3+50];
                    cellTrackingCurrentCount = 0;
                    cellTrackingCurrentStatus = 1;
                    cellTrackingCurrentSizeHold = positionReviseCurrentCount*3+50;
                }
                else if (cellTrackingCurrentStatus == 1 && cellTrackingCurrentSizeHold < positionReviseCurrentCount){
                    delete [] arrayCellTrackingCurrent;
                    
                    errorNoHold = 29;
                    arrayCellTrackingCurrent = new int [positionReviseCurrentCount*3+50];
                    cellTrackingCurrentCount = 0;
                    cellTrackingCurrentSizeHold = positionReviseCurrentCount*3+50;
                }
                else cellTrackingCurrentCount = 0;
                
                if (xyPositionCenterCurrentStatus == 0){
                    errorNoHold = 30;
                    arrayXYPositionCenterCurrent = new int [gravityCenterRevCurrentCount*3+50];
                    xyPositionCenterCurrentCount = 0;
                    xyPositionCenterCurrentStatus = 1;
                    xyPositionCenterCurrentSizeHold = gravityCenterRevCurrentCount*3+50;
                }
                else if (xyPositionCenterCurrentStatus == 1 && xyPositionCenterCurrentSizeHold < gravityCenterRevCurrentCount){
                    delete [] arrayXYPositionCenterCurrent;
                    
                    errorNoHold = 31;
                    arrayXYPositionCenterCurrent = new int [gravityCenterRevCurrentCount*3+50];
                    xyPositionCenterCurrentCount = 0;
                    xyPositionCenterCurrentSizeHold = gravityCenterRevCurrentCount*3+50;
                }
                else xyPositionCenterCurrentCount = 0;
                
                if (cellTrackingCurrentAssStatus == 0){
                    errorNoHold = 32;
                    arrayCellTrackingCurrentAss = new int [associatedDataCurrCount*3+50];
                    cellTrackingCurrentAssCount = 0;
                    cellTrackingCurrentAssStatus = 1;
                    cellTrackingCurrentAssSizeHold = associatedDataCurrCount*3+50;
                }
                else if (cellTrackingCurrentAssStatus == 1 && cellTrackingCurrentAssSizeHold < associatedDataCurrCount){
                    delete [] arrayCellTrackingCurrentAss;
                    
                    errorNoHold = 33;
                    arrayCellTrackingCurrentAss = new int [associatedDataCurrCount*3+50];
                    cellTrackingCurrentAssCount = 0;
                    cellTrackingCurrentAssSizeHold = associatedDataCurrCount*3+50;
                }
                else cellTrackingCurrentAssCount = 0;
                
                //for (int counterA = 0; counterA < timeSelectedCurrentCount/10; counterA++){
                //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelectedCurrent [counterA*10+counterB];
                //	cout<<" arrayTimeSelectedCurrent "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < associatedDataCurrCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRevCurrent [counterA*6+counterB];
                //	cout<<" arrayGravityCenterRevCurrent "<<counterA<<endl;
                //}
                
                int endPosition = 0;
                int saveFlag = 0;
                int connectTimeStatus = 0;
                
                for (int counter1 = 0; counter1 < timeSelectedCurrentCount/10; counter1++){
                    if (arrayTimeSelectedCurrent [counter1*10] != 3 && arrayTimeSelectedCurrent [counter1*10] != 4){
                        if (counter1 == timeSelectedCurrentCount/10-1) endPosition = positionReviseCurrentCount/7-1;
                        else endPosition = arrayTimeSelectedCurrent [(counter1+1)*10+2]-1;
                        
                        if (endPosition < arrayTimeSelectedCurrent [counter1*10+2]) endPosition = positionReviseCurrentCount/7-1;
                        
                        connectTimeStatus = arrayTimeSelectedCurrent [counter1*10+8];
                        
                        saveFlag = 0;
                        
                        for (int counter2 = arrayTimeSelectedCurrent [counter1*10+2]; counter2 <= endPosition; counter2++){
                            if (connectTimeStatus == arrayPositionReviseCurrent [counter2*7+3] && arrayPositionReviseCurrent [counter2*7]-horizontalStart >= 0 && arrayPositionReviseCurrent [counter2*7]-horizontalStart < trackAreaSize && arrayPositionReviseCurrent [counter2*7+1]-verticalStart >= 0 && arrayPositionReviseCurrent [counter2*7+1]-verticalStart < trackAreaSize){
                                saveFlag++;
                            }
                        }
                        
                        if (saveFlag != 0){
                            for (int counter2 = arrayTimeSelectedCurrent [counter1*10+2]; counter2 <= endPosition; counter2++){
                                if (connectTimeStatus == arrayPositionReviseCurrent [counter2*7+3]){
                                    arrayCellTrackingCurrent [cellTrackingCurrentCount] = arrayPositionReviseCurrent [counter2*7], cellTrackingCurrentCount++;
                                    arrayCellTrackingCurrent [cellTrackingCurrentCount] = arrayPositionReviseCurrent [counter2*7+1], cellTrackingCurrentCount++;
                                    arrayCellTrackingCurrent [cellTrackingCurrentCount] = arrayPositionReviseCurrent [counter2*7+2], cellTrackingCurrentCount++;
                                    arrayCellTrackingCurrent [cellTrackingCurrentCount] = arrayPositionReviseCurrent [counter2*7+3], cellTrackingCurrentCount++;
                                    arrayCellTrackingCurrent [cellTrackingCurrentCount] = arrayTimeSelectedCurrent [counter1*10], cellTrackingCurrentCount++;
                                    arrayCellTrackingCurrent [cellTrackingCurrentCount] = arrayPositionReviseCurrent [counter2*7+5], cellTrackingCurrentCount++;
                                }
                            }
                            
                            for (int counter2 = 0; counter2 < gravityCenterRevCurrentCount/6; counter2++){
                                if (connectTimeStatus == arrayGravityCenterRevCurrent [counter2*6+4]){
                                    arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = arrayGravityCenterRevCurrent [counter2*6], xyPositionCenterCurrentCount++;
                                    arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = arrayGravityCenterRevCurrent [counter2*6+1], xyPositionCenterCurrentCount++;
                                    arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = arrayGravityCenterRevCurrent [counter2*6+2], xyPositionCenterCurrentCount++;
                                    arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = arrayGravityCenterRevCurrent [counter2*6+3], xyPositionCenterCurrentCount++;
                                    arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = arrayGravityCenterRevCurrent [counter2*6+4], xyPositionCenterCurrentCount++;
                                    arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = 0, xyPositionCenterCurrentCount++;
                                }
                            }
                            
                            for (int counter2 = 0; counter2 < associatedDataCurrCount/6; counter2++){
                                if (connectTimeStatus == arrayAssociatedDataCurr [counter2*6]){
                                    arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = arrayAssociatedDataCurr [counter2*6], cellTrackingCurrentAssCount++;
                                    arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = arrayAssociatedDataCurr [counter2*6+1], cellTrackingCurrentAssCount++;
                                    arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = arrayAssociatedDataCurr [counter2*6+2], cellTrackingCurrentAssCount++;
                                    arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = arrayAssociatedDataCurr [counter2*6+3], cellTrackingCurrentAssCount++;
                                    arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = arrayAssociatedDataCurr [counter2*6+4], cellTrackingCurrentAssCount++;
                                    arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = arrayAssociatedDataCurr [counter2*6+5], cellTrackingCurrentAssCount++;
                                }
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < cellTrackingCurrentAssCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrentAss [counterA*6+counterB];
                //	cout<<" arrayCellTrackingCurrentAss "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
                //    cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
                //}
                
                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    for (int counterX = 0; counterX < trackAreaSize; counterX++) arrayCellTrackingCurrentMap [counterY][counterX] = 0;
                }
                
                int findFlag = 0;
                
                //for (int counterA = newYCenter-10; counterA < newYCenter2+10; counterA++){
                //    for (int counterB = newXCenter-10; counterB < newXCenter2+10; counterB++) cout<<" "<<revisedMapCurrent [counterA][counterB];
                //    cout<<" revisedMapCurrent "<<counterA<<endl;
                //}
                
                for (int counterY = verticalStart; counterY < verticalStart+trackAreaSize; counterY++){
                    for (int counterX = horizontalStart; counterX < horizontalStart+trackAreaSize; counterX++){
                        if (counterY < 0 || counterY >= imageDimension || counterX < 0 || counterX >= imageDimension){
                            arrayCellTrackingCurrentMap [counterY-verticalStart][counterX-horizontalStart] = 0;
                        }
                        else{
                            
                            findFlag = 0;
                            
                            if (revisedMapCurrent [counterY][counterX] != 0){
                                for (int counter1 = 0; counter1 < xyPositionCenterCurrentCount/6; counter1++){
                                    if (arrayXYPositionCenterCurrent [counter1*6+4] == revisedMapCurrent [counterY][counterX]){
                                        findFlag =1;
                                        break;
                                    }
                                }
                            }
                            
                            if (counterY >= 0 && counterY < imageDimension && counterX >= 0 && counterX < imageDimension){
                                if (findFlag == 1) arrayCellTrackingCurrentMap [counterY-verticalStart][counterX-horizontalStart] = revisedMapCurrent [counterY][counterX];
                                else arrayCellTrackingCurrentMap [counterY-verticalStart][counterX-horizontalStart] = 0;
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                //	for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingCurrentMap [counterA][counterB];
                //	cout<<" arrayCellTrackingCurrentMap "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
                //    cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
                //}
                
                errorNoHold = 34;
                int *connectedPixels = new int [gravityCenterRevCurrentCount/6+1];
                
                for (int counter1 = 0; counter1 < gravityCenterRevCurrentCount/6+1; counter1++) connectedPixels [counter1] = 0;
                
                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                        if (arrayCellTrackingCurrentMap [counterY][counterX] != 0) connectedPixels [arrayCellTrackingCurrentMap [counterY][counterX]]++;
                    }
                }
                
                //------Map up-date------
                int connectTemp2 = 1;
                
                for (int counter1 = 1; counter1 < gravityCenterRevCurrentCount/6+1; counter1++){
                    if (connectedPixels [counter1] != 0){
                        connectedPixels [counter1] = connectTemp2;
                        connectTemp2++;
                    }
                }
                
                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                        if (arrayCellTrackingCurrentMap [counterY][counterX] != 0) arrayCellTrackingCurrentMap [counterY][counterX] = connectedPixels [arrayCellTrackingCurrentMap [counterY][counterX]];
                    }
                }
                
                for (int counter1 = 0; counter1 < xyPositionCenterCurrentCount/6; counter1++){
                    if (arrayXYPositionCenterCurrent [counter1*6+4] != 0) arrayXYPositionCenterCurrent [counter1*6+4] = connectedPixels [arrayXYPositionCenterCurrent [counter1*6+4]];
                }
                
                //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
                //    cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < cellTrackingCurrentCount/6; counter1++){
                    if (arrayCellTrackingCurrent [counter1*6+3] != 0) arrayCellTrackingCurrent [counter1*6+3] = connectedPixels [arrayCellTrackingCurrent [counter1*6+3]];
                }
                
                //for (int counterA = 0; counterA < cellTrackingCurrentCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrent [counterA*6+counterB];
                //	cout<<" arrayCellTrackingCurrent "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < cellTrackingCurrentAssCount/6; counter1++){
                    if (arrayCellTrackingCurrentAss [counter1*6] != 0) arrayCellTrackingCurrentAss [counter1*6] = connectedPixels [arrayCellTrackingCurrentAss [counter1*6]];
                }
                
                //for (int counterA = 0; counterA < cellTrackingCurrentAssCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrentAss [counterA*6+counterB];
                //	cout<<" arrayCellTrackingCurrentAss "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                //    for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingCurrentMap [counterA][counterB];
                //    cout<<" arrayCellTrackingCurrentMap "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < timeSelectedCurrentCount/10; counterA++){
                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelectedCurrent [counterA*10+counterB];
                //    cout<<" arrayTimeSelectedCurrent "<<counterA<<endl;
                //}
                
                delete [] connectedPixels;
            }
            
            //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
            //    cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < gravityCenterRevCurrentCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRevCurrent [counterA*6+counterB];
            //    cout<<" arrayGravityCenterRevCurrent "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < imageDimension; counterA++){
            //    for (int counterB = 0; counterB < imageDimension; counterB++){
            //        if (revisedMapCurrent [counterA][counterB] == 2390) cout<<revisedMapCurrent [counterA][counterB]<<" revisedMapCurrent"<<endl;
            //    }
            //}
            
            sleepingPosition = 12;
            errorNoHold = 0;
            subCompletionFlag = 0;
        }
        catch (int errorCheckThrow){
            if (errorNoHold >= 1000 && errorNoHold < 2000){
                string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
                mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                time_t rawtime;
                struct tm * timeinfo;
                time (&rawtime);
                timeinfo = localtime ( &rawtime );
                
                int tsec = timeinfo -> tm_sec;
                int tmin = timeinfo -> tm_min;
                int thour = timeinfo -> tm_hour;
                int tday = timeinfo -> tm_mday;
                int tmon = timeinfo -> tm_mon;
                
                string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
                
                errorPath = errorPath+"/Cell_CarvingTrackingSetCurrent01 "+dateTime;
                
                ofstream oin2;
                oin2.open(errorPath.c_str(), ios::out);
                oin2<<"TrackingSetCurrent"<<endl;
                oin2<<errorNoHold<<endl;
                oin2<<analysisImageName<<endl;
                oin2<<analysisID<<endl;
                oin2<<treatmentNameHold<<endl;
                oin2<<cellLineageNoHold<<endl;
                oin2<<cellNoHold<<endl;
                oin2<<dateTime<<endl;
                
                if (errorNoHold == 1000) oin2<<"MasterData/Revise reading error"<<endl;
                else if (errorNoHold == 1001) oin2<<"MasterDataRevise uploading error"<<endl;
                else if (errorNoHold == 1002) oin2<<"MasterData uploading error"<<endl;
                else if (errorNoHold == 1003) oin2<<"Status data uploading error"<<endl;
                else if (errorNoHold == 1004) oin2<<"ConnectRel data uploading error"<<endl;
                else if (errorNoHold == 1005) oin2<<"ConnectRel data open-error"<<endl;
                else if (errorNoHold == 1006) oin2<<"Map open-error"<<endl;
                else if (errorNoHold == 1007) oin2<<"Array size error"<<endl;
                oin2.close();
            }
            
            if (errorNoHold == 0) errorNoHold = 1000;
            
            subCompletionFlag = 0;
        }
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingTrackingSetCurrent02 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"TrackingSetCurrent"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
        
        subCompletionFlag = 0;
    }
}

-(void)gravityCenterRevCurrentUpDate{
    try{
        
        errorNoHold = 0;
        
        int *arrayUpDate = new int [gravityCenterRevCurrentCount+10];
        
        for (int counter1 = 0; counter1 < gravityCenterRevCurrentCount; counter1++) arrayUpDate [counter1] = arrayGravityCenterRevCurrent [counter1];
        
        delete [] arrayGravityCenterRevCurrent;
        arrayGravityCenterRevCurrent = new int [gravityCenterRevCurrentLimit*3+2000];
        gravityCenterRevCurrentLimit = gravityCenterRevLimit*3+2000;
        
        for (int counter1 = 0; counter1 < gravityCenterRevCurrentCount; counter1++) arrayGravityCenterRevCurrent [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
        
        gravityCenterRevCurrentCount = gravityCenterRevLimit*3+2000;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingTrackingSetCurrent03 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"TrackingSetCurrent-gravityCenterRevCurrentUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

-(void)associatedDataCurrUpDate{
    try{
        
        errorNoHold = 0;
        
        int *arrayUpDate = new int [associatedDataCurrCount+10];
        
        for (int counter1 = 0; counter1 < associatedDataCurrCount; counter1++) arrayUpDate [counter1] = arrayAssociatedDataCurr [counter1];
        
        delete [] arrayAssociatedDataCurr;
        arrayAssociatedDataCurr = new int [associatedDataCurrLimit*3+2000];
        associatedDataCurrLimit = associatedDataCurrLimit*3+2000;
        
        for (int counter1 = 0; counter1 < associatedDataCurrCount; counter1++) arrayAssociatedDataCurr [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
        
        associatedDataCurrSizeHold = associatedDataCurrLimit*3+2000;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingTrackingSetCurrent04 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"TrackingSetCurrent-associatedDataCurrUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

@end
