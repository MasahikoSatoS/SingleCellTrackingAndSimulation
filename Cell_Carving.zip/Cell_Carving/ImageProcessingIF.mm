//
//  ImageProcessingIF.m
//  Cell_Carving
//
//  Created by Masahiko Sato on 2015-12-22.
//
//

#import "ImageProcessingIF.h"

NSString *notificationToImageProcessingIF = @"notoficationExecuteImageProcessingIF";

@implementation ImageProcessingIF

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToImageProcessingIF object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    try{
        try{
            
            errorNoHold = 0;
            int errorCheckThrow = 0;
            
            gravityCenterXHold1 = 0;
            gravityCenterYHold1 = 0;
            gravityAverageHold1 = 0;
            gravityCellNo1 = 0;
            
            fluorescentDetectionDisplay1 = 0;
            
            //---------Fluorescent Image Find--------
            int nextLoad = 0;
            
            for (int counter1 = 0; counter1 < 270; counter1 = counter1+9){
                if (atoi(arrayIFDataHold [counter1].c_str()) != 0 && atoi(arrayIFDataHold [counter1+8].c_str()) <= imageNumberInt){
                    nextLoad = counter1/9+1;
                }
                else if (atoi(arrayIFDataHold [counter1].c_str()) == 0){
                    break;
                }
            }
            
            //for (int counterA = 0; counterA < 90/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayIFDataHold [counterA*9+counterB];
            //    cout<<" arrayIFDataHold "<<counterA<<endl;
            //}
            
            int fluorescentNoIF1 = 0;
            int fluorescentNoIF2 = 0;
            int fluorescentNoIF3 = 0;
            int fluorescentNoIF4 = 0;
            int fluorescentNoIF5 = 0;
            int fluorescentNoIF6 = 0;
            string fluorescentRoundNo = "";
            string fluorescentNameIF1 = "";
            string fluorescentNameIF2 = "";
            string fluorescentNameIF3 = "";
            string fluorescentNameIF4 = "";
            string fluorescentNameIF5 = "";
            string fluorescentNameIF6 = "";
            
            if (nextLoad > 0){
                nextLoad--;
                
                fluorescentEntryCount = atoi(arrayIFDataHold [nextLoad*9+7].c_str());
                fluorescentRoundNo = arrayIFDataHold [nextLoad*9];
                
                if (fluorescentEntryCount >= 1){
                    fluorescentNoIF1 = atoi(arrayIFDataHold [nextLoad*9+4].c_str());
                    fluorescentNameIF1 = arrayIFDataHold [nextLoad*9+1];
                }
                if (fluorescentEntryCount >= 2){
                    fluorescentNoIF2 = atoi(arrayIFDataHold [nextLoad*9+5].c_str());
                    fluorescentNameIF2 = arrayIFDataHold [nextLoad*9+2];
                }
                if (fluorescentEntryCount >= 3){
                    fluorescentNoIF3 = atoi(arrayIFDataHold [nextLoad*9+6].c_str());
                    fluorescentNameIF3 = arrayIFDataHold [nextLoad*9+3];
                }
                if (fluorescentEntryCount >= 4){
                    fluorescentNoIF4 = atoi(arrayIFDataHold [nextLoad*9+6].c_str());
                    fluorescentNameIF4 = arrayIFDataHold [nextLoad*9+3];
                }
                if (fluorescentEntryCount >= 5){
                    fluorescentNoIF5 = atoi(arrayIFDataHold [nextLoad*9+6].c_str());
                    fluorescentNameIF5 = arrayIFDataHold [nextLoad*9+3];
                }
                if (fluorescentEntryCount >= 6){
                    fluorescentNoIF6 = atoi(arrayIFDataHold [nextLoad*9+6].c_str());
                    fluorescentNameIF6 = arrayIFDataHold [nextLoad*9+3];
                }
            }
            
            string extensionString2 = to_string (imageNumberInt);
            
            if (extensionString2.length() == 1) extensionString2 = "000"+extensionString2;
            else if (extensionString2.length() == 2) extensionString2 = "00"+extensionString2;
            else if (extensionString2.length() == 3) extensionString2 = "0"+extensionString2;
            
            int fluorescentDisplayFind1 = 0;
            int fluorescentDisplayFind2 = 0;
            int fluorescentDisplayFind3 = 0;
            int fluorescentDisplayFind4 = 0;
            int fluorescentDisplayFind5 = 0;
            int fluorescentDisplayFind6 = 0;
            
            ifstream fin;
            
            string extension2 = to_string(fluorescentNoIF1);
            string fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF1+".TIF"+fluorescentRoundNo;
            
            fin.open(fluorescentPath1.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF1+".BMP"+fluorescentRoundNo;
            }
            else fin.close();
            
            extension2 = to_string(fluorescentNoIF2);
            string fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF2+".TIF"+fluorescentRoundNo;
            
            fin.open(fluorescentPath2.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF2+".BMP"+fluorescentRoundNo;
            }
            else fin.close();
            
            extension2 = to_string(fluorescentNoIF3);
            string fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF3+".TIF"+fluorescentRoundNo;
            
            fin.open(fluorescentPath3.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF3+".BMP"+fluorescentRoundNo;
            }
            else fin.close();
            
            extension2 = to_string(fluorescentNoIF4);
            string fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF4+".TIF"+fluorescentRoundNo;
            
            fin.open(fluorescentPath4.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF4+".BMP"+fluorescentRoundNo;
            }
            else fin.close();
            
            extension2 = to_string(fluorescentNoIF5);
            string fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF5+".TIF"+fluorescentRoundNo;
            
            fin.open(fluorescentPath5.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF5+".BMP"+fluorescentRoundNo;
            }
            else fin.close();
            
            extension2 = to_string(fluorescentNoIF6);
            string fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF6+".TIF"+fluorescentRoundNo;
            
            fin.open(fluorescentPath6.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF6+".BMP"+fluorescentRoundNo;
            }
            else fin.close();
            
            struct stat sizeOfFile;
            
            if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind1 = 1;
            }
            if (stat(fluorescentPath2.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind2 = 1;
            }
            if (stat(fluorescentPath3.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind3 = 1;
            }
            if (stat(fluorescentPath4.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind4 = 1;
            }
            if (stat(fluorescentPath5.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind5 = 1;
            }
            if (stat(fluorescentPath6.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind6 = 1;
            }
            
            if (fluorescentDisplayFind1 == 1 || fluorescentDisplayFind2 == 1 || fluorescentDisplayFind3 == 1 || fluorescentDisplayFind4 == 1 || fluorescentDisplayFind5 == 1 || fluorescentDisplayFind6 == 1) fluorescentDetectionDisplay1 = 1;
            
            string expandDataPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extensionString2+"_"+analysisID+"_"+treatmentNameHold+"_ExtendLineData";
            
            long sizeForCopy = 0;
            long size1 = 0;
            long size2 = 0;
            int checkFlag = 0;
            
            for (int counter1 = 0; counter1 < 6; counter1++){
                sizeForCopy = 0;
                
                if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter1 == 0) size1 = sizeForCopy;
                    else if (counter1 == 1) size2 = sizeForCopy;
                    else if (counter1 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter1 == 3) size1 = sizeForCopy;
                    else if (counter1 == 4) size2 = sizeForCopy;
                    else if (counter1 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            if (stat(expandDataPath.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                errorNoHold = 1000;
                throw errorCheckThrow;
            }
            
            if (checkFlag == 1){
                if (expandLineFluorescentStatus == 0){
                    errorNoHold = 1;
                    expandLineFluorescent = new int [sizeForCopy+50];
                    expandLineFluorescentCount = 0;
                    expandLineFluorescentLimit = (int)sizeForCopy+50;
                    expandLineFluorescentStatus = 1;
                    expandLineFluorescentSizeHold = (int)sizeForCopy+50;
                }
                else if (expandLineFluorescentStatus == 1 && expandLineFluorescentSizeHold < sizeForCopy){
                    delete [] expandLineFluorescent;
                    
                    errorNoHold = 2;
                    expandLineFluorescent = new int [sizeForCopy+50];
                    expandLineFluorescentCount = 0;
                    expandLineFluorescentLimit = (int)sizeForCopy+50;
                    expandLineFluorescentSizeHold = (int)sizeForCopy+50;
                }
                else expandLineFluorescentCount = 0;
                
                fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    int finData [8];
                    
                    errorNoHold = 3;
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                errorNoHold = 1001;
                                throw errorCheckThrow;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--1 X position
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y position
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                            finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                            else{
                                
                                expandLineFluorescent [expandLineFluorescentCount] = finData [1], expandLineFluorescentCount++;
                                expandLineFluorescent [expandLineFluorescentCount] = finData [3], expandLineFluorescentCount++;
                                expandLineFluorescent [expandLineFluorescentCount] = finData [6], expandLineFluorescentCount++;
                                expandLineFluorescent [expandLineFluorescentCount] = finData [7], expandLineFluorescentCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    errorNoHold = 1002;
                    throw errorCheckThrow;
                }
            }
            else if (expandLineFluorescentStatus == 0){
                errorNoHold = 4;
                expandLineFluorescent = new int [500];
                expandLineFluorescentCount = 0;
                expandLineFluorescentLimit = 500;
                expandLineFluorescentStatus = 1;
                expandLineFluorescentSizeHold = 500;
            }
            else expandLineFluorescentCount = 0;
            
            //for (int counterA = 0; counterA < expandLineFluorescentCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandLineFluorescent [counterA*4+counterB];
            //    cout<<" expandLineFluorescent "<<counterA<<endl;
            //}
            
            expandDataPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extensionString2+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
            
            sizeForCopy = 0;
            
            if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (sizeForCopy != 0){
                if (expandLineFluorescentDataStatus == 0){
                    errorNoHold = 5;
                    expandLineFluorescentData = new int [sizeForCopy+50];
                    expandLineFluorescentDataCount = 0;
                    expandLineFluorescentDataStatus = 1;
                    expandLineFluorescentDataLimit = (int)sizeForCopy+50;
                    expandLineFluorescentDataSizeHold = (int)sizeForCopy+50;
                }
                else if (expandLineFluorescentDataStatus == 1 && expandLineFluorescentDataSizeHold < sizeForCopy){
                    delete [] expandLineFluorescentData;
                    
                    errorNoHold = 6;
                    expandLineFluorescentData = new int [sizeForCopy+50];
                    expandLineFluorescentDataCount = 0;
                    expandLineFluorescentDataLimit = (int)sizeForCopy+50;
                    expandLineFluorescentDataSizeHold = (int)sizeForCopy+50;
                }
                else expandLineFluorescentDataCount = 0;
                
                fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    int finData [8];
                    
                    errorNoHold = 7;
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                            errorNoHold = 1003;
                            throw errorCheckThrow;
                        }
                    }
                    
                    fin.close();
                    
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pix
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            
                            if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                            else{
                                
                                expandLineFluorescentData [expandLineFluorescentDataCount] = finData [2], expandLineFluorescentDataCount++;
                                expandLineFluorescentData [expandLineFluorescentDataCount] = finData [3], expandLineFluorescentDataCount++;
                                expandLineFluorescentData [expandLineFluorescentDataCount] = finData [4], expandLineFluorescentDataCount++;
                                expandLineFluorescentData [expandLineFluorescentDataCount] = finData [7], expandLineFluorescentDataCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    errorNoHold = 1004;
                    throw errorCheckThrow;
                }
            }
            else if (expandLineFluorescentDataStatus == 0){
                errorNoHold = 8;
                expandLineFluorescentData = new int [150];
                expandLineFluorescentDataCount = 0;
                expandLineFluorescentDataStatus = 1;
                expandLineFluorescentDataLimit = 150;
                expandLineFluorescentDataSizeHold = 150;
            }
            else expandLineFluorescentDataCount = 0;
            
            //for (int counterA = 0; counterA < expandLineFluorescentDataCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandLineFluorescentData [counterA*4+counterB];
            //    cout<<" expandLineFluorescentData "<<counterA<<endl;
            //}
            
            if (fluorescentMapStatus1 == 0 && fluorescentEntryCount >= 1){
                fluorescentMapStatus1 = 1;
                
                errorNoHold = 9;
                fluorescentMap1 = new int *[imageDimension+1];
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                    errorNoHold = 10;
                    fluorescentMap1 [counter1] = new int [imageDimension+1];
                }
                
                fluorescentMapSizeHold = imageDimension;
            }
            else if (fluorescentMapStatus1 == 1 && fluorescentEntryCount >= 1){
                if (fluorescentMapSizeHold < imageDimension){
                    for (int counter1 = 0; counter1 < fluorescentMapSizeHold+1; counter1++) delete [] fluorescentMap1 [counter1];
                    delete [] fluorescentMap1;
                    
                    errorNoHold = 11;
                    fluorescentMap1 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 12;
                        fluorescentMap1 [counter1] = new int [imageDimension+1];
                    }
                    
                    fluorescentMapSizeHold = imageDimension;
                }
            }
            
            if (fluorescentMapStatus2 == 0 && fluorescentEntryCount >= 2){
                fluorescentMapStatus2 = 1;
                
                errorNoHold = 13;
                fluorescentMap2 = new int *[imageDimension+1];
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                    errorNoHold = 14;
                    fluorescentMap2 [counter1] = new int [imageDimension+1];
                }
            }
            else if (fluorescentMapStatus2 == 1 && fluorescentEntryCount >= 2){
                if (fluorescentMapSizeHold < imageDimension){
                    for (int counter1 = 0; counter1 < fluorescentMapSizeHold+1; counter1++) delete [] fluorescentMap2 [counter1];
                    delete [] fluorescentMap2;
                    
                    errorNoHold = 15;
                    fluorescentMap2 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 16;
                        fluorescentMap2 [counter1] = new int [imageDimension+1];
                    }
                }
            }
            
            if (fluorescentMapStatus3 == 0 && fluorescentEntryCount >= 3){
                fluorescentMapStatus3 = 1;
                
                errorNoHold = 17;
                fluorescentMap3 = new int *[imageDimension+1];
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                    errorNoHold = 18;
                    fluorescentMap3 [counter1] = new int [imageDimension+1];
                }
            }
            else if (fluorescentMapStatus3 == 1 && fluorescentEntryCount >= 3){
                if (fluorescentMapSizeHold < imageDimension){
                    for (int counter1 = 0; counter1 < fluorescentMapSizeHold+1; counter1++) delete [] fluorescentMap3 [counter1];
                    delete [] fluorescentMap3;
                    
                    errorNoHold = 19;
                    fluorescentMap3 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 20;
                        fluorescentMap3 [counter1] = new int [imageDimension+1];
                    }
                    
                    fluorescentMapSizeHold = imageDimension;
                }
            }
            
            if (fluorescentMapStatus4 == 0 && fluorescentEntryCount >= 4){
                fluorescentMapStatus4 = 1;
                
                errorNoHold = 21;
                fluorescentMap4 = new int *[imageDimension+1];
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                    errorNoHold = 22;
                    fluorescentMap4 [counter1] = new int [imageDimension+1];
                }
            }
            else if (fluorescentMapStatus4 == 1 && fluorescentEntryCount >= 4){
                if (fluorescentMapSizeHold < imageDimension){
                    for (int counter1 = 0; counter1 < fluorescentMapSizeHold+1; counter1++) delete [] fluorescentMap4 [counter1];
                    delete [] fluorescentMap4;
                    
                    errorNoHold = 23;
                    fluorescentMap4 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 24;
                        fluorescentMap4 [counter1] = new int [imageDimension+1];
                    }
                    
                    fluorescentMapSizeHold = imageDimension;
                }
            }
            
            if (fluorescentMapStatus5 == 0 && fluorescentEntryCount >= 5){
                fluorescentMapStatus5 = 1;
                
                errorNoHold = 25;
                fluorescentMap5 = new int *[imageDimension+1];
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                    errorNoHold = 26;
                    fluorescentMap5 [counter1] = new int [imageDimension+1];
                }
            }
            else if (fluorescentMapStatus5 == 1 && fluorescentEntryCount >= 5){
                if (fluorescentMapSizeHold < imageDimension){
                    for (int counter1 = 0; counter1 < fluorescentMapSizeHold+1; counter1++) delete [] fluorescentMap5 [counter1];
                    delete [] fluorescentMap5;
                    
                    errorNoHold = 27;
                    fluorescentMap5 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 28;
                        fluorescentMap5 [counter1] = new int [imageDimension+1];
                    }
                    
                    fluorescentMapSizeHold = imageDimension;
                }
            }
            
            if (fluorescentMapStatus6 == 0 && fluorescentEntryCount >= 6){
                fluorescentMapStatus6 = 1;
                
                errorNoHold = 29;
                fluorescentMap6 = new int *[imageDimension+1];
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                    errorNoHold = 30;
                    fluorescentMap6 [counter1] = new int [imageDimension+1];
                }
            }
            else if (fluorescentMapStatus6 == 1 && fluorescentEntryCount >= 6){
                if (fluorescentMapSizeHold < imageDimension){
                    for (int counter1 = 0; counter1 < fluorescentMapSizeHold+1; counter1++) delete [] fluorescentMap6 [counter1];
                    delete [] fluorescentMap6;
                    
                    errorNoHold = 31;
                    fluorescentMap6 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 32;
                        fluorescentMap6 [counter1] = new int [imageDimension+1];
                    }
                    
                    fluorescentMapSizeHold = imageDimension;
                }
            }
            
            if (fluorescentEntryCount >= 1){
                extension2 = to_string(fluorescentNoIF1);
                fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF1+".TIF"+fluorescentRoundNo;
                
                sizeForCopy = 0;
                size1 = 0;
                size2 = 0;
                checkFlag = 0;
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    sizeForCopy = 0;
                    
                    if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter1 == 0) size1 = sizeForCopy;
                        else if (counter1 == 1) size2 = sizeForCopy;
                        else if (counter1 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter1 == 3) size1 = sizeForCopy;
                        else if (counter1 == 4) size2 = sizeForCopy;
                        else if (counter1 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                    errorNoHold = 1005;
                    throw errorCheckThrow;
                }
                
                if (checkFlag == 1){
                    fin.open(fluorescentPath1.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        int dataConversion [4];
                        int endianType = 0;
                        int imageWidthEntry = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        int imageDimensionReadCount = 0;
                        
                        unsigned long headPosition = 0;
                        
                        errorNoHold = 33;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentPath1.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            dataConversion [0] = uploadTemp [0];
                            dataConversion [1] = uploadTemp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTemp [7];
                                dataConversion [1] = uploadTemp [6];
                                dataConversion [2] = uploadTemp [5];
                                dataConversion [3] = uploadTemp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTemp [4];
                                dataConversion [1] = uploadTemp [5];
                                dataConversion [2] = uploadTemp [6];
                                dataConversion [3] = uploadTemp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            imageDimensionReadCount = 0;
                            imageWidthEntry = 0;
                            
                            if (tifImageColorGray == 0){
                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                    fluorescentMap1 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                            else if (tifImageColorGray == 1){
                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                    value0 = uploadTemp [counter3];
                                    value1 = uploadTemp [counter3+1];
                                    value2 = uploadTemp [counter3+2];
                                    
                                    fluorescentMap1 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                }
                else{
                    
                    fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF1+".BMP"+fluorescentRoundNo;
                    
                    sizeForCopy = 0;
                    
                    if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        errorNoHold = 34;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentPath1.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            int imageDimensionReadCount = 0;
                            
                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                    fluorescentMap1 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                }
                                
                                imageDimensionReadCount++;
                            }
                        }
                        else{
                            
                            errorNoHold = 1006;
                            throw errorCheckThrow;
                        }
                        
                        delete [] uploadTemp;
                    }
                }
            }
            
            if (fluorescentEntryCount >= 2){
                extension2 = to_string(fluorescentNoIF2);
                fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF2+".TIF"+fluorescentRoundNo;
                
                size1 = 0;
                size2 = 0;
                checkFlag = 0;
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    sizeForCopy = 0;
                    
                    if (stat(fluorescentPath2.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter1 == 0) size1 = sizeForCopy;
                        else if (counter1 == 1) size2 = sizeForCopy;
                        else if (counter1 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter1 == 3) size1 = sizeForCopy;
                        else if (counter1 == 4) size2 = sizeForCopy;
                        else if (counter1 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                if (stat(fluorescentPath2.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                    errorNoHold = 1007;
                    throw errorCheckThrow;
                }
                
                if (checkFlag == 1){
                    fin.open(fluorescentPath2.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        int dataConversion [4];
                        int endianType = 0;
                        int imageWidthEntry = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        int imageDimensionReadCount = 0;
                        
                        unsigned long headPosition = 0;
                        
                        errorNoHold = 35;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentPath2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            dataConversion [0] = uploadTemp [0];
                            dataConversion [1] = uploadTemp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTemp [7];
                                dataConversion [1] = uploadTemp [6];
                                dataConversion [2] = uploadTemp [5];
                                dataConversion [3] = uploadTemp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTemp [4];
                                dataConversion [1] = uploadTemp [5];
                                dataConversion [2] = uploadTemp [6];
                                dataConversion [3] = uploadTemp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            imageDimensionReadCount = 0;
                            imageWidthEntry = 0;
                            
                            if (tifImageColorGray == 0){
                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                    fluorescentMap2 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                            else if (tifImageColorGray == 1){
                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                    value0 = uploadTemp [counter3];
                                    value1 = uploadTemp [counter3+1];
                                    value2 = uploadTemp [counter3+2];
                                    
                                    fluorescentMap2 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                }
                else{
                    
                    fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF2+".BMP"+fluorescentRoundNo;
                    
                    sizeForCopy = 0;
                    
                    if (stat(fluorescentPath2.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        errorNoHold = 36;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentPath2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            int imageDimensionReadCount = 0;
                            
                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                    fluorescentMap2 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                }
                                
                                imageDimensionReadCount++;
                            }
                        }
                        else{
                            
                            errorNoHold = 1008;
                            throw errorCheckThrow;
                        }
                        
                        delete [] uploadTemp;
                    }
                }
            }
            
            if (fluorescentEntryCount >= 3){
                extension2 = to_string(fluorescentNoIF3);
                fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF3+".TIF"+fluorescentRoundNo;
                
                size1 = 0;
                size2 = 0;
                checkFlag = 0;
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    sizeForCopy = 0;
                    
                    if (stat(fluorescentPath3.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter1 == 0) size1 = sizeForCopy;
                        else if (counter1 == 1) size2 = sizeForCopy;
                        else if (counter1 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter1 == 3) size1 = sizeForCopy;
                        else if (counter1 == 4) size2 = sizeForCopy;
                        else if (counter1 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                if (stat(fluorescentPath3.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                    errorNoHold = 1009;
                    throw errorCheckThrow;
                }
                
                if (checkFlag == 1){
                    fin.open(fluorescentPath3.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        int dataConversion [4];
                        int endianType = 0;
                        int imageWidthEntry = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        int imageDimensionReadCount = 0;
                        
                        unsigned long headPosition = 0;
                        
                        errorNoHold = 37;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentPath3.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            dataConversion [0] = uploadTemp [0];
                            dataConversion [1] = uploadTemp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTemp [7];
                                dataConversion [1] = uploadTemp [6];
                                dataConversion [2] = uploadTemp [5];
                                dataConversion [3] = uploadTemp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTemp [4];
                                dataConversion [1] = uploadTemp [5];
                                dataConversion [2] = uploadTemp [6];
                                dataConversion [3] = uploadTemp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            imageDimensionReadCount = 0;
                            imageWidthEntry = 0;
                            
                            if (tifImageColorGray == 0){
                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                    fluorescentMap3 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                            else if (tifImageColorGray == 1){
                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                    value0 = uploadTemp [counter3];
                                    value1 = uploadTemp [counter3+1];
                                    value2 = uploadTemp [counter3+2];
                                    
                                    fluorescentMap3 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                }
                else{
                    
                    fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF3+".BMP"+fluorescentRoundNo;
                    
                    sizeForCopy = 0;
                    
                    if (stat(fluorescentPath3.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        errorNoHold = 38;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentPath3.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            int imageDimensionReadCount = 0;
                            
                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                    fluorescentMap3 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                }
                                
                                imageDimensionReadCount++;
                            }
                        }
                        else{
                            
                            errorNoHold = 1010;
                            throw errorCheckThrow;
                        }
                        
                        delete [] uploadTemp;
                    }
                }
            }
            
            if (fluorescentEntryCount >= 4){
                extension2 = to_string(fluorescentNoIF4);
                fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF4+".TIF"+fluorescentRoundNo;
                
                size1 = 0;
                size2 = 0;
                checkFlag = 0;
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    sizeForCopy = 0;
                    
                    if (stat(fluorescentPath4.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter1 == 0) size1 = sizeForCopy;
                        else if (counter1 == 1) size2 = sizeForCopy;
                        else if (counter1 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter1 == 3) size1 = sizeForCopy;
                        else if (counter1 == 4) size2 = sizeForCopy;
                        else if (counter1 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                if (stat(fluorescentPath4.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                    errorNoHold = 1011;
                    throw errorCheckThrow;
                }
                
                if (checkFlag == 1){
                    fin.open(fluorescentPath4.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        int dataConversion [4];
                        int endianType = 0;
                        int imageWidthEntry = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        int imageDimensionReadCount = 0;
                        
                        unsigned long headPosition = 0;
                        
                        errorNoHold = 39;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentPath4.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            dataConversion [0] = uploadTemp [0];
                            dataConversion [1] = uploadTemp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTemp [7];
                                dataConversion [1] = uploadTemp [6];
                                dataConversion [2] = uploadTemp [5];
                                dataConversion [3] = uploadTemp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTemp [4];
                                dataConversion [1] = uploadTemp [5];
                                dataConversion [2] = uploadTemp [6];
                                dataConversion [3] = uploadTemp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            imageDimensionReadCount = 0;
                            imageWidthEntry = 0;
                            
                            if (tifImageColorGray == 0){
                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                    fluorescentMap4 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                            else if (tifImageColorGray == 1){
                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                    value0 = uploadTemp [counter3];
                                    value1 = uploadTemp [counter3+1];
                                    value2 = uploadTemp [counter3+2];
                                    
                                    fluorescentMap4 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                }
                else{
                    
                    fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF4+".BMP"+fluorescentRoundNo;
                    
                    sizeForCopy = 0;
                    
                    if (stat(fluorescentPath4.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        errorNoHold = 40;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentPath4.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            int imageDimensionReadCount = 0;
                            
                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                    fluorescentMap4 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                }
                                
                                imageDimensionReadCount++;
                            }
                        }
                        else{
                            
                            errorNoHold = 1012;
                            throw errorCheckThrow;
                        }
                        
                        delete [] uploadTemp;
                    }
                }
            }
            
            if (fluorescentEntryCount >= 5){
                extension2 = to_string(fluorescentNoIF5);
                fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF5+".TIF"+fluorescentRoundNo;
                
                size1 = 0;
                size2 = 0;
                checkFlag = 0;
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    sizeForCopy = 0;
                    
                    if (stat(fluorescentPath5.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter1 == 0) size1 = sizeForCopy;
                        else if (counter1 == 1) size2 = sizeForCopy;
                        else if (counter1 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter1 == 3) size1 = sizeForCopy;
                        else if (counter1 == 4) size2 = sizeForCopy;
                        else if (counter1 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                if (stat(fluorescentPath5.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                    errorNoHold = 1013;
                    throw errorCheckThrow;
                }
                
                if (checkFlag == 1){
                    fin.open(fluorescentPath5.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        int dataConversion [4];
                        int endianType = 0;
                        int imageWidthEntry = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        int imageDimensionReadCount = 0;
                        
                        unsigned long headPosition = 0;
                        
                        errorNoHold = 41;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentPath5.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            dataConversion [0] = uploadTemp [0];
                            dataConversion [1] = uploadTemp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTemp [7];
                                dataConversion [1] = uploadTemp [6];
                                dataConversion [2] = uploadTemp [5];
                                dataConversion [3] = uploadTemp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTemp [4];
                                dataConversion [1] = uploadTemp [5];
                                dataConversion [2] = uploadTemp [6];
                                dataConversion [3] = uploadTemp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            imageDimensionReadCount = 0;
                            imageWidthEntry = 0;
                            
                            if (tifImageColorGray == 0){
                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                    fluorescentMap5 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                            else if (tifImageColorGray == 1){
                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                    value0 = uploadTemp [counter3];
                                    value1 = uploadTemp [counter3+1];
                                    value2 = uploadTemp [counter3+2];
                                    
                                    fluorescentMap5 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                }
                else{
                    
                    fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF5+".BMP"+fluorescentRoundNo;
                    
                    sizeForCopy = 0;
                    
                    if (stat(fluorescentPath5.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        errorNoHold = 42;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentPath3.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            int imageDimensionReadCount = 0;
                            
                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                    fluorescentMap5 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                }
                                
                                imageDimensionReadCount++;
                            }
                        }
                        else{
                            
                            errorNoHold = 1014;
                            throw errorCheckThrow;
                        }
                        
                        delete [] uploadTemp;
                    }
                }
            }
            
            if (fluorescentEntryCount >= 6){
                extension2 = to_string(fluorescentNoIF6);
                fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF6+".TIF"+fluorescentRoundNo;
                
                size1 = 0;
                size2 = 0;
                checkFlag = 0;
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    sizeForCopy = 0;
                    
                    if (stat(fluorescentPath6.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter1 == 0) size1 = sizeForCopy;
                        else if (counter1 == 1) size2 = sizeForCopy;
                        else if (counter1 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter1 == 3) size1 = sizeForCopy;
                        else if (counter1 == 4) size2 = sizeForCopy;
                        else if (counter1 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                if (stat(fluorescentPath6.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                    errorNoHold = 1015;
                    throw errorCheckThrow;
                }
                
                if (checkFlag == 1){
                    fin.open(fluorescentPath6.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        int dataConversion [4];
                        int endianType = 0;
                        int imageWidthEntry = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        int imageDimensionReadCount = 0;
                        
                        unsigned long headPosition = 0;
                        
                        errorNoHold = 43;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentPath6.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            dataConversion [0] = uploadTemp [0];
                            dataConversion [1] = uploadTemp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTemp [7];
                                dataConversion [1] = uploadTemp [6];
                                dataConversion [2] = uploadTemp [5];
                                dataConversion [3] = uploadTemp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTemp [4];
                                dataConversion [1] = uploadTemp [5];
                                dataConversion [2] = uploadTemp [6];
                                dataConversion [3] = uploadTemp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            imageDimensionReadCount = 0;
                            imageWidthEntry = 0;
                            
                            if (tifImageColorGray == 0){
                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                    fluorescentMap6 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                            else if (tifImageColorGray == 1){
                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                    value0 = uploadTemp [counter3];
                                    value1 = uploadTemp [counter3+1];
                                    value2 = uploadTemp [counter3+2];
                                    
                                    fluorescentMap6 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                }
                else{
                    
                    fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentNameIF6+".BMP"+fluorescentRoundNo;
                    
                    if (stat(fluorescentPath6.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        errorNoHold = 44;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentPath6.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            int imageDimensionReadCount = 0;
                            
                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                    fluorescentMap6 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                }
                                
                                imageDimensionReadCount++;
                            }
                        }
                        else{
                            
                            errorNoHold = 1016;
                            throw errorCheckThrow;
                        }
                        
                        delete [] uploadTemp;
                    }
                }
            }
            
            [self fluorescentProcess];
            if (errorNoHold != 0){
                errorNoHold = errorNoHold+2000;
                throw errorCheckThrow;
            }
            
            string cellLineageExtract = cellLineageNoHold.substr(1);
            string cellNumberExtract = cellNoHold.substr(1);
            int cellLineageTempInt = atoi(cellLineageExtract.c_str());
            int cellNumberTempInt = atoi(cellNumberExtract.c_str());
            
            eventSequenceCount = 0;
            
            arrayEventSequence [0] = imageNumberInt, eventSequenceCount++;
            arrayEventSequence [1] = 2, eventSequenceCount++;
            arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++;
            arrayEventSequence [eventSequenceCount] = cellNumberTempInt, eventSequenceCount++;
            
            //------Set target to connect Rel------
            int connectNoIFTemp = 0;
            
            for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt){
                    connectNoIFTemp = arrayConnectLineageRel [counter1*6+1];
                    break;
                }
            }
            
            for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                if (arrayGravityCenterRev [counter1*6+4] == connectNoIFTemp){
                    gravityCenterXHold1 = arrayGravityCenterRev [counter1*6];
                    gravityCenterYHold1 = arrayGravityCenterRev [counter1*6+1];
                    gravityAverageHold1 = arrayGravityCenterRev [counter1*6+3];
                    gravityCellNo1 = cellNumberTempInt;
                    break;
                }
            }
            
            errorNoHold = 45;
            int *arrayExpandTemp = new int [expandLineFluorescentCount+50];
            int expandTempCount = 0;
            
            for (int counter1 = 0; counter1 < expandLineFluorescentCount/7; counter1++){
                if (expandLineFluorescent [counter1*7+2] != targetConnectInitial){
                    arrayExpandTemp [expandTempCount] = expandLineFluorescent [counter1*7], expandTempCount++;
                    arrayExpandTemp [expandTempCount] = expandLineFluorescent [counter1*7+1], expandTempCount++;
                    arrayExpandTemp [expandTempCount] = expandLineFluorescent [counter1*7+2], expandTempCount++;
                    arrayExpandTemp [expandTempCount] = expandLineFluorescent [counter1*7+3], expandTempCount++;
                    arrayExpandTemp [expandTempCount] = expandLineFluorescent [counter1*7+4], expandTempCount++;
                    arrayExpandTemp [expandTempCount] = expandLineFluorescent [counter1*7+5], expandTempCount++;
                    arrayExpandTemp [expandTempCount] = expandLineFluorescent [counter1*7+6], expandTempCount++;
                }
            }
            
            expandLineFluorescentCount = 0;
            for (int counter1 = 0; counter1 < expandTempCount; counter1++) expandLineFluorescent [expandLineFluorescentCount] = arrayExpandTemp [counter1], expandLineFluorescentCount++;
            delete [] arrayExpandTemp;
            
            errorNoHold = 46;
            int *arrayExpandDataTemp = new int [expandLineFluorescentDataCount+50];
            int expandDataTempCount = 0;
            
            for (int counter1 = 0; counter1 < expandLineFluorescentDataCount/7; counter1++){
                if (expandLineFluorescentData [counter1*7] != targetConnectInitial){
                    arrayExpandDataTemp [expandDataTempCount] = expandLineFluorescentData [counter1*7], expandDataTempCount++;
                    arrayExpandDataTemp [expandDataTempCount] = expandLineFluorescentData [counter1*7+1], expandDataTempCount++;
                    arrayExpandDataTemp [expandDataTempCount] = expandLineFluorescentData [counter1*7+2], expandDataTempCount++;
                    arrayExpandDataTemp [expandDataTempCount] = expandLineFluorescentData [counter1*7+3], expandDataTempCount++;
                    arrayExpandDataTemp [expandDataTempCount] = expandLineFluorescentData [counter1*7+4], expandDataTempCount++;
                    arrayExpandDataTemp [expandDataTempCount] = expandLineFluorescentData [counter1*7+5], expandDataTempCount++;
                    arrayExpandDataTemp [expandDataTempCount] = expandLineFluorescentData [counter1*7+6], expandDataTempCount++;
                }
            }
            
            expandLineFluorescentDataCount = 0;
            for (int counter1 = 0; counter1 < expandDataTempCount; counter1++) expandLineFluorescentData [expandLineFluorescentDataCount] = arrayExpandDataTemp [counter1], expandLineFluorescentDataCount++;
            delete [] arrayExpandDataTemp;
            
            int returnData = 0;
            int processTypeFluorescent = 1;
            
            if (autoExpand == 1){
                merge = [[Merge alloc] init];
                returnData = [merge lineExtendTrackType2:targetConnectInitial:processTypeFluorescent];
                
                do{
                } while(subCompletionFlag2 == 1);
                
                if (errorNoHold != 0){
                    errorNoHold = errorNoHold+2000;
                    throw errorCheckThrow;
                }
            }
            
            if (autoExpand == 0 || returnData == 1){
                for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                    if (arrayPositionRevise [counter1*7+3] == targetConnectInitial){
                        if (expandLineFluorescentCount+20 > expandLineFluorescentLimit){
                            [self expandLineFluorescentUpDate];
                            if (errorNoHold != 0){
                                errorNoHold = errorNoHold+2000;
                                throw errorCheckThrow;
                            }
                        }
                        
                        expandLineFluorescent [expandLineFluorescentCount] = arrayPositionRevise [counter1*7], expandLineFluorescentCount++;
                        expandLineFluorescent [expandLineFluorescentCount] = arrayPositionRevise [counter1*7+1], expandLineFluorescentCount++;
                        expandLineFluorescent [expandLineFluorescentCount] = targetConnectInitial, expandLineFluorescentCount++;
                        expandLineFluorescent [expandLineFluorescentCount] = 7, expandLineFluorescentCount++;
                    }
                }
                
                if (fluorescentEntryCount >= 2){
                    for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                        if (arrayPositionRevise [counter1*7+3] == targetConnectInitial){
                            if (expandLineFluorescentCount+20 > expandLineFluorescentLimit){
                                [self expandLineFluorescentUpDate];
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                            }
                            
                            expandLineFluorescent [expandLineFluorescentCount] = arrayPositionRevise [counter1*7], expandLineFluorescentCount++;
                            expandLineFluorescent [expandLineFluorescentCount] = arrayPositionRevise [counter1*7+1], expandLineFluorescentCount++;
                            expandLineFluorescent [expandLineFluorescentCount] = targetConnectInitial, expandLineFluorescentCount++;
                            expandLineFluorescent [expandLineFluorescentCount] = 8, expandLineFluorescentCount++;
                        }
                    }
                }
                
                if (fluorescentEntryCount >= 3){
                    for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                        if (arrayPositionRevise [counter1*7+3] == targetConnectInitial){
                            if (expandLineFluorescentCount+20 > expandLineFluorescentLimit){
                                [self expandLineFluorescentUpDate];
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                            }
                            
                            expandLineFluorescent [expandLineFluorescentCount] = arrayPositionRevise [counter1*7], expandLineFluorescentCount++;
                            expandLineFluorescent [expandLineFluorescentCount] = arrayPositionRevise [counter1*7+1], expandLineFluorescentCount++;
                            expandLineFluorescent [expandLineFluorescentCount] = targetConnectInitial, expandLineFluorescentCount++;
                            expandLineFluorescent [expandLineFluorescentCount] = 9, expandLineFluorescentCount++;
                        }
                    }
                }
                
                if (fluorescentEntryCount >= 4){
                    for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                        if (arrayPositionRevise [counter1*7+3] == targetConnectInitial){
                            if (expandLineFluorescentCount+20 > expandLineFluorescentLimit){
                                [self expandLineFluorescentUpDate];
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                            }
                            
                            expandLineFluorescent [expandLineFluorescentCount] = arrayPositionRevise [counter1*7], expandLineFluorescentCount++;
                            expandLineFluorescent [expandLineFluorescentCount] = arrayPositionRevise [counter1*7+1], expandLineFluorescentCount++;
                            expandLineFluorescent [expandLineFluorescentCount] = targetConnectInitial, expandLineFluorescentCount++;
                            expandLineFluorescent [expandLineFluorescentCount] = 10, expandLineFluorescentCount++;
                        }
                    }
                }
                
                if (fluorescentEntryCount >= 5){
                    for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                        if (arrayPositionRevise [counter1*7+3] == targetConnectInitial){
                            if (expandLineFluorescentCount+20 > expandLineFluorescentLimit){
                                [self expandLineFluorescentUpDate];
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                            }
                            
                            expandLineFluorescent [expandLineFluorescentCount] = arrayPositionRevise [counter1*7], expandLineFluorescentCount++;
                            expandLineFluorescent [expandLineFluorescentCount] = arrayPositionRevise [counter1*7+1], expandLineFluorescentCount++;
                            expandLineFluorescent [expandLineFluorescentCount] = targetConnectInitial, expandLineFluorescentCount++;
                            expandLineFluorescent [expandLineFluorescentCount] = 11, expandLineFluorescentCount++;
                        }
                    }
                }
                
                if (fluorescentEntryCount >= 6){
                    for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                        if (arrayPositionRevise [counter1*7+3] == targetConnectInitial){
                            if (expandLineFluorescentCount+20 > expandLineFluorescentLimit){
                                [self expandLineFluorescentUpDate];
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                            }
                            
                            expandLineFluorescent [expandLineFluorescentCount] = arrayPositionRevise [counter1*7], expandLineFluorescentCount++;
                            expandLineFluorescent [expandLineFluorescentCount] = arrayPositionRevise [counter1*7+1], expandLineFluorescentCount++;
                            expandLineFluorescent [expandLineFluorescentCount] = targetConnectInitial, expandLineFluorescentCount++;
                            expandLineFluorescent [expandLineFluorescentCount] = 12, expandLineFluorescentCount++;
                        }
                    }
                }
                
                int pixelValueTemp = 0;
                int pixelAreaTemp = 0;
                int pixelValueTemp2 = 0;
                int pixelAreaTemp2 = 0;
                int pixelValueTemp3 = 0;
                int pixelAreaTemp3 = 0;
                int pixelValueTemp4 = 0;
                int pixelAreaTemp4 = 0;
                int pixelValueTemp5 = 0;
                int pixelAreaTemp5 = 0;
                int pixelValueTemp6 = 0;
                int pixelAreaTemp6 = 0;
                
                for (int counterY = 0; counterY < imageDimension; counterY++){
                    for (int counterX = 0; counterX < imageDimension; counterX++){
                        if (revisedWorkingMap [counterY][counterX] == targetConnectInitial){
                            if (fluorescentEntryCount >= 1){
                                if (fluorescentCutOff1 >= fluorescentMap1 [counterY][counterX]) pixelValueTemp = pixelValueTemp+fluorescentMap1 [counterY][counterX];
                                pixelAreaTemp++;
                            }
                            if (fluorescentEntryCount >= 2){
                                if (fluorescentCutOff2 >= fluorescentMap2 [counterY][counterX]) pixelValueTemp2 = pixelValueTemp2+fluorescentMap2 [counterY][counterX];
                                pixelAreaTemp2++;
                            }
                            if (fluorescentEntryCount >= 3){
                                if (fluorescentCutOff3 >= fluorescentMap3 [counterY][counterX]) pixelValueTemp3 = pixelValueTemp3+fluorescentMap3 [counterY][counterX];
                                pixelAreaTemp3++;
                            }
                            if (fluorescentEntryCount >= 4){
                                if (fluorescentCutOff4 >= fluorescentMap4 [counterY][counterX]) pixelValueTemp4 = pixelValueTemp4+fluorescentMap4 [counterY][counterX];
                                pixelAreaTemp4++;
                            }
                            if (fluorescentEntryCount >= 5){
                                if (fluorescentCutOff5 >= fluorescentMap5 [counterY][counterX]) pixelValueTemp5 = pixelValueTemp5+fluorescentMap5 [counterY][counterX];
                                pixelAreaTemp5++;
                            }
                            if (fluorescentEntryCount >= 6){
                                if (fluorescentCutOff6 >= fluorescentMap6 [counterY][counterX]) pixelValueTemp6 = pixelValueTemp6+fluorescentMap6 [counterY][counterX];
                                pixelAreaTemp6++;
                            }
                        }
                    }
                }
                
                double averageArea = pixelValueTemp/(double)pixelAreaTemp;
                
                if (expandLineFluorescentDataCount+20 > expandLineFluorescentDataLimit){
                    [self expandLineFluorescentDataUpDate];
                    if (errorNoHold != 0){
                        errorNoHold = errorNoHold+2000;
                        throw errorCheckThrow;
                    }
                }
                
                expandLineFluorescentData [expandLineFluorescentDataCount] = targetConnectInitial, expandLineFluorescentDataCount++;
                expandLineFluorescentData [expandLineFluorescentDataCount] = 7, expandLineFluorescentDataCount++;
                expandLineFluorescentData [expandLineFluorescentDataCount] = (int)averageArea, expandLineFluorescentDataCount++;
                expandLineFluorescentData [expandLineFluorescentDataCount] = pixelAreaTemp, expandLineFluorescentDataCount++;
                
                if (fluorescentEntryCount >= 2){
                    averageArea = pixelValueTemp2/(double)pixelAreaTemp2;
                    
                    expandLineFluorescentData [expandLineFluorescentDataCount] = targetConnectInitial, expandLineFluorescentDataCount++;
                    expandLineFluorescentData [expandLineFluorescentDataCount] = 8, expandLineFluorescentDataCount++;
                    expandLineFluorescentData [expandLineFluorescentDataCount] = (int)averageArea, expandLineFluorescentDataCount++;
                    expandLineFluorescentData [expandLineFluorescentDataCount] = pixelAreaTemp2, expandLineFluorescentDataCount++;
                }
                
                if (fluorescentEntryCount >= 3){
                    averageArea = pixelValueTemp3/(double)pixelAreaTemp3;
                    
                    expandLineFluorescentData [expandLineFluorescentDataCount] = targetConnectInitial, expandLineFluorescentDataCount++;
                    expandLineFluorescentData [expandLineFluorescentDataCount] = 9, expandLineFluorescentDataCount++;
                    expandLineFluorescentData [expandLineFluorescentDataCount] = (int)averageArea, expandLineFluorescentDataCount++;
                    expandLineFluorescentData [expandLineFluorescentDataCount] = pixelAreaTemp3, expandLineFluorescentDataCount++;
                }
                
                if (fluorescentEntryCount >= 4){
                    averageArea = pixelValueTemp4/(double)pixelAreaTemp4;
                    
                    expandLineFluorescentData [expandLineFluorescentDataCount] = targetConnectInitial, expandLineFluorescentDataCount++;
                    expandLineFluorescentData [expandLineFluorescentDataCount] = 10, expandLineFluorescentDataCount++;
                    expandLineFluorescentData [expandLineFluorescentDataCount] = (int)averageArea, expandLineFluorescentDataCount++;
                    expandLineFluorescentData [expandLineFluorescentDataCount] = pixelAreaTemp4, expandLineFluorescentDataCount++;
                }
                
                if (fluorescentEntryCount >= 5){
                    averageArea = pixelValueTemp3/(double)pixelAreaTemp5;
                    
                    expandLineFluorescentData [expandLineFluorescentDataCount] = targetConnectInitial, expandLineFluorescentDataCount++;
                    expandLineFluorescentData [expandLineFluorescentDataCount] = 11, expandLineFluorescentDataCount++;
                    expandLineFluorescentData [expandLineFluorescentDataCount] = (int)averageArea, expandLineFluorescentDataCount++;
                    expandLineFluorescentData [expandLineFluorescentDataCount] = pixelAreaTemp5, expandLineFluorescentDataCount++;
                }
                
                if (fluorescentEntryCount >= 6){
                    averageArea = pixelValueTemp3/(double)pixelAreaTemp6;
                    
                    expandLineFluorescentData [expandLineFluorescentDataCount] = targetConnectInitial, expandLineFluorescentDataCount++;
                    expandLineFluorescentData [expandLineFluorescentDataCount] = 12, expandLineFluorescentDataCount++;
                    expandLineFluorescentData [expandLineFluorescentDataCount] = (int)averageArea, expandLineFluorescentDataCount++;
                    expandLineFluorescentData [expandLineFluorescentDataCount] = pixelAreaTemp6, expandLineFluorescentDataCount++;
                }
            }
            
            int processType = 3;
            trackingDataSave = [[TrackingDataSave alloc] init];
            [trackingDataSave trackingDataSaveTemp:processType];
            
            do{
            } while(subCompletionFlag == 1);
            
            if (errorNoHold != 0){
                errorNoHold = errorNoHold+2000;
                throw errorCheckThrow;
            }
            
            returnMessage = "NX";
            returnMessageTime = to_string(imageNumberInt);
            returnMessageExt = "0";
            
            firstCommunication = 4;
            errorNoHold = 0;
        }
        catch (int errorCheckThrow){
            if (errorNoHold >= 1000 && errorNoHold < 2000){
                string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
                mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                time_t rawtime;
                struct tm * timeinfo;
                time (&rawtime);
                timeinfo = localtime ( &rawtime );
                
                int tsec = timeinfo -> tm_sec;
                int tmin = timeinfo -> tm_min;
                int thour = timeinfo -> tm_hour;
                int tday = timeinfo -> tm_mday;
                int tmon = timeinfo -> tm_mon;
                
                string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
                
                errorPath = errorPath+"/Cell_CarvingImageProcessingIF01 "+dateTime;
                
                ofstream oin2;
                oin2.open(errorPath.c_str(), ios::out);
                oin2<<"ImageProcessingIF"<<endl;
                oin2<<errorNoHold<<endl;
                oin2<<analysisImageName<<endl;
                oin2<<analysisID<<endl;
                oin2<<treatmentNameHold<<endl;
                oin2<<cellLineageNoHold<<endl;
                oin2<<cellNoHold<<endl;
                oin2<<dateTime<<endl;
                
                if (errorNoHold == 1000) oin2<<"ExpandLine reading error"<<endl;
                else if (errorNoHold == 1001) oin2<<"ExpandLine uploading error"<<endl;
                else if (errorNoHold == 1002) oin2<<"ExpandLine open-error"<<endl;
                else if (errorNoHold == 1003) oin2<<"ExpandArea uploading error"<<endl;
                else if (errorNoHold == 1004) oin2<<"ExpandArea open-error"<<endl;
                else if (errorNoHold >= 1005 && errorNoHold >= 1016) oin2<<"Fluorescent image (tif/bmp) open-error"<<endl;
                oin2.close();
            }
            
            emergencyExit = 1;
            firstCommunication = 20;
            
            subCompletionFlag = 0;
        }
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingImageProcessingIF02 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"ImageProcessingIF"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        emergencyExit = 1;
        firstCommunication = 20;
    }
}

-(void)fluorescentProcess{
    try{
        
        errorNoHold = 0;
        
        ifstream fin;
        
        string extension = to_string(imageNumberInt);
        
        if (extension.length() == 1) extension = "000"+extension;
        else if (extension.length() == 2) extension = "00"+extension;
        else if (extension.length() == 3) extension = "0"+extension;
        
        string extension2 = to_string(fluorescentNo1);
        
        string fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+".tif";
        
        fin.open(fluorescentPath1.c_str(), ios::in);
        
        if (!fin.is_open()){
            fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+".bmp";
        }
        else fin.close();
        
        struct stat sizeOfFile;
        
        if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0){
            int matchFind = 0;
            
            for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                if (arrayFluorescentCutOff [counter1*7] == imageNumberInt){
                    fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                    fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                    fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                    fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                    fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                    fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                    matchFind = 1;
                    break;
                }
            }
            
            if (matchFind == 0){
                string cutOffPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
                
                if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                    int nearestCount = 0;
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                        if (arrayFluorescentCutOff [counter1*7] < imageNumberInt){
                            if (nearestCount < arrayFluorescentCutOff [counter1*7]){
                                nearestCount = arrayFluorescentCutOff [counter1*7];
                                fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                                fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                                fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                            }
                        }
                    }
                    
                    if (fluorescentCutOffStatus == 0){
                        errorNoHold = 47;
                        arrayFluorescentCutOff = new int [imageEndHold*4];
                        fluorescentCutOffCount = 0;
                        fluorescentCutOffStatus = 1;
                    }
                    
                    if (nearestCount != 0){
                        arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberInt, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
                    }
                    else{
                        
                        arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberInt, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    }
                    
                    ofstream oin;
                    oin.open(cutOffPath.c_str(), ios::out);
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                    oin<<"End"<<endl;
                    oin.close();
                }
                else{
                    
                    fluorescentCutOff1 = 150;
                    fluorescentCutOff2 = 150;
                    fluorescentCutOff3 = 150;
                    fluorescentCutOff4 = 150;
                    fluorescentCutOff5 = 150;
                    fluorescentCutOff6 = 150;
                    
                    if (fluorescentCutOffStatus == 0){
                        errorNoHold = 48;
                        arrayFluorescentCutOff = new int [imageEndHold*7];
                        fluorescentCutOffCount = 0;
                        fluorescentCutOffStatus = 1;
                    }
                    
                    arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberInt, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    
                    ofstream oin;
                    oin.open(cutOffPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                    
                    oin<<"End"<<endl;
                    oin.close();
                }
            }
        }
        
        errorNoHold = 0;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingImageProcessingIF03 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"ImageProcessingIF-fluorescentProcess"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
    }
}

-(void)referenceLineCountUpDate{
    try{
        
        errorNoHold = 0;
        
        int *arrayUpDate = new int [referenceLineCount+10];
        
        for (int counter1 = 0; counter1 < referenceLineCount; counter1++) arrayUpDate [counter1] = arrayReferenceLine [counter1];
        
        delete [] arrayReferenceLine;
        arrayReferenceLine = new int [referenceLineLimit+5000];
        referenceLineLimit = referenceLineLimit+5000;
        
        for (int counter1 = 0; counter1 < referenceLineCount; counter1++) arrayReferenceLine [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingImageProcessingIF04 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"ImageProcessingIF-referenceLineCountUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

-(void)expandLineFluorescentUpDate{
    try{
        
        errorNoHold = 0;
        
        int *arrayUpDate = new int [expandLineFluorescentCount+10];
        
        for (int counter1 = 0; counter1 < expandLineFluorescentCount; counter1++) arrayUpDate [counter1] = expandLineFluorescent [counter1];
        
        delete [] expandLineFluorescent;
        expandLineFluorescent = new int [expandLineFluorescentLimit*4+10000];
        expandLineFluorescentLimit = expandLineFluorescentLimit*4+10000;
        
        for (int counter1 = 0; counter1 < expandLineFluorescentCount; counter1++) expandLineFluorescent [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
        
        expandLineFluorescentSizeHold = expandLineFluorescentLimit*4+10000;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingImageProcessingIF05 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"ImageProcessingIF-expandLineFluorescentUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

-(void)expandLineFluorescentDataUpDate{
    try{
        
        errorNoHold = 0;
        
        int *arrayUpDate = new int [expandLineFluorescentDataCount+10];
        
        for (int counter1 = 0; counter1 < expandLineFluorescentDataCount; counter1++) arrayUpDate [counter1] = expandLineFluorescentData [counter1];
        
        delete [] expandLineFluorescentData;
        expandLineFluorescentData = new int [expandLineFluorescentDataLimit*4+10000];
        expandLineFluorescentDataLimit = expandLineFluorescentDataLimit*4+10000;
        
        for (int counter1 = 0; counter1 < expandLineFluorescentDataCount; counter1++) expandLineFluorescentData [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
        
        expandLineFluorescentDataSizeHold = expandLineFluorescentDataLimit*4+10000;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingImageProcessingIF06 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"ImageProcessingIF-expandLineFluorescentDataUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToImageProcessingIF object:nil];
}

@end
