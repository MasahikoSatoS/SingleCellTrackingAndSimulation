//
//  TargetTrack2.h
//  Cell_Carving
//
//  Created by Masahiko Sato on 2015-04-01.
//
//

#ifndef TARGETTRACK2_H
#define TARGETTRACK2_H
#import "Controller.h"
#endif

@interface TargetTrack2 : NSObject{
    id targetPrevious;
    id targetCurrent;
}

-(int)targetTrackProcess :(int)forceSet;

@end
