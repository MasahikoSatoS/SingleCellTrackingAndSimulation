//
//  ImageProcessingIF.h
//  Cell_Carving
//
//  Created by Masahiko Sato on 2015-12-22.
//
//

#ifndef IMAGEPROCESSINGIF_H
#define IMAGEPROCESSINGIF_H
#import "Controller.h"
#endif

@interface ImageProcessingIF : NSObject{
    id trackingDataSave;
    id merge;
}

-(id)init;
-(void)dealloc;

-(void)fluorescentProcess;
-(void)expandLineFluorescentUpDate;
-(void)expandLineFluorescentDataUpDate;

@end
