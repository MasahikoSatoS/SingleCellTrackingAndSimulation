//
// TargetCurrent.mm
// cell_carving
//
// Created by Masahiko Sato on 13/06/04.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "TargetCurrent.h"

@implementation TargetCurrent

-(void)targetCurrentMain:(int)roundTwo{
    try{
        try{
            
            errorNoHold = 0;
            int errorCheckThrow = 0;
            subCompletionFlag2 = 1;
            
            int previousPairAddition = arrayCellTrackingPreviousAss [(cellTrackingPreviousAssCount/6-1)*6];
            
            //------Connectivity map based on outline vector------
            int lineNumberOriginalCurrent2 = cellTrackingCurrentAssCount/6;
            int terminationFlagLoop = 1;
            int lineNumberPrevious2 = 0;
            int lineNumberCurrent2 = 0;
            int maxTargetEntry = 0;
            int targetPointer = 0;
            int noMergeTableCount = 0;
            int noMergeTableLimit = 0;
            int additionCount = 0;
            int maxConnect = 0;
            int numberOfEntry = 0;
            int previousConnectNumber1 = 0;
            int previousIntensity = 0;
            int previousDimension = 0;
            int currentMajor = 0;
            int majorIntensity = 0;
            int majorPair = 0;
            int majorProcess = 0;
            int majorDimension = 0;
            int connectMajorCurrentA1 = 0;
            int connectMajorCurrentB1 = 0;
            int connectMajorCurrentC1 = 0;
            int connectMajorCurrentCountA1 = 0;
            int connectMajorCurrentCountB1 = 0;
            int connectMajorCurrentCountC1 = 0;
            int attachTemp = 0;
            int numberOfAttach = 0;
            int entryCount = 1;
            int terminationFlag1 = 0;
            int largestAttach = 0;
            int largestAttachCount = 0;
            int currentMinorTemp = 0;
            int allocationResult = 0;
            int highSide = 0;
            int overlapNumber = 0;
            int majorIntensityTemp = 0;
            int majorPairTemp = 0;
            int majorProcessTemp = 0;
            int majorDimensionTemp = 0;
            int connectMajorCurrentExA1 = 0;
            int connectMajorCurrentExB1 = 0;
            int connectMajorCurrentExC1 = 0;
            int additional220 = 0;
            int switchFlag = 0;
            int minorOverlapAreaTemp = 0;
            int noReFusionFlag = 0;
            int separateGroup = 0;
            int gravityMajorX = 0;
            int gravityMajorY = 0;
            int gravityMinorX = 0;
            int gravityMinorY = 0;
            int distance = 0;
            int gapDataCount = 0;
            int zeroPathCount = 0;
            int blankPathCount = 0;
            int attachCount = 0;
            int previousTableCountTemp = 0;
            int previousTotalCountTemp = 0;
            int previousAverageCountTemp = 0;
            int currentTableCountTemp = 0;
            int currentTotalCountTemp = 0;
            int currentAverageCountTemp = 0;
            int maxPointDimX = 0;
            int maxPointDimY = 0;
            int minPointDimX = 0;
            int minPointDimY = 0;
            int horizontalStart2 = 0;
            int verticalStart2 = 0;
            int dimensionTemp = 0;
            int horizontalLength = 0;
            int verticalLength = 0;
            int connectivityNumber = 0;
            int connectAnalysisCount = 0;
            int terminationFlag = 0;
            int connectAnalysisTempCount = 0;
            int xSource = 0;
            int ySource = 0;
            int insideFind = 0;
            int highSideNumber = 0;
            int startOrder = 0;
            int findFreePoint = 0;
            int extendConnectCount2 = 0;
            int connectNo = 0;
            int remainingCheck = 0;
            int currentPixCount1 = 0;
            int currentPixCount2 = 0;
            int gravityX1 = 0;
            int gravityY1 = 0;
            int gravityX2 = 0;
            int gravityY2 = 0;
            int cellTrackingCurrentTempCount = 0;
            int cellTrackingCurrentTempLimit = 0;
            int connectProcessNo = 0;
            int connectTemp2 = 0;
            int zeroFillFlag = 0;
            int largestConnect = 0;
            int largestConnectNo = 0;
            int xPositionTempStart = 0;
            int yPositionTempStart = 0;
            int lineSize = 0;
            int constructedLineCount = 0;
            int findFlag = 0;
            int gravityTempX = 0;
            int gravityTempY = 0;
            int previousPointLine1 = 0;
            int previousTotaLine1 = 0;
            int previousPointLine2 = 0;
            int previousTotaLine2 = 0;
            int typeSubArray = 1;
            int groupInvert = 0;
            int prevPixelCount1 = 0;
            int maxPairNumber = 0;
            int currentPointLine = 0;
            int currentTotaLine = 0;
            int entryTemp = 0;
            int sortFindFlag = 0;
            int overlapMax = 0;
            int overlapCount = 0;
            
            double previousAverageLine1 = 0;
            double previousAverageLine2 = 0;
            double currentAverageLine = 0;
            
            string processNo1 = "";
            string processNo2 = "";
            
            do{
                
                if (terminationFlagLoop == 1){
                    terminationFlagLoop = 0;
                    
                    //------Current, Previous line number set------
                    lineNumberPrevious2 = cellTrackingPreviousAssCount/6;
                    lineNumberCurrent2 = cellTrackingCurrentAssCount/6;
                    maxTargetEntry = maxTargetEntryTrack;
                    targetPointer = targetPointerTrack;
                    
                    //cout<<targetPointer<<" "<<lineNumberPrevious2<<" "<<lineNumberCurrent2<<" "<<maxTargetEntry+1<<" Prev_Curr_lineNo"<<endl;
                    
                    //------Overlap Table Set------
                    errorNoHold = 1;
                    int **overlapAreaTable = new int *[lineNumberPrevious2+5];
                    errorNoHold = 2;
                    int **overlapIntensityTable = new int *[lineNumberPrevious2+5];
                    errorNoHold = 3;
                    int **overlapPercentageTable = new int *[lineNumberPrevious2+5];
                    errorNoHold = 4;
                    int **overlapNumberTable = new int *[lineNumberPrevious2+5];
                    
                    for (int counter1 = 0; counter1 < lineNumberPrevious2+5; counter1++){
                        errorNoHold = 5;
                        overlapAreaTable [counter1] = new int [maxTargetEntry+1];
                        errorNoHold = 6;
                        overlapIntensityTable [counter1] = new int [maxTargetEntry+1];
                        errorNoHold = 7;
                        overlapPercentageTable [counter1] = new int [maxTargetEntry+1];
                        errorNoHold = 8;
                        overlapNumberTable [counter1] = new int [maxTargetEntry+1];
                    }
                    
                    for (int counterY = 1; counterY < lineNumberPrevious2+5; counterY++){
                        for (int counterX = 0; counterX < maxTargetEntry+1; counterX++){
                            overlapAreaTable [counterY][counterX] = 0;
                            overlapIntensityTable [counterY][counterX] = 0;
                            overlapPercentageTable [counterY][counterX] = 0;
                            overlapNumberTable [counterY][counterX] = 0;
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < overlapPixelAreaCountTrack/3; counter1++){
                        overlapAreaTable [arrayOverlapPixelAreaTrack [counter1*3]][arrayOverlapPixelAreaTrack [counter1*3+1]] = arrayOverlapPixelAreaTrack [counter1*3+2];
                    }
                    
                    for (int counter1 = 0; counter1 < overlapPixelIntensityCountTrack/3; counter1++){
                        overlapIntensityTable [arrayOverlapPixelIntensityTrack [counter1*3]][arrayOverlapPixelIntensityTrack [counter1*3+1]] = arrayOverlapPixelIntensityTrack [counter1*3+2];
                    }
                    
                    for (int counter1 = 0; counter1 < overlapPercentCountTrack/3; counter1++){
                        overlapPercentageTable [arrayOverlapPercentTrack [counter1*3]][arrayOverlapPercentTrack [counter1*3+1]] = arrayOverlapPercentTrack [counter1*3+2];
                    }
                    
                    for (int counter1 = 0; counter1 < overlapNumberCountTrack/3; counter1++){
                        overlapNumberTable [arrayOverlapNumberTrack [counter1*3]][arrayOverlapNumberTrack [counter1*3+1]] = arrayOverlapNumberTrack [counter1*3+2];
                    }
                    
                    //------Overlap Source------
                    errorNoHold = 9;
                    int **overlapSource = new int *[lineNumberPrevious2+5];
                    for (int counter1 = 0; counter1 < lineNumberPrevious2+5; counter1++){
                        errorNoHold = 10;
                        overlapSource [counter1] = new int [lineNumberCurrent2+5];
                    }
                    
                    for (int counterY = 0; counterY < lineNumberPrevious2+5; counterY++){
                        for (int counterX = 0; counterX < lineNumberCurrent2+5; counterX++) overlapSource [counterY][counterX] = 0;
                    }
                    
                    for (int counterY = 1; counterY < lineNumberPrevious2+1; counterY++){
                        for (int counterX = 0; counterX < maxTargetEntry; counterX++){
                            if (overlapNumberTable [counterY][counterX] != 0) overlapSource [counterY][overlapNumberTable [counterY][counterX]] = 1;
                        }
                    }
                    
                    //for (int counterY = 1; counterY < lineNumberPrevious2+1; counterY++){
                    //    for (int counterX = 1; counterX < lineNumberCurrent2+1; counterX++){
                    //        cout<< counterY<<" "<< counterX<<" "<<overlapSource [counterY][counterX]<<" overlapSource"<<endl;
                    //    }
                    //}
                    
                    //for (int counterY = 1; counterY < lineNumberPrevious2+1; counterY++){
                    //    for (int counterX = 0; counterX < maxTargetEntry; counterX++){
                    //        cout<<counterY<<" "<<counterX<<" Number "<<" "<<overlapNumberTable [counterY][counterX]<<" Area "<<overlapAreaTable [counterY][counterX];
                    //        cout<<" Intensity "<<overlapIntensityTable [counterY][counterX]<<" Percent "<<overlapPercentageTable [counterY][counterX]<<" overlapPercentageTable "<<endl;
                    //    }
                    //}
                    
                    //for (int counter1 = 1; counter1 < lineNumberPrevious2+1; counter1++){
                    //    cout<<counter1<<" Pix "<<arrayPreviousTableTrack [counter1*2]<<" ConnNo "<<arrayPreviousTableTrack [counter1*2+1];
                    //    cout<<" Total "<<arrayPreviousTableTrackTotal [counter1]<<" Average "<<arrayPreviousAverageTrack [counter1];
                    //    cout<<" arrayPreviousAverageTrack"<<endl;
                    //}
                    
                    //------Association Data Set------
                    errorNoHold = 11;
                    int **currentAssData = new int *[lineNumberCurrent2+5];
                    for (int counter1 = 0; counter1 < lineNumberCurrent2+5; counter1++){
                        errorNoHold = 12;
                        currentAssData [counter1] = new int [9];
                    }
                    
                    for (int counter1 = 1; counter1 < cellTrackingCurrentAssCount/6+1; counter1++){
                        if (arrayCellTrackingCurrentAss [(counter1-1)*6] != 0 && arrayCurrentTableTrack [arrayCellTrackingCurrentAss [(counter1-1)*6]*2+1] > 0) currentAssData [counter1][0] = arrayCellTrackingCurrentAss [(counter1-1)*6];
                        else currentAssData [counter1][0] = 0; //------Vector number------
                        
                        currentAssData [counter1][1] = arrayCellTrackingCurrentAss [(counter1-1)*6+1]; //------Process type------
                        currentAssData [counter1][2] = arrayCellTrackingCurrentAss [(counter1-1)*6+2]; //------Cut type------
                        currentAssData [counter1][3] = arrayCellTrackingCurrentAss [(counter1-1)*6+3]; //------Pair ------
                        currentAssData [counter1][4] = arrayCellTrackingCurrentAss [(counter1-1)*6+4]; //------Dimension------
                        currentAssData [counter1][5] = arrayCellTrackingCurrentAss [(counter1-1)*6+5]; //------Reserve------
                        currentAssData [counter1][6] = 0; //------Round------
                    }
                    
                    //for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                    //	cout<<counter1<<" ConnNo "<<currentAssData [counter1][0]<<" Process "<<currentAssData [counter1][1];
                    //    cout<<" Cut "<<currentAssData [counter1][2]<<" Pair "<<currentAssData [counter1][3]<<" Dim "<<currentAssData [counter1][4];
                    //    cout<<" Reserve "<<currentAssData [counter1][5]<<" Round "<<currentAssData [counter1][6]<<" ASSCur_Curr"<<endl;
                    //}
                    
                    errorNoHold = 13;
                    int **previousAssData = new int *[lineNumberPrevious2+5];
                    for (int counter1 = 0; counter1 < lineNumberPrevious2+5; counter1++){
                        errorNoHold = 14;
                        previousAssData [counter1] = new int [9];
                    }
                    
                    for (int counter1 = 1; counter1 < cellTrackingPreviousAssCount/6+1; counter1++){
                        if (arrayCellTrackingPreviousAss [(counter1-1)*6] != 0 && arrayPreviousTableTrack [arrayCellTrackingPreviousAss [(counter1-1)*6]*2+1] > 0) previousAssData [counter1][0] = arrayCellTrackingPreviousAss [(counter1-1)*6]; //------Vector number------
                        else previousAssData [counter1][0] = 0; //------Vector number------
                        
                        previousAssData [counter1][1] = arrayCellTrackingPreviousAss [(counter1-1)*6+1]; //------Process type------
                        previousAssData [counter1][2] = arrayCellTrackingPreviousAss [(counter1-1)*6+2]; //------Cut type------
                        previousAssData [counter1][3] = arrayCellTrackingPreviousAss [(counter1-1)*6+3]; //------Pair ------
                        previousAssData [counter1][4] = arrayCellTrackingPreviousAss [(counter1-1)*6+4]; //------Dimension------
                        previousAssData [counter1][5] = arrayCellTrackingPreviousAss [(counter1-1)*6+5]; //------Reserve------
                        previousAssData [counter1][6] = 0; //------Round------
                    }
                    
                    //for (int counter1 = 1; counter1 < lineNumberPrevious2+1; counter1++){
                    //	cout<<counter1<<" ConnNo "<<previousAssData [counter1][0]<<" Process "<<previousAssData [counter1][1];
                    //    cout<<" Cut "<<previousAssData [counter1][2]<<" Pair "<<previousAssData [counter1][3]<<" Dim "<<previousAssData [counter1][4];
                    //    cout<<" Reserve "<<previousAssData [counter1][5]<<" Round "<<previousAssData [counter1][6]<<" ASSPrev_Curr"<<endl;
                    //}
                    
                    //------No Merge Table------
                    errorNoHold = 15;
                    int **noMergeTable = new int *[lineNumberPrevious2+5];
                    for (int counter1 = 0; counter1 < lineNumberPrevious2+5; counter1++){
                        errorNoHold = 16;
                        noMergeTable [counter1] = new int [lineNumberCurrent2+5];
                    }
                    
                    for (int counterY = 0; counterY < lineNumberPrevious2+5; counterY++){
                        for (int counterX = 0; counterX < lineNumberCurrent2+5; counterX++) noMergeTable [counterY][counterX] = 0;
                    }
                    
                    noMergeTableCount = noMergeTableCountTrack;
                    noMergeTableLimit = noMergeTableLimitTrack;
                    
                    for (int counter1 = 1; counter1 < noMergeTableCountTrack/2+1; counter1++){
                        noMergeTable [arrayNoMergeTableTrack [(counter1-1)*2]][arrayNoMergeTableTrack [(counter1-1)*2+1]] = 1;
                    }
                    
                    //for (int counterY = 1; counterY < lineNumberPrevious2+1; counterY++){
                    //	for (int counterX = 1; counterX < lineNumberCurrent2+1; counterX++){
                    //		if (noMergeTable [counterY][counterX] > 0) cout<< counterY<<" "<< counterX<<" "<<noMergeTable [counterY][counterX]<<" Merge_Table-Curr"<<endl;
                    //	}
                    //}
                    
                    //------Gravity Center info For Display------
                    //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
                    //	cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                    //	cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < groupInfoCurrentCount/9; counterA++){
                    //	for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayGroupInfoCurrent [counterA*9+counterB];
                    //	cout<<" arrayGroupInfoCurrent "<<counterA<<endl;
                    //}
                    
                    //------Group Table Previous------
                    errorNoHold = 17;
                    int *groupTablePreviousious = new int [groupInfoPreviousCount+50];
                    
                    for (int counter1 = 0; counter1 < groupInfoPreviousCount; counter1++) groupTablePreviousious [counter1] = arrayGroupInfoPrevious [counter1];
                    
                    //for (int counterA = 0; counterA < groupInfoPreviousCount/5; counterA++){
                    //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayGroupInfoPrevious [counterA*5+counterB];
                    //	cout<<" arrayGroupInfoPrevious "<<counterA<<endl;
                    //}
                    
                    //------Main Process------
                    additionCount = 0;
                    maxConnect = 0;
                    
                    for (int counterY = 0; counterY < trackAreaSize; counterY++){
                        for (int counterX = 0; counterX < trackAreaSize; counterX++){
                            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                if (connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect) maxConnect = connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                if (connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect) maxConnect = connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                if (connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect) maxConnect = connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                            }
                        }
                    }
                    
                    errorNoHold = 18;
                    int *connectMajorCurrentTempA1 = new int [maxConnect+5];
                    errorNoHold = 19;
                    int *connectMajorCurrentTempB1 = new int [maxConnect+5];
                    errorNoHold = 20;
                    int *connectMajorCurrentTempC1 = new int [maxConnect+5];
                    
                    for (int counter1 = 1; counter1 < lineNumberPrevious2+1; counter1++){
                        numberOfEntry = 0;
                        
                        for (int counter2 = 0; counter2 < maxTargetEntry; counter2++){
                            if (overlapNumberTable [counter1][counter2] > 0) numberOfEntry++;
                        }
                        
                        if (numberOfEntry > 1){
                            previousConnectNumber1 = counter1;
                            previousIntensity = (int)(arrayPreviousAverageTrack [counter1]);
                            previousDimension = previousAssData [previousConnectNumber1][4];
                            currentMajor = overlapNumberTable [counter1][0];
                            
                            majorIntensity = (int)(arrayCurrentAverageTrack [currentMajor]);
                            majorPair = currentAssData [currentMajor][3];
                            majorProcess = currentAssData [currentMajor][1];
                            majorDimension = currentAssData [currentMajor][4];
                            
                            connectMajorCurrentA1 = 0;
                            connectMajorCurrentB1 = 0;
                            connectMajorCurrentC1 = 0;
                            
                            for (int counter2 = 0; counter2 < maxConnect+1; counter2++){
                                connectMajorCurrentTempA1 [counter2] = 0;
                                connectMajorCurrentTempB1 [counter2] = 0;
                                connectMajorCurrentTempC1 [counter2] = 0;
                            }
                            
                            for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                    if (arrayCellTrackingCurrentMap [counterY][counterX] == currentMajor && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                        connectMajorCurrentTempA1 [connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]]++;
                                    }
                                    if (arrayCellTrackingCurrentMap [counterY][counterX] == currentMajor && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                        connectMajorCurrentTempB1 [connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]]++;
                                    }
                                    if (arrayCellTrackingCurrentMap [counterY][counterX] == currentMajor && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                        connectMajorCurrentTempC1 [connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]]++;
                                    }
                                }
                            }
                            
                            connectMajorCurrentCountA1 = 0;
                            connectMajorCurrentCountB1 = 0;
                            connectMajorCurrentCountC1 = 0;
                            
                            for (int counter2 = 1; counter2 < maxConnect+1; counter2++){
                                if (connectMajorCurrentCountA1 < connectMajorCurrentTempA1 [counter2]){
                                    connectMajorCurrentA1 = counter2;
                                    connectMajorCurrentCountA1 = connectMajorCurrentTempA1 [counter2];
                                }
                                if (connectMajorCurrentCountB1 < connectMajorCurrentTempB1 [counter2]){
                                    connectMajorCurrentB1 = counter2;
                                    connectMajorCurrentCountB1 = connectMajorCurrentTempB1 [counter2];
                                }
                                if (connectMajorCurrentCountC1 < connectMajorCurrentTempC1 [counter2]){
                                    connectMajorCurrentC1 = counter2;
                                    connectMajorCurrentCountC1 = connectMajorCurrentTempC1 [counter2];
                                }
                            }
                            
                            errorNoHold = 21;
                            int *attachMajor = new int [lineNumberCurrent2+5];
                            
                            for (int counter2 = 0; counter2 < lineNumberCurrent2+1; counter2++) attachMajor [counter2] = 0;
                            
                            if (numberOfEntry >= 3){
                                for (int counter2 = 1; counter2 < maxTargetEntry; counter2++){
                                    for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                        for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                            attachTemp = 0;
                                            
                                            if (arrayCellTrackingCurrentMap [counterY][counterX] == overlapNumberTable [counter1][counter2]){
                                                if (counterY-1 >= 0 && counterX-1 >= 0 && arrayCellTrackingCurrentMap [counterY-1][counterX-1] == currentMajor) attachTemp = 1;
                                                if (counterY-1 >= 0 && arrayCellTrackingCurrentMap [counterY-1][counterX] == currentMajor) attachTemp = 1;
                                                if (counterY-1 >= 0 && counterX+1 < trackAreaSize && arrayCellTrackingCurrentMap [counterY-1][counterX+1] == currentMajor) attachTemp = 1;
                                                if (counterX+1 < trackAreaSize && arrayCellTrackingCurrentMap [counterY][counterX+1] == currentMajor) attachTemp = 1;
                                                if (counterY+1 < trackAreaSize && counterX+1 < trackAreaSize && arrayCellTrackingCurrentMap [counterY+1][counterX+1] == currentMajor) attachTemp = 1;
                                                if (counterY+1 < trackAreaSize && arrayCellTrackingCurrentMap [counterY+1][counterX] == currentMajor) attachTemp = 1;
                                                if (counterY+1 < trackAreaSize && counterX-1 >= 0 && arrayCellTrackingCurrentMap [counterY+1][counterX-1] == currentMajor) attachTemp = 1;
                                                if (counterX-1 >= 0 && arrayCellTrackingCurrentMap [counterY][counterX-1] == currentMajor) attachTemp = 1;
                                                if (attachTemp == 1) attachMajor [overlapNumberTable [counter1][counter2]]++;
                                            }
                                        }
                                    }
                                }
                                
                                //for (int counter2 = 1; counter2 < lineNumberCurrent2+1; counter2++) cout<<counter2<<" "<<attachMajor [counter2]<<" arrayPreviousAverageTrack"<<endl;
                                
                                numberOfAttach = 0;
                                
                                for (int counter2 = 0; counter2 < maxTargetEntry; counter2++){
                                    if (overlapNumberTable [previousConnectNumber1][counter2] != 0){
                                        if (attachMajor [overlapNumberTable [previousConnectNumber1][counter2]] != 0) numberOfAttach++;
                                    }
                                }
                                
                                if (numberOfAttach != 0){
                                    errorNoHold = 22;
                                    int *overlapAreaTableTemp = new int [maxTargetEntry+5];
                                    errorNoHold = 23;
                                    int *overlapIntensityTableTemp = new int [maxTargetEntry+5];
                                    errorNoHold = 24;
                                    int *overlapPercentageTableTemp = new int [maxTargetEntry+5];
                                    errorNoHold = 25;
                                    int *overlapNumberTableTemp = new int [maxTargetEntry+5];
                                    errorNoHold = 26;
                                    int *attachMajorTemp = new int [maxTargetEntry+5];
                                    errorNoHold = 27;
                                    int *attachMajorTemp2 = new int [maxTargetEntry+5];
                                    
                                    for (int counter2 = 0; counter2 < maxTargetEntry+5; counter2++){
                                        overlapAreaTableTemp [counter2] = 0;
                                        overlapIntensityTableTemp [counter2] = 0;
                                        overlapPercentageTableTemp [counter2] = 0;
                                        overlapNumberTableTemp [counter2] = 0;
                                        attachMajorTemp [counter2] = 0;
                                        attachMajorTemp2 [counter2] = 0;
                                    }
                                    
                                    for (int counter2 = 1; counter2 < maxTargetEntry; counter2++){
                                        if (overlapNumberTable [previousConnectNumber1][counter2] != 0){
                                            attachMajorTemp [counter2] = attachMajor [overlapNumberTable [previousConnectNumber1][counter2]];
                                        }
                                    }
                                    
                                    entryCount = 1;
                                    
                                    do{
                                        
                                        terminationFlag1 = 1;
                                        largestAttach = 0;
                                        largestAttachCount = 0;
                                        
                                        for (int counter2 = 1; counter2 < maxTargetEntry; counter2++){
                                            if (attachMajorTemp [counter2] != -1 && attachMajorTemp [counter2] != 0){
                                                if (largestAttach < attachMajorTemp [counter2]){
                                                    largestAttach = attachMajorTemp [counter2];
                                                    largestAttachCount = counter2;
                                                }
                                            }
                                        }
                                        
                                        if (largestAttachCount != 0){
                                            overlapAreaTableTemp [entryCount] = overlapAreaTable [previousConnectNumber1][largestAttachCount];
                                            overlapIntensityTableTemp [entryCount] = overlapIntensityTable [previousConnectNumber1][largestAttachCount];
                                            overlapPercentageTableTemp [entryCount] = overlapPercentageTable [previousConnectNumber1][largestAttachCount];
                                            overlapNumberTableTemp [entryCount] = overlapNumberTable [previousConnectNumber1][largestAttachCount];
                                            attachMajorTemp2 [entryCount] = attachMajor [overlapNumberTableTemp [entryCount]];
                                            attachMajorTemp [largestAttachCount] = -1;
                                            entryCount++;
                                        }
                                        else{
                                            
                                            for (int counter2 = 1; counter2 < maxTargetEntry; counter2++){
                                                if (attachMajorTemp [counter2] != -1){
                                                    overlapAreaTableTemp [entryCount] = overlapAreaTable [previousConnectNumber1][counter2];
                                                    overlapIntensityTableTemp [entryCount] = overlapIntensityTable [previousConnectNumber1][counter2];
                                                    overlapPercentageTableTemp [entryCount] = overlapPercentageTable [previousConnectNumber1][counter2];
                                                    overlapNumberTableTemp [entryCount] = overlapNumberTable [previousConnectNumber1][counter2];
                                                    attachMajorTemp2 [entryCount] = attachMajor [overlapNumberTableTemp [entryCount]];
                                                    entryCount++;
                                                }
                                            }
                                            
                                            terminationFlag1 = 0;
                                        }
                                        
                                    } while (terminationFlag1 == 1);
                                    
                                    for (int counter2 = 1; counter2 < maxTargetEntry; counter2++){
                                        overlapAreaTable [previousConnectNumber1][counter2] = overlapAreaTableTemp [counter2];
                                        overlapIntensityTable [previousConnectNumber1][counter2] = overlapIntensityTableTemp [counter2];
                                        overlapPercentageTable [previousConnectNumber1][counter2] = overlapPercentageTableTemp [counter2];
                                        overlapNumberTable [previousConnectNumber1][counter2] = overlapNumberTableTemp [counter2];
                                        attachMajor [counter2] = attachMajorTemp2 [counter2];
                                    }
                                    
                                    delete [] overlapAreaTableTemp;
                                    delete [] overlapIntensityTableTemp;
                                    delete [] overlapPercentageTableTemp;
                                    delete [] overlapNumberTableTemp;
                                    delete [] attachMajorTemp;
                                    delete [] attachMajorTemp2;
                                }
                            }
                            
                            errorNoHold = 28;
                            int *minorIntensity = new int [numberOfEntry+5];
                            errorNoHold = 29;
                            int *minorPair = new int [numberOfEntry+5];
                            errorNoHold = 30;
                            int *minorProcess = new int [numberOfEntry+5];
                            errorNoHold = 31;
                            int *minorDimension = new int [numberOfEntry+5];
                            errorNoHold = 32;
                            int *connectMinorCurrentA1 = new int [numberOfEntry+5];
                            errorNoHold = 33;
                            int *connectMinorCurrentB1 = new int [numberOfEntry+5];
                            errorNoHold = 34;
                            int *connectMinorCurrentC1 = new int [numberOfEntry+5];
                            errorNoHold = 35;
                            int *currentConnectNumber = new int [numberOfEntry+5];
                            
                            for (int counter2 = 0; counter2 < numberOfEntry+5; counter2++){
                                minorIntensity [counter2] = 0;
                                minorPair [counter2] = 0;
                                minorProcess [counter2] = 0;
                                minorDimension [counter2] = 0;
                                connectMinorCurrentA1 [counter2] = 0;
                                connectMinorCurrentB1 [counter2] = 0;
                                connectMinorCurrentC1 [counter2] = 0;
                                currentConnectNumber [counter2] = 0;
                            }
                            
                            for (int counter2 = 1; counter2 < numberOfEntry; counter2++){
                                currentMinorTemp = overlapNumberTable [counter1][counter2];
                                
                                if (currentMinorTemp > 0){
                                    minorIntensity [counter2] = (int)(arrayCurrentAverageTrack [currentMinorTemp]);
                                    minorPair [counter2] = currentAssData [currentMinorTemp][3];
                                    minorProcess [counter2] = currentAssData [currentMinorTemp][1];
                                    minorDimension [counter2] = currentAssData [currentMinorTemp][4];
                                    currentConnectNumber [counter2] = currentMinorTemp;
                                    
                                    for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                        for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                            if (arrayCellTrackingCurrentMap [counterY][counterX] == currentMinorTemp && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0) connectMinorCurrentA1 [counter2] = connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                            if (arrayCellTrackingCurrentMap [counterY][counterX] == currentMinorTemp && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0) connectMinorCurrentB1 [counter2] = connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                            if (arrayCellTrackingCurrentMap [counterY][counterX] == currentMinorTemp && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0) connectMinorCurrentC1 [counter2] = connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                        }
                                    }
                                }
                            }
                            
                            //for (int counter2 = 1; counter2 < numberOfEntry; counter2++){
                            //	cout<<" MinorInt "<<minorIntensity [counter2]<<" MinorPair "<<minorPair [counter2]<<" MinorProcess "<<minorProcess [counter2];
                            //    cout<<" Minor Dim "<<minorDimension [counter2]<<" MinorA1 "<<connectMinorCurrentA1 [counter2]<<" MinorB1 "<<connectMinorCurrentB1 [counter2];
                            //    cout<<" MinorC1 "<<connectMinorCurrentC1 [counter2]<<" CurrentContNo "<<currentConnectNumber [counter2]<<" Attach "<<attachMajor [counter2]<<endl;
                            //}
                            
                            allocationResult = 0;
                            highSide = 0;
                            overlapNumber = currentConnectNumber [1];
                            processNo1 = "";
                            
                            //cout<<currentMajor<<" "<<overlapNumber<<" CurMajor_OverlapNo"<<endl;
                            
                            if (previousIntensity >= cutOff2 && majorIntensity >= cutOff2){
                                if (minorIntensity [1] < cutOff4) allocationResult = 3, processNo1 = "E_100"; //------No merge------
                                if (minorIntensity [1] >= cutOff4 && minorIntensity [1] < cutOff2){
                                    if (attachMajor [1] >= 5){
                                        if (minorPair [1] == majorPair && majorPair != 0){
                                            if (majorDimension >= 5) allocationResult = 5, processNo1 = "E_101"; //------Fusion------
                                            else if (majorDimension < 5){
                                                if (arrayCurrentTableTrack [currentMajor*2]*0.5 > arrayCurrentTableTrack [overlapNumber*2]) allocationResult = 5, processNo1 = "E_102";
                                                else if (arrayCurrentTableTrack [currentMajor*2]*0.5 <= arrayCurrentTableTrack [overlapNumber*2]) allocationResult = 3, processNo1 = "E_103";
                                            }
                                        }
                                        else if (minorPair [1] != majorPair && majorPair != 0) allocationResult = 3, processNo1 = "E_104";
                                        else allocationResult = 3, processNo1 = "E_105";
                                    }
                                    else if (attachMajor [1] < 5){
                                        if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.5) allocationResult = 5, processNo1 = "E_106";
                                        else allocationResult = 3, processNo1 = "E_107";
                                    }
                                }
                                if (minorIntensity [1] >= cutOff2){
                                    if (attachMajor [1] >= 5){
                                        if (minorPair [1] == majorPair && majorPair != 0){
                                            if (majorDimension >= 5) allocationResult = 5, processNo1 = "E_108"; //------Fusion------
                                            else if (majorDimension < 5){
                                                if (arrayCurrentTableTrack [currentMajor*2]*0.3 > arrayCurrentTableTrack [overlapNumber*2]) allocationResult = 5, processNo1 = "E_109";
                                                else if (arrayCurrentTableTrack [currentMajor*2]*0.3 <= arrayCurrentTableTrack [overlapNumber*2]) allocationResult = 3, processNo1 = "E_110";
                                            }
                                        }
                                        else if (minorPair [1] != majorPair && majorPair != 0) allocationResult = 3, processNo1 = "E_111";
                                        else allocationResult = 3, processNo1 = "E_112";
                                    }
                                    else if (attachMajor [1] < 5){
                                        if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.7) allocationResult = 5, processNo1 = "E_113";
                                        else allocationResult = 3, processNo1 = "E_114";
                                    }
                                }
                            }
                            if (previousIntensity >= cutOff2 && majorIntensity < cutOff2 && majorIntensity >= cutOff4){
                                if (minorIntensity [1] < cutOff4){
                                    if (attachMajor [1] >= 5){
                                        if (minorPair [1] == majorPair && majorPair != 0){
                                            if (majorDimension >= 5) allocationResult = 5, processNo1 = "E_115"; //------Fusion------
                                            else if (majorDimension < 5){
                                                if (arrayCurrentTableTrack [currentMajor*2]*0.5 > arrayCurrentTableTrack [overlapNumber*2]) allocationResult = 5, processNo1 = "E_116";
                                                else if (arrayCurrentTableTrack [currentMajor*2]*0.5 <= arrayCurrentTableTrack [overlapNumber*2]) allocationResult = 3, processNo1 = "E_117";
                                            }
                                        }
                                        else if (minorPair [1] != majorPair && majorPair != 0){
                                            if (arrayCurrentTableTrack [overlapNumber*2]-overlapAreaTable [counter1][1] >= 100) allocationResult = 3, processNo1 = "E_118";
                                            else if (arrayCurrentTableTrack [overlapNumber*2]-overlapAreaTable [counter1][1] < 100) allocationResult = 5, processNo1 = "E_119";
                                        }
                                        else{
                                            
                                            if (arrayCurrentTableTrack [overlapNumber*2]-overlapAreaTable [counter1][1] >= 50) allocationResult = 3, processNo1 = "E_120";
                                            else if (arrayCurrentTableTrack [overlapNumber*2]-overlapAreaTable [counter1][1] < 50) allocationResult = 5, processNo1 = "E_121";
                                        }
                                    }
                                    else if (attachMajor [1] < 5){
                                        if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.7) allocationResult = 5, processNo1 = "E_122";
                                        else allocationResult = 3, processNo1 = "E_123";
                                    }
                                }
                                if (minorIntensity [1] >= cutOff4 && minorIntensity [1] < cutOff2){
                                    if (attachMajor [1] >= 5){
                                        if (minorPair [1] == majorPair && majorPair != 0){
                                            if (majorDimension >= 5) allocationResult = 5, processNo1 = "E_124"; //------Fusion------
                                            else if (majorDimension < 5){
                                                if (arrayCurrentTableTrack [currentMajor*2]*0.5 > arrayCurrentTableTrack [overlapNumber*2]) allocationResult = 5, processNo1 = "E_125";
                                                else if (arrayCurrentTableTrack [currentMajor*2]*0.5 <= arrayCurrentTableTrack [overlapNumber*2]) allocationResult = 3, processNo1 = "E_126";
                                            }
                                        }
                                        else if (minorPair [1] != majorPair && majorPair != 0){
                                            if (arrayCurrentTableTrack [overlapNumber*2]-overlapAreaTable [counter1][1] >= 50) allocationResult = 3, processNo1 = "E_127";
                                            else if (arrayCurrentTableTrack [overlapNumber*2]-overlapAreaTable [counter1][1] < 50) allocationResult = 5, processNo1 = "E_128";
                                        }
                                        else{
                                            
                                            if (arrayCurrentTableTrack [overlapNumber*2]-overlapAreaTable [counter1][1] >= 50) allocationResult = 3, processNo1 = "E_129";
                                            else if (arrayCurrentTableTrack [overlapNumber*2]-overlapAreaTable [counter1][1] < 50) allocationResult = 5, processNo1 = "E_130";
                                        }
                                    }
                                    else if (attachMajor [1] < 5){
                                        if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.7) allocationResult = 5, processNo1 = "E_131";
                                        else allocationResult = 3, processNo1 = "E_132";
                                    }
                                }
                                if (minorIntensity [1] >= cutOff2){
                                    if (arrayCurrentTableTrack [currentMajor*2]*0.8 < arrayCurrentTableTrack [overlapNumber*2]){
                                        majorIntensityTemp = overlapAreaTable [counter1][0];
                                        majorPairTemp = overlapIntensityTable [counter1][0];
                                        majorProcessTemp = overlapPercentageTable [counter1][0];
                                        majorDimensionTemp = overlapNumberTable [counter1][0];
                                        overlapAreaTable [counter1][0] = overlapAreaTable [counter1][1];
                                        overlapIntensityTable [counter1][0] = overlapIntensityTable [counter1][1];
                                        overlapPercentageTable [counter1][0] = overlapPercentageTable [counter1][1];
                                        overlapNumberTable [counter1][0] = overlapNumberTable [counter1][1];
                                        overlapAreaTable [counter1][1] = majorIntensityTemp;
                                        overlapIntensityTable [counter1][1] = majorPairTemp;
                                        overlapPercentageTable [counter1][1] = majorProcessTemp;
                                        overlapNumberTable [counter1][1] = majorDimensionTemp;
                                        majorIntensityTemp = majorIntensity;
                                        connectMajorCurrentExA1 = connectMajorCurrentA1;
                                        connectMajorCurrentExB1 = connectMajorCurrentB1;
                                        connectMajorCurrentExC1 = connectMajorCurrentC1;
                                        majorIntensity = minorIntensity [1];
                                        majorPair = minorPair [1];
                                        majorProcess = minorProcess [1];
                                        majorDimension = minorDimension [1];
                                        connectMajorCurrentA1 = connectMinorCurrentA1 [1];
                                        connectMajorCurrentB1 = connectMinorCurrentB1 [1];
                                        connectMajorCurrentC1 = connectMinorCurrentC1 [1];
                                        minorIntensity [1] = majorIntensityTemp;
                                        minorPair [1] = majorPair;
                                        minorProcess [1] = majorProcess;
                                        minorDimension [1] = majorDimension;
                                        connectMinorCurrentA1 [1] = connectMajorCurrentExA1;
                                        connectMinorCurrentB1 [1] = connectMajorCurrentExB1;
                                        connectMinorCurrentC1 [1] = connectMajorCurrentExC1;
                                        overlapNumber = currentMajor;
                                        currentMajor = overlapNumberTable [counter1][0];
                                    }
                                    
                                    //cout<<currentMajor<<" "<<overlapNumber<<" CurMajor_OverlapNo2"<<endl;
                                    
                                    if (attachMajor [1] >= 5){
                                        if (minorPair [1] == majorPair && majorPair != 0){
                                            if (majorDimension >= 5) allocationResult = 5, processNo1 = "E_133"; //------Fusion------
                                            else if (majorDimension < 5){
                                                if (arrayCurrentTableTrack [currentMajor*2]*0.5 > arrayCurrentTableTrack [overlapNumber*2]) allocationResult = 5, processNo1 = "E_134";
                                                else if (arrayCurrentTableTrack [currentMajor*2]*0.5 <= arrayCurrentTableTrack [overlapNumber*2]) allocationResult = 3, processNo1 = "E_135";
                                            }
                                        }
                                        else if (minorPair [1] != majorPair && majorPair != 0) allocationResult = 3, processNo1 = "E_136";
                                        else allocationResult = 3, processNo1 = "E_137";
                                    }
                                    else if (attachMajor [1] < 5){
                                        if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.7) allocationResult = 5, processNo1 = "E_138";
                                        else allocationResult = 3, processNo1 = "E_139";
                                    }
                                }
                            }
                            if (previousIntensity >= cutOff2 && majorIntensity < cutOff4){
                                additional220 = 0;
                                switchFlag = 0;
                                
                                if (numberOfEntry-1 != 1){
                                    minorOverlapAreaTemp = 0;
                                    
                                    for (int counter2 = 2; counter2 < numberOfEntry; counter2++){
                                        if (minorIntensity [1] >= cutOff2){
                                            if (overlapAreaTable [1][counter2] > minorOverlapAreaTemp){
                                                minorOverlapAreaTemp = overlapAreaTable [1][counter2];
                                                additional220 = counter2;
                                            }
                                        }
                                    }
                                    
                                    if (additional220 != 0){
                                        if (arrayCurrentTableTrack [currentConnectNumber [additional220]*2] > arrayPreviousTableTrack [currentMajor*2]*0.4){
                                            majorIntensityTemp = overlapAreaTable [counter1][0];
                                            majorPairTemp = overlapIntensityTable [counter1][0];
                                            majorProcessTemp = overlapPercentageTable [counter1][0];
                                            majorDimensionTemp = overlapNumberTable [counter1][0];
                                            overlapAreaTable [counter1][0] = overlapAreaTable [counter1][1];
                                            overlapIntensityTable [counter1][0] = overlapIntensityTable [counter1][1];
                                            overlapPercentageTable [counter1][0] = overlapPercentageTable [counter1][1];
                                            overlapNumberTable [counter1][0] = overlapNumberTable [counter1][1];
                                            overlapAreaTable [counter1][1] = majorIntensityTemp;
                                            overlapIntensityTable [counter1][1] = majorPairTemp;
                                            overlapPercentageTable [counter1][1] = majorProcessTemp;
                                            overlapNumberTable [counter1][1] = majorDimensionTemp;
                                            majorIntensityTemp = majorIntensity;
                                            connectMajorCurrentExA1 = connectMajorCurrentA1;
                                            connectMajorCurrentExB1 = connectMajorCurrentB1;
                                            connectMajorCurrentExC1 = connectMajorCurrentC1;
                                            majorIntensity = minorIntensity [1];
                                            majorPair = minorPair [1];
                                            majorProcess = minorProcess [1];
                                            majorDimension = minorDimension [1];
                                            connectMajorCurrentA1 = connectMinorCurrentA1 [1];
                                            connectMajorCurrentB1 = connectMinorCurrentB1 [1];
                                            connectMajorCurrentC1 = connectMinorCurrentC1 [1];
                                            minorIntensity [1] = majorIntensityTemp;
                                            minorPair [1] = majorPair;
                                            minorProcess [1] = majorProcess;
                                            minorDimension [1] = majorDimension;
                                            connectMinorCurrentA1 [1] = connectMajorCurrentExA1;
                                            connectMinorCurrentB1 [1] = connectMajorCurrentExB1;
                                            connectMinorCurrentC1 [1] = connectMajorCurrentExC1;
                                            overlapNumber = currentMajor;
                                            currentMajor = overlapNumberTable [counter1][0];
                                            switchFlag = 1;
                                        }
                                    }
                                }
                                if (minorIntensity [1] < cutOff4 && switchFlag == 0) allocationResult = 7; //------Both major minor no marge------
                                else if (minorIntensity [1] >= cutOff4 && minorIntensity [1] < cutOff2 && switchFlag == 0){
                                    if (attachMajor [1] >= 5){
                                        if (arrayCurrentTableTrack [currentMajor*2]*0.7 > arrayCurrentTableTrack [overlapNumber*2]) allocationResult = 5, processNo1 = "E_140";
                                        else if (arrayCurrentTableTrack [currentMajor*2]*0.7 <= arrayCurrentTableTrack [overlapNumber*2]) allocationResult = 3, processNo1 = "E_141";
                                    }
                                    if (attachMajor [1] < 5){
                                        if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.7) allocationResult = 5, processNo1 = "E_142";
                                        else allocationResult = 3, processNo1 = "E_143";
                                    }
                                }
                                else if (minorIntensity [1] >= cutOff2 || switchFlag == 1){
                                    if (switchFlag == 1) allocationResult = 3;
                                    else if (minorIntensity [1] >= cutOff2 && switchFlag == 0) allocationResult = 5, processNo1 = "E_144";
                                    else allocationResult = 3, processNo1 = "E_145";
                                }
                                else allocationResult = 3, processNo1 = "E_146";
                            }
                            
                            if (previousIntensity < cutOff2 && majorIntensity >= cutOff2){
                                if (majorPair != minorPair [1]){
                                    if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.6 && arrayCurrentTableTrackTotal [overlapNumber] > 100){
                                        if (majorDimension >= 5) allocationResult = 5, processNo1 = "E_147"; //------Fusion------
                                        else if (majorDimension < 5){
                                            if (arrayCurrentTableTrack [currentMajor*2]*0.5 > arrayCurrentTableTrack [overlapNumber*2]){
                                                if (roundTwo == 1) allocationResult = 1, processNo1 = "E_148";
                                                else allocationResult = 3, processNo1 = "E_149";
                                            }
                                            else if (arrayCurrentTableTrack [currentMajor*2]*0.5 <= arrayCurrentTableTrack [overlapNumber*2]){
                                                if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.8) allocationResult = 5, processNo1 = "E_149.2"; //------round, well overpal------
                                                else allocationResult = 3, processNo1 = "E_150"; //------Divide after M case------
                                            }
                                        }
                                    }
                                    else allocationResult = 3, processNo1 = "E_151";
                                }
                                else if (connectMajorCurrentA1 != connectMinorCurrentA1 [1]){
                                    if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.6 && arrayCurrentTableTrackTotal [overlapNumber] > 100 && roundTwo == 1) allocationResult = 1, processNo1 = "E_152";
                                    else allocationResult = 3, processNo1 = "E_153";
                                }
                                else if (connectMajorCurrentB1 != connectMinorCurrentB1 [1]){
                                    if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.6 && arrayCurrentTableTrackTotal [overlapNumber] > 100 && roundTwo == 1) allocationResult = 1, processNo1 = "E_154";
                                    else allocationResult = 3, processNo1 = "E_155";
                                }
                                else if (minorIntensity [1] < cutOff4){
                                    if (overlapIntensityTable [counter1][0] >= cutOff2 && overlapIntensityTable [counter1][1] < cutOff4 && previousDimension < 3 && previousIntensity >= cutOff3){
                                        if (arrayPreviousTableTrack [previousConnectNumber1*2] < 100 || roundTwo == 2) allocationResult = 3, processNo1 = "E_156";
                                        else allocationResult = 2, highSide = 1, processNo1 = "E_157"; //------Divide, 220, 180------
                                    }
                                    else{
                                        
                                        if (connectMajorCurrentA1 != 0 && connectMajorCurrentA1 == connectMinorCurrentA1 [1]){
                                            if (majorProcess != 0 && minorProcess [1] != 0) allocationResult = 3, processNo1 = "E_158";
                                            else allocationResult = 5, processNo1 = "E_159";
                                        }
                                        else if (connectMajorCurrentA1 != 0 && connectMajorCurrentA1 != connectMinorCurrentA1 [1]){
                                            if (connectMinorCurrentB1 [1] != 0) allocationResult = 5, processNo1 = "E_160";
                                            else if (connectMinorCurrentB1 [1] == 0){
                                                if (arrayPreviousTableTrack [previousConnectNumber1*2] < 100 || roundTwo == 2) allocationResult = 3, processNo1 = "E_161";
                                                else allocationResult = 1, processNo1 = "E_162";
                                            }
                                        }
                                        else if (connectMajorCurrentB1 != 0 && connectMajorCurrentB1 == connectMinorCurrentB1 [1]) allocationResult = 5, processNo1 = "E_163";
                                        else if (connectMajorCurrentB1 != 0 && connectMajorCurrentB1 != connectMinorCurrentB1 [1]){
                                            if (arrayPreviousTableTrack [previousConnectNumber1*2] < 100 || roundTwo == 2) allocationResult = 3, processNo1 = "E_164";
                                            else allocationResult = 1, processNo1 = "E_165";
                                        }
                                        else if (connectMajorCurrentC1 != 0 && connectMajorCurrentC1 == connectMinorCurrentC1 [1]) allocationResult = 5, processNo1 = "E_166";
                                        else if (connectMajorCurrentC1 != 0 && connectMajorCurrentC1 != connectMinorCurrentC1 [1]){
                                            if (arrayPreviousTableTrack [previousConnectNumber1*2] < 100 || roundTwo == 2) allocationResult = 3, processNo1 = "E_167";
                                            else allocationResult = 1, processNo1 = "E_168";
                                        }
                                    }
                                }
                                if (minorIntensity [1] >= cutOff4 && minorIntensity [1] < cutOff2){
                                    if ((overlapIntensityTable [counter1][0] >= cutOff2 && overlapIntensityTable [counter1][1] < cutOff4 && previousDimension < 3 && previousIntensity >= cutOff3) || (overlapIntensityTable [counter1][0] < cutOff4 && overlapIntensityTable [counter1][1] >= cutOff2 && previousDimension < 3 && previousIntensity >= cutOff3)){
                                        if (arrayPreviousTableTrack [previousConnectNumber1*2] < 100 || roundTwo == 2) allocationResult = 3, processNo1 = "E_169";
                                        else{
                                            
                                            allocationResult = 2, processNo1 = "E_170"; //------Divide, 220, 180------
                                            
                                            if (overlapIntensityTable [counter1][0] >= cutOff2 && overlapIntensityTable [counter1][1] < cutOff4) highSide = 1, processNo1 = "E_171";
                                            else highSide = 2, processNo1 = "E_172";
                                        }
                                    }
                                    else{
                                        
                                        if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.6) allocationResult = 5, processNo1 = "E_173";
                                        else if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] <= 0.6){
                                            if (connectMajorCurrentA1 != 0 && connectMajorCurrentA1 == connectMinorCurrentA1 [1]){
                                                if ((majorProcess != 0 && minorProcess [1] != 0) || (majorProcess == 0 && minorProcess [1] != 0) || (majorProcess != 0 && minorProcess [1] == 0)) allocationResult = 3, processNo1 = "E_174";
                                                else allocationResult = 5, processNo1 = "E_175";
                                            }
                                            else if (connectMajorCurrentA1 != 0 && connectMajorCurrentA1 != connectMinorCurrentA1 [1]){
                                                if (connectMinorCurrentB1 [1] != 0) allocationResult = 5, processNo1 = "E_176"; //------Divide normal------
                                                else if (connectMinorCurrentB1 [1] == 0){
                                                    if (arrayPreviousTableTrack [previousConnectNumber1*2] < 100 || roundTwo == 2) allocationResult = 3, processNo1 = "E_177";
                                                    else allocationResult = 1, processNo1 = "E_178";
                                                }
                                            }
                                            else if (connectMajorCurrentB1 != 0 && connectMajorCurrentB1 == connectMinorCurrentB1 [1]) allocationResult = 5, processNo1 = "E_179";
                                            else if (connectMajorCurrentB1 != 0 && connectMajorCurrentB1 != connectMinorCurrentB1 [1]){
                                                if (arrayPreviousTableTrack [previousConnectNumber1*2] < 100 || roundTwo == 2) allocationResult = 3, processNo1 = "E_180";
                                                else allocationResult = 1, processNo1 = "E_181";
                                            }
                                            else if (connectMajorCurrentC1 != 0 && connectMajorCurrentC1 == connectMinorCurrentC1 [1]) allocationResult = 5, processNo1 = "E_182";
                                            else if (connectMajorCurrentC1 != 0 && connectMajorCurrentC1 != connectMinorCurrentC1 [1]){
                                                if (arrayPreviousTableTrack [previousConnectNumber1*2] < 100 || roundTwo == 2) allocationResult = 3, processNo1 = "E_183";
                                                else allocationResult = 1, processNo1 = "E_184";
                                            }
                                        }
                                    }
                                }
                                if (minorIntensity [1] >= cutOff2){
                                    if (attachMajor [1] >= 5){
                                        if (minorPair [1] == majorPair && majorPair != 0){
                                            if (majorDimension >= 5) allocationResult = 5, processNo1 = "E_185"; //------Fusion------
                                            else if (majorDimension < 5){
                                                if (arrayCurrentTableTrack [currentMajor*2]*0.3 > arrayCurrentTableTrack [overlapNumber*2]) allocationResult = 5, processNo1 = "E_186";
                                                else if (arrayCurrentTableTrack [currentMajor*2]*0.3 <= arrayCurrentTableTrack [overlapNumber*2]) allocationResult = 3, processNo1 = "E_187";
                                            }
                                        }
                                        else if (minorPair [1] != majorPair && majorPair != 0) allocationResult = 3, processNo1 = "E_188";
                                        else allocationResult = 3;
                                    }
                                    else if (attachMajor [1] < 5 && majorPair != 0){
                                        if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.7) allocationResult = 5, processNo1 = "E_189";
                                        else allocationResult = 3, processNo1 = "E_190";
                                    }
                                    else{
                                        
                                        if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.7) allocationResult = 5, processNo1 = "E_191";
                                        else allocationResult = 3, processNo1 = "E_192";
                                    }
                                }
                            }
                            if (previousIntensity < cutOff2 && majorIntensity < cutOff2 && majorIntensity >= cutOff4){
                                if (majorPair != minorPair [1]){
                                    if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.6 && arrayCurrentTableTrackTotal [overlapNumber] > 100){
                                        if (majorDimension >= 5) allocationResult = 5, processNo1 = "E_193"; //------Long shape, fusion------
                                        else if (majorDimension < 5){
                                            if (arrayCurrentTableTrack [currentMajor*2]*0.5 > arrayCurrentTableTrack [overlapNumber*2]) allocationResult = 3, processNo1 = "E_194"; //------round small------//ADD M decision
                                            else if (arrayCurrentTableTrack [currentMajor*2]*0.5 <= arrayCurrentTableTrack [overlapNumber*2]){
                                                if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.8) allocationResult = 5, processNo1 = "E_195"; //------round, well overpal------
                                                else allocationResult = 3, processNo1 = "E_196"; //------Divide after M case------
                                            }
                                        }
                                    }
                                    else allocationResult = 3, processNo1 = "E_197";
                                }
                                else if (connectMajorCurrentA1 != connectMinorCurrentA1 [1]){
                                    if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.6 && arrayCurrentTableTrackTotal [overlapNumber] > 100) allocationResult = 5, processNo1 = "E_198";
                                    else allocationResult = 3, processNo1 = "E_199";
                                }
                                else if (connectMajorCurrentB1 != connectMinorCurrentB1 [1]){
                                    if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.6 && arrayCurrentTableTrackTotal [overlapNumber] > 100) allocationResult = 5, processNo1 = "E_200";
                                    else allocationResult = 3, processNo1 = "E_201";
                                }
                                else if ((overlapIntensityTable [counter1][0] >= cutOff2 && overlapIntensityTable [counter1][1] < cutOff4 && previousDimension < 3 && previousIntensity >= cutOff3) || (overlapIntensityTable [counter1][0] < cutOff4 && overlapIntensityTable [counter1][1] >= cutOff2 && previousDimension < 3 && previousIntensity >= cutOff3)){
                                    if (arrayPreviousTableTrack [previousConnectNumber1*2] < 100 || roundTwo == 2) allocationResult = 3, processNo1 = "E_202";
                                    else{
                                        
                                        allocationResult = 2, processNo1 = "E_203"; //------Divide, 220, 180------
                                        
                                        if (overlapIntensityTable [counter1][0] >= cutOff2 && overlapIntensityTable [counter1][1] < cutOff4) highSide = 1, processNo1 = "E_204";
                                        else highSide = 2, processNo1 = "E_205";
                                    }
                                }
                                else{
                                    
                                    if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.6) allocationResult = 5, processNo1 = "E_206";
                                    else if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] <= 0.6){
                                        if (connectMajorCurrentA1 != 0 && connectMajorCurrentA1 == connectMinorCurrentA1 [1]){
                                            if (majorProcess != 0 && minorProcess [1] != 0) allocationResult = 3, processNo1 = "E_207";
                                            else allocationResult = 5, processNo1 = "E_208";
                                        }
                                        else if (connectMajorCurrentA1 != 0 && connectMajorCurrentA1 != connectMinorCurrentA1 [1]){
                                            if (connectMinorCurrentB1 [1] != 0) allocationResult = 5; //------Divide normal------
                                            if (connectMinorCurrentB1 [1] == 0){
                                                if (arrayPreviousTableTrack [previousConnectNumber1*2] < 100 || roundTwo == 2) allocationResult = 3, processNo1 = "E_209";
                                                else allocationResult = 1, processNo1 = "E_210";
                                            }
                                        }
                                        else if (connectMajorCurrentB1 != 0 && connectMajorCurrentB1 == connectMinorCurrentB1 [1]) allocationResult = 5, processNo1 = "E_211";
                                        else if (connectMajorCurrentB1 != 0 && connectMajorCurrentB1 != connectMinorCurrentB1 [1]){
                                            if (arrayPreviousTableTrack [previousConnectNumber1*2] < 100 || roundTwo == 2) allocationResult = 3, processNo1 = "E_212";
                                            else allocationResult = 1, processNo1 = "E_213";
                                        }
                                        else if (connectMajorCurrentC1 != 0 && connectMajorCurrentC1 == connectMinorCurrentC1 [1]) allocationResult = 5, processNo1 = "E_214";
                                        else if (connectMajorCurrentC1 != 0 && connectMajorCurrentC1 != connectMinorCurrentC1 [1]){
                                            if (arrayPreviousTableTrack [previousConnectNumber1*2] < 100) allocationResult = 3, processNo1 = "E_215";
                                            
                                        }
                                        else{
                                            
                                            if (roundTwo == 1) allocationResult = 1, processNo1 = "E_216";
                                            else allocationResult = 3, processNo1 = "E_217";
                                        }
                                    }
                                }
                            }
                            if (previousIntensity < cutOff2 && majorIntensity < cutOff4){
                                if (majorPair != minorPair [1]){
                                    if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.6 && arrayCurrentTableTrackTotal [overlapNumber] > 100){
                                        if (majorDimension >= 5) allocationResult = 5, processNo1 = "E_218"; //------Fusion------
                                        else if (majorDimension < 5){
                                            if (arrayCurrentTableTrack [currentMajor*2]*0.5 > arrayCurrentTableTrack [overlapNumber*2]) allocationResult = 5, processNo1 = "E_219";
                                            else if (arrayCurrentTableTrack [currentMajor*2]*0.5 <= arrayCurrentTableTrack [overlapNumber*2]){
                                                if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.8) allocationResult = 5, processNo1 = "E_220"; //------round, well overpal------
                                                else allocationResult = 3, processNo1 = "E_221"; //------Divide after M case------
                                            }
                                        }
                                    }
                                    else allocationResult = 3, processNo1 = "E_222";
                                }
                                else if (connectMajorCurrentA1 != connectMinorCurrentA1 [1]){
                                    if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.6 && arrayCurrentTableTrackTotal [overlapNumber] > 100) allocationResult = 5, processNo1 = "E_223";
                                    else allocationResult = 3, processNo1 = "E_224";
                                }
                                else if (connectMajorCurrentB1 != connectMinorCurrentB1 [1]){
                                    if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.6 && arrayCurrentTableTrackTotal [overlapNumber] > 100) allocationResult = 5, processNo1 = "E_225";
                                    else allocationResult = 3, processNo1 = "E_226";
                                }
                                else if (minorIntensity [1] < cutOff2){
                                    if ((overlapIntensityTable [counter1][0] >= cutOff2 && overlapIntensityTable [counter1][1] < cutOff4 && previousDimension < 3 && previousIntensity >= cutOff3) || (overlapIntensityTable [counter1][0] < cutOff4 && overlapIntensityTable [counter1][1] >= cutOff2 && previousDimension < 3 && previousIntensity >= cutOff3)){
                                        if (arrayPreviousTableTrack [previousConnectNumber1*2] < 100 || roundTwo == 2) allocationResult = 3, processNo1 = "E_227";
                                        else{
                                            
                                            allocationResult = 2, processNo1 = "E_228"; //------Divide, 220, 180------
                                            
                                            if (overlapIntensityTable [counter1][0] >= cutOff2 && overlapIntensityTable [counter1][1] < cutOff4) highSide = 1, processNo1 = "E_229";
                                            else highSide = 2, processNo1 = "E_230";
                                        }
                                    }
                                    else{
                                        
                                        if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.6) allocationResult = 5, processNo1 = "E_231";
                                        else if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] <= 0.6){
                                            if (connectMajorCurrentA1 != 0 && connectMajorCurrentA1 == connectMinorCurrentA1 [1]){
                                                if ((majorProcess != 0 && minorProcess [1] != 0) || (majorProcess == 0 && minorProcess [1] != 0) || (majorProcess != 0 && minorProcess [1] == 0)) allocationResult = 3, processNo1 = "E_232";
                                                else allocationResult = 5, processNo1 = "E_233";
                                            }
                                            else if (connectMajorCurrentA1 != 0 && connectMajorCurrentA1 != connectMinorCurrentA1 [1]){
                                                if (connectMinorCurrentB1 [1] != 0) allocationResult = 5, processNo1 = "E_234"; //------Divide normal------
                                                if (connectMinorCurrentB1 [1] == 0){
                                                    if (arrayPreviousTableTrack [previousConnectNumber1*2] < 100 || roundTwo == 2) allocationResult = 3, processNo1 = "E_235";
                                                    else allocationResult = 1, processNo1 = "E_236";
                                                }
                                            }
                                            else if (connectMajorCurrentB1 != 0 && connectMajorCurrentB1 == connectMinorCurrentB1 [1]) allocationResult = 5, processNo1 = "E_237";
                                            else if (connectMajorCurrentB1 != 0 && connectMajorCurrentB1 != connectMinorCurrentB1 [1]){
                                                if (arrayPreviousTableTrack [previousConnectNumber1*2] < 100 || roundTwo == 2) allocationResult = 3, processNo1 = "E_238";
                                                else allocationResult = 1, processNo1 = "E_239";
                                            }
                                            else if (connectMajorCurrentC1 != 0 && connectMajorCurrentC1 == connectMinorCurrentC1 [1]) allocationResult = 5, processNo1 = "E_240";
                                            else if (connectMajorCurrentC1 != 0 && connectMajorCurrentC1 != connectMinorCurrentC1 [1]){
                                                if (arrayPreviousTableTrack [previousConnectNumber1*2] < 100 || roundTwo == 2) allocationResult = 3, processNo1 = "E_241";
                                                else allocationResult = 1, processNo1 = "E_242";
                                            }
                                        }
                                    }
                                }
                                if (minorIntensity [1] >= cutOff2){
                                    if (arrayCurrentTableTrack [overlapNumber*2] > 100){
                                        if (overlapIntensityTable [counter1][0] < cutOff4 && overlapIntensityTable [counter1][1] >= cutOff2 && previousDimension < 3 && previousIntensity >= cutOff3){
                                            if (arrayPreviousTableTrack [previousConnectNumber1*2] < 100 || roundTwo == 2) allocationResult = 3, processNo1 = "E_243";
                                            else allocationResult = 2, highSide = 2, processNo1 = "E_244"; //------Divide, 220, 180------
                                        }
                                        else{
                                            
                                            if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.6) allocationResult = 5, processNo1 = "E_245";
                                            else if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] <= 0.6){
                                                if (connectMajorCurrentA1 != 0 && connectMajorCurrentA1 == connectMinorCurrentA1 [1]){
                                                    if ((majorProcess != 0 && minorProcess [1] != 0) || (majorProcess == 0 && minorProcess [1] != 0) || (majorProcess != 0 && minorProcess [1] == 0)) allocationResult = 3, processNo1 = "E_246";
                                                    else allocationResult = 5, processNo1 = "E_247";
                                                }
                                                else if (connectMajorCurrentA1 != 0 && connectMajorCurrentA1 != connectMinorCurrentA1 [1]){
                                                    if (connectMinorCurrentB1 [1] != 0) allocationResult = 5; //------Divide normal------
                                                    if (connectMinorCurrentB1 [1] == 0){
                                                        if (arrayPreviousTableTrack [previousConnectNumber1*2] < 100 || roundTwo == 2) allocationResult = 3, processNo1 = "E_248";
                                                        else allocationResult = 1, processNo1 = "E_249";
                                                    }
                                                }
                                                else if (connectMajorCurrentB1 != 0 && connectMajorCurrentB1 == connectMinorCurrentB1 [1]) allocationResult = 5, processNo1 = "E_250";
                                                else if (connectMajorCurrentB1 != 0 && connectMajorCurrentB1 != connectMinorCurrentB1 [1]){
                                                    if (arrayPreviousTableTrack [previousConnectNumber1*2] < 100 || roundTwo == 2) allocationResult = 3, processNo1 = "E_251";
                                                    else allocationResult = 1, processNo1 = "E_252";
                                                }
                                                else if (connectMajorCurrentC1 != 0 && connectMajorCurrentC1 == connectMinorCurrentC1 [1]) allocationResult = 5, processNo1 = "E_253";
                                                else if (connectMajorCurrentC1 != 0 && connectMajorCurrentC1 != connectMinorCurrentC1 [1]){
                                                    if (arrayPreviousTableTrack [previousConnectNumber1*2] < 100 || roundTwo == 2) allocationResult = 3, processNo1 = "E_254";
                                                    else allocationResult = 1, processNo1 = "E_255";
                                                }
                                            }
                                        }
                                    }
                                    else if (arrayCurrentTableTrack [overlapNumber*2] <= 100) allocationResult = 5, processNo1 = "E_256";
                                    else allocationResult = 3, processNo1 = "E_257";
                                }
                            }
                            
                            //cout<<"All Result "<<allocationResult<<" "<<processNo1<<endl;
                            
                            //==========Group check==========
                            noReFusionFlag = 0;
                            
                            if (allocationResult == 5 && arrayCurrentTableTrack [currentMajor*2+1] < 0){
                                if (arrayCurrentTableTrack [currentMajor*2+1] < 0){
                                    if (arrayCurrentTableTrack [currentMajor*2] == arrayCurrentTableTrack [overlapNumber*2]) noReFusionFlag = 1;
                                }
                                else if (arrayCurrentTableTrack [overlapNumber*2+1] > 0){
                                    if (arrayCurrentTableTrack [currentMajor*2+1]*-1 == arrayCurrentTableTrack [overlapNumber*2]) noReFusionFlag = 1;
                                }
                            }
                            else if (allocationResult == 1 && arrayCurrentTableTrack [currentMajor*2+1] > 0){
                                if (arrayCurrentTableTrack [overlapNumber*2+1] < 0){
                                    if (arrayCurrentTableTrack [currentMajor*2] == arrayCurrentTableTrack [overlapNumber*2]*-1) noReFusionFlag = 1;
                                }
                            }
                            
                            //==========Relationship between gravity center==========
                            separateGroup = 0;
                            gravityMajorX = 0;
                            gravityMajorY = 0;
                            gravityMinorX = 0;
                            gravityMinorY = 0;
                            
                            for (int counter2 = 0; counter2 < xyPositionCenterCurrentCount/6; counter2++){
                                if (arrayXYPositionCenterCurrent [counter2*6+4] == currentMajor){
                                    gravityMajorX = arrayXYPositionCenterCurrent [counter2*6];
                                    gravityMajorY = arrayXYPositionCenterCurrent [counter2*6+1];
                                }
                                if (arrayXYPositionCenterCurrent [counter2*6+4] == overlapNumber){
                                    gravityMinorX = arrayXYPositionCenterCurrent [counter2*6];
                                    gravityMinorY = arrayXYPositionCenterCurrent [counter2*6+1];
                                }
                            }
                            
                            if (gravityMajorX-gravityMinorX == 0) distance = abs(gravityMajorY-gravityMinorY);
                            else if (gravityMajorY-gravityMinorY == 0) distance = abs(gravityMajorX-gravityMinorX);
                            else distance = abs(gravityMajorX-gravityMinorX)*abs(gravityMajorY-gravityMinorY);
                            
                            errorNoHold = 36;
                            int *arrayGapData = new int [distance*2+50];
                            
                            gapFill = [[GapFill alloc] init];
                            gapDataCount= [gapFill gapFilling:gravityMajorX:gravityMajorY:gravityMinorX:gravityMinorY:arrayGapData];
                            
                            zeroPathCount = 0;
                            blankPathCount = 0;
                            
                            for (int counter2 = 0; counter2 < gapDataCount/2; counter2++){
                                
                                //cout<<counter2<<" "<<XPositionTemp<<" "<<YPositionTemp<<" "<<connetCurrMapC [YPositionTemp][XPositionTemp]<<" LineData1"<<endl;
                                
                                if (arrayGapData [counter2*2+1] >= 0 && arrayGapData [counter2*2+1] < imageDimension && arrayGapData [counter2*2] >= 0 && arrayGapData [counter2*2] < imageDimension){
                                    if (connectMapC [mapPositionPointerCurrent][arrayGapData [counter2*2+1]*imageDimension+arrayGapData [counter2*2]] == 0) zeroPathCount++;
                                    if (sourceImage [mapPositionPointerCurrent][arrayGapData [counter2*2+1]*imageDimension+arrayGapData [counter2*2]] == 100 || sourceImage [mapPositionPointerCurrent][arrayGapData [counter2*2+1]*imageDimension+arrayGapData [counter2*2]] < 50) blankPathCount++;
                                }
                            }
                            
                            delete [] arrayGapData;
                            
                            processNo2 = "";
                            
                            if (zeroPathCount >= 5 || blankPathCount >= 5 || groupTablePreviousious [(previousConnectNumber1-1)*5+3] == 1) separateGroup = 1;
                            if (noReFusionFlag == 1) allocationResult = 3;
                            
                            attachCount = 0;
                            
                            for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                    attachTemp = 0;
                                    
                                    if (arrayCellTrackingCurrentMap [counterY][counterX] == currentMajor){
                                        if (counterY-1 >= 0 && counterX-1 >= 0 && arrayCellTrackingCurrentMap [counterY-1][counterX-1] == overlapNumber) attachTemp = 1;
                                        if (counterY-1 >= 0 && arrayCellTrackingCurrentMap [counterY-1][counterX] == overlapNumber) attachTemp = 1;
                                        if (counterY-1 >= 0 && counterX+1 < trackAreaSize && arrayCellTrackingCurrentMap [counterY-1][counterX+1] == overlapNumber) attachTemp = 1;
                                        if (counterX+1 < trackAreaSize && arrayCellTrackingCurrentMap [counterY][counterX+1] == overlapNumber) attachTemp = 1;
                                        if (counterY+1 < trackAreaSize && counterX+1 < trackAreaSize && arrayCellTrackingCurrentMap [counterY+1][counterX+1] == overlapNumber) attachTemp = 1;
                                        if (counterY+1 < trackAreaSize && arrayCellTrackingCurrentMap [counterY+1][counterX] == overlapNumber) attachTemp = 1;
                                        if (counterY+1 < trackAreaSize && counterX-1 >= 0 && arrayCellTrackingCurrentMap [counterY+1][counterX-1] == overlapNumber) attachTemp = 1;
                                        if (counterX-1 >= 0 && arrayCellTrackingCurrentMap [counterY][counterX-1] == overlapNumber) attachTemp = 1;
                                        if (attachTemp == 1) attachCount++;
                                    }
                                }
                            }
                            
                            if (allocationResult == 1 || allocationResult == 2){
                                if (previousConnectNumber1 == targetPointer && attachCount > 10) allocationResult = 5;
                                else if (previousConnectNumber1 == targetPointer) allocationResult = 3;
                                else if (groupTablePreviousious [(previousConnectNumber1-1)*5+4] == 2000 && groupTablePreviousious [(previousConnectNumber1-1)*5+3] == 0){
                                    if ((arrayGroupInfoCurrent [(currentMajor-1)*3] == arrayGroupInfoCurrent [(overlapNumber-1)*3]*-1 || arrayGroupInfoCurrent [(currentMajor-1)*3]*-1 == arrayGroupInfoCurrent [(overlapNumber-1)*3] ||arrayGroupInfoCurrent [(currentMajor-1)*3]*-1 == arrayGroupInfoCurrent [(overlapNumber-1)*3]*-1) && attachCount > 10){
                                        allocationResult = 5, processNo2 = "G_01";
                                    }
                                    else if (arrayGroupInfoCurrent [(currentMajor-1)*3+2] == arrayGroupInfoCurrent [(overlapNumber-1)*3+2] && arrayCurrentAverageTrack [currentMajor]*0.8 < arrayCurrentAverageTrack [overlapNumber] && arrayCurrentAverageTrack [currentMajor]*1.2 > arrayCurrentAverageTrack [overlapNumber] && attachCount > 10){
                                        allocationResult = 5, processNo2 = "G_02";
                                    }
                                    else if (arrayCurrentTableTrack [currentMajor*2]*0.5 >= arrayCurrentTableTrack [overlapNumber*2] && attachCount > 10) allocationResult = 5, processNo2 = "G_03";
                                    else allocationResult = 3, processNo2 = "G_04";
                                }
                                else if (groupTablePreviousious [(previousConnectNumber1-1)*5+4] <= 10 && groupTablePreviousious [(previousConnectNumber1-1)*5+3] == 0){
                                    if ((arrayGroupInfoCurrent [(currentMajor-1)*3] == arrayGroupInfoCurrent [(overlapNumber-1)*3]*-1 || arrayGroupInfoCurrent [(currentMajor-1)*3]*-1 == arrayGroupInfoCurrent [(overlapNumber-1)*3] ||arrayGroupInfoCurrent [(currentMajor-1)*3]*-1 == arrayGroupInfoCurrent [(overlapNumber-1)*3]*-1) && attachCount > 10){
                                        allocationResult = 5, processNo2 = "G_05";
                                    }
                                    else if (arrayGroupInfoCurrent [(currentMajor-1)*3+2] == arrayGroupInfoCurrent [(overlapNumber-1)*3+2] && arrayCurrentAverageTrack [currentMajor]*0.8 < arrayCurrentAverageTrack [overlapNumber] && arrayCurrentAverageTrack [currentMajor]*1.2 > arrayCurrentAverageTrack [overlapNumber] && attachCount > 10){
                                        allocationResult = 5, processNo2 = "G_06";
                                    }
                                    else if (arrayCurrentTableTrack [currentMajor*2]*0.5 >= arrayCurrentTableTrack [overlapNumber*2] && attachCount > 10) allocationResult = 5, processNo2 = "G_07";
                                    else if (overlapAreaTable [0][1]/(double)arrayCurrentTableTrack [currentMajor*2] <= 0.8 || overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] <= 0.8) allocationResult = 3, processNo2 = "G_08";
                                }
                                else if (groupTablePreviousious [(previousConnectNumber1-1)*5+3] == 1) allocationResult = 3, processNo2 = "G_09";
                            }
                            else if (allocationResult == 5){
                                if (attachCount > 10){
                                    if (separateGroup == 1) allocationResult = 3, processNo2 = "G_10";
                                    else{
                                        
                                        if (overlapNumber > lineNumberOriginalCurrent2) allocationResult = 3, processNo2 = "G_11"; //------Limit fusion of connect created by Fusion/Abort3------
                                        else if (groupTablePreviousious [(previousConnectNumber1-1)*5+4] == 2000 && targetPointer != previousConnectNumber1){
                                            if ((arrayGroupInfoCurrent [(currentMajor-1)*3] != arrayGroupInfoCurrent [(overlapNumber-1)*3]*-1) || (arrayGroupInfoCurrent [(currentMajor-1)*3]*-1 != arrayGroupInfoCurrent [(overlapNumber-1)*3]) ||(arrayGroupInfoCurrent [(currentMajor-1)*3]*-1 != arrayGroupInfoCurrent [(overlapNumber-1)*3]*-1) ||(arrayGroupInfoCurrent [(currentMajor-1)*3] != arrayGroupInfoCurrent [(overlapNumber-1)*3])){
                                                if (arrayGroupInfoCurrent [(currentMajor-1)*3+2] != arrayGroupInfoCurrent [(overlapNumber-1)*3+2]){
                                                    allocationResult = 3, processNo2 = "G_12";
                                                }
                                            }
                                        }
                                        else if (groupTablePreviousious [(previousConnectNumber1-1)*5+4] == 2000 && targetPointer == previousConnectNumber1 && overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] <= 0.5){
                                            if (arrayGroupInfoCurrent [(currentMajor-1)*3+2] != arrayGroupInfoCurrent [(overlapNumber-1)*3+2]) allocationResult = 3, processNo2 = "G_13";
                                        }
                                    }
                                }
                                else allocationResult = 3, processNo2 = "G_11.1";
                            }
                            else if (allocationResult == 3){
                                if (separateGroup == 1) allocationResult = 3, processNo2 = "G_14";
                                else{
                                    
                                    if (groupTablePreviousious [(previousConnectNumber1-1)*5+4] == 2000 && groupTablePreviousious [(previousConnectNumber1-1)*5+3] == 0){
                                        if ((arrayGroupInfoCurrent [(currentMajor-1)*3] == arrayGroupInfoCurrent [(overlapNumber-1)*3]*-1 || arrayGroupInfoCurrent [(currentMajor-1)*3]*-1 == arrayGroupInfoCurrent [(overlapNumber-1)*3] || arrayGroupInfoCurrent [(currentMajor-1)*3]*-1 == arrayGroupInfoCurrent [(overlapNumber-1)*3]*-1) && attachCount > 10){
                                            allocationResult = 5, processNo2 = "G_15";
                                        }
                                        else if (arrayGroupInfoCurrent [(currentMajor-1)*3+2] == arrayGroupInfoCurrent [(overlapNumber-1)*3+2] && arrayCurrentAverageTrack [currentMajor]*0.6 < arrayCurrentAverageTrack [overlapNumber] && arrayCurrentAverageTrack [currentMajor]*1.4 > arrayCurrentAverageTrack [overlapNumber] && attachCount > 10){
                                            allocationResult = 5, processNo2 = "G_16";
                                        }
                                        else if (overlapAreaTable [counter1][1]/(double)arrayCurrentTableTrack [overlapNumber*2] > 0.4 && attachCount > 10) allocationResult = 5, processNo2 = "G_17";
                                    }
                                    else if (groupTablePreviousious [(previousConnectNumber1-1)*5+4] <= 10 && groupTablePreviousious [(previousConnectNumber1-1)*5+3] == 0){
                                        if ((arrayGroupInfoCurrent [(currentMajor-1)*3] == arrayGroupInfoCurrent [(overlapNumber-1)*3]*-1) || (arrayGroupInfoCurrent [(currentMajor-1)*3]*-1 == arrayGroupInfoCurrent [(overlapNumber-1)*3]) ||(arrayGroupInfoCurrent [(currentMajor-1)*3]*-1 == arrayGroupInfoCurrent [(overlapNumber-1)*3]*-1)){
                                            if (arrayCurrentAverageTrack [currentMajor]*0.6 < arrayCurrentAverageTrack [overlapNumber] && arrayCurrentAverageTrack [currentMajor]*1.4 > arrayCurrentAverageTrack [overlapNumber]) allocationResult = 3, processNo2 = "G_18";
                                            else if (attachCount > 10) allocationResult = 5, processNo2 = "G_19";
                                        }
                                        else if (arrayGroupInfoCurrent [(currentMajor-1)*3+2] == arrayGroupInfoCurrent [(overlapNumber-1)*3+2] && arrayCurrentAverageTrack [currentMajor]*0.6 < arrayCurrentAverageTrack [overlapNumber] && arrayCurrentAverageTrack [currentMajor]*1.4 > arrayCurrentAverageTrack [overlapNumber] && attachCount > 10){
                                            allocationResult = 5, processNo2 = "G_20";
                                        }
                                        else if (arrayGroupInfoCurrent [(currentMajor-1)*3+2] != arrayGroupInfoCurrent [(overlapNumber-1)*3+2]) allocationResult = 3, processNo2 = "G_21";
                                    }
                                }
                            }
                            
                            //cout<<"AllResult2 "<<allocationResult<<" "<<processNo2<<endl;
                            
                            errorNoHold = 37;
                            int *arrayPreviousTableTemp = new int [lineNumberPrevious2*2+50];
                            previousTableCountTemp = 0;
                            errorNoHold = 38;
                            int *arrayPreviousTotalTemp = new int [lineNumberPrevious2+50];
                            previousTotalCountTemp = 0;
                            
                            errorNoHold = 39;
                            double *arrayPreviousAverageTemp = new double [lineNumberPrevious2+50];
                            previousAverageCountTemp = 0;
                            
                            errorNoHold = 40;
                            int *arrayCurrentTableTemp = new int [lineNumberCurrent2*2+50];
                            currentTableCountTemp = 0;
                            errorNoHold = 41;
                            int *arrayCurrentTotalTemp = new int [lineNumberCurrent2+50];
                            currentTotalCountTemp = 0;
                            
                            errorNoHold = 42;
                            double *arrayCurrentAverageTemp = new double [lineNumberCurrent2+50];
                            currentAverageCountTemp = 0;
                            
                            //+++++++++++Division++++++++++
                            if (allocationResult == 1 || allocationResult == 2){ //------Previous Divide, 1: flat, 2, over 220/below 220------
                                
                                //cout<<" ALR_ 1_2_Div "<<" PrevNo "<<previousConnectNumber1<<" PrevAdd "<<lineNumberPrevious2+additionCount<<endl;
                                
                                maxPointDimX = 0;
                                maxPointDimY = 0;
                                minPointDimX = 1000000;
                                minPointDimY = 1000000;
                                
                                for (int counter2 = 0; counter2 < cellTrackingPreviousCount/6; counter2++){
                                    if (arrayCellTrackingPrevious [counter2*6+3] == previousConnectNumber1){
                                        if (maxPointDimX < arrayCellTrackingPrevious [counter2*6]) maxPointDimX = arrayCellTrackingPrevious [counter2*6];
                                        if (minPointDimX > arrayCellTrackingPrevious [counter2*6]) minPointDimX = arrayCellTrackingPrevious [counter2*6];
                                        if (maxPointDimY < arrayCellTrackingPrevious [counter2*6+1]) maxPointDimY = arrayCellTrackingPrevious [counter2*6+1];
                                        if (minPointDimY > arrayCellTrackingPrevious [counter2*6+1]) minPointDimY = arrayCellTrackingPrevious [counter2*6+1];
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < cellTrackingCurrentCount/6; counter2++){
                                    if (arrayCellTrackingCurrent [counter2*6+3] == overlapNumber || arrayCellTrackingCurrent [counter2*6+3] == currentMajor){
                                        if (maxPointDimX < arrayCellTrackingCurrent [counter2*6]) maxPointDimX = arrayCellTrackingCurrent [counter2*6];
                                        if (minPointDimX > arrayCellTrackingCurrent [counter2*6]) minPointDimX = arrayCellTrackingCurrent [counter2*6];
                                        if (maxPointDimY < arrayCellTrackingCurrent [counter2*6+1]) maxPointDimY = arrayCellTrackingCurrent [counter2*6+1];
                                        if (minPointDimY > arrayCellTrackingCurrent [counter2*6+1]) minPointDimY = arrayCellTrackingCurrent [counter2*6+1];
                                    }
                                }
                                
                                dimensionTemp = 0;
                                horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                                verticalLength = (maxPointDimY-minPointDimY)/2*2;
                                
                                if (horizontalLength >= verticalLength) dimensionTemp = horizontalLength+30;
                                if (horizontalLength < verticalLength) dimensionTemp = verticalLength+30;
                                
                                if (dimensionTemp < 128) dimensionTemp = 128;
                                else dimensionTemp = (dimensionTemp/2)*2;
                                
                                horizontalStart2 = minPointDimX-(dimensionTemp-horizontalLength)/2;
                                verticalStart2 = minPointDimY-(dimensionTemp-verticalLength)/2;
                                
                                errorNoHold = 43;
                                int **connectivityUpdate = new int *[dimensionTemp+5];
                                errorNoHold = 44;
                                int **connectivityUpdate2 = new int *[dimensionTemp+5];
                                errorNoHold = 45;
                                int **connectivityUpdate3 = new int *[dimensionTemp+5];
                                errorNoHold = 46;
                                int **connectivityUpdate4 = new int *[dimensionTemp+5];
                                errorNoHold = 47;
                                int **connectivityUpdate5 = new int *[dimensionTemp+5];
                                
                                for (int counter2 = 0; counter2 < dimensionTemp+5; counter2++){
                                    errorNoHold = 48;
                                    connectivityUpdate [counter2] = new int [dimensionTemp+5];
                                    errorNoHold = 49;
                                    connectivityUpdate2 [counter2] = new int [dimensionTemp+5];
                                    errorNoHold = 50;
                                    connectivityUpdate3 [counter2] = new int [dimensionTemp+5];
                                    errorNoHold = 51;
                                    connectivityUpdate4 [counter2] = new int [dimensionTemp+5];
                                    errorNoHold = 52;
                                    connectivityUpdate5 [counter2] = new int [dimensionTemp+5];
                                }
                                
                                for (int counterY = 0; counterY < dimensionTemp+5; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp+5; counterX++){
                                        connectivityUpdate [counterY][counterX] = 0;
                                        connectivityUpdate2 [counterY][counterX] = 0;
                                        connectivityUpdate3 [counterY][counterX] = 0;
                                        connectivityUpdate4 [counterY][counterX] = 0;
                                        connectivityUpdate5 [counterY][counterX] = 0;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < cellTrackingPreviousCount/6; counter2++){
                                    if (arrayCellTrackingPrevious [counter2*6+3] == previousConnectNumber1){
                                        connectivityUpdate [arrayCellTrackingPrevious [counter2*6+1]-verticalStart2+1][arrayCellTrackingPrevious [counter2*6]-horizontalStart2+1] = 1;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < dimensionTemp+2; counterA++){
                                //	for (int counterB = 0; counterB < dimensionTemp+2; counterB++) cout<<" "<<connectivityUpdate [counterA][counterB];
                                //	cout<<" connectivityUpdate "<<counterA<<endl;
                                //}
                                
                                for (int counter2 = 0; counter2 < cellTrackingCurrentCount/6; counter2++){
                                    if (arrayCellTrackingCurrent [counter2*6+3] == overlapNumber){
                                        connectivityUpdate2 [arrayCellTrackingCurrent [counter2*6+1]-verticalStart2+1][arrayCellTrackingCurrent [counter2*6]-horizontalStart2+1] = 1;
                                    }
                                    
                                    if (arrayCellTrackingCurrent [counter2*6+3] == currentMajor){
                                        connectivityUpdate3 [arrayCellTrackingCurrent [counter2*6+1]-verticalStart2+1][arrayCellTrackingCurrent [counter2*6]-horizontalStart2+1] = 1;
                                    }
                                }
                                
                                errorNoHold = 53;
                                int *connectAnalysisX = new int [(dimensionTemp+2)*4];
                                errorNoHold = 54;
                                int *connectAnalysisY = new int [(dimensionTemp+2)*4];
                                errorNoHold = 55;
                                int *connectAnalysisTempX = new int [(dimensionTemp+2)*4];
                                errorNoHold = 56;
                                int *connectAnalysisTempY = new int [(dimensionTemp+2)*4];
                                
                                connectivityNumber = 0;
                                
                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                        if (connectivityUpdate [counterY][counterX] == 0){
                                            connectivityNumber--;
                                            connectivityUpdate [counterY][counterX] = connectivityNumber;
                                            
                                            connectAnalysisCount = 0;
                                            
                                            if (counterY-1 >= 0 && connectivityUpdate [counterY-1][counterX] == 0){
                                                connectivityUpdate [counterY-1][counterX] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                            }
                                            if (counterX+1 < dimensionTemp+2 && connectivityUpdate [counterY][counterX+1] == 0){
                                                connectivityUpdate [counterY][counterX+1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                            }
                                            if (counterY+1 < dimensionTemp+2 && connectivityUpdate [counterY+1][counterX] == 0){
                                                connectivityUpdate [counterY+1][counterX] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                            }
                                            if (counterX-1 >= 0 && connectivityUpdate [counterY][counterX-1] == 0){
                                                connectivityUpdate [counterY][counterX-1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                            }
                                            
                                            if (connectAnalysisCount != 0){
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    connectAnalysisTempCount = 0;
                                                    
                                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                        
                                                        if (ySource-1 >= 0 && connectivityUpdate [ySource-1][xSource] == 0){
                                                            connectivityUpdate [ySource-1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource+1 < dimensionTemp+2 && connectivityUpdate [ySource][xSource+1] == 0){
                                                            connectivityUpdate [ySource][xSource+1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                        if (ySource+1 < dimensionTemp+2 && connectivityUpdate [ySource+1][xSource] == 0){
                                                            connectivityUpdate [ySource+1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource-1 >= 0 && connectivityUpdate [ySource][xSource-1] == 0){
                                                            connectivityUpdate [ySource][xSource-1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                    }
                                                    
                                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                                    }
                                                    
                                                    connectAnalysisCount = connectAnalysisTempCount;
                                                    
                                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                                    
                                                } while (terminationFlag == 1);
                                            }
                                        }
                                    }
                                }
                                
                                if (allocationResult == 1){
                                    for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                        for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                            if (connectivityUpdate [counterY][counterX] == -1) connectivityUpdate [counterY][counterX] = 0;
                                            else connectivityUpdate [counterY][counterX] = -1;
                                        }
                                    }
                                }
                                else{
                                    
                                    for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                        for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                            if (connectivityUpdate [counterY][counterX] == -1) connectivityUpdate [counterY][counterX] = 0;
                                            else{
                                                
                                                if (counterY+verticalStart2-1 >= 0 && counterY+verticalStart2-1 < imageDimension && counterX+horizontalStart2-1 >= 0 && counterX+horizontalStart2-1 < imageDimension){
                                                    if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2-1)*imageDimension+counterX+horizontalStart2-1] < cutOff2) connectivityUpdate [counterY][counterX] = -1;
                                                    else if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2-1)*imageDimension+counterX+horizontalStart2-1] >= cutOff2) connectivityUpdate [counterY][counterX] = -2;
                                                    else connectivityUpdate [counterY][counterX] = 0;
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                additionCount++;
                                previousPairAddition++;
                                
                                connectivityNumber = 0;
                                
                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                        if (connectivityUpdate2 [counterY][counterX] == 0){
                                            connectivityNumber--;
                                            connectivityUpdate2 [counterY][counterX] = connectivityNumber;
                                            
                                            connectAnalysisCount = 0;
                                            
                                            if (counterY-1 >= 0 && connectivityUpdate2 [counterY-1][counterX] == 0){
                                                connectivityUpdate2 [counterY-1][counterX] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                            }
                                            if (counterX+1 < dimensionTemp+2 && connectivityUpdate2 [counterY][counterX+1] == 0){
                                                connectivityUpdate2 [counterY][counterX+1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                            }
                                            if (counterY+1 < dimensionTemp+2 && connectivityUpdate2 [counterY+1][counterX] == 0){
                                                connectivityUpdate2 [counterY+1][counterX] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                            }
                                            if (counterX-1 >= 0 && connectivityUpdate2 [counterY][counterX-1] == 0){
                                                connectivityUpdate2 [counterY][counterX-1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                            }
                                            
                                            if (connectAnalysisCount != 0){
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    connectAnalysisTempCount = 0;
                                                    
                                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                        
                                                        if (ySource-1 >= 0 && connectivityUpdate2 [ySource-1][xSource] == 0){
                                                            connectivityUpdate2 [ySource-1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource+1 < dimensionTemp+2 && connectivityUpdate2 [ySource][xSource+1] == 0){
                                                            connectivityUpdate2 [ySource][xSource+1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                        if (ySource+1 < dimensionTemp+2 && connectivityUpdate2 [ySource+1][xSource] == 0){
                                                            connectivityUpdate2 [ySource+1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource-1 >= 0 && connectivityUpdate2 [ySource][xSource-1] == 0){
                                                            connectivityUpdate2 [ySource][xSource-1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                    }
                                                    
                                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                                    }
                                                    
                                                    connectAnalysisCount = connectAnalysisTempCount;
                                                    
                                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                                    
                                                } while (terminationFlag == 1);
                                            }
                                        }
                                    }
                                }
                                
                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                        if (connectivityUpdate2 [counterY][counterX] == -1) connectivityUpdate2 [counterY][counterX] = 0;
                                        else connectivityUpdate2 [counterY][counterX] = lineNumberPrevious2+additionCount;
                                    }
                                }
                                
                                connectivityNumber = 0;
                                
                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                        if (connectivityUpdate3 [counterY][counterX] == 0){
                                            connectivityNumber--;
                                            connectivityUpdate3 [counterY][counterX] = connectivityNumber;
                                            
                                            connectAnalysisCount = 0;
                                            
                                            if (counterY-1 >= 0 && connectivityUpdate3 [counterY-1][counterX] == 0){
                                                connectivityUpdate3 [counterY-1][counterX] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                            }
                                            if (counterX+1 < dimensionTemp+2 && connectivityUpdate3 [counterY][counterX+1] == 0){
                                                connectivityUpdate3 [counterY][counterX+1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                            }
                                            if (counterY+1 < dimensionTemp+2 && connectivityUpdate3 [counterY+1][counterX] == 0){
                                                connectivityUpdate3 [counterY+1][counterX] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                            }
                                            if (counterX-1 >= 0 && connectivityUpdate3 [counterY][counterX-1] == 0){
                                                connectivityUpdate3 [counterY][counterX-1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                            }
                                            
                                            if (connectAnalysisCount != 0){
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    connectAnalysisTempCount = 0;
                                                    
                                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                        
                                                        if (ySource-1 >= 0 && connectivityUpdate3 [ySource-1][xSource] == 0){
                                                            connectivityUpdate3 [ySource-1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource+1 < dimensionTemp+2 && connectivityUpdate3 [ySource][xSource+1] == 0){
                                                            connectivityUpdate3 [ySource][xSource+1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                        if (ySource+1 < dimensionTemp+2 && connectivityUpdate3 [ySource+1][xSource] == 0){
                                                            connectivityUpdate3 [ySource+1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource-1 >= 0 && connectivityUpdate3 [ySource][xSource-1] == 0){
                                                            connectivityUpdate3 [ySource][xSource-1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                    }
                                                    
                                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                                    }
                                                    
                                                    connectAnalysisCount = connectAnalysisTempCount;
                                                    
                                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                                    
                                                } while (terminationFlag == 1);
                                            }
                                        }
                                    }
                                }
                                
                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                        if (connectivityUpdate3 [counterY][counterX] == -1) connectivityUpdate3 [counterY][counterX] = 0;
                                        else connectivityUpdate3 [counterY][counterX] = previousConnectNumber1;
                                    }
                                }
                                
                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                        if (connectivityUpdate2 [counterY][counterX] != 0 && connectivityUpdate [counterY][counterX] < 0){
                                            connectivityUpdate [counterY][counterX] = connectivityUpdate2 [counterY][counterX];
                                        }
                                        else if (connectivityUpdate3 [counterY][counterX] != 0 && connectivityUpdate [counterY][counterX] < 0){
                                            connectivityUpdate [counterY][counterX] = connectivityUpdate3 [counterY][counterX];
                                        }
                                        
                                        connectivityUpdate3 [counterY][counterX] = 0;
                                        connectivityUpdate4 [counterY][counterX] = 0;
                                    }
                                }
                                
                                //cout<<" AddCount "<<additionCount<<" PrevPairAdd "<<previousPairAddition<<endl;
                                
                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++) connectivityUpdate2 [counterY][counterX] = connectivityUpdate [counterY][counterX];
                                }
                                
                                //======Inside check=====
                                errorNoHold = 57;
                                int *insideCheck = new int [lineNumberPrevious2*2+5];
                                
                                for (int counter2 = 0; counter2 < lineNumberPrevious2*2+5; counter2++) insideCheck [counter2] = 0;
                                
                                for (int counterY = 1; counterY < dimensionTemp+1; counterY++){
                                    for (int counterX = 1; counterX < dimensionTemp+1; counterX++){
                                        if (counterY+verticalStart2-1 >= 0 && counterY+verticalStart2-1 < trackAreaSize && counterX+horizontalStart2-1 >= 0 && counterX+horizontalStart2-1 < trackAreaSize){
                                            if (connectivityUpdate2 [counterY][counterX] != 0 && arrayCellTrackingPreviousMap [counterY+verticalStart2-1][counterX+horizontalStart2-1] != 0){
                                                insideCheck [arrayCellTrackingPreviousMap [counterY+verticalStart2-1][counterX+horizontalStart2-1]*2]++;
                                            }
                                            else if (connectivityUpdate2 [counterY][counterX] == 0 && arrayCellTrackingPreviousMap [counterY+verticalStart2-1][counterX+horizontalStart2-1] != 0){
                                                insideCheck [arrayCellTrackingPreviousMap [counterY+verticalStart2-1][counterX+horizontalStart2-1]*2+1]++;
                                            }
                                        }
                                    }
                                }
                                
                                insideCheck [previousConnectNumber1*2] = 0;
                                
                                insideFind = 0;
                                
                                for (int counter2 = 1; counter2 <= lineNumberPrevious2; counter2++){
                                    if (insideCheck [counter2*2] != 0 && insideCheck [counter2*2+1] == 0) insideFind = 1;
                                    else if (insideCheck [counter2*2] != 0 && insideCheck [counter2*2+1] != 0) insideCheck [counter2*2] = 0;
                                }
                                
                                if (insideFind == 1){
                                    errorNoHold = 58;
                                    int **connectivityUpdateInside = new int *[dimensionTemp+5];
                                    
                                    for (int counter2 = 0; counter2 < dimensionTemp+5; counter2++){
                                        errorNoHold = 59;
                                        connectivityUpdateInside [counter2] = new int [dimensionTemp+5];
                                    }
                                    
                                    for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                        for (int counterX = 0; counterX < dimensionTemp+2; counterX++) connectivityUpdateInside [counterY][counterX] = 0;
                                    }
                                    
                                    for (int counterY = 1; counterY < dimensionTemp+1; counterY++){
                                        for (int counterX = 1; counterX < dimensionTemp+1; counterX++){
                                            if (counterY+verticalStart2-1 >= 0 && counterY+verticalStart2-1 < trackAreaSize && counterX+horizontalStart2-1 >= 0 && counterX+horizontalStart2-1 < trackAreaSize){
                                                if (arrayCellTrackingPreviousMap [counterY+verticalStart2-1][counterX+horizontalStart2-1] != 0){
                                                    for (int counter2 = 1; counter2 <= lineNumberPrevious2; counter2++){
                                                        if (insideCheck [counter2*2] != 0 && arrayCellTrackingPreviousMap [counterY+verticalStart2-1][counterX+horizontalStart2-1] == counter2){
                                                            connectivityUpdateInside [counterY][counterX] = 1;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < dimensionTemp+2; counterA++){
                                    //    for (int counterB = 0; counterB < dimensionTemp+2; counterB++) cout<<" "<<connectivityUpdateInside [counterA][counterB];
                                    //     cout<<" connectivityUpdateInside "<<counterA<<endl;
                                    // }
                                    
                                    for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                        for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                            if (connectivityUpdateInside [counterY][counterX] == 1) connectivityUpdate2 [counterY][counterX] = 0;
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < dimensionTemp+5; counter2++) delete [] connectivityUpdateInside [counter2];
                                    
                                    delete [] connectivityUpdateInside;
                                }
                                
                                delete [] insideCheck;
                                
                                highSideNumber = 0;
                                
                                if (highSide == 1) highSideNumber = previousConnectNumber1;
                                else if (highSide == 2) highSideNumber = lineNumberPrevious2+additionCount;
                                
                                terminationFlag = 0;
                                startOrder = 0;
                                
                                errorNoHold = 60;
                                int *extendConnectList2 = new int [6];
                                extendConnectList2 [0] = previousConnectNumber1;
                                extendConnectList2 [1] = 0;
                                extendConnectList2 [2] = lineNumberPrevious2+additionCount;
                                extendConnectList2 [3] = 0;
                                
                                extendConnectCount2 = 4;
                                
                                do{
                                    
                                    for (int counter2 = startOrder; counter2 < extendConnectCount2/2; counter2++){
                                        connectNo = extendConnectList2 [counter2*2];
                                        
                                        if (extendConnectList2 [counter2*2+1] == 0){
                                            findFreePoint = 0;
                                            
                                            for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                                for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                    if (connectivityUpdate [counterY][counterX] == connectNo){
                                                        if (counterY-1 >= 0 && counterX-1 >= 0 && ((highSideNumber == 0 && connectivityUpdate [counterY-1][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY-1][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY-1][counterX-1] == -2))){
                                                            connectivityUpdate2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                                        }
                                                        if (counterY-1 >= 0 && ((highSideNumber == 0 && connectivityUpdate [counterY-1][counterX] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY-1][counterX] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY-1][counterX] == -2))){
                                                            connectivityUpdate2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                                        }
                                                        if (counterY-1 >= 0 && counterX+1 < dimensionTemp+2 && ((highSideNumber == 0 && connectivityUpdate [counterY-1][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY-1][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY-1][counterX+1] == -2))){
                                                            connectivityUpdate2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                                        }
                                                        if (counterX+1 < dimensionTemp+2 && ((highSideNumber == 0 && connectivityUpdate [counterY][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY][counterX+1] == -2))){
                                                            connectivityUpdate2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                                        }
                                                        if (counterY+1 < dimensionTemp+2 && counterX+1 < dimensionTemp+2 && ((highSideNumber == 0 && connectivityUpdate [counterY+1][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY+1][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY+1][counterX+1] == -2))){
                                                            connectivityUpdate2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                                        }
                                                        if (counterY+1 < dimensionTemp+2 && ((highSideNumber == 0 && connectivityUpdate [counterY+1][counterX] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY+1][counterX] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY+1][counterX] == -2))){
                                                            connectivityUpdate2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                                        }
                                                        if (counterY+1 < dimensionTemp+2 && counterX-1 >= 0 && ((highSideNumber == 0 && connectivityUpdate [counterY+1][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY+1][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY+1][counterX-1] == -2))){
                                                            connectivityUpdate2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                                        }
                                                        if (counterX-1 >= 0 && ((highSideNumber == 0 && connectivityUpdate [counterY][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY][counterX-1] == -2))){
                                                            connectivityUpdate2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                                for (int counterX = 0; counterX < dimensionTemp+2; counterX++) connectivityUpdate [counterY][counterX] = connectivityUpdate2 [counterY][counterX];
                                            }
                                            
                                            if (findFreePoint == 0) extendConnectList2 [counter2*2+1] = 1;
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < startOrder; counter2++){
                                        connectNo = extendConnectList2 [counter2*2];
                                        
                                        if (extendConnectList2 [counter2*2+1] == 0){
                                            findFreePoint = 0;
                                            
                                            for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                                for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                    if (connectivityUpdate [counterY][counterX] == connectNo){
                                                        if (counterY-1 >= 0 && counterX-1 >= 0 && ((highSideNumber == 0 && connectivityUpdate [counterY-1][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY-1][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY-1][counterX-1] == -2))){
                                                            connectivityUpdate2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                                        }
                                                        if (counterY-1 >= 0  && ((highSideNumber == 0 && connectivityUpdate [counterY-1][counterX] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY-1][counterX] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY-1][counterX] == -2))){
                                                            connectivityUpdate2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                                        }
                                                        if (counterY-1 >= 0 && counterX+1 < dimensionTemp+2 && ((highSideNumber == 0 && connectivityUpdate [counterY-1][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY-1][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY-1][counterX+1] == -2))){
                                                            connectivityUpdate2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                                        }
                                                        if (counterX+1 < dimensionTemp+2 && ((highSideNumber == 0 && connectivityUpdate [counterY][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY][counterX+1] == -2))){
                                                            connectivityUpdate2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                                        }
                                                        if (counterY+1 < dimensionTemp+2 && counterX+1 < dimensionTemp+2 && ((highSideNumber == 0 && connectivityUpdate [counterY+1][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY+1][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY+1][counterX+1] == -2))){
                                                            connectivityUpdate2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                                        }
                                                        if (counterY+1 < dimensionTemp+2 && ((highSideNumber == 0 && connectivityUpdate [counterY+1][counterX] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY+1][counterX] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY+1][counterX] == -2))){
                                                            connectivityUpdate2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                                        }
                                                        if (counterY+1 < dimensionTemp+2 && counterX-1 >= 0 && ((highSideNumber == 0 && connectivityUpdate [counterY+1][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY+1][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY+1][counterX-1] == -2))){
                                                            connectivityUpdate2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                                        }
                                                        if (counterX-1 >= 0 && ((highSideNumber == 0 && connectivityUpdate [counterY][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY][counterX-1] == -2))){
                                                            connectivityUpdate2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                                for (int counterX = 0; counterX < dimensionTemp+2; counterX++) connectivityUpdate [counterY][counterX] = connectivityUpdate2 [counterY][counterX];
                                            }
                                            
                                            if (findFreePoint == 0) extendConnectList2 [counter2*2+1] = 1;
                                        }
                                    }
                                    
                                    remainingCheck = 0;
                                    
                                    for (int counter2 = 0; counter2 < extendConnectCount2/2; counter2++){
                                        if (extendConnectList2 [counter2*2+1] == 0) remainingCheck = 1;
                                    }
                                    
                                    if (remainingCheck == 0) terminationFlag = 1;
                                    
                                    startOrder++;
                                    
                                    if (startOrder == extendConnectCount2/2) startOrder = 0;
                                    
                                } while (terminationFlag == 0);
                                
                                delete [] extendConnectList2;
                                
                                currentPixCount1 = 0;
                                currentPixCount2 = 0;
                                gravityX1 = 0;
                                gravityY1 = 0;
                                gravityX2 = 0;
                                gravityY2 = 0;
                                
                                //------Tracking Data Up-Date------
                                errorNoHold = 61;
                                int *arrayCellTrackingCurrentTemp = new int [cellTrackingPreviousCount+50];
                                cellTrackingCurrentTempCount = 0;
                                cellTrackingCurrentTempLimit = cellTrackingPreviousCount+50;
                                
                                for (int counter2 = 0; counter2 < cellTrackingPreviousCount/6; counter2++){
                                    if (arrayCellTrackingPrevious [counter2*6+3] != previousConnectNumber1){
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingPrevious [counter2*6], cellTrackingCurrentTempCount++;
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingPrevious [counter2*6+1], cellTrackingCurrentTempCount++;
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingPrevious [counter2*6+2], cellTrackingCurrentTempCount++;
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingPrevious [counter2*6+3], cellTrackingCurrentTempCount++;
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingPrevious [counter2*6+4], cellTrackingCurrentTempCount++;
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingPrevious [counter2*6+5], cellTrackingCurrentTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < 2; counter2++){
                                    if (counter2 == 0) connectProcessNo = lineNumberPrevious2+additionCount;
                                    else connectProcessNo = previousConnectNumber1;
                                    
                                    for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                        for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                            if (connectivityUpdate [counterY][counterX] == connectProcessNo) connectivityUpdate2 [counterY][counterX] = connectProcessNo;
                                            else connectivityUpdate2 [counterY][counterX] = 0;
                                        }
                                    }
                                    
                                    //-------Zero Fill-------
                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                        for (int counterY = 0; counterY < dimensionTemp+2; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
                                    }
                                    
                                    for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                        for (int counterX = 0; counterX < dimensionTemp+2; counterX++) connectivityUpdate5 [counterY][counterX] = connectivityUpdate2 [counterY][counterX];
                                    }
                                    
                                    connectivityNumber = 0;
                                    
                                    for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                        for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                            if (connectivityUpdate5 [counterY2][counterX2] == 0){
                                                connectivityNumber--;
                                                connectAnalysisCount = 0;
                                                
                                                connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                                                
                                                if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                                                    connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                                }
                                                if (counterX2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                                    connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                                }
                                                if (counterY2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                                    connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                                }
                                                if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                                    connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                                }
                                                
                                                if (connectAnalysisCount != 0){
                                                    do{
                                                        
                                                        terminationFlag = 1;
                                                        connectAnalysisTempCount = 0;
                                                        
                                                        for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                            xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                            
                                                            if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                                                connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                            }
                                                            if (xSource+1 < dimensionTemp+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                                                connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                            }
                                                            if (ySource+1 < dimensionTemp+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                                                connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                            }
                                                            if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                                                connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                            }
                                                        }
                                                        
                                                        for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                            connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                        }
                                                        
                                                        connectAnalysisCount = connectAnalysisTempCount;
                                                        
                                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                                        
                                                    } while (terminationFlag == 1);
                                                }
                                            }
                                        }
                                    }
                                    
                                    if (connectivityNumber < -1){
                                        errorNoHold = 62;
                                        int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                                        
                                        for (int counter3 = 0; counter3 < connectivityNumber*-1*2+5; counter3++) connectCheckArray [counter3] = 0;
                                        
                                        for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                            for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                                                
                                                if (connectTemp2 < -1){
                                                    connectTemp2 = connectTemp2*-1;
                                                    
                                                    if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                    }
                                                    if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                                    }
                                                    if (counterY2-1 >= 0 && counterX2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                    }
                                                    if (counterX2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                    }
                                                    if (counterY2+1 < dimensionTemp+2 && counterX2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                    }
                                                    if (counterY2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                                    }
                                                    if (counterY2+1 < dimensionTemp+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                    }
                                                    if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        zeroFillFlag = 0;
                                        
                                        for (int counter3 = 2; counter3 <= connectivityNumber*-1; counter3++){
                                            if (connectCheckArray [counter3*2] != 0 &&  connectCheckArray [counter3*2+1] == 0) zeroFillFlag = 1;
                                        }
                                        
                                        if (zeroFillFlag == 1){
                                            for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                                for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                    connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                                                    
                                                    if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                                                }
                                            }
                                            
                                            for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                                for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                    if (connectivityUpdate5 [counterY2][counterX2] > 0) connectivityUpdate2 [counterY2][counterX2] = connectivityUpdate5 [counterY2][counterX2];
                                                }
                                            }
                                        }
                                        
                                        delete [] connectCheckArray;
                                    }
                                    
                                    for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                        for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                            if (connectivityUpdate2 [counterY][counterX] != 0){
                                                if (counterX+1 < dimensionTemp+2 && connectivityUpdate2 [counterY][counterX+1] == 0) connectivityUpdate2 [counterY][counterX] = -1;
                                                else if (counterY+1 < dimensionTemp+2 && connectivityUpdate2 [counterY+1][counterX] == 0) connectivityUpdate2 [counterY][counterX] = -1;
                                                else if (counterX-1 >= 0 && connectivityUpdate2 [counterY][counterX-1] == 0) connectivityUpdate2 [counterY][counterX] = -1;
                                                else if (counterY-1 >= 0 && connectivityUpdate2 [counterY-1][counterX] == 0) connectivityUpdate2 [counterY][counterX] = -1;
                                            }
                                        }
                                    }
                                    
                                    for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                        for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                            if (connectivityUpdate2 [counterY][counterX] > 0) connectivityUpdate2 [counterY][counterX] = 0;
                                            if (connectivityUpdate2 [counterY][counterX] < 0) connectivityUpdate2 [counterY][counterX] = 1;
                                        }
                                    }
                                    
                                    connectivityNumber = 0;
                                    
                                    for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                        for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                            if (connectivityUpdate2 [counterY2][counterX2] == 0){
                                                connectivityNumber--;
                                                connectAnalysisCount = 0;
                                                
                                                connectivityUpdate2 [counterY2][counterX2] = connectivityNumber;
                                                
                                                if (counterY2-1 >= 0 && connectivityUpdate2 [counterY2-1][counterX2] == 0){
                                                    connectivityUpdate2 [counterY2-1][counterX2] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                                }
                                                if (counterX2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2][counterX2+1] == 0){
                                                    connectivityUpdate2 [counterY2][counterX2+1] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                                }
                                                if (counterY2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2+1][counterX2] == 0){
                                                    connectivityUpdate2 [counterY2+1][counterX2] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                                }
                                                if (counterX2-1 >= 0 && connectivityUpdate2 [counterY2][counterX2-1] == 0){
                                                    connectivityUpdate2 [counterY2][counterX2-1] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                                }
                                                
                                                if (connectAnalysisCount != 0){
                                                    do{
                                                        
                                                        terminationFlag = 1;
                                                        connectAnalysisTempCount = 0;
                                                        
                                                        for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                            xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                            
                                                            if (ySource-1 >= 0 && connectivityUpdate2 [ySource-1][xSource] == 0){
                                                                connectivityUpdate2 [ySource-1][xSource] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                            }
                                                            if (xSource+1 < dimensionTemp+2 && connectivityUpdate2 [ySource][xSource+1] == 0){
                                                                connectivityUpdate2 [ySource][xSource+1] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                            }
                                                            if (ySource+1 < dimensionTemp+2 && connectivityUpdate2 [ySource+1][xSource] == 0){
                                                                connectivityUpdate2 [ySource+1][xSource] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                            }
                                                            if (xSource-1 >= 0 && connectivityUpdate2 [ySource][xSource-1] == 0){
                                                                connectivityUpdate2 [ySource][xSource-1] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                            }
                                                        }
                                                        
                                                        for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                            connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                        }
                                                        
                                                        connectAnalysisCount = connectAnalysisTempCount;
                                                        
                                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                                        
                                                    } while (terminationFlag == 1);
                                                }
                                            }
                                        }
                                    }
                                    
                                    //------Determine number of pixels------
                                    connectivityNumber = connectivityNumber*-1;
                                    
                                    errorNoHold = 63;
                                    int *connectedPixels2 = new int [connectivityNumber+50];
                                    
                                    for (int counter3 = 0; counter3 < connectivityNumber+50; counter3++) connectedPixels2 [counter3] = 0;
                                    
                                    for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                        for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                            if (connectivityUpdate2 [counterY2][counterX2] < -1) connectedPixels2 [connectivityUpdate2 [counterY2][counterX2]*-1]++;
                                        }
                                    }
                                    
                                    for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                        for (int counterX = 0; counterX < dimensionTemp+2; counterX++) connectivityUpdate5 [counterY][counterX] = 0;
                                    }
                                    
                                    largestConnect = 0;
                                    largestConnectNo = 0;
                                    
                                    for (int counter3 = 2; counter3 <= connectivityNumber; counter3++){
                                        if (connectedPixels2 [counter3] > largestConnect){
                                            largestConnect = connectedPixels2 [counter3];
                                            largestConnectNo = counter3;
                                        }
                                    }
                                    
                                    delete [] connectedPixels2;
                                    
                                    if (largestConnect > 20){
                                        for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                            for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                if (connectivityUpdate2 [counterY2][counterX2] == largestConnectNo*-1){
                                                    if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate2 [counterY2-1][counterX2-1] == 1){
                                                        connectivityUpdate5 [counterY2-1][counterX2-1] = 1;
                                                        connectivityUpdate2 [counterY2-1][counterX2-1] = 0;
                                                    }
                                                    if (counterY2-1 >= 0 && connectivityUpdate2 [counterY2-1][counterX2] == 1){
                                                        connectivityUpdate5 [counterY2-1][counterX2] = 1;
                                                        connectivityUpdate2 [counterY2-1][counterX2] = 0;
                                                    }
                                                    if (counterY2-1 >= 0 && counterX2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2-1][counterX2+1] == 1){
                                                        connectivityUpdate5 [counterY2-1][counterX2+1] = 1;
                                                        connectivityUpdate2 [counterY2-1][counterX2+1] = 0;
                                                    }
                                                    if (counterX2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2][counterX2+1] == 1){
                                                        connectivityUpdate5 [counterY2][counterX2+1] = 1;
                                                        connectivityUpdate2 [counterY2][counterX2+1] = 0;
                                                    }
                                                    if (counterY2+1 < dimensionTemp+2 && counterX2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2+1][counterX2+1] == 1){
                                                        connectivityUpdate5 [counterY2+1][counterX2+1] = 1;
                                                        connectivityUpdate2 [counterY2+1][counterX2+1] = 0;
                                                    }
                                                    if (counterY2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2+1][counterX2] == 1){
                                                        connectivityUpdate5 [counterY2+1][counterX2] = 1;
                                                        connectivityUpdate2 [counterY2+1][counterX2] = 0;
                                                    }
                                                    if (counterY2+1 < dimensionTemp+2 && counterX2-1 >= 0 && connectivityUpdate2 [counterY2+1][counterX2-1] == 1){
                                                        connectivityUpdate5 [counterY2+1][counterX2-1] = 1;
                                                        connectivityUpdate2 [counterY2+1][counterX2-1] = 0;
                                                    }
                                                    if (counterX2-1 >= 0 && connectivityUpdate2 [counterY2][counterX2-1] == 1){
                                                        connectivityUpdate5 [counterY2][counterX2-1] = 1;
                                                        connectivityUpdate2 [counterY2][counterX2-1] = 0;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        xPositionTempStart = 0;
                                        yPositionTempStart = 0;
                                        lineSize = 0;
                                        
                                        for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                            for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                if (connectivityUpdate5 [counterY2][counterX2] == 1){
                                                    connectivityUpdate2 [counterY2][counterX2] = 1;
                                                    xPositionTempStart = counterX2;
                                                    yPositionTempStart = counterY2;
                                                    lineSize++;
                                                }
                                                else connectivityUpdate2 [counterY2][counterX2] = 0;
                                            }
                                        }
                                        
                                        constructedLineCount = 0;
                                        
                                        errorNoHold = 64;
                                        int *arrayNewLines = new int [lineSize*2+50];
                                        
                                        connectivityUpdate2 [yPositionTempStart][xPositionTempStart] = -1;
                                        arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                        arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                        
                                        do{
                                            
                                            findFlag = 0;
                                            terminationFlag = 0;
                                            
                                            if (xPositionTempStart+1 < dimensionTemp+2){
                                                if (connectivityUpdate2 [yPositionTempStart][xPositionTempStart+1] == 1){
                                                    connectivityUpdate2 [yPositionTempStart][xPositionTempStart+1] = -1;
                                                    arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                                    arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                                    xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                                }
                                            }
                                            if (xPositionTempStart+1 < dimensionTemp+2 && yPositionTempStart+1 < dimensionTemp+2 && findFlag == 0){
                                                if (connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                                                    connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                                                    arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                                    arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                                    xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                                }
                                            }
                                            if (yPositionTempStart+1 < dimensionTemp+2 && findFlag == 0){
                                                if (connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart] == 1){
                                                    connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart] = -1;
                                                    arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                                    arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                                    yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                                }
                                            }
                                            if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimensionTemp+2 && findFlag == 0){
                                                if (connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                                                    connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                                                    arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                                    arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                                    xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                                }
                                            }
                                            if (xPositionTempStart-1 >= 0 && findFlag == 0){
                                                if (connectivityUpdate2 [yPositionTempStart][xPositionTempStart-1] == 1){
                                                    connectivityUpdate2 [yPositionTempStart][xPositionTempStart-1] = -1;
                                                    arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                                    arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                                    xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                                }
                                            }
                                            if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                                                if (connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                                                    connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                                                    arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                                    arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                                    xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                                }
                                            }
                                            if (yPositionTempStart-1 >= 0 && findFlag == 0){
                                                if (connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart] == 1){
                                                    connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart] = -1;
                                                    arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                                    arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                                    yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                                }
                                            }
                                            if (xPositionTempStart+1 < dimensionTemp+2 && yPositionTempStart-1 >= 0 && findFlag == 0){
                                                if (connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                                                    connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                                                    arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                                    arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                                    xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                                                }
                                            }
                                            
                                        } while (terminationFlag == 1);
                                        
                                        //===========
                                        //int aa = arrayNewLines [0]-1;
                                        //int bb = arrayNewLines [1]-1;
                                        
                                        //int cc = arrayNewLines [(constructedLineCount/2-1)*2]-1;
                                        //int dd = arrayNewLines [(constructedLineCount/2-1)*2+1]-1;
                                        
                                        //int findLink = 0;
                                        
                                        //if (cc-1 == aa && dd-1 == bb) findLink = 1;
                                        //else  if (cc == aa && dd-1 == bb) findLink = 1;
                                        //else  if (cc+1 == aa && dd-1 == bb) findLink = 1;
                                        //else  if (cc+1 == aa && dd == bb) findLink = 1;
                                        //else  if (cc+1 == aa && dd+1 == bb) findLink = 1;
                                        //else  if (cc == aa && dd+1 == bb) findLink = 1;
                                        //else  if (cc-1 == aa && dd+1 == bb) findLink = 1;
                                        //else  if (cc-1 == aa && dd == bb) findLink = 1;
                                        
                                        //if (findLink == 0){
                                        //    for (int counterA = 0; counterA < dimensionTemp+2; counterA++){
                                        //        for (int counterB = 0; counterB < dimensionTemp+2; counterB++) cout<<" "<<connectivityUpdate2 [counterA][counterB];
                                        //        cout<<" connectivityUpdate2 "<<counterA<<endl;
                                        //    }
                                        //}
                                        
                                        //for (int counterA = 0; counterA < dimensionTemp+2; counterA++){
                                        //    for (int counterB = 0; counterB < dimensionTemp+2; counterB++) cout<<" "<< connectivityUpdate2 [counterA][counterB];
                                        //     cout<<"  connectivityUpdate2 "<<counterA<<endl;
                                        // }
                                        
                                        errorNoHold = 65;
                                        int *arrayUpDate = new int [cellTrackingCurrentTempCount+10];
                                        
                                        for (int counter3 = 0; counter3 < cellTrackingCurrentTempCount+10; counter3++) arrayUpDate [counter3] = arrayCellTrackingCurrentTemp [counter3];
                                        
                                        delete [] arrayCellTrackingCurrentTemp;
                                        errorNoHold = 66;
                                        arrayCellTrackingCurrentTemp = new int [cellTrackingCurrentTempLimit+constructedLineCount*3+50];
                                        cellTrackingCurrentTempLimit = cellTrackingCurrentTempLimit+constructedLineCount*3+50;
                                        
                                        for (int counter3 = 0; counter3 < cellTrackingCurrentTempCount; counter3++) arrayCellTrackingCurrentTemp [counter3] = arrayUpDate [counter3];
                                        delete [] arrayUpDate;
                                        
                                        if (counter2 == 0){
                                            for (int counter3 = 0; counter3 < constructedLineCount/2; counter3++){
                                                connectivityUpdate3 [arrayNewLines [counter3*2+1]-1][arrayNewLines [counter3*2]-1] = 1;
                                                
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayNewLines [counter3*2]-1+horizontalStart2, cellTrackingCurrentTempCount++;
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayNewLines [counter3*2+1]-1+verticalStart2, cellTrackingCurrentTempCount++;
                                                
                                                if (arrayNewLines [counter3*2+1]-1+verticalStart2 >= 0 && arrayNewLines [counter3*2+1]-1+verticalStart2 < imageDimension && arrayNewLines [counter3*2]-1+horizontalStart2 >= 0 && arrayNewLines [counter3*2]-1+horizontalStart2 < imageDimension){
                                                    arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = sourceImage [mapPositionPointerCurrent][(arrayNewLines [counter3*2+1]-1+verticalStart2)*imageDimension+arrayNewLines [counter3*2]-1+horizontalStart2], cellTrackingCurrentTempCount++;
                                                }
                                                else arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 100, cellTrackingCurrentTempCount++;
                                                
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = lineNumberPrevious2+additionCount, cellTrackingCurrentTempCount++;
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 0, cellTrackingCurrentTempCount++;
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 0, cellTrackingCurrentTempCount++;
                                            }
                                            
                                            connectivityNumber = -3;
                                            
                                            for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                                for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                                    if (connectivityUpdate3 [counterY][counterX] == 0){
                                                        connectivityNumber = connectivityNumber+2;
                                                        connectAnalysisCount = 0;
                                                        
                                                        if (connectivityNumber >= 1) connectivityNumber = 1, connectivityUpdate3 [counterY][counterX] = connectivityNumber;
                                                        
                                                        if (counterY-1 >= 0 &&  connectivityUpdate3 [counterY-1][counterX] == 0){
                                                            connectivityUpdate3 [counterY-1][counterX] = connectivityNumber;
                                                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                        }
                                                        if (counterX+1 < dimensionTemp &&  connectivityUpdate3 [counterY][counterX+1] == 0){
                                                            connectivityUpdate3 [counterY][counterX+1] = connectivityNumber;
                                                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                        }
                                                        if (counterY+1 < dimensionTemp &&  connectivityUpdate3 [counterY+1][counterX] == 0){
                                                            connectivityUpdate3 [counterY+1][counterX] = connectivityNumber;
                                                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                        }
                                                        if (counterX-1 >= 0 &&  connectivityUpdate3 [counterY][counterX-1] == 0){
                                                            connectivityUpdate3 [counterY][counterX-1] = connectivityNumber;
                                                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                        }
                                                        
                                                        if (connectAnalysisCount != 0){
                                                            do{
                                                                
                                                                terminationFlag = 1;
                                                                connectAnalysisTempCount = 0;
                                                                
                                                                for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                                    xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                                    
                                                                    if (ySource-1 >= 0 &&  connectivityUpdate3 [ySource-1][xSource] == 0){
                                                                        connectivityUpdate3 [ySource-1][xSource] = connectivityNumber;
                                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                    }
                                                                    if (xSource+1 < dimensionTemp &&  connectivityUpdate3 [ySource][xSource+1] == 0){
                                                                        connectivityUpdate3 [ySource][xSource+1] = connectivityNumber;
                                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                    }
                                                                    if (ySource+1 < dimensionTemp &&  connectivityUpdate3 [ySource+1][xSource] == 0){
                                                                        connectivityUpdate3 [ySource+1][xSource] = connectivityNumber;
                                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                    }
                                                                    if (xSource-1 >= 0 &&  connectivityUpdate3 [ySource][xSource-1] == 0){
                                                                        connectivityUpdate3 [ySource][xSource-1] = connectivityNumber;
                                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                    }
                                                                }
                                                                
                                                                for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                                    connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                                }
                                                                
                                                                connectAnalysisCount = connectAnalysisTempCount;
                                                                
                                                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                                                
                                                            } while (terminationFlag == 1);
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                                for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                                    if (connectivityUpdate3 [counterY][counterX] == -1) connectivityUpdate3 [counterY][counterX] = 0;
                                                }
                                            }
                                            
                                            gravityTempX = 0;
                                            gravityTempY = 0;
                                            
                                            for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                                for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                                    if (connectivityUpdate3 [counterY][counterX] == 1){
                                                        gravityTempX = gravityTempX+counterX;
                                                        gravityTempY = gravityTempY+counterY;
                                                        currentPixCount2++;
                                                    }
                                                }
                                            }
                                            
                                            gravityX2 = (int)(gravityTempX/(double)currentPixCount2)+horizontalStart2;
                                            gravityY2 = (int)(gravityTempY/(double)currentPixCount2)+verticalStart2;
                                            
                                        }
                                        else if (counter2 == 1){
                                            for (int counter3 = 0; counter3 < constructedLineCount/2; counter3++){
                                                connectivityUpdate4 [arrayNewLines [counter3*2+1]-1][arrayNewLines [counter3*2]-1] = 1;
                                                
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayNewLines [counter3*2]-1+horizontalStart2, cellTrackingCurrentTempCount++;
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayNewLines [counter3*2+1]-1+verticalStart2, cellTrackingCurrentTempCount++;
                                                
                                                if (arrayNewLines [counter3*2+1]-1+verticalStart2 >= 0 && arrayNewLines [counter3*2+1]-1+verticalStart2 < imageDimension && arrayNewLines [counter3*2]-1+horizontalStart2 >= 0 && arrayNewLines [counter3*2]-1+horizontalStart2 < imageDimension){
                                                    arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = sourceImage [mapPositionPointerCurrent][(arrayNewLines [counter3*2+1]-1+verticalStart2)*imageDimension+arrayNewLines [counter3*2]-1+horizontalStart2], cellTrackingCurrentTempCount++;
                                                }
                                                else arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 100, cellTrackingCurrentTempCount++;
                                                
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = previousConnectNumber1, cellTrackingCurrentTempCount++;
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 0, cellTrackingCurrentTempCount++;
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 0, cellTrackingCurrentTempCount++;
                                            }
                                            
                                            connectivityNumber = -3;
                                            
                                            for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                                for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                                    if (connectivityUpdate4 [counterY][counterX] == 0){
                                                        connectivityNumber = connectivityNumber+2;
                                                        connectAnalysisCount = 0;
                                                        
                                                        if (connectivityNumber >= 1) connectivityNumber = 1, connectivityUpdate4 [counterY][counterX] = connectivityNumber;
                                                        
                                                        if (counterY-1 >= 0 &&   connectivityUpdate4 [counterY-1][counterX] == 0){
                                                            connectivityUpdate4 [counterY-1][counterX] = connectivityNumber;
                                                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                        }
                                                        if (counterX+1 < dimensionTemp &&   connectivityUpdate4 [counterY][counterX+1] == 0){
                                                            connectivityUpdate4 [counterY][counterX+1] = connectivityNumber;
                                                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                        }
                                                        if (counterY+1 < dimensionTemp &&   connectivityUpdate4 [counterY+1][counterX] == 0){
                                                            connectivityUpdate4 [counterY+1][counterX] = connectivityNumber;
                                                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                        }
                                                        if (counterX-1 >= 0 &&   connectivityUpdate4 [counterY][counterX-1] == 0){
                                                            connectivityUpdate4 [counterY][counterX-1] = connectivityNumber;
                                                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                        }
                                                        
                                                        if (connectAnalysisCount != 0){
                                                            do{
                                                                
                                                                terminationFlag = 1;
                                                                connectAnalysisTempCount = 0;
                                                                
                                                                for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                                    xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                                    
                                                                    if (ySource-1 >= 0 && connectivityUpdate4 [ySource-1][xSource] == 0){
                                                                        connectivityUpdate4 [ySource-1][xSource] = connectivityNumber;
                                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                    }
                                                                    if (xSource+1 < dimensionTemp && connectivityUpdate4 [ySource][xSource+1] == 0){
                                                                        connectivityUpdate4 [ySource][xSource+1] = connectivityNumber;
                                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                    }
                                                                    if (ySource+1 < dimensionTemp && connectivityUpdate4 [ySource+1][xSource] == 0){
                                                                        connectivityUpdate4 [ySource+1][xSource] = connectivityNumber;
                                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                    }
                                                                    if (xSource-1 >= 0 && connectivityUpdate4 [ySource][xSource-1] == 0){
                                                                        connectivityUpdate4 [ySource][xSource-1] = connectivityNumber;
                                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                    }
                                                                }
                                                                
                                                                for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                                    connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                                }
                                                                
                                                                connectAnalysisCount = connectAnalysisTempCount;
                                                                
                                                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                                                
                                                            } while (terminationFlag == 1);
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                                for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                                    if (connectivityUpdate4 [counterY][counterX] == -1) connectivityUpdate4 [counterY][counterX] = 0;
                                                }
                                            }
                                            
                                            gravityTempX = 0;
                                            gravityTempY = 0;
                                            
                                            for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                                for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                                    if (connectivityUpdate4 [counterY][counterX] == 1){
                                                        gravityTempX = gravityTempX+counterX;
                                                        gravityTempY = gravityTempY+counterY;
                                                        currentPixCount1++;
                                                    }
                                                }
                                            }
                                            
                                            gravityX1 = (int)(gravityTempX/(double)currentPixCount1)+horizontalStart2;
                                            gravityY1 = (int)(gravityTempY/(double)currentPixCount1)+verticalStart2;
                                        }
                                        
                                        delete [] arrayNewLines;
                                    }
                                }
                                
                                delete [] connectAnalysisX;
                                delete [] connectAnalysisY;
                                delete [] connectAnalysisTempX;
                                delete [] connectAnalysisTempY;
                                
                                if (currentPixCount1 > 40 && currentPixCount2 > 40){
                                    //------Map Update, Average re-determination------
                                    
                                    for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                        for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                            if (arrayCellTrackingPreviousMap [counterY][counterX] == previousConnectNumber1) arrayCellTrackingPreviousMap [counterY][counterX] = 0;
                                        }
                                    }
                                    
                                    for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                        for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                            if (counterY+verticalStart2-verticalStart >= 0 && counterY+verticalStart2-verticalStart < trackAreaSize && counterX+horizontalStart2-horizontalStart >= 0 && counterX+horizontalStart2-horizontalStart < trackAreaSize){
                                                if (connectivityUpdate3 [counterY][counterX] == 1) arrayCellTrackingPreviousMap [counterY+verticalStart2-verticalStart][counterX+horizontalStart2-horizontalStart] = lineNumberPrevious2+additionCount;
                                                if (connectivityUpdate4 [counterY][counterX] == 1) arrayCellTrackingPreviousMap [counterY+verticalStart2-verticalStart][counterX+horizontalStart2-horizontalStart] = previousConnectNumber1;
                                            }
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                                    //	for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingPreviousMap [counterA][counterB];
                                    //	cout<<" carrayCellTrackingPreviousMape "<<counterA<<endl;
                                    //}
                                    
                                    //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                                    //	for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<connectivityUpdate [counterA][counterB];
                                    //	cout<<" connectivityUpdate "<<counterA<<endl;
                                    //}
                                    
                                    if (cellTrackingPreviousStatus == 0){
                                        errorNoHold = 67;
                                        arrayCellTrackingPrevious = new int [cellTrackingCurrentTempCount*3+50];
                                        cellTrackingPreviousCount = 0;
                                        cellTrackingPreviousStatus = 1;
                                        cellTrackingPreviousSizeHold = cellTrackingCurrentTempCount*3+50;
                                    }
                                    else if (cellTrackingPreviousStatus == 1 && cellTrackingPreviousSizeHold < cellTrackingCurrentTempCount){
                                        delete [] arrayCellTrackingPrevious;
                                        
                                        errorNoHold = 68;
                                        arrayCellTrackingPrevious = new int [cellTrackingCurrentTempCount*3+50];
                                        cellTrackingPreviousCount = 0;
                                        cellTrackingPreviousSizeHold = cellTrackingCurrentTempCount*3+50;
                                    }
                                    else cellTrackingPreviousCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < cellTrackingCurrentTempCount; counter2++) arrayCellTrackingPrevious [cellTrackingPreviousCount] = arrayCellTrackingCurrentTemp [counter2], cellTrackingPreviousCount++;
                                    
                                    delete [] arrayCellTrackingCurrentTemp;
                                    errorNoHold = 69;
                                    arrayCellTrackingCurrentTemp = new int [cellTrackingPreviousCount+50];
                                    cellTrackingCurrentTempCount = 0;
                                    
                                    for (int counter2 = 1; counter2 < lineNumberPrevious2+additionCount+1; counter2++){
                                        for (int counter3 = 0; counter3 < cellTrackingPreviousCount/6; counter3++){
                                            if (arrayCellTrackingPrevious [counter3*6+3] == counter2){
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingPrevious [counter3*6], cellTrackingCurrentTempCount++;
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingPrevious [counter3*6+1], cellTrackingCurrentTempCount++;
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingPrevious [counter3*6+2], cellTrackingCurrentTempCount++;
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingPrevious [counter3*6+3], cellTrackingCurrentTempCount++;
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingPrevious [counter3*6+4], cellTrackingCurrentTempCount++;
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingPrevious [counter3*6+5], cellTrackingCurrentTempCount++;
                                            }
                                        }
                                    }
                                    
                                    cellTrackingPreviousCount = 0;
                                    for (int counter2 = 0; counter2 < cellTrackingCurrentTempCount; counter2++) arrayCellTrackingPrevious [cellTrackingPreviousCount] = arrayCellTrackingCurrentTemp [counter2], cellTrackingPreviousCount++;
                                    
                                    //------Map Update, Table, Total, Average------
                                    previousPointLine1 = 0;
                                    previousTotaLine1 = 0;
                                    previousPointLine2 = 0;
                                    previousTotaLine2 = 0;
                                    
                                    for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                        for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                            if (connectivityUpdate3 [counterY][counterX] != 0){
                                                if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                                                    
                                                    previousPointLine2++;
                                                    
                                                    if (connectivityUpdate3 [counterY][counterX] != 100){ //------Line One data------
                                                        previousTotaLine2 = previousTotaLine2+sourceImage [mapPositionPointer][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2];
                                                    }
                                                }
                                                
                                                if (connectivityUpdate4 [counterY][counterX] != 0){
                                                    if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                                                        previousPointLine1++;
                                                        
                                                        if (connectivityUpdate [counterY][counterX] != 100){ //------Line Two Data------
                                                            previousTotaLine1 = previousTotaLine1+sourceImage [mapPositionPointer][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2];
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    previousAverageLine1 = previousTotaLine1/(double)previousPointLine1;
                                    previousAverageLine2 = previousTotaLine2/(double)previousPointLine2;
                                    
                                    //cout<<previousAverageLine1<<" "<<previousTotaLine1<<" "<<previousPointLine1<<" "<<previousAverageLine2<<" "<<previousTotaLine2<<" "<<previousPointLine2<<" AV_totalF"<<endl;
                                    
                                    for (int counter2 = 1; counter2 < lineNumberPrevious2+1; counter2++){
                                        if (counter2 != previousConnectNumber1){
                                            arrayPreviousTableTemp [previousTableCountTemp] = arrayPreviousTableTrack [counter2*2], previousTableCountTemp++;
                                            arrayPreviousTableTemp [previousTableCountTemp] = arrayPreviousTableTrack [counter2*2+1], previousTableCountTemp++;
                                            arrayPreviousTotalTemp [previousTotalCountTemp] = (int)arrayPreviousTableTrackTotal [counter2], previousTotalCountTemp++;
                                            arrayPreviousAverageTemp [previousAverageCountTemp] = arrayPreviousAverageTrack [counter2], previousAverageCountTemp++;
                                            
                                            //cout<<" Pix "<<arrayPreviousTableTrack [counter2*2]<<" ConnNo "<<arrayPreviousTableTrack [counter2][1]<<" Total "<<previousTotal [counter2]<<" Average "<<
                                            //arrayPreviousAverageTrack [counter2]<<" PrevTable_curr"<<endl;
                                        }
                                        else{
                                            
                                            arrayPreviousTableTemp [previousTableCountTemp] = previousPointLine1, previousTableCountTemp++;
                                            arrayPreviousTableTemp [previousTableCountTemp] = arrayPreviousTableTrack [counter2*2+1], previousTableCountTemp++;
                                            arrayPreviousTotalTemp [previousTotalCountTemp] = previousTotaLine1, previousTotalCountTemp++;
                                            arrayPreviousAverageTemp [previousAverageCountTemp] = previousAverageLine1, previousAverageCountTemp++;
                                            
                                            //cout<<" Pix "<<previousPointLine1<<" ConnNo "<<arrayPreviousTableTrack [counter2][1]<<" Total "<<previousTotaLine1<<" Average "<<previousAverageLine1<<
                                            //" PrevTable_curr2"<<endl;
                                        }
                                    }
                                    
                                    arrayPreviousTableTemp [previousTableCountTemp] = previousPointLine2, previousTableCountTemp++;
                                    arrayPreviousTableTemp [previousTableCountTemp] = lineNumberPrevious2+additionCount, previousTableCountTemp++;
                                    arrayPreviousTotalTemp [previousTotalCountTemp] = previousTotaLine2, previousTotalCountTemp++;
                                    arrayPreviousAverageTemp [previousAverageCountTemp] = previousAverageLine2, previousAverageCountTemp++;
                                    
                                    //cout<<" ALR_ 1_2_Div "<<" PrevNo "<<previousConnectNumber1<<" PrevAdd "<<lineNumberPrevious2+additionCount<<endl;
                                    //cout<<" AddCount "<<additionCount<<" PrevPairAdd "<<previousPairAddition<<endl;
                                    
                                    for (int counter2 = 1; counter2 < lineNumberPrevious2+2; counter2++){
                                        if (previousConnectNumber1 == counter2) overlapSource [counter2][overlapNumber] = 0;
                                        if (lineNumberPrevious2+additionCount == counter2) overlapSource [counter2][overlapNumber] = 1;
                                    }
                                    
                                    //cout<<" Pix "<<previousPointLine2<<" ConnNo "<<arrayPreviousTableTrack [previousConnectNumber1*2+1]<<" Total "<<previousTotaLine2<<" Average "<<previousAverageLine2<<" PrevTable_curr3"<<endl;
                                    
                                    //------Associate Data Update------
                                    if (cellTrackingPreviousAssStatus == 0){
                                        errorNoHold = 70;
                                        arrayCellTrackingPreviousAss = new int [lineNumberPrevious2*18+100];
                                        cellTrackingPreviousAssCount = 0;
                                        cellTrackingPreviousAssStatus = 1;
                                        cellTrackingPreviousAssSizeHold = lineNumberPrevious2*18+100;
                                    }
                                    else if (cellTrackingPreviousAssStatus == 1 && cellTrackingPreviousAssSizeHold < lineNumberPrevious2*6){
                                        delete [] arrayCellTrackingPreviousAss;
                                        
                                        errorNoHold = 71;
                                        arrayCellTrackingPreviousAss = new int [lineNumberPrevious2*18+100];
                                        cellTrackingPreviousAssCount = 0;
                                        cellTrackingPreviousAssSizeHold = lineNumberPrevious2*18+100;
                                    }
                                    else cellTrackingPreviousAssCount = 0;
                                    
                                    for (int counter2 = 1; counter2 < lineNumberPrevious2+1; counter2++){
                                        arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = previousAssData [counter2][0], cellTrackingPreviousAssCount++;
                                        arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = previousAssData [counter2][1], cellTrackingPreviousAssCount++;
                                        arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = previousAssData [counter2][2], cellTrackingPreviousAssCount++;
                                        arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = previousAssData [counter2][3], cellTrackingPreviousAssCount++;
                                        arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = previousAssData [counter2][4], cellTrackingPreviousAssCount++;
                                        arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = previousAssData [counter2][5], cellTrackingPreviousAssCount++;
                                        
                                        //cout<<" Number "<<previousAssData [counter2][0]<<" Process "<<previousAssData [counter2][1]<<" Cut "<<previousAssData [counter2][2]<<" Pair "<<
                                        //previousAssData [counter2][3]<<" Dim "<<previousAssData [counter2][4]<<" Reserve "<<previousAssData [counter2][5]<<" Round "<<previousAssData [counter2][6]<<" ASSPREV_Curr"<<endl;
                                    }
                                    
                                    arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = lineNumberPrevious2+additionCount, cellTrackingPreviousAssCount++;
                                    arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = previousAssData [previousConnectNumber1][1], cellTrackingPreviousAssCount++;
                                    arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = previousAssData [previousConnectNumber1][2], cellTrackingPreviousAssCount++;
                                    arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = previousPairAddition, cellTrackingPreviousAssCount++;
                                    arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = previousAssData [previousConnectNumber1][4]/2, cellTrackingPreviousAssCount++;
                                    arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = 0, cellTrackingPreviousAssCount++;
                                    
                                    //cout<<" Number "<<lineNumberPrevious2+additionCount<<" Process "<<previousAssData [previousConnectNumber1][1]<<" Cut "<<previousAssData [previousConnectNumber1][2]<<
                                    //" Pair "<<previousPairAddition<<" Dim "<<previousAssData [previousConnectNumber1][4]/2<<" Reserve "<<0<<" Round "<<previousAssData [previousConnectNumber1][6]<<" ASSPREV_Curr2"<<endl;
                                    
                                    delete [] arrayCellTrackingCurrentTemp;
                                    errorNoHold = 72;
                                    arrayCellTrackingCurrentTemp = new int [xyPositionCenterPreviousCount+50];
                                    cellTrackingCurrentTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < xyPositionCenterPreviousCount/6; counter2++){
                                        if (arrayXYPositionCenterPrevious [counter2*6+4] != previousConnectNumber1){
                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterPrevious [counter2*6], cellTrackingCurrentTempCount++;
                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterPrevious [counter2*6+1], cellTrackingCurrentTempCount++;
                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterPrevious [counter2*6+2], cellTrackingCurrentTempCount++;
                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterPrevious [counter2*6+3], cellTrackingCurrentTempCount++;
                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterPrevious [counter2*6+4], cellTrackingCurrentTempCount++;
                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterPrevious [counter2*6+5], cellTrackingCurrentTempCount++;
                                        }
                                    }
                                    
                                    if (xyPositionCenterPreviousStatus == 0){
                                        errorNoHold = 73;
                                        arrayXYPositionCenterPrevious = new int [cellTrackingCurrentTempCount*3+100];
                                        xyPositionCenterPreviousCount = 0;
                                        xyPositionCenterPreviousStatus = 1;
                                        xyPositionCenterPreviousSizeHold = cellTrackingCurrentTempCount*3+100;
                                    }
                                    else if (xyPositionCenterPreviousStatus == 1 && xyPositionCenterPreviousSizeHold < cellTrackingCurrentTempCount){
                                        delete [] arrayXYPositionCenterPrevious;
                                        
                                        errorNoHold = 74;
                                        arrayXYPositionCenterPrevious = new int [cellTrackingCurrentTempCount*3+100];
                                        xyPositionCenterPreviousCount = 0;
                                        xyPositionCenterPreviousSizeHold = cellTrackingCurrentTempCount*3+100;
                                    }
                                    else xyPositionCenterPreviousCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < cellTrackingCurrentTempCount; counter2++) arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = arrayCellTrackingCurrentTemp [counter2], xyPositionCenterPreviousCount++;
                                    
                                    arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = gravityX1, xyPositionCenterPreviousCount++;
                                    arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = gravityY1, xyPositionCenterPreviousCount++;
                                    arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = previousPointLine1, xyPositionCenterPreviousCount++;
                                    arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = (int)previousAverageLine1, xyPositionCenterPreviousCount++;
                                    arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = previousConnectNumber1, xyPositionCenterPreviousCount++;
                                    arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = 0, xyPositionCenterPreviousCount++;
                                    
                                    arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = gravityX2, xyPositionCenterPreviousCount++;
                                    arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = gravityY2, xyPositionCenterPreviousCount++;
                                    arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = previousPointLine2, xyPositionCenterPreviousCount++;
                                    arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = (int)previousAverageLine2, xyPositionCenterPreviousCount++;
                                    arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = lineNumberPrevious2+additionCount, xyPositionCenterPreviousCount++;
                                    arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = 0, xyPositionCenterPreviousCount++;
                                    
                                    delete [] arrayCellTrackingCurrentTemp;
                                    errorNoHold = 75;
                                    arrayCellTrackingCurrentTemp = new int [xyPositionCenterPreviousCount+50];
                                    cellTrackingCurrentTempCount = 0;
                                    
                                    for (int counter2 = 1; counter2 < lineNumberPrevious2+additionCount+1; counter2++){
                                        for (int counter3 = 0; counter3 < xyPositionCenterPreviousCount/6; counter3++){
                                            if (arrayXYPositionCenterPrevious [counter3*6+4] == counter2){
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterPrevious [counter3*6], cellTrackingCurrentTempCount++;
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterPrevious [counter3*6+1], cellTrackingCurrentTempCount++;
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterPrevious [counter3*6+2], cellTrackingCurrentTempCount++;
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterPrevious [counter3*6+3], cellTrackingCurrentTempCount++;
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterPrevious [counter3*6+4], cellTrackingCurrentTempCount++;
                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterPrevious [counter3*6+5], cellTrackingCurrentTempCount++;
                                            }
                                        }
                                    }
                                    
                                    xyPositionCenterPreviousCount = 0;
                                    for (int counter2 = 0; counter2 < cellTrackingCurrentTempCount; counter2++) arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = arrayCellTrackingCurrentTemp [counter2], xyPositionCenterPreviousCount++;
                                    
                                    delete [] arrayCellTrackingCurrentTemp;
                                    
                                    //------Group Table update------
                                    typeSubArray = 1;
                                    tableInterpretation = [[TableInterpretation alloc] init];
                                    [tableInterpretation interpretationFirst:typeSubArray];
                                    
                                    do{
                                    } while (subCompletionFlag3 == 1);
                                    
                                    if (errorNoHold != 0){
                                        errorNoHold = errorNoHold+2000;
                                        throw errorCheckThrow;
                                    }
                                    
                                    groupInvert = 0;
                                    
                                    for (int counter2 = 0; counter2 < groupInfoPreviousCount/5; counter2++){
                                        if (targetPointer == counter2+1 && arrayGroupInfoPrevious [counter2*5] < 0) groupInvert = arrayGroupInfoPrevious [counter2*5]*-1;
                                        
                                        if (arrayGroupInfoPrevious [counter2*5] == 0){
                                            arrayGroupInfoPrevious [counter2*5+3] = 0;
                                            arrayGroupInfoPrevious [counter2*5+4] = 0;
                                        }
                                        else if (lineNumberPrevious2+additionCount != counter2+1){
                                            arrayGroupInfoPrevious [counter2*5+3] = groupTablePreviousious [counter2*5+3];
                                            arrayGroupInfoPrevious [counter2*5+4] = groupTablePreviousious [counter2*5+4];
                                        }
                                        else{
                                            
                                            arrayGroupInfoPrevious [counter2*5+3] = groupTablePreviousious [(previousConnectNumber1-1)*5+3];
                                            arrayGroupInfoPrevious [counter2*5+4] = groupTablePreviousious [(previousConnectNumber1-1)*5+4];
                                        }
                                    }
                                    
                                    if (groupInvert != 0){
                                        for (int counter2 = 0; counter2 < groupInfoPreviousCount/5; counter2++){
                                            if (targetPointer == counter2+1 && arrayGroupInfoPrevious [counter2*5] < 0) arrayGroupInfoPrevious [counter2*5] = groupInvert;
                                            else if (arrayGroupInfoPrevious [counter2*5] == groupInvert) arrayGroupInfoPrevious [counter2*5] = groupInvert*-1;
                                        }
                                    }
                                    
                                    //------XY center Target Info Update------
                                    errorNoHold = 76;
                                    arrayCellTrackingCurrentTemp = new int [xyPositionCenterPreviousCount+50];
                                    cellTrackingCurrentTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < xyPositionCenterPreviousCount/6; counter2++){
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterPrevious [counter2*6], cellTrackingCurrentTempCount++;
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterPrevious [counter2*6+1], cellTrackingCurrentTempCount++;
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterPrevious [counter2*6+2], cellTrackingCurrentTempCount++;
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterPrevious [counter2*6+3], cellTrackingCurrentTempCount++;
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterPrevious [counter2*6+4], cellTrackingCurrentTempCount++;
                                        
                                        if (arrayXYPositionCenterPrevious [counter2*6+4] == targetPointer) arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 1, cellTrackingCurrentTempCount++;
                                        else arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 0, cellTrackingCurrentTempCount++;
                                    }
                                    
                                    xyPositionCenterPreviousCount = 0;
                                    for (int counter2 = 0; counter2 < cellTrackingCurrentTempCount; counter2++) arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = arrayCellTrackingCurrentTemp [counter2], xyPositionCenterPreviousCount++;
                                    
                                    delete [] arrayCellTrackingCurrentTemp;
                                    
                                    //cout<<targetPointer<<"  TARG4================================="<<endl;
                                }
                                else{
                                    
                                    additionCount--;
                                    previousPairAddition--;
                                    allocationResult = 3;
                                    
                                    delete [] arrayCellTrackingCurrentTemp;
                                }
                                
                                for (int counter2 = 0; counter2 < dimensionTemp+5; counter2++){
                                    delete [] connectivityUpdate [counter2];
                                    delete [] connectivityUpdate2 [counter2];
                                    delete [] connectivityUpdate3 [counter2];
                                    delete [] connectivityUpdate4 [counter2];
                                    delete [] connectivityUpdate5 [counter2];
                                }
                                
                                delete [] connectivityUpdate;
                                delete [] connectivityUpdate2;
                                delete [] connectivityUpdate3;
                                delete [] connectivityUpdate4;
                                delete [] connectivityUpdate5;
                            }
                            
                            if (allocationResult == 5){ //------Fusion------
                                
                                //cout<<"ALR_5_Fus "<<" OverlapNo "<<overlapNumber<<" currentMajor "<<currentMajor<<endl;
                                
                                maxPointDimX = 0;
                                maxPointDimY = 0;
                                minPointDimX = 1000000;
                                minPointDimY = 1000000;
                                
                                for (int counter2 = 0; counter2 < cellTrackingCurrentCount/6; counter2++){
                                    if (arrayCellTrackingCurrent [counter2*6+3] == overlapNumber || arrayCellTrackingCurrent [counter2*6+3] == currentMajor){
                                        if (maxPointDimX < arrayCellTrackingCurrent [counter2*6]) maxPointDimX = arrayCellTrackingCurrent [counter2*6];
                                        if (minPointDimX > arrayCellTrackingCurrent [counter2*6]) minPointDimX = arrayCellTrackingCurrent [counter2*6];
                                        if (maxPointDimY < arrayCellTrackingCurrent [counter2*6+1]) maxPointDimY = arrayCellTrackingCurrent [counter2*6+1];
                                        if (minPointDimY > arrayCellTrackingCurrent [counter2*6+1]) minPointDimY = arrayCellTrackingCurrent [counter2*6+1];
                                    }
                                }
                                
                                dimensionTemp = 0;
                                horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                                verticalLength = (maxPointDimY-minPointDimY)/2*2;
                                
                                if (horizontalLength >= verticalLength) dimensionTemp = horizontalLength+30;
                                if (horizontalLength < verticalLength) dimensionTemp = verticalLength+30;
                                
                                if (dimensionTemp < 128) dimensionTemp = 128;
                                else dimensionTemp = (dimensionTemp/2)*2;
                                
                                horizontalStart2 = minPointDimX-(dimensionTemp-horizontalLength)/2;
                                verticalStart2 = minPointDimY-(dimensionTemp-verticalLength)/2;
                                
                                errorNoHold = 77;
                                int **connectivityUpdate = new int *[dimensionTemp+5];
                                errorNoHold = 78;
                                int **connectivityUpdate2 = new int *[dimensionTemp+5];
                                errorNoHold = 79;
                                int **connectivityUpdate3 = new int *[dimensionTemp+5];
                                errorNoHold = 80;
                                int **connectivityUpdate5 = new int *[dimensionTemp+5];
                                errorNoHold = 81;
                                int **connectivityUpdateInside = new int *[dimensionTemp+5];
                                
                                for (int counter2 = 0; counter2 < dimensionTemp+5; counter2++){
                                    errorNoHold = 82;
                                    connectivityUpdate [counter2] = new int [dimensionTemp+5];
                                    errorNoHold = 83;
                                    connectivityUpdate2 [counter2] = new int [dimensionTemp+5];
                                    errorNoHold = 84;
                                    connectivityUpdate3 [counter2] = new int [dimensionTemp+5];
                                    errorNoHold = 85;
                                    connectivityUpdate5 [counter2] = new int [dimensionTemp+5];
                                    errorNoHold = 86;
                                    connectivityUpdateInside [counter2] = new int [dimensionTemp+5];
                                }
                                
                                for (int counterY = 0; counterY < dimensionTemp+5; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp+5; counterX++){
                                        connectivityUpdate [counterY][counterX] = 0;
                                        connectivityUpdate2 [counterY][counterX] = 0;
                                        connectivityUpdate3 [counterY][counterX] = 0;
                                        connectivityUpdate5 [counterY][counterX] = 0;
                                        connectivityUpdateInside [counterY][counterX] = 0;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < cellTrackingCurrentCount/6; counter2++){
                                    if (arrayCellTrackingCurrent [counter2*6+3] == overlapNumber){
                                        connectivityUpdate [arrayCellTrackingCurrent [counter2*6+1]-verticalStart2+1][arrayCellTrackingCurrent [counter2*6]-horizontalStart2+1] = 1;
                                    }
                                    
                                    if (arrayCellTrackingCurrent [counter2*6+3] == currentMajor){
                                        connectivityUpdate2 [arrayCellTrackingCurrent [counter2*6+1]-verticalStart2+1][arrayCellTrackingCurrent [counter2*6]-horizontalStart2+1] = 1;
                                    }
                                }
                                
                                errorNoHold = 87;
                                int *connectAnalysisX = new int [(dimensionTemp+2)*4];
                                errorNoHold = 88;
                                int *connectAnalysisY = new int [(dimensionTemp+2)*4];
                                errorNoHold = 89;
                                int *connectAnalysisTempX = new int [(dimensionTemp+2)*4];
                                errorNoHold = 90;
                                int *connectAnalysisTempY = new int [(dimensionTemp+2)*4];
                                
                                connectivityNumber = 0;
                                
                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                        if (connectivityUpdate [counterY][counterX] == 0){
                                            connectivityNumber--;
                                            connectivityUpdate [counterY][counterX] = connectivityNumber;
                                            
                                            connectAnalysisCount = 0;
                                            
                                            if (counterY-1 >= 0 && connectivityUpdate [counterY-1][counterX] == 0){
                                                connectivityUpdate [counterY-1][counterX] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                            }
                                            if (counterX+1 < dimensionTemp+2 && connectivityUpdate [counterY][counterX+1] == 0){
                                                connectivityUpdate [counterY][counterX+1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                            }
                                            if (counterY+1 < dimensionTemp+2 && connectivityUpdate [counterY+1][counterX] == 0){
                                                connectivityUpdate [counterY+1][counterX] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                            }
                                            if (counterX-1 >= 0 && connectivityUpdate [counterY][counterX-1] == 0){
                                                connectivityUpdate [counterY][counterX-1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                            }
                                            
                                            if (connectAnalysisCount != 0){
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    connectAnalysisTempCount = 0;
                                                    
                                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                        
                                                        if (ySource-1 >= 0 && connectivityUpdate [ySource-1][xSource] == 0){
                                                            connectivityUpdate [ySource-1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource+1 < dimensionTemp+2 && connectivityUpdate [ySource][xSource+1] == 0){
                                                            connectivityUpdate [ySource][xSource+1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                        if (ySource+1 < dimensionTemp+2 && connectivityUpdate [ySource+1][xSource] == 0){
                                                            connectivityUpdate [ySource+1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource-1 >= 0 && connectivityUpdate [ySource][xSource-1] == 0){
                                                            connectivityUpdate [ySource][xSource-1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                    }
                                                    
                                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                                    }
                                                    
                                                    connectAnalysisCount = connectAnalysisTempCount;
                                                    
                                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                                    
                                                } while (terminationFlag == 1);
                                            }
                                        }
                                    }
                                }
                                
                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                        if (connectivityUpdate [counterY][counterX] == -1) connectivityUpdate [counterY][counterX] = 0;
                                        else connectivityUpdate [counterY][counterX] = 1;
                                    }
                                }
                                
                                connectivityNumber = 0;
                                
                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                        if (connectivityUpdate2 [counterY][counterX] == 0){
                                            connectivityNumber--;
                                            connectivityUpdate2 [counterY][counterX] = connectivityNumber;
                                            
                                            connectAnalysisCount = 0;
                                            
                                            if (counterY-1 >= 0 && connectivityUpdate2 [counterY-1][counterX] == 0){
                                                connectivityUpdate2 [counterY-1][counterX] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                            }
                                            if (counterX+1 < dimensionTemp+2 && connectivityUpdate2 [counterY][counterX+1] == 0){
                                                connectivityUpdate2 [counterY][counterX+1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                            }
                                            if (counterY+1 < dimensionTemp+2 && connectivityUpdate2 [counterY+1][counterX] == 0){
                                                connectivityUpdate2 [counterY+1][counterX] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                            }
                                            if (counterX-1 >= 0 && connectivityUpdate2 [counterY][counterX-1] == 0){
                                                connectivityUpdate2 [counterY][counterX-1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                            }
                                            
                                            if (connectAnalysisCount != 0){
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    connectAnalysisTempCount = 0;
                                                    
                                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                        
                                                        if (ySource-1 >= 0 && connectivityUpdate2 [ySource-1][xSource] == 0){
                                                            connectivityUpdate2 [ySource-1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource+1 < dimensionTemp+2 && connectivityUpdate2 [ySource][xSource+1] == 0){
                                                            connectivityUpdate2 [ySource][xSource+1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                        if (ySource+1 < dimensionTemp+2 && connectivityUpdate2 [ySource+1][xSource] == 0){
                                                            connectivityUpdate2 [ySource+1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource-1 >= 0 && connectivityUpdate2 [ySource][xSource-1] == 0){
                                                            connectivityUpdate2 [ySource][xSource-1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                    }
                                                    
                                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                                    }
                                                    
                                                    connectAnalysisCount = connectAnalysisTempCount;
                                                    
                                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                                    
                                                } while (terminationFlag == 1);
                                            }
                                        }
                                    }
                                }
                                
                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                        if (connectivityUpdate2 [counterY][counterX] == -1) connectivityUpdate2 [counterY][counterX] = 0;
                                        else connectivityUpdate2 [counterY][counterX] = 1;
                                    }
                                }
                                
                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                        if (connectivityUpdate [counterY][counterX] == 1) connectivityUpdate2 [counterY][counterX] = 1;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < dimensionTemp+2; counterA++){
                                //	for (int counterB = 0; counterB < dimensionTemp+2; counterB++) cout<<" "<<connectivityUpdate2 [counterA][counterB];
                                //	cout<<" connectivityUpdate2 "<<counterA<<endl;
                                //}
                                
                                //-------Zero Fill-------
                                for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                    for (int counterY = 0; counterY < dimensionTemp+2; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
                                }
                                
                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++) connectivityUpdate5 [counterY][counterX] = connectivityUpdate2 [counterY][counterX];
                                }
                                
                                connectivityNumber = 0;
                                
                                for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                    for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                        if (connectivityUpdate5 [counterY2][counterX2] == 0){
                                            connectivityNumber--;
                                            connectAnalysisCount = 0;
                                            
                                            connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                                            
                                            if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                                                connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                            }
                                            if (counterX2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                                connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                            }
                                            if (counterY2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                                connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                            }
                                            if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                                connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                            }
                                            
                                            if (connectAnalysisCount != 0){
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    connectAnalysisTempCount = 0;
                                                    
                                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                        
                                                        if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                                            connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource+1 < dimensionTemp+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                                            connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                        if (ySource+1 < dimensionTemp+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                                            connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                                            connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                    }
                                                    
                                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                                    }
                                                    
                                                    connectAnalysisCount = connectAnalysisTempCount;
                                                    
                                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                                    
                                                } while (terminationFlag == 1);
                                            }
                                        }
                                    }
                                }
                                
                                if (connectivityNumber < -1){
                                    errorNoHold = 91;
                                    int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                                    
                                    for (int counter2 = 0; counter2 < connectivityNumber*-1*2+5; counter2++) connectCheckArray [counter2] = 0;
                                    
                                    for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                        for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                            connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                                            
                                            if (connectTemp2 < -1){
                                                connectTemp2 = connectTemp2*-1;
                                                
                                                if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterY2-1 >= 0 && counterX2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterX2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterY2+1 < dimensionTemp+2 && counterX2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterY2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterY2+1 < dimensionTemp+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                                if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                }
                                            }
                                        }
                                    }
                                    
                                    zeroFillFlag = 0;
                                    
                                    for (int counter2 = 2; counter2 <= connectivityNumber*-1; counter2++){
                                        if (connectCheckArray [counter2*2] != 0 && connectCheckArray [counter2*2+1] == 0) zeroFillFlag = 1;
                                    }
                                    
                                    if (zeroFillFlag == 1){
                                        for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                            for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                                                
                                                if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                                            }
                                        }
                                        
                                        for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                            for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                if (connectivityUpdate5 [counterY2][counterX2] > 0) connectivityUpdate2 [counterY2][counterX2] = connectivityUpdate5 [counterY2][counterX2];
                                            }
                                        }
                                    }
                                    
                                    delete [] connectCheckArray;
                                }
                                
                                //======Inside check=====
                                errorNoHold = 92;
                                int *insideCheck = new int [lineNumberCurrent2*2+5];
                                
                                for (int counter2 = 0; counter2 < lineNumberCurrent2*2+5; counter2++) insideCheck [counter2] = 0;
                                
                                for (int counterY = 1; counterY < dimensionTemp+1; counterY++){
                                    for (int counterX = 1; counterX < dimensionTemp+1; counterX++){
                                        
                                        if (counterY+verticalStart2-1 >= 0 && counterY+verticalStart2-1 < trackAreaSize && counterX+horizontalStart2-1 >= 0 && counterX+horizontalStart2-1 < trackAreaSize){
                                            if (connectivityUpdate2 [counterY][counterX] != 0 && arrayCellTrackingCurrentMap [counterY+verticalStart2-1][counterX+horizontalStart2-1] != 0){
                                                insideCheck [arrayCellTrackingCurrentMap [counterY+verticalStart2-1][counterX+horizontalStart2-1]*2]++;
                                            }
                                            else if (connectivityUpdate2 [counterY][counterX] == 0 && arrayCellTrackingCurrentMap [counterY+verticalStart2-1][counterX+horizontalStart2-1] != 0){
                                                insideCheck [arrayCellTrackingCurrentMap [counterY+verticalStart2-1][counterX+horizontalStart2-1]*2+1]++;
                                            }
                                        }
                                    }
                                }
                                
                                insideCheck [overlapNumber*2] = 0;
                                insideCheck [currentMajor*2] = 0;
                                
                                insideFind = 0;
                                
                                for (int counter2 = 1; counter2 <= lineNumberCurrent2; counter2++){
                                    if (insideCheck [counter2*2] != 0 && insideCheck [counter2*2+1] == 0) insideFind = 1;
                                    else if (insideCheck [counter2*2] != 0 && insideCheck [counter2*2+1] != 0) insideCheck [counter2*2] = 0;
                                }
                                
                                if (insideFind == 1){
                                    for (int counterY = 1; counterY < dimensionTemp+1; counterY++){
                                        for (int counterX = 1; counterX < dimensionTemp+1; counterX++){
                                            if (counterY+verticalStart2-1 >= 0 && counterY+verticalStart2-1 < trackAreaSize && counterX+horizontalStart2-1 >= 0 && counterX+horizontalStart2-1 < trackAreaSize){
                                                
                                                if (arrayCellTrackingCurrentMap [counterY+verticalStart2-1][counterX+horizontalStart2-1] != 0){
                                                    for (int counter2 = 1; counter2 <= lineNumberCurrent2; counter2++){
                                                        if (insideCheck [counter2*2] != 0 && arrayCellTrackingCurrentMap [counterY+verticalStart2-1][counterX+horizontalStart2-1] == counter2){
                                                            connectivityUpdateInside [counterY][counterX] = arrayCellTrackingCurrentMap [counterY+verticalStart2-1][counterX+horizontalStart2-1];
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                delete [] insideCheck;
                                
                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                        if (connectivityUpdate2 [counterY][counterX] != 0){
                                            if (counterX+1 < dimensionTemp+2 && connectivityUpdate2 [counterY][counterX+1] == 0) connectivityUpdate2 [counterY][counterX] = -1;
                                            else if (counterY+1 < dimensionTemp+2 && connectivityUpdate2 [counterY+1][counterX] == 0) connectivityUpdate2 [counterY][counterX] = -1;
                                            else if (counterX-1 >= 0 && connectivityUpdate2 [counterY][counterX-1] == 0) connectivityUpdate2 [counterY][counterX] = -1;
                                            else if (counterY-1 >= 0 && connectivityUpdate2 [counterY-1][counterX] == 0) connectivityUpdate2 [counterY][counterX] = -1;
                                        }
                                    }
                                }
                                
                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                        if (connectivityUpdate2 [counterY][counterX] > 0) connectivityUpdate2 [counterY][counterX] = 0;
                                        if (connectivityUpdate2 [counterY][counterX] < 0) connectivityUpdate2 [counterY][counterX] = 1;
                                    }
                                }
                                
                                connectivityNumber = 0;
                                
                                for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                    for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                        if (connectivityUpdate2 [counterY2][counterX2] == 0){
                                            connectivityNumber--;
                                            connectAnalysisCount = 0;
                                            
                                            connectivityUpdate2 [counterY2][counterX2] = connectivityNumber;
                                            
                                            if (counterY2-1 >= 0 && connectivityUpdate2 [counterY2-1][counterX2] == 0){
                                                connectivityUpdate2 [counterY2-1][counterX2] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                            }
                                            if (counterX2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2][counterX2+1] == 0){
                                                connectivityUpdate2 [counterY2][counterX2+1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                            }
                                            if (counterY2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2+1][counterX2] == 0){
                                                connectivityUpdate2 [counterY2+1][counterX2] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                            }
                                            if (counterX2-1 >= 0 && connectivityUpdate2 [counterY2][counterX2-1] == 0){
                                                connectivityUpdate2 [counterY2][counterX2-1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                            }
                                            
                                            if (connectAnalysisCount != 0){
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    connectAnalysisTempCount = 0;
                                                    
                                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                        
                                                        if (ySource-1 >= 0 && connectivityUpdate2 [ySource-1][xSource] == 0){
                                                            connectivityUpdate2 [ySource-1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource+1 < dimensionTemp+2 && connectivityUpdate2 [ySource][xSource+1] == 0){
                                                            connectivityUpdate2 [ySource][xSource+1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                        if (ySource+1 < dimensionTemp+2 && connectivityUpdate2 [ySource+1][xSource] == 0){
                                                            connectivityUpdate2 [ySource+1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource-1 >= 0 && connectivityUpdate2 [ySource][xSource-1] == 0){
                                                            connectivityUpdate2 [ySource][xSource-1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                    }
                                                    
                                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                                    }
                                                    
                                                    connectAnalysisCount = connectAnalysisTempCount;
                                                    
                                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                                    
                                                } while (terminationFlag == 1);
                                            }
                                        }
                                    }
                                }
                                
                                //------Determine number of pixels------
                                connectivityNumber = connectivityNumber*-1;
                                
                                errorNoHold = 93;
                                int *connectedPixels2 = new int [connectivityNumber+50];
                                
                                for (int counter2 = 0; counter2 < connectivityNumber+50; counter2++) connectedPixels2 [counter2] = 0;
                                
                                for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                    for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                        if (connectivityUpdate2 [counterY2][counterX2] < -1) connectedPixels2 [connectivityUpdate2 [counterY2][counterX2]*-1]++;
                                    }
                                }
                                
                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++) connectivityUpdate5 [counterY][counterX] = 0;
                                }
                                
                                largestConnect = 0;
                                largestConnectNo = 0;
                                
                                for (int counter2 = 2; counter2 <= connectivityNumber; counter2++){
                                    if (connectedPixels2 [counter2] > largestConnect){
                                        largestConnect = connectedPixels2 [counter2];
                                        largestConnectNo = counter2;
                                    }
                                }
                                
                                for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                    for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                        if (connectivityUpdate2 [counterY2][counterX2] == largestConnectNo*-1){
                                            if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate2 [counterY2-1][counterX2-1] == 1){
                                                connectivityUpdate5 [counterY2-1][counterX2-1] = 1;
                                                connectivityUpdate2 [counterY2-1][counterX2-1] = 0;
                                            }
                                            if (counterY2-1 >= 0 && connectivityUpdate2 [counterY2-1][counterX2] == 1){
                                                connectivityUpdate5 [counterY2-1][counterX2] = 1;
                                                connectivityUpdate2 [counterY2-1][counterX2] = 0;
                                            }
                                            if (counterY2-1 >= 0 && counterX2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2-1][counterX2+1] == 1){
                                                connectivityUpdate5 [counterY2-1][counterX2+1] = 1;
                                                connectivityUpdate2 [counterY2-1][counterX2+1] = 0;
                                            }
                                            if (counterX2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2][counterX2+1] == 1){
                                                connectivityUpdate5 [counterY2][counterX2+1] = 1;
                                                connectivityUpdate2 [counterY2][counterX2+1] = 0;
                                            }
                                            if (counterY2+1 < dimensionTemp+2 && counterX2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2+1][counterX2+1] == 1){
                                                connectivityUpdate5 [counterY2+1][counterX2+1] = 1;
                                                connectivityUpdate2 [counterY2+1][counterX2+1] = 0;
                                            }
                                            if (counterY2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2+1][counterX2] == 1){
                                                connectivityUpdate5 [counterY2+1][counterX2] = 1;
                                                connectivityUpdate2 [counterY2+1][counterX2] = 0;
                                            }
                                            if (counterY2+1 < dimensionTemp+2 && counterX2-1 >= 0 && connectivityUpdate2 [counterY2+1][counterX2-1] == 1){
                                                connectivityUpdate5 [counterY2+1][counterX2-1] = 1;
                                                connectivityUpdate2 [counterY2+1][counterX2-1] = 0;
                                            }
                                            if (counterX2-1 >= 0 && connectivityUpdate2 [counterY2][counterX2-1] == 1){
                                                connectivityUpdate5 [counterY2][counterX2-1] = 1;
                                                connectivityUpdate2 [counterY2][counterX2-1] = 0;
                                            }
                                        }
                                    }
                                }
                                
                                delete [] connectedPixels2;
                                
                                xPositionTempStart = 0;
                                yPositionTempStart = 0;
                                lineSize = 0;
                                
                                for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                    for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                        if (connectivityUpdate5 [counterY2][counterX2] == 1){
                                            connectivityUpdate2 [counterY2][counterX2] = 1;
                                            
                                            xPositionTempStart = counterX2;
                                            yPositionTempStart = counterY2;
                                            lineSize++;
                                        }
                                        else connectivityUpdate2 [counterY2][counterX2] = 0;
                                    }
                                }
                                
                                constructedLineCount = 0;
                                
                                errorNoHold = 94;
                                int *arrayNewLines = new int [lineSize*2+50];
                                
                                connectivityUpdate2 [yPositionTempStart][xPositionTempStart] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                
                                do{
                                    
                                    findFlag = 0;
                                    terminationFlag = 0;
                                    
                                    if (xPositionTempStart+1 < dimensionTemp+2){
                                        if (connectivityUpdate2 [yPositionTempStart][xPositionTempStart+1] == 1){
                                            connectivityUpdate2 [yPositionTempStart][xPositionTempStart+1] = -1;
                                            arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                            arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                            xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                        }
                                    }
                                    if (xPositionTempStart+1 < dimensionTemp+2 && yPositionTempStart+1 < dimensionTemp+2 && findFlag == 0){
                                        if (connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                                            connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                                            arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                            arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                            xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                        }
                                    }
                                    if (yPositionTempStart+1 < dimensionTemp+2 && findFlag == 0){
                                        if (connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart] == 1){
                                            connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart] = -1;
                                            arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                            arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                            yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                        }
                                    }
                                    if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimensionTemp+2 && findFlag == 0){
                                        if (connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                                            connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                                            arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                            arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                            xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                        }
                                    }
                                    if (xPositionTempStart-1 >= 0 && findFlag == 0){
                                        if (connectivityUpdate2 [yPositionTempStart][xPositionTempStart-1] == 1){
                                            connectivityUpdate2 [yPositionTempStart][xPositionTempStart-1] = -1;
                                            arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                            arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                            xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                        }
                                    }
                                    if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                                        if (connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                                            connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                                            arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                            arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                            xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                        }
                                    }
                                    if (yPositionTempStart-1 >= 0 && findFlag == 0){
                                        if (connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart] == 1){
                                            connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart] = -1;
                                            arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                            arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                            yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                        }
                                    }
                                    if (xPositionTempStart+1 < dimensionTemp+2 && yPositionTempStart-1 >= 0 && findFlag == 0){
                                        if (connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                                            connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                                            arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                            arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                            xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                                        }
                                    }
                                    
                                } while (terminationFlag == 1);
                                
                                //===========
                                //int aa = arrayNewLines [0]-1;
                                //int bb = arrayNewLines [1]-1;
                                
                                //int cc = arrayNewLines [(constructedLineCount/2-1)*2]-1;
                                //int dd = arrayNewLines [(constructedLineCount/2-1)*2+1]-1;
                                
                                //int findLink = 0;
                                
                                //if (cc-1 == aa && dd-1 == bb) findLink = 1;
                                //else  if (cc == aa && dd-1 == bb) findLink = 1;
                                //else  if (cc+1 == aa && dd-1 == bb) findLink = 1;
                                //else  if (cc+1 == aa && dd == bb) findLink = 1;
                                //else  if (cc+1 == aa && dd+1 == bb) findLink = 1;
                                //else  if (cc == aa && dd+1 == bb) findLink = 1;
                                //else  if (cc-1 == aa && dd+1 == bb) findLink = 1;
                                //else  if (cc-1 == aa && dd == bb) findLink = 1;
                                
                                //if (findLink == 0){
                                //    for (int counterA = 0; counterA < dimensionTemp+2; counterA++){
                                //        for (int counterB = 0; counterB < dimensionTemp+2; counterB++) cout<<" "<<connectivityUpdate2 [counterA][counterB];
                                //        cout<<" connectivityUpdate2 "<<counterA<<endl;
                                //    }
                                //}
                                //==========
                                
                                //for (int counterA = 0; counterA < dimensionTemp+2; counterA++){
                                //    for (int counterB = 0; counterB < dimensionTemp+2; counterB++) cout<<" "<< connectivityUpdate2 [counterA][counterB];
                                //    cout<<" connectivityUpdate2 "<<counterA<<endl;
                                //}
                                
                                //------Tracking Data Up-Date------
                                errorNoHold = 95;
                                int *arrayCellTrackingCurrentTemp = new int [cellTrackingCurrentCount+constructedLineCount*3+50];
                                cellTrackingCurrentTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < cellTrackingCurrentCount/6; counter2++){
                                    if (arrayCellTrackingCurrent [counter2*6+3] != currentMajor && arrayCellTrackingCurrent [counter2*6+3] != overlapNumber){
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter2*6], cellTrackingCurrentTempCount++;
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter2*6+1], cellTrackingCurrentTempCount++;
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter2*6+2], cellTrackingCurrentTempCount++;
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter2*6+3], cellTrackingCurrentTempCount++;
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter2*6+4], cellTrackingCurrentTempCount++;
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter2*6+5], cellTrackingCurrentTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                                    connectivityUpdate3 [arrayNewLines [counter2*2+1]-1][arrayNewLines [counter2*2]-1] = 1;
                                    
                                    arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayNewLines [counter2*2]-1+horizontalStart2, cellTrackingCurrentTempCount++;
                                    arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayNewLines [counter2*2+1]-1+verticalStart2, cellTrackingCurrentTempCount++;
                                    
                                    if (arrayNewLines [counter2*2+1]-1+verticalStart2 >= 0 && arrayNewLines [counter2*2+1]-1+verticalStart2 < imageDimension && arrayNewLines [counter2*2]-1+horizontalStart2 >= 0 && arrayNewLines [counter2*2]-1+horizontalStart2 < imageDimension){
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = sourceImage [mapPositionPointerCurrent][(arrayNewLines [counter2*2+1]-1+verticalStart2)*imageDimension+arrayNewLines [counter2*2]-1+horizontalStart2], cellTrackingCurrentTempCount++;
                                    }
                                    else arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 100, cellTrackingCurrentTempCount++;
                                    
                                    arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = currentMajor, cellTrackingCurrentTempCount++;
                                    arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 0, cellTrackingCurrentTempCount++;
                                    arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 0, cellTrackingCurrentTempCount++;
                                }
                                
                                if (cellTrackingCurrentStatus == 0){
                                    errorNoHold = 96;
                                    arrayCellTrackingCurrent = new int [cellTrackingCurrentTempCount*3+50];
                                    cellTrackingCurrentCount = 0;
                                    cellTrackingCurrentStatus = 1;
                                    cellTrackingCurrentSizeHold = cellTrackingCurrentTempCount*3+50;
                                }
                                else if (cellTrackingCurrentStatus == 1 && cellTrackingCurrentSizeHold < cellTrackingCurrentTempCount){
                                    delete [] arrayCellTrackingCurrent;
                                    
                                    errorNoHold = 97;
                                    arrayCellTrackingCurrent = new int [cellTrackingCurrentTempCount*3+50];
                                    cellTrackingCurrentCount = 0;
                                    cellTrackingCurrentSizeHold = cellTrackingCurrentTempCount*3+50;
                                }
                                else cellTrackingCurrentCount = 0;
                                
                                for (int counter2 = 0; counter2 < cellTrackingCurrentTempCount; counter2++) arrayCellTrackingCurrent [cellTrackingCurrentCount] = arrayCellTrackingCurrentTemp [counter2], cellTrackingCurrentCount++;
                                
                                delete [] arrayCellTrackingCurrentTemp;
                                errorNoHold = 98;
                                arrayCellTrackingCurrentTemp = new int [cellTrackingCurrentCount*2+50];
                                cellTrackingCurrentTempCount = 0;
                                
                                for (int counter2 = 1; counter2 < lineNumberCurrent2+1; counter2++){
                                    for (int counter3 = 0; counter3 < cellTrackingCurrentCount/6; counter3++){
                                        if (arrayCellTrackingCurrent [counter3*6+3] == counter2){
                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter3*6], cellTrackingCurrentTempCount++;
                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter3*6+1], cellTrackingCurrentTempCount++;
                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter3*6+2], cellTrackingCurrentTempCount++;
                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter3*6+3], cellTrackingCurrentTempCount++;
                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter3*6+4], cellTrackingCurrentTempCount++;
                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter3*6+5], cellTrackingCurrentTempCount++;
                                        }
                                    }
                                }
                                
                                if (cellTrackingCurrentStatus == 0){
                                    errorNoHold = 99;
                                    arrayCellTrackingCurrent = new int [cellTrackingCurrentTempCount*3+50];
                                    cellTrackingCurrentCount = 0;
                                    cellTrackingCurrentStatus = 1;
                                    cellTrackingCurrentSizeHold = cellTrackingCurrentTempCount*3+50;
                                }
                                else if (cellTrackingCurrentStatus == 1 && cellTrackingCurrentSizeHold < cellTrackingCurrentTempCount){
                                    delete [] arrayCellTrackingCurrent;
                                    
                                    errorNoHold = 100;
                                    arrayCellTrackingCurrent = new int [cellTrackingCurrentTempCount*3+50];
                                    cellTrackingCurrentCount = 0;
                                    cellTrackingCurrentSizeHold = cellTrackingCurrentTempCount*3+50;
                                }
                                else cellTrackingCurrentCount = 0;
                                
                                for (int counter2 = 0; counter2 < cellTrackingCurrentTempCount; counter2++) arrayCellTrackingCurrent [cellTrackingCurrentCount] = arrayCellTrackingCurrentTemp [counter2], cellTrackingCurrentCount++;
                                
                                connectivityNumber = -3;
                                
                                for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                        if (connectivityUpdate3 [counterY][counterX] == 0){
                                            connectivityNumber = connectivityNumber+2;
                                            connectAnalysisCount = 0;
                                            
                                            if (connectivityNumber >= 1) connectivityNumber = 1, connectivityUpdate3 [counterY][counterX] = connectivityNumber;
                                            
                                            if (counterY-1 >= 0 &&  connectivityUpdate3 [counterY-1][counterX] == 0){
                                                connectivityUpdate3 [counterY-1][counterX] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                            }
                                            if (counterX+1 < dimensionTemp &&  connectivityUpdate3 [counterY][counterX+1] == 0){
                                                connectivityUpdate3 [counterY][counterX+1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                            }
                                            if (counterY+1 < dimensionTemp &&  connectivityUpdate3 [counterY+1][counterX] == 0){
                                                connectivityUpdate3 [counterY+1][counterX] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                            }
                                            if (counterX-1 >= 0 &&  connectivityUpdate3 [counterY][counterX-1] == 0){
                                                connectivityUpdate3 [counterY][counterX-1] = connectivityNumber;
                                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                            }
                                            
                                            if (connectAnalysisCount != 0){
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    connectAnalysisTempCount = 0;
                                                    
                                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                        
                                                        if (ySource-1 >= 0 &&  connectivityUpdate3 [ySource-1][xSource] == 0){
                                                            connectivityUpdate3 [ySource-1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource+1 < dimensionTemp &&  connectivityUpdate3 [ySource][xSource+1] == 0){
                                                            connectivityUpdate3 [ySource][xSource+1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                        if (ySource+1 < dimensionTemp &&  connectivityUpdate3 [ySource+1][xSource] == 0){
                                                            connectivityUpdate3 [ySource+1][xSource] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                        }
                                                        if (xSource-1 >= 0 &&  connectivityUpdate3 [ySource][xSource-1] == 0){
                                                            connectivityUpdate3 [ySource][xSource-1] = connectivityNumber;
                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                        }
                                                    }
                                                    
                                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                                    }
                                                    
                                                    connectAnalysisCount = connectAnalysisTempCount;
                                                    
                                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                                    
                                                } while (terminationFlag == 1);
                                            }
                                        }
                                    }
                                }
                                
                                for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                        if (connectivityUpdate3 [counterY][counterX] == -1) connectivityUpdate3 [counterY][counterX] = 0;
                                    }
                                }
                                
                                prevPixelCount1 = 0;
                                gravityTempX = 0;
                                gravityTempY = 0;
                                
                                for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                        if (connectivityUpdate3 [counterY][counterX] == 1){
                                            gravityTempX = gravityTempX+counterX;
                                            gravityTempY = gravityTempY+counterY;
                                            prevPixelCount1++;
                                        }
                                    }
                                }
                                
                                gravityX1 = (int)(gravityTempX/(double)prevPixelCount1)+horizontalStart2;
                                gravityY1 = (int)(gravityTempY/(double)prevPixelCount1)+verticalStart2;
                                
                                delete [] arrayNewLines;
                                delete [] connectAnalysisX;
                                delete [] connectAnalysisY;
                                delete [] connectAnalysisTempX;
                                delete [] connectAnalysisTempY;
                                
                                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                        if (arrayCellTrackingCurrentMap [counterY][counterX] == currentMajor || arrayCellTrackingCurrentMap [counterY][counterX] == overlapNumber) arrayCellTrackingCurrentMap [counterY][counterX] = 0;
                                    }
                                }
                                
                                for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                        if (counterY+verticalStart2-verticalStart >= 0 && counterY+verticalStart2-verticalStart < trackAreaSize && counterX+horizontalStart2-horizontalStart >= 0 && counterX+horizontalStart2-horizontalStart < trackAreaSize){
                                            if (connectivityUpdate3 [counterY][counterX] == 1) arrayCellTrackingCurrentMap [counterY+verticalStart2-verticalStart][counterX+horizontalStart2-horizontalStart] = currentMajor;
                                        }
                                    }
                                }
                                
                                for (int counterY = 1; counterY < dimensionTemp+1; counterY++){
                                    for (int counterX = 1; counterX < dimensionTemp+1; counterX++){
                                        if (connectivityUpdateInside [counterY][counterX] != 0){
                                            if (counterY+verticalStart2-1 >= 0 && counterY+verticalStart2-1 < trackAreaSize && counterX+horizontalStart2-1 >= 0 && counterX+horizontalStart2-1 < trackAreaSize){
                                                arrayCellTrackingCurrentMap [counterY+verticalStart2-1][counterX+horizontalStart2-1] = connectivityUpdateInside [counterY][counterX];
                                            }
                                        }
                                    }
                                }
                                
                                //------Associate Data set------
                                currentAssData [overlapNumber][0] = 0;
                                
                                if ((currentAssData [currentMajor][1] == 1 && currentAssData [overlapNumber][1] == 2) || (currentAssData [currentMajor][1] == 2 && currentAssData [overlapNumber][1] == 1)){
                                    currentAssData [currentMajor][1] = 2;
                                }
                                if ((currentAssData [currentMajor][1] == 1 && currentAssData [overlapNumber][1] == 0) || (currentAssData [currentMajor][1] == 0 && currentAssData [overlapNumber][1] == 1)){
                                    currentAssData [currentMajor][1] = 1;
                                }
                                if ((currentAssData [currentMajor][1] == 2 && currentAssData [overlapNumber][1] == 0) || (currentAssData [currentMajor][1] == 0 && currentAssData [overlapNumber][1] == 2)){
                                    currentAssData [currentMajor][1] = 2;
                                }
                                if (currentAssData [currentMajor][3] != 0 && currentAssData [overlapNumber][3] != 0){
                                    if (currentAssData [currentMajor][3] != currentAssData [overlapNumber][3]){
                                        maxPairNumber = 0;
                                        
                                        for (int counter2 = 1; counter2 < lineNumberCurrent2+1; counter2++){
                                            if (maxPairNumber < currentAssData [counter2][3]) maxPairNumber = currentAssData [counter2][3];
                                        }
                                        
                                        currentAssData [currentMajor][3] = maxPairNumber+1;
                                    }
                                }
                                if (currentAssData [currentMajor][3] == 0 && currentAssData [overlapNumber][3] != 0) currentAssData [currentMajor][3] = currentAssData [overlapNumber][3];
                                
                                if (currentAssData [currentMajor][2] == 0 && currentAssData [overlapNumber][2] == 1) currentAssData [currentMajor][2] = 1;
                                else if (currentAssData [currentMajor][2] == 0 && currentAssData [overlapNumber][2] == 2) currentAssData [currentMajor][2] = 2;
                                else if (currentAssData [currentMajor][2] == 1 && currentAssData [overlapNumber][2] == 2) currentAssData [currentMajor][2] = 2;
                                
                                currentAssData [currentMajor][4] = currentAssData [currentMajor][4]+currentAssData [overlapNumber][4];
                                
                                if (cellTrackingCurrentAssStatus == 0){
                                    errorNoHold = 102;
                                    arrayCellTrackingCurrentAss = new int [lineNumberCurrent2*18+50];
                                    cellTrackingCurrentAssCount = 0;
                                    cellTrackingCurrentAssStatus = 1;
                                    cellTrackingCurrentAssSizeHold = lineNumberCurrent2*18+50;
                                }
                                else if (cellTrackingCurrentAssStatus == 1 && cellTrackingCurrentAssSizeHold < lineNumberCurrent2*6){
                                    delete [] arrayCellTrackingCurrentAss;
                                    
                                    errorNoHold = 103;
                                    arrayCellTrackingCurrentAss = new int [lineNumberCurrent2*18+50];
                                    cellTrackingCurrentAssCount = 0;
                                    cellTrackingCurrentAssSizeHold = lineNumberCurrent2*18+50;
                                }
                                else cellTrackingCurrentAssCount = 0;
                                
                                for (int counter2 = 1; counter2 < lineNumberCurrent2+1; counter2++){
                                    arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = currentAssData [counter2][0], cellTrackingCurrentAssCount++;
                                    arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = currentAssData [counter2][1], cellTrackingCurrentAssCount++;
                                    arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = currentAssData [counter2][2], cellTrackingCurrentAssCount++;
                                    arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = currentAssData [counter2][3], cellTrackingCurrentAssCount++;
                                    arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = currentAssData [counter2][4], cellTrackingCurrentAssCount++;
                                    arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = currentAssData [counter2][5], cellTrackingCurrentAssCount++;
                                    
                                    //cout<<" Number "<<previousAssData [counter5][0]<<" Process "<<previousAssData [counter5][1]<<" Cut "<<previousAssData [counter5][2]<<" Pair "<<previousAssData [counter5][3]<<" Dim "<<previousAssData [counter5][4]<<" Reserve "<<previousAssData [counter5][5]<<" Round "<<previousAssData [counter5][0]<<" ASSPREV_Prev"<<endl;
                                }
                                
                                //cout<<targetPointer<<" TARG"<<endl;
                                
                                //------Table, Total, Average update------
                                currentPointLine = 0;
                                currentTotaLine = 0;
                                
                                for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                    for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                        if (connectivityUpdate3 [counterY][counterX] != 0){
                                            if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                                                currentPointLine++;
                                                
                                                if (connectivityUpdate3 [counterY][counterX] != 100){ //------Line one data get------
                                                    currentTotaLine = currentTotaLine+sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2];
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                currentAverageLine = currentTotaLine/(double)currentPointLine;
                                
                                //cout<<currentMajor<<" "<<currentAverageLine<<" "<<currentTotaLine<<" "<<currentPointLine<<" Average1"<<endl;
                                //cout<<currentAverageLine2<<" "<<currentTotaLine2<<" "<<currentPointLine2<<" Average2"<<endl;
                                
                                for (int counter2 = 1; counter2 < lineNumberCurrent2+1; counter2++){
                                    if (counter2 != currentMajor && counter2 != overlapNumber){
                                        arrayCurrentTableTemp [currentTableCountTemp] = arrayCurrentTableTrack [counter2*2], currentTableCountTemp++;
                                        arrayCurrentTableTemp [currentTableCountTemp] = arrayCurrentTableTrack [counter2*2+1], currentTableCountTemp++;
                                        arrayCurrentTotalTemp [currentTotalCountTemp] = (int)arrayCurrentTableTrackTotal [counter2], currentTotalCountTemp++;
                                        arrayCurrentAverageTemp [currentAverageCountTemp] = arrayCurrentAverageTrack [counter2], currentAverageCountTemp++;
                                        
                                        //cout<<" Pix "<<arrayPreviousTableTrack [counter2*2]<<" ConnNo "<<arrayPreviousTableTrack [counter2*2+1]<<" Total "<<previousTotal [counter2]<<" Average "<<arrayPreviousAverageTrack [counter2]<<" PREVTABLE-Prev1"<<endl;
                                    }
                                    else if (counter2 == currentMajor){
                                        arrayCurrentTableTemp [currentTableCountTemp] = currentPointLine, currentTableCountTemp++;
                                        arrayCurrentTableTemp [currentTableCountTemp] = arrayCurrentTableTrack [currentMajor*2+1], currentTableCountTemp++;
                                        arrayCurrentTotalTemp [currentTotalCountTemp] = currentTotaLine, currentTotalCountTemp++;
                                        arrayCurrentAverageTemp [currentAverageCountTemp] = currentAverageLine, currentAverageCountTemp++;
                                        
                                        //cout<<" Pix "<<previousPointLine<<" ConnNo "<<arrayPreviousTableTrack [previousConnectNumber1*2+1]<<" Total "<<previousTotaLine<<" Average "<<previousAverageLine<<" PREVTABLE-Prev2"<<endl;
                                    }
                                    else{
                                        
                                        //------In the event that Connect is merged and connect number is removed, add original connect number in the [0]------
                                        //------Put merged counterpart connect number*-1 in [1]------
                                        arrayCurrentTableTemp [currentTableCountTemp] = overlapNumber, currentTableCountTemp++;
                                        arrayCurrentTableTemp [currentTableCountTemp] = arrayCurrentTableTrack [currentMajor*2+1]*-1, currentTableCountTemp++;
                                        arrayCurrentTotalTemp [currentTotalCountTemp] = 0, currentTotalCountTemp++;
                                        arrayCurrentAverageTemp [currentAverageCountTemp] = 0, currentAverageCountTemp++;
                                        
                                        //cout<<" Pix "<<overlapNumber<<" ConnNo "<<arrayCurrentTableTrack [currentMajor*2+1]*-1<<" Total "<<0<<" Average "<<0<<" PREVTABLE-Prev3"<<endl;
                                    }
                                }
                                
                                overlapSource [previousConnectNumber1][overlapNumber] = 0;
                                
                                for (int counter2 = 0; counter2 < maxTargetEntry; counter2++){
                                    if (overlapNumberTable [previousConnectNumber1][counter2] == overlapNumber){
                                        overlapSource [previousConnectNumber1][overlapNumberTable [previousConnectNumber1][counter2]] = 0;
                                    }
                                }
                                
                                delete [] arrayCellTrackingCurrentTemp;
                                errorNoHold = 104;
                                arrayCellTrackingCurrentTemp = new int [xyPositionCenterCurrentCount+50];
                                cellTrackingCurrentTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < xyPositionCenterCurrentCount/6; counter2++){
                                    if (arrayXYPositionCenterCurrent [counter2*6+4] != currentMajor){
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter2*6], cellTrackingCurrentTempCount++;
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter2*6+1], cellTrackingCurrentTempCount++;
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter2*6+2], cellTrackingCurrentTempCount++;
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter2*6+3], cellTrackingCurrentTempCount++;
                                        
                                        if (arrayXYPositionCenterCurrent [counter2*6+4] == overlapNumber) arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 0, cellTrackingCurrentTempCount++;
                                        else arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter2*6+4], cellTrackingCurrentTempCount++;
                                        
                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter2*6+5], cellTrackingCurrentTempCount++;
                                    }
                                }
                                
                                if (xyPositionCenterCurrentStatus == 0){
                                    errorNoHold = 105;
                                    arrayXYPositionCenterCurrent = new int [cellTrackingCurrentTempCount*3+50];
                                    xyPositionCenterCurrentCount = 0;
                                    xyPositionCenterCurrentStatus = 1;
                                    xyPositionCenterCurrentSizeHold = cellTrackingCurrentTempCount*3+50;
                                }
                                else if (xyPositionCenterCurrentStatus == 1 && xyPositionCenterCurrentSizeHold < cellTrackingCurrentTempCount){
                                    delete [] arrayXYPositionCenterCurrent;
                                    
                                    errorNoHold = 106;
                                    arrayXYPositionCenterCurrent = new int [cellTrackingCurrentTempCount*3+50];
                                    xyPositionCenterCurrentCount = 0;
                                    xyPositionCenterCurrentSizeHold = cellTrackingCurrentTempCount*3+50;
                                }
                                else xyPositionCenterCurrentCount = 0;
                                
                                for (int counter2 = 0; counter2 < cellTrackingCurrentTempCount; counter2++) arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = arrayCellTrackingCurrentTemp [counter2], xyPositionCenterCurrentCount++;
                                
                                arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = gravityX1, xyPositionCenterCurrentCount++;
                                arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = gravityY1, xyPositionCenterCurrentCount++;
                                arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = currentPointLine, xyPositionCenterCurrentCount++;
                                arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = (int)currentAverageLine, xyPositionCenterCurrentCount++;
                                arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = currentMajor, xyPositionCenterCurrentCount++;
                                arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = 0, xyPositionCenterCurrentCount++;
                                
                                delete [] arrayCellTrackingCurrentTemp;
                                errorNoHold = 107;
                                arrayCellTrackingCurrentTemp = new int [xyPositionCenterCurrentCount+50];
                                cellTrackingCurrentTempCount = 0;
                                
                                for (int counter2 = 1; counter2 <= lineNumberCurrent2; counter2++){
                                    for (int counter3 = 0; counter3 < xyPositionCenterCurrentCount/6; counter3++){
                                        if (arrayXYPositionCenterCurrent [counter3*6+4] == counter2){
                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter3*6], cellTrackingCurrentTempCount++;
                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter3*6+1], cellTrackingCurrentTempCount++;
                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter3*6+2], cellTrackingCurrentTempCount++;
                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter3*6+3], cellTrackingCurrentTempCount++;
                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter3*6+4], cellTrackingCurrentTempCount++;
                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter3*6+5], cellTrackingCurrentTempCount++;
                                        }
                                    }
                                }
                                
                                xyPositionCenterCurrentCount = 0;
                                for (int counter2 = 0; counter2 < cellTrackingCurrentTempCount; counter2++) arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = arrayCellTrackingCurrentTemp [counter2], xyPositionCenterCurrentCount++;
                                
                                delete [] arrayCellTrackingCurrentTemp;
                                
                                //cout<<targetPointer<<" TARG6==============================="<<endl;
                                
                                //------Group Table update------
                                typeSubArray = 2;
                                tableInterpretation = [[TableInterpretation alloc] init];
                                [tableInterpretation interpretationFirst:typeSubArray];
                                
                                do{
                                } while(subCompletionFlag3 == 1);
                                
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                                
                                if (targetPointer == previousConnectNumber1){
                                    if (arrayGroupInfoCurrent [(currentMajor-1)*3] < 0){
                                        for (int counter2 = 0; counter2 < groupInfoCurrentCount/3; counter2++){
                                            if (arrayGroupInfoCurrent [counter2*3] == arrayGroupInfoCurrent [(currentMajor-1)*3]*-1) arrayGroupInfoCurrent [counter2*3] = arrayGroupInfoCurrent [(currentMajor-1)*3]*-1;
                                        }
                                        
                                        arrayGroupInfoCurrent [(currentMajor-1)*3] = arrayGroupInfoCurrent [(currentMajor-1)*3]*-1;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < dimensionTemp+5; counter2++){
                                    delete [] connectivityUpdate [counter2];
                                    delete [] connectivityUpdate2 [counter2];
                                    delete [] connectivityUpdate3 [counter2];
                                    delete [] connectivityUpdate5 [counter2];
                                    delete [] connectivityUpdateInside [counter2];
                                }
                                
                                delete [] connectivityUpdate;
                                delete [] connectivityUpdate2;
                                delete [] connectivityUpdate3;
                                delete [] connectivityUpdate5;
                                delete [] connectivityUpdateInside;
                            }
                            
                            if (allocationResult == 1 || allocationResult == 2 || allocationResult == 5){
                                
                                //cout<<"ALR_1_2_5"<<endl;
                                
                                errorNoHold = 108;
                                int **overlapData3 = new int *[lineNumberPrevious2+additionCount+5];
                                errorNoHold = 109;
                                int **overlapIntensity3 = new int *[lineNumberPrevious2+additionCount+5];
                                errorNoHold = 110;
                                int **overlapPercent3 = new int *[lineNumberPrevious2+additionCount+5];
                                
                                for (int counter2 = 0; counter2 < lineNumberPrevious2+additionCount+5; counter2++){
                                    errorNoHold = 111;
                                    overlapData3 [counter2] = new int [lineNumberCurrent2+5];
                                    errorNoHold = 112;
                                    overlapIntensity3 [counter2] = new int [lineNumberCurrent2+5];
                                    errorNoHold = 113;
                                    overlapPercent3 [counter2] = new int [lineNumberCurrent2+5];
                                }
                                
                                for (int counterY = 1; counterY < lineNumberPrevious2+additionCount+5; counterY++){
                                    for (int counterX = 1; counterX < lineNumberCurrent2+5; counterX++){
                                        overlapData3 [counterY][counterX] = 0;
                                        overlapIntensity3 [counterY][counterX] = 0;
                                        overlapPercent3 [counterY][counterX] = 0;
                                    }
                                }
                                
                                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                        if (arrayCellTrackingPreviousMap [counterY][counterX] > 0 && arrayCellTrackingCurrentMap [counterY][counterX] > 0){
                                            overlapData3 [arrayCellTrackingPreviousMap [counterY][counterX]][arrayCellTrackingCurrentMap [counterY][counterX]]++;
                                            
                                            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                                overlapIntensity3 [arrayCellTrackingPreviousMap [counterY][counterX]][arrayCellTrackingCurrentMap [counterY][counterX]] = overlapIntensity3 [arrayCellTrackingPreviousMap [counterY][counterX]][arrayCellTrackingCurrentMap [counterY][counterX]]+sourceImage [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                            }
                                        }
                                    }
                                }
                                
                                for (int counterY = 1; counterY < lineNumberPrevious2+additionCount+1; counterY++){
                                    for (int counterX = 1; counterX < lineNumberCurrent2+1; counterX++){
                                        if (overlapSource [counterY][counterX] == 0) overlapData3 [counterY][counterX] = 0;
                                    }
                                }
                                
                                for (int counterY = 1; counterY < lineNumberPrevious2+additionCount+1; counterY++){
                                    for (int counterX = 1; counterX < lineNumberCurrent2+1; counterX++){
                                        if (overlapData3 [counterY][counterX] > 0 && arrayPreviousTableTrack [counterY*2] > 0){
                                            overlapIntensity3 [counterY][counterX] = (int)(overlapIntensity3 [counterY][counterX]/(double)overlapData3 [counterY][counterX]);
                                        }
                                        
                                        if (overlapData3 [counterY][counterX] > 0 && arrayPreviousTableTrack [counterY*2] > 0){
                                            overlapPercent3 [counterY][counterX] = (int)((overlapData3 [counterY][counterX]/(double)arrayPreviousTableTrack [counterY*2])*100);
                                        }
                                    }
                                }
                                
                                //for (int counterY = 1; counterY < lineNumberPrevious2+1; counterY++){
                                //	for (int counterX = 1; counterX < lineNumberCurrent2+additionCount+1; counterX++) cout<<counterY<<" "<<counterX<<" "<<overlapData3 [counterY][counterX]<<" OV3"<<endl;
                                //}
                                
                                maxTargetEntry = 0;
                                
                                for (int counterY = 1; counterY < lineNumberPrevious2+additionCount+1; counterY++){
                                    entryTemp = 0;
                                    
                                    for (int counterX = 1; counterX < lineNumberCurrent2+1; counterX++){
                                        if (overlapData3 [counterY][counterX] != 0 && arrayCurrentTableTrack [counterX*2] > 0) entryTemp++;
                                    }
                                    if (entryTemp > maxTargetEntry) maxTargetEntry = entryTemp;
                                }
                                
                                errorNoHold = 114;
                                int **overlapNumber4 = new int *[lineNumberPrevious2+additionCount+5];
                                errorNoHold = 115;
                                int **overlapData4 = new int *[lineNumberPrevious2+additionCount+5];
                                errorNoHold = 116;
                                int **overlapIntensity4 = new int *[lineNumberPrevious2+additionCount+5];
                                errorNoHold = 117;
                                int **overlapPercent4 = new int *[lineNumberPrevious2+additionCount+5];
                                
                                for (int counter2 = 0; counter2 < lineNumberPrevious2+additionCount+5; counter2++){
                                    errorNoHold = 118;
                                    overlapNumber4 [counter2] = new int [maxTargetEntry+5];
                                    errorNoHold = 119;
                                    overlapData4 [counter2] = new int [maxTargetEntry+5];
                                    errorNoHold = 120;
                                    overlapIntensity4 [counter2] = new int [maxTargetEntry+5];
                                    errorNoHold = 121;
                                    overlapPercent4 [counter2] = new int [maxTargetEntry+5];
                                }
                                
                                for (int counterY = 1; counterY < lineNumberPrevious2+additionCount+5; counterY++){
                                    for (int counterX = 0; counterX < maxTargetEntry+5; counterX++){
                                        overlapNumber4 [counterY][counterX] = 0;
                                        overlapData4 [counterY][counterX] = 0;
                                        overlapIntensity4 [counterY][counterX] = 0;
                                        overlapPercent4 [counterY][counterX] = 0;
                                    }
                                }
                                
                                for (int counterY = 1; counterY < lineNumberPrevious2+additionCount+1; counterY++){
                                    //------Sort------
                                    entryCount = 0;
                                    
                                    do{
                                        
                                        terminationFlag1 = 1;
                                        sortFindFlag = 0;
                                        overlapMax = 0;
                                        overlapCount = 0;
                                        
                                        for (int counter2 = 1; counter2 < lineNumberCurrent2+1; counter2++){
                                            if (overlapMax < overlapPercent3 [counterY][counter2] && overlapPercent3 [counterY][counter2] != 0){
                                                overlapMax = overlapPercent3 [counterY][counter2];
                                                overlapCount = counter2;
                                                sortFindFlag = 1;
                                            }
                                        }
                                        
                                        if (sortFindFlag == 1){
                                            overlapNumber4 [counterY][entryCount] = overlapCount;
                                            overlapData4 [counterY][entryCount] = overlapData3 [counterY][overlapCount];
                                            overlapIntensity4 [counterY][entryCount] = overlapIntensity3 [counterY][overlapCount];
                                            overlapPercent4 [counterY][entryCount] = overlapMax;
                                            overlapPercent3 [counterY][overlapCount] = 0;
                                            entryCount++;
                                        }
                                        else terminationFlag1 = 0;
                                        
                                    } while (terminationFlag1 == 1);
                                }
                                
                                delete [] arrayOverlapNumberTrack;
                                errorNoHold = 122;
                                arrayOverlapNumberTrack = new int [(lineNumberPrevious2+additionCount)*maxTargetEntry*3+10];
                                int overlapNumberCount = 0;
                                
                                delete [] arrayOverlapPixelAreaTrack;
                                errorNoHold = 123;
                                arrayOverlapPixelAreaTrack = new int [(lineNumberPrevious2+additionCount)*maxTargetEntry*3+10];
                                int overlapPixelAreaCount = 0;
                                
                                delete [] arrayOverlapPixelIntensityTrack;
                                errorNoHold = 124;
                                arrayOverlapPixelIntensityTrack = new int [(lineNumberPrevious2+additionCount)*maxTargetEntry*3+10];
                                int overlapPixelIntensityCount = 0;
                                
                                delete [] arrayOverlapPercentTrack;
                                errorNoHold = 125;
                                arrayOverlapPercentTrack = new int [(lineNumberPrevious2+additionCount)*maxTargetEntry*3+10];
                                int overlapPercentCount = 0;
                                
                                for (int counterY = 1; counterY < lineNumberPrevious2+additionCount+1; counterY++){
                                    entryCount = 0;
                                    
                                    for (int counterX = 0; counterX < maxTargetEntry; counterX++){
                                        if (overlapNumber4 [counterY][counterX] != 0 && overlapData4 [counterY][counterX] >= 10){
                                            if (arrayCurrentTableTrack [overlapNumber4 [counterY][counterX]*2] > 0 && arrayCurrentTableTrack [overlapNumber4 [counterY][counterX]*2+1] > 0){
                                                arrayOverlapNumberTrack [overlapNumberCount] = counterY, overlapNumberCount++;
                                                arrayOverlapNumberTrack [overlapNumberCount] = entryCount, overlapNumberCount++;
                                                arrayOverlapNumberTrack [overlapNumberCount] = overlapNumber4 [counterY][counterX], overlapNumberCount++;
                                                
                                                arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = counterY, overlapPixelAreaCount++;
                                                arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = entryCount, overlapPixelAreaCount++;
                                                arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = overlapData4 [counterY][counterX], overlapPixelAreaCount++;
                                                
                                                arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = counterY, overlapPixelIntensityCount++;
                                                arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = entryCount, overlapPixelIntensityCount++;
                                                arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = overlapIntensity4 [counterY][counterX], overlapPixelIntensityCount++;
                                                
                                                arrayOverlapPercentTrack [overlapPercentCount] = counterY, overlapPercentCount++;
                                                arrayOverlapPercentTrack [overlapPercentCount] = entryCount, overlapPercentCount++;
                                                arrayOverlapPercentTrack [overlapPercentCount] = overlapPercent4 [counterY][counterX], overlapPercentCount++;
                                                
                                                entryCount++;
                                            }
                                        }
                                    }
                                }
                                
                                overlapPixelAreaCountTrack = overlapPixelAreaCount;
                                overlapPixelIntensityCountTrack = overlapPixelIntensityCount;
                                overlapPercentCountTrack = overlapPercentCount;
                                overlapNumberCountTrack = overlapNumberCount;
                                
                                for (int counter2 = 0; counter2 < lineNumberPrevious2+additionCount+5; counter2++){
                                    delete [] overlapData3 [counter2];
                                    delete [] overlapIntensity3 [counter2];
                                    delete [] overlapPercent3 [counter2];
                                    delete [] overlapNumber4 [counter2];
                                    delete [] overlapData4 [counter2];
                                    delete [] overlapIntensity4 [counter2];
                                    delete [] overlapPercent4 [counter2];
                                }
                                
                                delete [] overlapData3;
                                delete [] overlapIntensity3;
                                delete [] overlapPercent3;
                                delete [] overlapNumber4;
                                delete [] overlapData4;
                                delete [] overlapIntensity4;
                                delete [] overlapPercent4;
                            }
                            
                            delete [] attachMajor;
                            
                            //+++++++++++No Merge Case++++++++++
                            if (allocationResult == 3 || allocationResult == 7){ //------Move data to No merge Table, 3: minor, 7, Major and Minor------
                                
                                //cout<<" ALR_3_7_<ove "<<" OverlapNO "<<overlapNumber<<" currMajor "<<currentMajor<<endl;
                                
                                if (previousConnectNumber1 == targetPointer && overlapIntensityTable [counter1][0] < cutOff4 && overlapIntensityTable [counter1][1] < cutOff4){
                                    overlapSource [counter1][overlapNumberTable [counter1][1]] = 0;
                                    overlapNumberTable [counter1][1] = 0;
                                }
                                else{
                                    
                                    if (arrayCurrentTableTrack [currentMajor*2]*0.5 < arrayCurrentTableTrack [overlapNumber*2]){ //------If area of second connect is less than 50% of major, remove. If not, enter to No merge------
                                        overlapSource [counter1][overlapNumberTable [counter1][1]] = 0;
                                        noMergeTable [counter1][overlapNumber] = 1;
                                        overlapNumberTable [counter1][1] = 0;
                                    }
                                    else{
                                        
                                        overlapSource [counter1][overlapNumberTable [counter1][1]] = 0;
                                        overlapNumberTable [counter1][1] = 0;
                                    }
                                }
                                
                                if (allocationResult == 7){ //------If Number of entry is 1, no enter to No Merge Table------
                                    overlapSource [counter1][overlapNumberTable [counter1][0]] = 0;
                                    overlapNumberTable [counter1][0] = 0;
                                    
                                    if (numberOfEntry > 1) noMergeTable [counter1][currentMajor] = 1;
                                }
                                
                                delete [] arrayOverlapNumberTrack;
                                errorNoHold = 126;
                                arrayOverlapNumberTrack = new int [lineNumberPrevious2*maxTargetEntry*3+10];
                                int overlapNumberCount = 0;
                                
                                delete [] arrayOverlapPixelAreaTrack;
                                errorNoHold = 127;
                                arrayOverlapPixelAreaTrack = new int [lineNumberPrevious2*maxTargetEntry*3+10];
                                int overlapPixelAreaCount = 0;
                                
                                delete [] arrayOverlapPixelIntensityTrack;
                                errorNoHold = 128;
                                arrayOverlapPixelIntensityTrack = new int [lineNumberPrevious2*maxTargetEntry*3+10];
                                int overlapPixelIntensityCount = 0;
                                
                                delete [] arrayOverlapPercentTrack;
                                errorNoHold = 129;
                                arrayOverlapPercentTrack = new int [lineNumberPrevious2*maxTargetEntry*3+10];
                                int overlapPercentCount = 0;
                                
                                //------OverlapTable, Up date------
                                for (int counterY = 1; counterY < lineNumberPrevious2+additionCount+1; counterY++){
                                    entryCount = 0;
                                    
                                    for (int counterX = 0; counterX < maxTargetEntry; counterX++){
                                        if (overlapNumberTable [counterY][counterX] != 0){
                                            arrayOverlapNumberTrack [overlapNumberCount] = counterY, overlapNumberCount++;
                                            arrayOverlapNumberTrack [overlapNumberCount] = entryCount, overlapNumberCount++;
                                            arrayOverlapNumberTrack [overlapNumberCount] = overlapNumberTable [counterY][counterX], overlapNumberCount++;
                                            
                                            arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = counterY, overlapPixelAreaCount++;
                                            arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = entryCount, overlapPixelAreaCount++;
                                            arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = overlapAreaTable [counterY][counterX], overlapPixelAreaCount++;
                                            
                                            arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = counterY, overlapPixelIntensityCount++;
                                            arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = entryCount, overlapPixelIntensityCount++;
                                            arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = overlapIntensityTable [counterY][counterX], overlapPixelIntensityCount++;
                                            
                                            arrayOverlapPercentTrack [overlapPercentCount] = counterY, overlapPercentCount++;
                                            arrayOverlapPercentTrack [overlapPercentCount] = entryCount, overlapPercentCount++;
                                            arrayOverlapPercentTrack [overlapPercentCount] = overlapPercentageTable [counterY][counterX], overlapPercentCount++;
                                            
                                            entryCount++;
                                        }
                                    }
                                }
                                
                                overlapPixelAreaCountTrack = overlapPixelAreaCount;
                                overlapPixelIntensityCountTrack = overlapPixelIntensityCount;
                                overlapPercentCountTrack = overlapPercentCount;
                                overlapNumberCountTrack = overlapNumberCount;
                                
                                for (int counterY = 1; counterY < lineNumberPrevious2+additionCount+1; counterY++){
                                    for (int counterX = 1; counterX < lineNumberCurrent2+1; counterX++){
                                        if (noMergeTable [counterY][counterX] > 0){
                                            if (noMergeTableCount+2 > noMergeTableLimit){
                                                errorNoHold = 130;
                                                int *arraySourceTemp = new int [noMergeTableCount+50];
                                                for (int counter2 = 0; counter2 < noMergeTableCount; counter2++) arraySourceTemp [counter2] = arrayNoMergeTableTrack [counter1];
                                                
                                                delete [] arrayNoMergeTableTrack;
                                                errorNoHold = 131;
                                                arrayNoMergeTableTrack = new int [noMergeTableLimit+50];
                                                noMergeTableLimit = noMergeTableLimit+50;
                                                
                                                for (int counter2 = 0; counter2 < noMergeTableCount; counter2++) arrayNoMergeTableTrack [counter2] = arraySourceTemp [counter1];
                                                delete [] arraySourceTemp;
                                            }
                                            
                                            arrayNoMergeTableTrack [noMergeTableCount] = counterY, noMergeTableCount++;
                                            arrayNoMergeTableTrack [noMergeTableCount] = counterX, noMergeTableCount++;
                                        }
                                    }
                                }
                                
                                noMergeTableCountTrack = noMergeTableCount;
                                noMergeTableLimitTrack = noMergeTableLimit;
                            }
                            
                            delete [] minorIntensity;
                            delete [] minorPair;
                            delete [] minorProcess;
                            delete [] minorDimension;
                            delete [] connectMinorCurrentA1;
                            delete [] connectMinorCurrentB1;
                            delete [] connectMinorCurrentC1;
                            delete [] currentConnectNumber;
                            
                            if (previousAverageCountTemp != 0){
                                delete [] arrayPreviousTableTrack;
                                errorNoHold = 132;
                                arrayPreviousTableTrack = new int [lineNumberPrevious2*2+50];
                                
                                delete [] arrayPreviousTableTrackTotal;
                                errorNoHold = 133;
                                arrayPreviousTableTrackTotal = new double [lineNumberPrevious2+50];
                                
                                delete [] arrayPreviousAverageTrack;
                                errorNoHold = 134;
                                arrayPreviousAverageTrack = new double [lineNumberPrevious2+50];
                                
                                for (int counter2 = 0; counter2 < previousAverageCountTemp; counter2++){
                                    arrayPreviousTableTrack [(counter2+1)*2] = arrayPreviousTableTemp [counter2*2];
                                    arrayPreviousTableTrack [(counter2+1)*2+1] = arrayPreviousTableTemp [counter2*2+1];
                                    arrayPreviousTableTrackTotal [counter2+1] = arrayPreviousTotalTemp [counter2];
                                    arrayPreviousAverageTrack [counter2+1] = arrayPreviousAverageTemp [counter2];
                                }
                            }
                            
                            delete [] arrayPreviousTableTemp;
                            delete [] arrayPreviousTotalTemp;
                            delete [] arrayPreviousAverageTemp;
                            
                            if (currentAverageCountTemp != 0){
                                delete [] arrayCurrentTableTrack;
                                errorNoHold = 135;
                                arrayCurrentTableTrack = new int [lineNumberCurrent2*2+50];
                                
                                delete [] arrayCurrentTableTrackTotal;
                                errorNoHold = 136;
                                arrayCurrentTableTrackTotal = new double [lineNumberCurrent2+50];
                                
                                delete [] arrayCurrentAverageTrack;
                                errorNoHold = 137;
                                arrayCurrentAverageTrack = new double [lineNumberCurrent2+50];
                                
                                for (int counter2 = 0; counter2 < currentAverageCountTemp; counter2++){
                                    arrayCurrentTableTrack [(counter2+1)*2] = arrayCurrentTableTemp [counter2*2];
                                    arrayCurrentTableTrack [(counter2+1)*2+1] = arrayCurrentTableTemp [counter2*2+1];
                                    arrayCurrentTableTrackTotal [counter2+1] = arrayCurrentTotalTemp [counter2];
                                    arrayCurrentAverageTrack [counter2+1] = arrayCurrentAverageTemp [counter2];
                                }
                            }
                            
                            delete [] arrayCurrentTableTemp;
                            delete [] arrayCurrentTotalTemp;
                            delete [] arrayCurrentAverageTemp;
                            
                            if (allocationResult > 0){
                                terminationFlagLoop = 1;
                                break;
                            }
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < lineNumberPrevious2+5; counter1++){
                        delete [] overlapAreaTable [counter1];
                        delete [] overlapIntensityTable [counter1];
                        delete [] overlapPercentageTable [counter1];
                        delete [] overlapNumberTable [counter1];
                        delete [] overlapSource [counter1];
                        delete [] previousAssData [counter1];
                        delete [] noMergeTable [counter1];
                    }
                    
                    delete [] overlapAreaTable;
                    delete [] overlapIntensityTable;
                    delete [] overlapPercentageTable;
                    delete [] overlapNumberTable;
                    delete [] overlapSource;
                    delete [] previousAssData;
                    delete [] noMergeTable;
                    
                    delete [] groupTablePreviousious;
                    
                    for (int counter1 = 0; counter1 < lineNumberCurrent2+5; counter1++) delete [] currentAssData [counter1];
                    delete [] currentAssData;
                    
                    delete [] connectMajorCurrentTempA1;
                    delete [] connectMajorCurrentTempB1;
                    delete [] connectMajorCurrentTempC1;
                    
                    maxTargetEntryTrack = maxTargetEntry;
                    targetPointerTrack = targetPointer;
                    
                    //cout<<p_variablesSet -> _maxTargetEntry<<" MaxTarget4"<<endl;
                }
                
            } while (terminationFlagLoop == 1);
            
            //for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrevious [counterA*6+counterB];
            //	cout<<" arrayCellTrackingPrevious "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < cellTrackingCurrentCount/6; counterA++){
            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrent [counterA*6+counterB];
            //	cout<<" arrayCellTrackingCurrent "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < p_variablesSet ->_overlapPixelIntensityCount/3; counterA++){
            //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelIntensityTrack [counterA*3+counterB];
            //    cout<<" arrayOverlapPixelIntensityTrack "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < p_variablesSet ->_overlapPixelAreaCount/3; counterA++){
            //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelAreaTrack [counterA*3+counterB];
            //    cout<<" arrayOverlapPixelAreaTrack "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < p_variablesSet ->_overlapPercentCount/3; counterA++){
            //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPercentTrack [counterA*3+counterB];
            //    cout<<" arrayOverlapPercentTrack "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < p_variablesSet ->_overlapNumberCount/3; counterA++){
            //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapNumberTrack [counterA*3+counterB];
            //    cout<<" arrayOverlapNumberTrack "<<counterA<<endl;
            //}
            
            errorNoHold = 0;
            subCompletionFlag2 = 0;
        }
        catch (int errorCheckThrow){
            if (errorNoHold == 0) errorNoHold = 1000;
            
            subCompletionFlag2 = 0;
        }
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingTargetCurrent "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"TargetCurrent"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
        
        subCompletionFlag2 = 0;
    }
}

@end
