//
//  TableInterpret.h
//  Cell_Carving
//
//  Created by Masahiko Sato on 2015-03-26.
//
//

#import <Cocoa/Cocoa.h>

@interface TableInterpret : NSWindowController

@end
