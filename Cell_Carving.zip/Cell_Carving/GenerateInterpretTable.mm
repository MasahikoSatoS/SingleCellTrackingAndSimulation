//
//  GenerateInterpretTable.m
//  Cell_Carving
//
//  Created by Masahiko Sato on 2015-03-26.
//
//

#import "GenerateInterpretTable.h"

@implementation GenerateInterpretTable

-(void)trackTableGenerate{
    try{
        
        errorNoHold = 0;
        subCompletionFlag = 1;
        
        //==========Tracking Table Entry==========
        if (roundStatus == 2){
            if (cellTrackingTableStatus == 0){
                errorNoHold = 1;
                arrayCellTrackingTable = new int [cellTrackingRelCount*20+50];
                cellTrackingTableCount = 0;
                cellTrackingTableLimit = cellTrackingRelCount*20+50;
                cellTrackingTableStatus = 1;
                cellTrackingTableSizeHold = cellTrackingRelCount*20+50;
            }
            else if (cellTrackingTableStatus == 1 && cellTrackingTableSizeHold < cellTrackingRelCount){
                delete [] arrayCellTrackingTable;
                
                errorNoHold = 2;
                arrayCellTrackingTable = new int [cellTrackingRelCount*20+50];
                cellTrackingTableCount = 0;
                cellTrackingTableLimit = cellTrackingRelCount*20+50;
                cellTrackingTableSizeHold = cellTrackingRelCount*20+50;
            }
            else cellTrackingTableCount = 0;
            
            for (int counter1 = 0; counter1 < cellTrackingTableLimit; counter1++) arrayCellTrackingTable [counter1] = 0;
            
            for (int counter1 = 0; counter1 < cellTrackingRelCount; counter1++) arrayCellTrackingTable [cellTrackingTableCount] = arrayCellTrackingRel [counter1], cellTrackingTableCount++;
        }
        
        //for (int counterA = 0; counterA < cellTrackingRelCount/15; counterA++){
        //  for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingRel [counterA*15+counterB];
        // cout<<" arrayCellTrackingRel "<<counterA<<endl;
        //}
        
        if (roundStatus > 2){
            int nextConnectNo1 = 0;
            int nextConnectNo2 = 0;
            int originalConnectNo1 = 0;
            int originalConnectNo2 = 0;
            int findFlag1 = 0;
            int findFlag2 = 0;
            
            for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                if (arrayCellTrackingTable [counter1*15] == roundStatus-2){
                    nextConnectNo1 = arrayCellTrackingTable [counter1*15+10];
                    nextConnectNo2 = arrayCellTrackingTable [counter1*15+11];
                    
                    if (nextConnectNo1 != 0){
                        for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                            if (arrayCellTrackingTable [counter2*15] == roundStatus-1 && arrayCellTrackingTable [counter2*15+2] == nextConnectNo1){
                                originalConnectNo1 = arrayCellTrackingTable [counter2*15+10];
                                originalConnectNo2 = arrayCellTrackingTable [counter2*15+11];
                                
                                if (arrayCellTrackingTable [counter2*15+7] == 1){
                                    originalConnectNo1 = targetConnectInitial;
                                    originalConnectNo2 = 0;
                                }
                                
                                findFlag1 = 0;
                                findFlag2 = 0;
                                
                                for (int counter3 = 0; counter3 < cellTrackingRelCount/15; counter3++){
                                    if (arrayCellTrackingRel [counter3*15] == roundStatus-1 && arrayCellTrackingRel [counter3*15+2] == originalConnectNo1) findFlag1 = 1;
                                    if (arrayCellTrackingRel [counter3*15] == roundStatus-1 && arrayCellTrackingRel [counter3*15+2] == originalConnectNo2) findFlag2 = 2;
                                }
                                
                                arrayCellTrackingTable [counter1*15+10] = 0;
                                arrayCellTrackingTable [counter1*15+11] = 0;
                                
                                if (findFlag1 == 1) arrayCellTrackingTable [counter1*15+10] = originalConnectNo1;
                                else if (findFlag2 == 2){
                                    if (arrayCellTrackingTable [counter1*15+10] == 0) arrayCellTrackingTable [counter1*15+10] = originalConnectNo2;
                                    else arrayCellTrackingTable [counter1*15+11] = originalConnectNo2;
                                }
                            }
                        }
                    }
                    
                    if (nextConnectNo2 != 0){
                        for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                            if (arrayCellTrackingTable [counter1*15] == nextConnectNo2){
                                originalConnectNo1 = arrayCellTrackingTable [counter2*15+10];
                                originalConnectNo2 = arrayCellTrackingTable [counter2*15+11];
                                
                                if (arrayCellTrackingTable [counter2*15+7] == 1){
                                    originalConnectNo1 = targetConnectInitial;
                                    originalConnectNo2 = 0;
                                }
                                
                                findFlag1 = 0;
                                findFlag2 = 0;
                                
                                for (int counter3 = 0; counter3 < cellTrackingRelCount/15; counter3++){
                                    if (arrayCellTrackingRel [counter3*15] == roundStatus-1 && arrayCellTrackingRel [counter3*15+2] != 0 && arrayCellTrackingRel [counter3*15+2] == originalConnectNo1) findFlag1 = 1;
                                    if (arrayCellTrackingRel [counter3*15] == roundStatus-1 && arrayCellTrackingRel [counter3*15+2] != 0 && arrayCellTrackingRel [counter3*15+2] == originalConnectNo2) findFlag2 = 2;
                                }
                                
                                arrayCellTrackingTable [counter1*15+10] = 0;
                                arrayCellTrackingTable [counter1*15+11] = 0;
                                
                                if (findFlag1 == 1) arrayCellTrackingTable [counter1*15+10] = originalConnectNo1;
                                else if (findFlag2 == 2){
                                    if (arrayCellTrackingTable [counter1*15+10] == 0) arrayCellTrackingTable [counter1*15+10] = originalConnectNo2;
                                    else arrayCellTrackingTable [counter1*15+11] = originalConnectNo2;
                                }
                            }
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
            //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
            //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
            //}
            
            errorNoHold = 3;
            int *arrayCellTrackingTableTemp = new int [cellTrackingTableCount+50];
            int cellTrackingTableCountTemp = 0;
            
            for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                if (arrayCellTrackingTable [counter1*15] <= roundStatus-2){
                    arrayCellTrackingTableTemp [cellTrackingTableCountTemp] = arrayCellTrackingTable [counter1*15], cellTrackingTableCountTemp++; //------Round number------
                    arrayCellTrackingTableTemp [cellTrackingTableCountTemp] = arrayCellTrackingTable [counter1*15+1], cellTrackingTableCountTemp++; //------Image number------
                    arrayCellTrackingTableTemp [cellTrackingTableCountTemp] = arrayCellTrackingTable [counter1*15+2], cellTrackingTableCountTemp++; //------Connect number------
                    arrayCellTrackingTableTemp [cellTrackingTableCountTemp] = arrayCellTrackingTable [counter1*15+3], cellTrackingTableCountTemp++; //------X position------
                    arrayCellTrackingTableTemp [cellTrackingTableCountTemp] = arrayCellTrackingTable [counter1*15+4], cellTrackingTableCountTemp++; //------Y position------
                    arrayCellTrackingTableTemp [cellTrackingTableCountTemp] = arrayCellTrackingTable [counter1*15+5], cellTrackingTableCountTemp++; //------Area------
                    arrayCellTrackingTableTemp [cellTrackingTableCountTemp] = arrayCellTrackingTable [counter1*15+6], cellTrackingTableCountTemp++; //------Intensity------
                    arrayCellTrackingTableTemp [cellTrackingTableCountTemp] = arrayCellTrackingTable [counter1*15+7], cellTrackingTableCountTemp++; //------Target------
                    arrayCellTrackingTableTemp [cellTrackingTableCountTemp] = arrayCellTrackingTable [counter1*15+8], cellTrackingTableCountTemp++; //------Mitosis------
                    arrayCellTrackingTableTemp [cellTrackingTableCountTemp] = arrayCellTrackingTable [counter1*15+9], cellTrackingTableCountTemp++; //------Divide/Fuse/Check------
                    arrayCellTrackingTableTemp [cellTrackingTableCountTemp] = arrayCellTrackingTable [counter1*15+10], cellTrackingTableCountTemp++; //------Next1------
                    arrayCellTrackingTableTemp [cellTrackingTableCountTemp] = arrayCellTrackingTable [counter1*15+11], cellTrackingTableCountTemp++; //------Next2------
                    arrayCellTrackingTableTemp [cellTrackingTableCountTemp] = arrayCellTrackingTable [counter1*15+12], cellTrackingTableCountTemp++; //------Prev1----
                    arrayCellTrackingTableTemp [cellTrackingTableCountTemp] = arrayCellTrackingTable [counter1*15+13], cellTrackingTableCountTemp++; //------Prev2------
                    arrayCellTrackingTableTemp [cellTrackingTableCountTemp] = arrayCellTrackingTable [counter1*15+14], cellTrackingTableCountTemp++; //------Done count------
                }
            }
            
            cellTrackingTableCount = 0;
            
            for (int counter1 = 0; counter1 < cellTrackingTableCountTemp; counter1++) arrayCellTrackingTable [cellTrackingTableCount] = arrayCellTrackingTableTemp [counter1], cellTrackingTableCount++;
            
            delete [] arrayCellTrackingTableTemp;
            
            if (cellTrackingTableCount+cellTrackingRelCount > cellTrackingTableLimit){
                errorNoHold = 4;
                int *arrayUpDate = new int [cellTrackingTableCount+10];
                
                for (int counter1 = 0; counter1 < cellTrackingTableCount; counter1++) arrayUpDate [counter1] = arrayCellTrackingTable [counter1];
                
                delete [] arrayCellTrackingTable;
                errorNoHold = 5;
                arrayCellTrackingTable = new int [cellTrackingTableLimit+cellTrackingRelCount*20+10000];
                cellTrackingTableLimit = cellTrackingTableLimit+cellTrackingRelCount*20+10000;
                
                for (int counter1 = 0; counter1 < cellTrackingTableCount; counter1++) arrayCellTrackingTable [counter1] = arrayUpDate [counter1];
                delete [] arrayUpDate;
                
                cellTrackingTableSizeHold = cellTrackingTableLimit+cellTrackingRelCount*20+10000;
            }
            
            for (int counter1 = 0; counter1 < cellTrackingRelCount; counter1++) arrayCellTrackingTable [cellTrackingTableCount] = arrayCellTrackingRel [counter1], cellTrackingTableCount++;
        }
        
        //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
        //	for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
        //	cout<<" arrayCellTrackingTable "<<counterA<<endl;
        //}
        
        errorNoHold = 0;
        subCompletionFlag = 0;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingGenerateInterpretTable "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"GenerateInterpretTable"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
        
        subCompletionFlag = 0;
    }
}

@end
