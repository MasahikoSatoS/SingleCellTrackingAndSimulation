//
// TargetTrack.h
// cell_carving
//
// Created by Masahiko Sato on 02/01/12.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#ifndef TARGETTRACK_H
#define TARGETTRACK_H
#import "Controller.h"
#endif

@interface TargetTrack : NSObject{
    id targetPrevious;
    id targetCurrent;
}

-(int)targetTrackProcess;

@end
