//
// Controller.h
// cell_carving
//
// Created by Masahiko Sato on 10/07/11.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#ifndef CONTROLLER_H
#define CONTROLLER_H
#import <Cocoa/Cocoa.h>
#import "ImageFileUpLoad.h"
#import "TrackingSet.h"
#import "TrackingSetCurrent.h"
#import "ImageProcessing.h"
#import "ImageProcessingEnd.h"
#import "ImageProcessingIF.h"
#import "Merge.h"
#import "OverlapCheck.h"
#import "NewLineSet.h"
#import "GenerateInterpretTable.h"
#import "TargetTrack.h"
#import "TargetTrack2.h"
#import "TargetPrevious.h"
#import "TargetCurrent.h"
#import "TableInterpretation.h"
#import "MitosisPattern.h"
#import "GapFill.h"
#import "AreaCut.h"
#import "AreaCutCurrent.h"
#import "TrackingDataSave.h"
#import "SourceDisplay.h"
#import "TerminationMonitor.h"
#import "TiffFileRead.h"
#include <iostream>
#include <string>
#include <cstdio>
#include <dirent.h>
#include <sys/stat.h>
#include <fstream>
#include <sstream>
#include <errno.h>
#include <cstdlib>
#endif

using namespace std;

extern NSString *notificationToSourceImage;
extern NSString *notificationToImageProcessing;
extern NSString *notificationToTermination;
extern NSString *notificationToImageProcessingEnd;
extern NSString *notificationToImageProcessingIF;

//------Mitosis Pattern library---------
extern int *arrayMitosisPattern; //Mitosis pattern array
extern int mitosisPatternCount;
extern int mitosisPatternStatus;
extern int mitosisPatternSizeHold;
extern int lastPatternNumber; //Mitosis entry number

//------Basic Information---------
extern int firstCommunication; //Set when communication is established
extern int imageNumberInt; //Hold Image No.
extern int imageDimension; //Hold Image size
extern int xGravityCenter; //Gravity center
extern int yGravityCenter; //Gravity center
extern int roundStatus; //Round Status
extern int mitosisStatusHold; //Mitosis status

extern int *arrayLineageStartEnd; //Lineage Start/end point array
extern int lineageStartEndCount;
extern int lineageStartEndStatus;
extern int lineageStartEndSizeHold;

extern int *arrayLineageData; //Hold Lineage data
extern int lineageDataCount;
extern int lineageDataStatus;
extern int lineageDataSizeHold;

extern string *arrayTreatmentStatus; //Hold status of treatment
extern int treatmentStatusCount; //Treatment count

extern int maxTimePoint; //Max time point
extern int timeOneHold; //Time one
extern int timeEndHold; //Time end
extern int ifStartHold; //IF start
extern int imageEndHold; //Image end
extern int timeEventEntryHold; //Time event entry
extern int eventTypeEntryHold; //Event type
extern int exitRequest; //Set when Quit is pressed
extern int retryFlag; //Set when Retry is set
extern int retryInfoHold; //Limit retry once
extern int trackingLimit; //Hold Tracking Interval
extern int outsideSettingFlag; //Set when M/CD is set outside of tracking starting time
extern int blankDisplay; //Flag for idle display
extern int blankDisplayCount; //Flag for idle display for count
extern string analysisImageName; //Analysis name
extern string analysisID; //Analysis ID
extern string treatmentNameHold; //Treatment Name
extern string cellLineageNoHold; //Cell Lineage No.
extern string cellNoHold; //Cell No.
extern int cellStatusLoading; //Cell Status
extern int targetCellStatus; //Target status

extern int gravityCenterXHold1; //Gravity center X
extern int gravityCenterYHold1; //Gravity center Y
extern int gravityAverageHold1; //Average
extern int gravityCellNo1; //Cell No.

extern int gravityCenterXCurrentHold1; //Gravity centre X current
extern int gravityCenterYCurrentHold1; //Gravity centre Y current
extern int gravityAverageCurrentHold1; //Average current
extern int gravityCellNoCurrent1; //Cell No. current
extern int gravityCenterXCurrentHold2; //Gravity centre X current
extern int gravityCenterYCurrentHold2; //Gravity centre Y current
extern int gravityAverageCurrentHold2; //Average current
extern int gravityCellNoCurrent2; //Cell No. current
extern int gravityCenterXCurrentHold3; //Gravity centre X current
extern int gravityCenterYCurrentHold3; //Gravity centre Y current
extern int gravityAverageCurrentHold3; //Average current
extern int gravityCellNoCurrent3; //Cell No. current
extern int gravityCenterXCurrentHold4; //Gravity centre X current
extern int gravityCenterYCurrentHold4; //Gravity centre Y current
extern int gravityAverageCurrentHold4; //Average current
extern int gravityCellNoCurrent4; //Cell No. current
extern int gravityCenterEntryType; //Gravity centre entry type
extern double averageHold; //Average hold
extern double averageCurrentHold; //Average current hold

extern int optionalShiftPercent; //Shift %
extern int optionalShiftOrientation; //Shift orientation
extern int *arrayOptionalLineData; //Option line data
extern int optionalLineDataCount;
extern int optionalLineDataLimit;

extern uint8_t *fileReadArray; //Array holding image data
extern int tifImageColorGray; //Tif image color type

//-------TargetTrack--------
extern int trackAreaSize; //Track area size
extern int horizontalStart; //Image dimension X
extern int verticalStart; //Image dimension Y

//-------Previous Whole data array-------
extern int *arrayTimeSelected; //Hold Line Data Info.
extern int timeSelectedCount;
extern int timeSelectedLimit;
extern int timeSelectedStatus;
extern int timeSelectedSizeHold;

extern int *arrayConnectLineageRel; //Connect No-LineageNo relation Table
extern int connectLineageRelCount;
extern int connectLineageRelLimit;
extern int connectLineageRelStatus;
extern int connectLineageRelSizeHold;

extern int *arrayEventSequence; //Event sequence
extern int eventSequenceCount;
extern int eventSequenceLimit;
extern int eventSequenceStatus;

extern int *arrayPositionRevise; //Hold largest position revise
extern int positionReviseCount;
extern int positionReviseLimit;
extern int positionReviseAddition;
extern int positionReviseStatus;
extern int positionReviseSizeHold;

extern int *arrayGravityCenterRev; //Hold Gravity Center Data
extern int gravityCenterRevCount;
extern int gravityCenterRevLimit;
extern int gravityCenterRevStatus;
extern int gravityCenterRevSizeHold;

extern int *arrayAssociatedData; //Associate data
extern int associatedDataCount;
extern int associatedDataLimit;
extern int associatedDataStatus;
extern int associatedDataSizeHold;

extern int *arrayMitosisParameter; //Hold Mitosis Status
extern int mitosisParameterCount;
extern int mitosisParameterLimit;
extern int mitosisParameterStatus;

//-------Previous Whole Image array-------
extern int **revisedMap; //Whole connect map revise
extern int **revisedWorkingMap; //Whole connect map for update
extern int mapLoadingStatusPrev; //Map loading status
extern int revisedMapSizeHold; //Hold largest image size

extern int **sourceImage; //Grey scale image map
extern int **connectMap200; //Whole connect maps, processed
extern int **connectMap220; //Whole connect maps, processed
extern int **connectMap240; //Whole connect maps, processed
extern int **connectMapA; //Whole connect maps, processed
extern int **connectMapB; //Whole connect maps, processed
extern int **connectMapC; //Whole connect maps, processed
extern int **connectMapD; //Whole connect maps, processed

extern int *imageNoHoldMain; //Hold Image No. for processing
extern int mapEntryTotal; //No. of map entry, if multiple time points are processed, upload all maps for the time point
extern int mapPositionPointer; //Position indicator within the map array
extern int mapPositionPointerCurrent; //Map position for current
extern int mapPositionPointerHold; //Keep mapPositionPointer data
extern int verticalPositionHold; //Map vertical position
extern int trackingCheckInterval; //Tracking interval
extern int mainMapLoadStatus; //Map load status
extern string currentTreatmentNameHold; //Treatment name

//-------Previous Selected data array--------
extern int *arrayCellTrackingPrevious; //Previous cell info
extern int cellTrackingPreviousCount;
extern int cellTrackingPreviousStatus;
extern int cellTrackingPreviousSizeHold;

extern int *arrayCellTrackingPreviousAss; //Associate data previous
extern int cellTrackingPreviousAssCount;
extern int cellTrackingPreviousAssStatus;
extern int cellTrackingPreviousAssSizeHold;

extern int *arrayXYPositionCenterPrevious; //Previous XY position
extern int xyPositionCenterPreviousCount;
extern int xyPositionCenterPreviousStatus;
extern int xyPositionCenterPreviousSizeHold;

//-------Previous Selected Image array--------
extern int **arrayCellTrackingPreviousMap; //Previous Map
extern int sectionMapLoadingStatusPrev; //Set when maps are loaded
extern int cellTrackingPreviousMapSizeHold; //Set when maps are loaded

//-------Current Whole Data array-------
extern int *arrayTimeSelectedCurrent; //Hold Line Data Info.
extern int timeSelectedCurrentCount;
extern int timeSelectedCurrentLimit;
extern int timeSelectedCurrentStatus;
extern int timeSelectedCurrentSizeHold;

extern int *arrayConnectLineageRelCurrent; //Connect relation Table
extern int connectLineageRelCurrentCount;
extern int connectLineageRelCurrentLimit;
extern int connectLineageRelCurrentStatus;
extern int connectLineageRelCurrentSizeHold;

extern int *arrayPositionReviseCurrent; //Position revise data current
extern int positionReviseCurrentCount;
extern int positionReviseCurrentLimit;
extern int positionReviseCurrentAddition;
extern int positionReviseCurrentStatus;
extern int positionReviseCurrentSizeHold;

extern int *arrayGravityCenterRevCurrent; //Hold Gravity Center Data
extern int gravityCenterRevCurrentCount;
extern int gravityCenterRevCurrentLimit;
extern int gravityCenterRevCurrentStatus;
extern int gravityCenterRevCurrentSizeHold;

extern int *arrayAssociatedDataCurr; //Associate data
extern int associatedDataCurrCount;
extern int associatedDataCurrLimit;
extern int associatedDataCurrStatus;
extern int associatedDataCurrSizeHold;

//-------Current Whole Image array-------
extern int **revisedMapCurrent; //Whole connect map
extern int mapLoadingStatus; //Map loading status
extern int revisedMapCurrentSizeHold; //Current map size

//-------Current Selected data array-------
extern int *arrayCellTrackingCurrent; //Line Data Current
extern int cellTrackingCurrentCount;
extern int cellTrackingCurrentStatus;
extern int cellTrackingCurrentSizeHold;

extern int *arrayCellTrackingCurrentAss; //Line Data Current Associate
extern int cellTrackingCurrentAssCount;
extern int cellTrackingCurrentAssStatus;
extern int cellTrackingCurrentAssSizeHold;

extern int *arrayXYPositionCenterCurrent; //Position Current
extern int xyPositionCenterCurrentCount;
extern int xyPositionCenterCurrentStatus;
extern int xyPositionCenterCurrentSizeHold;

//-------Current Selected Image array-------
extern int **arrayCellTrackingCurrentMap; //Current Map
extern int sectionMapLoadingStatus; //Set when maps are loaded
extern int cellTrackingCurrentMapSizeHold; //Current map size

//-------Group Data-------
extern int *arrayGroupInfoCurrent; //Group Info. Current
extern int groupInfoCurrentCount;
extern int groupInfoCurrentStatus;
extern int groupInfoCurrentSizeHold;

extern int *arrayGroupInfoPrevious; //Group Info. Previous
extern int groupInfoPreviousCount;
extern int groupInfoPreviousStatus;
extern int groupInfoPreviousSizeHold;

//-------Sequential tracking info---------
extern int *arrayCellTrackingTable; //All Tracking Information hold
extern int cellTrackingTableCount;
extern int cellTrackingTableLimit;
extern int cellTrackingTableStatus;
extern int cellTrackingTableSizeHold;

extern int *arrayAttachTable; //All Attach Information hold
extern int cellAttachCount;
extern int cellAttachLimit;
extern int cellAttachStatus;

//------Area cut--------
extern int *arrayReferenceLine; //Reference Line to Set Next Connect
extern int referenceLineCount;
extern int referenceLineLimit;

extern int **connectivityMapCut; //ConnectivityMap for Cut
extern int connectivityMapCutStatus; //ConnectivityMap for Cut
extern int connectivityMapCutSizeHold; //ConnectivityMap for Cut

extern int **internalZeroMap; //ConnectivityMap for Cut
extern int internalZeroMapStatus;
extern int internalZeroMapSizeHold;

extern int **targetMap; //ConnectivityMap for Cut
extern int targetMapStatus;
extern int targetMapSizeHold;

extern int fusionPartnerLine; //Fusion partner lineage No.
extern int fusionPartnerCellNo; //Fusion partner cell No.
extern string cellNoHoldDiv1; //Div Cell No
extern string cellNoHoldDiv2; //Div Cell No
extern string cellNoHoldDiv3; //Div Cell No
extern string cellNoHoldDiv4; //Div Cell No

//------Table Result interpret---------
extern int trackHoldFlag; //Tracking end status
extern int terminationInfo; //Statement for the termination

extern int *connectNoHold; //Hold Connect No.
extern int connectNoHoldCount;
extern int connectNoHoldStatus;
extern int connectNoHoldSizeHold;

extern int targetConnectInitial; //Target prev connect No. hold

extern int *arrayCellTrackingRel; //Tracking Rel table
extern int cellTrackingRelCount;
extern int cellTrackingRelStatus;
extern int cellTrackingRelSizeHold;

extern string returnMessage; //Return message
extern string returnMessageTime; //Return message
extern string returnMessageExt; //Return message

extern int *arrayFusionPartner; //Hold fusion partner info
extern int fusionPartnerCount;
extern int fusionPartnerLimit;
extern int fusionPartnerStatus;

//------Image display--------
extern int *arrayDisplayData; //Hold display data
extern int displayDataCount;
extern int displayDataStatus;
extern int displayDataSizeHold;

extern int *arrayDisplayRel; //Hold display data
extern int displayRelCount;
extern int displayRelStatus;
extern int displayRelSizeHold;

extern int *arrayDisplayGravityCenter; //Hold display data
extern int displayGravityCenterCount;
extern int displayGravityCenterStatus;
extern int displayGravityCenterSizeHold;

extern int trackAreaSizeDisplay; //Area size display
extern int xTrackingPosition; //Gravity Center position to image display
extern int yTrackingPosition; //Gravity Center position to image display
extern int xDisplayPosition; //X position to image display
extern int yDisplayPosition; //Y position to image display

//------Fluorescent Map---------
extern int **fluorescentMap1; //Fluorescent Maps
extern int fluorescentMapStatus1;
extern int **fluorescentMap2; //Fluorescent Maps
extern int fluorescentMapStatus2;
extern int **fluorescentMap3; //Fluorescent Maps
extern int fluorescentMapStatus3;
extern int **fluorescentMap4; //Fluorescent Maps
extern int fluorescentMapStatus4;
extern int **fluorescentMap5; //Fluorescent Maps
extern int fluorescentMapStatus5;
extern int **fluorescentMap6; //Fluorescent Maps
extern int fluorescentMapStatus6;
extern int fluorescentMapSizeHold; //Fluorescent Maps loading

extern int **fluorescentMapCurrent1; //Fluorescent Maps current
extern int fluorescentMapCurrentStatus1;
extern int **fluorescentMapCurrent2; //Fluorescent Maps current
extern int fluorescentMapCurrentStatus2;
extern int **fluorescentMapCurrent3; //Fluorescent Maps current
extern int fluorescentMapCurrentStatus3;
extern int **fluorescentMapCurrent4; //Fluorescent Maps current
extern int fluorescentMapCurrentStatus4;
extern int **fluorescentMapCurrent5; //Fluorescent Maps current
extern int fluorescentMapCurrentStatus5;
extern int **fluorescentMapCurrent6; //Fluorescent Maps current
extern int fluorescentMapCurrentStatus6;
extern int fluorescentMapCurrentSizeHold; //Fluorescent Maps loading

extern int *expandLineFluorescent; //Fluorescent line data
extern int expandLineFluorescentCount;
extern int expandLineFluorescentLimit;
extern int expandLineFluorescentStatus;
extern int expandLineFluorescentSizeHold;

extern int *expandLineFluorescentData; //Fluorescent area data
extern int expandLineFluorescentDataCount;
extern int expandLineFluorescentDataLimit;
extern int expandLineFluorescentDataStatus;
extern int expandLineFluorescentDataSizeHold;

extern int *expandLineFluorescentCurrent; //Fluorescent line data current
extern int expandLineFluorescentCurrentCount;
extern int expandLineFluorescentCurrentLimit;
extern int expandLineFluorescentCurrentStatus;
extern int expandLineFluorescentCurrentSizeHold;

extern int *expandLineFluorescentDataCurrent; //Fluorescent area data current
extern int expandLineFluorescentDataCurrentCount;
extern int expandLineFluorescentDataCurrentLimit;
extern int expandLineFluorescentDataCurrentStatus;
extern int expandLineFluorescentDataCurrentSizeHold;

//------Fluorescent Option---------
extern int fluorescentCutOff1; //Fluorescent cut off value
extern int fluorescentCutOff2; //Fluorescent cut off value
extern int fluorescentCutOff3; //Fluorescent cut off value
extern int fluorescentCutOff4; //Fluorescent cut off value
extern int fluorescentCutOff5; //Fluorescent cut off value
extern int fluorescentCutOff6; //Fluorescent cut off value
extern int fluorescentCutOffCurrent1; //Fluorescent cut off value current
extern int fluorescentCutOffCurrent2; //Fluorescent cut off value current
extern int fluorescentCutOffCurrent3; //Fluorescent cut off value current
extern int fluorescentCutOffCurrent4; //Fluorescent cut off value current
extern int fluorescentCutOffCurrent5; //Fluorescent cut off value current
extern int fluorescentCutOffCurrent6; //Fluorescent cut off value current
extern int fluorescentNo1; //Fluorescent No
extern int fluorescentNo2; //Fluorescent No
extern int fluorescentNo3; //Fluorescent No
extern int fluorescentNo4; //Fluorescent No
extern int fluorescentNo5; //Fluorescent No
extern int fluorescentNo6; //Fluorescent No
extern int fluorescentEntryCount; //Fluorescent entry No

extern int *arrayFluorescentCutOff; //Fluorescent cut off array
extern int fluorescentCutOffCount;
extern int fluorescentCutOffStatus;

extern int autoExpand; //Auto expand Status
extern int autoExpandLine; //Auto expand line
extern string fluorescentName1; //Fluorescent color Name
extern string fluorescentName2; //Fluorescent color Name
extern string fluorescentName3; //Fluorescent color Name
extern string fluorescentName4; //Fluorescent color Name
extern string fluorescentName5; //Fluorescent color Name
extern string fluorescentName6; //Fluorescent color Name
extern string *arrayIFDataHold; //IF data array
extern int fluorescentDetectionDisplay1; //Fluorescent detection previous
extern int fluorescentDetectionDisplay2; //Fluorescent detection current

//--------DIC cut Off---------
extern int cutStatusDic; //DIC cut
extern int cutStatusFluorescent; //Fluorescent cut
extern int cutOff1; //DIC cut
extern int cutOff2; //DIC cut
extern int cutOff3; //DIC cut
extern int cutOff4; //DIC cut
extern int cutOff5; //DIC cut
extern int cutOff6; //DIC cut
extern int cutOff7; //DIC cut

extern string pathNameString; //Path name
extern string trackingDataFolderPath; //Tracking Data path
extern string cellCurvingSettingPath; //Cell Curving system data path
extern string mitosisPatternPath; //Mitosis pattern data path
extern string imageFolderPath; //Cell image folder path
extern string instractionCCPath;

//--------Overlap check array--------
extern int **putativeMap; //Hold area expansion data
extern int putativeMapStatus;
extern int putativeMapSizeHold;

//--------Directory process---------
extern string *arrayFileHandling; //Array for file order process
extern int fileHandlingCount;
extern int fileHandlingLimit;

//--------Mitosis/division parameter/map--------
extern double mitosisSDHold; //Mitosis SD
extern int mitosisValueHold; //Mitosis value
extern int divisionDistanceHold; //Div distance
extern int mitosisAreaHold; //Mitosis area
extern double mitosisRelativeLowHold; //Mitosis relative to parent cell low
extern double mitosisRelativeHighHold; //Mitosis relative to parent cell high
extern int jumpAllFlag; //Jump distance
extern int connectExpandFlag; //Connect expand
extern int mapMergeStatus; //Map merge allow on off
extern int percentOverlap; //Percent overlap
extern int gravityCentreMoveLimitFlag; //Gravity centre move allow on off
extern int mitosisOffFlag; //Mitosis set on off
extern int fusionMarkSetFlag; //Fusion mark set on off

//--------Error no----------
extern int errorNoHold; //Error no
extern int emergencyExit; //Exit flag
extern int trackingExitCount; //Tracking exit count
extern int sleepingCheck; //Sleeping check
extern int sleepingPosition; //Sleeping position hold

extern int subCompletionFlag; //Sub process completion check
extern int subCompletionFlag2; //Sub process completion check
extern int subCompletionFlag3; //Sub process completion check

//----------Target track---------
extern int targetPointerTrack; //Target position
extern int maxTargetEntryTrack; //No of entry into arrays
extern int *arrayPreviousTableTrack; //Previous table Area
extern double *arrayPreviousTableTrackTotal; //Previous table Intensity Total
extern double *arrayPreviousAverageTrack; //Previous table Average
extern int *arrayCurrentTableTrack; //Current table Area
extern double *arrayCurrentTableTrackTotal; //Current table Intensity Total
extern double *arrayCurrentAverageTrack; //Current table Average
extern int *arrayOverlapNumberTrack; //Overlap Number
extern int *arrayOverlapPixelAreaTrack; //Overlap Area
extern int *arrayOverlapPixelIntensityTrack; //Overlap Intensity
extern int *arrayOverlapPercentTrack; //Overlap %
extern int *arrayNoMergeTableTrack; //No Merge NumberTrack
extern int overlapNumberCountTrack; //Number of overlap
extern int overlapPixelAreaCountTrack; //Overlap pix area
extern int overlapPixelIntensityCountTrack; //Overlap pix intensity
extern int overlapPercentCountTrack; //Overlap percent
extern int noMergeTableCountTrack; //No merge table count
extern int noMergeTableLimitTrack; //No merge table limit

//-------Interpretation--------
extern int statusAdditionalInfo; //Additional status info
extern int *arrayPartnerInfo; //Connect Partners
extern int partnerInfoCount;

//========arrayCellTrackingTable==========
//1.Round number
//2.Image number
//3.Connect number (for tracking, not same with connect no of master database)
//4.X position
//5.Y position
//6.Area
//7.Intensity
//8.Target [0: non-target, 1: Target]
//9.Mitosis Status [0. Non mitosis, 1. Mitosis high, 2. Mitosis low, 3. Cell death, high, 4. Cell death, low, 5. Mitosis Final, 6, Mitosis very high, 7. Debris, 8. cell death final, 10. mitosis send to Tracking, 11. cell death send to Tracking]
//10.Divide/Fuse/Check
//   -1: Fusion (end);
//   -2: W Mark;
//   -3, W Mark (Fusion partner found);
//   -4, Multiple fusion ends;
//   2,3,4,5: Cell Division;
//   60: No space before cell division;
//   10: Cell death;
//   1000: Recheck IP;
//   1001: Recheck MitosisClear;
//   1002: Recheck Mitosis/Cell Death;
//   1003: Cell debris;
//   1004: Recheck cell death clear;
//   1005: Recheck cell death;
//   1006: Recheck cell divi after mitosis;
//   1007: Recheck Div (no mitosis found);
//   1008: Check Lost or Fuse End (will be determined by area cut);
//   1009: Fusion check-multiple Cells;
//   1010: LineageFuse-redo;
//   1011: Tracking redo;
//   1012: Div cancel and redo;
//   100: Mitosis set
//   101: Mitosis Set fail
//   200: Out of frame
//11.Next1 [next connect no 1].
//12.Next2 [next connect no 2]
//13.Previous1 [prev connect no 1]
//14.Previous2 [prev connect no 2]
//15 Done [1,2,3,4,5...: First 10 continuity, 1001,1002,1003,1004,1005...: cell candidates, 2000: cell selected]

//-----TargetHoldFlag-------
//**-1: Fusion (end);
//**-2: W Mark;
//**-3, W Mark (Fusion partner found);
//**-4, Multiple fusion ends;
//**2: Cell Division;
//**3: Cell Division;
//**4: Cell Division;
//**5: Cell Division;
//**60: No space before cell division;
//**10: Cell death;
//**1000: Recheck IP;
//**1001: Recheck MitosisClear;
//**1002: Recheck Mitosis/Cell Death;
//**1003: Cell debris;
//**1004: Recheck cell death clear;
//**1005: Recheck cell death;
//**1006: Recheck cell divi after mitosis;
//**1007: Recheck Div (no mitosis found);
//**1008: Check Lost or Fuse End (will be determined by area cut);
//**1009: Fusion check-multiple Cells;
//**1010: LineageFuse-redo;
//**1011: Tracking redo;
//**1012: Div cancel and redo;
//**100: Mitosis Set
//101: Mitosis Set fail
//**4000: Loading error;
//**3000: Target connect lost;
//**3002: Fusion area check;
//**3003: Fusion Position occupied
//**5000: No next outline data
//**200: Out of frame

//-----TargetHoldFlag Process Arrange-------
//0, -2, 100: Set Current and go next round
//-3: Fusion Set Current and go next round
//2, 3, 4, 5: Set Div and return
//10, 1000, 1001, 1002, 1003, 1004, 1005, 5000, 101: Set Current and return
//1008: After area check, set 3000 or -1 (counterpart find and fuse, return), or -4 (multiple fusion ends)
//1010: Lineage fuse redo (return)
//1011: Tracking redo, reset data to the round to restart
//1006, 1007, 1009, 4000, 3000, 3002, 3003: No current set and return

//--------Return messages---------
//**"TT"; Outline data-less than 10, returnMessage:TT, returnMessageTime:Current, returnMessageExt:0
//**"LE"; Loading error (UploadCount < 11), returnMessage:LE, returnMessageTime:Current, returnMessageExt:0
//**"MS"; No Mitosis Pattern Data, returnMessage:MS, returnMessageTime:0, returnMessageExt:0
//**"AM"; Amend line Missing, returnMessage:AM, returnMessageTime:Current, returnMessageExt:0
//**"DD": Dipolar division (TargetHoldFlag = 2), returnMessage:DD, returnMessageTime:Current+1, returnMessageExt:0
//**"TD": Tripolar division (TargetHoldFlag = 3), returnMessage:TD, returnMessageTime:Current+1, returnMessageExt:0
//**"HD": Tetrapolar division (TargetHoldFlag = 4), returnMessage:HD, returnMessageTime:Current+1, returnMessageExt:0
//**"MD": Multipolar division (TargetHoldFlag = 5), returnMessage:MD, returnMessageTime:Current, returnMessageExt:0
//**"NS": No space before cell division (TargetHoldFlag = 60), returnMessage:NS, returnMessageTime:Current, returnMessageExt:0
//**"CD": Cell Death (TargetHoldFlag = 10), returnMessage:CD, returnMessageTime:CD set point, returnMessageExt:0
//**"IP": Impartial Mitosis (TargetHoldFlag = 1000), returnMessage:IP, returnMessageTime:Current+1, returnMessageExt:0
//**"MC": Mitosis clear (TargetHoldFlag = 1001), returnMessage:MC, returnMessageTime:Current+1, returnMessageExt:0
//**"AC": Mitosis/cell death need check (TargetHoldFlag = 1002), returnMessage:AC, returnMessageTime:Current+1, returnMessageExt:0
//**"DB": Cell debris (TargetHoldFlag = 1003), returnMessage:MD, returnMessageTime:Current+1, returnMessageExt:0
//**"RC": Check Cell Death, cell death is cleared (TargetHoldFlag = 1004), returnMessage:RC, returnMessageTime:Current+1, returnMessageExt:0
//**"SC": Check Cell Death (TargetHoldFlag = 1005), returnMessage:SC, returnMessageTime:Current+1, returnMessageExt:0
//**"CM": Check Division--One or more Div cell intensity Low (TargetHoldFlag = 1006), returnMessage:CM, returnMessageTime:Current, returnMessageExt:0
//**"CN": Check Division--no mitosis found (TargetHoldFlag = 1007), returnMessage:CN, returnMessageTime:Current, returnMessageExt:0
//**"FM": Check Fusion multiple cells (TargetHoldFlag = 1009), returnMessage:FM, returnMessageTime:Current, returnMessageExt:0
//**"RD": Lineage Fuse (TargetHoldFlag = 1010), returnMessage:FM, returnMessageTime:Current, returnMessageExt:Be fused cell lineage no
//**"TL": Target area lost (TargetHoldFlag = 3000), returnMessage:TL, returnMessageTime:Current, returnMessageExt:0
//**"TL": Target area lost: prev Lost:RoundStatus != 2 (TargetHoldFlag = 3500), returnMessage:TL, returnMessageTime:Current, returnMessageExt:0
//**"FE": Fusion Area lost (TargetHoldFlag = 3002), returnMessage:FE, returnMessageTime:Current, returnMessageExt:0
//**"FO": Fusion position occupied by other mark (TargetHoldFlag = 3003), returnMessage:FO, returnMessageTime:Current, returnMessageExt:0
//**"NX": Wait Next Outline data (TargetHoldFlag = 5000), returnMessage:NX, returnMessageTime:Current+1, returnMessageExt:0
//**"MF": Mitosis Set fail (TargetHoldFlag = 101), returnMessage:MF, returnMessageTime:Current+1, returnMessageExt:0
//**"NM": Wait Next Outline data + Mitosis Set fail (TargetHoldFlag = 5000+101), returnMessage:NM, returnMessageTime:Current+1, returnMessageExt:0
//**"DL": Cell Division Lost at Area cut, returnMessage:DL, returnMessageTime:Current, returnMessageExt:0
//**"OF": Out of frame (TargetHoldFlag = 1008, then 200), returnMessage:OF, returnMessageTime:Current, returnMessageExt:0
//**"FC": Cell Fusion End (TargetHoldFlag = 1008, then -1), returnMessage:FC, returnMessageTime:Current+1, returnMessageExt:0
//**"ME": Multiple Cell Fusion Ends Find (TargetHoldFlag = 1008, then -4), returnMessage:FC, returnMessageTime:Current, returnMessageExt:0
//**"CF": No overlapped segment (TargetHoldFlag = 4000, occurred after the first round), returnMessage:CF, returnMessageTime:Current, returnMessageExt:0
//**"CL": No overlapped segment (TargetHoldFlag = 4000, occurred at the first round), returnMessage:CL, returnMessageTime:Current, returnMessageExt:0
//**"RM": Mitosis was set at the outside of range (TargetHoldFlag = 100 and outsideFlag == 1), returnMessage:RM, returnMessageTime:0, returnMessageExt:Mitosis Position
//**"EX": When press Exit and no other warning is set, returnMessageTime:0, returnMessageExt:0
//**"IM": Image End Processed, returnMessage:IM, returnMessageTime:Current, returnMessageExt:0
//**"TM": Image End Processed, target lost, returnMessage:TM, returnMessageTime:Current, returnMessageExt:0

//*"arrayFusionPartner": Image no, Ling No, Cell No.

//=======arrayGroupInfoCurrent=======
//1. Group no: associated group, e.g. -1
//2. Entry round
//3. Link no

//=========arrayGroupInfoPrevious========
//1. Group no: associated group, e.g. -1
//2. Entry round
//3. Link no
//4. Mitosis status
//5. Done marks
//Created at the first Prev reading, then updated at the end pf each round by copying from the Current

//=========arrayCellGroupTable=========
//1. Round number
//2. Connect number
//3. Group number
//4. Group link
//Hold each round of connect/group info

//=========arrayMitosisParameter=========
//1. Lineage no
//2. Cell no
//3. Image no
//4. Status (1: mitosis likely, 2: mitosis probably, 3: cell death probably, 4: cell death likely, 5: Mitosis Determine, 6: mitosis very likely, 8: cell death determine)
//Entry from Cell tracking: 10: mitosis >> change to 5 >> change to 10 when back to Cell Tracking
//Cell death 8 >> change to 11 when back to cell tracking

//========Error=========
//1-200 new
//1000-2000 fin.open

@interface Controller : NSObject{
    int restartCount; //Count for restart
    int basicArrayStatus; //Array set status
    int backSaveOff; //Progress ON
    int backSaveCount; //Progress count
    
    IBOutlet NSTextField *timePoint;
    IBOutlet NSTextField *xPosition;
    IBOutlet NSTextField *yPosition;
    IBOutlet NSTextField *pixelNumberDisplay;
    IBOutlet NSTextField *mitosisStatusDisplay;
    IBOutlet NSTextField *analysisNameAuto;
    IBOutlet NSTextField *analysisIDAuto;
    IBOutlet NSTextField *treatNameAuto;
    IBOutlet NSTextField *cellLingNoAuto;
    IBOutlet NSTextField *cellNoAuto;
    IBOutlet NSWindow *controllerWindow;
    
    IBOutlet NSProgressIndicator *backSave;
    
    NSTimer *controllerTimer;
    
    id trackingSet;
    id tableInterpretation;
    id imageFileUpLoad;
    id tiffFileRead;
}

-(id)init;
-(void)dealloc;
-(void)userPathSet;
-(void)processControl;
-(void)fileHandlingUpDate;
-(void)processStopMain;

-(IBAction)processStopSub:(id)sender;

@end
