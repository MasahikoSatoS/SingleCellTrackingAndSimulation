//
//  TerminationMonitor.h
//  Cell_Carving
//
//  Created by Masahiko Sato on 2014-05-26.
//
//

#ifndef TERMINATIONMONITOR_H
#define TERMINATIONMONITOR_H
#import "Controller.h"
#endif

@interface TerminationMonitor : NSObject{
    NSTimer *commTimer;
}

-(id)init;
-(void)dealloc;
-(void)processControl;

@end
