//
// TargetPrev.mm
// cell_carving
//
// Created by Masahiko Sato on 13/06/04.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "TargetPrevious.h"

@implementation TargetPrevious

-(void)targetPreviousMain:(int)roundTwo{
    try{
        try{
            
            errorNoHold = 0;
            int errorCheckThrow = 0;
            subCompletionFlag2 = 1;
            
            int currentPairAddition = arrayCellTrackingCurrentAss [(cellTrackingCurrentAssCount/6-1)*6];
            
            //cout<<currentPairAddition<<" Addition"<<endl;
            
            //------connectivity map based on outline vector------
            int terminationFlagLoop = 1;
            int lineNumberPrevious2 = 0;
            int lineNumberCurrent2 = 0;
            int maxTargetEntry = 0;
            int targetPointer = 0;
            int additionCount = 0;
            int maxConnect = 0;
            int maxConnect2 = 0;
            int numberOfEntry = 0;
            int processTypeList [9];
            int currentMajorOriginal = 0;
            int majorStatus = 0;
            int processType = 0;
            int previousNumber1 = 0;
            int previousNumber2 = 0;
            int currentConnectNumber1 = 0; //------Current Identified (major or minor)------
            int currentConnectNumber2 = 0; //------Current Major, if Identified = Major, same with currentConnectNumber1------
            int currentConnectNumber3 = 0; //------Current Major2------
            int currentPositionA1 = 0;
            int currentPositionB1 = 0;
            int currentDimension1 = 0;
            int allocationResult = 0;
            int processPrevious1 = 0;
            int processPrevious2 = 0;
            int pairPrevious1 = 0;
            int pairPrevious2 = 0;
            int dimensionPrevious1 = 0;
            int dimensionPrevious2 = 0;
            int connectPreviousA1 = 0;
            int connectPreviousB1 = 0;
            int connectPreviousC1 = 0;
            int connectPreviousA2 = 0;
            int connectPreviousB2 = 0;
            int connectPreviousC2 = 0;
            int numberOfEntry2 = 0;
            int connectPreviousCountA1 = 0;
            int connectPreviousCountB1 = 0;
            int connectPreviousCountC1 = 0;
            int connectPreviousCountA2 = 0;
            int connectPreviousCountB2 = 0;
            int connectPreviousCountC2 = 0;
            int connectCurrentCountA1 = 0;
            int connectCurrentCountB1 = 0;
            int connectCurrentCountC1 = 0;
            int connectCurrentCountA2 = 0;
            int connectCurrentCountB2 = 0;
            int connectCurrentCountC2 = 0;
            int connectCurrentCountA3 = 0;
            int connectCurrentCountB3 = 0;
            int connectCurrentCountC3 = 0;
            int highSide = 0;
            int noReFusionFlag = 0;
            int attachCount = 0;
            int attachTemp = 0;
            int divisionCancelFlag = 0;
            int previousTableCountTemp = 0;
            int previousTotalCountTemp = 0;
            int previousAverageCountTemp = 0;
            int currentTableCountTemp = 0;
            int currentTotalCountTemp = 0;
            int currentAverageCountTemp = 0;
            int maxPointDimX = 0;
            int maxPointDimY = 0;
            int minPointDimX = 0;
            int minPointDimY = 0;
            int horizontalStart2 = 0;
            int verticalStart2 = 0;
            int dimensionTemp = 0;
            int horizontalLength = 0;
            int verticalLength = 0;
            int connectivityNumber = 0;
            int connectAnalysisCount = 0;
            int terminationFlag = 0;
            int connectAnalysisTempCount = 0;
            int xSource = 0;
            int ySource = 0;
            int insideFind = 0;
            int highSideNumber = 0;
            int startOrder = 0;
            int findFreePoint = 0;
            int extendConnectCount2 = 0;
            int connectNo = 0;
            int remainingCheck = 0;
            int connectPointNoCount1 = 0;
            int connectPointNoCount2 = 0;
            int prevPixelCount1 = 0;
            int prevPixelCount2 = 0;
            int gravityX1 = 0;
            int gravityY1 = 0;
            int gravityX2 = 0;
            int gravityY2 = 0;
            int cellTrackingCurrentTempCount = 0;
            int cellTrackingCurrentTempLimit = 0;
            int connectProcessNo = 0;
            int connectTemp2 = 0;
            int zeroFillFlag = 0;
            int largestConnect = 0;
            int largestConnectNo = 0;
            int xPositionTempStart = 0;
            int yPositionTempStart = 0;
            int lineSize = 0;
            int constructedLineCount = 0;
            int findFlag = 0;
            int gravityTempX = 0;
            int gravityTempY = 0;
            int currentPointLine1 = 0;
            int currentTotaLine1 = 0;
            int currentPointLine2 = 0;
            int currentTotaLine2 = 0;
            int currentAverageLine1 = 0;
            int currentAverageLine2 = 0;
            int typeSubArray = 0;
            int previousConnectNumberKeep = 0;
            int previousConnectNumberAdd = 0;
            int maxPairNumber = 0;
            int targetRoundCount = 0;
            int targetMitosisCount = 0;
            int previousPointLine1 = 0;
            int previousTotaLine1 = 0;
            int matchFlag = 0;
            int cellTrackingPreviousTempCount = 0;
            int groupInvert = 0;
            int entryCount = 0;
            
            double prevAverageLine1 = 0;
            
            string processNo1 = "";
            string processNo2 = "";
            
            do{
                
                if (terminationFlagLoop == 1){
                    terminationFlagLoop = 0;
                    
                    //------Current, Previous line number set------
                    lineNumberPrevious2 = cellTrackingPreviousAssCount/6;
                    lineNumberCurrent2 = cellTrackingCurrentAssCount/6;
                    maxTargetEntry = maxTargetEntryTrack;
                    targetPointer = targetPointerTrack;
                    
                    //------Overlap Table Set------
                    errorNoHold = 1;
                    int **overlapAreaTable = new int *[lineNumberPrevious2+5];
                    errorNoHold = 2;
                    int **overlapIntensityTable = new int *[lineNumberPrevious2+5];
                    errorNoHold = 3;
                    int **overlapPercentageTable = new int *[lineNumberPrevious2+5];
                    errorNoHold = 4;
                    int **overlapNumberTable = new int *[lineNumberPrevious2+5];
                    
                    for (int counter1 = 0; counter1 < lineNumberPrevious2+5; counter1++){
                        errorNoHold = 5;
                        overlapAreaTable [counter1] = new int [maxTargetEntry+1];
                        errorNoHold = 6;
                        overlapIntensityTable [counter1] = new int [maxTargetEntry+1];
                        errorNoHold = 7;
                        overlapPercentageTable [counter1] = new int [maxTargetEntry+1];
                        errorNoHold = 8;
                        overlapNumberTable [counter1] = new int [maxTargetEntry+1];
                    }
                    
                    for (int counterY = 1; counterY < lineNumberPrevious2+5; counterY++){
                        for (int counterX = 0; counterX < maxTargetEntry+1; counterX++){
                            overlapAreaTable [counterY][counterX] = 0;
                            overlapIntensityTable [counterY][counterX] = 0;
                            overlapPercentageTable [counterY][counterX] = 0;
                            overlapNumberTable [counterY][counterX] = 0;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < overlapPixelAreaCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelAreaTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapPixelAreaTrack "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < overlapPixelAreaCountTrack/3; counter1++){
                        overlapAreaTable [arrayOverlapPixelAreaTrack [counter1*3]][arrayOverlapPixelAreaTrack [counter1*3+1]] = arrayOverlapPixelAreaTrack [counter1*3+2];
                    }
                    
                    //for (int counterA = 0; counterA < overlapPixelIntensityCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelIntensityTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapPixelIntensityTrack"<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < overlapPixelIntensityCountTrack/3; counter1++){
                        overlapIntensityTable [arrayOverlapPixelIntensityTrack [counter1*3]][arrayOverlapPixelIntensityTrack [counter1*3+1]] = arrayOverlapPixelIntensityTrack [counter1*3+2];
                    }
                    
                    for (int counter1 = 0; counter1 < overlapPercentCountTrack/3; counter1++){
                        overlapPercentageTable [arrayOverlapPercentTrack [counter1*3]][arrayOverlapPercentTrack [counter1*3+1]] = arrayOverlapPercentTrack [counter1*3+2];
                    }
                    
                    for (int counter1 = 0; counter1 < overlapNumberCountTrack/3; counter1++){
                        overlapNumberTable [arrayOverlapNumberTrack [counter1*3]][arrayOverlapNumberTrack [counter1*3+1]] = arrayOverlapNumberTrack [counter1*3+2];
                    }
                    
                    //------Overlap Source------
                    errorNoHold = 9;
                    int **overlapSource = new int *[lineNumberPrevious2+5];
                    for (int counter1 = 0; counter1 < lineNumberPrevious2+5; counter1++){
                        errorNoHold = 10;
                        overlapSource [counter1] = new int [lineNumberCurrent2+5];
                    }
                    
                    for (int counterY = 0; counterY < lineNumberPrevious2+5; counterY++){
                        for (int counterX = 0; counterX < lineNumberCurrent2+5; counterX++) overlapSource [counterY][counterX] = 0;
                    }
                    
                    for (int counterY = 1; counterY < lineNumberPrevious2+1; counterY++){
                        for (int counterX = 0; counterX < maxTargetEntry; counterX++) overlapSource [counterY][overlapNumberTable [counterY][counterX]] = 1;
                    }
                    
                    //cout<<p_variablesSet ->_targetPointer<<" Target_Current"<<endl;
                    
                    //------Association Data Set------
                    errorNoHold = 11;
                    int **currentAssData = new int *[lineNumberCurrent2+5];
                    for (int counter1 = 0; counter1 < lineNumberCurrent2+5; counter1++){
                        errorNoHold = 12;
                        currentAssData [counter1] = new int [9];
                    }
                    
                    for (int counter1 = 1; counter1 < cellTrackingCurrentAssCount/6+1; counter1++){ //------If A connect is removed, Put "0" in the VECTOR NUMBER
                        if (arrayCellTrackingCurrentAss [(counter1-1)*6] != 0 && arrayCurrentTableTrack [arrayCellTrackingCurrentAss [(counter1-1)*6]*2+1] > 0) currentAssData [counter1][0] = arrayCellTrackingCurrentAss [(counter1-1)*6];
                        else currentAssData [counter1][0] = 0; //------Vector number------
                        
                        currentAssData [counter1][1] = arrayCellTrackingCurrentAss [(counter1-1)*6+1]; //------Process type------
                        currentAssData [counter1][2] = arrayCellTrackingCurrentAss [(counter1-1)*6+2]; //------Cut type------
                        currentAssData [counter1][3] = arrayCellTrackingCurrentAss [(counter1-1)*6+3]; //------Pair ------
                        currentAssData [counter1][4] = arrayCellTrackingCurrentAss [(counter1-1)*6+4]; //------Dimension------
                        currentAssData [counter1][5] = arrayCellTrackingCurrentAss [(counter1-1)*6+5]; //------Reserve------
                        currentAssData [counter1][6] = 0; //------Round------
                    }
                    
                    //for (int counter1 = 1; counter1 < lineNumberCurrent2+1; counter1++){
                    //	cout<<counter1<<" ConnNo "<<currentAssData [counter1][0]<<" Process "<<currentAssData [counter1*2+1]<<" Cut "<<currentAssData [counter1][2];
                    //    cout<<" Pair "<<currentAssData [counter1][3]<<" Dim "<<currentAssData [counter1][4]<<" Reserve "<<endl;
                    //    cout<<currentAssData [counter1][5]<<" Round "<<currentAssData [counter1][6]<<" ASSCur_Prev"<<endl;
                    //}
                    
                    errorNoHold = 13;
                    int **previousAssData = new int *[lineNumberPrevious2+5];
                    for (int counter1 = 0; counter1 < lineNumberPrevious2+5; counter1++){
                        errorNoHold = 14;
                        previousAssData [counter1] = new int [9];
                    }
                    
                    for (int counter1 = 1; counter1 < cellTrackingPreviousAssCount/6+1; counter1++){ //------If A connect is removed, Put "0" in the VECTOR NUMBER
                        previousAssData [counter1][0] = arrayCellTrackingPreviousAss [(counter1-1)*6]; //------Vector number------
                        previousAssData [counter1][1] = arrayCellTrackingPreviousAss [(counter1-1)*6+1]; //------Process type------
                        previousAssData [counter1][2] = arrayCellTrackingPreviousAss [(counter1-1)*6+2]; //------Cut type------
                        previousAssData [counter1][3] = arrayCellTrackingPreviousAss [(counter1-1)*6+3]; //------Pair ------
                        previousAssData [counter1][4] = arrayCellTrackingPreviousAss [(counter1-1)*6+4]; //------Dimension------
                        previousAssData [counter1][5] = arrayCellTrackingPreviousAss [(counter1-1)*6+5]; //------Reserve------
                        previousAssData [counter1][6] = 0; //------Round------
                    }
                    
                    //for (int counter1 = 1; counter1 < lineNumberPrevious2+1; counter1++){
                    //    cout<<counter1<<" ConnNo "<<previousAssData [counter1][0]<<" Process "<<previousAssData [counter1][1]<<" Cut "<<previousAssData [counter1][2];
                    //    cout<<" Pair "<<previousAssData [counter1][3]<<" Dim "<<previousAssData [counter1][4]<<" Reserve ";
                    //    cout<<previousAssData [counter1][5]<<" Round "<<previousAssData [counter1][6]<<" ASSPrev_Prev"<<endl;
                    //}
                    
                    //------Gravity Info Just for Display------
                    //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
                    //	cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < xyPositionCenterPrevCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrev [counterA*6+counterB];
                    //	cout<<" arrayXYPositionCenterPrev "<<counterA<<endl;
                    //}
                    
                    //------Group Table Previous------
                    errorNoHold = 15;
                    int *groupTablePrevious = new int [groupInfoPreviousCount+50];
                    
                    for (int counter1 = 0; counter1 < groupInfoPreviousCount; counter1++) groupTablePrevious[counter1] = arrayGroupInfoPrevious [counter1];
                    
                    //for (int counterA = 0; counterA < groupInfoPrevCount/5; counterA++){
                    //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayGroupInfoPrevious [counterA*5+counterB];
                    //	cout<<" arrayGroupInfoPrevious "<<counterA<<endl;
                    //}
                    
                    //------Main Process------
                    additionCount = 0;
                    maxConnect = 0;
                    maxConnect2 = 0;
                    
                    for (int counterY = 0; counterY < trackAreaSize; counterY++){
                        for (int counterX = 0; counterX < trackAreaSize; counterX++){
                            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                if (connectMapA [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect) maxConnect = connectMapA [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                if (connectMapB [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect) maxConnect = connectMapB [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                if (connectMapC [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect) maxConnect = connectMapC [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                if (connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect2) maxConnect2 = connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                if (connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect2) maxConnect2 = connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                if (connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect2) maxConnect2 = connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                            }
                        }
                    }
                    
                    errorNoHold = 16;
                    int *connectPrevTempA1 = new int [maxConnect+5];
                    errorNoHold = 17;
                    int *connectPrevTempB1 = new int [maxConnect+5];
                    errorNoHold = 18;
                    int *connectPrevTempC1 = new int [maxConnect+5];
                    errorNoHold = 19;
                    int *connectPrevTempA2 = new int [maxConnect+5];
                    errorNoHold = 20;
                    int *connectPrevTempB2 = new int [maxConnect+5];
                    errorNoHold = 21;
                    int *connectPrevTempC2 = new int [maxConnect+5];
                    errorNoHold = 22;
                    int *connectCurrentTempA1 = new int [maxConnect2+5];
                    errorNoHold = 23;
                    int *connectCurrentTempB1 = new int [maxConnect2+5];
                    errorNoHold = 24;
                    int *connectCurrentTempC1 = new int [maxConnect2+5];
                    errorNoHold = 25;
                    int *connectCurrentTempA2 = new int [maxConnect2+5];
                    errorNoHold = 26;
                    int *connectCurrentTempB2 = new int [maxConnect2+5];
                    errorNoHold = 27;
                    int *connectCurrentTempC2 = new int [maxConnect2+5];
                    errorNoHold = 28;
                    int *connectCurrentTempA3 = new int [maxConnect2+5];
                    errorNoHold = 29;
                    int *connectCurrentTempB3 = new int [maxConnect2+5];
                    errorNoHold = 30;
                    int *connectCurrentTempC3 = new int[maxConnect2+5];
                    
                    for (int counter1 = 1; counter1 < lineNumberPrevious2+1; counter1++){
                        numberOfEntry = 0;
                        
                        for (int counter2 = 0; counter2 < maxTargetEntry; counter2++){
                            if (overlapNumberTable [counter1][counter2] > 0) numberOfEntry++;
                        }
                        
                        if (numberOfEntry > 0){
                            processTypeList [0] = 0;
                            processTypeList [1] = 0;
                            processTypeList [2] = 0;
                            processTypeList [3] = 0;
                            processTypeList [4] = 0;
                            processTypeList [5] = 0;
                            processTypeList [6] = 0;
                            processTypeList [7] = 0;
                            processTypeList [8] = 0;
                            currentMajorOriginal = overlapNumberTable [counter1][0];
                            
                            if (currentMajorOriginal != 0){
                                for (int counter2 = 0; counter2 < maxTargetEntry; counter2++){
                                    majorStatus = 0;
                                    
                                    if (counter2 == 0) majorStatus = 1;
                                    
                                    for (int counter3 = 1; counter3 < lineNumberPrevious2+1; counter3++){
                                        if (counter1 != counter3){
                                            for (int counter4 = 0; counter4 < maxTargetEntry; counter4++){
                                                if (overlapNumberTable [counter3][counter4] != 0){
                                                    if (counter4 == 0 && majorStatus == 1 && overlapNumberTable [counter1][counter2] == overlapNumberTable [counter3][counter4]){
                                                        processTypeList [0] = 1; //------Major/Major------
                                                        processTypeList [1] = overlapNumberTable [counter1][counter2]; //------Current number------
                                                        processTypeList [2] = 0; //------Current position1------
                                                        processTypeList [3] = 0; //------Current position2------
                                                        processTypeList [4] = overlapNumberTable [counter1][counter2]; //------Major number1------
                                                        processTypeList [5] = 0; //------Major position1------
                                                        processTypeList [6] = overlapNumberTable [counter1][counter2]; //------Major number2------
                                                        processTypeList [7] = 0; //------Major position2------
                                                        processTypeList [8] = counter3; //------Previous Number2------
                                                    }
                                                    if (counter4 != 0 && majorStatus == 1 && overlapNumberTable [counter1][counter2] == overlapNumberTable [counter3][counter4] && processTypeList [0] != 1){
                                                        processTypeList [0] = 2; //------Major/Minor------
                                                        processTypeList [1] = overlapNumberTable [counter1][counter2];
                                                        processTypeList [2] = 0;
                                                        processTypeList [3] = counter4;
                                                        processTypeList [4] = overlapNumberTable [counter1][counter2];
                                                        processTypeList [5] = 0;
                                                        processTypeList [6] = overlapNumberTable [counter3][0];
                                                        processTypeList [7] = 0;
                                                        processTypeList [8] = counter3;
                                                    }
                                                    if (counter4 != 0 && majorStatus == 0 && overlapNumberTable [counter1][counter2] == overlapNumberTable [counter3][counter4] && processTypeList [0] != 1 && processTypeList [0] != 2){
                                                        processTypeList [0] = 3; //------Minor/Minor------
                                                        processTypeList [1] = overlapNumberTable [counter1][counter2];
                                                        processTypeList [2] = counter2;
                                                        processTypeList [3] = counter4;
                                                        processTypeList [4] = overlapNumberTable [counter1][0];
                                                        processTypeList [5] = 0;
                                                        processTypeList [6] = overlapNumberTable [counter3][0];
                                                        processTypeList [7] = 0;
                                                        processTypeList [8] = counter3;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                //cout<<" Type" <<processTypeList [0]<<" CurNo "<<processTypeList [1]<<" CurrPost1 "<<processTypeList [2]<<" CurPost2 "<<processTypeList [3]<<endl;
                                //cout<<" Major1 "<<processTypeList [4]<<" MajorPost1"<<processTypeList [5]<<" Major2 "<<processTypeList [6]<<" MajorPost2 "<<endl;
                                //cout<<processTypeList [7]<<" PrevNo2 "<<processTypeList [8]<<" ProcessTypeList"<<endl;
                                
                                if (processTypeList [0] != 0){
                                    processType = processTypeList [0];
                                    previousNumber1 = counter1;
                                    previousNumber2 = processTypeList [8];
                                    
                                    currentConnectNumber1 = processTypeList [1]; //------Current Identified (major or minor)------
                                    currentConnectNumber2 = processTypeList [4]; //------Current Major, if Identified = Major, same with currentConnectNumber1------
                                    currentConnectNumber3 = processTypeList [6]; //------Current Major2------
                                    currentPositionA1 = processTypeList [2];
                                    currentPositionB1 = processTypeList [3];
                                    currentDimension1 = currentAssData [currentConnectNumber1][4];
                                    
                                    //cout<<" PrevNo1 "<<previousNumber1<<" PrevNo2 "<<previousNumber2<<" CurNo1 "<<currentConnectNumber1<<" CurNo2 "<<currentConnectNumber2<<endl;
                                    //cout<<" CurNo3 "<<currentConnectNumber3<<" CurPosition1 "<<currentPositionA1<<" CurPosition2 "<<currentPositionB1<<" Prev_Cur_No"<<endl;
                                    
                                    allocationResult = 0;
                                    processPrevious1 = previousAssData [previousNumber1][1];
                                    processPrevious2 = previousAssData [previousNumber2][1];
                                    pairPrevious1 = previousAssData [previousNumber1][3];
                                    pairPrevious2 = previousAssData [previousNumber2][3];
                                    dimensionPrevious1 = previousAssData [previousNumber1][4];
                                    dimensionPrevious2 = previousAssData [previousNumber2][4];
                                    
                                    //cout<<" ProcessPrev1 "<<processPrevious1<<" ProcessPrev2 "<<processPrevious2<<" PairPrev1 "<<pairPrevious1<<" PairPrev2 "<<pairPrevious2<<endl;
                                    //cout<<" DimPrev1 "<<dimensionPrevious1<<" DimPrev2 "<<dimensionPrevious2<<endl;
                                    
                                    connectPreviousA1 = 0;
                                    connectPreviousB1 = 0;
                                    connectPreviousC1 = 0;
                                    connectPreviousA2 = 0;
                                    connectPreviousB2 = 0;
                                    connectPreviousC2 = 0;
                                    
                                    for (int counter2 = 0; counter2 < maxConnect+1; counter2++){
                                        connectPrevTempA1 [counter2] = 0;
                                        connectPrevTempB1 [counter2] = 0;
                                        connectPrevTempC1 [counter2] = 0;
                                        connectPrevTempA2 [counter2] = 0;
                                        connectPrevTempB2 [counter2] = 0;
                                        connectPrevTempC2 [counter2] = 0;
                                    }
                                    
                                    numberOfEntry2 = 0;
                                    
                                    for (int counter2 = 0; counter2 < maxTargetEntry; counter2++){
                                        if (overlapNumberTable [previousNumber2][counter2] > 0) numberOfEntry2++;
                                    }
                                    
                                    //------Make a list of connected numbers, Previous------
                                    for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                        for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                            if (arrayCellTrackingPreviousMap [counterY][counterX] == previousNumber1 && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapA [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                                connectPrevTempA1 [connectMapA [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]]++;
                                            }
                                            if (arrayCellTrackingPreviousMap [counterY][counterX] == previousNumber1 && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapB [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                                connectPrevTempB1 [connectMapB [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]]++;
                                            }
                                            if (arrayCellTrackingPreviousMap [counterY][counterX] == previousNumber1 && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapC [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                                connectPrevTempC1 [connectMapC [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]]++;
                                            }
                                            if (arrayCellTrackingPreviousMap [counterY][counterX] == previousNumber2 && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapA [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                                connectPrevTempA2 [connectMapA [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]]++;
                                            }
                                            if (arrayCellTrackingPreviousMap [counterY][counterX] == previousNumber2 && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapB [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                                connectPrevTempB2 [connectMapB [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]]++;
                                            }
                                            if (arrayCellTrackingPreviousMap [counterY][counterX] == previousNumber2 && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapC [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                                connectPrevTempC2 [connectMapC [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]]++;
                                            }
                                        }
                                    }
                                    
                                    //------Select Largest one------
                                    connectPreviousCountA1 = 0;
                                    connectPreviousCountB1 = 0;
                                    connectPreviousCountC1 = 0;
                                    connectPreviousCountA2 = 0;
                                    connectPreviousCountB2 = 0;
                                    connectPreviousCountC2 = 0;
                                    
                                    for (int counter2 = 1; counter2 < maxConnect+1; counter2++){
                                        if (connectPreviousCountA1 < connectPrevTempA1 [counter2]){
                                            connectPreviousA1 = counter2;
                                            connectPreviousCountA1 = connectPrevTempA1 [counter2];
                                        }
                                        if (connectPreviousCountB1 < connectPrevTempB1 [counter2]){
                                            connectPreviousB1 = counter2;
                                            connectPreviousCountB1 = connectPrevTempB1 [counter2];
                                        }
                                        if (connectPreviousCountC1 < connectPrevTempC1 [counter2]){
                                            connectPreviousC1 = counter2;
                                            connectPreviousCountC1 = connectPrevTempC1 [counter2];
                                        }
                                        if (connectPreviousCountA2 < connectPrevTempA2 [counter2]){
                                            connectPreviousA2 = counter2;
                                            connectPreviousCountA2 = connectPrevTempA2 [counter2];
                                        }
                                        if (connectPreviousCountB2 < connectPrevTempB2 [counter2]){
                                            connectPreviousB2 = counter2;
                                            connectPreviousCountB2 = connectPrevTempB2 [counter2];
                                        }
                                        if (connectPreviousCountC2 < connectPrevTempC2 [counter2]){
                                            connectPreviousC2 = counter2;
                                            connectPreviousCountC2 = connectPrevTempC2 [counter2];
                                        }
                                    }
                                    
                                    //------Make a list of connected numbers, Cur------
                                    for (int counter2 = 0; counter2 < maxConnect2+1; counter2++){
                                        connectCurrentTempA1 [counter2] = 0;
                                        connectCurrentTempB1 [counter2] = 0;
                                        connectCurrentTempC1 [counter2] = 0;
                                        connectCurrentTempA2 [counter2] = 0;
                                        connectCurrentTempB2 [counter2] = 0;
                                        connectCurrentTempC2 [counter2] = 0;
                                        connectCurrentTempA3 [counter2] = 0;
                                        connectCurrentTempB3 [counter2] = 0;
                                        connectCurrentTempC3 [counter2] = 0;
                                    }
                                    
                                    for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                        for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                            if (arrayCellTrackingCurrentMap [counterY][counterX] == currentConnectNumber1 && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                                connectCurrentTempA1 [connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]]++;
                                            }
                                            if (arrayCellTrackingCurrentMap [counterY][counterX] == currentConnectNumber1 && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                                connectCurrentTempB1 [connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]]++;
                                            }
                                            if (arrayCellTrackingCurrentMap [counterY][counterX] == currentConnectNumber1 && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                                connectCurrentTempC1 [connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]]++;
                                            }
                                            if (arrayCellTrackingCurrentMap [counterY][counterX] == currentConnectNumber2 && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                                connectCurrentTempA2 [connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]]++;
                                            }
                                            if (arrayCellTrackingCurrentMap [counterY][counterX] == currentConnectNumber2 && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                                connectCurrentTempB2 [connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]]++;
                                            }
                                            if (arrayCellTrackingCurrentMap [counterY][counterX] == currentConnectNumber2 && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                                connectCurrentTempC2 [connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]]++;
                                            }
                                            if (arrayCellTrackingCurrentMap [counterY][counterX] == currentConnectNumber3 && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                                connectCurrentTempA3 [connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]]++;
                                            }
                                            if (arrayCellTrackingCurrentMap [counterY][counterX] == currentConnectNumber3 && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                                connectCurrentTempB3 [connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]]++;
                                            }
                                            if (arrayCellTrackingCurrentMap [counterY][counterX] == currentConnectNumber3 && counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                                connectCurrentTempC3 [connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]]++;
                                            }
                                        }
                                    }
                                    
                                    //------Select Largest one------
                                    connectCurrentCountA1 = 0;
                                    connectCurrentCountB1 = 0;
                                    connectCurrentCountC1 = 0;
                                    connectCurrentCountA2 = 0;
                                    connectCurrentCountB2 = 0;
                                    connectCurrentCountC2 = 0;
                                    connectCurrentCountA3 = 0;
                                    connectCurrentCountB3 = 0;
                                    connectCurrentCountC3 = 0;
                                    
                                    for (int counter2 = 1; counter2 < maxConnect2+1; counter2++){
                                        if (connectCurrentCountA1 < connectCurrentTempA1 [counter2]) connectCurrentCountA1 = connectCurrentTempA1 [counter2];
                                        if (connectCurrentCountB1 < connectCurrentTempB1 [counter2]) connectCurrentCountB1 = connectCurrentTempA1 [counter2];
                                        if (connectCurrentCountC1 < connectCurrentTempC1 [counter2]) connectCurrentCountC1 = connectCurrentTempA1 [counter2];
                                        if (connectCurrentCountA2 < connectCurrentTempA2 [counter2]) connectCurrentCountA2 = connectCurrentTempA1 [counter2];
                                        if (connectCurrentCountB2 < connectCurrentTempB2 [counter2]) connectCurrentCountB2 = connectCurrentTempA1 [counter2];
                                        if (connectCurrentCountC2 < connectCurrentTempC2 [counter2]) connectCurrentCountC2 = connectCurrentTempA1 [counter2];
                                        if (connectCurrentCountA3 < connectCurrentTempA3 [counter2]) connectCurrentCountA3 = connectCurrentTempA1 [counter2];
                                        if (connectCurrentCountB3 < connectCurrentTempB3 [counter2]) connectCurrentCountB3 = connectCurrentTempA1 [counter2];
                                        if (connectCurrentCountC3 < connectCurrentTempC3 [counter2]) connectCurrentCountC3 = connectCurrentTempA1 [counter2];
                                    }
                                    
                                    //cout<<" PreA1 "<<connectPreviousA1<<" PreB1 "<<connectPreviousB1<<" PreC1 "<<connectPreviousC1<<endl;
                                    //cout<<" PreA2 "<<connectPreviousA2<<" PreB2 "<<connectPreviousB2<<" PreC2 "<<connectPreviousC2<<endl;
                                    //cout<<" CurA1 "<<connectCurrentCountA1<<" CurB1 "<<connectCurrentCountB1<<" CurC1 "<<connectCurrentCountC1<<endl;
                                    //cout<<" CurA2 "<<connectCurrentCountA2<<" CurB2 "<<connectCurrentCountB2<<" CurC3 "<<connectCurrentCountC2<<endl;
                                    //cout<<" CurA3 "<<connectCurrentCountA3<<" CurB3 "<<connectCurrentCountB3<<" CurC3 "<<connectCurrentCountC3<<endl;
                                    
                                    //------Process Type 3------
                                    processNo1 = "";
                                    
                                    if (processType == 3){
                                        if (pairPrevious1 != 0 && pairPrevious2 != 0){
                                            if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff3){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*0.7 > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2;
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1]*0.7 <= overlapAreaTable [previousNumber2][currentPositionB1] && overlapAreaTable [previousNumber1][currentPositionA1]*0.3 > overlapAreaTable [previousNumber2][currentPositionB1]){
                                                    if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100){
                                                        if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 3, processNo1 = "C3_111";
                                                        else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 2, processNo1 = "C3_112";
                                                        else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                            if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C3_113";
                                                            else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C3_114";
                                                            else if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_114.1";
                                                            else allocationResult = 1, processNo1 = "C3_115";
                                                        }
                                                        else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 4, processNo1 = "C3_116";
                                                    }
                                                    else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= 100){
                                                        if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50){
                                                            if (roundTwo == 2) allocationResult = 3, processNo1 = "C3_117";
                                                            else allocationResult = 1, processNo1 = "C3_118";
                                                        }
                                                        else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                            if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_119";
                                                            else allocationResult = 1, processNo1 = "C3_120";
                                                        }
                                                        else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                            if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C3_121";
                                                            else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C3_122";
                                                            else if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_122.1";
                                                            else allocationResult = 1, processNo1 = "C3_123";
                                                        }
                                                        else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 4, processNo1 = "C3_124";
                                                    }
                                                }
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1]*0.3 <= overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C3_125";
                                            }
                                            else if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff3){
                                                if (overlapIntensityTable [previousNumber1][currentPositionA1] > cutOff3 && overlapIntensityTable [previousNumber2][currentPositionB1] > cutOff3){
                                                    if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100){
                                                        if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 3, processNo1 = "C3_126";
                                                        else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 2, processNo1 = "C3_127";
                                                        else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                            if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C3_128";
                                                            else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C3_129";
                                                            else if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_129.1";
                                                            else allocationResult = 1, processNo1 = "C3_130";
                                                        }
                                                        else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 4, processNo1 = "C3_131";
                                                    }
                                                    else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= 100){
                                                        if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50){
                                                            if (roundTwo == 2) allocationResult = 3, processNo1 = "C3_132";
                                                            else allocationResult = 1, processNo1 = "C3_133";
                                                        }
                                                        else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                            if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_134";
                                                            else allocationResult = 1, processNo1 = "C3_135";
                                                        }
                                                        else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                            if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C3_136";
                                                            else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C3_137";
                                                            else if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_137.1";
                                                            else allocationResult = 1, processNo1 = "C3_138";
                                                        }
                                                        else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 4, processNo1 = "C3_139";
                                                    }
                                                }
                                                else if (overlapIntensityTable [previousNumber1][currentPositionA1] > cutOff3 && overlapIntensityTable [previousNumber2][currentPositionB1] <= cutOff3){
                                                    if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100){
                                                        if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff3) allocationResult = 2, processNo1 = "C3_140";
                                                        else allocationResult = 3, processNo1 = "C3_141";
                                                    }
                                                    else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= 100){
                                                        if (arrayCurrentAverageTrack [currentConnectNumber1] >= cutOff3){
                                                            if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 2, processNo1 = "C3_142";
                                                            else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 2, processNo1 = "C3_143";
                                                            else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 2, processNo1 = "C3_144";
                                                            else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 4, processNo1 = "C3_145";
                                                        }
                                                        else{
                                                            
                                                            if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 3, processNo1 = "C3_146";
                                                            else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 2, processNo1 = "C3_147";
                                                            else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                                if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C3_148";
                                                                else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C3_149";
                                                                else if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_149.1";
                                                                else allocationResult = 1, processNo1 = "C3_150";
                                                            }
                                                            else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 5, processNo1 = "C3_151";
                                                        }
                                                    }
                                                }
                                                else if (overlapIntensityTable [previousNumber1][currentPositionA1] <= cutOff3 && overlapIntensityTable [previousNumber2][currentPositionB1] > cutOff3){
                                                    if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100){
                                                        if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff3) allocationResult = 3, processNo1 = "C3_152";
                                                        else allocationResult = 2, processNo1 = "C3_153";
                                                    }
                                                    else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= 100){
                                                        if (arrayCurrentAverageTrack [currentConnectNumber1] >= cutOff3){
                                                            if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 3, processNo1 = "C3_154";
                                                            else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 3, processNo1 = "C3_155";
                                                            else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 3, processNo1 = "C3_156";
                                                            else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 4, processNo1 = "C3_157";
                                                        }
                                                        else{
                                                            
                                                            if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 2, processNo1 = "C3_158";
                                                            else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 3, processNo1 = "C3_159";
                                                            else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                                if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C3_160";
                                                                else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C3_161";
                                                                else if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_161.1";
                                                                else allocationResult = 1, processNo1 = "C3_162";
                                                            }
                                                            else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 5, processNo1 = "C3_163";
                                                        }
                                                    }
                                                }
                                                else if (overlapIntensityTable [previousNumber1][currentPositionA1] <= cutOff3 && overlapIntensityTable [previousNumber1][currentPositionA1] > cutOff4 && overlapIntensityTable [previousNumber2][currentPositionB1] <= cutOff3 && overlapIntensityTable [previousNumber2][currentPositionB1] > cutOff4){
                                                    if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100){
                                                        if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 3, processNo1 = "C3_164";
                                                        else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 2, processNo1 = "C3_165";
                                                        else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                            if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C3_166";
                                                            else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C3_167";
                                                            else if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_167.1";
                                                            else allocationResult = 1, processNo1 = "C3_168";
                                                        }
                                                        else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 4, processNo1 = "C3_169";
                                                    }
                                                    else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= 100){
                                                        if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50){
                                                            if (roundTwo == 2) allocationResult = 3, processNo1 = "C3_170";
                                                            else allocationResult = 1, processNo1 = "C3_171";
                                                        }
                                                        else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                            if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_172";
                                                            else allocationResult = 1, processNo1 = "C3_173";
                                                        }
                                                        else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                            if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C3_174";
                                                            else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C3_175";
                                                            else if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_175.1";
                                                            else allocationResult = 1, processNo1 = "C3_176";
                                                        }
                                                        else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 4, processNo1 = "C3_177";
                                                    }
                                                }
                                                else if (overlapIntensityTable [previousNumber1][currentPositionA1] <= cutOff4 && overlapIntensityTable [previousNumber2][currentPositionB1] <= cutOff4) allocationResult = 6, processNo1 = "C3_178";
                                            }
                                        }
                                        else if (pairPrevious1 != 0 && pairPrevious2 == 0){
                                            if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff3) allocationResult = 2, processNo1 = "C3_179";
                                            if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff3){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*0.5 >= overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo1 = "C3_180";
                                                else allocationResult = 3, processNo1 = "C3_181";
                                            }
                                        }
                                        else if (pairPrevious1 == 0 && pairPrevious2 != 0){
                                            if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff3){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*0.5 >= overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo1 = "C3_182";
                                                else allocationResult = 3, processNo1 = "C3_183";
                                            }
                                            if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff3) allocationResult = 2, processNo1 = "C3_184";
                                        }
                                        else if (pairPrevious1 == 0 && pairPrevious2 == 0){
                                            if (connectPreviousA1 != 0 && connectPreviousA2 != 0){
                                                if (connectPreviousA1 == connectPreviousA2){
                                                    if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff3) allocationResult = 6, processNo1 = "C3_185";
                                                    else if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff3){
                                                        if (overlapAreaTable [previousNumber1][currentPositionA1]*0.7 > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo1 = "C3_186";
                                                        else if (overlapAreaTable [previousNumber1][currentPositionA1]*0.7 <= overlapAreaTable [previousNumber2][currentPositionB1] && overlapAreaTable [previousNumber1][currentPositionA1]*0.3 > overlapAreaTable [previousNumber2][currentPositionB1]){
                                                            if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100){
                                                                if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 3, processNo1 = "C3_187";
                                                                else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 2, processNo1 = "C3_188";
                                                                else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C3_189";
                                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C3_190";
                                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_190.1";
                                                                    else allocationResult = 1, processNo1 = "C3_191";
                                                                }
                                                                else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 4, processNo1 = "C3_192";
                                                            }
                                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= 100){
                                                                if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50){
                                                                    if (roundTwo == 2) allocationResult = 3, processNo1 = "C3_193";
                                                                    else allocationResult = 1, processNo1 = "C3_194";
                                                                }
                                                                else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                                    if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_195";
                                                                    else allocationResult = 1, processNo1 = "C3_196";
                                                                }
                                                                else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C3_197";
                                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C3_198";
                                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_198.1";
                                                                    else allocationResult = 1, processNo1 = "C3_199";
                                                                }
                                                                else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 4, processNo1 = "C3_200";
                                                            }
                                                        }
                                                        else if (overlapAreaTable [previousNumber1][currentPositionA1]*0.3 <= overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C3_201";
                                                    }
                                                }
                                                if (connectPreviousA1 != connectPreviousA2){
                                                    if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff3){
                                                        if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff2){
                                                            if (overlapAreaTable [previousNumber1][currentPositionA1]*0.5 >= overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo1 = "C3_202";
                                                            else allocationResult = 3, processNo1 = "C3_203";
                                                        }
                                                        else allocationResult = 6, processNo1 = "C3_204";
                                                    }
                                                    else if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff3){
                                                        if (overlapAreaTable [previousNumber1][currentPositionA1]*0.7 > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo1 = "C3_205";
                                                        else if (overlapAreaTable [previousNumber1][currentPositionA1]*0.7 <= overlapAreaTable [previousNumber2][currentPositionB1] && overlapAreaTable [previousNumber1][currentPositionA1]*0.3 > overlapAreaTable [previousNumber2][currentPositionB1]){
                                                            if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100){
                                                                if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 3, processNo1 = "C3_206";
                                                                else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 2, processNo1 = "C3_207";
                                                                else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 6, processNo1 = "C3_208";
                                                                else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 4, processNo1 = "C3_209";
                                                            }
                                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= 100){
                                                                if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 3, processNo1 = "C3_210";
                                                                else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 2, processNo1 = "C3_211";
                                                                else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 4, processNo1 = "C3_212";
                                                                else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 4, processNo1 = "C3_213";
                                                            }
                                                        }
                                                        else if (overlapAreaTable [previousNumber1][currentPositionA1]*0.3 <= overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C3_214";
                                                    }
                                                }
                                            }
                                            else if (connectPreviousA1 == 0 && connectPreviousA2 != 0){
                                                if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff3){
                                                    if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff2){
                                                        if (overlapAreaTable [previousNumber1][currentPositionA1]*0.5 >= overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo1 = "C3_215";
                                                        else allocationResult = 3, processNo1 = "C3_216";
                                                    }
                                                    else allocationResult = 3, processNo1 = "C3_217";
                                                }
                                                else if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff3){
                                                    if (overlapIntensityTable [previousNumber2][currentPositionB1] > cutOff3){
                                                        if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100) allocationResult = 2, processNo1 = "C3_218";
                                                        else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= 100){
                                                            if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 3, processNo1 = "C3_219";
                                                            else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 2, processNo1 = "C3_220";
                                                            else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                                if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C3_221";
                                                                else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C3_222";
                                                                else if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_222.1";
                                                                else allocationResult = 1, processNo1 = "C3_223";
                                                            }
                                                            else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 5, processNo1 = "C3_224";
                                                        }
                                                    }
                                                    if (overlapIntensityTable [previousNumber2][currentPositionB1] <= cutOff3){
                                                        if (overlapAreaTable [previousNumber1][currentPositionA1] >= overlapAreaTable [previousNumber2][currentPositionB1]*1.5) allocationResult = 2, processNo1 = "C3_225";
                                                        else allocationResult = 3, processNo1 = "C3_226";
                                                    }
                                                }
                                            }
                                            else if (connectPreviousA1 != 0 && connectPreviousA2 == 0){
                                                if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff3){
                                                    if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff2){
                                                        if (overlapAreaTable [previousNumber1][currentPositionA1]*0.5 >= overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo1 = "C3_227";
                                                        else allocationResult = 3, processNo1 = "C3_228";
                                                    }
                                                    else allocationResult = 2, processNo1 = "C3_229";
                                                }
                                                if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff3){
                                                    if (overlapIntensityTable [previousNumber1][currentPositionA1] > cutOff3){
                                                        if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100) allocationResult = 3, processNo1 = "C3_230";
                                                        else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= 100){
                                                            if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 2, processNo1 = "C3_231";
                                                            else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 3, processNo1 = "C3_232";
                                                            else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                                if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C3_233";
                                                                else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C3_234";
                                                                else if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_234.1";
                                                                else allocationResult = 1, processNo1 = "C3_235";
                                                            }
                                                            else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 5, processNo1 = "C3_236";
                                                        }
                                                    }
                                                    else if (overlapIntensityTable [previousNumber1][currentPositionA1] <= cutOff3){
                                                        if (overlapAreaTable [previousNumber1][currentPositionA1]*1.5 <= overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C3_237";
                                                        else allocationResult = 2, processNo1 = "C3_238";
                                                    }
                                                }
                                            }
                                            else if (connectPreviousA1 == 0 && connectPreviousA2 == 0){
                                                if (connectPreviousB1 != 0 && connectPreviousB2 != 0){
                                                    if (connectPreviousB1 == connectPreviousB2){
                                                        if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff3) allocationResult = 6, processNo1 = "C3_239";
                                                        else if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff3){
                                                            if (overlapAreaTable [previousNumber1][currentPositionA1]*0.7 > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo1 = "C3_240";
                                                            else if (overlapAreaTable [previousNumber1][currentPositionA1]*0.7 <= overlapAreaTable [previousNumber2][currentPositionB1] && overlapAreaTable [previousNumber1][currentPositionA1]*0.3 > overlapAreaTable [previousNumber2][currentPositionB1]){
                                                                if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100){
                                                                    if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 3, processNo1 = "C3_241";
                                                                    else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 2, processNo1 = "C3_242";
                                                                    else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C3_243";
                                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C3_244";
                                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_244.1";
                                                                        else allocationResult = 1, processNo1 = "C3_245";
                                                                    }
                                                                    else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 4, processNo1 = "C3_246";
                                                                }
                                                                else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= 100){
                                                                    if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50){
                                                                        if (roundTwo == 2) allocationResult = 3, processNo1 = "C3_247";
                                                                        else allocationResult = 1, processNo1 = "C3_248";
                                                                    }
                                                                    else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                                        if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_249";
                                                                        else allocationResult = 1, processNo1 = "C3_250";
                                                                    }
                                                                    else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C3_251";
                                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C3_252";
                                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_252.1";
                                                                        else allocationResult = 1, processNo1 = "C3_253";
                                                                    }
                                                                    else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 4, processNo1 = "C3_254";
                                                                }
                                                            }
                                                            else if (overlapAreaTable [previousNumber1][currentPositionA1]*0.3 <= overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C3_255";
                                                        }
                                                    }
                                                    else if (connectPreviousB1 != connectPreviousB2){
                                                        if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff3) allocationResult = 6, processNo1 = "C3_256";
                                                        else if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff3){
                                                            if (overlapAreaTable [previousNumber1][currentPositionA1]*0.7 > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo1 = "C3_257";
                                                            else if (overlapAreaTable [previousNumber1][currentPositionA1]*0.7 <= overlapAreaTable [previousNumber2][currentPositionB1] && overlapAreaTable [previousNumber1][currentPositionA1]*0.3 > overlapAreaTable [previousNumber2][currentPositionB1]){
                                                                if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100){
                                                                    if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 3, processNo1 = "C3_258";
                                                                    else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 2, processNo1 = "C3_259";
                                                                    else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 6, processNo1 = "C3_260";
                                                                    else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 4, processNo1 = "C3_261";
                                                                }
                                                                else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= 100){
                                                                    if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 3, processNo1 = "C3_262";
                                                                    else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 2, processNo1 = "C3_263";
                                                                    else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 4, processNo1 = "C3_264";
                                                                    else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 4, processNo1 = "C3_265";
                                                                }
                                                            }
                                                            else if (overlapAreaTable [previousNumber1][currentPositionA1]*0.3 <= overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C3_266";
                                                        }
                                                    }
                                                }
                                                else if (connectPreviousB1 == 0 && connectPreviousB2 != 0){
                                                    if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff3) allocationResult = 3, processNo1 = "C3_267";
                                                    else if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff3){
                                                        if (overlapIntensityTable [previousNumber2][currentPositionB1] > cutOff3){
                                                            if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100) allocationResult = 2, processNo1 = "C3_268";
                                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= 100){
                                                                if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 3, processNo1 = "C3_269";
                                                                else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 2, processNo1 = "C3_270";
                                                                else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C3_271";
                                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C3_272";
                                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_272.1";
                                                                    else allocationResult = 1, processNo1 = "C3_273";
                                                                }
                                                                else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 5, processNo1 = "C3_274";
                                                            }
                                                        }
                                                        if (overlapIntensityTable [previousNumber2][currentPositionB1] <= cutOff3){
                                                            if (overlapAreaTable [previousNumber1][currentPositionA1] >= overlapAreaTable [previousNumber2][currentPositionB1]*1.5) allocationResult = 3, processNo1 = "C3_275";
                                                            else allocationResult = 2, processNo1 = "C3_276";
                                                        }
                                                    }
                                                }
                                                else if (connectPreviousB1 != 0 && connectPreviousB2 == 0){
                                                    if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff3) allocationResult = 2, processNo1 = "C3_277";
                                                    else if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff3){
                                                        if (overlapIntensityTable [previousNumber1][currentPositionA1] > cutOff3){
                                                            if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100) allocationResult = 2, processNo1 = "C3_278";
                                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= 100){
                                                                if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 3, processNo1 = "C3_279";
                                                                else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 2, processNo1 = "C3_280";
                                                                else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C3_281";
                                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C3_282";
                                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_282.1";
                                                                    else allocationResult = 1, processNo1 = "C3_283";
                                                                }
                                                                else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 5, processNo1 = "C3_284";
                                                            }
                                                        }
                                                        if (overlapIntensityTable [previousNumber1][currentPositionA1] <= cutOff3){
                                                            if (overlapAreaTable [previousNumber1][currentPositionA1]*1.5 <= overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C3_285";
                                                            else allocationResult = 2, processNo1 = "C3_286";
                                                        }
                                                    }
                                                }
                                                else if (connectPreviousB1 == 0 && connectPreviousB2 == 0){
                                                    if (connectPreviousC1 != 0 && connectPreviousC2 != 0){
                                                        if (connectPreviousC1 == connectPreviousC2){
                                                            if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff3) allocationResult = 6, processNo1 = "C3_287";
                                                            else if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff3){
                                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*0.7 > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2;
                                                                else if (overlapAreaTable [previousNumber1][currentPositionA1]*0.7 <= overlapAreaTable [previousNumber2][currentPositionB1] && overlapAreaTable [previousNumber1][currentPositionA1]*0.3 > overlapAreaTable [previousNumber2][currentPositionB1]){
                                                                    if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100){
                                                                        if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 3, processNo1 = "C3_288";
                                                                        else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 2, processNo1 = "C3_289";
                                                                        else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                                            if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C3_290";
                                                                            else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C3_291";
                                                                            else if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_291.1";
                                                                            else allocationResult = 1, processNo1 = "C3_292";
                                                                        }
                                                                        else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 4, processNo1 = "C3_293";
                                                                    }
                                                                    else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= 100){
                                                                        if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50){
                                                                            if (roundTwo == 2) allocationResult = 3, processNo1 = "C3_294";
                                                                            else allocationResult = 1, processNo1 = "C3_295";
                                                                        }
                                                                        else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                                            if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_296";
                                                                            else allocationResult = 1, processNo1 = "C3_297";
                                                                        }
                                                                        else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                                            if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C3_298";
                                                                            else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C3_299";
                                                                            else if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_299.1";
                                                                            else allocationResult = 1, processNo1 = "C3_300";
                                                                        }
                                                                        else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 4, processNo1 = "C3_301";
                                                                    }
                                                                }
                                                                else if (overlapAreaTable [previousNumber1][currentPositionA1]*0.3 <= overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C3_302";
                                                            }
                                                        }
                                                        else if (connectPreviousC1 != connectPreviousC2){
                                                            if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff3) allocationResult = 6, processNo1 = "C3_303";
                                                            else if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff3){
                                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*0.7 > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo1 = "C3_304";
                                                                else if (overlapAreaTable [previousNumber1][currentPositionA1]*0.7 <= overlapAreaTable [previousNumber2][currentPositionB1] && overlapAreaTable [previousNumber1][currentPositionA1]*0.3 > overlapAreaTable [previousNumber2][currentPositionB1]){
                                                                    if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100){
                                                                        if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 3, processNo1 = "C3_305";
                                                                        else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 2, processNo1 = "C3_306";
                                                                        else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 6, processNo1 = "C3_307";
                                                                        else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 4, processNo1 = "C3_308";
                                                                    }
                                                                    else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= 100){
                                                                        if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 3, processNo1 = "C3_309";
                                                                        else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 2, processNo1 = "C3_310";
                                                                        else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 4, processNo1 = "C3_311";
                                                                        else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 4, processNo1 = "C3_312";
                                                                    }
                                                                }
                                                                else if (overlapAreaTable [previousNumber1][currentPositionA1]*0.3 <= overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C3_313";
                                                            }
                                                        }
                                                    }
                                                    else if (connectPreviousC1 == 0 && connectPreviousC2 != 0){
                                                        if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff3) allocationResult = 3, processNo1 = "C3_314";
                                                        else if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff3){
                                                            if (overlapIntensityTable [previousNumber2][currentPositionB1] > cutOff3){
                                                                if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100) allocationResult = 2, processNo1 = "C3_315";
                                                                else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= 100){
                                                                    if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 3, processNo1 = "C3_316";
                                                                    else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 2, processNo1 = "C3_317";
                                                                    else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C3_319";
                                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C3_319";
                                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_319.1";
                                                                        else allocationResult = 1, processNo1 = "C3_320";
                                                                    }
                                                                    else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 5, processNo1 = "C3_321";
                                                                }
                                                            }
                                                            if (overlapIntensityTable [previousNumber2][currentPositionB1] <= cutOff3){
                                                                if (overlapAreaTable [previousNumber1][currentPositionA1] >= overlapAreaTable [previousNumber2][currentPositionB1]*1.5) allocationResult = 3, processNo1 = "C3_322";
                                                                else allocationResult = 2, processNo1 = "C3_323";
                                                            }
                                                        }
                                                    }
                                                    else if (connectPreviousC1 != 0 && connectPreviousC2 == 0){
                                                        if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff3) allocationResult = 2, processNo1 = "C3_324";
                                                        else if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff3){
                                                            if (overlapIntensityTable [previousNumber1][currentPositionA1] > cutOff3){
                                                                if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100) allocationResult = 2, processNo1 = "C3_325";
                                                                else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= 100){
                                                                    if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 3, processNo1 = "C3_326";
                                                                    else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] < 50) allocationResult = 2, processNo1 = "C3_327";
                                                                    else if (arrayPreviousTableTrack [previousNumber1*2] < 50 && arrayPreviousTableTrack [previousNumber2*2] < 50){
                                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C3_328";
                                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C3_329";
                                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C3_329.1";
                                                                        else allocationResult = 1, processNo1 = "C3_330";
                                                                    }
                                                                    else if (arrayPreviousTableTrack [previousNumber1*2] >= 50 && arrayPreviousTableTrack [previousNumber2*2] >= 50) allocationResult = 5, processNo1 = "C3_331";
                                                                }
                                                            }
                                                            else if (overlapIntensityTable [previousNumber1][currentPositionA1] <= cutOff3){
                                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*1.5 <= overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C3_332";
                                                                else allocationResult = 2, processNo1 = "C3_333";
                                                            }
                                                        }
                                                    }
                                                    else if (connectPreviousC1 == 0 && connectPreviousC2 == 0) allocationResult = 6, processNo1 = "C3_334";
                                                }
                                            }
                                        }
                                    }
                                    
                                    if (processType == 2){
                                        if (pairPrevious1 != 0 && pairPrevious2 != 0){
                                            if (pairPrevious1 == pairPrevious2){
                                                if (dimensionPrevious1 > 5 && dimensionPrevious2 > 5 && roundTwo == 1) allocationResult = 1, processNo1 = "C2_111";
                                                else allocationResult = 2;
                                            }
                                            else if (pairPrevious1 != pairPrevious2){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*0.5 <= overlapAreaTable [previousNumber2][currentPositionB1] && roundTwo == 1) allocationResult = 1, processNo1 = "C2_112";
                                                else allocationResult = 2, processNo1 = "C2_113";
                                            }
                                        }
                                        else if ((pairPrevious1 != 0 && pairPrevious2 == 0) || (pairPrevious1 == 0 && pairPrevious2 != 0)){
                                            if (overlapPercentageTable [previousNumber1][currentPositionA1] > 20 && overlapPercentageTable [previousNumber2][currentPositionB1] > 20 && roundTwo == 1) allocationResult = 1, processNo1 = "C2_114";
                                            else if (overlapAreaTable [previousNumber1][currentPositionA1]*0.5 <= overlapAreaTable [previousNumber2][currentPositionB1] && roundTwo == 1) allocationResult = 1, processNo1 = "C2_115";
                                            else allocationResult = 2, processNo1 = "C2_116";
                                        }
                                        else if (pairPrevious1 == 0 && pairPrevious2 == 0){
                                            if (processPrevious1 != 0 && processPrevious2 != 0){
                                                if (arrayPreviousTableTrack [previousNumber2*2] < 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C2_117";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1]*0.5 <= overlapAreaTable [previousNumber2][currentPositionB1] && roundTwo == 1) allocationResult = 1, processNo1 = "C2_118";
                                                else allocationResult = 2, processNo1 = "C2_119";
                                            }
                                            else if (processPrevious1 == 0 && processPrevious2 != 0){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*0.5 <= overlapAreaTable [previousNumber2][currentPositionB1] && roundTwo == 1) allocationResult = 1, processNo1 = "C2_120";
                                                else allocationResult = 2, processNo1 = "C2_121";
                                            }
                                            else if (processPrevious1 != 0 && processPrevious2 == 0){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*0.5 <= overlapAreaTable [previousNumber2][currentPositionB1] && roundTwo == 1) allocationResult = 1, processNo1 = "C2_122";
                                                else allocationResult = 2, processNo1 = "C2_123";
                                            }
                                            else if (connectPreviousA1 != 0 && connectPreviousA2 != 0){
                                                if (connectPreviousA1 == connectPreviousA2){
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C2_124";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C2_125";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C2_125.1";
                                                    else allocationResult = 1, processNo1 = "C2_126";
                                                }
                                                else if (connectPreviousA1 != connectPreviousA2){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1]*0.5 <= overlapAreaTable [previousNumber2][currentPositionB1] && roundTwo == 1) allocationResult = 1, processNo1 = "C2_127";
                                                    else allocationResult = 2, processNo1 = "C2_128";
                                                }
                                            }
                                            else if ((connectPreviousA1 != 0 && connectPreviousA2 == 0) || (connectPreviousA1 == 0 && connectPreviousA2 != 0)) allocationResult = 2, processNo1 = "C2_129";
                                            else if (connectPreviousA1 == 0 && connectPreviousA2 == 0){
                                                if (connectPreviousB1 != 0 && connectPreviousB2 != 0){
                                                    if (connectPreviousB1 == connectPreviousB2){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C2_130";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C2_131";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C2_131.1";
                                                        else allocationResult = 1, processNo1 = "C2_132";
                                                    }
                                                    else if (connectPreviousB1 != connectPreviousB2){
                                                        if (overlapAreaTable [previousNumber1][currentPositionA1]*0.5 <= overlapAreaTable [previousNumber2][currentPositionB1] && roundTwo == 1) allocationResult = 1, processNo1 = "C2_133";
                                                        else allocationResult = 2, processNo1 = "C2_134";
                                                    }
                                                }
                                                else if ((connectPreviousB1 != 0 && connectPreviousB2 == 0) || (connectPreviousB1 == 0 && connectPreviousB2 != 0)) allocationResult = 2, processNo1 = "C2_135";
                                                else if (connectPreviousB1 == 0 && connectPreviousB2 == 0){
                                                    if (connectPreviousC1 != 0 && connectPreviousC2 != 0){
                                                        if (connectPreviousC1 == connectPreviousC2){
                                                            if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C2_136";
                                                            else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C2_137";
                                                            else if (roundTwo == 2) allocationResult = 2, processNo1 = "C2_137.1";
                                                            else allocationResult = 1, processNo1 = "C2_138";
                                                        }
                                                        else if (connectPreviousC1 != connectPreviousC2){
                                                            if (overlapAreaTable [previousNumber1][currentPositionA1]*0.5 <= overlapAreaTable [previousNumber2][currentPositionB1] && roundTwo == 1) allocationResult = 1, processNo1 = "C2_139";
                                                            else allocationResult = 2, processNo1 = "C2_140";
                                                        }
                                                    }
                                                    else if ((connectPreviousC1 != 0 && connectPreviousC2 == 0) || (connectPreviousC1 == 0 && connectPreviousC2 != 0)){
                                                        if (overlapAreaTable [previousNumber1][currentPositionA1]*0.5 <= overlapAreaTable [previousNumber2][currentPositionB1] && roundTwo == 1) allocationResult = 1, processNo1 = "C2_141";
                                                        else allocationResult = 2, processNo1 = "C2_142";
                                                    }
                                                    else if (connectPreviousC1 == 0 && connectPreviousC2 == 0) allocationResult = 6, processNo1 = "C2_143";
                                                }
                                            }
                                        }
                                    }
                                    
                                    highSide = 0;
                                    
                                    if (processType == 1){
                                        if (arrayPreviousAverageTrack [previousNumber1] >= cutOff2 && arrayPreviousAverageTrack [previousNumber2] >= cutOff2){
                                            if (dimensionPrevious1 >= 5 && dimensionPrevious2 >= 5){
                                                if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_101";
                                                else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_102";
                                                else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_102.1";
                                                else allocationResult = 1, processNo1 = "C1_103";
                                            }
                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*1.5 < overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C1_104";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] >= overlapAreaTable [previousNumber2][currentPositionB1]*1.5) allocationResult = 2, processNo1 = "C1_105";
                                                else if (numberOfEntry == 1 && numberOfEntry2 > 1) allocationResult = 2, processNo1 = "C1_106";
                                                else if (numberOfEntry > 1 && numberOfEntry2 == 1) allocationResult = 3, processNo1 = "C1_107";
                                                else if ((numberOfEntry == 1 && numberOfEntry2 == 1) || (numberOfEntry > 1 && numberOfEntry2 > 1)){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo1 = "C1_108";
                                                    else allocationResult = 3, processNo1 = "C1_109";
                                                }
                                            }
                                            else if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff2){
                                                if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 80){
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_110";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_111";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_111.1";
                                                    else allocationResult = 1, processNo1 = "C1_112";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40){
                                                    if (overlapAreaTable [previousNumber2][currentPositionB1] >= 100 && roundTwo == 2) allocationResult = 1, processNo1 = "C1_113";
                                                    else if (overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50 && roundTwo == 2) allocationResult = 1, processNo1 = "C1_114";
                                                    else allocationResult = 2, processNo1 = "C1_115";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                    if (overlapAreaTable [previousNumber2][currentPositionB1] >= 100 && roundTwo == 2) allocationResult = 1, processNo1 = "C1_116";
                                                    else if (overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50 && roundTwo == 2) allocationResult = 1, processNo1 = "C1_117";
                                                    else allocationResult = 2, processNo1 = "C1_118";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 80){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 2) allocationResult = 1, processNo1 = "C1_119";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 2) allocationResult = 1, processNo1 = "C1_120";
                                                    else allocationResult = 3, processNo1 = "C1_121";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_122";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_123";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_123.1";
                                                        else allocationResult = 1, processNo1 = "C1_124";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                        if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_125";
                                                        else allocationResult = 1, processNo1 = "C1_126";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_127";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                        if (roundTwo == 2) allocationResult = 3, processNo1 = "C1_128";
                                                        else allocationResult = 1, processNo1 = "C1_129";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_130";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_131";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_131.1";
                                                        else allocationResult = 1, processNo1 = "C1_132";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_133";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100) allocationResult = 3, processNo1 = "C1_134";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50) allocationResult = 3, processNo1 = "C1_135";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_136";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_137";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_137.1";
                                                        else allocationResult = 1, processNo1 = "C1_138";
                                                    }
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                    if (overlapAreaTable [previousNumber2][currentPositionB1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_139";
                                                    else if (overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_140";
                                                    else allocationResult = 2, processNo1 = "C1_141";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 80){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_142";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] > 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_143";
                                                    else allocationResult = 3, processNo1 = "C1_144";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_145";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] > 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_146";
                                                    else allocationResult = 3, processNo1 = "C1_147";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_148";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_149";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_149.1";
                                                        else allocationResult = 1, processNo1 = "C1_150";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                        if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_151";
                                                        else allocationResult = 1, processNo1 = "C1_152";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_153";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                        if (roundTwo == 2) allocationResult = 3, processNo1 = "C1_154";
                                                        else allocationResult = 1, processNo1 = "C1_155";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_156";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_157";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_157.1";
                                                        else allocationResult = 1, processNo1 = "C1_158";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_159";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100) allocationResult = 3, processNo1 = "C1_160";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50) allocationResult = 3, processNo1 = "C1_161";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_162";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_163";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_163.1";
                                                        else allocationResult = 1, processNo1 = "C1_164";
                                                    }
                                                }
                                            }
                                            else if (arrayCurrentAverageTrack [currentConnectNumber1] < cutOff2 && arrayCurrentAverageTrack [currentConnectNumber1] >= cutOff4){
                                                if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapAreaTable [previousNumber2][currentPositionB1] >= 80){
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_165";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_166";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_166.1";
                                                    else allocationResult = 1, processNo1 = "C1_167";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40){
                                                    if (overlapAreaTable [previousNumber2][currentPositionB1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_168";
                                                    else if (overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_169";
                                                    else allocationResult = 2, processNo1 = "C1_170";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapAreaTable [previousNumber2][currentPositionB1] < 40){
                                                    if (overlapAreaTable [previousNumber2][currentPositionB1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_171";
                                                    else if (overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_172";
                                                    else allocationResult = 2, processNo1 = "C1_173";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapAreaTable [previousNumber2][currentPositionB1] >= 80){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_174";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_175";
                                                    else allocationResult = 3, processNo1 = "C1_176";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_177";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_178";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_178.1";
                                                        else allocationResult = 1, processNo1 = "C1_179";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                        if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_180";
                                                        else allocationResult = 1, processNo1 = "C1_181";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_182";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                        if (roundTwo == 2) allocationResult = 3, processNo1 = "C1_183";
                                                        else allocationResult = 1, processNo1 = "C1_184";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_185";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_186";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_186.1";
                                                        else allocationResult = 1, processNo1 = "C1_187";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_188";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100) allocationResult = 3, processNo1 = "C1_189";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50) allocationResult = 3, processNo1 = "C1_190";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_191";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_192";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_192.1";
                                                        else allocationResult = 1, processNo1 = "C1_193";
                                                    }
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                    if (overlapAreaTable [previousNumber2][currentPositionB1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_194";
                                                    else if (overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_195";
                                                    else allocationResult = 2, processNo1 = "C1_196";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapAreaTable [previousNumber2][currentPositionB1] >= 80){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_197";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_198";
                                                    else allocationResult = 3, processNo1 = "C1_199";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40 && overlapAreaTable [previousNumber2][currentPositionB1] < 80){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_200";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_201";
                                                    else allocationResult = 3, processNo1 = "C1_202";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_203";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_204";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_204.1";
                                                        else allocationResult = 1, processNo1 = "C1_205";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                        if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_206";
                                                        else allocationResult = 1, processNo1 = "C1_207";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_208";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                        if (roundTwo == 2) allocationResult = 3, processNo1 = "C1_209";
                                                        else allocationResult = 1, processNo1 = "C1_210";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_211";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_212";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_212.1";
                                                        else allocationResult = 1, processNo1 = "C1_213";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_214";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100) allocationResult = 3, processNo1 = "C1_215";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50) allocationResult = 3, processNo1 = "C1_216";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_217";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_218";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_218.1";
                                                        else allocationResult = 1, processNo1 = "C1_219";
                                                    }
                                                }
                                            }
                                            else if (arrayCurrentAverageTrack [currentConnectNumber1] < cutOff4){
                                                if (overlapIntensityTable [previousNumber1][currentPositionA1] < cutOff2 && overlapIntensityTable [previousNumber2][currentPositionB1] >= cutOff2) allocationResult = 3, processNo1 = "C1_220";
                                                else if (overlapIntensityTable [previousNumber1][currentPositionA1] >= cutOff2 && overlapIntensityTable [previousNumber2][currentPositionB1] < cutOff2) allocationResult = 2, processNo1 = "C1_221";
                                                else allocationResult = 6, processNo1 = "C1_222";
                                            }
                                        }
                                        else if (arrayPreviousAverageTrack [previousNumber1] >= cutOff2 && arrayPreviousAverageTrack [previousNumber2] < cutOff2 && arrayPreviousAverageTrack [previousNumber2] >= cutOff4){
                                            if (dimensionPrevious1 >= 5 && dimensionPrevious2 >= 5){
                                                if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_223";
                                                else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_224";
                                                else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_224.1";
                                                else allocationResult = 1, processNo1 = "C1_225";
                                            }
                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*1.5 < overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C1_226";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]*1.5) allocationResult = 2, processNo1 = "C1_227";
                                                else if (numberOfEntry == 1 && numberOfEntry2 > 1) allocationResult = 2, processNo1 = "C1_228";
                                                else if (numberOfEntry > 1 && numberOfEntry2 == 1) allocationResult = 3, processNo1 = "C1_229";
                                                else if ((numberOfEntry == 1 && numberOfEntry2 == 1) || (numberOfEntry > 1 && numberOfEntry2 > 1)){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo1 = "C1_230";
                                                    else allocationResult = 3, processNo1 = "C1_231";
                                                }
                                            }
                                            else if (arrayCurrentAverageTrack [currentConnectNumber1] >= cutOff2){
                                                if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 80){
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_232";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_233";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_233.1";
                                                    else allocationResult = 1, processNo1 = "C1_234";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40){
                                                    if (overlapAreaTable [previousNumber2][currentPositionB1] >= 110 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_235";
                                                    else if (overlapAreaTable [previousNumber2][currentPositionB1] < 110 && overlapAreaTable [previousNumber2][currentPositionB1] >= 60 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_236";
                                                    else allocationResult = 2, processNo1 = "C1_237";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                    if (overlapAreaTable [previousNumber2][currentPositionB1] >= 110 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_238";
                                                    else if (overlapAreaTable [previousNumber2][currentPositionB1] < 110 && overlapAreaTable [previousNumber2][currentPositionB1] >= 60 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_239";
                                                    else allocationResult = 2, processNo1 = "C1_240";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 80){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_241";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_242";
                                                    else allocationResult = 3, processNo1 = "C1_243";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 110){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_244";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_245";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_245.1";
                                                        else allocationResult = 1, processNo1 = "C1_246";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 110 && overlapAreaTable [previousNumber2][currentPositionB1] >= 60){
                                                        if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_247";
                                                        else allocationResult = 1, processNo1 = "C1_248";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 60) allocationResult = 2, processNo1 = "C1_249";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 110){
                                                        if (roundTwo == 2) allocationResult = 3, processNo1 = "C1_250";
                                                        else allocationResult = 1, processNo1 = "C1_251";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 110 && overlapAreaTable [previousNumber2][currentPositionB1] >= 60){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_252";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_253";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_253.1";
                                                        else allocationResult = 1, processNo1 = "C1_254";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 60) allocationResult = 2, processNo1 = "C1_255";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 110) allocationResult = 3, processNo1 = "C1_256";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 110 && overlapAreaTable [previousNumber2][currentPositionB1] >= 60) allocationResult = 3, processNo1 = "C1_257";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 60){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_258";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_259";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_259.1";
                                                        else allocationResult = 1, processNo1 = "C1_260";
                                                    }
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                    if (overlapAreaTable [previousNumber2][currentPositionB1] >= 110 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_261";
                                                    else if (overlapAreaTable [previousNumber2][currentPositionB1] < 110 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_262";
                                                    else allocationResult = 2, processNo1 = "C1_263";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 80){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_264";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_265";
                                                    else allocationResult = 3, processNo1 = "C1_266";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_267";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_268";
                                                    else allocationResult = 3, processNo1 = "C1_269";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 110){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_270";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_271";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_271.1";
                                                        else allocationResult = 1, processNo1 = "C1_272";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 110 && overlapAreaTable [previousNumber2][currentPositionB1] >= 60){
                                                        if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_273";
                                                        else allocationResult = 1, processNo1 = "C1_274";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 60) allocationResult = 2, processNo1 = "C1_275";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 110){
                                                        if (roundTwo == 2) allocationResult = 3, processNo1 = "C1_276";
                                                        else allocationResult = 1, processNo1 = "C1_277";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 110 && overlapAreaTable [previousNumber2][currentPositionB1] >= 60){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_278";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_279";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_279.1";
                                                        else allocationResult = 1, processNo1 = "C1_280";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 60) allocationResult = 2, processNo1 = "C1_281";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 110) allocationResult = 3, processNo1 = "C1_282";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 110 && overlapAreaTable [previousNumber2][currentPositionB1] >= 60) allocationResult = 3, processNo1 = "C1_283";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 60){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_284";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_285";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_285.1";
                                                        else allocationResult = 1, processNo1 = "C1_286";
                                                    }
                                                }
                                            }
                                            else if (arrayCurrentAverageTrack [currentConnectNumber1] < cutOff2 && arrayCurrentAverageTrack [currentConnectNumber1] >= cutOff4){
                                                if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 80){
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_287";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_288";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_288.1";
                                                    else allocationResult = 1, processNo1 = "C1_289";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40){
                                                    if (overlapAreaTable [previousNumber2][currentPositionB1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_290";
                                                    else if (overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_291";
                                                    else allocationResult = 2, processNo1 = "C1_292";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                    if (overlapAreaTable [previousNumber2][currentPositionB1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_293";
                                                    else if (overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_294";
                                                    else allocationResult = 2, processNo1 = "C1_295";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 80){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_296";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_297";
                                                    else allocationResult = 3, processNo1 = "C1_298";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_299";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_300";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_300.1";
                                                        else allocationResult = 1, processNo1 = "C1_301";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                        if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_302";
                                                        else allocationResult = 1, processNo1 = "C1_303";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_304";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                        if (roundTwo == 2) allocationResult = 3, processNo1 = "C1_305";
                                                        else allocationResult = 1, processNo1 = "C1_306";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_307";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_308";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_308.1";
                                                        else allocationResult = 1, processNo1 = "C1_309";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_310";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100) allocationResult = 3, processNo1 = "C1_301";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50) allocationResult = 3, processNo1 = "C1_302";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_303";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_304";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_304.1";
                                                        else allocationResult = 1, processNo1 = "C1_305";
                                                    }
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                    if (overlapAreaTable [previousNumber2][currentPositionB1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_306";
                                                    else if (overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_307";
                                                    else allocationResult = 2, processNo1 = "C1_308";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 80){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_309";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_310";
                                                    else allocationResult = 3, processNo1 = "C1_311";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_312";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_313";
                                                    else allocationResult = 3, processNo1 = "C1_314";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_315";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_316";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_316.1";
                                                        else allocationResult = 1, processNo1 = "C1_317";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                        if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_318";
                                                        else allocationResult = 1, processNo1 = "C1_319";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_320";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                        if (roundTwo == 2) allocationResult = 3, processNo1 = "C1_321";
                                                        else allocationResult = 1, processNo1 = "C1_322";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_323";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_324";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_324.1";
                                                        else allocationResult = 1, processNo1 = "C1_325";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_326";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100) allocationResult = 3, processNo1 = "C1_327";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50) allocationResult = 3, processNo1 = "C1_328";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_329";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_330";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_330.1";
                                                        else allocationResult = 1, processNo1 = "C1_331";
                                                    }
                                                }
                                            }
                                            else if (currentDimension1 >= 5){
                                                if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_332";
                                                else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_333";
                                                else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_333.1";
                                                else allocationResult = 1, processNo1 = "C1_334";
                                            }
                                            else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_335";
                                            else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50) allocationResult = 3, processNo1 = "C1_336";
                                            else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_337";
                                            else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_338";
                                                else allocationResult = 1, processNo1 = "C1_339";
                                            }
                                        }
                                        else if (arrayPreviousAverageTrack [previousNumber1] >= cutOff2 && arrayPreviousAverageTrack [previousNumber2] < cutOff4){
                                            if (dimensionPrevious1 >= 5 && dimensionPrevious2 >= 5){
                                                if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_340";
                                                else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_341";
                                                else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_341.1";
                                                else allocationResult = 1, processNo1 = "C1_342";
                                            }
                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100){
                                                if (arrayCurrentAverageTrack [currentConnectNumber1] >= cutOff2) allocationResult = 2, processNo1 = "C1_343";
                                                else if (arrayCurrentAverageTrack [currentConnectNumber1] < cutOff4) allocationResult = 3, processNo1 = "C1_344";
                                                else if (numberOfEntry == 1 && numberOfEntry2 > 1) allocationResult = 2, processNo1 = "C1_345";
                                                else if (numberOfEntry > 1 && numberOfEntry2 == 1) allocationResult = 3, processNo1 = "C1_346";
                                                else if ((numberOfEntry == 1 && numberOfEntry2 == 1) || (numberOfEntry > 1 && numberOfEntry2 > 1)){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo1 = "C1_347";
                                                    else allocationResult = 3, processNo1 = "C1_348";
                                                }
                                            }
                                            else if (arrayCurrentAverageTrack [currentConnectNumber1] >= cutOff2){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*2.0 < overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C1_349";
                                                else if (currentDimension1 >= 5 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_350";
                                                else allocationResult = 2, processNo1 = "C1_351";
                                            }
                                            else if (overlapIntensityTable [previousNumber1][currentPositionA1] >= cutOff2 && overlapIntensityTable [previousNumber2][currentPositionB1] >= cutOff2){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*2.0 < overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C1_352";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]*2.0) allocationResult = 2, processNo1 = "C1_353";
                                                else allocationResult = 2, processNo1 = "C1_354";
                                            }
                                            else if (overlapIntensityTable [previousNumber1][currentPositionA1] < cutOff2 && overlapIntensityTable [previousNumber2][currentPositionB1] >= cutOff2) allocationResult = 5, highSide = 2, processNo1 = "C1_355";
                                            else if (overlapIntensityTable [previousNumber1][currentPositionA1] >= cutOff2 && overlapIntensityTable [previousNumber2][currentPositionB1] < cutOff2) allocationResult = 5, highSide = 1, processNo1 = "C1_356";
                                            else if (overlapIntensityTable [previousNumber1][currentPositionA1] < cutOff2 && overlapIntensityTable [previousNumber2][currentPositionB1] < cutOff2){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]*2.0) allocationResult = 2, processNo1 = "C1_357";
                                                else{
                                                    
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_358";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_359";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_359.1";
                                                    else allocationResult = 1, processNo1 = "C1_360";
                                                }
                                            }
                                        }
                                        else if (arrayPreviousAverageTrack [previousNumber1] < cutOff2 && arrayPreviousAverageTrack [previousNumber1] >= cutOff4 && arrayPreviousAverageTrack [previousNumber2] >= cutOff2){
                                            if (dimensionPrevious1 >= 5 && dimensionPrevious2 >= 5){
                                                if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_361";
                                                else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_362";
                                                else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_362.1";
                                                else allocationResult = 1, processNo1 = "C1_363";
                                            }
                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100){
                                                if (arrayCurrentAverageTrack [currentConnectNumber1] >= cutOff2) allocationResult = 3, processNo1 = "C1_364";
                                                else if (arrayCurrentAverageTrack [currentConnectNumber1] < cutOff2) allocationResult = 2, processNo1 = "C1_365";
                                                else if (numberOfEntry == 1 && numberOfEntry2 > 1) allocationResult = 2, processNo1 = "C1_366";
                                                else if (numberOfEntry > 1 && numberOfEntry2 == 1) allocationResult = 3, processNo1 = "C1_367";
                                                else if ((numberOfEntry == 1 && numberOfEntry2 == 1) || (numberOfEntry > 1 && numberOfEntry2 > 1)){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo1 = "C1_368";
                                                    else allocationResult = 3, processNo1 = "C1_369";
                                                }
                                            }
                                            else if (arrayCurrentAverageTrack [currentConnectNumber1] >= cutOff2){
                                                if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 80){
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_370";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_371";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_371.1";
                                                    else allocationResult = 1, processNo1 = "C1_372";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 110 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_373";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 110 && overlapAreaTable [previousNumber1][currentPositionA1] >= 60 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_374";
                                                    else allocationResult = 3, processNo1 = "C1_375";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 110 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_376";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 110 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_377";
                                                    else allocationResult = 2, processNo1 = "C1_378";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 80){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 110 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_379";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 110 && overlapAreaTable [previousNumber1][currentPositionA1] >= 60 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_380";
                                                    else allocationResult = 3, processNo1 = "C1_381";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 110 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_382";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_383";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_383.1";
                                                        else allocationResult = 1, processNo1 = "C1_384";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 110 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                        if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_385";
                                                        else allocationResult = 1, processNo1 = "C1_386";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 110 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_387";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 110 && overlapAreaTable [previousNumber1][currentPositionA1] >= 60 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                        if (roundTwo == 2) allocationResult = 3, processNo1 = "C1_388";
                                                        else allocationResult = 1, processNo1 = "C1_389";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 110 && overlapAreaTable [previousNumber1][currentPositionA1] >= 60 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_390";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_391";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_391.1";
                                                        else allocationResult = 1, processNo1 = "C1_392";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 110 && overlapAreaTable [previousNumber1][currentPositionA1] >= 60 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_393";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 60 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100) allocationResult = 3, processNo1 = "C1_394";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 60 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50) allocationResult = 3, processNo1 = "C1_395";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 60 && overlapAreaTable [previousNumber2][currentPositionB1] < 50){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_396";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_397";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_397.1";
                                                        else allocationResult = 1, processNo1 = "C1_398";
                                                    }
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                    if (overlapAreaTable [previousNumber2][currentPositionB1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_399";
                                                    else if (overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 60 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_400";
                                                    else allocationResult = 2, processNo1 = "C1_401";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 80){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 110 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_402";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 110 && overlapAreaTable [previousNumber1][currentPositionA1] >= 60 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_403";
                                                    else allocationResult = 3, processNo1 = "C1_404";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 110 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_405";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 110 && overlapAreaTable [previousNumber1][currentPositionA1] >= 60 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_406";
                                                    else allocationResult = 3, processNo1 = "C1_407";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 110 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_408";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_409";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_409.1";
                                                        else allocationResult = 1, processNo1 = "C1_410";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 110 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                        if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_411";
                                                        else allocationResult = 1, processNo1 = "C1_412";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 110 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_413";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 110 && overlapAreaTable [previousNumber1][currentPositionA1] >= 60 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                        if (roundTwo == 2) allocationResult = 3, processNo1 = "C1_414";
                                                        else allocationResult = 1, processNo1 = "C1_415";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 110 && overlapAreaTable [previousNumber1][currentPositionA1] >= 60 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_416";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_417";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_417.1";
                                                        else allocationResult = 1, processNo1 = "C1_418";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 110 && overlapAreaTable [previousNumber1][currentPositionA1] >= 60 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_419";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 60 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100) allocationResult = 3, processNo1 = "C1_420";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 60 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50) allocationResult = 3, processNo1 = "C1_421";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 60 && overlapAreaTable [previousNumber2][currentPositionB1] < 50){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_422";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_423";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_423.1";
                                                        else allocationResult = 1, processNo1 = "C1_424";
                                                    }
                                                }
                                            }
                                            else if (arrayCurrentAverageTrack [currentConnectNumber1] < cutOff2 && arrayCurrentAverageTrack [currentConnectNumber1] >= cutOff4){
                                                if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 80){
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_425";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_426";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_426.1";
                                                    else allocationResult = 1, processNo1 = "C1_427";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40){
                                                    if (overlapAreaTable [previousNumber2][currentPositionB1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_428";
                                                    else if (overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_429";
                                                    else allocationResult = 2, processNo1 = "C1_430";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                    if (overlapAreaTable [previousNumber2][currentPositionB1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_431";
                                                    else if (overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_432";
                                                    else allocationResult = 2, processNo1 = "C1_433";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 80){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_434";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_435";
                                                    else allocationResult = 3, processNo1 = "C1_436";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_437";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_438";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_438.1";
                                                        else allocationResult = 1, processNo1 = "C1_439";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                        if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_440";
                                                        else allocationResult = 1, processNo1 = "C1_441";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_442";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                        if (roundTwo == 2) allocationResult = 3, processNo1 = "C1_443";
                                                        else allocationResult = 1, processNo1 = "C1_444";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_445";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_446";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_446.1";
                                                        else allocationResult = 1, processNo1 = "C1_447";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_448";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100) allocationResult = 3, processNo1 = "C1_449";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50) allocationResult = 3, processNo1 = "C1_450";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_451";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_452";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_452.1";
                                                        else allocationResult = 1, processNo1 = "C1_453";
                                                    }
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                    if (overlapAreaTable [previousNumber2][currentPositionB1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_454";
                                                    else if (overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_455";
                                                    else allocationResult = 2, processNo1 = "C1_456";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable[previousNumber2][currentPositionB1] >= 80){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_457";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_458";
                                                    else allocationResult = 3, processNo1 = "C1_459";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_460";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_461";
                                                    else allocationResult = 3, processNo1 = "C1_462";
                                                }
                                                else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_463";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_464";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_464.1";
                                                        else allocationResult = 1, processNo1 = "C1_465";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                        if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_466";
                                                        else allocationResult = 1, processNo1 = "C1_467";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_468";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                        if (roundTwo == 2) allocationResult = 3, processNo1 = "C1_469";
                                                        else allocationResult = 1, processNo1 = "C1_470";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_471";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_472";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_472.1";
                                                        else allocationResult = 1, processNo1 = "C1_473";
                                                    }
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_474";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100) allocationResult = 3, processNo1 = "C1_475";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50) allocationResult = 3, processNo1 = "C1_476";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50){
                                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_477";
                                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_478";
                                                        else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_478.1";
                                                        else allocationResult = 1, processNo1 = "C1_479";
                                                    }
                                                }
                                            }
                                            else if (currentDimension1 >= 5){
                                                if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_480";
                                                else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_481";
                                                else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_481.1";
                                                else allocationResult = 1, processNo1 = "C1_482";
                                            }
                                            else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_483";
                                            else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50) allocationResult = 3, processNo1 = "C1_484";
                                            else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_485";
                                            else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_486";
                                                else allocationResult = 1, processNo1 = "C1_487";
                                            }
                                        }
                                        else if (arrayPreviousAverageTrack [previousNumber1] < cutOff2 && arrayPreviousAverageTrack [previousNumber1] >= cutOff4 && arrayPreviousAverageTrack [previousNumber2] < cutOff2 && arrayPreviousAverageTrack [previousNumber2] >= cutOff4){
                                            if (dimensionPrevious1 >= 5 && dimensionPrevious2 >= 5){
                                                if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_488";
                                                else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_489";
                                                else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_489.1";
                                                else allocationResult = 1, processNo1 = "C1_490";
                                            }
                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*1.5 < overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C1_491";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]*1.5) allocationResult = 2, processNo1 = "C1_492";
                                                else if (numberOfEntry == 1 && numberOfEntry2 > 1) allocationResult = 2, processNo1 = "C1_493";
                                                else if (numberOfEntry > 1 && numberOfEntry2 == 1) allocationResult = 3, processNo1 = "C1_494";
                                                else if ((numberOfEntry == 1 && numberOfEntry2 == 1) || (numberOfEntry > 1 && numberOfEntry2 > 1)){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo1 = "C1_495";
                                                    else allocationResult = 3, processNo1 = "C1_496";
                                                }
                                            }
                                            else if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 80){
                                                if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_497";
                                                else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_498";
                                                else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_498.1";
                                                else allocationResult = 1, processNo1 = "C1_499";
                                            }
                                            else if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40){
                                                if (overlapAreaTable [previousNumber2][currentPositionB1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_500";
                                                else if (overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_501";
                                                else allocationResult = 2, processNo1 = "C1_502";
                                            }
                                            else if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                if (overlapAreaTable [previousNumber2][currentPositionB1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_503";
                                                else if (overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_504";
                                                else allocationResult = 2, processNo1 = "C1_505";
                                            }
                                            else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 80){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_506";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_507";
                                                else allocationResult = 3, processNo1 = "C1_508";
                                            }
                                            else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_509";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_510";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_510.1";
                                                    else allocationResult = 1, processNo1 = "C1_511";
                                                }
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                    if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_512";
                                                    else allocationResult = 1, processNo1 = "C1_513";
                                                }
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_514";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                    if (roundTwo == 2) allocationResult = 3, processNo1 = "C1_515";
                                                    else allocationResult = 1, processNo1 = "C1_516";
                                                }
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_517";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_518";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_518.1";
                                                    else allocationResult = 1, processNo1 = "C1_519";
                                                }
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_520";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100) allocationResult = 3, processNo1 = "C1_521";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50) allocationResult = 3, processNo1 = "C1_522";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50){
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_523";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_524";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_524.1";
                                                    else allocationResult = 1, processNo1 = "C1_525";
                                                }
                                            }
                                            else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                if (overlapAreaTable [previousNumber2][currentPositionB1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_526";
                                                else if (overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_527";
                                                else allocationResult = 2, processNo1 = "C1_528";
                                            }
                                            else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 80){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_529";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_530";
                                                else allocationResult = 3, processNo1 = "C1_531";
                                            }
                                            else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_532";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_533";
                                                else allocationResult = 3, processNo1 = "C1_534";
                                            }
                                            else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_535";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_536";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_536.1";
                                                    else allocationResult = 1, processNo1 = "C1_537";
                                                }
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                    if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_538";
                                                    else allocationResult = 1, processNo1 = "C1_539";
                                                }
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_540";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                    if (roundTwo == 2) allocationResult = 3, processNo1 = "C1_541";
                                                    else allocationResult = 1, processNo1 = "C1_542";
                                                }
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_543";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_544";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_544.1";
                                                    else allocationResult = 1, processNo1 = "C1_545";
                                                }
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_546";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100) allocationResult = 3, processNo1 = "C1_547";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50) allocationResult = 3, processNo1 = "C1_548";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50){
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_549";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_550";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_550.1";
                                                    else allocationResult = 1, processNo1 = "C1_551";
                                                }
                                            }
                                        }
                                        else if (arrayPreviousAverageTrack [previousNumber1] < cutOff2 && arrayPreviousAverageTrack [previousNumber1] >= cutOff4 && arrayPreviousAverageTrack [previousNumber2] < cutOff4){
                                            if (dimensionPrevious1 >= 5 && dimensionPrevious2 >= 5){
                                                if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_552";
                                                else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_553";
                                                else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_553.1";
                                                else allocationResult = 1, processNo1 = "C1_554";
                                            }
                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*1.5 < overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C1_555";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]*1.5) allocationResult = 2, processNo1 = "C1_556";
                                                else if (numberOfEntry == 1 && numberOfEntry2 > 1) allocationResult = 2, processNo1 = "C1_557";
                                                else if (numberOfEntry > 1 && numberOfEntry2 == 1) allocationResult = 3, processNo1 = "C1_558";
                                                else if ((numberOfEntry == 1 && numberOfEntry2 == 1) || (numberOfEntry > 1 && numberOfEntry2 > 1)){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo1 = "C1_559";
                                                    else allocationResult = 3, processNo1 = "C1_560";
                                                }
                                            }
                                            else if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff2){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*2.0 < overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C1_561";
                                                else if (currentDimension1 >= 5) allocationResult = 1, processNo1 = "C1_562";
                                                else allocationResult = 2, processNo1 = "C1_563";
                                            }
                                            else if (overlapIntensityTable [previousNumber1][currentPositionA1] >= cutOff2 && overlapIntensityTable [previousNumber2][currentPositionB1] < cutOff4) allocationResult = 5, highSide = 1, processNo1 = "C1_564";
                                            else if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]*1.5) allocationResult = 2, processNo1 = "C1_565";
                                            else if (overlapAreaTable [previousNumber1][currentPositionA1]*1.5 < overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C1_567";
                                            else{
                                                
                                                if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_568";
                                                else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_569";
                                                else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_569.1";
                                                else allocationResult = 1, processNo1 = "C1_570";
                                            }
                                        }
                                        else if (arrayPreviousAverageTrack [previousNumber1] < cutOff4 && arrayPreviousAverageTrack [previousNumber2] >= cutOff2){
                                            if (dimensionPrevious1 >= 5 && dimensionPrevious2 >= 5) allocationResult = 1, processNo1 = "C1_571";
                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100){
                                                if (arrayCurrentAverageTrack [currentConnectNumber1] >= cutOff2) allocationResult = 3, processNo1 = "C1_572";
                                                else if (arrayCurrentAverageTrack [currentConnectNumber1] < cutOff4) allocationResult = 2, processNo1 = "C1_573";
                                                else if (numberOfEntry == 1 && numberOfEntry2 > 1) allocationResult = 2, processNo1 = "C1_574";
                                                else if (numberOfEntry > 1 && numberOfEntry2 == 1) allocationResult = 3, processNo1 = "C1_575";
                                                else if ((numberOfEntry == 1 && numberOfEntry2 == 1) || (numberOfEntry > 1 && numberOfEntry2 > 1)){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo1 = "C1_576";
                                                    else allocationResult = 3, processNo1 = "C1_578";
                                                }
                                            }
                                            else if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff2){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]*2.0) allocationResult = 2, processNo1 = "C1_579";
                                                else if (currentDimension1 >= 5 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_580";
                                                else allocationResult = 3, processNo1 = "C1_581";
                                            }
                                            else if (overlapIntensityTable [previousNumber1][currentPositionA1] >= cutOff2 && overlapIntensityTable [previousNumber2][currentPositionB1] >= cutOff2){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*2.0 < overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C1_582";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]*2.0) allocationResult = 2, processNo1 = "C1_583";
                                                else{
                                                    
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_584";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_585";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_585.1";
                                                    else allocationResult = 1, processNo1 = "C1_586";
                                                }
                                            }
                                            else if (overlapIntensityTable [previousNumber1][currentPositionA1] < cutOff2 && overlapIntensityTable [previousNumber2][currentPositionB1] >= cutOff2) allocationResult = 5, highSide = 2, processNo1 = "C1_587";
                                            else if (overlapIntensityTable [previousNumber1][currentPositionA1] >= cutOff2 && overlapIntensityTable [previousNumber2][currentPositionB1] < cutOff2) allocationResult = 5, highSide = 1, processNo1 = "C1_588";
                                            else if (overlapIntensityTable [previousNumber1][currentPositionA1] < cutOff2 && overlapIntensityTable [previousNumber2][currentPositionB1] < cutOff2){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*2.0 < overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C1_589";
                                                else{
                                                    
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_590";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_591";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_591.1";
                                                    else allocationResult = 1, processNo1 = "C1_592";
                                                }
                                            }
                                        }
                                        else if (arrayPreviousAverageTrack [previousNumber1] < cutOff4 && arrayPreviousAverageTrack [previousNumber2] < cutOff2 && arrayPreviousAverageTrack [previousNumber2] >= cutOff4){
                                            if (dimensionPrevious1 >= 5 && dimensionPrevious2 >= 5){
                                                if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_593";
                                                else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_594";
                                                else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_594.1";
                                                else allocationResult = 1, processNo1 = "C1_595";
                                            }
                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*1.5 < overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C1_596";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]*1.5) allocationResult = 2, processNo1 = "C1_497";
                                                else if (numberOfEntry == 1 && numberOfEntry2 > 1) allocationResult = 2, processNo1 = "C1_598";
                                                else if (numberOfEntry > 1 && numberOfEntry2 == 1) allocationResult = 3, processNo1 = "C1_599";
                                                else if ((numberOfEntry == 1 && numberOfEntry2 == 1) || (numberOfEntry > 1 && numberOfEntry2 > 1)){
                                                    if (overlapPercentageTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo1 = "C1_600";
                                                    else allocationResult = 3, processNo1 = "C1_601";
                                                }
                                            }
                                            else if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff2){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]*2.0) allocationResult = 2, processNo1 = "C1_602";
                                                else if (currentDimension1 >= 5 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_603";
                                                else allocationResult = 3, processNo1 = "C1_604";
                                            }
                                            else if (overlapIntensityTable [previousNumber1][currentPositionA1] < cutOff4 && overlapIntensityTable [previousNumber2][currentPositionB1] >= cutOff2) allocationResult = 5, highSide = 2, processNo1 = "C1_605";
                                            else if (overlapAreaTable [previousNumber1][currentPositionA1]*1.5 < overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C1_606";
                                            else if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]*1.5) allocationResult = 2, processNo1 = "C1_607";
                                            else{
                                                
                                                if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_608";
                                                else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_609";
                                                else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_609.1";
                                                else allocationResult = 1, processNo1 = "C1_610";
                                            }
                                        }
                                        else if (arrayPreviousAverageTrack [previousNumber1] < cutOff4 && arrayPreviousAverageTrack [previousNumber2] < cutOff4){
                                            if (dimensionPrevious1 >= 5 && dimensionPrevious2 >= 5){
                                                if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_611";
                                                else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_612";
                                                else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_612.1";
                                                else allocationResult = 1, processNo1 = "C1_613";
                                            }
                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] < 100){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*1.5 < overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C1_614";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]*1.5) allocationResult = 2, processNo1 = "C1_615";
                                                else if (numberOfEntry == 1 && numberOfEntry2 > 1) allocationResult = 2, processNo1 = "C1_616";
                                                else if (numberOfEntry > 1 && numberOfEntry2 == 1) allocationResult = 3, processNo1 = "C1_617";
                                                else if ((numberOfEntry == 1 && numberOfEntry2 == 1) || (numberOfEntry > 1 && numberOfEntry2 > 1)) allocationResult = 6, processNo1 = "C1_618";
                                            }
                                            else if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff2){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1]*1.5 < overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo1 = "C1_619";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]*1.5) allocationResult = 2, processNo1 = "C1_620";
                                                else if (currentDimension1 >= 5) allocationResult = 1, processNo1 = "C1_621";
                                                else{
                                                    
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_622";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_623";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_623.1";
                                                    else allocationResult = 1, processNo1 = "C1_624";
                                                }
                                            }
                                            else if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 80){
                                                if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_625";
                                                else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_626";
                                                else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_626.1";
                                                else allocationResult = 1, processNo1 = "C1_627";
                                            }
                                            else if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40){
                                                if (overlapAreaTable [previousNumber2][currentPositionB1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_628";
                                                else if (overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_629";
                                                else allocationResult = 2, processNo1 = "C1_630";
                                            }
                                            else if (overlapPercentageTable [previousNumber1][currentPositionA1] >= 80 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                if (overlapAreaTable [previousNumber2][currentPositionB1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_631";
                                                else if (overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_632";
                                                else allocationResult = 2, processNo1 = "C1_633";
                                            }
                                            else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 80){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_634";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_635";
                                                else allocationResult = 3, processNo1 = "C1_636";
                                            }
                                            else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_637";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_638";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_638.1";
                                                    else allocationResult = 1, processNo1 = "C1_639";
                                                }
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                    if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_640";
                                                    else allocationResult = 1, processNo1 = "C1_641";
                                                }
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_642";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                    if (roundTwo == 2) allocationResult = 3, processNo1 = "C1_643";
                                                    else allocationResult = 1, processNo1 = "C1_644";
                                                }
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_645";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_656";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_656.1";
                                                    else allocationResult = 1, processNo1 = "C1_647";
                                                }
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_648";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100) allocationResult = 3, processNo1 = "C1_649";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50) allocationResult = 3, processNo1 = "C1_650";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50){
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_651";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_652";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_652.1";
                                                    else allocationResult = 1, processNo1 = "C1_653";
                                                }
                                            }
                                            else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 80 && overlapPercentageTable [previousNumber1][currentPositionA1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                if (overlapAreaTable [previousNumber2][currentPositionB1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_654";
                                                else if (overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_655";
                                                else allocationResult = 2, processNo1 = "C1_656";
                                            }
                                            else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 80){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_657";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_658";
                                                else allocationResult = 3, processNo1 = "C1_659";
                                            }
                                            else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] >= 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 80){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_660";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && roundTwo == 1) allocationResult = 1, processNo1 = "C1_661";
                                                else allocationResult = 3, processNo1 = "C1_662";
                                            }
                                            else if (overlapPercentageTable [previousNumber1][currentPositionA1] < 40 && overlapPercentageTable [previousNumber2][currentPositionB1] < 40){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_663";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_664";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_664.1";
                                                    else allocationResult = 1, processNo1 = "C1_665";
                                                }
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                    if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_666";
                                                    else allocationResult = 1, processNo1 = "C1_667";
                                                }
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] >= 100 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_668";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100){
                                                    if (roundTwo == 2) allocationResult = 3, processNo1 = "C1_669";
                                                    else allocationResult = 1, processNo1 = "C1_670";
                                                }
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50){
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_671";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_672";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_672.1";
                                                    else allocationResult = 1, processNo1 = "C1_673";
                                                }
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 100 && overlapAreaTable [previousNumber1][currentPositionA1] >= 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50) allocationResult = 2, processNo1 = "C1_674";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] >= 100) allocationResult = 3, processNo1 = "C1_675";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 100 && overlapAreaTable [previousNumber2][currentPositionB1] >= 50) allocationResult = 3, processNo1 = "C1_676";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] < 50 && overlapAreaTable [previousNumber2][currentPositionB1] < 50){
                                                    if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2, processNo1 = "C1_678";
                                                    else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3, processNo1 = "C1_679";
                                                    else if (roundTwo == 2) allocationResult = 2, processNo1 = "C1_679.1";
                                                    else allocationResult = 1, processNo1 = "C1_680";
                                                }
                                            }
                                        }
                                    }
                                    
                                    //cout<<"ALLC RESULT "<<allocationResult<<" "<<processNo1<<endl;
                                    
                                    //==========Group check==========
                                    noReFusionFlag = 0;
                                    processNo2 = "";
                                    
                                    if (allocationResult == 1 && arrayPreviousTableTrack [previousNumber1*2+1] < 0){
                                        if (arrayPreviousTableTrack [previousNumber2*2+1] < 0){
                                            if (arrayPreviousTableTrack [previousNumber1*2] == arrayPreviousTableTrack [previousNumber2*2]) noReFusionFlag = 1;
                                        }
                                        else if (arrayPreviousTableTrack [previousNumber2*2+1] > 0){
                                            if (arrayPreviousTableTrack [previousNumber1*2+1]*-1 == arrayPreviousTableTrack [previousNumber2*2]) noReFusionFlag = 1;
                                        }
                                    }
                                    else if (allocationResult == 1 && arrayPreviousTableTrack [previousNumber1*2+1] > 0){
                                        if (arrayPreviousTableTrack [previousNumber2*2+1] < 0){
                                            if (arrayPreviousTableTrack [previousNumber1*2] == arrayPreviousTableTrack [previousNumber2*2]*-1) noReFusionFlag = 1;
                                        }
                                    }
                                    
                                    if (noReFusionFlag == 1){
                                        if (overlapAreaTable [previousNumber1][currentPositionA1] < overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo2 = "CR_A1";
                                        else allocationResult = 2, processNo2 = "CR_A2";
                                    }
                                    
                                    //------Attach check---------
                                    attachCount = 0;
                                    
                                    for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                        for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                            attachTemp = 0;
                                            
                                            if (arrayCellTrackingPreviousMap [counterY][counterX] == previousNumber1){
                                                if (counterY-1 >= 0 && counterX-1 >= 0 && arrayCellTrackingPreviousMap [counterY-1][counterX-1] == previousNumber2) attachTemp = 1;
                                                if (counterY-1 >= 0 && arrayCellTrackingPreviousMap [counterY-1][counterX] == previousNumber2) attachTemp = 1;
                                                if (counterY-1 >= 0 && counterX+1 < trackAreaSize && arrayCellTrackingPreviousMap [counterY-1][counterX+1] == previousNumber2) attachTemp = 1;
                                                if (counterX+1 < trackAreaSize && arrayCellTrackingPreviousMap [counterY][counterX+1] == previousNumber2) attachTemp = 1;
                                                if (counterY+1 < trackAreaSize && counterX+1 < trackAreaSize && arrayCellTrackingPreviousMap [counterY+1][counterX+1] == previousNumber2) attachTemp = 1;
                                                if (counterY+1 < trackAreaSize && arrayCellTrackingPreviousMap [counterY+1][counterX] == previousNumber2) attachTemp = 1;
                                                if (counterY+1 < trackAreaSize && counterX-1 >= 0 && arrayCellTrackingPreviousMap [counterY+1][counterX-1] == previousNumber2) attachTemp = 1;
                                                if (counterX-1 >= 0 && arrayCellTrackingPreviousMap [counterY][counterX-1] == previousNumber2) attachTemp = 1;
                                                if (attachTemp == 1) attachCount++;
                                            }
                                        }
                                    }
                                    
                                    if (allocationResult == 1){
                                        if (attachCount > 10){
                                            if (groupTablePrevious [(previousNumber1-1)*5+4] == 2000 && groupTablePrevious [(previousNumber2-1)*5+4] == 2000){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]){
                                                    if (targetPointer == previousNumber1) allocationResult = 2, processNo2 = "CR_A3";
                                                    else allocationResult = 3, processNo2 = "CR_A4";
                                                }
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] <= overlapAreaTable [previousNumber2][currentPositionB1]){
                                                    if (targetPointer == previousNumber2) allocationResult = 3, processNo2 = "CR_A5";
                                                    else allocationResult = 2, processNo2 = "CR_A6";
                                                }
                                            }
                                            else if ((targetPointer == previousNumber1 && groupTablePrevious [(previousNumber1-1)*5+4] < groupTablePrevious [(previousNumber2-1)*5+4]) ||
                                                     (targetPointer == previousNumber2 && groupTablePrevious [(previousNumber1-1)*5+4] > groupTablePrevious [(previousNumber2-1)*5+4]) ||
                                                     (targetPointer != previousNumber1 && targetPointer != previousNumber2 && ((groupTablePrevious [(previousNumber1-1)*5+4] > groupTablePrevious [(previousNumber2-1)*5+4]) || (groupTablePrevious [(previousNumber1-1)*5+4] < groupTablePrevious [(previousNumber2-1)*5+4])))){
                                                if (groupTablePrevious [(previousNumber1-1)*5]*-1 == groupTablePrevious [(previousNumber2-1)*5] || groupTablePrevious [(previousNumber1-1)*5] == groupTablePrevious [(previousNumber2-1)*5]*-1) allocationResult = 1, processNo2 = "CR_A42";
                                                else if (groupTablePrevious [(previousNumber1-1)*5+2] == groupTablePrevious [(previousNumber2-1)*5+2]) allocationResult = 1, processNo2 = "CR_A43";
                                                else if (processType == 3){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo2 = "CR_A44";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] <= overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo2 = "CR_A45";
                                                }
                                                else if (processType == 2) allocationResult = 3, processNo2 = "CR_A46";
                                                else if (processType == 1){
                                                    if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff2){
                                                        if (arrayPreviousAverageTrack [previousNumber1] > cutOff2 && arrayPreviousAverageTrack [previousNumber2] > cutOff2){
                                                            if (arrayCurrentTableTrack [currentConnectNumber1*2] < (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.7) allocationResult = 1, processNo2 = "CR_A47";
                                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.7) allocationResult = 4, processNo2 = "CR_A48";
                                                        }
                                                        else if (arrayPreviousAverageTrack [previousNumber1] <= cutOff2 && arrayPreviousAverageTrack [previousNumber2] > cutOff2){
                                                            if (targetPointer == previousNumber1) allocationResult = 2, processNo2 = "CR_A49";
                                                            else allocationResult = 3, processNo2 = "CR_A50";
                                                        }
                                                        else if (arrayPreviousAverageTrack [previousNumber1] > cutOff2 && arrayPreviousAverageTrack [previousNumber2] <= cutOff2){
                                                            if (targetPointer == previousNumber2) allocationResult = 3, processNo2 = "CR_A51";
                                                            else allocationResult = 2, processNo2 = "CR_A52";
                                                        }
                                                        else if (arrayPreviousAverageTrack [previousNumber1] <= cutOff2 && arrayPreviousAverageTrack [previousNumber2] <= cutOff2){
                                                            if (arrayCurrentTableTrack [currentConnectNumber1*2] < (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.7) allocationResult = 1, processNo2 = "CR_A53";
                                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.7) allocationResult = 4, processNo2 = "CR_A54";
                                                        }
                                                    }
                                                    else if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff2 && arrayCurrentAverageTrack [currentConnectNumber2] > cutOff4){
                                                        if (arrayPreviousAverageTrack [previousNumber1] > cutOff2 && arrayPreviousAverageTrack [previousNumber2] > cutOff2){
                                                            if (arrayCurrentTableTrack [currentConnectNumber1*2] < (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.5) allocationResult = 1, processNo2 = "CR_A55";
                                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.5) allocationResult = 4, processNo2 = "CR_A56";
                                                        }
                                                        else if (arrayPreviousAverageTrack [previousNumber1] <= cutOff2 && arrayPreviousAverageTrack [previousNumber2] > cutOff2){
                                                            if (arrayCurrentTableTrack [currentConnectNumber1*2] < (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.5){
                                                                if (targetPointer == previousNumber2) allocationResult = 3, processNo2 = "CR_A57";
                                                                else allocationResult = 2, processNo2 = "CR_A58";
                                                            }
                                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.5) allocationResult = 5, highSide = 2, processNo2 = "CR_A59";
                                                        }
                                                        else if (arrayPreviousAverageTrack [previousNumber1] > cutOff2 && arrayPreviousAverageTrack [previousNumber2] <= cutOff2){
                                                            if (arrayCurrentTableTrack [currentConnectNumber1*2] < (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.5){
                                                                if (targetPointer == previousNumber1) allocationResult = 2, processNo2 = "CR_A60";
                                                                else allocationResult = 3, processNo2 = "CR_A61";
                                                            }
                                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.5) allocationResult = 5, highSide = 1, processNo2 = "CR_A62";
                                                        }
                                                        else if (arrayPreviousAverageTrack [previousNumber1] <= cutOff2 && arrayPreviousAverageTrack [previousNumber2] <= cutOff2){
                                                            if (arrayCurrentTableTrack [currentConnectNumber1*2] < (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.5){
                                                                if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]){
                                                                    if (targetPointer == previousNumber2) allocationResult = 3, processNo2 = "CR_A63";
                                                                    else allocationResult = 2, processNo2 = "CR_A64";
                                                                }
                                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] <= overlapAreaTable [previousNumber2][currentPositionB1]){
                                                                    if (targetPointer == previousNumber1) allocationResult = 2, processNo2 = "CR_A65";
                                                                    else allocationResult = 3, processNo2 = "CR_A66";
                                                                }
                                                            }
                                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.5) allocationResult = 4, processNo2 = "CR_A67";
                                                        }
                                                    }
                                                    else if (arrayCurrentTableTrackTotal [currentConnectNumber1] <= cutOff4){
                                                        if (arrayCurrentAverageTrack [previousNumber1] > cutOff2 && arrayPreviousAverageTrack [previousNumber2] > cutOff2){
                                                            if (arrayCurrentTableTrack [currentConnectNumber1*2] < (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.7) allocationResult = 1, processNo2 = "CR_A68";
                                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.7) allocationResult = 1, processNo2 = "CR_A69";
                                                        }
                                                        else if (arrayPreviousAverageTrack [previousNumber1]<= cutOff2 && arrayPreviousAverageTrack [previousNumber2] > cutOff2){
                                                            if (targetPointer == previousNumber2) allocationResult = 3, processNo2 = "CR_A70";
                                                            else allocationResult = 2, processNo2 = "CR_A71";
                                                        }
                                                        else if (arrayPreviousAverageTrack [previousNumber1] > cutOff2 && arrayPreviousAverageTrack [previousNumber2] <= cutOff2){
                                                            if (targetPointer == previousNumber1) allocationResult = 2, processNo2 = "CR_A72";
                                                            else allocationResult = 3, processNo2 = "CR_A73";
                                                        }
                                                        else if (arrayPreviousAverageTrack [previousNumber1] <= cutOff2 && arrayPreviousAverageTrack [previousNumber2] <= cutOff2){
                                                            if (arrayCurrentTableTrack [currentConnectNumber1*2] < (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.7){
                                                                if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]){
                                                                    if (targetPointer == previousNumber2) allocationResult = 3, processNo2 = "CR_A74";
                                                                    else allocationResult = 2, processNo2 = "CR_A71";
                                                                }
                                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] <= overlapAreaTable [previousNumber2][currentPositionB1]){
                                                                    if (targetPointer == previousNumber1) allocationResult = 2, processNo2 = "CR_A75";
                                                                    else allocationResult = 3, processNo2 = "CR_A76";
                                                                }
                                                            }
                                                            else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.7) allocationResult = 4, processNo2 = "CR_A77";
                                                        }
                                                    }
                                                }
                                            }
                                            else allocationResult = 1;
                                        }
                                        else{
                                            
                                            if (processType == 3){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo2 = "CR_A78.1";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] <= overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo2 = "CR_A79";
                                            }
                                            else if (processType == 2) allocationResult = 3, processNo2 = "CR_A80.1";
                                            else if (processType == 1){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo2 = "CR_A78.2";
                                                else if (overlapAreaTable [previousNumber1][currentPositionA1] <= overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo2 = "CR_A79.2";
                                            }
                                        }
                                    }
                                    else if (allocationResult == 4 || allocationResult == 5){
                                        divisionCancelFlag = 0;
                                        
                                        //------If currentConnect is a target of Previous connect, not allow to divide-------
                                        for (int counter2 = 0; counter2 < maxTargetEntry; counter2++){
                                            if (overlapNumberTable [targetPointer][counter2] != 0 && overlapNumberTable [targetPointer][counter2] == currentConnectNumber1){
                                                divisionCancelFlag = 1;
                                            }
                                        }
                                        
                                        if ((groupTablePrevious [(previousNumber1-1)*5+4] < 2000 && groupTablePrevious [(previousNumber2-1)*5+4] < 2000) || divisionCancelFlag == 1){
                                            if ((groupTablePrevious [(previousNumber1-1)*5]*-1 == groupTablePrevious [(previousNumber2-1)*5]) || (groupTablePrevious [(previousNumber1-1)*5] == groupTablePrevious [(previousNumber2-1)*5]*-1) || (groupTablePrevious [(previousNumber1-1)*5]*-1 == groupTablePrevious [(previousNumber2-1)*5]*-1) || (groupTablePrevious [(previousNumber1-1)*5+2] == groupTablePrevious [(previousNumber2-1)*5+2]) || divisionCancelFlag == 1){
                                                if (processType == 3 || divisionCancelFlag == 1){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2, processNo2 = "CR_A78";
                                                    else if (overlapAreaTable [previousNumber1][currentPositionA1] <= overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 3, processNo2 = "CR_A79";
                                                }
                                                else if (processType == 2) allocationResult = 3, processNo2 = "CR_A80";
                                                else if (processType == 1 && roundTwo == 1 && attachCount > 10) allocationResult = 1, processNo2 = "CR_A81";
                                            }
                                        }
                                    }
                                    else if (allocationResult == 2 ||allocationResult == 3 || allocationResult == 6){
                                        if (processType == 1 && groupTablePrevious [(previousNumber1-1)*5+4] < 2000 && groupTablePrevious [(previousNumber2-1)*5+4] < 2000){
                                            if ((groupTablePrevious [(previousNumber1-1)*5+4] > groupTablePrevious [(previousNumber2-1)*5+4]) || (groupTablePrevious [(previousNumber1-1)*5+4] < groupTablePrevious [(previousNumber2-1)*5+4])){
                                                if (arrayCurrentAverageTrack [currentConnectNumber1] > cutOff2){
                                                    if (arrayPreviousAverageTrack [previousNumber1] > cutOff2 && arrayPreviousAverageTrack [previousNumber2] > cutOff2){
                                                        if (arrayCurrentTableTrack [currentConnectNumber1*2] < (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.7){
                                                            if (roundTwo == 1 && attachCount > 10) allocationResult = 1, processNo2 = "CR_A110";
                                                        }
                                                        else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.7) allocationResult = 4, processNo2 = "CR_A111";
                                                    }
                                                    else if (arrayPreviousAverageTrack [previousNumber1] <= cutOff2 && arrayPreviousAverageTrack [previousNumber2] > cutOff2){
                                                        if (targetPointer == previousNumber1) allocationResult = 2, processNo2 = "CR_A112";
                                                        else allocationResult = 3, processNo2 = "CR_A113";
                                                    }
                                                    else if (arrayPreviousAverageTrack [previousNumber1] > cutOff2 && arrayPreviousAverageTrack [previousNumber2] <= cutOff2){
                                                        if (targetPointer == previousNumber2) allocationResult = 3, processNo2 = "CR_A114";
                                                        else allocationResult = 2, processNo2 = "CR_A115";
                                                    }
                                                    else if (arrayPreviousAverageTrack [previousNumber1] <= cutOff2 && arrayPreviousAverageTrack [previousNumber2] <= cutOff2){
                                                        if (arrayCurrentTableTrack [currentConnectNumber1*2] < (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.7){
                                                            if (roundTwo == 1 && attachCount > 10) allocationResult = 1, processNo2 = "CR_A116";
                                                        }
                                                        else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.7) allocationResult = 4, processNo2 = "CR_A117";
                                                    }
                                                }
                                                else if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff2 && arrayCurrentAverageTrack [currentConnectNumber2] > cutOff4){
                                                    if (arrayPreviousAverageTrack [previousNumber1] > cutOff2 && arrayPreviousAverageTrack [previousNumber2] > cutOff2){
                                                        if (arrayCurrentTableTrack [currentConnectNumber1*2] < (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.5){
                                                            if (roundTwo == 1 && attachCount > 10) allocationResult = 1, processNo2 = "CR_A118";
                                                        }
                                                        else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.5) allocationResult = 4, processNo2 = "CR_A119";
                                                    }
                                                    else if (arrayPreviousAverageTrack [previousNumber1] <= cutOff2 && arrayPreviousAverageTrack [previousNumber1] > cutOff2){
                                                        if (arrayCurrentTableTrack [currentConnectNumber1*2] < (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.5){
                                                            if (targetPointer == previousNumber2) allocationResult = 3, processNo2 = "CR_A120";
                                                            else allocationResult = 2, processNo2 = "CR_A121";
                                                        }
                                                        else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.5) allocationResult = 5, highSide = 2, processNo2 = "CR_A122";
                                                    }
                                                    else if (arrayPreviousAverageTrack [previousNumber1] > cutOff2 && arrayPreviousAverageTrack [previousNumber1] <= cutOff2){
                                                        if (arrayCurrentTableTrack [currentConnectNumber1*2] < (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.5){
                                                            if (targetPointer == previousNumber1) allocationResult = 2, processNo2 = "CR_A123";
                                                            else allocationResult = 3, processNo2 = "CR_A124";
                                                        }
                                                        else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.5) allocationResult = 5, highSide = 1, processNo2 = "CR_A125";
                                                    }
                                                    else if (arrayPreviousAverageTrack [previousNumber1] <= cutOff2 && arrayPreviousAverageTrack [previousNumber2] <= cutOff2){
                                                        if (arrayCurrentTableTrack [currentConnectNumber1*2] < (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.5){
                                                            if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]){
                                                                if (targetPointer == previousNumber2) allocationResult = 3, processNo2 = "CR_A126";
                                                                else allocationResult = 2, processNo2 = "CR_A127";
                                                            }
                                                            else if (overlapAreaTable [previousNumber1][currentPositionA1] <= overlapAreaTable [previousNumber2][currentPositionB1]){
                                                                if (targetPointer == previousNumber1) allocationResult = 2, processNo2 = "CR_A128";
                                                                else allocationResult = 3, processNo2 = "CR_A129";
                                                            }
                                                        }
                                                        else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.5) allocationResult = 4, processNo2 = "CR_A130";
                                                    }
                                                }
                                                else if (arrayCurrentAverageTrack [currentConnectNumber1] <= cutOff4){
                                                    if (arrayPreviousAverageTrack [previousNumber1] > cutOff2 && arrayPreviousAverageTrack [previousNumber2] > cutOff2){
                                                        if (arrayCurrentTableTrack [currentConnectNumber1*2] < (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.7){
                                                            if (roundTwo == 1 && attachCount > 10) allocationResult = 1, processNo2 = "CR_A131";
                                                        }
                                                        else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.7){
                                                            if (roundTwo == 1 && attachCount > 10) allocationResult = 1, processNo2 = "CR_A132";
                                                        }
                                                    }
                                                    else if (arrayPreviousAverageTrack [previousNumber1]<= cutOff2 && arrayPreviousAverageTrack [previousNumber2] > cutOff2){
                                                        if (targetPointer == previousNumber2) allocationResult = 3, processNo2 = "CR_A133";
                                                        else allocationResult = 2, processNo2 = "CR_A134";
                                                    }
                                                    else if (arrayPreviousAverageTrack [previousNumber1] > cutOff2 && arrayPreviousAverageTrack [previousNumber2] <= cutOff2){
                                                        if (targetPointer == previousNumber1) allocationResult = 2, processNo2 = "CR_A135";
                                                        else allocationResult = 3, processNo2 = "CR_A136";
                                                    }
                                                    else if (arrayPreviousAverageTrack [previousNumber1] <= cutOff2 && arrayPreviousAverageTrack [previousNumber2] <= cutOff2){
                                                        if (arrayCurrentTableTrack [currentConnectNumber1*2] < (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.7){
                                                            if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]){
                                                                if (targetPointer == previousNumber2) allocationResult = 3, processNo2 = "CR_A137";
                                                                else allocationResult = 2, processNo2 = "CR_A138";
                                                            }
                                                            else if (overlapAreaTable [previousNumber1][currentPositionA1] <= overlapAreaTable [previousNumber2][currentPositionB1]){
                                                                if (targetPointer == previousNumber1) allocationResult = 2, processNo2 = "CR_A139";
                                                                else allocationResult = 3, processNo2 = "CR_A140";
                                                            }
                                                        }
                                                        else if (arrayCurrentTableTrack [currentConnectNumber1*2] >= (arrayPreviousTableTrack [previousNumber1*2]+arrayPreviousTableTrack [previousNumber2*2])*0.7) allocationResult = 4, processNo2 = "CR_A141";
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    //cout<<"ALLC RESULT2 "<<allocationResult<<" "<<processNo2<<endl;
                                    
                                    if (allocationResult == 2){
                                        if (numberOfEntry2 == 1 && targetPointer == previousNumber2 && roundTwo == 1 && attachCount > 10) allocationResult = 1;
                                        
                                        //cout<<numberOfEntry2 <<"  Target-Taken2_RevFuse"<<endl;
                                    }
                                    
                                    if (allocationResult == 3){
                                        if (numberOfEntry == 1 && targetPointer == previousNumber1 && roundTwo == 1 && attachCount > 10) allocationResult = 1;
                                        
                                        //cout<<numberOfEntry<<"  Target-Taken3_RevFuse"<<endl;
                                    }
                                    
                                    if (allocationResult == 2){
                                        if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3;
                                    }
                                    
                                    if (allocationResult == 3){
                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2;
                                    }
                                    
                                    if (allocationResult == 6){
                                        if (targetPointer == previousNumber1 && roundTwo == 2) allocationResult = 2;
                                        else if (targetPointer == previousNumber2 && roundTwo == 2) allocationResult = 3;
                                    }
                                    
                                    // cout<<"ALLC RESULT3 "<<allocationResult<<" "<<endl;
                                    
                                    errorNoHold = 31;
                                    int *arrayPreviousTableTemp = new int [lineNumberPrevious2*2+50];
                                    previousTableCountTemp = 0;
                                    errorNoHold = 32;
                                    int *arrayPreviousTotalTemp = new int [lineNumberPrevious2+50];
                                    previousTotalCountTemp = 0;
                                    
                                    errorNoHold = 33;
                                    double *arrayPreviousAverageTemp = new double [lineNumberPrevious2+50];
                                    previousAverageCountTemp = 0;
                                    
                                    errorNoHold = 34;
                                    int *arrayCurrentTableTemp = new int [lineNumberCurrent2*2+50];
                                    currentTableCountTemp = 0;
                                    errorNoHold = 35;
                                    int *arrayCurrentTotalTemp = new int [lineNumberCurrent2+50];
                                    currentTotalCountTemp = 0;
                                    
                                    errorNoHold = 36;
                                    double *arrayCurrentAverageTemp = new double [lineNumberCurrent2+50];
                                    currentAverageCountTemp = 0;
                                    
                                    //for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
                                    //   for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrevious [counterA*6+counterB];
                                    //    cout<<" arrayCellTrackingPrev "<<counterA<<endl;
                                    //}
                                    
                                    //+++++++++Allocation 4: Divide Current+++++++++
                                    if (allocationResult == 4 || allocationResult == 5){
                                        
                                        //cout<<"AL4_5_Div"<<" PrevNo1 "<<previousNumber1<<" PrevNo2 "<<previousNumber2<<endl;
                                        // cout<<p_variablesSet ->_targetPointer<<" Target_Current2 "<<targetPointer<<endl;
                                        
                                        //for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
                                        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrevious [counterA*6+counterB];
                                        //	cout<<" arrayCellTrackingPrevious "<<counterA<<endl;
                                        //}
                                        
                                        //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                                        //    for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingCurrentMap [counterA][counterB];
                                        //    cout<<" arrayCellTrackingCurrentMap "<<counterA<<endl;
                                        //}
                                        
                                        maxPointDimX = 0;
                                        maxPointDimY = 0;
                                        minPointDimX = 1000000;
                                        minPointDimY = 1000000;
                                        
                                        for (int counter2 = 0; counter2 < cellTrackingPreviousCount/6; counter2++){
                                            if (arrayCellTrackingPrevious [counter2*6+3] == previousNumber1 || arrayCellTrackingPrevious [counter2*6+3] == previousNumber2){
                                                if (maxPointDimX < arrayCellTrackingPrevious [counter2*6]) maxPointDimX = arrayCellTrackingPrevious [counter2*6];
                                                if (minPointDimX > arrayCellTrackingPrevious [counter2*6]) minPointDimX = arrayCellTrackingPrevious [counter2*6];
                                                if (maxPointDimY < arrayCellTrackingPrevious [counter2*6+1]) maxPointDimY = arrayCellTrackingPrevious [counter2*6+1];
                                                if (minPointDimY > arrayCellTrackingPrevious [counter2*6+1]) minPointDimY = arrayCellTrackingPrevious [counter2*6+1];
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < cellTrackingCurrentCount/6; counter2++){
                                            if (arrayCellTrackingCurrent [counter2*6+3] == currentConnectNumber1){
                                                if (maxPointDimX < arrayCellTrackingCurrent [counter2*6]) maxPointDimX = arrayCellTrackingCurrent [counter2*6];
                                                if (minPointDimX > arrayCellTrackingCurrent [counter2*6]) minPointDimX = arrayCellTrackingCurrent [counter2*6];
                                                if (maxPointDimY < arrayCellTrackingCurrent [counter2*6+1]) maxPointDimY = arrayCellTrackingCurrent [counter2*6+1];
                                                if (minPointDimY > arrayCellTrackingCurrent [counter2*6+1]) minPointDimY = arrayCellTrackingCurrent [counter2*6+1];
                                            }
                                        }
                                        
                                        dimensionTemp = 0;
                                        horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                                        verticalLength = (maxPointDimY-minPointDimY)/2*2;
                                        
                                        if (horizontalLength >= verticalLength) dimensionTemp = horizontalLength+30;
                                        if (horizontalLength < verticalLength) dimensionTemp = verticalLength+30;
                                        
                                        if (dimensionTemp < 128) dimensionTemp = 128;
                                        else dimensionTemp = (dimensionTemp/2)*2;
                                        
                                        horizontalStart2 = minPointDimX-(dimensionTemp-horizontalLength)/2;
                                        verticalStart2 = minPointDimY-(dimensionTemp-verticalLength)/2;
                                        
                                        errorNoHold = 37;
                                        int **connectivityUpdate = new int *[dimensionTemp+5];
                                        errorNoHold = 38;
                                        int **connectivityUpdate2 = new int *[dimensionTemp+5];
                                        errorNoHold = 39;
                                        int **connectivityUpdate3 = new int *[dimensionTemp+5];
                                        errorNoHold = 40;
                                        int **connectivityUpdate4 = new int *[dimensionTemp+5];
                                        errorNoHold = 41;
                                        int **connectivityUpdate5 = new int *[dimensionTemp+5];
                                        
                                        for (int counter2 = 0; counter2 < dimensionTemp+5; counter2++){
                                            errorNoHold = 42;
                                            connectivityUpdate [counter2] = new int [dimensionTemp+5];
                                            errorNoHold = 43;
                                            connectivityUpdate2 [counter2] = new int [dimensionTemp+5];
                                            errorNoHold = 44;
                                            connectivityUpdate3 [counter2] = new int [dimensionTemp+5];
                                            errorNoHold = 45;
                                            connectivityUpdate4 [counter2] = new int [dimensionTemp+5];
                                            errorNoHold = 46;
                                            connectivityUpdate5 [counter2] = new int [dimensionTemp+5];
                                        }
                                        
                                        for (int counterY = 0; counterY < dimensionTemp+5; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp+5; counterX++){
                                                connectivityUpdate [counterY][counterX] = 0;
                                                connectivityUpdate2 [counterY][counterX] = 0;
                                                connectivityUpdate3 [counterY][counterX] = 0;
                                                connectivityUpdate4 [counterY][counterX] = 0;
                                                connectivityUpdate5 [counterY][counterX] = 0;
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < cellTrackingCurrentCount/6; counter2++){
                                            if (arrayCellTrackingCurrent [counter2*6+3] == currentConnectNumber1){
                                                connectivityUpdate [arrayCellTrackingCurrent [counter2*6+1]-verticalStart2+1][arrayCellTrackingCurrent [counter2*6]-horizontalStart2+1] = 1;
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < dimensionTemp+2; counterA++){
                                        //	for (int counterB = 0; counterB < dimensionTemp+2; counterB++) cout<<" "<<connectivityUpdate [counterA][counterB];
                                        //	cout<<" connectivityUpdate2 "<<counterA<<endl;
                                        //}
                                        
                                        //for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
                                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrevious [counterA*6+counterB];
                                        //    cout<<" arrayCellTrackingPrevious "<<counterA<<" "<<endl;
                                        //}
                                        
                                        for (int counter2 = 0; counter2 < cellTrackingPreviousCount/6; counter2++){
                                            if (arrayCellTrackingPrevious [counter2*6+3] == previousNumber1){
                                                connectivityUpdate2 [arrayCellTrackingPrevious [counter2*6+1]-verticalStart2+1][arrayCellTrackingPrevious [counter2*6]-horizontalStart2+1] = 1;
                                            }
                                            
                                            if (arrayCellTrackingPrevious [counter2*6+3] == previousNumber2){
                                                connectivityUpdate3 [arrayCellTrackingPrevious [counter2*6+1]-verticalStart2+1][arrayCellTrackingPrevious [counter2*6]-horizontalStart2+1] = 1;
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < dimensionTemp+2; counterA++){
                                        //	for (int counterB = 0; counterB < dimensionTemp+2; counterB++) cout<<" "<<connectivityUpdate2 [counterA][counterB];
                                        //    cout<<" connectivityUpdate2 "<<counterA<<endl;
                                        //}
                                        
                                        //for (int counterA = 0; counterA < dimensionTemp+2; counterA++){
                                        //	for (int counterB = 0; counterB < dimensionTemp+2; counterB++) cout<<" "<<connectivityUpdate3 [counterA][counterB];
                                        //	cout<<" connectivityUpdate3 "<<counterA<<endl;
                                        //}
                                        
                                        errorNoHold = 47;
                                        int *connectAnalysisX = new int [(dimensionTemp+2)*4];
                                        errorNoHold = 48;
                                        int *connectAnalysisY = new int [(dimensionTemp+2)*4];
                                        errorNoHold = 49;
                                        int *connectAnalysisTempX = new int [(dimensionTemp+2)*4];
                                        errorNoHold = 50;
                                        int *connectAnalysisTempY = new int [(dimensionTemp+2)*4];
                                        
                                        connectivityNumber = 0;
                                        
                                        for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                if (connectivityUpdate [counterY][counterX] == 0){
                                                    connectivityNumber--;
                                                    connectivityUpdate [counterY][counterX] = connectivityNumber;
                                                    
                                                    connectAnalysisCount = 0;
                                                    
                                                    if (counterY-1 >= 0 && connectivityUpdate [counterY-1][counterX] == 0){
                                                        connectivityUpdate [counterY-1][counterX] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                    }
                                                    if (counterX+1 < dimensionTemp+2 && connectivityUpdate [counterY][counterX+1] == 0){
                                                        connectivityUpdate [counterY][counterX+1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                    }
                                                    if (counterY+1 < dimensionTemp+2 && connectivityUpdate [counterY+1][counterX] == 0){
                                                        connectivityUpdate [counterY+1][counterX] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                    }
                                                    if (counterX-1 >= 0 && connectivityUpdate [counterY][counterX-1] == 0){
                                                        connectivityUpdate [counterY][counterX-1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                    }
                                                    
                                                    if (connectAnalysisCount != 0){
                                                        do{
                                                            
                                                            terminationFlag = 1;
                                                            connectAnalysisTempCount = 0;
                                                            
                                                            for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                                xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                                
                                                                if (ySource-1 >= 0 && connectivityUpdate [ySource-1][xSource] == 0){
                                                                    connectivityUpdate [ySource-1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource+1 < dimensionTemp+2 && connectivityUpdate [ySource][xSource+1] == 0){
                                                                    connectivityUpdate [ySource][xSource+1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                                if (ySource+1 < dimensionTemp+2 && connectivityUpdate [ySource+1][xSource] == 0){
                                                                    connectivityUpdate [ySource+1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource-1 >= 0 && connectivityUpdate [ySource][xSource-1] == 0){
                                                                    connectivityUpdate [ySource][xSource-1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                            }
                                                            
                                                            for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                                connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                                            }
                                                            
                                                            connectAnalysisCount = connectAnalysisTempCount;
                                                            
                                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                                            
                                                        } while (terminationFlag == 1);
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (allocationResult == 4){
                                            for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                                for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                    if (connectivityUpdate [counterY][counterX] == -1) connectivityUpdate [counterY][counterX] = 0;
                                                    else connectivityUpdate [counterY][counterX] = -1;
                                                }
                                            }
                                        }
                                        else{
                                            
                                            for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                                for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                    if (connectivityUpdate [counterY][counterX] == -1) connectivityUpdate [counterY][counterX] = 0;
                                                    else{
                                                        
                                                        if (counterY+verticalStart2-1 >= 0 && counterY+verticalStart2-1 < imageDimension && counterX+horizontalStart2-1 >= 0 && counterX+horizontalStart2-1 < imageDimension){
                                                            if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2-1)*imageDimension+counterX+horizontalStart2-1] < cutOff2) connectivityUpdate [counterY][counterX] = -1;
                                                            else if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2-1)*imageDimension+counterX+horizontalStart2-1] >= cutOff2) connectivityUpdate [counterY][counterX] = -2;
                                                        }
                                                        else connectivityUpdate [counterY][counterX] = 0;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < dimensionTemp+2; counterA++){
                                        //	for (int counterB = 0; counterB < dimensionTemp+2; counterB++) cout<<" "<<connectivityUpdate [counterA][counterB];
                                        //	cout<<" connectivityUpdate "<<counterA<<endl;
                                        //}
                                        
                                        additionCount++;
                                        currentPairAddition++;
                                        
                                        connectivityNumber = 0;
                                        
                                        for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                if (connectivityUpdate2 [counterY][counterX] == 0){
                                                    connectivityNumber--;
                                                    connectivityUpdate2 [counterY][counterX] = connectivityNumber;
                                                    
                                                    connectAnalysisCount = 0;
                                                    
                                                    if (counterY-1 >= 0 && connectivityUpdate2 [counterY-1][counterX] == 0){
                                                        connectivityUpdate2 [counterY-1][counterX] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                    }
                                                    if (counterX+1 < dimensionTemp+2 && connectivityUpdate2 [counterY][counterX+1] == 0){
                                                        connectivityUpdate2 [counterY][counterX+1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                    }
                                                    if (counterY+1 < dimensionTemp+2 && connectivityUpdate2 [counterY+1][counterX] == 0){
                                                        connectivityUpdate2 [counterY+1][counterX] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                    }
                                                    if (counterX-1 >= 0 && connectivityUpdate2 [counterY][counterX-1] == 0){
                                                        connectivityUpdate2 [counterY][counterX-1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                    }
                                                    
                                                    if (connectAnalysisCount != 0){
                                                        do{
                                                            
                                                            terminationFlag = 1;
                                                            connectAnalysisTempCount = 0;
                                                            
                                                            for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                                xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                                
                                                                if (ySource-1 >= 0 && connectivityUpdate2 [ySource-1][xSource] == 0){
                                                                    connectivityUpdate2 [ySource-1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource+1 < dimensionTemp+2 && connectivityUpdate2 [ySource][xSource+1] == 0){
                                                                    connectivityUpdate2 [ySource][xSource+1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                                if (ySource+1 < dimensionTemp+2 && connectivityUpdate2 [ySource+1][xSource] == 0){
                                                                    connectivityUpdate2 [ySource+1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource-1 >= 0 && connectivityUpdate2 [ySource][xSource-1] == 0){
                                                                    connectivityUpdate2 [ySource][xSource-1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                            }
                                                            
                                                            for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                                connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                                            }
                                                            
                                                            connectAnalysisCount = connectAnalysisTempCount;
                                                            
                                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                                            
                                                        } while (terminationFlag == 1);
                                                    }
                                                }
                                            }
                                        }
                                        
                                        for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                if (connectivityUpdate2 [counterY][counterX] == -1) connectivityUpdate2 [counterY][counterX] = 0;
                                                else connectivityUpdate2 [counterY][counterX] = currentConnectNumber1;
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < dimensionTemp+2; counterA++){
                                        //	for (int counterB = 0; counterB < dimensionTemp+2; counterB++) cout<<" "<<connectivityUpdate2 [counterA][counterB];
                                        //	cout<<" connectivityUpdate2 "<<counterA<<endl;
                                        //}
                                        
                                        connectivityNumber = 0;
                                        
                                        for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                if (connectivityUpdate3 [counterY][counterX] == 0){
                                                    connectivityNumber--;
                                                    connectivityUpdate3 [counterY][counterX] = connectivityNumber;
                                                    
                                                    connectAnalysisCount = 0;
                                                    
                                                    if (counterY-1 >= 0 && connectivityUpdate3 [counterY-1][counterX] == 0){
                                                        connectivityUpdate3 [counterY-1][counterX] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                    }
                                                    if (counterX+1 < dimensionTemp+2 && connectivityUpdate3 [counterY][counterX+1] == 0){
                                                        connectivityUpdate3 [counterY][counterX+1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                    }
                                                    if (counterY+1 < dimensionTemp+2 && connectivityUpdate3 [counterY+1][counterX] == 0){
                                                        connectivityUpdate3 [counterY+1][counterX] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                    }
                                                    if (counterX-1 >= 0 && connectivityUpdate3 [counterY][counterX-1] == 0){
                                                        connectivityUpdate3 [counterY][counterX-1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                    }
                                                    
                                                    if (connectAnalysisCount != 0){
                                                        do{
                                                            
                                                            terminationFlag = 1;
                                                            connectAnalysisTempCount = 0;
                                                            
                                                            for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                                xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                                
                                                                if (ySource-1 >= 0 && connectivityUpdate3 [ySource-1][xSource] == 0){
                                                                    connectivityUpdate3 [ySource-1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource+1 < dimensionTemp+2 && connectivityUpdate3 [ySource][xSource+1] == 0){
                                                                    connectivityUpdate3 [ySource][xSource+1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                                if (ySource+1 < dimensionTemp+2 && connectivityUpdate3 [ySource+1][xSource] == 0){
                                                                    connectivityUpdate3 [ySource+1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource-1 >= 0 && connectivityUpdate3 [ySource][xSource-1] == 0){
                                                                    connectivityUpdate3 [ySource][xSource-1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                            }
                                                            
                                                            for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                                connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                                            }
                                                            
                                                            connectAnalysisCount = connectAnalysisTempCount;
                                                            
                                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                                            
                                                        } while (terminationFlag == 1);
                                                    }
                                                }
                                            }
                                        }
                                        
                                        for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                if (connectivityUpdate3 [counterY][counterX] == -1) connectivityUpdate3 [counterY][counterX] = 0;
                                                else connectivityUpdate3 [counterY][counterX] = lineNumberCurrent2+additionCount;
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < dimensionTemp+2; counterA++){
                                        //	for (int counterB = 0; counterB < dimensionTemp+2; counterB++) cout<<" "<<connectivityUpdate3 [counterA][counterB];
                                        //	cout<<" connectivityUpdate3 "<<counterA<<endl;
                                        //}
                                        
                                        for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                if (connectivityUpdate2 [counterY][counterX] != 0 && connectivityUpdate [counterY][counterX] < 0){
                                                    connectivityUpdate [counterY][counterX] = connectivityUpdate2 [counterY][counterX];
                                                }
                                                else if (connectivityUpdate3 [counterY][counterX] != 0 && connectivityUpdate [counterY][counterX] < 0){
                                                    connectivityUpdate [counterY][counterX] = connectivityUpdate3 [counterY][counterX];
                                                }
                                                
                                                connectivityUpdate3 [counterY][counterX] = 0;
                                                connectivityUpdate4 [counterY][counterX] = 0;
                                            }
                                        }
                                        
                                        for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                connectivityUpdate2 [counterY][counterX] = connectivityUpdate [counterY][counterX];
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < dimensionTemp; counterA++){
                                        //	for (int counterB = 0; counterB < dimensionTemp; counterB++) cout<<" "<<connectivityUpdate [counterA][counterB];
                                        //	cout<<" connectivityUpdate "<<counterA<<endl;
                                        //}
                                        
                                        // for (int counterA = 0; counterA < dimensionTemp; counterA++){
                                        // 	for (int counterB = 0; counterB < dimensionTemp; counterB++) cout<<" "<<connectivityUpdate2 [counterA][counterB];
                                        // 	cout<<" connectivityUpdate2 "<<counterA<<endl;
                                        // }
                                        
                                        //======Inside check=====
                                        errorNoHold = 51;
                                        int *insideCheck = new int [lineNumberCurrent2*2+5];
                                        
                                        for (int counter2 = 0; counter2 < lineNumberCurrent2*2+5; counter2++) insideCheck [counter2] = 0;
                                        
                                        for (int counterY = 1; counterY < dimensionTemp+1; counterY++){
                                            for (int counterX = 1; counterX < dimensionTemp+1; counterX++){
                                                if (counterY+verticalStart2-1 >= 0 && counterY+verticalStart2-1 < trackAreaSize && counterX+horizontalStart2-1 >= 0 && counterX+horizontalStart2-1 < trackAreaSize){
                                                    if (connectivityUpdate2 [counterY][counterX] != 0 && arrayCellTrackingCurrentMap [counterY+verticalStart2-1][counterX+horizontalStart2-1] != 0){
                                                        insideCheck [arrayCellTrackingCurrentMap [counterY+verticalStart2-1][counterX+horizontalStart2-1]*2]++;
                                                    }
                                                    else if (connectivityUpdate2 [counterY][counterX] == 0 && arrayCellTrackingCurrentMap [counterY+verticalStart2-1][counterX+horizontalStart2-1] != 0){
                                                        insideCheck [arrayCellTrackingCurrentMap [counterY+verticalStart2-1][counterX+horizontalStart2-1]*2+1]++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        insideCheck [currentConnectNumber1*2] = 0;
                                        
                                        insideFind = 0;
                                        
                                        for (int counter2 = 1; counter2 <= lineNumberCurrent2; counter2++){
                                            if (insideCheck [counter2*2] != 0 && insideCheck [counter2*2+1] == 0) insideFind = 1;
                                            else if (insideCheck [counter2*2] != 0 && insideCheck [counter2*2+1] != 0) insideCheck [counter2*2] = 0;
                                        }
                                        
                                        //for (int counter3 = 0; counter3 < lineNumberCurrent2; counter3++){
                                        //     cout<<counter3<<" "<<insideCheck [counter3*2]<<" "<<insideCheck [counter3*2+1]<<" inside"<<endl;
                                        // }
                                        
                                        if (insideFind == 1){
                                            errorNoHold = 52;
                                            int **connectivityUpdateInside = new int *[dimensionTemp+5];
                                            
                                            for (int counter2 = 0; counter2 < dimensionTemp+5; counter2++){
                                                errorNoHold = 53;
                                                connectivityUpdateInside [counter2] = new int [dimensionTemp+5];
                                            }
                                            
                                            for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                                for (int counterX = 0; counterX < dimensionTemp+2; counterX++) connectivityUpdateInside [counterY][counterX] = 0;
                                            }
                                            
                                            for (int counterY = 1; counterY < dimensionTemp+1; counterY++){
                                                for (int counterX = 1; counterX < dimensionTemp+1; counterX++){
                                                    if (counterY+verticalStart2-1 >= 0 && counterY+verticalStart2-1 < trackAreaSize && counterX+horizontalStart2-1 >= 0 && counterX+horizontalStart2-1 < trackAreaSize){
                                                        if (arrayCellTrackingCurrentMap [counterY+verticalStart2-1][counterX+horizontalStart2-1] != 0){
                                                            for (int counter2 = 1; counter2 <= lineNumberCurrent2; counter2++){
                                                                if (insideCheck [counter2*2] != 0 && arrayCellTrackingCurrentMap [counterY+verticalStart2-1][counterX+horizontalStart2-1] == counter2){
                                                                    connectivityUpdateInside [counterY][counterX] = 1;
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            // for (int counterA = 0; counterA < dimensionTemp+2; counterA++){
                                            //     for (int counterB = 0; counterB < dimensionTemp+2; counterB++) cout<<" "<<connectivityUpdateInside [counterA][counterB];
                                            //      cout<<" connectivityUpdateInside "<<counterA<<endl;
                                            //  }
                                            
                                            for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                                for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                    if (connectivityUpdateInside [counterY][counterX] == 1) connectivityUpdate2 [counterY][counterX] = 0;
                                                }
                                            }
                                            
                                            //for (int counterA = 0; counterA < dimensionTemp+2; counterA++){
                                            //    for (int counterB = 0; counterB < dimensionTemp+2; counterB++) cout<<" "<<connectivityUpdate2 [counterA][counterB];
                                            //    cout<<" connectivityUpdate2 "<<counterA<<endl;
                                            //}
                                            
                                            for (int counter2 = 0; counter2 < dimensionTemp+5; counter2++) delete [] connectivityUpdateInside [counter2];
                                            
                                            delete [] connectivityUpdateInside;
                                        }
                                        
                                        delete [] insideCheck;
                                        //============================================
                                        
                                        highSideNumber = 0;
                                        
                                        if (highSide == 1) highSideNumber = currentConnectNumber1;
                                        else if (highSide == 2) highSideNumber = lineNumberCurrent2+additionCount;
                                        
                                        terminationFlag = 0;
                                        startOrder = 0;
                                        
                                        errorNoHold = 54;
                                        int *extendConnectList2 = new int [6];
                                        extendConnectList2 [0] = currentConnectNumber1;
                                        extendConnectList2 [1] = 0;
                                        extendConnectList2 [2] = lineNumberCurrent2+additionCount;
                                        extendConnectList2 [3] = 0;
                                        
                                        extendConnectCount2 = 4;
                                        
                                        do{
                                            
                                            for (int counter2 = startOrder; counter2 < extendConnectCount2/2; counter2++){
                                                connectNo = extendConnectList2 [counter2*2];
                                                
                                                if (extendConnectList2 [counter2*2+1] == 0){
                                                    findFreePoint = 0;
                                                    
                                                    for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                                        for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                            if (connectivityUpdate [counterY][counterX] == connectNo){
                                                                if (counterY-1 >= 0 && counterX-1 >= 0 && ((highSideNumber == 0 && connectivityUpdate [counterY-1][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY-1][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY-1][counterX-1] == -2))){
                                                                    connectivityUpdate2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                                                }
                                                                if (counterY-1 >= 0 && ((highSideNumber == 0 && connectivityUpdate [counterY-1][counterX] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY-1][counterX] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY-1][counterX] == -2))){
                                                                    connectivityUpdate2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                                                }
                                                                if (counterY-1 >= 0 && counterX+1 < dimensionTemp+2 && ((highSideNumber == 0 && connectivityUpdate [counterY-1][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY-1][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY-1][counterX+1] == -2))){
                                                                    connectivityUpdate2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                                                }
                                                                if (counterX+1 < dimensionTemp+2 && ((highSideNumber == 0 && connectivityUpdate [counterY][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY][counterX+1] == -2))){
                                                                    connectivityUpdate2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                                                }
                                                                if (counterY+1 < dimensionTemp+2 && counterX+1 < dimensionTemp+2 && ((highSideNumber == 0 && connectivityUpdate [counterY+1][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY+1][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY+1][counterX+1] == -2))){
                                                                    connectivityUpdate2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                                                }
                                                                if (counterY+1 < dimensionTemp+2 && ((highSideNumber == 0 && connectivityUpdate [counterY+1][counterX] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY+1][counterX] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY+1][counterX] == -2))){
                                                                    connectivityUpdate2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                                                }
                                                                if (counterY+1 < dimensionTemp+2 && counterX-1 >= 0 && ((highSideNumber == 0 && connectivityUpdate [counterY+1][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY+1][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY+1][counterX-1] == -2))){
                                                                    connectivityUpdate2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                                                }
                                                                if (counterX-1 >= 0 && ((highSideNumber == 0 && connectivityUpdate [counterY][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY][counterX-1] == -2))){
                                                                    connectivityUpdate2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                                                }
                                                            }
                                                        }
                                                    }
                                                    
                                                    for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                                        for (int counterX = 0; counterX < dimensionTemp+2; counterX++) connectivityUpdate [counterY][counterX] = connectivityUpdate2 [counterY][counterX];
                                                    }
                                                    
                                                    if (findFreePoint == 0) extendConnectList2 [counter2*2+1] = 1;
                                                }
                                            }
                                            
                                            for (int counter2 = 0; counter2 < startOrder; counter2++){
                                                connectNo = extendConnectList2 [counter2*2];
                                                
                                                if (extendConnectList2 [counter2*2+1] == 0){
                                                    findFreePoint = 0;
                                                    
                                                    for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                                        for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                            if (connectivityUpdate [counterY][counterX] == connectNo){
                                                                if (counterY-1 >= 0 && counterX-1 >= 0 && ((highSideNumber == 0 && connectivityUpdate [counterY-1][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY-1][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY-1][counterX-1] == -2))){
                                                                    connectivityUpdate2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                                                }
                                                                if (counterY-1 >= 0  && ((highSideNumber == 0 && connectivityUpdate [counterY-1][counterX] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY-1][counterX] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY-1][counterX] == -2))){
                                                                    connectivityUpdate2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                                                }
                                                                if (counterY-1 >= 0 && counterX+1 < dimensionTemp+2 && ((highSideNumber == 0 && connectivityUpdate [counterY-1][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY-1][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY-1][counterX+1] == -2))){
                                                                    connectivityUpdate2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                                                }
                                                                if (counterX+1 < dimensionTemp+2 && ((highSideNumber == 0 && connectivityUpdate [counterY][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY][counterX+1] == -2))){
                                                                    connectivityUpdate2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                                                }
                                                                if (counterY+1 < dimensionTemp+2 && counterX+1 < dimensionTemp+2 && ((highSideNumber == 0 && connectivityUpdate [counterY+1][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY+1][counterX+1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY+1][counterX+1] == -2))){
                                                                    connectivityUpdate2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                                                }
                                                                if (counterY+1 < dimensionTemp+2 && ((highSideNumber == 0 && connectivityUpdate [counterY+1][counterX] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY+1][counterX] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY+1][counterX] == -2))){
                                                                    connectivityUpdate2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                                                }
                                                                if (counterY+1 < dimensionTemp+2 && counterX-1 >= 0 && ((highSideNumber == 0 && connectivityUpdate [counterY+1][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY+1][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY+1][counterX-1] == -2))){
                                                                    connectivityUpdate2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                                                }
                                                                if (counterX-1 >= 0 && ((highSideNumber == 0 && connectivityUpdate [counterY][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber != connectNo && connectivityUpdate [counterY][counterX-1] == -1) || (highSideNumber != 0 && highSideNumber == connectNo && connectivityUpdate [counterY][counterX-1] == -2))){
                                                                    connectivityUpdate2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                                                }
                                                            }
                                                        }
                                                    }
                                                    
                                                    for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                                        for (int counterX = 0; counterX < dimensionTemp+2; counterX++) connectivityUpdate [counterY][counterX] = connectivityUpdate2 [counterY][counterX];
                                                    }
                                                    
                                                    if (findFreePoint == 0) extendConnectList2 [counter2*2+1] = 1;
                                                }
                                            }
                                            
                                            remainingCheck = 0;
                                            
                                            for (int counter2 = 0; counter2 < extendConnectCount2/2; counter2++){
                                                if (extendConnectList2 [counter2*2+1] == 0) remainingCheck = 1;
                                            }
                                            
                                            if (remainingCheck == 0) terminationFlag = 1;
                                            
                                            startOrder++;
                                            
                                            if (startOrder == extendConnectCount2/2) startOrder = 0;
                                            
                                        } while (terminationFlag == 0);
                                        
                                        delete [] extendConnectList2;
                                        
                                        connectPointNoCount1 = 0;
                                        connectPointNoCount2 = 0;
                                        
                                        for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                if (connectivityUpdate [counterY][counterX] == currentConnectNumber1) connectPointNoCount1++;
                                                if (connectivityUpdate [counterY][counterX] == lineNumberCurrent2+additionCount) connectPointNoCount2++;
                                            }
                                        }
                                        
                                        if (currentConnectNumber1 > 50 && connectPointNoCount2 > 50){
                                            prevPixelCount1 = 0;
                                            prevPixelCount2 = 0;
                                            gravityX1 = 0;
                                            gravityY1 = 0;
                                            gravityX2 = 0;
                                            gravityY2 = 0;
                                            
                                            //------Tracking Data Up-Date------
                                            errorNoHold = 55;
                                            int *arrayCellTrackingCurrentTemp = new int [cellTrackingCurrentCount+50];
                                            cellTrackingCurrentTempCount = 0;
                                            cellTrackingCurrentTempLimit = cellTrackingCurrentCount+50;
                                            
                                            for (int counter2 = 0; counter2 < cellTrackingCurrentCount/6; counter2++){
                                                if (arrayCellTrackingCurrent [counter2*6+3] != currentConnectNumber1){
                                                    arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter2*6], cellTrackingCurrentTempCount++;
                                                    arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter2*6+1], cellTrackingCurrentTempCount++;
                                                    arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter2*6+2], cellTrackingCurrentTempCount++;
                                                    arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter2*6+3], cellTrackingCurrentTempCount++;
                                                    arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter2*6+4], cellTrackingCurrentTempCount++;
                                                    arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter2*6+5], cellTrackingCurrentTempCount++;
                                                }
                                            }
                                            
                                            for (int counter2 = 0; counter2 < 2; counter2++){
                                                if (counter2 == 0) connectProcessNo = currentConnectNumber1;
                                                else connectProcessNo = lineNumberCurrent2+additionCount;
                                                
                                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                        if (connectivityUpdate [counterY][counterX] == connectProcessNo) connectivityUpdate2 [counterY][counterX] = connectProcessNo;
                                                        else connectivityUpdate2 [counterY][counterX] = 0;
                                                    }
                                                }
                                                
                                                //-------Zero Fill-------
                                                for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                    for (int counterY = 0; counterY < dimensionTemp+2; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
                                                }
                                                
                                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                        connectivityUpdate5 [counterY][counterX] = connectivityUpdate2 [counterY][counterX];
                                                    }
                                                }
                                                
                                                connectivityNumber = 0;
                                                
                                                for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                                    for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                        if (connectivityUpdate5 [counterY2][counterX2] == 0){
                                                            connectivityNumber--;
                                                            connectAnalysisCount = 0;
                                                            
                                                            connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                                                            
                                                            if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                                                                connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                                                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                                            }
                                                            if (counterX2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                                                connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                                                                connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                                            }
                                                            if (counterY2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                                                connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                                                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                                            }
                                                            if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                                                connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                                                                connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                                            }
                                                            
                                                            if (connectAnalysisCount != 0){
                                                                do{
                                                                    
                                                                    terminationFlag = 1;
                                                                    connectAnalysisTempCount = 0;
                                                                    
                                                                    for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                                        xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                                        
                                                                        if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                                                            connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                        }
                                                                        if (xSource+1 < dimensionTemp+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                                                            connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                        }
                                                                        if (ySource+1 < dimensionTemp+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                                                            connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                        }
                                                                        if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                                                            connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                        }
                                                                    }
                                                                    
                                                                    for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                                        connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                                    }
                                                                    
                                                                    connectAnalysisCount = connectAnalysisTempCount;
                                                                    
                                                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                                                    
                                                                } while (terminationFlag == 1);
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                if (connectivityNumber < -1){
                                                    errorNoHold = 56;
                                                    int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                                                    
                                                    for (int counter3 = 0; counter3 < connectivityNumber*-1*2+5; counter3++) connectCheckArray [counter3] = 0;
                                                    
                                                    for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                                        for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                            connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                                                            
                                                            if (connectTemp2 < -1){
                                                                connectTemp2 = connectTemp2*-1;
                                                                
                                                                if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                                }
                                                                if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                                                }
                                                                if (counterY2-1 >= 0 && counterX2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                                }
                                                                if (counterX2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                                }
                                                                if (counterY2+1 < dimensionTemp+2 && counterX2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                                }
                                                                if (counterY2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                                                }
                                                                if (counterY2+1 < dimensionTemp+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                                }
                                                                if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                                }
                                                            }
                                                        }
                                                    }
                                                    
                                                    zeroFillFlag = 0;
                                                    
                                                    for (int counter3 = 2; counter3 <= connectivityNumber*-1; counter3++){
                                                        if (connectCheckArray [counter3*2] != 0 &&  connectCheckArray [counter3*2+1] == 0) zeroFillFlag = 1;
                                                    }
                                                    
                                                    if (zeroFillFlag == 1){
                                                        for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                                            for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                                connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                                                                
                                                                if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                                                            }
                                                        }
                                                        
                                                        for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                                            for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                                if (connectivityUpdate5 [counterY2][counterX2] > 0) connectivityUpdate2 [counterY2][counterX2] = connectivityUpdate5 [counterY2][counterX2];
                                                            }
                                                        }
                                                    }
                                                    
                                                    delete [] connectCheckArray;
                                                }
                                                
                                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                        if (connectivityUpdate2 [counterY][counterX] != 0){
                                                            if (counterX+1 < dimensionTemp+2 && connectivityUpdate2 [counterY][counterX+1] == 0) connectivityUpdate2 [counterY][counterX] = -1;
                                                            else if (counterY+1 < dimensionTemp+2 && connectivityUpdate2 [counterY+1][counterX] == 0) connectivityUpdate2 [counterY][counterX] = -1;
                                                            else if (counterX-1 >= 0 && connectivityUpdate2 [counterY][counterX-1] == 0) connectivityUpdate2 [counterY][counterX] = -1;
                                                            else if (counterY-1 >= 0 && connectivityUpdate2 [counterY-1][counterX] == 0) connectivityUpdate2 [counterY][counterX] = -1;
                                                        }
                                                    }
                                                }
                                                
                                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                        if (connectivityUpdate2 [counterY][counterX] > 0) connectivityUpdate2 [counterY][counterX] = 0;
                                                        if (connectivityUpdate2 [counterY][counterX] < 0) connectivityUpdate2 [counterY][counterX] = 1;
                                                    }
                                                }
                                                
                                                connectivityNumber = 0;
                                                
                                                for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                                    for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                        if (connectivityUpdate2 [counterY2][counterX2] == 0){
                                                            connectivityNumber--;
                                                            connectAnalysisCount = 0;
                                                            
                                                            connectivityUpdate2 [counterY2][counterX2] = connectivityNumber;
                                                            
                                                            if (counterY2-1 >= 0 && connectivityUpdate2 [counterY2-1][counterX2] == 0){
                                                                connectivityUpdate2 [counterY2-1][counterX2] = connectivityNumber;
                                                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                                            }
                                                            if (counterX2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2][counterX2+1] == 0){
                                                                connectivityUpdate2 [counterY2][counterX2+1] = connectivityNumber;
                                                                connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                                            }
                                                            if (counterY2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2+1][counterX2] == 0){
                                                                connectivityUpdate2 [counterY2+1][counterX2] = connectivityNumber;
                                                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                                            }
                                                            if (counterX2-1 >= 0 && connectivityUpdate2 [counterY2][counterX2-1] == 0){
                                                                connectivityUpdate2 [counterY2][counterX2-1] = connectivityNumber;
                                                                connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                                            }
                                                            
                                                            if (connectAnalysisCount != 0){
                                                                do{
                                                                    
                                                                    terminationFlag = 1;
                                                                    connectAnalysisTempCount = 0;
                                                                    
                                                                    for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                                        xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                                        
                                                                        if (ySource-1 >= 0 && connectivityUpdate2 [ySource-1][xSource] == 0){
                                                                            connectivityUpdate2 [ySource-1][xSource] = connectivityNumber;
                                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                        }
                                                                        if (xSource+1 < dimensionTemp+2 && connectivityUpdate2 [ySource][xSource+1] == 0){
                                                                            connectivityUpdate2 [ySource][xSource+1] = connectivityNumber;
                                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                        }
                                                                        if (ySource+1 < dimensionTemp+2 && connectivityUpdate2 [ySource+1][xSource] == 0){
                                                                            connectivityUpdate2 [ySource+1][xSource] = connectivityNumber;
                                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                        }
                                                                        if (xSource-1 >= 0 && connectivityUpdate2 [ySource][xSource-1] == 0){
                                                                            connectivityUpdate2 [ySource][xSource-1] = connectivityNumber;
                                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                        }
                                                                    }
                                                                    
                                                                    for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                                        connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                                    }
                                                                    
                                                                    connectAnalysisCount = connectAnalysisTempCount;
                                                                    
                                                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                                                    
                                                                } while (terminationFlag == 1);
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                //------Determine number of pixels------
                                                connectivityNumber = connectivityNumber*-1;
                                                
                                                errorNoHold = 57;
                                                int *connectedPixels2 = new int [connectivityNumber+50];
                                                
                                                for (int counter3 = 0; counter3 < connectivityNumber+50; counter3++) connectedPixels2 [counter3] = 0;
                                                
                                                for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                                    for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                        if (connectivityUpdate2 [counterY2][counterX2] < -1) connectedPixels2 [connectivityUpdate2 [counterY2][counterX2]*-1]++;
                                                    }
                                                }
                                                
                                                for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                                    for (int counterX = 0; counterX < dimensionTemp+2; counterX++) connectivityUpdate5 [counterY][counterX] = 0;
                                                }
                                                
                                                largestConnect = 0;
                                                largestConnectNo = 0;
                                                
                                                for (int counter3 = 2; counter3 <= connectivityNumber; counter3++){
                                                    if (connectedPixels2 [counter3] > largestConnect){
                                                        largestConnect = connectedPixels2 [counter3];
                                                        largestConnectNo = counter3;
                                                    }
                                                }
                                                
                                                delete [] connectedPixels2;
                                                
                                                if (largestConnect > 20){
                                                    for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                                        for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                            if (connectivityUpdate2 [counterY2][counterX2] == largestConnectNo*-1){
                                                                if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate2 [counterY2-1][counterX2-1] == 1){
                                                                    connectivityUpdate5 [counterY2-1][counterX2-1] = 1;
                                                                    connectivityUpdate2 [counterY2-1][counterX2-1] = 0;
                                                                }
                                                                if (counterY2-1 >= 0 && connectivityUpdate2 [counterY2-1][counterX2] == 1){
                                                                    connectivityUpdate5 [counterY2-1][counterX2] = 1;
                                                                    connectivityUpdate2 [counterY2-1][counterX2] = 0;
                                                                }
                                                                if (counterY2-1 >= 0 && counterX2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2-1][counterX2+1] == 1){
                                                                    connectivityUpdate5 [counterY2-1][counterX2+1] = 1;
                                                                    connectivityUpdate2 [counterY2-1][counterX2+1] = 0;
                                                                }
                                                                if (counterX2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2][counterX2+1] == 1){
                                                                    connectivityUpdate5 [counterY2][counterX2+1] = 1;
                                                                    connectivityUpdate2 [counterY2][counterX2+1] = 0;
                                                                }
                                                                if (counterY2+1 < dimensionTemp+2 && counterX2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2+1][counterX2+1] == 1){
                                                                    connectivityUpdate5 [counterY2+1][counterX2+1] = 1;
                                                                    connectivityUpdate2 [counterY2+1][counterX2+1] = 0;
                                                                }
                                                                if (counterY2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2+1][counterX2] == 1){
                                                                    connectivityUpdate5 [counterY2+1][counterX2] = 1;
                                                                    connectivityUpdate2 [counterY2+1][counterX2] = 0;
                                                                }
                                                                if (counterY2+1 < dimensionTemp+2 && counterX2-1 >= 0 && connectivityUpdate2 [counterY2+1][counterX2-1] == 1){
                                                                    connectivityUpdate5 [counterY2+1][counterX2-1] = 1;
                                                                    connectivityUpdate2 [counterY2+1][counterX2-1] = 0;
                                                                }
                                                                if (counterX2-1 >= 0 && connectivityUpdate2 [counterY2][counterX2-1] == 1){
                                                                    connectivityUpdate5 [counterY2][counterX2-1] = 1;
                                                                    connectivityUpdate2 [counterY2][counterX2-1] = 0;
                                                                }
                                                            }
                                                        }
                                                    }
                                                    
                                                    xPositionTempStart = 0;
                                                    yPositionTempStart = 0;
                                                    lineSize = 0;
                                                    
                                                    for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                                        for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                            if (connectivityUpdate5 [counterY2][counterX2] == 1){
                                                                connectivityUpdate2 [counterY2][counterX2] = 1;
                                                                
                                                                xPositionTempStart = counterX2;
                                                                yPositionTempStart = counterY2;
                                                                lineSize++;
                                                            }
                                                            else connectivityUpdate2 [counterY2][counterX2] = 0;
                                                        }
                                                    }
                                                    
                                                    constructedLineCount = 0;
                                                    
                                                    errorNoHold = 58;
                                                    int *arrayNewLines = new int [lineSize*2+50];
                                                    
                                                    connectivityUpdate2 [yPositionTempStart][xPositionTempStart] = -1;
                                                    arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                                    arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                                    
                                                    do{
                                                        
                                                        findFlag = 0;
                                                        terminationFlag = 0;
                                                        
                                                        if (xPositionTempStart+1 < dimensionTemp+2){
                                                            if (connectivityUpdate2 [yPositionTempStart][xPositionTempStart+1] == 1){
                                                                connectivityUpdate2 [yPositionTempStart][xPositionTempStart+1] = -1;
                                                                arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                                                arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                                                xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                                            }
                                                        }
                                                        if (xPositionTempStart+1 < dimensionTemp+2 && yPositionTempStart+1 < dimensionTemp+2 && findFlag == 0){
                                                            if (connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                                                                connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                                                                arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                                                arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                                                xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                                            }
                                                        }
                                                        if (yPositionTempStart+1 < dimensionTemp+2 && findFlag == 0){
                                                            if (connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart] == 1){
                                                                connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart] = -1;
                                                                arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                                                arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                                                yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                                            }
                                                        }
                                                        if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimensionTemp+2 && findFlag == 0){
                                                            if (connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                                                                connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                                                                arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                                                arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                                                xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                                            }
                                                        }
                                                        if (xPositionTempStart-1 >= 0 && findFlag == 0){
                                                            if (connectivityUpdate2 [yPositionTempStart][xPositionTempStart-1] == 1){
                                                                connectivityUpdate2 [yPositionTempStart][xPositionTempStart-1] = -1;
                                                                arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                                                arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                                                xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                                            }
                                                        }
                                                        if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                                                            if (connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                                                                connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                                                                arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                                                arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                                                xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                                            }
                                                        }
                                                        if (yPositionTempStart-1 >= 0 && findFlag == 0){
                                                            if (connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart] == 1){
                                                                connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart] = -1;
                                                                arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                                                arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                                                yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                                            }
                                                        }
                                                        if (xPositionTempStart+1 < dimensionTemp+2 && yPositionTempStart-1 >= 0 && findFlag == 0){
                                                            if (connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                                                                connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                                                                arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                                                arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                                                xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                                                            }
                                                        }
                                                        
                                                    } while (terminationFlag == 1);
                                                    
                                                    //===========
                                                    //int aa = arrayNewLines [0]-1;
                                                    //int bb = arrayNewLines [1]-1;
                                                    
                                                    //int cc = arrayNewLines [(constructedLineCount/2-1)*2]-1;
                                                    //int dd = arrayNewLines [(constructedLineCount/2-1)*2+1]-1;
                                                    
                                                    //int findLink = 0;
                                                    
                                                    //if (cc-1 == aa && dd-1 == bb) findLink = 1;
                                                    //else  if (cc == aa && dd-1 == bb) findLink = 1;
                                                    //else  if (cc+1 == aa && dd-1 == bb) findLink = 1;
                                                    //else  if (cc+1 == aa && dd == bb) findLink = 1;
                                                    //else  if (cc+1 == aa && dd+1 == bb) findLink = 1;
                                                    //else  if (cc == aa && dd+1 == bb) findLink = 1;
                                                    //else  if (cc-1 == aa && dd+1 == bb) findLink = 1;
                                                    //else  if (cc-1 == aa && dd == bb) findLink = 1;
                                                    
                                                    //if (findLink == 0){
                                                    //    for (int counterA = 0; counterA < dimensionTemp+2; counterA++){
                                                    //        for (int counterB = 0; counterB < dimensionTemp+2; counterB++) cout<<" "<<connectivityUpdate2 [counterA][counterB];
                                                    //        cout<<" connectivityUpdate2 "<<counterA<<endl;
                                                    //    }
                                                    //}
                                                    //==========
                                                    
                                                    errorNoHold = 59;
                                                    int *arrayUpDate = new int [cellTrackingCurrentTempCount+10];
                                                    
                                                    for (int counter3 = 0; counter3 < cellTrackingCurrentTempCount; counter3++) arrayUpDate [counter3] = arrayCellTrackingCurrentTemp [counter3];
                                                    
                                                    delete [] arrayCellTrackingCurrentTemp;
                                                    errorNoHold = 60;
                                                    arrayCellTrackingCurrentTemp = new int [cellTrackingCurrentTempLimit+constructedLineCount*3+50];
                                                    cellTrackingCurrentTempLimit = cellTrackingCurrentTempLimit+constructedLineCount*3+50;
                                                    
                                                    for (int counter3 = 0; counter3 < cellTrackingCurrentTempCount; counter3++) arrayCellTrackingCurrentTemp [counter3] = arrayUpDate [counter3];
                                                    delete [] arrayUpDate;
                                                    
                                                    if (counter2 == 0){
                                                        for (int counter3 = 0; counter3 < constructedLineCount/2; counter3++){
                                                            connectivityUpdate3 [arrayNewLines [counter3*2+1]-1][arrayNewLines [counter3*2]-1] = 1;
                                                            
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayNewLines [counter3*2]-1+horizontalStart2, cellTrackingCurrentTempCount++;
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayNewLines [counter3*2+1]-1+verticalStart2, cellTrackingCurrentTempCount++;
                                                            
                                                            if (arrayNewLines [counter3*2+1]-1+verticalStart2 >= 0 && arrayNewLines [counter3*2+1]-1+verticalStart2 < imageDimension && arrayNewLines [counter3*2]-1+horizontalStart2 >= 0 && arrayNewLines [counter3*2]-1+horizontalStart2 < imageDimension){
                                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = sourceImage [mapPositionPointerCurrent][(arrayNewLines [counter3*2+1]-1+verticalStart2)*imageDimension+arrayNewLines [counter3*2]-1+horizontalStart2], cellTrackingCurrentTempCount++;
                                                            }
                                                            else arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 100, cellTrackingCurrentTempCount++;
                                                            
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = currentConnectNumber1, cellTrackingCurrentTempCount++;
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 0, cellTrackingCurrentTempCount++;
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 0, cellTrackingCurrentTempCount++;
                                                        }
                                                        
                                                        //for (int counterA = 0; counterA < cellTrackingCurrentCount/6; counterA++){
                                                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrent [counterA*6+counterB];
                                                        //    cout<<" arrayCellTrackingCurrent "<<counterA<<endl;
                                                        //}
                                                        
                                                        connectivityNumber = -3;
                                                        
                                                        for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                                            for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                                                if (connectivityUpdate3 [counterY][counterX] == 0){
                                                                    connectivityNumber = connectivityNumber+2;
                                                                    connectAnalysisCount = 0;
                                                                    
                                                                    if (connectivityNumber >= 1) connectivityNumber = 1, connectivityUpdate3 [counterY][counterX] = connectivityNumber;
                                                                    
                                                                    if (counterY-1 >= 0 &&  connectivityUpdate3 [counterY-1][counterX] == 0){
                                                                        connectivityUpdate3 [counterY-1][counterX] = connectivityNumber;
                                                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                                    }
                                                                    if (counterX+1 < dimensionTemp &&  connectivityUpdate3 [counterY][counterX+1] == 0){
                                                                        connectivityUpdate3 [counterY][counterX+1] = connectivityNumber;
                                                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                                    }
                                                                    if (counterY+1 < dimensionTemp &&  connectivityUpdate3 [counterY+1][counterX] == 0){
                                                                        connectivityUpdate3 [counterY+1][counterX] = connectivityNumber;
                                                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                                    }
                                                                    if (counterX-1 >= 0 &&  connectivityUpdate3 [counterY][counterX-1] == 0){
                                                                        connectivityUpdate3 [counterY][counterX-1] = connectivityNumber;
                                                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                                    }
                                                                    
                                                                    if (connectAnalysisCount != 0){
                                                                        do{
                                                                            
                                                                            terminationFlag = 1;
                                                                            connectAnalysisTempCount = 0;
                                                                            
                                                                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                                                xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                                                
                                                                                if (ySource-1 >= 0 &&  connectivityUpdate3 [ySource-1][xSource] == 0){
                                                                                    connectivityUpdate3 [ySource-1][xSource] = connectivityNumber;
                                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                                }
                                                                                if (xSource+1 < dimensionTemp &&  connectivityUpdate3 [ySource][xSource+1] == 0){
                                                                                    connectivityUpdate3 [ySource][xSource+1] = connectivityNumber;
                                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                                }
                                                                                if (ySource+1 < dimensionTemp &&  connectivityUpdate3 [ySource+1][xSource] == 0){
                                                                                    connectivityUpdate3 [ySource+1][xSource] = connectivityNumber;
                                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                                }
                                                                                if (xSource-1 >= 0 &&  connectivityUpdate3 [ySource][xSource-1] == 0){
                                                                                    connectivityUpdate3 [ySource][xSource-1] = connectivityNumber;
                                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                                }
                                                                            }
                                                                            
                                                                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                                                connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                                            }
                                                                            
                                                                            connectAnalysisCount = connectAnalysisTempCount;
                                                                            
                                                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                                                            
                                                                        } while (terminationFlag == 1);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        
                                                        for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                                            for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                                                if (connectivityUpdate3 [counterY][counterX] == -1) connectivityUpdate3 [counterY][counterX] = 0;
                                                            }
                                                        }
                                                        
                                                        gravityTempX = 0;
                                                        gravityTempY = 0;
                                                        
                                                        for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                                            for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                                                if (connectivityUpdate3 [counterY][counterX] == 1){
                                                                    gravityTempX = gravityTempX+counterX;
                                                                    gravityTempY = gravityTempY+counterY;
                                                                    prevPixelCount1++;
                                                                }
                                                            }
                                                        }
                                                        
                                                        gravityX1 = (int)(gravityTempX/(double)prevPixelCount1)+horizontalStart2;
                                                        gravityY1 = (int)(gravityTempY/(double)prevPixelCount1)+verticalStart2;
                                                    }
                                                    else if (counter2 == 1){
                                                        for (int counter3 = 0; counter3 < constructedLineCount/2; counter3++){
                                                            connectivityUpdate4 [arrayNewLines [counter3*2+1]-1][arrayNewLines [counter3*2]-1] = 1;
                                                            
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayNewLines [counter3*2]-1+horizontalStart2, cellTrackingCurrentTempCount++;
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayNewLines [counter3*2+1]-1+verticalStart2, cellTrackingCurrentTempCount++;
                                                            
                                                            if (arrayNewLines [counter3*2+1]-1+verticalStart2 >= 0 && arrayNewLines [counter3*2+1]-1+verticalStart2 < imageDimension && arrayNewLines [counter3*2]-1+horizontalStart2 >= 0 && arrayNewLines [counter3*2]-1+horizontalStart2 < imageDimension){
                                                                arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = sourceImage [mapPositionPointerCurrent][(arrayNewLines [counter3*2+1]-1+verticalStart2)*imageDimension+arrayNewLines [counter3*2]-1+horizontalStart2], cellTrackingCurrentTempCount++;
                                                            }
                                                            else arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 100, cellTrackingCurrentTempCount++;
                                                            
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = lineNumberCurrent2+additionCount, cellTrackingCurrentTempCount++;
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 0, cellTrackingCurrentTempCount++;
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = 0, cellTrackingCurrentTempCount++;
                                                        }
                                                        
                                                        connectivityNumber = -3;
                                                        
                                                        for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                                            for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                                                if (connectivityUpdate4 [counterY][counterX] == 0){
                                                                    connectivityNumber = connectivityNumber+2;
                                                                    connectAnalysisCount = 0;
                                                                    
                                                                    if (connectivityNumber >= 1) connectivityNumber = 1, connectivityUpdate4 [counterY][counterX] = connectivityNumber;
                                                                    
                                                                    if (counterY-1 >= 0 &&   connectivityUpdate4 [counterY-1][counterX] == 0){
                                                                        connectivityUpdate4 [counterY-1][counterX] = connectivityNumber;
                                                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                                    }
                                                                    if (counterX+1 < dimensionTemp &&   connectivityUpdate4 [counterY][counterX+1] == 0){
                                                                        connectivityUpdate4 [counterY][counterX+1] = connectivityNumber;
                                                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                                    }
                                                                    if (counterY+1 < dimensionTemp &&   connectivityUpdate4 [counterY+1][counterX] == 0){
                                                                        connectivityUpdate4 [counterY+1][counterX] = connectivityNumber;
                                                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                                    }
                                                                    if (counterX-1 >= 0 &&   connectivityUpdate4 [counterY][counterX-1] == 0){
                                                                        connectivityUpdate4 [counterY][counterX-1] = connectivityNumber;
                                                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                                    }
                                                                    
                                                                    if (connectAnalysisCount != 0){
                                                                        do{
                                                                            
                                                                            terminationFlag = 1;
                                                                            connectAnalysisTempCount = 0;
                                                                            
                                                                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                                                xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                                                
                                                                                if (ySource-1 >= 0 &&   connectivityUpdate4 [ySource-1][xSource] == 0){
                                                                                    connectivityUpdate4 [ySource-1][xSource] = connectivityNumber;
                                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                                }
                                                                                if (xSource+1 < dimensionTemp &&   connectivityUpdate4 [ySource][xSource+1] == 0){
                                                                                    connectivityUpdate4 [ySource][xSource+1] = connectivityNumber;
                                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                                }
                                                                                if (ySource+1 < dimensionTemp &&   connectivityUpdate4 [ySource+1][xSource] == 0){
                                                                                    connectivityUpdate4 [ySource+1][xSource] = connectivityNumber;
                                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                                }
                                                                                if (xSource-1 >= 0 &&   connectivityUpdate4 [ySource][xSource-1] == 0){
                                                                                    connectivityUpdate4 [ySource][xSource-1] = connectivityNumber;
                                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                                }
                                                                            }
                                                                            
                                                                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                                                connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                                            }
                                                                            
                                                                            connectAnalysisCount = connectAnalysisTempCount;
                                                                            
                                                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                                                            
                                                                        } while (terminationFlag == 1);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        
                                                        for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                                            for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                                                if (connectivityUpdate4 [counterY][counterX] == -1) connectivityUpdate4 [counterY][counterX] = 0;
                                                            }
                                                        }
                                                        
                                                        gravityTempX = 0;
                                                        gravityTempY = 0;
                                                        
                                                        for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                                            for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                                                if (connectivityUpdate4 [counterY][counterX] == 1){
                                                                    gravityTempX = gravityTempX+counterX;
                                                                    gravityTempY = gravityTempY+counterY;
                                                                    prevPixelCount2++;
                                                                }
                                                            }
                                                        }
                                                        
                                                        gravityX2 = (int)(gravityTempX/(double)prevPixelCount2)+horizontalStart2;
                                                        gravityY2 = (int)(gravityTempY/(double)prevPixelCount2)+verticalStart2;
                                                    }
                                                    
                                                    delete [] arrayNewLines;
                                                }
                                            }
                                            
                                            //cout<<prevPixelCount1<<" "<<prevPixelCount2 <<" prevConnect"<<endl;
                                            
                                            //------Abort Type 2, process------
                                            if (prevPixelCount1 > 40 && prevPixelCount2 > 40){
                                                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                                        if (arrayCellTrackingCurrentMap [counterY][counterX] == currentConnectNumber1) arrayCellTrackingCurrentMap [counterY][counterX] = 0;
                                                    }
                                                }
                                                
                                                for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                                    for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                                        if (counterY+verticalStart2-verticalStart >= 0 && counterY+verticalStart2-verticalStart < trackAreaSize && counterX+horizontalStart2-horizontalStart >= 0 && counterX+horizontalStart2-horizontalStart < trackAreaSize){
                                                            if (connectivityUpdate3 [counterY][counterX] == 1) arrayCellTrackingCurrentMap [counterY+verticalStart2-verticalStart][counterX+horizontalStart2-horizontalStart] = currentConnectNumber1;
                                                            if (connectivityUpdate4 [counterY][counterX] == 1) arrayCellTrackingCurrentMap [counterY+verticalStart2-verticalStart][counterX+horizontalStart2-horizontalStart] = lineNumberCurrent2+additionCount;
                                                        }
                                                    }
                                                }
                                                
                                                if (cellTrackingCurrentStatus == 0){
                                                    errorNoHold = 61;
                                                    arrayCellTrackingCurrent = new int [cellTrackingCurrentTempCount*3+50];
                                                    cellTrackingCurrentCount = 0;
                                                    cellTrackingCurrentStatus = 1;
                                                    cellTrackingCurrentSizeHold = cellTrackingCurrentTempCount*3+50;
                                                }
                                                else if (cellTrackingCurrentStatus == 1 && cellTrackingCurrentSizeHold < cellTrackingCurrentTempCount){
                                                    delete [] arrayCellTrackingCurrent;
                                                    
                                                    errorNoHold = 62;
                                                    arrayCellTrackingCurrent = new int [cellTrackingCurrentTempCount*3+50];
                                                    cellTrackingCurrentCount = 0;
                                                    cellTrackingCurrentSizeHold = cellTrackingCurrentTempCount*3+50;
                                                }
                                                else cellTrackingCurrentCount = 0;
                                                
                                                for (int counter2 = 0; counter2 < cellTrackingCurrentTempCount; counter2++) arrayCellTrackingCurrent [cellTrackingCurrentCount] = arrayCellTrackingCurrentTemp [counter2], cellTrackingCurrentCount++;
                                                
                                                //------Tracking Data Sort------
                                                delete [] arrayCellTrackingCurrentTemp;
                                                errorNoHold = 63;
                                                arrayCellTrackingCurrentTemp = new int [cellTrackingCurrentCount+50];
                                                cellTrackingCurrentTempCount = 0;
                                                
                                                for (int counter2 = 1; counter2 < lineNumberCurrent2+additionCount+1; counter2++){
                                                    for (int counter3 = 0; counter3 < cellTrackingCurrentCount/6; counter3++){
                                                        if (arrayCellTrackingCurrent [counter3*6+3] == counter2){
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter3*6], cellTrackingCurrentTempCount++;
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter3*6+1], cellTrackingCurrentTempCount++;
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter3*6+2], cellTrackingCurrentTempCount++;
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter3*6+3], cellTrackingCurrentTempCount++;
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter3*6+4], cellTrackingCurrentTempCount++;
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayCellTrackingCurrent [counter3*6+5], cellTrackingCurrentTempCount++;
                                                        }
                                                    }
                                                }
                                                
                                                cellTrackingCurrentCount = 0;
                                                for (int counter2 = 0; counter2 < cellTrackingCurrentTempCount; counter2++) arrayCellTrackingCurrent [cellTrackingCurrentCount] = arrayCellTrackingCurrentTemp [counter2], cellTrackingCurrentCount++;
                                                
                                                //------Map Update, Table, Total, Average------
                                                currentPointLine1 = 0;
                                                currentTotaLine1 = 0;
                                                currentPointLine2 = 0;
                                                currentTotaLine2 = 0;
                                                
                                                for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                                    for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                                        if (connectivityUpdate3 [counterY][counterX] != 0){
                                                            if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                                                                currentPointLine1++;
                                                                
                                                                if (connectivityUpdate3 [counterY][counterX] != 100){ //------Line one data get------
                                                                    currentTotaLine1 = currentTotaLine1+sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2];
                                                                }
                                                            }
                                                        }
                                                        
                                                        if (connectivityUpdate4 [counterY][counterX] != 0){
                                                            if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                                                                currentPointLine2++;
                                                                
                                                                if (connectivityUpdate4 [counterY][counterX] != 100){ //------Line Two data get------
                                                                    currentTotaLine2 = currentTotaLine2+sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2];
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                currentAverageLine1 = (int)(currentTotaLine1/(double)currentPointLine1);
                                                currentAverageLine2 = (int)(currentTotaLine2/(double)currentPointLine2);
                                                
                                                //cout<<currentAverageLine1<<" "<<currentTotaLine1<<" "<<currentPointLine1<<" AV/Total1"<<endl;
                                                //cout<<currentAverageLine2<<" "<<currentTotaLine2<<" "<<currentPointLine2<<" AV/Total2"<<endl;
                                                //cout<<" CurrNo1 "<<currentConnectNumber1<<" CurrNo1+Add "<<lineNumberCurrent2+additionCount<<" "<<additionCount<<endl;
                                                
                                                //------Table, Total Average Update------
                                                for (int counter2 = 1; counter2 < lineNumberCurrent2+1; counter2++){
                                                    if (counter2 != currentConnectNumber1){
                                                        arrayCurrentTableTemp [currentTableCountTemp] = arrayCurrentTableTrack [counter2*2], currentTableCountTemp++;
                                                        arrayCurrentTableTemp [currentTableCountTemp] = arrayCurrentTableTrack [counter2*2+1], currentTableCountTemp++;
                                                        arrayCurrentTotalTemp [currentTotalCountTemp] = (int)arrayCurrentTableTrackTotal [counter2], currentTotalCountTemp++;
                                                        arrayCurrentAverageTemp [currentAverageCountTemp] = arrayCurrentAverageTrack [counter2], currentAverageCountTemp++;
                                                        
                                                        //cout<<counter2<<" Pix "<<arrayCurrentTableTrack [counter2*2]<<" ConnNo "<<arrayCurrentTableTrack [counter2*2+1]<<" Total "<<arrayCurrentTableTrackTotal [counter2]<<" Average "<<arrayCurrentTableTrackTotal [counter2]<<" CURRTABLE_Prev Renw1"<<endl;
                                                    }
                                                    else{
                                                        
                                                        arrayCurrentTableTemp [currentTableCountTemp] = currentPointLine1, currentTableCountTemp++;
                                                        arrayCurrentTableTemp [currentTableCountTemp] = arrayCurrentTableTrack [counter2*2+1], currentTableCountTemp++;
                                                        arrayCurrentTotalTemp [currentTotalCountTemp] = currentTotaLine1, currentTotalCountTemp++;
                                                        arrayCurrentAverageTemp [currentAverageCountTemp] = currentAverageLine1, currentAverageCountTemp++;
                                                        
                                                        //cout<<counter2<<" Pix "<<currentPointLine1<<" ConnNo "<<arrayCurrentTableTrack [currentConnectNumber1*2+1]<<" Total "<<currentTotaLine1<<" Average "<<currentAverageLine1<<" CURRTABLE_Prev Renw1B"<<endl;
                                                    }
                                                }
                                                
                                                arrayCurrentTableTemp [currentTableCountTemp] = currentPointLine2, currentTableCountTemp++;
                                                arrayCurrentTableTemp [currentTableCountTemp] = lineNumberCurrent2+additionCount, currentTableCountTemp++;
                                                arrayCurrentTotalTemp [currentTotalCountTemp] = currentTotaLine2, currentTotalCountTemp++;
                                                arrayCurrentAverageTemp [currentAverageCountTemp] = currentAverageLine2, currentAverageCountTemp++;
                                                
                                                //cout<<" Pix "<<currentPointLine2<<" ConnNo "<<lineNumberCurrent2+additionCount<<" Total "<<currentTotaLine2<<" Average "<<currentAverageLine2<<" CURRTABLE_Prev Renw2"<<endl;
                                                
                                                //for (int counter2 = 0; counter2 < lineNumberCurrent2+1; counter2++){
                                                //    cout<<counter1<<" Pix "<<arrayCurrentTableTemp [counter2*2]<<" ConnNo "<<arrayCurrentTableTemp [counter2*2+1];
                                                //    cout<<" Total "<<arrayCurrentTotalTemp [counter2]<<" Average "<<arrayCurrentAverageTemp [counter2];
                                                //    cout<<" TABLE_CURRTEMP"<<endl;
                                                //}
                                                
                                                for (int counter2 = 1; counter2 < lineNumberCurrent2+2; counter2++){
                                                    if (currentConnectNumber1 == counter2) overlapSource [previousNumber2][counter2] = 0;
                                                    if (lineNumberCurrent2+additionCount == counter2) overlapSource [previousNumber2][counter2] = 1;
                                                }
                                                
                                                //for (int counterA = 0; counterA <cellTrackingCurrentAssCount/6; counterA++){
                                                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrentAss [counterA*6+counterB];
                                                //     cout<<" arrayAssociatedDataewererer "<<counterA<<endl;
                                                // }
                                                
                                                if (cellTrackingCurrentAssStatus == 0){
                                                    errorNoHold = 64;
                                                    arrayCellTrackingCurrentAss = new int [lineNumberCurrent2*18+50];
                                                    cellTrackingCurrentAssCount = 0;
                                                    cellTrackingCurrentAssStatus = 1;
                                                    cellTrackingCurrentAssSizeHold = lineNumberCurrent2*18+50;
                                                }
                                                else if (cellTrackingCurrentAssStatus == 1 && cellTrackingCurrentAssSizeHold < lineNumberCurrent2*6){
                                                    delete [] arrayCellTrackingCurrentAss;
                                                    
                                                    errorNoHold = 65;
                                                    arrayCellTrackingCurrentAss = new int [lineNumberCurrent2*18+50];
                                                    cellTrackingCurrentAssCount = 0;
                                                    cellTrackingCurrentAssSizeHold = lineNumberCurrent2*18+50;
                                                }
                                                else cellTrackingCurrentAssCount = 0;
                                                
                                                //------Associate Data Up-date------
                                                for (int counter2 = 1; counter2 < lineNumberCurrent2+1; counter2++){
                                                    arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = currentAssData [counter2][0], cellTrackingCurrentAssCount++;
                                                    arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = currentAssData [counter2][1], cellTrackingCurrentAssCount++;
                                                    arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = currentAssData [counter2][2], cellTrackingCurrentAssCount++;
                                                    arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = currentAssData [counter2][3], cellTrackingCurrentAssCount++;
                                                    arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = currentAssData [counter2][4], cellTrackingCurrentAssCount++;
                                                    arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = currentAssData [counter2][5], cellTrackingCurrentAssCount++;
                                                }
                                                
                                                arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = lineNumberCurrent2+additionCount, cellTrackingCurrentAssCount++;
                                                arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = currentAssData [currentConnectNumber1][1], cellTrackingCurrentAssCount++;
                                                arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = currentAssData [currentConnectNumber1][2], cellTrackingCurrentAssCount++;
                                                arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = currentPairAddition, cellTrackingCurrentAssCount++;
                                                arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = currentAssData [currentConnectNumber1][4]/2, cellTrackingCurrentAssCount++;
                                                arrayCellTrackingCurrentAss [cellTrackingCurrentAssCount] = 0, cellTrackingCurrentAssCount++;
                                                
                                                //------Gravity Center Update------
                                                delete [] arrayCellTrackingCurrentTemp;
                                                errorNoHold = 66;
                                                arrayCellTrackingCurrentTemp = new int [xyPositionCenterCurrentCount+50];
                                                cellTrackingCurrentTempCount = 0;
                                                
                                                for (int counter2 = 0; counter2 < xyPositionCenterCurrentCount/6; counter2++){
                                                    if (arrayXYPositionCenterCurrent [counter2*6+4] != currentConnectNumber1){
                                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter2*6], cellTrackingCurrentTempCount++;
                                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter2*6+1], cellTrackingCurrentTempCount++;
                                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter2*6+2], cellTrackingCurrentTempCount++;
                                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter2*6+3], cellTrackingCurrentTempCount++;
                                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter2*6+4], cellTrackingCurrentTempCount++;
                                                        arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter2*6+5], cellTrackingCurrentTempCount++;
                                                    }
                                                }
                                                
                                                if (xyPositionCenterCurrentStatus == 0){
                                                    errorNoHold = 67;
                                                    arrayXYPositionCenterCurrent = new int [cellTrackingCurrentTempCount*3+50];
                                                    xyPositionCenterCurrentCount = 0;
                                                    xyPositionCenterCurrentStatus = 1;
                                                    xyPositionCenterCurrentSizeHold = cellTrackingCurrentTempCount*3+50;
                                                }
                                                else if (xyPositionCenterCurrentStatus == 1 && xyPositionCenterCurrentSizeHold < cellTrackingCurrentTempCount){
                                                    delete [] arrayXYPositionCenterCurrent;
                                                    
                                                    errorNoHold = 68;
                                                    arrayXYPositionCenterCurrent = new int [cellTrackingCurrentTempCount*3+50];
                                                    xyPositionCenterCurrentCount = 0;
                                                    xyPositionCenterCurrentSizeHold = cellTrackingCurrentTempCount*3+50;
                                                }
                                                else xyPositionCenterCurrentCount = 0;
                                                
                                                for (int counter2 = 0; counter2 < cellTrackingCurrentTempCount; counter2++) arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = arrayCellTrackingCurrentTemp [counter2], xyPositionCenterCurrentCount++;
                                                
                                                arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = gravityX1, xyPositionCenterCurrentCount++;
                                                arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = gravityY1, xyPositionCenterCurrentCount++;
                                                arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = currentPointLine1, xyPositionCenterCurrentCount++;
                                                arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = currentAverageLine1, xyPositionCenterCurrentCount++;
                                                arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = currentConnectNumber1, xyPositionCenterCurrentCount++;
                                                arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = 0, xyPositionCenterCurrentCount++;
                                                
                                                arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = gravityX2, xyPositionCenterCurrentCount++;
                                                arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = gravityY2, xyPositionCenterCurrentCount++;
                                                arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = currentPointLine2, xyPositionCenterCurrentCount++;
                                                arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = currentAverageLine2, xyPositionCenterCurrentCount++;
                                                arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = lineNumberCurrent2+additionCount, xyPositionCenterCurrentCount++;
                                                arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = 0, xyPositionCenterCurrentCount++;
                                                
                                                delete [] arrayCellTrackingCurrentTemp;
                                                errorNoHold = 69;
                                                arrayCellTrackingCurrentTemp = new int [xyPositionCenterCurrentCount+50];
                                                cellTrackingCurrentTempCount = 0;
                                                
                                                //------Data Sort------
                                                for (int counter2 = 1; counter2 < lineNumberCurrent2+additionCount+1; counter2++){
                                                    for (int counter3 = 0; counter3 < xyPositionCenterCurrentCount/6; counter3++){
                                                        if (arrayXYPositionCenterCurrent [counter3*6+4] == counter2){
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter3*6], cellTrackingCurrentTempCount++;
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter3*6+1], cellTrackingCurrentTempCount++;
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter3*6+2], cellTrackingCurrentTempCount++;
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter3*6+3], cellTrackingCurrentTempCount++;
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter3*6+4], cellTrackingCurrentTempCount++;
                                                            arrayCellTrackingCurrentTemp [cellTrackingCurrentTempCount] = arrayXYPositionCenterCurrent [counter3*6+5], cellTrackingCurrentTempCount++;
                                                        }
                                                    }
                                                }
                                                
                                                xyPositionCenterCurrentCount = 0;
                                                for (int counter2 = 0; counter2 < cellTrackingCurrentTempCount; counter2++) arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = arrayCellTrackingCurrentTemp [counter2], xyPositionCenterCurrentCount++;
                                                
                                                delete [] arrayCellTrackingCurrentTemp;
                                                
                                                //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
                                                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
                                                //    cout<<" xyPositionCenterCurrentCountPR "<<counterA<<endl;
                                                //}
                                                
                                                //------Group Table update------
                                                typeSubArray = 2;
                                                tableInterpretation = [[TableInterpretation alloc] init];
                                                [tableInterpretation interpretationFirst:typeSubArray];
                                                
                                                do{
                                                } while (subCompletionFlag3 == 1);
                                                
                                                if (errorNoHold != 0){
                                                    errorNoHold = errorNoHold+2000;
                                                    throw errorCheckThrow;
                                                }
                                            }
                                            else{
                                                
                                                additionCount--;
                                                currentPairAddition--;
                                                
                                                if (processType == 3){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2;
                                                    else allocationResult = 3;
                                                }
                                                if (processType == 1){
                                                    if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2;
                                                    else allocationResult = 3;
                                                }
                                                
                                                delete [] arrayCellTrackingCurrentTemp;
                                            }
                                        }
                                        else{
                                            
                                            additionCount--;
                                            currentPairAddition--;
                                            
                                            if (processType == 3){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2;
                                                else allocationResult = 3;
                                            }
                                            if (processType == 1){
                                                if (overlapAreaTable [previousNumber1][currentPositionA1] > overlapAreaTable [previousNumber2][currentPositionB1]) allocationResult = 2;
                                                else allocationResult = 3;
                                            }
                                            
                                            //cout<<processType<<" "<<allocationResult<<" "<<previousNumber1<<" "<<previousNumber2<<" "<<overlapAreaTable [previousNumber1][currentPositionA1]<<" "<<overlapAreaTable [previousNumber2][currentPositionB1]<<" data"<<endl;
                                        }
                                        
                                        for (int counter2 = 0; counter2 < dimensionTemp+5; counter2++){
                                            delete [] connectivityUpdate [counter2];
                                            delete [] connectivityUpdate2 [counter2];
                                            delete [] connectivityUpdate3 [counter2];
                                            delete [] connectivityUpdate4 [counter2];
                                            delete [] connectivityUpdate5 [counter2];
                                        }
                                        
                                        delete [] connectivityUpdate;
                                        delete [] connectivityUpdate2;
                                        delete [] connectivityUpdate3;
                                        delete [] connectivityUpdate4;
                                        delete [] connectivityUpdate5;
                                        
                                        delete [] connectAnalysisX;
                                        delete [] connectAnalysisY;
                                        delete [] connectAnalysisTempX;
                                        delete [] connectAnalysisTempY;
                                    }
                                    
                                    //+++++++++Allocation 1: Fuse Previous++++++++++
                                    if (allocationResult == 1){
                                        
                                        //cout<<"AL_1_Fuse "<<" PrevNo1 "<<previousNumber1<<" PrevNo2 "<<previousNumber2<<endl;
                                        
                                        maxPointDimX = 0;
                                        maxPointDimY = 0;
                                        minPointDimX = 1000000;
                                        minPointDimY = 1000000;
                                        
                                        for (int counter2 = 0; counter2 < cellTrackingPreviousCount/6; counter2++){
                                            if (arrayCellTrackingPrevious [counter2*6+3] == previousNumber1 || arrayCellTrackingPrevious [counter2*6+3] == previousNumber2){
                                                if (maxPointDimX < arrayCellTrackingPrevious [counter2*6]) maxPointDimX = arrayCellTrackingPrevious [counter2*6];
                                                if (minPointDimX > arrayCellTrackingPrevious [counter2*6]) minPointDimX = arrayCellTrackingPrevious [counter2*6];
                                                if (maxPointDimY < arrayCellTrackingPrevious [counter2*6+1]) maxPointDimY = arrayCellTrackingPrevious [counter2*6+1];
                                                if (minPointDimY > arrayCellTrackingPrevious [counter2*6+1]) minPointDimY = arrayCellTrackingPrevious [counter2*6+1];
                                            }
                                        }
                                        
                                        dimensionTemp = 0;
                                        horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                                        verticalLength = (maxPointDimY-minPointDimY)/2*2;
                                        
                                        if (horizontalLength >= verticalLength) dimensionTemp = horizontalLength+30;
                                        if (horizontalLength < verticalLength) dimensionTemp = verticalLength+30;
                                        
                                        if (dimensionTemp < 128) dimensionTemp = 128;
                                        else dimensionTemp = (dimensionTemp/2)*2;
                                        
                                        horizontalStart2 = minPointDimX-(dimensionTemp-horizontalLength)/2;
                                        verticalStart2 = minPointDimY-(dimensionTemp-verticalLength)/2;
                                        
                                        errorNoHold = 70;
                                        int **connectivityUpdate = new int *[dimensionTemp+5];
                                        errorNoHold = 71;
                                        int **connectivityUpdate2 = new int *[dimensionTemp+5];
                                        errorNoHold = 72;
                                        int **connectivityUpdate3 = new int *[dimensionTemp+5];
                                        errorNoHold = 73;
                                        int **connectivityUpdate5 = new int *[dimensionTemp+5];
                                        errorNoHold = 74;
                                        int **connectivityUpdateInside = new int *[dimensionTemp+5];
                                        
                                        for (int counter2 = 0; counter2 < dimensionTemp+5; counter2++){
                                            errorNoHold = 75;
                                            connectivityUpdate [counter2] = new int [dimensionTemp+5];
                                            errorNoHold = 76;
                                            connectivityUpdate2 [counter2] = new int [dimensionTemp+5];
                                            errorNoHold = 77;
                                            connectivityUpdate3 [counter2] = new int [dimensionTemp+5];
                                            errorNoHold = 78;
                                            connectivityUpdate5 [counter2] = new int [dimensionTemp+5];
                                            errorNoHold = 79;
                                            connectivityUpdateInside [counter2] = new int [dimensionTemp+5];
                                        }
                                        
                                        for (int counterY = 0; counterY < dimensionTemp+5; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp+5; counterX++){
                                                connectivityUpdate [counterY][counterX] = 0;
                                                connectivityUpdate2 [counterY][counterX] = 0;
                                                connectivityUpdate3 [counterY][counterX] = 0;
                                                connectivityUpdate5 [counterY][counterX] = 0;
                                                connectivityUpdateInside [counterY][counterX] = 0;
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < cellTrackingPreviousCount/6; counter2++){
                                            if (arrayCellTrackingPrevious [counter2*6+3] == previousNumber1){
                                                connectivityUpdate [arrayCellTrackingPrevious [counter2*6+1]-verticalStart2+1][arrayCellTrackingPrevious [counter2*6]-horizontalStart2+1] = 1;
                                            }
                                            
                                            if (arrayCellTrackingPrevious [counter2*6+3] == previousNumber2){
                                                connectivityUpdate2 [arrayCellTrackingPrevious [counter2*6+1]-verticalStart2+1][arrayCellTrackingPrevious [counter2*6]-horizontalStart2+1] = 1;
                                            }
                                        }
                                        
                                        errorNoHold = 80;
                                        int *connectAnalysisX = new int [(dimensionTemp+2)*4];
                                        errorNoHold = 81;
                                        int *connectAnalysisY = new int [(dimensionTemp+2)*4];
                                        errorNoHold = 82;
                                        int *connectAnalysisTempX = new int [(dimensionTemp+2)*4];
                                        errorNoHold = 83;
                                        int *connectAnalysisTempY = new int [(dimensionTemp+2)*4];
                                        
                                        connectivityNumber = 0;
                                        
                                        for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                if (connectivityUpdate [counterY][counterX] == 0){
                                                    connectivityNumber--;
                                                    connectivityUpdate [counterY][counterX] = connectivityNumber;
                                                    
                                                    connectAnalysisCount = 0;
                                                    
                                                    if (counterY-1 >= 0 && connectivityUpdate [counterY-1][counterX] == 0){
                                                        connectivityUpdate [counterY-1][counterX] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                    }
                                                    if (counterX+1 < dimensionTemp+2 && connectivityUpdate [counterY][counterX+1] == 0){
                                                        connectivityUpdate [counterY][counterX+1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                    }
                                                    if (counterY+1 < dimensionTemp+2 && connectivityUpdate [counterY+1][counterX] == 0){
                                                        connectivityUpdate [counterY+1][counterX] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                    }
                                                    if (counterX-1 >= 0 && connectivityUpdate [counterY][counterX-1] == 0){
                                                        connectivityUpdate [counterY][counterX-1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                    }
                                                    
                                                    if (connectAnalysisCount != 0){
                                                        do{
                                                            
                                                            terminationFlag = 1;
                                                            connectAnalysisTempCount = 0;
                                                            
                                                            for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                                xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                                
                                                                if (ySource-1 >= 0 && connectivityUpdate [ySource-1][xSource] == 0){
                                                                    connectivityUpdate [ySource-1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource+1 < dimensionTemp+2 && connectivityUpdate [ySource][xSource+1] == 0){
                                                                    connectivityUpdate [ySource][xSource+1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                                if (ySource+1 < dimensionTemp+2 && connectivityUpdate [ySource+1][xSource] == 0){
                                                                    connectivityUpdate [ySource+1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource-1 >= 0 && connectivityUpdate [ySource][xSource-1] == 0){
                                                                    connectivityUpdate [ySource][xSource-1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                            }
                                                            
                                                            for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                                connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                                            }
                                                            
                                                            connectAnalysisCount = connectAnalysisTempCount;
                                                            
                                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                                            
                                                        } while (terminationFlag == 1);
                                                    }
                                                }
                                            }
                                        }
                                        
                                        for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                if (connectivityUpdate [counterY][counterX] == -1) connectivityUpdate [counterY][counterX] = 0;
                                                else connectivityUpdate [counterY][counterX] = 1;
                                            }
                                        }
                                        
                                        connectivityNumber = 0;
                                        
                                        for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                if (connectivityUpdate2 [counterY][counterX] == 0){
                                                    connectivityNumber--;
                                                    connectivityUpdate2 [counterY][counterX] = connectivityNumber;
                                                    
                                                    connectAnalysisCount = 0;
                                                    
                                                    if (counterY-1 >= 0 && connectivityUpdate2 [counterY-1][counterX] == 0){
                                                        connectivityUpdate2 [counterY-1][counterX] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                    }
                                                    if (counterX+1 < dimensionTemp+2 && connectivityUpdate2 [counterY][counterX+1] == 0){
                                                        connectivityUpdate2 [counterY][counterX+1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                    }
                                                    if (counterY+1 < dimensionTemp+2 && connectivityUpdate2 [counterY+1][counterX] == 0){
                                                        connectivityUpdate2 [counterY+1][counterX] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                    }
                                                    if (counterX-1 >= 0 && connectivityUpdate2 [counterY][counterX-1] == 0){
                                                        connectivityUpdate2 [counterY][counterX-1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                    }
                                                    
                                                    if (connectAnalysisCount != 0){
                                                        do{
                                                            
                                                            terminationFlag = 1;
                                                            connectAnalysisTempCount = 0;
                                                            
                                                            for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                                xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                                
                                                                if (ySource-1 >= 0 && connectivityUpdate2 [ySource-1][xSource] == 0){
                                                                    connectivityUpdate2 [ySource-1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource+1 < dimensionTemp+2 && connectivityUpdate2 [ySource][xSource+1] == 0){
                                                                    connectivityUpdate2 [ySource][xSource+1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                                if (ySource+1 < dimensionTemp+2 && connectivityUpdate2 [ySource+1][xSource] == 0){
                                                                    connectivityUpdate2 [ySource+1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource-1 >= 0 && connectivityUpdate2 [ySource][xSource-1] == 0){
                                                                    connectivityUpdate2 [ySource][xSource-1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                            }
                                                            
                                                            for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                                connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                                            }
                                                            
                                                            connectAnalysisCount = connectAnalysisTempCount;
                                                            
                                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                                            
                                                        } while (terminationFlag == 1);
                                                    }
                                                }
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < dimensionTemp+2; counterA++){
                                        //	for (int counterB = 0; counterB < dimensionTemp+2; counterB++) cout<<" "<<connectivityUpdate2 [counterA][counterB];
                                        //	cout<<" connectivityUpdate2 "<<counterA<<endl;
                                        //}
                                        
                                        for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                if (connectivityUpdate2 [counterY][counterX] == -1) connectivityUpdate2 [counterY][counterX] = 0;
                                                else connectivityUpdate2 [counterY][counterX] = 1;
                                            }
                                        }
                                        
                                        if (arrayPreviousTableTrack [previousNumber1*2] > arrayPreviousTableTrack [previousNumber2*2]){
                                            previousConnectNumberKeep = previousNumber1;
                                            previousConnectNumberAdd = previousNumber2;
                                        }
                                        else{
                                            
                                            previousConnectNumberKeep = previousNumber2;
                                            previousConnectNumberAdd = previousNumber1;
                                        }
                                        
                                        //cout<<" Keep "<<previousConnectNumberKeep<<" Add "<<previousConnectNumberAdd<<endl;
                                        
                                        arrayPreviousTableTrack [previousConnectNumberAdd*2] = arrayPreviousTableTrack [counter1*2];
                                        
                                        //------Map Update------
                                        for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                if (connectivityUpdate [counterY][counterX] == 1) connectivityUpdate2 [counterY][counterX] = 1;
                                            }
                                        }
                                        
                                        //-------Zero Fill-------
                                        for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                            for (int counterY = 0; counterY < dimensionTemp+2; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
                                        }
                                        
                                        for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                connectivityUpdate5 [counterY][counterX] = connectivityUpdate2 [counterY][counterX];
                                            }
                                        }
                                        
                                        connectivityNumber = 0;
                                        
                                        for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                            for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                if (connectivityUpdate5 [counterY2][counterX2] == 0){
                                                    connectivityNumber--;
                                                    connectAnalysisCount = 0;
                                                    
                                                    connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                                                    
                                                    if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                                                        connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                                    }
                                                    if (counterX2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                                        connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                                    }
                                                    if (counterY2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                                        connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                                    }
                                                    if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                                        connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                                    }
                                                    
                                                    if (connectAnalysisCount != 0){
                                                        do{
                                                            
                                                            terminationFlag = 1;
                                                            connectAnalysisTempCount = 0;
                                                            
                                                            for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                                xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                                
                                                                if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                                                    connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource+1 < dimensionTemp+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                                                    connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                                if (ySource+1 < dimensionTemp+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                                                    connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                                                    connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                            }
                                                            
                                                            for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                                connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                                            }
                                                            
                                                            connectAnalysisCount = connectAnalysisTempCount;
                                                            
                                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                                            
                                                        } while (terminationFlag == 1);
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (connectivityNumber < -1){
                                            errorNoHold = 84;
                                            int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                                            
                                            for (int counter2 = 0; counter2 < connectivityNumber*-1*2+5; counter2++) connectCheckArray [counter2] = 0;
                                            
                                            for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                                for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                    connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                                                    
                                                    if (connectTemp2 < -1){
                                                        connectTemp2 = connectTemp2*-1;
                                                        
                                                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                        }
                                                        if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                                        }
                                                        if (counterY2-1 >= 0 && counterX2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                        }
                                                        if (counterX2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                        }
                                                        if (counterY2+1 < dimensionTemp+2 && counterX2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                        }
                                                        if (counterY2+1 < dimensionTemp+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                                        }
                                                        if (counterY2+1 < dimensionTemp+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                        }
                                                        if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            zeroFillFlag = 0;
                                            
                                            for (int counter2 = 2; counter2 <= connectivityNumber*-1; counter2++){
                                                if (connectCheckArray [counter2*2] != 0 &&  connectCheckArray [counter2*2+1] == 0) zeroFillFlag = 1;
                                            }
                                            
                                            if (zeroFillFlag == 1){
                                                for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                                    for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                        connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                                                        
                                                        if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                                                    }
                                                }
                                                
                                                for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                                    for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                        if (connectivityUpdate5 [counterY2][counterX2] > 0) connectivityUpdate2 [counterY2][counterX2] = connectivityUpdate5 [counterY2][counterX2];
                                                    }
                                                }
                                            }
                                            
                                            delete [] connectCheckArray;
                                        }
                                        
                                        //======Inside check=====
                                        errorNoHold = 85;
                                        int *insideCheck = new int [lineNumberPrevious2*2+5];
                                        
                                        for (int counter2 = 0; counter2 < lineNumberPrevious2*2+5; counter2++) insideCheck [counter2] = 0;
                                        
                                        for (int counterY = 1; counterY < dimensionTemp+1; counterY++){
                                            for (int counterX = 1; counterX < dimensionTemp+1; counterX++){
                                                if (counterY+verticalStart2-1 >= 0 && counterY+verticalStart2-1 < trackAreaSize && counterX+horizontalStart2-1 >= 0 && counterX+horizontalStart2-1 < trackAreaSize){
                                                    if (connectivityUpdate2 [counterY][counterX] != 0 && arrayCellTrackingPreviousMap [counterY+verticalStart2-1][counterX+horizontalStart2-1] != 0){
                                                        insideCheck [arrayCellTrackingPreviousMap [counterY+verticalStart2-1][counterX+horizontalStart2-1]*2]++;
                                                    }
                                                    else if (connectivityUpdate2 [counterY][counterX] == 0 && arrayCellTrackingPreviousMap [counterY+verticalStart2-1][counterX+horizontalStart2-1] != 0){
                                                        insideCheck [arrayCellTrackingPreviousMap [counterY+verticalStart2-1][counterX+horizontalStart2-1]*2+1]++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        insideCheck [previousNumber1*2] = 0;
                                        insideCheck [previousNumber2*2] = 0;
                                        
                                        insideFind = 0;
                                        
                                        for (int counter2 = 1; counter2 <= lineNumberPrevious2; counter2++){
                                            if (insideCheck [counter2*2] != 0 && insideCheck [counter2*2+1] == 0) insideFind = 1;
                                            else if (insideCheck [counter2*2] != 0 && insideCheck [counter2*2+1] != 0) insideCheck [counter2*2] = 0;
                                        }
                                        
                                        if (insideFind == 1){
                                            for (int counterY = 1; counterY < dimensionTemp+1; counterY++){
                                                for (int counterX = 1; counterX < dimensionTemp+1; counterX++){
                                                    if (counterY+verticalStart2-1 >= 0 && counterY+verticalStart2-1 < trackAreaSize && counterX+horizontalStart2-1 >= 0 && counterX+horizontalStart2-1 < trackAreaSize){
                                                        if (arrayCellTrackingPreviousMap [counterY+verticalStart2-1][counterX+horizontalStart2-1] != 0){
                                                            for (int counter2 = 1; counter2 <= lineNumberPrevious2; counter2++){
                                                                if (insideCheck [counter2*2] != 0 && arrayCellTrackingPreviousMap [counterY+verticalStart2-1][counterX+horizontalStart2-1] == counter2){
                                                                    connectivityUpdateInside [counterY][counterX] = arrayCellTrackingPreviousMap [counterY+verticalStart2-1][counterX+horizontalStart2-1];
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                        delete [] insideCheck;
                                        
                                        for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                if (connectivityUpdate2 [counterY][counterX] != 0){
                                                    if (counterX+1 < dimensionTemp+2 && connectivityUpdate2 [counterY][counterX+1] == 0) connectivityUpdate2 [counterY][counterX] = -1;
                                                    else if (counterY+1 < dimensionTemp+2 && connectivityUpdate2 [counterY+1][counterX] == 0) connectivityUpdate2 [counterY][counterX] = -1;
                                                    else if (counterX-1 >= 0 && connectivityUpdate2 [counterY][counterX-1] == 0) connectivityUpdate2 [counterY][counterX] = -1;
                                                    else if (counterY-1 >= 0 && connectivityUpdate2 [counterY-1][counterX] == 0) connectivityUpdate2 [counterY][counterX] = -1;
                                                }
                                            }
                                        }
                                        
                                        for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp+2; counterX++){
                                                if (connectivityUpdate2 [counterY][counterX] > 0) connectivityUpdate2 [counterY][counterX] = 0;
                                                if (connectivityUpdate2 [counterY][counterX] < 0) connectivityUpdate2 [counterY][counterX] = 1;
                                            }
                                        }
                                        
                                        connectivityNumber = 0;
                                        
                                        for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                            for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                if (connectivityUpdate2 [counterY2][counterX2] == 0){
                                                    connectivityNumber--;
                                                    connectAnalysisCount = 0;
                                                    
                                                    connectivityUpdate2 [counterY2][counterX2] = connectivityNumber;
                                                    
                                                    if (counterY2-1 >= 0 && connectivityUpdate2 [counterY2-1][counterX2] == 0){
                                                        connectivityUpdate2 [counterY2-1][counterX2] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                                    }
                                                    if (counterX2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2][counterX2+1] == 0){
                                                        connectivityUpdate2 [counterY2][counterX2+1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                                    }
                                                    if (counterY2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2+1][counterX2] == 0){
                                                        connectivityUpdate2 [counterY2+1][counterX2] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                                    }
                                                    if (counterX2-1 >= 0 && connectivityUpdate2 [counterY2][counterX2-1] == 0){
                                                        connectivityUpdate2 [counterY2][counterX2-1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                                    }
                                                    
                                                    if (connectAnalysisCount != 0){
                                                        do{
                                                            
                                                            terminationFlag = 1;
                                                            connectAnalysisTempCount = 0;
                                                            
                                                            for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                                xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                                
                                                                if (ySource-1 >= 0 && connectivityUpdate2 [ySource-1][xSource] == 0){
                                                                    connectivityUpdate2 [ySource-1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource+1 < dimensionTemp+2 && connectivityUpdate2 [ySource][xSource+1] == 0){
                                                                    connectivityUpdate2 [ySource][xSource+1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                                if (ySource+1 < dimensionTemp+2 && connectivityUpdate2 [ySource+1][xSource] == 0){
                                                                    connectivityUpdate2 [ySource+1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource-1 >= 0 && connectivityUpdate2 [ySource][xSource-1] == 0){
                                                                    connectivityUpdate2 [ySource][xSource-1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                            }
                                                            
                                                            for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                                connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                                            }
                                                            
                                                            connectAnalysisCount = connectAnalysisTempCount;
                                                            
                                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                                            
                                                        } while (terminationFlag == 1);
                                                    }
                                                }
                                            }
                                        }
                                        
                                        //------Determine number of pixels------
                                        connectivityNumber = connectivityNumber*-1;
                                        
                                        errorNoHold = 86;
                                        int *connectedPixels2 = new int [connectivityNumber+50];
                                        
                                        for (int counter2 = 0; counter2 < connectivityNumber+50; counter2++) connectedPixels2 [counter2] = 0;
                                        
                                        for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                            for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                if (connectivityUpdate2 [counterY2][counterX2] < -1) connectedPixels2 [connectivityUpdate2 [counterY2][counterX2]*-1]++;
                                            }
                                        }
                                        
                                        for (int counterY = 0; counterY < dimensionTemp+2; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp+2; counterX++) connectivityUpdate5 [counterY][counterX] = 0;
                                        }
                                        
                                        largestConnect = 0;
                                        largestConnectNo = 0;
                                        
                                        for (int counter2 = 2; counter2 <= connectivityNumber; counter2++){
                                            if (connectedPixels2 [counter2] > largestConnect){
                                                largestConnect = connectedPixels2 [counter2];
                                                largestConnectNo = counter2;
                                            }
                                        }
                                        
                                        delete [] connectedPixels2;
                                        
                                        for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                            for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                if (connectivityUpdate2 [counterY2][counterX2] == largestConnectNo*-1){
                                                    if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate2 [counterY2-1][counterX2-1] == 1){
                                                        connectivityUpdate5 [counterY2-1][counterX2-1] = 1;
                                                        connectivityUpdate2 [counterY2-1][counterX2-1] = 0;
                                                    }
                                                    if (counterY2-1 >= 0 && connectivityUpdate2 [counterY2-1][counterX2] == 1){
                                                        connectivityUpdate5 [counterY2-1][counterX2] = 1;
                                                        connectivityUpdate2 [counterY2-1][counterX2] = 0;
                                                    }
                                                    if (counterY2-1 >= 0 && counterX2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2-1][counterX2+1] == 1){
                                                        connectivityUpdate5 [counterY2-1][counterX2+1] = 1;
                                                        connectivityUpdate2 [counterY2-1][counterX2+1] = 0;
                                                    }
                                                    if (counterX2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2][counterX2+1] == 1){
                                                        connectivityUpdate5 [counterY2][counterX2+1] = 1;
                                                        connectivityUpdate2 [counterY2][counterX2+1] = 0;
                                                    }
                                                    if (counterY2+1 < dimensionTemp+2 && counterX2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2+1][counterX2+1] == 1){
                                                        connectivityUpdate5 [counterY2+1][counterX2+1] = 1;
                                                        connectivityUpdate2 [counterY2+1][counterX2+1] = 0;
                                                    }
                                                    if (counterY2+1 < dimensionTemp+2 && connectivityUpdate2 [counterY2+1][counterX2] == 1){
                                                        connectivityUpdate5 [counterY2+1][counterX2] = 1;
                                                        connectivityUpdate2 [counterY2+1][counterX2] = 0;
                                                    }
                                                    if (counterY2+1 < dimensionTemp+2 && counterX2-1 >= 0 && connectivityUpdate2 [counterY2+1][counterX2-1] == 1){
                                                        connectivityUpdate5 [counterY2+1][counterX2-1] = 1;
                                                        connectivityUpdate2 [counterY2+1][counterX2-1] = 0;
                                                    }
                                                    if (counterX2-1 >= 0 && connectivityUpdate2 [counterY2][counterX2-1] == 1){
                                                        connectivityUpdate5 [counterY2][counterX2-1] = 1;
                                                        connectivityUpdate2 [counterY2][counterX2-1] = 0;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        xPositionTempStart = 0;
                                        yPositionTempStart = 0;
                                        lineSize = 0;
                                        
                                        for (int counterY2 = 0; counterY2 < dimensionTemp+2; counterY2++){
                                            for (int counterX2 = 0; counterX2 < dimensionTemp+2; counterX2++){
                                                if (connectivityUpdate5 [counterY2][counterX2] == 1){
                                                    connectivityUpdate2 [counterY2][counterX2] = 1;
                                                    
                                                    xPositionTempStart = counterX2;
                                                    yPositionTempStart = counterY2;
                                                    lineSize++;
                                                }
                                                else connectivityUpdate2 [counterY2][counterX2] = 0;
                                            }
                                        }
                                        
                                        constructedLineCount = 0;
                                        
                                        errorNoHold = 87;
                                        int *arrayNewLines = new int [lineSize*2+50];
                                        
                                        connectivityUpdate2 [yPositionTempStart][xPositionTempStart] = -1;
                                        arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                        arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                        
                                        do{
                                            
                                            findFlag = 0;
                                            terminationFlag = 0;
                                            
                                            if (xPositionTempStart+1 < dimensionTemp+2){
                                                if (connectivityUpdate2 [yPositionTempStart][xPositionTempStart+1] == 1){
                                                    connectivityUpdate2 [yPositionTempStart][xPositionTempStart+1] = -1;
                                                    arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                                    arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                                    xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                                }
                                            }
                                            if (xPositionTempStart+1 < dimensionTemp+2 && yPositionTempStart+1 < dimensionTemp+2 && findFlag == 0){
                                                if (connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                                                    connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                                                    arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                                    arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                                    xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                                }
                                            }
                                            if (yPositionTempStart+1 < dimensionTemp+2 && findFlag == 0){
                                                if (connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart] == 1){
                                                    connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart] = -1;
                                                    arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                                    arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                                    yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                                }
                                            }
                                            if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimensionTemp+2 && findFlag == 0){
                                                if (connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                                                    connectivityUpdate2 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                                                    arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                                    arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                                    xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                                }
                                            }
                                            if (xPositionTempStart-1 >= 0 && findFlag == 0){
                                                if (connectivityUpdate2 [yPositionTempStart][xPositionTempStart-1] == 1){
                                                    connectivityUpdate2 [yPositionTempStart][xPositionTempStart-1] = -1;
                                                    arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                                    arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                                    xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                                }
                                            }
                                            if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                                                if (connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                                                    connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                                                    arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                                    arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                                    xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                                }
                                            }
                                            if (yPositionTempStart-1 >= 0 && findFlag == 0){
                                                if (connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart] == 1){
                                                    connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart] = -1;
                                                    arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                                    arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                                    yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                                }
                                            }
                                            if (xPositionTempStart+1 < dimensionTemp+2 && yPositionTempStart-1 >= 0 && findFlag == 0){
                                                if (connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                                                    connectivityUpdate2 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                                                    arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                                    arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                                    xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                                                }
                                            }
                                            
                                        } while (terminationFlag == 1);
                                        
                                        //for (int counterA = 0; counterA < dimensionTemp+2; counterA++){
                                        //    for (int counterB = 0; counterB < dimensionTemp+2; counterB++) cout<<" "<<connectivityUpdate2 [counterA][counterB];
                                        //   cout<<" connectivityUpdate2 "<<counterA<<endl;
                                        //}
                                        
                                        //===========
                                        //int aa = arrayNewLines [0]-1;
                                        //int bb = arrayNewLines [1]-1;
                                        
                                        //int cc = arrayNewLines [(constructedLineCount/2-1)*2]-1;
                                        //int dd = arrayNewLines [(constructedLineCount/2-1)*2+1]-1;
                                        
                                        //int findLink = 0;
                                        
                                        //if (cc-1 == aa && dd-1 == bb) findLink = 1;
                                        //else  if (cc == aa && dd-1 == bb) findLink = 1;
                                        //else  if (cc+1 == aa && dd-1 == bb) findLink = 1;
                                        //else  if (cc+1 == aa && dd == bb) findLink = 1;
                                        //else  if (cc+1 == aa && dd+1 == bb) findLink = 1;
                                        //else  if (cc == aa && dd+1 == bb) findLink = 1;
                                        //else  if (cc-1 == aa && dd+1 == bb) findLink = 1;
                                        //else  if (cc-1 == aa && dd == bb) findLink = 1;
                                        
                                        //if (findLink == 0){
                                        //    for (int counterA = 0; counterA < dimensionTemp+2; counterA++){
                                        //        for (int counterB = 0; counterB < dimensionTemp+2; counterB++) cout<<" "<<connectivityUpdate2 [counterA][counterB];
                                        //        cout<<" connectivityUpdate2 "<<counterA<<endl;
                                        //    }
                                        //}
                                        //==========
                                        
                                        //------Tracking Data Up-Date------
                                        errorNoHold = 89;
                                        int *arrayCellTrackingPreviousTemp = new int [cellTrackingPreviousCount+constructedLineCount*3+50];
                                        cellTrackingPreviousTempCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < cellTrackingPreviousCount/6; counter2++){
                                            if (arrayCellTrackingPrevious [counter2*6+3] != previousConnectNumberKeep && arrayCellTrackingPrevious [counter2*6+3] != previousConnectNumberAdd){
                                                arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayCellTrackingPrevious [counter2*6], cellTrackingPreviousTempCount++;
                                                arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayCellTrackingPrevious [counter2*6+1], cellTrackingPreviousTempCount++;
                                                arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayCellTrackingPrevious [counter2*6+2], cellTrackingPreviousTempCount++;
                                                arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayCellTrackingPrevious [counter2*6+3], cellTrackingPreviousTempCount++;
                                                arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayCellTrackingPrevious [counter2*6+4], cellTrackingPreviousTempCount++;
                                                arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayCellTrackingPrevious [counter2*6+5], cellTrackingPreviousTempCount++;
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                                            connectivityUpdate3 [arrayNewLines [counter2*2+1]-1][arrayNewLines [counter2*2]-1] = 1;
                                            
                                            arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayNewLines [counter2*2]-1+horizontalStart2, cellTrackingPreviousTempCount++;
                                            arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayNewLines [counter2*2+1]-1+verticalStart2, cellTrackingPreviousTempCount++;
                                            
                                            if (arrayNewLines [counter2*2+1]-1+verticalStart2 >= 0 && arrayNewLines [counter2*2+1]-1+verticalStart2 < imageDimension && arrayNewLines [counter2*2]-1+horizontalStart2 >= 0 && arrayNewLines [counter2*2]-1+horizontalStart2 < imageDimension){
                                                arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = sourceImage [mapPositionPointer][(arrayNewLines [counter2*2+1]-1+verticalStart2)*imageDimension+arrayNewLines [counter2*2]-1+horizontalStart2], cellTrackingPreviousTempCount++;
                                            }
                                            else arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = 100, cellTrackingPreviousTempCount++;
                                            
                                            arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = previousConnectNumberKeep, cellTrackingPreviousTempCount++;
                                            arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = 0, cellTrackingPreviousTempCount++;
                                            arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = 0, cellTrackingPreviousTempCount++;
                                        }
                                        
                                        if (cellTrackingPreviousStatus == 0){
                                            errorNoHold = 90;
                                            arrayCellTrackingPrevious = new int [cellTrackingPreviousTempCount*3+50];
                                            cellTrackingPreviousCount = 0;
                                            cellTrackingPreviousStatus = 1;
                                            cellTrackingPreviousSizeHold = cellTrackingPreviousTempCount*3+50;
                                        }
                                        else if (cellTrackingPreviousStatus == 1 && cellTrackingPreviousSizeHold < cellTrackingPreviousTempCount){
                                            delete [] arrayCellTrackingPrevious;
                                            
                                            errorNoHold = 91;
                                            arrayCellTrackingPrevious = new int [cellTrackingPreviousTempCount*3+50];
                                            cellTrackingPreviousCount = 0;
                                            cellTrackingPreviousSizeHold = cellTrackingPreviousTempCount*3+50;
                                        }
                                        else cellTrackingPreviousCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < cellTrackingPreviousTempCount; counter2++) arrayCellTrackingPrevious [cellTrackingPreviousCount] = arrayCellTrackingPreviousTemp [counter2], cellTrackingPreviousCount++;
                                        
                                        delete [] arrayCellTrackingPreviousTemp;
                                        errorNoHold = 92;
                                        arrayCellTrackingPreviousTemp = new int [cellTrackingPreviousCount*2+50];
                                        cellTrackingPreviousTempCount = 0;
                                        
                                        for (int counter2 = 1; counter2 < lineNumberPrevious2+1; counter2++){
                                            for (int counter3 = 0; counter3 < cellTrackingPreviousCount/6; counter3++){
                                                if (arrayCellTrackingPrevious [counter3*6+3] == counter2){
                                                    arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayCellTrackingPrevious [counter3*6], cellTrackingPreviousTempCount++;
                                                    arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayCellTrackingPrevious [counter3*6+1], cellTrackingPreviousTempCount++;
                                                    arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayCellTrackingPrevious [counter3*6+2], cellTrackingPreviousTempCount++;
                                                    arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayCellTrackingPrevious [counter3*6+3], cellTrackingPreviousTempCount++;
                                                    arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayCellTrackingPrevious [counter3*6+4], cellTrackingPreviousTempCount++;
                                                    arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayCellTrackingPrevious [counter3*6+5], cellTrackingPreviousTempCount++;
                                                }
                                            }
                                        }
                                        
                                        if (cellTrackingPreviousStatus == 0){
                                            errorNoHold = 93;
                                            arrayCellTrackingPrevious = new int [cellTrackingPreviousTempCount*3+50];
                                            cellTrackingPreviousCount = 0;
                                            cellTrackingPreviousStatus = 1;
                                            cellTrackingPreviousSizeHold = cellTrackingPreviousTempCount*3+50;
                                        }
                                        else if (cellTrackingPreviousStatus == 1 && cellTrackingPreviousSizeHold < cellTrackingPreviousTempCount){
                                            delete [] arrayCellTrackingPrevious;
                                            
                                            errorNoHold = 94;
                                            arrayCellTrackingPrevious = new int [cellTrackingPreviousTempCount*3+50];
                                            cellTrackingPreviousCount = 0;
                                            cellTrackingPreviousSizeHold = cellTrackingPreviousTempCount*3+50;
                                        }
                                        else cellTrackingPreviousCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < cellTrackingPreviousTempCount; counter2++) arrayCellTrackingPrevious [cellTrackingPreviousCount] = arrayCellTrackingPreviousTemp [counter2], cellTrackingPreviousCount++;
                                        
                                        connectivityNumber = -3;
                                        
                                        for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                                if (connectivityUpdate3 [counterY][counterX] == 0){
                                                    connectivityNumber = connectivityNumber+2;
                                                    connectAnalysisCount = 0;
                                                    
                                                    if (connectivityNumber >= 1) connectivityNumber = 1, connectivityUpdate3 [counterY][counterX] = connectivityNumber;
                                                    
                                                    if (counterY-1 >= 0 &&  connectivityUpdate3 [counterY-1][counterX] == 0){
                                                        connectivityUpdate3 [counterY-1][counterX] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                    }
                                                    if (counterX+1 < dimensionTemp &&  connectivityUpdate3 [counterY][counterX+1] == 0){
                                                        connectivityUpdate3 [counterY][counterX+1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                    }
                                                    if (counterY+1 < dimensionTemp &&  connectivityUpdate3 [counterY+1][counterX] == 0){
                                                        connectivityUpdate3 [counterY+1][counterX] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                    }
                                                    if (counterX-1 >= 0 &&  connectivityUpdate3 [counterY][counterX-1] == 0){
                                                        connectivityUpdate3 [counterY][counterX-1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                    }
                                                    
                                                    if (connectAnalysisCount != 0){
                                                        do{
                                                            
                                                            terminationFlag = 1;
                                                            connectAnalysisTempCount = 0;
                                                            
                                                            for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                                xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                                
                                                                if (ySource-1 >= 0 &&  connectivityUpdate3 [ySource-1][xSource] == 0){
                                                                    connectivityUpdate3 [ySource-1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource+1 < dimensionTemp &&  connectivityUpdate3 [ySource][xSource+1] == 0){
                                                                    connectivityUpdate3 [ySource][xSource+1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                                if (ySource+1 < dimensionTemp &&  connectivityUpdate3 [ySource+1][xSource] == 0){
                                                                    connectivityUpdate3 [ySource+1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource-1 >= 0 &&  connectivityUpdate3 [ySource][xSource-1] == 0){
                                                                    connectivityUpdate3 [ySource][xSource-1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                            }
                                                            
                                                            for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                                connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                                            }
                                                            
                                                            connectAnalysisCount = connectAnalysisTempCount;
                                                            
                                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                                            
                                                        } while (terminationFlag == 1);
                                                    }
                                                }
                                            }
                                        }
                                        
                                        for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                                if (connectivityUpdate3 [counterY][counterX] == -1) connectivityUpdate3 [counterY][counterX] = 0;
                                            }
                                        }
                                        
                                        prevPixelCount1 = 0;
                                        gravityTempX = 0;
                                        gravityTempY = 0;
                                        
                                        for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                                if (connectivityUpdate3 [counterY][counterX] == 1){
                                                    gravityTempX = gravityTempX+counterX;
                                                    gravityTempY = gravityTempY+counterY;
                                                    prevPixelCount1++;
                                                }
                                            }
                                        }
                                        
                                        gravityX1 = (int)(gravityTempX/(double)prevPixelCount1)+horizontalStart2;
                                        gravityY1 = (int)(gravityTempY/(double)prevPixelCount1)+verticalStart2;
                                        
                                        delete [] arrayNewLines;
                                        delete [] connectAnalysisX;
                                        delete [] connectAnalysisY;
                                        delete [] connectAnalysisTempX;
                                        delete [] connectAnalysisTempY;
                                        
                                        //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                                        //	for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<connectivityUpdate [counterA][counterB];
                                        //	cout<<" connectivityUpdate "<<counterA<<endl;
                                        //}
                                        
                                        for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                            for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                                if (arrayCellTrackingPreviousMap [counterY][counterX] == previousConnectNumberKeep || arrayCellTrackingPreviousMap [counterY][counterX] == previousConnectNumberAdd) arrayCellTrackingPreviousMap [counterY][counterX] = 0;
                                            }
                                        }
                                        
                                        for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                                if (counterY+verticalStart2-verticalStart >= 0 && counterY+verticalStart2-verticalStart < trackAreaSize && counterX+horizontalStart2-horizontalStart >= 0 && counterX+horizontalStart2-horizontalStart < trackAreaSize){
                                                    if (connectivityUpdate3 [counterY][counterX] == 1) arrayCellTrackingPreviousMap [counterY+verticalStart2-verticalStart][counterX+horizontalStart2-horizontalStart] = previousConnectNumberKeep;
                                                }
                                            }
                                        }
                                        
                                        for (int counterY = 1; counterY < dimensionTemp+1; counterY++){
                                            for (int counterX = 1; counterX < dimensionTemp+1; counterX++){
                                                if (connectivityUpdateInside [counterY][counterX] != 0){
                                                    if (counterY+verticalStart2-1 >= 0 && counterY+verticalStart2-1 < trackAreaSize && counterX+horizontalStart2-1 >= 0 && counterX+horizontalStart2-1 < trackAreaSize){
                                                        arrayCellTrackingPreviousMap [counterY+verticalStart2-1][counterX+horizontalStart2-1] = connectivityUpdateInside [counterY][counterX];
                                                    }
                                                }
                                            }
                                        }
                                        
                                        //------Associate Data set------
                                        previousAssData [previousConnectNumberAdd][0] = 0;
                                        
                                        if ((previousAssData [previousConnectNumberKeep][1] == 0 && previousAssData [previousConnectNumberAdd][1] == 1) || (previousAssData [previousConnectNumberKeep][1] == 1 && previousAssData [previousConnectNumberAdd][1] == 0)){
                                            previousAssData [previousConnectNumberKeep][1] = 1;
                                        }
                                        else if ((previousAssData [previousConnectNumberKeep][1] == 0 && previousAssData [previousConnectNumberAdd][1] == 2) || (previousAssData [previousConnectNumberKeep][1] == 2 && previousAssData [previousConnectNumberAdd][1] == 0)){
                                            previousAssData [previousConnectNumberKeep][1] = 2;
                                        }
                                        else if ((previousAssData [previousConnectNumberKeep][1] == 1 && previousAssData [previousConnectNumberAdd][1] == 2) || (previousAssData [previousConnectNumberKeep][1] == 2 && previousAssData [previousConnectNumberAdd][1] == 1)){
                                            previousAssData [previousConnectNumberKeep][1] = 2;
                                        }
                                        
                                        if (previousAssData [previousConnectNumberKeep][3] != 0 && previousAssData [previousConnectNumberAdd][3] != 0){
                                            if (previousAssData [previousConnectNumberKeep][3] != previousAssData [previousConnectNumberAdd][3]){
                                                maxPairNumber = 0;
                                                
                                                for (int counter2 = 1; counter2 < lineNumberPrevious2+1; counter2++){
                                                    if (maxPairNumber < previousAssData [counter2][3]) maxPairNumber = previousAssData [counter2][3];
                                                }
                                                
                                                previousAssData [previousConnectNumberKeep][3] = maxPairNumber+1;
                                            }
                                        }
                                        else if (previousAssData [previousConnectNumberKeep][3] == 0 && previousAssData [previousConnectNumberAdd][3] != 0){
                                            previousAssData [previousConnectNumberKeep][3] = previousAssData [previousConnectNumberAdd][3];
                                        }
                                        
                                        if (previousAssData [previousConnectNumberKeep][2] == 0 && previousAssData [previousConnectNumberAdd][2] == 1) previousAssData [previousConnectNumberKeep][2] = 1;
                                        else if (previousAssData [previousConnectNumberKeep][2] == 0 && previousAssData [previousConnectNumberAdd][2] == 2) previousAssData [previousConnectNumberKeep][2] = 1;
                                        else if (previousAssData [previousConnectNumberKeep][2] == 1 && previousAssData [previousConnectNumberAdd][2] == 2) previousAssData [previousConnectNumberKeep][2] = 2;
                                        
                                        previousAssData [previousConnectNumberKeep][4] = previousAssData [previousConnectNumberKeep][4]+previousAssData [previousConnectNumberAdd][4];
                                        
                                        if (cellTrackingPreviousAssStatus == 0){
                                            errorNoHold = 95;
                                            arrayCellTrackingPreviousAss = new int [lineNumberPrevious2*18+100];
                                            cellTrackingPreviousAssCount = 0;
                                            cellTrackingPreviousAssStatus = 1;
                                            cellTrackingPreviousAssSizeHold = lineNumberPrevious2*18+100;
                                        }
                                        else if (cellTrackingPreviousAssStatus == 1 && cellTrackingPreviousAssSizeHold < lineNumberPrevious2*6){
                                            delete [] arrayCellTrackingPreviousAss;
                                            
                                            errorNoHold = 96;
                                            arrayCellTrackingPreviousAss = new int [lineNumberPrevious2*18+100];
                                            cellTrackingPreviousAssCount = 0;
                                            cellTrackingPreviousAssSizeHold = lineNumberPrevious2*18+100;
                                        }
                                        else cellTrackingPreviousAssCount = 0;
                                        
                                        for (int counter2 = 1; counter2 < lineNumberPrevious2+1; counter2++){
                                            arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = previousAssData [counter2][0], cellTrackingPreviousAssCount++;
                                            arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = previousAssData [counter2][1], cellTrackingPreviousAssCount++;
                                            arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = previousAssData [counter2][2], cellTrackingPreviousAssCount++;
                                            arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = previousAssData [counter2][3], cellTrackingPreviousAssCount++;
                                            arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = previousAssData [counter2][4], cellTrackingPreviousAssCount++;
                                            arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = previousAssData [counter2][5], cellTrackingPreviousAssCount++;
                                        }
                                        
                                        //------Target Update------
                                        if (targetPointer == previousConnectNumberAdd){
                                            targetPointer = previousConnectNumberKeep;
                                            
                                            targetMitosisCount = arrayGroupInfoPrevious [(previousConnectNumberAdd-1)*5+3];
                                            targetRoundCount = arrayGroupInfoPrevious [(previousConnectNumberAdd-1)*5+4];
                                        }
                                        else{
                                            
                                            targetMitosisCount = arrayGroupInfoPrevious [(previousConnectNumberAdd-1)*5+3];
                                            targetRoundCount = arrayGroupInfoPrevious [(targetPointer-1)*5+4];
                                        }
                                        
                                        //cout<<targetPointer<<"  Target-Fuse"<<endl;
                                        
                                        //------Table, Total, Average update------
                                        previousPointLine1 = 0;
                                        previousTotaLine1 = 0;
                                        
                                        for (int counterY = 0; counterY < dimensionTemp; counterY++){
                                            for (int counterX = 0; counterX < dimensionTemp; counterX++){
                                                if (connectivityUpdate3 [counterY][counterX] != 0){
                                                    if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                                                        previousPointLine1++;
                                                        
                                                        if (connectivityUpdate3 [counterY][counterX] != 100){ //------Line one data get------
                                                            previousTotaLine1 = previousTotaLine1+sourceImage [mapPositionPointer][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2];
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                        prevAverageLine1 = previousTotaLine1/(double)previousPointLine1;
                                        
                                        for (int counter2 = 1; counter2 < lineNumberPrevious2+1; counter2++){
                                            if (counter2 != previousConnectNumberKeep && counter2 != previousConnectNumberAdd){
                                                arrayPreviousTableTemp [previousTableCountTemp] = arrayPreviousTableTrack [counter2*2], previousTableCountTemp++;
                                                arrayPreviousTableTemp [previousTableCountTemp] = arrayPreviousTableTrack [counter2*2+1], previousTableCountTemp++;
                                                arrayPreviousTotalTemp [previousTotalCountTemp] = (int)arrayPreviousTableTrackTotal [counter2], previousTotalCountTemp++;
                                                arrayPreviousAverageTemp [previousAverageCountTemp] = arrayPreviousAverageTrack [counter2], previousAverageCountTemp++;
                                                
                                                //cout<<counter2<<" Pix "<<arrayPreviousTableTemp [counter2*2]<<" ConnNo "<<arrayPreviousTableTemp [counter2*2+1]<<" Total "<<arrayPreviousTotalTemp [counter2]<<" Average "<<arrayPreviousAverageTemp [counter2]<<" PREVTABLE-Prev1"<<endl;
                                            }
                                            else if (counter2 == previousConnectNumberKeep){
                                                arrayPreviousTableTemp [previousTableCountTemp] = previousPointLine1, previousTableCountTemp++;
                                                arrayPreviousTableTemp [previousTableCountTemp] = arrayPreviousTableTrack [previousConnectNumberKeep*2+1], previousTableCountTemp++;
                                                arrayPreviousTotalTemp [previousTotalCountTemp] = previousTotaLine1, previousTotalCountTemp++;
                                                arrayPreviousAverageTemp [previousAverageCountTemp] = prevAverageLine1, previousAverageCountTemp++;
                                                
                                                //cout<<counter2<<" Pix "<<previousPointLine1<<" ConnNo "<<arrayPreviousTableTemp [previousConnectNumberKeep*2+1]<<" Total "<<previousTotaLine1<<" Average "<<prevAverageLine1<<" PREVTABLE-Prev2"<<endl;
                                            }
                                            else{
                                                
                                                //------In the event that Connect is merged and connect number is removed, add original connect number in the [0]------
                                                //------put merged counterpart connect number*-1 in [1]------
                                                arrayPreviousTableTemp [previousTableCountTemp] = previousConnectNumberAdd, previousTableCountTemp++;
                                                arrayPreviousTableTemp [previousTableCountTemp] = arrayPreviousTableTrack [previousConnectNumberKeep*2+1]*-1, previousTableCountTemp++;
                                                arrayPreviousTotalTemp [previousTotalCountTemp] = 0, previousTotalCountTemp++;
                                                arrayPreviousAverageTemp [previousAverageCountTemp] = 0, previousAverageCountTemp++;
                                                
                                                //cout<<counter2<<" Pix "<<previousConnectNumberAdd<<" ConnNo "<<arrayPreviousTableTemp [previousConnectNumberKeep*2+1]*-1<<" Total "<<0<<" Average "<<0<<" PREVTABLE-Prev3"<<endl;
                                            }
                                        }
                                        
                                        for (int counterX = 0; counterX < maxTargetEntry; counterX++){
                                            matchFlag = 0;
                                            
                                            if (overlapNumberTable [previousConnectNumberAdd][counterX] > 0){
                                                for (int counterX2 = 0; counterX2 < maxTargetEntry; counterX2++){
                                                    if (overlapNumberTable [previousConnectNumberKeep][counterX2] == overlapNumberTable [previousConnectNumberAdd][counterX]){
                                                        overlapSource [previousConnectNumberAdd][overlapNumberTable [previousConnectNumberAdd][counterX]] = 0;
                                                        matchFlag = 1;
                                                    }
                                                }
                                                
                                                if (matchFlag == 0){
                                                    overlapSource [previousConnectNumberKeep][overlapNumberTable [previousConnectNumberAdd][counterX]] = 1;
                                                    overlapSource [previousConnectNumberAdd][overlapNumberTable [previousConnectNumberAdd][counterX]] = 0;
                                                }
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                                        //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                                        //}
                                        
                                        delete [] arrayCellTrackingPreviousTemp;
                                        errorNoHold = 97;
                                        arrayCellTrackingPreviousTemp = new int [xyPositionCenterPreviousCount+50];
                                        cellTrackingPreviousTempCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < xyPositionCenterPreviousCount/6; counter2++){
                                            if (arrayXYPositionCenterPrevious [counter2*6+4] != previousConnectNumberKeep){
                                                arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayXYPositionCenterPrevious [counter2*6], cellTrackingPreviousTempCount++;
                                                arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayXYPositionCenterPrevious [counter2*6+1], cellTrackingPreviousTempCount++;
                                                arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayXYPositionCenterPrevious [counter2*6+2], cellTrackingPreviousTempCount++;
                                                arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayXYPositionCenterPrevious [counter2*6+3], cellTrackingPreviousTempCount++;
                                                
                                                if (arrayXYPositionCenterPrevious [counter2*6+4] == previousConnectNumberAdd) arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = 0, cellTrackingPreviousTempCount++;
                                                else arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayXYPositionCenterPrevious [counter2*6+4], cellTrackingPreviousTempCount++;
                                                
                                                if (targetPointer == arrayXYPositionCenterPrevious [counter2*6+4]) arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = 1, cellTrackingPreviousTempCount++;
                                                else arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = 0, cellTrackingPreviousTempCount++;
                                            }
                                        }
                                        
                                        if (xyPositionCenterPreviousStatus == 0){
                                            errorNoHold = 98;
                                            arrayXYPositionCenterPrevious = new int [cellTrackingPreviousTempCount*3+100];
                                            xyPositionCenterPreviousCount = 0;
                                            xyPositionCenterPreviousStatus = 1;
                                            xyPositionCenterPreviousSizeHold = cellTrackingPreviousTempCount*3+100;
                                        }
                                        else if (xyPositionCenterPreviousStatus == 1 && xyPositionCenterPreviousSizeHold < cellTrackingPreviousTempCount){
                                            delete [] arrayXYPositionCenterPrevious;
                                            
                                            errorNoHold = 99;
                                            arrayXYPositionCenterPrevious = new int [cellTrackingPreviousTempCount*3+100];
                                            xyPositionCenterPreviousCount = 0;
                                            xyPositionCenterPreviousSizeHold = cellTrackingPreviousTempCount*3+100;
                                        }
                                        else xyPositionCenterPreviousCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < cellTrackingPreviousTempCount; counter2++) arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = arrayCellTrackingPreviousTemp [counter2], xyPositionCenterPreviousCount++;
                                        
                                        arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = gravityX1, xyPositionCenterPreviousCount++;
                                        arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = gravityY1, xyPositionCenterPreviousCount++;
                                        arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = previousPointLine1, xyPositionCenterPreviousCount++;
                                        arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = (int)prevAverageLine1, xyPositionCenterPreviousCount++;
                                        arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = previousConnectNumberKeep, xyPositionCenterPreviousCount++;
                                        
                                        if (targetPointer == previousConnectNumberKeep) arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = 1, xyPositionCenterPreviousCount++;
                                        else arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = 0, xyPositionCenterPreviousCount++;
                                        
                                        delete [] arrayCellTrackingPreviousTemp;
                                        errorNoHold = 100;
                                        arrayCellTrackingPreviousTemp = new int [xyPositionCenterPreviousCount*2+50];
                                        cellTrackingPreviousTempCount = 0;
                                        
                                        for (int counter2 = 1; counter2 <= lineNumberPrevious2; counter2++){
                                            for (int counter3 = 0; counter3 < xyPositionCenterPreviousCount/6; counter3++){
                                                if (arrayXYPositionCenterPrevious [counter3*6+4] == counter2){
                                                    arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayXYPositionCenterPrevious [counter3*6], cellTrackingPreviousTempCount++;
                                                    arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayXYPositionCenterPrevious [counter3*6+1], cellTrackingPreviousTempCount++;
                                                    arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayXYPositionCenterPrevious [counter3*6+2], cellTrackingPreviousTempCount++;
                                                    arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayXYPositionCenterPrevious [counter3*6+3], cellTrackingPreviousTempCount++;
                                                    arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayXYPositionCenterPrevious [counter3*6+4], cellTrackingPreviousTempCount++;
                                                    arrayCellTrackingPreviousTemp [cellTrackingPreviousTempCount] = arrayXYPositionCenterPrevious [counter3*6+5], cellTrackingPreviousTempCount++;
                                                }
                                            }
                                        }
                                        
                                        xyPositionCenterPreviousCount = 0;
                                        for (int counter2 = 0; counter2 < cellTrackingPreviousTempCount; counter2++) arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = arrayCellTrackingPreviousTemp [counter2], xyPositionCenterPreviousCount++;
                                        
                                        delete [] arrayCellTrackingPreviousTemp;
                                        
                                        //------Group Table update------
                                        typeSubArray = 1;
                                        tableInterpretation = [[TableInterpretation alloc] init];
                                        [tableInterpretation interpretationFirst:typeSubArray];
                                        
                                        do{
                                        } while (subCompletionFlag3 == 1);
                                        
                                        if (errorNoHold != 0){
                                            errorNoHold = errorNoHold+2000;
                                            throw errorCheckThrow;
                                        }
                                        
                                        groupInvert = 0;
                                        
                                        for (int counter2 = 0; counter2 < groupInfoPreviousCount/5; counter2++){
                                            if (targetPointer == counter2+1 && arrayGroupInfoPrevious [counter2*5] < 0) groupInvert = arrayGroupInfoPrevious [counter2*5]*-1;
                                            
                                            if (arrayGroupInfoPrevious [counter2*5] == 0){
                                                arrayGroupInfoPrevious [counter2*5+3] = 0;
                                                arrayGroupInfoPrevious [counter2*5+4] = 0;
                                            }
                                            else{
                                                
                                                arrayGroupInfoPrevious [counter2*5+3] = groupTablePrevious [counter2*5+3];
                                                arrayGroupInfoPrevious [counter2*5+4] = groupTablePrevious [counter2*5+4];
                                            }
                                        }
                                        
                                        if (groupInvert != 0){
                                            for (int counter2 = 0; counter2 < groupInfoPreviousCount/5; counter2++){
                                                if (targetPointer == counter2+1 && arrayGroupInfoPrevious [counter2*5] < 0) arrayGroupInfoPrevious [counter2*5] = groupInvert;
                                                else if (arrayGroupInfoPrevious [counter2*5] == groupInvert) arrayGroupInfoPrevious [counter2*5] = groupInvert*-1;
                                            }
                                        }
                                        
                                        arrayGroupInfoPrevious [(targetPointer-1)*5+3] = targetMitosisCount;
                                        arrayGroupInfoPrevious [(targetPointer-1)*5+4] = targetRoundCount;
                                        
                                        //for (int counterA = 0; counterA < groupInfoPreviousCount/5; counterA++){
                                        //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayGroupInfoPrevious [counterA*5+counterB];
                                        //    cout<<" arrayGroupInfoPrevious "<<counterA<<endl;
                                        //}
                                        
                                        for (int counter2 = 0; counter2 < dimensionTemp+5; counter2++){
                                            delete [] connectivityUpdate [counter2];
                                            delete [] connectivityUpdate2 [counter2];
                                            delete [] connectivityUpdate3 [counter2];
                                            delete [] connectivityUpdate5 [counter2];
                                            delete [] connectivityUpdateInside [counter2];
                                        }
                                        
                                        delete [] connectivityUpdate;
                                        delete [] connectivityUpdate2;
                                        delete [] connectivityUpdate3;
                                        delete [] connectivityUpdate5;
                                        delete [] connectivityUpdateInside;
                                    }
                                    
                                    //cout<<p_variablesSet ->_targetPointer<<" Target_Current "<<targetPointer<<endl;
                                    
                                    //+++++++++Allocation 1, 4 AND 5++++++++++
                                    if (allocationResult == 1 || allocationResult == 4 || allocationResult == 5){
                                        
                                        //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                                        //	for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingCurrentMap [counterA][counterB];
                                        //	cout<<" arrayCellTrackingCurrentMap "<<counterA<<endl;
                                        //}
                                        
                                        //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                                        //	for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingPreviousMap [counterA][counterB];
                                        //	cout<<" arrayCellTrackingPreviousMap "<<counterA<<endl;
                                        //}
                                        
                                        errorNoHold = 101;
                                        int **overlapData3 = new int *[lineNumberPrevious2+5];
                                        errorNoHold = 102;
                                        int **overlapIntensity3 = new int *[lineNumberPrevious2+5];
                                        errorNoHold = 103;
                                        int **overlapPercent3 = new int *[lineNumberPrevious2+5];
                                        
                                        for (int counter2 = 0; counter2 < lineNumberPrevious2+5; counter2++){
                                            errorNoHold = 104;
                                            overlapData3 [counter2] = new int [lineNumberCurrent2+additionCount+5];
                                            errorNoHold = 105;
                                            overlapIntensity3 [counter2] = new int [lineNumberCurrent2+additionCount+5];
                                            errorNoHold = 106;
                                            overlapPercent3 [counter2] = new int [lineNumberCurrent2+additionCount+5];
                                        }
                                        
                                        for (int counterY = 1; counterY < lineNumberPrevious2+5; counterY++){
                                            for (int counterX = 1; counterX < lineNumberCurrent2+additionCount+5; counterX++){
                                                overlapData3 [counterY][counterX] = 0;
                                                overlapIntensity3 [counterY][counterX] = 0;
                                                overlapPercent3 [counterY][counterX] = 0;
                                            }
                                        }
                                        
                                        //for (int counter1 = 1; counter1 < lineNumberCurrent2+additionCount+1; counter1++){
                                        //	cout<<counter1<<" Pix "<<arrayCurrentTableTrack [counter1*2]<<" ConnNo "<<arrayCurrentTableTrack [counter1*2+1]<<" Total "<<arrayCurrentTableTrackTotal [counter1]<<" Average "<<arrayCurrentTableTrackTotal [counter1]<<" CURRTable_1_AND_4A"<<endl;
                                        //}
                                        
                                        for (int counterY = 0; counterY < trackAreaSize; counterY++){
                                            for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                                if (arrayCellTrackingPreviousMap [counterY][counterX] > 0 && arrayCellTrackingCurrentMap [counterY][counterX] > 0){
                                                    overlapData3 [arrayCellTrackingPreviousMap [counterY][counterX]][arrayCellTrackingCurrentMap [counterY][counterX]]++;
                                                    
                                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                                        overlapIntensity3 [arrayCellTrackingPreviousMap [counterY][counterX]][arrayCellTrackingCurrentMap [counterY][counterX]] = overlapIntensity3 [arrayCellTrackingPreviousMap [counterY][counterX]][arrayCellTrackingCurrentMap [counterY][counterX]]+sourceImage [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                                    }
                                                }
                                            }
                                        }
                                        
                                        for (int counterY = 1; counterY < lineNumberPrevious2+1; counterY++){
                                            for (int counterX = 1; counterX < lineNumberCurrent2+additionCount+1; counterX++){
                                                if (overlapSource [counterY][counterX] == 0) overlapData3 [counterY][counterX] = 0;
                                            }
                                        }
                                        
                                        for (int counterY = 1; counterY < lineNumberPrevious2+1; counterY++){
                                            for (int counterX = 1; counterX < lineNumberCurrent2+additionCount+1; counterX++){
                                                if (overlapData3 [counterY][counterX] > 0 && arrayPreviousTableTrack [counterY*2] > 0){
                                                    int overlapDataTemp = overlapData3 [counterY][counterX];
                                                    overlapIntensity3 [counterY][counterX] = (int)(overlapIntensity3 [counterY][counterX]/(double)overlapDataTemp);
                                                }
                                                if (overlapData3 [counterY][counterX] > 0 && arrayPreviousTableTrack [counterY*2] > 0){
                                                    overlapPercent3 [counterY][counterX] = (int)((overlapData3 [counterY][counterX]/(double)arrayPreviousTableTrack [counterY*2])*100);
                                                }
                                            }
                                        }
                                        
                                        maxTargetEntry = 0;
                                        
                                        for (int counterY = 1; counterY < lineNumberPrevious2+1; counterY++){
                                            int entryTemp = 0;
                                            
                                            for (int counterX = 1; counterX < lineNumberCurrent2+additionCount+1; counterX++){
                                                if (overlapData3 [counterY][counterX] != 0 && arrayCurrentTableTrack [counterX*2] > 0) entryTemp++;
                                            }
                                            if (entryTemp > maxTargetEntry) maxTargetEntry = entryTemp;
                                        }
                                        
                                        //for (int counterY = 1; counterY < lineNumberPrevious2+additionPrevCount+1; counterY++){
                                        //	for (int counterX = 1; counterX < lineNumberCurrent2+additionCount+1; counterX++) cout<<counterY<<" "<<counterX<<" "<<overlapData3 [counterY][counterX]<<" "<<overlapPercent3 [counterY][counterX]<<" OV3"<<endl;
                                        //}
                                        
                                        errorNoHold = 107;
                                        int **overlapNumber4 = new int *[lineNumberPrevious2+5];
                                        errorNoHold = 108;
                                        int **overlapData4 = new int *[lineNumberPrevious2+5];
                                        errorNoHold = 109;
                                        int **overlapIntensity4 = new int *[lineNumberPrevious2+5];
                                        errorNoHold = 110;
                                        int **overlapPercent4 = new int *[lineNumberPrevious2+5];
                                        
                                        for (int counter2 = 0; counter2 < lineNumberPrevious2+5; counter2++){
                                            errorNoHold = 111;
                                            overlapNumber4 [counter2] = new int [maxTargetEntry+5];
                                            errorNoHold = 112;
                                            overlapData4 [counter2] = new int [maxTargetEntry+5];
                                            errorNoHold = 113;
                                            overlapIntensity4 [counter2] = new int [maxTargetEntry+5];
                                            errorNoHold = 114;
                                            overlapPercent4 [counter2] = new int [maxTargetEntry+5];
                                        }
                                        
                                        for (int counterY = 1; counterY < lineNumberPrevious2+5; counterY++){
                                            for (int counterX = 0; counterX < maxTargetEntry+5; counterX++){
                                                overlapNumber4 [counterY][counterX] = 0;
                                                overlapData4 [counterY][counterX] = 0;
                                                overlapIntensity4 [counterY][counterX] = 0;
                                                overlapPercent4 [counterY][counterX] = 0;
                                            }
                                        }
                                        
                                        int terminationFlag1 = 0;
                                        
                                        for (int counterY = 1; counterY < lineNumberPrevious2+1; counterY++){
                                            //------Sort------
                                            entryCount = 0;
                                            
                                            do{
                                                
                                                terminationFlag1 = 1;
                                                int sortFindFlag = 0;
                                                int overlapMax = 0;
                                                int overlapCount = 0;
                                                
                                                for (int counter2 = 1; counter2 < lineNumberCurrent2+additionCount+1; counter2++){
                                                    if (overlapMax < overlapPercent3 [counterY][counter2] && overlapPercent3 [counterY][counter2] != 0){
                                                        overlapMax = overlapPercent3 [counterY][counter2];
                                                        overlapCount = counter2;
                                                        sortFindFlag = 1;
                                                    }
                                                }
                                                
                                                if (sortFindFlag == 1){
                                                    overlapNumber4 [counterY][entryCount] = overlapCount;
                                                    overlapData4 [counterY][entryCount] = overlapData3 [counterY][overlapCount];
                                                    overlapIntensity4 [counterY][entryCount] = overlapIntensity3 [counterY][overlapCount];
                                                    overlapPercent4 [counterY][entryCount] = overlapMax;
                                                    overlapPercent3 [counterY][overlapCount] = 0;
                                                    entryCount++;
                                                }
                                                else terminationFlag1 = 0;
                                                
                                            } while (terminationFlag1 == 1);
                                        }
                                        
                                        //for (int counterY = 1; counterY < lineNumberPrevious2+additionPrevCount+1; counterY++){
                                        //	for (int counterX = 0; counterX < maxTargetEntry; counterX++){
                                        //		cout<<counterY<<" Number "<<overlapNumber4 [counterY][counterX]<<" Area "<<overlapData4 [counterY][counterX];
                                        //        cout<<" Intensity "<<overlapIntensity4 [counterY][counterX]<<" Percentage "<<overlapPercent4 [counterY][counterX]<<" Overlap_1_AND_4"<<endl;
                                        //	}
                                        //}
                                        
                                        delete [] arrayOverlapNumberTrack;
                                        errorNoHold = 115;
                                        arrayOverlapNumberTrack = new int [lineNumberPrevious2*maxTargetEntry*3+10];
                                        int overlapNumberCount = 0;
                                        
                                        delete [] arrayOverlapPixelAreaTrack;
                                        errorNoHold = 116;
                                        arrayOverlapPixelAreaTrack = new int [lineNumberPrevious2*maxTargetEntry*3+10];
                                        int overlapPixelAreaCount = 0;
                                        
                                        delete [] arrayOverlapPixelIntensityTrack;
                                        errorNoHold = 117;
                                        arrayOverlapPixelIntensityTrack = new int [lineNumberPrevious2*maxTargetEntry*3+10];
                                        int overlapPixelIntensityCount = 0;
                                        
                                        delete [] arrayOverlapPercentTrack;
                                        errorNoHold = 118;
                                        arrayOverlapPercentTrack = new int [lineNumberPrevious2*maxTargetEntry*3+10];
                                        int overlapPercentCount = 0;
                                        
                                        for (int counterY = 1; counterY < lineNumberPrevious2+1; counterY++){
                                            entryCount = 0;
                                            
                                            for (int counterX = 0; counterX < maxTargetEntry; counterX++){
                                                if (overlapNumber4 [counterY][counterX] > 0 && ((overlapData4 [counterY][counterX] >= 0 && counterX == 0) || (overlapData4 [counterY][counterX] >= 10 && counterX != 0))){
                                                    int overlapDataTemp = overlapNumber4 [counterY][counterX];
                                                    
                                                    if (overlapDataTemp < lineNumberCurrent2+1){
                                                        if (arrayCurrentTableTrack [overlapDataTemp*2] > 0 && arrayCurrentTableTrack [overlapDataTemp*2+1] > 0){
                                                            arrayOverlapNumberTrack [overlapNumberCount] = counterY, overlapNumberCount++;
                                                            arrayOverlapNumberTrack [overlapNumberCount] = entryCount, overlapNumberCount++;
                                                            arrayOverlapNumberTrack [overlapNumberCount] = overlapNumber4 [counterY][counterX], overlapNumberCount++;
                                                            
                                                            arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = counterY, overlapPixelAreaCount++;
                                                            arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = entryCount, overlapPixelAreaCount++;
                                                            arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = overlapData4 [counterY][counterX], overlapPixelAreaCount++;
                                                            
                                                            arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = counterY, overlapPixelIntensityCount++;
                                                            arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = entryCount, overlapPixelIntensityCount++;
                                                            arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = overlapIntensity4 [counterY][counterX], overlapPixelIntensityCount++;
                                                            
                                                            arrayOverlapPercentTrack [overlapPercentCount] = counterY, overlapPercentCount++;
                                                            arrayOverlapPercentTrack [overlapPercentCount] = entryCount, overlapPercentCount++;
                                                            arrayOverlapPercentTrack [overlapPercentCount] = overlapPercent4 [counterY][counterX], overlapPercentCount++;
                                                            
                                                            entryCount++;
                                                        }
                                                    }
                                                    else{
                                                        
                                                        arrayOverlapNumberTrack [overlapNumberCount] = counterY, overlapNumberCount++;
                                                        arrayOverlapNumberTrack [overlapNumberCount] = entryCount, overlapNumberCount++;
                                                        arrayOverlapNumberTrack [overlapNumberCount] = overlapNumber4 [counterY][counterX], overlapNumberCount++;
                                                        
                                                        arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = counterY, overlapPixelAreaCount++;
                                                        arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = entryCount, overlapPixelAreaCount++;
                                                        arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = overlapData4 [counterY][counterX], overlapPixelAreaCount++;
                                                        
                                                        arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = counterY, overlapPixelIntensityCount++;
                                                        arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = entryCount, overlapPixelIntensityCount++;
                                                        arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = overlapIntensity4 [counterY][counterX], overlapPixelIntensityCount++;
                                                        
                                                        arrayOverlapPercentTrack [overlapPercentCount] = counterY, overlapPercentCount++;
                                                        arrayOverlapPercentTrack [overlapPercentCount] = entryCount, overlapPercentCount++;
                                                        arrayOverlapPercentTrack [overlapPercentCount] = overlapPercent4 [counterY][counterX], overlapPercentCount++;
                                                        
                                                        entryCount++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        overlapPixelAreaCountTrack = overlapPixelAreaCount;
                                        overlapPixelIntensityCountTrack = overlapPixelIntensityCount;
                                        overlapPercentCountTrack = overlapPercentCount;
                                        overlapNumberCountTrack = overlapNumberCount;
                                        
                                        for (int counter2 = 0; counter2 < lineNumberPrevious2+5; counter2++){
                                            delete [] overlapData3 [counter2];
                                            delete [] overlapIntensity3 [counter2];
                                            delete [] overlapPercent3 [counter2];
                                            delete [] overlapNumber4 [counter2];
                                            delete [] overlapData4 [counter2];
                                            delete [] overlapIntensity4 [counter2];
                                            delete [] overlapPercent4 [counter2];
                                        }
                                        
                                        delete [] overlapData3;
                                        delete [] overlapIntensity3;
                                        delete [] overlapPercent3;
                                        delete [] overlapNumber4;
                                        delete [] overlapData4;
                                        delete [] overlapIntensity4;
                                        delete [] overlapPercent4;
                                    }
                                    
                                    //+++++++++Allocation 2+++++++++
                                    if (allocationResult == 2){
                                        //cout<<"AL_2_taken"<<endl;
                                        
                                        //cout<<" PrevNo2 "<<previousNumber2<<" CurrPosition "<<currentPositionB1<<" "<<previousNumber1<<endl;
                                        
                                        overlapNumberTable [previousNumber2][currentPositionB1] = 0;
                                        overlapSource [previousNumber2][overlapNumberTable [previousNumber2][currentPositionB1]] = 0;
                                        
                                        if (numberOfEntry2 == 1 && targetPointer == previousNumber2){
                                            targetPointer = previousNumber1;
                                            
                                            for (int counter2 = 0; counter2 < xyPositionCenterPreviousCount/6; counter2++){
                                                if (arrayXYPositionCenterPrevious [counter2*6+4] == previousNumber2){
                                                    arrayXYPositionCenterPrevious [counter2*6+5] = 0;
                                                }
                                                
                                                if (arrayXYPositionCenterPrevious [counter2*6+4] == previousNumber1){
                                                    arrayXYPositionCenterPrevious [counter2*6+5] = 1;
                                                }
                                            }
                                            
                                            targetMitosisCount = arrayGroupInfoPrevious [(previousNumber2-1)*5+3];
                                            targetRoundCount = arrayGroupInfoPrevious [(previousNumber2-1)*5+4];
                                            
                                            groupInvert = 0;
                                            
                                            for (int counter2 = 0; counter2 < groupInfoPreviousCount/5; counter2++){
                                                if (targetPointer == counter2+1 && arrayGroupInfoPrevious [counter2*5] < 0) groupInvert = arrayGroupInfoPrevious [counter2*5]*-1;
                                                
                                                if (arrayGroupInfoPrevious [counter2*5] == 0){
                                                    arrayGroupInfoPrevious [counter2*5+3] = 0;
                                                    arrayGroupInfoPrevious [counter2*5+4] = 0;
                                                }
                                                else{
                                                    
                                                    arrayGroupInfoPrevious [counter2*5+3] = groupTablePrevious [counter2*5+3];
                                                    arrayGroupInfoPrevious [counter2*5+4] = groupTablePrevious [counter2*5+4];
                                                    
                                                    //cout<<previousNumber1<<" "<<groupTablePrevious [previousNumber1][10]<<" "<<groupTablePrevious [previousNumber1][11]<<" Group2"<<endl;
                                                }
                                            }
                                            
                                            if (groupInvert != 0){
                                                for (int counter2 = 0; counter2 < groupInfoPreviousCount/5; counter2++){
                                                    if (targetPointer == counter2+1 && arrayGroupInfoPrevious [counter2*5] < 0) arrayGroupInfoPrevious [counter2*5] = groupInvert;
                                                    else if (arrayGroupInfoPrevious [counter2*5] == groupInvert) arrayGroupInfoPrevious [counter2*5] = groupInvert*-1;
                                                }
                                            }
                                            
                                            arrayGroupInfoPrevious [(targetPointer-1)*5+3] = targetMitosisCount;
                                            arrayGroupInfoPrevious [(targetPointer-1)*5+4] = targetRoundCount;
                                            
                                            //for (int counterA = 0; counterA < groupInfoPreviousCount/5; counterA++){
                                            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayGroupInfoPrevious [counterA*5+counterB];
                                            //    cout<<" arrayGroupInfoPrevious "<<counterA<<endl;
                                            //}
                                        }
                                    }
                                    
                                    //+++++++++Allocation 3+++++++++
                                    if (allocationResult == 3){
                                        //cout<<"AL_3_taken"<<endl;
                                        
                                        //cout<<" PrevNo1 "<<previousNumber1<<" CurrPosition "<<currentPositionA1<<" "<<numberTemp<<endl;
                                        
                                        overlapNumberTable [previousNumber1][currentPositionA1] = 0;
                                        overlapSource [previousNumber1][overlapNumberTable [previousNumber1][currentPositionA1]] = 0;
                                        
                                        if (numberOfEntry == 1 && targetPointer == previousNumber1){
                                            targetPointer = previousNumber2;
                                            
                                            for (int counter2 = 0; counter2 < xyPositionCenterPreviousCount/6; counter2++){
                                                if (arrayXYPositionCenterPrevious [counter2*6+4] == previousNumber1){
                                                    arrayXYPositionCenterPrevious [counter2*6+5] = 0;
                                                }
                                                
                                                if (arrayXYPositionCenterPrevious [counter2*6+4] == previousNumber2){
                                                    arrayXYPositionCenterPrevious [counter2*6+5] = 1;
                                                }
                                            }
                                            
                                            targetMitosisCount = arrayGroupInfoPrevious [(previousNumber2-1)*5+3];
                                            targetRoundCount = arrayGroupInfoPrevious [(previousNumber1-1)*5+4];
                                            
                                            groupInvert = 0;
                                            
                                            for (int counter2 = 0; counter2 < groupInfoPreviousCount/5; counter2++){
                                                if (targetPointer == counter2+1 && arrayGroupInfoPrevious [counter2*5] < 0) groupInvert = arrayGroupInfoPrevious [counter2*5]*-1;
                                                
                                                if (arrayGroupInfoPrevious [counter2*5] == 0){
                                                    arrayGroupInfoPrevious [counter2*5+3] = 0;
                                                    arrayGroupInfoPrevious [counter2*5+4] = 0;
                                                }
                                                else{
                                                    
                                                    arrayGroupInfoPrevious [counter2*5+3] = groupTablePrevious [counter2*5+3];
                                                    arrayGroupInfoPrevious [counter2*5+4] = groupTablePrevious [counter2*5+4];
                                                    
                                                    //cout<<previousNumber1<<" "<<groupTablePrevious [previousNumber1][10]<<" "<<groupTablePrevious [previousNumber1][11]<<" Group2"<<endl;
                                                }
                                            }
                                            
                                            if (groupInvert != 0){
                                                for (int counter2 = 0; counter2 < groupInfoPreviousCount/5; counter2++){
                                                    if (targetPointer == counter2+1 && arrayGroupInfoPrevious [counter2*5] < 0) arrayGroupInfoPrevious [counter2*5] = groupInvert;
                                                    else if (arrayGroupInfoPrevious [counter2*5] == groupInvert) arrayGroupInfoPrevious [counter2*5] = groupInvert*-1;
                                                }
                                            }
                                            
                                            arrayGroupInfoPrevious [(targetPointer-1)*5+3] = targetMitosisCount;
                                            arrayGroupInfoPrevious [(targetPointer-1)*5+4] = targetRoundCount;
                                            
                                            //for (int counterA = 0; counterA < groupInfoPreviousCount/5; counterA++){
                                            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayGroupInfoPrevious [counterA*5+counterB];
                                            //    cout<<" arrayGroupInfoPrevious "<<counterA<<endl;
                                            //}
                                        }
                                    }
                                    
                                    //+++++++++Allocation 6+++++++++
                                    if (allocationResult == 6){
                                        
                                        //cout<<"AL_6_remove"<<endl;
                                        
                                        overlapNumberTable [previousNumber2][currentPositionB1] = 0;
                                        overlapNumberTable [previousNumber1][currentPositionA1] = 0;
                                        overlapSource [previousNumber2][overlapNumberTable [previousNumber2][currentPositionB1]] = 0;
                                        overlapSource [previousNumber1][overlapNumberTable [previousNumber1][currentPositionA1]] = 0;
                                    }
                                    
                                    //+++++++++Allocation 2 and 3+++++++++
                                    if (allocationResult == 2 || allocationResult == 3 || allocationResult == 6){
                                        
                                        //cout<<"AL2_3_6"<<endl;
                                        
                                        delete [] arrayOverlapNumberTrack;
                                        errorNoHold = 119;
                                        arrayOverlapNumberTrack = new int [lineNumberPrevious2*maxTargetEntry*3+10];
                                        int overlapNumberCount = 0;
                                        
                                        delete [] arrayOverlapPixelAreaTrack;
                                        errorNoHold = 120;
                                        arrayOverlapPixelAreaTrack = new int [lineNumberPrevious2*maxTargetEntry*3+10];
                                        int overlapPixelAreaCount = 0;
                                        
                                        delete [] arrayOverlapPixelIntensityTrack;
                                        errorNoHold = 121;
                                        arrayOverlapPixelIntensityTrack = new int [lineNumberPrevious2*maxTargetEntry*3+10];
                                        int overlapPixelIntensityCount = 0;
                                        
                                        delete [] arrayOverlapPercentTrack;
                                        errorNoHold = 122;
                                        arrayOverlapPercentTrack = new int [lineNumberPrevious2*maxTargetEntry*3+10];
                                        int overlapPercentCount = 0;
                                        
                                        for (int counterY = 1; counterY < lineNumberPrevious2+1; counterY++){
                                            entryCount = 0;
                                            
                                            for (int counterX = 0; counterX < maxTargetEntry; counterX++){
                                                if (overlapNumberTable [counterY][counterX] > 0){
                                                    arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = counterY, overlapPixelAreaCount++;
                                                    arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = entryCount, overlapPixelAreaCount++;
                                                    arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = overlapAreaTable [counterY][counterX], overlapPixelAreaCount++;
                                                    
                                                    arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = counterY, overlapPixelIntensityCount++;
                                                    arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = entryCount, overlapPixelIntensityCount++;
                                                    arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = overlapIntensityTable [counterY][counterX], overlapPixelIntensityCount++;
                                                    
                                                    arrayOverlapPercentTrack [overlapPercentCount] = counterY, overlapPercentCount++;
                                                    arrayOverlapPercentTrack [overlapPercentCount] = entryCount, overlapPercentCount++;
                                                    arrayOverlapPercentTrack [overlapPercentCount] = overlapPercentageTable [counterY][counterX], overlapPercentCount++;
                                                    
                                                    arrayOverlapNumberTrack [overlapNumberCount] = counterY, overlapNumberCount++;
                                                    arrayOverlapNumberTrack [overlapNumberCount] = entryCount, overlapNumberCount++;
                                                    arrayOverlapNumberTrack [overlapNumberCount] = overlapNumberTable [counterY][counterX], overlapNumberCount++;
                                                    
                                                    entryCount++;
                                                }
                                            }
                                        }
                                        
                                        overlapPixelAreaCountTrack = overlapPixelAreaCount;
                                        overlapPixelIntensityCountTrack = overlapPixelIntensityCount;
                                        overlapPercentCountTrack = overlapPercentCount;
                                        overlapNumberCountTrack = overlapNumberCount;
                                        
                                        //for (int counterA = 0; counterA < overlapNumberCount/3; counterA++){
                                        //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapNumberTrack [counterA*3+counterB];
                                        //    cout<<" arrayOverlapNumberTrack "<<counterA<<endl;
                                        //}
                                        
                                        //for (int counterA = 0; counterA < overlapPixelAreaCount/3; counterA++){
                                        //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelAreaTrack [counterA*3+counterB];
                                        //    cout<<" arrayOverlapPixelAreaTrack "<<counterA<<endl;
                                        //}
                                    }
                                    
                                    if (previousAverageCountTemp != 0){
                                        delete [] arrayPreviousTableTrack;
                                        errorNoHold = 123;
                                        arrayPreviousTableTrack = new int [lineNumberPrevious2*2+50];
                                        
                                        delete [] arrayPreviousTableTrackTotal;
                                        errorNoHold = 124;
                                        arrayPreviousTableTrackTotal = new double [lineNumberPrevious2+50];
                                        
                                        delete [] arrayPreviousAverageTrack;
                                        errorNoHold = 125;
                                        arrayPreviousAverageTrack = new double [lineNumberPrevious2+50];
                                        
                                        for (int counter2 = 0; counter2 < previousAverageCountTemp; counter2++){
                                            arrayPreviousTableTrack [(counter2+1)*2] = arrayPreviousTableTemp [counter2*2];
                                            arrayPreviousTableTrack [(counter2+1)*2+1] = arrayPreviousTableTemp [counter2*2+1];
                                            arrayPreviousTableTrackTotal [counter2+1] = arrayPreviousTotalTemp [counter2];
                                            arrayPreviousAverageTrack [counter2+1] = arrayPreviousAverageTemp [counter2];
                                        }
                                    }
                                    
                                    delete [] arrayPreviousTableTemp;
                                    delete [] arrayPreviousTotalTemp;
                                    delete [] arrayPreviousAverageTemp;
                                    
                                    if (currentAverageCountTemp != 0){
                                        delete [] arrayCurrentTableTrack;
                                        errorNoHold = 126;
                                        arrayCurrentTableTrack = new int [lineNumberCurrent2*2+50];
                                        
                                        delete [] arrayCurrentTableTrackTotal;
                                        errorNoHold = 127;
                                        arrayCurrentTableTrackTotal = new double [lineNumberCurrent2+50];
                                        
                                        delete [] arrayCurrentAverageTrack;
                                        errorNoHold = 128;
                                        arrayCurrentAverageTrack = new double [lineNumberCurrent2+50];
                                        
                                        for (int counter2 = 0; counter2 < currentAverageCountTemp; counter2++){
                                            arrayCurrentTableTrack [(counter2+1)*2] = arrayCurrentTableTemp [counter2*2];
                                            arrayCurrentTableTrack [(counter2+1)*2+1] = arrayCurrentTableTemp [counter2*2+1];
                                            arrayCurrentTableTrackTotal [counter2+1] = arrayCurrentTotalTemp [counter2];
                                            arrayCurrentAverageTrack [counter2+1] = arrayCurrentAverageTemp [counter2];
                                        }
                                    }
                                    
                                    delete [] arrayCurrentTableTemp;
                                    delete [] arrayCurrentTotalTemp;
                                    delete [] arrayCurrentAverageTemp;
                                    
                                    if (allocationResult != 0){
                                        terminationFlagLoop = 1;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < p_variablesSet ->_overlapPixelIntensityCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelIntensityTrack [counterA*3+counterB];
                    //    cout<<" arrayOverlapPixelIntensityTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < p_variablesSet ->_overlapPixelAreaCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelAreaTrack [counterA*3+counterB];
                    //    cout<<" arrayOverlapPixelAreaTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < p_variablesSet ->_overlapPercentCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPercentTrack [counterA*3+counterB];
                    //    cout<<" arrayOverlapPercentTrack "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < lineNumberPrevious2+5; counter1++){
                        delete [] overlapAreaTable [counter1];
                        delete [] overlapIntensityTable [counter1];
                        delete [] overlapPercentageTable [counter1];
                        delete [] overlapNumberTable [counter1];
                        delete [] overlapSource [counter1];
                        delete [] previousAssData [counter1];
                    }
                    
                    delete [] overlapAreaTable;
                    delete [] overlapIntensityTable;
                    delete [] overlapPercentageTable;
                    delete [] overlapNumberTable;
                    delete [] overlapSource;
                    delete [] previousAssData;
                    delete [] groupTablePrevious;
                    
                    for (int counter1 = 0; counter1 < lineNumberCurrent2+5; counter1++) delete [] currentAssData [counter1];
                    delete [] currentAssData;
                    
                    delete [] connectPrevTempA1;
                    delete [] connectPrevTempB1;
                    delete [] connectPrevTempC1;
                    delete [] connectPrevTempA2;
                    delete [] connectPrevTempB2;
                    delete [] connectPrevTempC2;
                    delete [] connectCurrentTempA1;
                    delete [] connectCurrentTempB1;
                    delete [] connectCurrentTempC1;
                    delete [] connectCurrentTempA2;
                    delete [] connectCurrentTempB2;
                    delete [] connectCurrentTempC2;
                    delete [] connectCurrentTempA3;
                    delete [] connectCurrentTempB3;
                    delete [] connectCurrentTempC3;
                    
                    maxTargetEntryTrack = maxTargetEntry;
                    targetPointerTrack = targetPointer;
                    
                    //cout<<p_variablesSet -> _maxTargetEntry<<" MaxTarget3"<<endl;
                }
                
            } while (terminationFlagLoop == 1);
            
            //for (int counterA = 0; counterA < cellTrackingPrevCount/6; counterA++){
            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrev [counterA*6+counterB];
            //	cout<<" arrayCellTrackingPrev "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrent [counterA*6+counterB];
            //	cout<<" arrayCellTrackingCurrent "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < groupInfoPrevCount/12; counterA++){
            //	for (int counterB = 0; counterB < 12; counterB++) cout<<" "<<arrayGroupInfoPrevious [counterA*12+counterB];
            //	cout<<" arrayGroupTablePrevious "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < p_variablesSet ->_overlapPixelIntensityCount/3; counterA++){
            //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelIntensityTrack [counterA*3+counterB];
            //    cout<<" arrayOverlapPixelIntensityTrack "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < p_variablesSet ->_overlapPixelAreaCount/3; counterA++){
            //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelAreaTrack [counterA*3+counterB];
            //    cout<<" arrayOverlapPixelAreaTrack "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < p_variablesSet ->_overlapPercentCount/3; counterA++){
            //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPercentTrack [counterA*3+counterB];
            //    cout<<" arrayOverlapPercentTrack "<<counterA<<endl;
            //}
            
            // NSLog(@"%@", [NSThread callStackSymbols]);
            
            errorNoHold = 0;
            subCompletionFlag2 = 0;
        }
        catch (int errorCheckThrow){
            if (errorNoHold == 0) errorNoHold = 1000;
            
            subCompletionFlag2 = 0;
        }
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingTargetPrevious "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"TargetPrevious"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
        
        subCompletionFlag2 = 0;
    }
}

@end
