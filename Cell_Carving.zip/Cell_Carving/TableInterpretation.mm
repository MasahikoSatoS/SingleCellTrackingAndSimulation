//
// TableInterpretation.mm
// cell_carving
//
// Created by Masahiko Sato on 13/06/19.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "TableInterpretation.h"

@implementation TableInterpretation

-(int)interpretationFirst:(int)processType{
    int connectDetect = 0;
    
    try{
        try{
            
            errorNoHold = 0;
            subCompletionFlag3 = 1;
            int errorCheckThrow = 0;
            
            //------Data set to Maps, maxConnect holds largest connect number, maxCount holds the number of connect entry------
            int maxConnect = 0;
            int maxCount = 0;
            
            if (processType == 1 || processType == 3){ //------Set, Round 1------
                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                        if (arrayCellTrackingPreviousMap [counterY][counterX] > 0 && arrayCellTrackingPreviousMap [counterY][counterX] > maxConnect) maxConnect = arrayCellTrackingPreviousMap [counterY][counterX];
                        
                        if (mapPositionPointer < mapEntryTotal && mapPositionPointer >= 0){
                            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                if (connectMapA [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect) maxConnect = connectMapA [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                if (connectMapB [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect) maxConnect = connectMapB [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                if (connectMapC [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect) maxConnect = connectMapC [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                if (connectMapD [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect) maxConnect = connectMapD [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                if (connectMap200 [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect) maxConnect = connectMap200 [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                if (connectMap220 [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect) maxConnect = connectMap220 [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                if (connectMap240 [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect) maxConnect = connectMap240 [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                            }
                        }
                        else{
                            
                            errorNoHold = 1000;
                            throw errorCheckThrow;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                // 	for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayImageConnect200Pr [counterA][counterB];
                //	cout<<" arrayImageConnect200Pr "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                //}
                
                if ((xyPositionCenterPreviousCount/6-1)*6+4 < xyPositionCenterPreviousSizeHold && (xyPositionCenterPreviousCount/6-1)*6+4 >= 0){
                    if (xyPositionCenterPreviousCount != 0) maxCount = arrayXYPositionCenterPrevious [(xyPositionCenterPreviousCount/6-1)*6+4];
                }
                else{
                    
                    errorNoHold = 1001;
                    throw errorCheckThrow;
                }
            }
            else if (processType == 2){ //------Set, Round > 1------
                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                        if (arrayCellTrackingCurrentMap [counterY][counterX] > maxConnect) maxConnect = arrayCellTrackingCurrentMap [counterY][counterX];
                        
                        if (mapPositionPointerCurrent < mapEntryTotal && mapPositionPointerCurrent >= 0){
                            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                if (connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect) maxConnect = connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                if (connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect) maxConnect = connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                if (connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect) maxConnect = connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                if (connectMapD [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect) maxConnect = connectMapD [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                if (connectMap200 [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect) maxConnect = connectMap200 [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                if (connectMap220 [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect) maxConnect = connectMap220 [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                                if (connectMap240 [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] > maxConnect) maxConnect = connectMap240 [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                            }
                        }
                        else{
                            
                            errorNoHold = 1002;
                            throw errorCheckThrow;
                        }
                    }
                }
                
                if ((xyPositionCenterCurrentCount/6-1)*6+4 < xyPositionCenterCurrentSizeHold && (xyPositionCenterCurrentCount/6-1)*6+4 >= 0){
                    if (xyPositionCenterCurrentCount != 0) maxCount = arrayXYPositionCenterCurrent [(xyPositionCenterCurrentCount/6-1)*6+4];
                }
                else{
                    
                    errorNoHold = 1003;
                    throw errorCheckThrow;
                }
            }
            
            //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
            //    cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
            //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
            //}
            
            //cout<<processType<<" "<<maxCount<<" "<<maxConnect<<" maxData"<<endl;
            
            if (maxCount != 0 && maxConnect != 0){
                if ((processType == 2 && xyPositionCenterCurrentCount != 0) || ((processType == 1 || processType == 3) && xyPositionCenterPreviousCount != 0)){
                    //------Overlapped Connect Histogram Preparation------
                    errorNoHold = 1;
                    int *intensityHistogram = new int [maxCount];
                    int intensityHistogramCount = 0;
                    int intensityHistogramLimit = maxCount;
                    
                    errorNoHold = 2;
                    int *intensityHistogram2 = new int [maxCount];
                    int intensityHistogramCount2 = 0;
                    int intensityHistogramLimit2 = maxCount;
                    
                    errorNoHold = 3;
                    int *intensityHistogram3 = new int [maxCount];
                    int intensityHistogramCount3 = 0;
                    int intensityHistogramLimit3 = maxCount;
                    
                    errorNoHold = 4;
                    int *intensityHistogram4 = new int [maxCount*2];
                    int intensityHistogramCount4 = 0;
                    int intensityHistogramLimit4 = maxCount*2;
                    
                    errorNoHold = 5;
                    int *intensityHistogram5 = new int [maxCount*2];
                    int intensityHistogramCount5 = 0;
                    int intensityHistogramLimit5 = maxCount*2;
                    
                    errorNoHold = 6;
                    int *intensityHistogram6 = new int [maxCount*4];
                    int intensityHistogramCount6 = 0;
                    int intensityHistogramLimit6 = maxCount*4;
                    
                    errorNoHold = 7;
                    int *intensityHistogram7 = new int [maxCount*4];
                    int intensityHistogramCount7 = 0;
                    int intensityHistogramLimit7 = maxCount*4;
                    
                    int connect4 = 0;
                    int map4 = 0;
                    int position4 = 0;
                    int connect5 = 0;
                    int map5 = 0;
                    int position5 = 0;
                    int connect6 = 0;
                    int map6 = 0;
                    int position6 = 0;
                    int connect7 = 0;
                    int map7 = 0;
                    int position7 = 0;
                    
                    // for (int counterA = 0; counterA < trackAreaSize; counterA++){
                    //	for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayImageConnectivityD [counterA][counterB];
                    //	cout<<" arrayImageConnectivityD "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                    //	for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingPreviousMap [counterA][counterB];
                    //cout<<" arrayCellTrackingPreviousMap "<<counterA<<endl;
                    //}
                    
                    int findFlag = 0;
                    
                    if (processType == 1 || processType == 3){
                        int connectTemp = 0;
                        
                        for (int counterY = 0; counterY < trackAreaSize; counterY++){
                            for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                if (arrayCellTrackingPreviousMap [counterY][counterX] > 0){
                                    connectTemp = arrayCellTrackingPreviousMap [counterY][counterX];
                                    
                                    if (intensityHistogramLimit-10 < intensityHistogramCount){
                                        errorNoHold = 8;
                                        int *arrayUpDate = new int [intensityHistogramCount+10];
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount; counter1++) arrayUpDate [counter1] = intensityHistogram [counter1];
                                        
                                        delete [] intensityHistogram;
                                        errorNoHold = 9;
                                        intensityHistogram = new int [intensityHistogramLimit+5000];
                                        intensityHistogramLimit = intensityHistogramLimit+5000;
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount; counter1++) intensityHistogram [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    if (intensityHistogramLimit2-10 < intensityHistogramCount2){
                                        errorNoHold = 10;
                                        int *arrayUpDate = new int [intensityHistogramCount2+10];
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount2; counter1++) arrayUpDate [counter1] = intensityHistogram2 [counter1];
                                        
                                        delete [] intensityHistogram2;
                                        errorNoHold = 11;
                                        intensityHistogram2 = new int [intensityHistogramLimit2+5000];
                                        intensityHistogramLimit2 = intensityHistogramLimit2+5000;
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount2; counter1++) intensityHistogram2 [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    if (intensityHistogramLimit3-10 < intensityHistogramCount3){
                                        errorNoHold = 12;
                                        int *arrayUpDate = new int [intensityHistogramCount3+10];
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount3; counter1++) arrayUpDate [counter1] = intensityHistogram3 [counter1];
                                        
                                        delete [] intensityHistogram3;
                                        errorNoHold = 13;
                                        intensityHistogram3 = new int [intensityHistogramLimit3+5000];
                                        intensityHistogramLimit3 = intensityHistogramLimit3+5000;
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount3; counter1++) intensityHistogram3 [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    if (intensityHistogramLimit4-10 < intensityHistogramCount4){
                                        errorNoHold = 14;
                                        int *arrayUpDate = new int [intensityHistogramCount4+10];
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount4; counter1++) arrayUpDate [counter1] = intensityHistogram4 [counter1];
                                        
                                        delete [] intensityHistogram4;
                                        errorNoHold = 15;
                                        intensityHistogram4 = new int [intensityHistogramLimit4+5000];
                                        intensityHistogramLimit4 = intensityHistogramLimit4+5000;
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount4; counter1++) intensityHistogram4 [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    if (intensityHistogramLimit5-10 < intensityHistogramCount5){
                                        errorNoHold = 16;
                                        int *arrayUpDate = new int [intensityHistogramCount5+10];
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount5; counter1++) arrayUpDate [counter1] = intensityHistogram5 [counter1];
                                        
                                        delete [] intensityHistogram5;
                                        errorNoHold = 17;
                                        intensityHistogram5 = new int [intensityHistogramLimit5+5000];
                                        intensityHistogramLimit5 = intensityHistogramLimit5+5000;
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount5; counter1++) intensityHistogram5 [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    if (intensityHistogramLimit6-10 < intensityHistogramCount6){
                                        errorNoHold = 18;
                                        int *arrayUpDate = new int [intensityHistogramCount6+10];
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount6; counter1++) arrayUpDate [counter1] = intensityHistogram6 [counter1];
                                        
                                        delete [] intensityHistogram6;
                                        errorNoHold = 19;
                                        intensityHistogram6 = new int [intensityHistogramLimit6+5000];
                                        intensityHistogramLimit6 = intensityHistogramLimit6+5000;
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount6; counter1++) intensityHistogram6 [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    if (intensityHistogramLimit7-10 < intensityHistogramCount7){
                                        errorNoHold = 20;
                                        int *arrayUpDate = new int [intensityHistogramCount7+10];
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount7; counter1++) arrayUpDate [counter1] = intensityHistogram7 [counter1];
                                        
                                        delete [] intensityHistogram7;
                                        errorNoHold = 21;
                                        intensityHistogram7 = new int [intensityHistogramLimit7+5000];
                                        intensityHistogramLimit7 = intensityHistogramLimit7+5000;
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount7; counter1++) intensityHistogram7 [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMap240 [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                        findFlag = 0;
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount/3; counter1++){
                                            if (intensityHistogram [counter1*3] == connectTemp && intensityHistogram [counter1*3+1] == connectMap240 [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                                intensityHistogram [counter1*3+2]++;
                                                findFlag = 1;
                                                break;
                                            }
                                        }
                                        
                                        if (findFlag == 0){
                                            intensityHistogram [intensityHistogramCount] = connectTemp, intensityHistogramCount++;
                                            intensityHistogram [intensityHistogramCount] = connectMap240 [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], intensityHistogramCount++;
                                            intensityHistogram [intensityHistogramCount] = 1, intensityHistogramCount++;
                                        }
                                    }
                                    
                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMap220 [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                        findFlag = 0;
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount2/3; counter1++){
                                            if (intensityHistogram2 [counter1*3] == connectTemp && intensityHistogram2 [counter1*3+1] == connectMap220 [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                                intensityHistogram2 [counter1*3+2]++;
                                                findFlag = 1;
                                                break;
                                            }
                                        }
                                        
                                        if (findFlag == 0){
                                            intensityHistogram2 [intensityHistogramCount2] = connectTemp, intensityHistogramCount2++;
                                            intensityHistogram2 [intensityHistogramCount2] = connectMap220 [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], intensityHistogramCount2++;
                                            intensityHistogram2 [intensityHistogramCount2] = 1, intensityHistogramCount2++;
                                        }
                                    }
                                    
                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMap200 [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                        findFlag = 0;
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount3/3; counter1++){
                                            if (intensityHistogram3 [counter1*3] == connectTemp && intensityHistogram3 [counter1*3+1] == connectMap200 [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                                intensityHistogram3 [counter1*3+2]++;
                                                findFlag = 1;
                                                break;
                                            }
                                        }
                                        
                                        if (findFlag == 0){
                                            intensityHistogram3 [intensityHistogramCount3] = connectTemp, intensityHistogramCount3++;
                                            intensityHistogram3 [intensityHistogramCount3] = connectMap200 [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], intensityHistogramCount3++;
                                            intensityHistogram3 [intensityHistogramCount3] = 1, intensityHistogramCount3++;
                                        }
                                    }
                                    
                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapA [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                        findFlag = 0;
                                        
                                        if (connect4 != connectTemp || map4 != connectMapA [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                            for (int counter1 = 0; counter1 < intensityHistogramCount4/3; counter1++){
                                                if (intensityHistogram4 [counter1*3] == connectTemp && intensityHistogram4 [counter1*3+1] == connectMapA [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                                    intensityHistogram4 [counter1*3+2]++;
                                                    findFlag = 1;
                                                    connect4 = connectTemp, map4 = connectMapA [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], position4 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                intensityHistogram4 [intensityHistogramCount4] = connectTemp, intensityHistogramCount4++;
                                                intensityHistogram4 [intensityHistogramCount4] = connectMapA [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], intensityHistogramCount4++;
                                                intensityHistogram4 [intensityHistogramCount4] = 1, intensityHistogramCount4++;
                                                connect4 = connectTemp, map4 = connectMapA [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], position4 = intensityHistogramCount4/3;
                                            }
                                        }
                                        else intensityHistogram4 [position4*3+2]++;
                                    }
                                    
                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapB [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                        findFlag = 0;
                                        
                                        if (connect5 != connectTemp || map5 != connectMapB [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                            for (int counter1 = 0; counter1 < intensityHistogramCount5/3; counter1++){
                                                if (intensityHistogram5 [counter1*3] == connectTemp && intensityHistogram5 [counter1*3+1] == connectMapB [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                                    intensityHistogram5 [counter1*3+2]++;
                                                    findFlag = 1;
                                                    connect5 = connectTemp, map5 = connectMapB [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], position5 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                intensityHistogram5 [intensityHistogramCount5] = connectTemp, intensityHistogramCount5++;
                                                intensityHistogram5 [intensityHistogramCount5] = connectMapB [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], intensityHistogramCount5++;
                                                intensityHistogram5 [intensityHistogramCount5] = 1, intensityHistogramCount5++;
                                                connect5 = connectTemp, map5 = connectMapB [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], position5 = intensityHistogramCount5/3;
                                            }
                                        }
                                        else intensityHistogram5 [position5*3+2]++;
                                    }
                                    
                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapC [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                        findFlag = 0;
                                        
                                        if (connect6 != connectTemp || map6 != connectMapC [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                            for (int counter1 = 0; counter1 < intensityHistogramCount6/3; counter1++){
                                                if (intensityHistogram6 [counter1*3] == connectTemp && intensityHistogram6 [counter1*3+1] == connectMapC [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                                    intensityHistogram6 [counter1*3+2]++;
                                                    findFlag = 1;
                                                    connect6 = connectTemp, map6 = connectMapC [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], position6 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                intensityHistogram6 [intensityHistogramCount6] = connectTemp, intensityHistogramCount6++;
                                                intensityHistogram6 [intensityHistogramCount6] = connectMapC [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], intensityHistogramCount6++;
                                                intensityHistogram6 [intensityHistogramCount6] = 1, intensityHistogramCount6++;
                                                connect6 = connectTemp, map6 = connectMapC [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], position6 = intensityHistogramCount6/3;
                                            }
                                        }
                                        else intensityHistogram6 [position6*3+2]++;
                                    }
                                    
                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapD [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                        findFlag = 0;
                                        
                                        if (connect7 != connectTemp || map7 != connectMapD [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                            for (int counter1 = 0; counter1 < intensityHistogramCount7/3; counter1++){
                                                if (intensityHistogram7 [counter1*3] == connectTemp && intensityHistogram7 [counter1*3+1] == connectMapD [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                                    intensityHistogram7 [counter1*3+2]++;
                                                    findFlag = 1;
                                                    connect7 = connectTemp, map7 = connectMapD [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], position7 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                intensityHistogram7 [intensityHistogramCount7] = connectTemp, intensityHistogramCount7++;
                                                intensityHistogram7 [intensityHistogramCount7] = connectMapD [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], intensityHistogramCount7++;
                                                intensityHistogram7 [intensityHistogramCount7] = 1, intensityHistogramCount7++;
                                                connect7 = connectTemp, map7 = connectMapD [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], position7 = intensityHistogramCount7/3;
                                            }
                                        }
                                        else intensityHistogram7 [position7*3+2]++;
                                    }
                                }
                            }
                        }
                    }
                    else if (processType == 2){
                        int connectTemp = 0;
                        
                        for (int counterY = 0; counterY < trackAreaSize; counterY++){
                            for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                if (arrayCellTrackingCurrentMap [counterY][counterX] > 0){
                                    connectTemp = arrayCellTrackingCurrentMap [counterY][counterX];
                                    
                                    if (intensityHistogramLimit-10 < intensityHistogramCount){
                                        errorNoHold = 22;
                                        int *arrayUpDate = new int [intensityHistogramCount+10];
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount; counter1++) arrayUpDate [counter1] = intensityHistogram [counter1];
                                        
                                        delete [] intensityHistogram;
                                        errorNoHold = 23;
                                        intensityHistogram = new int [intensityHistogramLimit+5000];
                                        intensityHistogramLimit = intensityHistogramLimit+5000;
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount; counter1++) intensityHistogram [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    if (intensityHistogramLimit2-10 < intensityHistogramCount2){
                                        errorNoHold = 24;
                                        int *arrayUpDate = new int [intensityHistogramCount2+10];
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount2; counter1++) arrayUpDate [counter1] = intensityHistogram2 [counter1];
                                        
                                        delete [] intensityHistogram2;
                                        errorNoHold = 25;
                                        intensityHistogram2 = new int [intensityHistogramLimit2+5000];
                                        intensityHistogramLimit2 = intensityHistogramLimit2+5000;
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount2; counter1++) intensityHistogram2 [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    if (intensityHistogramLimit3-10 < intensityHistogramCount3){
                                        errorNoHold = 26;
                                        int *arrayUpDate = new int [intensityHistogramCount3+10];
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount3; counter1++) arrayUpDate [counter1] = intensityHistogram3 [counter1];
                                        
                                        delete [] intensityHistogram3;
                                        errorNoHold = 27;
                                        intensityHistogram3 = new int [intensityHistogramLimit3+5000];
                                        intensityHistogramLimit3 = intensityHistogramLimit3+5000;
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount3; counter1++) intensityHistogram3 [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    if (intensityHistogramLimit4-10 < intensityHistogramCount4){
                                        errorNoHold = 28;
                                        int *arrayUpDate = new int [intensityHistogramCount4+10];
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount4; counter1++) arrayUpDate [counter1] = intensityHistogram4 [counter1];
                                        
                                        delete [] intensityHistogram4;
                                        errorNoHold = 29;
                                        intensityHistogram4 = new int [intensityHistogramLimit4+5000];
                                        intensityHistogramLimit4 = intensityHistogramLimit4+5000;
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount4; counter1++) intensityHistogram4 [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    if (intensityHistogramLimit5-10 < intensityHistogramCount5){
                                        errorNoHold = 30;
                                        int *arrayUpDate = new int [intensityHistogramCount5+10];
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount5; counter1++) arrayUpDate [counter1] = intensityHistogram5 [counter1];
                                        
                                        delete [] intensityHistogram5;
                                        errorNoHold = 31;
                                        intensityHistogram5 = new int [intensityHistogramLimit5+5000];
                                        intensityHistogramLimit5 = intensityHistogramLimit5+5000;
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount5; counter1++) intensityHistogram5 [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    if (intensityHistogramLimit6-10 < intensityHistogramCount6){
                                        errorNoHold = 32;
                                        int *arrayUpDate = new int [intensityHistogramCount6+10];
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount6; counter1++) arrayUpDate [counter1] = intensityHistogram6 [counter1];
                                        
                                        delete [] intensityHistogram6;
                                        errorNoHold = 33;
                                        intensityHistogram6 = new int [intensityHistogramLimit6+5000];
                                        intensityHistogramLimit6 = intensityHistogramLimit6+5000;
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount6; counter1++) intensityHistogram6 [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    if (intensityHistogramLimit7-10 < intensityHistogramCount7){
                                        errorNoHold = 34;
                                        int *arrayUpDate = new int [intensityHistogramCount7+10];
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount7; counter1++) arrayUpDate [counter1] = intensityHistogram7 [counter1];
                                        
                                        delete [] intensityHistogram7;
                                        errorNoHold = 35;
                                        intensityHistogram7 = new int [intensityHistogramLimit7+5000];
                                        intensityHistogramLimit7 = intensityHistogramLimit7+5000;
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount7; counter1++) intensityHistogram7 [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMap240 [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                        findFlag = 0;
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount/3; counter1++){
                                            if (intensityHistogram [counter1*3] == connectTemp && intensityHistogram [counter1*3+1] == connectMap240 [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                                intensityHistogram [counter1*3+2]++;
                                                findFlag = 1;
                                                break;
                                            }
                                        }
                                        
                                        if (findFlag == 0){
                                            intensityHistogram [intensityHistogramCount] = connectTemp, intensityHistogramCount++;
                                            intensityHistogram [intensityHistogramCount] = connectMap240 [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], intensityHistogramCount++;
                                            intensityHistogram [intensityHistogramCount] = 1, intensityHistogramCount++;
                                        }
                                    }
                                    
                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMap220 [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                        findFlag = 0;
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount2/3; counter1++){
                                            if (intensityHistogram2 [counter1*3] == connectTemp && intensityHistogram2 [counter1*3+1] == connectMap220 [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                                intensityHistogram2 [counter1*3+2]++;
                                                findFlag = 1;
                                                break;
                                            }
                                        }
                                        
                                        if (findFlag == 0){
                                            intensityHistogram2 [intensityHistogramCount2] = connectTemp, intensityHistogramCount2++;
                                            intensityHistogram2 [intensityHistogramCount2] = connectMap220 [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], intensityHistogramCount2++;
                                            intensityHistogram2 [intensityHistogramCount2] = 1, intensityHistogramCount2++;
                                        }
                                    }
                                    
                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMap200 [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                        findFlag = 0;
                                        
                                        for (int counter1 = 0; counter1 < intensityHistogramCount3/3; counter1++){
                                            if (intensityHistogram3 [counter1*3] == connectTemp && intensityHistogram3 [counter1*3+1] == connectMap200 [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                                intensityHistogram3 [counter1*3+2]++;
                                                findFlag = 1;
                                                break;
                                            }
                                        }
                                        
                                        if (findFlag == 0){
                                            intensityHistogram3 [intensityHistogramCount3] = connectTemp, intensityHistogramCount3++;
                                            intensityHistogram3 [intensityHistogramCount3] = connectMap200 [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], intensityHistogramCount3++;
                                            intensityHistogram3 [intensityHistogramCount3] = 1, intensityHistogramCount3++;
                                        }
                                    }
                                    
                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                        findFlag = 0;
                                        
                                        if (connect4 != connectTemp || map4 != connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                            for (int counter1 = 0; counter1 < intensityHistogramCount4/3; counter1++){
                                                if (intensityHistogram4 [counter1*3] == connectTemp && intensityHistogram4 [counter1*3+1] == connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                                    intensityHistogram4 [counter1*3+2]++;
                                                    findFlag = 1;
                                                    connect4 = connectTemp, map4 = connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], position4 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                intensityHistogram4 [intensityHistogramCount4] = connectTemp, intensityHistogramCount4++;
                                                intensityHistogram4 [intensityHistogramCount4] = connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], intensityHistogramCount4++;
                                                intensityHistogram4 [intensityHistogramCount4] = 1, intensityHistogramCount4++;
                                                connect4 = connectTemp, map4 = connectMapA [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], position4 = intensityHistogramCount4/3;
                                            }
                                        }
                                        else intensityHistogram4 [position4*3+2]++;
                                    }
                                    
                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                        findFlag = 0;
                                        
                                        if (connect5 != connectTemp || map5 != connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                            for (int counter1 = 0; counter1 < intensityHistogramCount5/3; counter1++){
                                                if (intensityHistogram5 [counter1*3] == connectTemp && intensityHistogram5 [counter1*3+1] == connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                                    intensityHistogram5 [counter1*3+2]++;
                                                    findFlag = 1;
                                                    connect5 = connectTemp, map5 = connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], position5 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                intensityHistogram5 [intensityHistogramCount5] = connectTemp, intensityHistogramCount5++;
                                                intensityHistogram5 [intensityHistogramCount5] = connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], intensityHistogramCount5++;
                                                intensityHistogram5 [intensityHistogramCount5] = 1, intensityHistogramCount5++;
                                                connect5 = connectTemp, map5 = connectMapB [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], position5 = intensityHistogramCount5/3;
                                            }
                                        }
                                        else intensityHistogram5 [position5*3+2]++;
                                    }
                                    
                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                        findFlag = 0;
                                        
                                        if (connect6 != connectTemp || map6 != connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                            for (int counter1 = 0; counter1 < intensityHistogramCount6/3; counter1++){
                                                if (intensityHistogram6 [counter1*3] == connectTemp && intensityHistogram6 [counter1*3+1] == connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                                    intensityHistogram6 [counter1*3+2]++;
                                                    findFlag = 1;
                                                    connect6 = connectTemp, map6 = connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], position6 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                intensityHistogram6 [intensityHistogramCount6] = connectTemp, intensityHistogramCount6++;
                                                intensityHistogram6 [intensityHistogramCount6] = connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], intensityHistogramCount6++;
                                                intensityHistogram6 [intensityHistogramCount6] = 1, intensityHistogramCount6++;
                                                connect6 = connectTemp, map6 = connectMapC [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], position6 = intensityHistogramCount6/3;
                                            }
                                        }
                                        else intensityHistogram6 [position6*3+2]++;
                                    }
                                    
                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectMapD [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart] != 0){
                                        findFlag = 0;
                                        
                                        if (connect7 != connectTemp || map7 != connectMapD [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                            for (int counter1 = 0; counter1 < intensityHistogramCount7/3; counter1++){
                                                if (intensityHistogram7 [counter1*3] == connectTemp && intensityHistogram7 [counter1*3+1] == connectMapD [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart]){
                                                    intensityHistogram7 [counter1*3+2]++;
                                                    findFlag = 1;
                                                    connect7 = connectTemp, map7 = connectMapD [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], position7 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                intensityHistogram7 [intensityHistogramCount7] = connectTemp, intensityHistogramCount7++;
                                                intensityHistogram7 [intensityHistogramCount7] = connectMapD [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], intensityHistogramCount7++;
                                                intensityHistogram7 [intensityHistogramCount7] = 1, intensityHistogramCount7++;
                                                connect7 = connectTemp, map7 = connectMapD [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart], position7 = intensityHistogramCount7/3;
                                            }
                                        }
                                        else intensityHistogram7 [position7*3+2]++;
                                    }
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < intensityHistogramCount2/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<intensityHistogram [counterA*3+counterB];
                    //	cout<<" intensityHistogram "<<counterA+1<<" "<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < intensityHistogramCount2/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<intensityHistogram2 [counterA*3+counterB];
                    //	cout<<" intensityHistogram2 "<<counterA+1<<" "<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < intensityHistogramCount2/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<intensityHistogram3 [counterA*3+counterB];
                    //	cout<<" intensityHistogram3 "<<counterA+1<<" "<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < intensityHistogramCount2/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<intensityHistogram4 [counterA*3+counterB];
                    //	cout<<" intensityHistogram4 "<<counterA+1<<" "<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < intensityHistogramCount2/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<intensityHistogram5 [counterA*3+counterB];
                    //	cout<<" intensityHistogram5 "<<counterA+1<<" "<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < intensityHistogramCount2/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<intensityHistogram6 [counterA*3+counterB];
                    //	cout<<" intensityHistogram6 "<<counterA+1<<" "<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < intensityHistogramCount2/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<intensityHistogram7 [counterA*3+counterB];
                    //	cout<<" intensityHistogram7 "<<counterA+1<<" "<<endl;
                    //}
                    
                    //------Select Largest Connect Group >> int intensityHistogramList []------
                    //1. hist1 no, 2. hist2 no, 3. hist3 no,.......
                    
                    errorNoHold = 36;
                    int *intensityHistogramList = new int [(maxCount+1)*7+5];
                    errorNoHold = 37;
                    int *intensityHistogramList2 = new int [(maxCount+1)*7+5];
                    
                    for (int counter1 = 0; counter1 < (maxCount+1)*7+5; counter1++){
                        intensityHistogramList [counter1] = 0;
                        intensityHistogramList2 [counter1] = 0;
                    }
                    
                    int countPreviousTemp = 0;
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount/3; counter1++){
                        countPreviousTemp = 0;
                        
                        if (intensityHistogramList [intensityHistogram [counter1*3]*7] != 0){
                            for (int counter2 = 0; counter2 < intensityHistogramCount/3; counter2++){
                                if (intensityHistogram [counter2*3] == intensityHistogram [counter1*3] && intensityHistogram [counter2*3+1] == intensityHistogramList [intensityHistogram [counter1*3]*7]){
                                    countPreviousTemp = intensityHistogram [counter2*3+2];
                                    break;
                                }
                            }
                            
                            if (countPreviousTemp > intensityHistogram [counter1*3+2]) intensityHistogramList [intensityHistogram [counter1*3]*7] = intensityHistogram [counter1*3+1];
                        }
                        else intensityHistogramList [intensityHistogram [counter1*3]*7] = intensityHistogram [counter1*3+1];
                    }
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount2/3; counter1++){
                        countPreviousTemp = 0;
                        
                        if (intensityHistogramList [intensityHistogram2 [counter1*3]*7+1] != 0){
                            for (int counter2 = 0; counter2 < intensityHistogramCount2/3; counter2++){
                                if (intensityHistogram2 [counter2*3] == intensityHistogram2 [counter1*3] && intensityHistogram2 [counter2*3+1] == intensityHistogramList [intensityHistogram2 [counter1*3]*7+1]){
                                    countPreviousTemp = intensityHistogram2 [counter2*3+2];
                                    break;
                                }
                            }
                            
                            if (countPreviousTemp > intensityHistogram2 [counter1*3+2]) intensityHistogramList [intensityHistogram2 [counter1*3]*7+1] = intensityHistogram2 [counter1*3+1];
                        }
                        else intensityHistogramList [intensityHistogram2 [counter1*3]*7+1] = intensityHistogram2 [counter1*3+1];
                    }
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount3/3; counter1++){
                        countPreviousTemp = 0;
                        
                        if (intensityHistogramList [intensityHistogram3 [counter1*3]*7+2] != 0){
                            for (int counter2 = 0; counter2 < intensityHistogramCount3/3; counter2++){
                                if (intensityHistogram3 [counter2*3] == intensityHistogram3 [counter1*3] && intensityHistogram3 [counter2*3+1] == intensityHistogramList [intensityHistogram3 [counter1*3]*7+2]){
                                    countPreviousTemp = intensityHistogram3 [counter2*3+2];
                                    break;
                                }
                            }
                            
                            if (countPreviousTemp > intensityHistogram3 [counter1*3+2]) intensityHistogramList [intensityHistogram3 [counter1*3]*7+2] = intensityHistogram3 [counter1*3+1];
                        }
                        else intensityHistogramList [intensityHistogram3 [counter1*3]*7+2] = intensityHistogram3 [counter1*3+1];
                    }
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount4/3; counter1++){
                        countPreviousTemp = 0;
                        
                        if (intensityHistogramList [intensityHistogram4 [counter1*3]*7+3] != 0){
                            for (int counter2 = 0; counter2 < intensityHistogramCount4/3; counter2++){
                                if (intensityHistogram4 [counter2*3] == intensityHistogram4 [counter1*3] && intensityHistogram4 [counter2*3+1] == intensityHistogramList [intensityHistogram4 [counter1*3]*7+3]){
                                    countPreviousTemp = intensityHistogram4 [counter2*3+2];
                                    break;
                                }
                            }
                            
                            if (countPreviousTemp > intensityHistogram4 [counter1*3+2]) intensityHistogramList [intensityHistogram4 [counter1*3]*7+3] = intensityHistogram4 [counter1*3+1];
                        }
                        else intensityHistogramList [intensityHistogram4 [counter1*3]*7+3] = intensityHistogram4 [counter1*3+1];
                    }
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount5/3; counter1++){
                        countPreviousTemp = 0;
                        
                        if (intensityHistogramList [intensityHistogram5 [counter1*3]*7+4] != 0){
                            for (int counter2 = 0; counter2 < intensityHistogramCount5/3; counter2++){
                                if (intensityHistogram5 [counter2*3] == intensityHistogram5 [counter1*3] && intensityHistogram5 [counter2*3+1] == intensityHistogramList [intensityHistogram5 [counter1*3]*7+4]){
                                    countPreviousTemp = intensityHistogram5 [counter2*3+2];
                                    break;
                                }
                            }
                            
                            if (countPreviousTemp > intensityHistogram5 [counter1*3+2]) intensityHistogramList [intensityHistogram5 [counter1*3]*7+4] = intensityHistogram5 [counter1*3+1];
                        }
                        else intensityHistogramList [intensityHistogram5 [counter1*3]*7+4] = intensityHistogram5 [counter1*3+1];
                    }
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount6/3; counter1++){
                        countPreviousTemp = 0;
                        
                        if (intensityHistogramList [intensityHistogram6 [counter1*3]*7+5] != 0){
                            for (int counter2 = 0; counter2 < intensityHistogramCount6/3; counter2++){
                                if (intensityHistogram6 [counter2*3] == intensityHistogram6 [counter1*3] && intensityHistogram6 [counter2*3+1] == intensityHistogramList [intensityHistogram6 [counter1*3]*7+5]){
                                    countPreviousTemp = intensityHistogram6 [counter2*3+2];
                                    break;
                                }
                            }
                            
                            if (countPreviousTemp > intensityHistogram6 [counter1*3+2]) intensityHistogramList [intensityHistogram6 [counter1*3]*7+5] = intensityHistogram6 [counter1*3+1];
                        }
                        else intensityHistogramList [intensityHistogram6 [counter1*3]*7+5] = intensityHistogram6 [counter1*3+1];
                    }
                    
                    for (int counter1 = 0; counter1 < intensityHistogramCount7/3; counter1++){
                        countPreviousTemp = 0;
                        
                        if (intensityHistogramList [intensityHistogram7 [counter1*3]*7+6] != 0){
                            for (int counter2 = 0; counter2 < intensityHistogramCount7/3; counter2++){
                                if (intensityHistogram7 [counter2*3] == intensityHistogram7 [counter1*3] && intensityHistogram7 [counter2*3+1] == intensityHistogramList [intensityHistogram7 [counter1*3]*7+6]){
                                    countPreviousTemp = intensityHistogram7 [counter2*3+2];
                                    break;
                                }
                            }
                            
                            if (countPreviousTemp > intensityHistogram7 [counter1*3+2]) intensityHistogramList [intensityHistogram7 [counter1*3]*7+6] = intensityHistogram7 [counter1*3+1];
                        }
                        else intensityHistogramList [intensityHistogram7 [counter1*3]*7+6] = intensityHistogram7 [counter1*3+1];
                    }
                    
                    //for (int counterA = 1; counterA < maxCount+1; counterA++){
                    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<intensityHistogramList [counterA*7+counterB];
                    //	cout<<" intensityHistogramList "<<counterA<<" "<<endl;
                    //}
                    
                    delete [] intensityHistogram;
                    delete [] intensityHistogram2;
                    delete [] intensityHistogram3;
                    delete [] intensityHistogram4;
                    delete [] intensityHistogram5;
                    delete [] intensityHistogram6;
                    delete [] intensityHistogram7;
                    
                    for (int counter1 = 0; counter1 < (maxCount+1)*7+5; counter1++) intensityHistogramList2 [counter1] = intensityHistogramList [counter1];
                    
                    //------Area and Intensity Information------
                    errorNoHold = 38;
                    int *areaIntensityList = new int [(maxCount+1)*2+5];
                    
                    for (int counter1 = 0; counter1 < (maxCount+1)*2+5; counter1++) areaIntensityList [counter1] = 0;
                    
                    if (processType == 2){
                        for (int counter1 = 0; counter1 < xyPositionCenterCurrentCount/6; counter1++){
                            areaIntensityList [arrayXYPositionCenterCurrent [counter1*6+4]*2] = arrayXYPositionCenterCurrent [counter1*6+2];
                            areaIntensityList [arrayXYPositionCenterCurrent [counter1*6+4]*2+1] = arrayXYPositionCenterCurrent [counter1*6+3];
                        }
                    }
                    else if (processType == 1 || processType == 3){
                        for (int counter1 = 0; counter1 < xyPositionCenterPreviousCount/6; counter1++){
                            areaIntensityList [arrayXYPositionCenterPrevious [counter1*6+4]*2] = arrayXYPositionCenterPrevious [counter1*6+2];
                            areaIntensityList [arrayXYPositionCenterPrevious [counter1*6+4]*2+1] = arrayXYPositionCenterPrevious [counter1*6+3];
                        }
                    }
                    
                    //for (int counterA = 1; counterA < maxCount+1; counterA++){
                    //	cout<<counterA<<" "<<areaIntensityList [counterA*2]<<" "<<areaIntensityList [counterA*2+1]<<" areaIntensityList"<<endl;
                    //}
                    
                    //------Attached Number List >> attachedNumberList [][]------
                    errorNoHold = 39;
                    int *attachedNumberList = new int [maxCount+2];
                    int attachedNumberListCount = 0;
                    int attachedNumberListLimit = 0;
                    
                    for (int counter1 = 0; counter1 < maxCount+2; counter1++) attachedNumberList [counter1] = 0;
                    
                    int attachFindA = 0;
                    int attachFindA2 = 0;
                    int attachFindA3 = 0;
                    int attachFindB = 0;
                    int attachFindB2 = 0;
                    int attachFindB3 = 0;
                    int attachFindC = 0;
                    int attachFindC2 = 0;
                    int attachFindC3 = 0;
                    int attachFindD = 0;
                    int attachFindD2 = 0;
                    int attachFindD3 = 0;
                    int attachFindE = 0;
                    int attachFindE2 = 0;
                    int attachFindE3 = 0;
                    int attachFindF = 0;
                    int attachFindF2 = 0;
                    int attachFindF3 = 0;
                    int attachFindG = 0;
                    int attachFindG2 = 0;
                    int attachFindG3 = 0;
                    int attachFindH = 0;
                    int attachFindH2 = 0;
                    int attachFindH3 = 0;
                    
                    if (processType == 1 || processType == 3){
                        int connectTemp = 0;
                        int attachPointCount = 0;
                        
                        for (int counterY = 0; counterY < trackAreaSize; counterY++){
                            for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                if (arrayCellTrackingPreviousMap [counterY][counterX] > 0){
                                    if (attachedNumberListLimit-10 < attachedNumberListCount){
                                        errorNoHold = 40;
                                        int *arrayUpDate = new int [attachedNumberListCount+10];
                                        
                                        for (int counter1 = 0; counter1 < attachedNumberListCount; counter1++) arrayUpDate [counter1] = attachedNumberList [counter1];
                                        
                                        delete [] attachedNumberList;
                                        errorNoHold = 41;
                                        attachedNumberList = new int [attachedNumberListLimit+5000];
                                        attachedNumberListLimit = attachedNumberListLimit+5000;
                                        
                                        for (int counter1 = 0; counter1 < attachedNumberListCount; counter1++) attachedNumberList [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    connectTemp = arrayCellTrackingPreviousMap [counterY][counterX];
                                    attachPointCount = 0;
                                    
                                    if (counterY-1 >= 0 && counterX-1 >= 0 && arrayCellTrackingPreviousMap [counterY-1][counterX-1] > 0 && arrayCellTrackingPreviousMap [counterY-1][counterX-1] != connectTemp){
                                        if (attachFindA != arrayCellTrackingPreviousMap [counterY][counterX] || attachFindA2 != arrayCellTrackingPreviousMap [counterY-1][counterX-1]){
                                            findFlag = 0;
                                            
                                            for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                                                if (attachedNumberList [counter1*5] == arrayCellTrackingPreviousMap [counterY][counterX] && attachedNumberList [counter1*5+1] == arrayCellTrackingPreviousMap [counterY-1][counterX-1]){
                                                    if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                                    findFlag = 1, attachFindA = arrayCellTrackingPreviousMap [counterY][counterX], attachFindA2 = arrayCellTrackingPreviousMap [counterY-1][counterX-1], attachFindA3 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingPreviousMap [counterY][counterX], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingPreviousMap [counterY-1][counterX-1], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachFindA = arrayCellTrackingPreviousMap [counterY][counterX], attachFindA2 = arrayCellTrackingPreviousMap [counterY-1][counterX-1], attachFindA3 = attachedNumberListCount/5;
                                                attachPointCount++;
                                            }
                                        }
                                        else if (attachPointCount == 0) attachedNumberList [attachFindA3*5+2]++, attachPointCount++;
                                    }
                                    
                                    if (counterY-1 >= 0 && arrayCellTrackingPreviousMap [counterY-1][counterX] > 0 && arrayCellTrackingPreviousMap [counterY-1][counterX] != connectTemp){
                                        if (attachFindB != arrayCellTrackingPreviousMap [counterY][counterX] || attachFindB2 != arrayCellTrackingPreviousMap [counterY-1][counterX]){
                                            findFlag = 0;
                                            
                                            for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                                                if (attachedNumberList [counter1*5] == arrayCellTrackingPreviousMap [counterY][counterX] && attachedNumberList [counter1*5+1] == arrayCellTrackingPreviousMap [counterY-1][counterX]){
                                                    if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                                    findFlag = 1, attachFindB = arrayCellTrackingPreviousMap [counterY][counterX], attachFindB2 = arrayCellTrackingPreviousMap [counterY-1][counterX], attachFindB3 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingPreviousMap [counterY][counterX], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingPreviousMap [counterY-1][counterX], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachFindB = arrayCellTrackingPreviousMap [counterY][counterX], attachFindB2 = arrayCellTrackingPreviousMap [counterY-1][counterX], attachFindB3 = attachedNumberListCount/5;
                                                attachPointCount++;
                                            }
                                        }
                                        else if (attachPointCount == 0) attachedNumberList [attachFindB3*5+2]++, attachPointCount++;
                                    }
                                    
                                    if (counterY-1 >= 0 && counterX+1 < trackAreaSize && arrayCellTrackingPreviousMap [counterY-1][counterX+1] > 0 && arrayCellTrackingPreviousMap [counterY-1][counterX+1] != connectTemp){
                                        if (attachFindC != arrayCellTrackingPreviousMap [counterY][counterX] || attachFindC2 != arrayCellTrackingPreviousMap [counterY-1][counterX+1]){
                                            findFlag = 0;
                                            
                                            for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                                                if (attachedNumberList [counter1*5] == arrayCellTrackingPreviousMap [counterY][counterX] && attachedNumberList [counter1*5+1] == arrayCellTrackingPreviousMap [counterY-1][counterX+1]){
                                                    if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                                    findFlag = 1, attachFindC = arrayCellTrackingPreviousMap [counterY][counterX], attachFindC2 = arrayCellTrackingPreviousMap [counterY-1][counterX+1], attachFindC3 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingPreviousMap [counterY][counterX], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingPreviousMap [counterY-1][counterX+1], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachFindC = arrayCellTrackingPreviousMap [counterY][counterX], attachFindC2 = arrayCellTrackingPreviousMap [counterY-1][counterX+1], attachFindC3 = attachedNumberListCount/5;
                                                attachPointCount++;
                                            }
                                        }
                                        else if (attachPointCount == 0) attachedNumberList [attachFindC3*5+2]++, attachPointCount++;
                                    }
                                    
                                    if (counterX+1 < trackAreaSize && arrayCellTrackingPreviousMap [counterY][counterX+1] > 0 && arrayCellTrackingPreviousMap [counterY][counterX+1] != connectTemp){
                                        if (attachFindD != arrayCellTrackingPreviousMap [counterY][counterX] || attachFindD2 != arrayCellTrackingPreviousMap [counterY][counterX+1]){
                                            findFlag = 0;
                                            
                                            for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                                                if (attachedNumberList [counter1*5] == arrayCellTrackingPreviousMap [counterY][counterX] && attachedNumberList [counter1*5+1] == arrayCellTrackingPreviousMap [counterY][counterX+1]){
                                                    if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                                    findFlag = 1, attachFindD = arrayCellTrackingPreviousMap [counterY][counterX], attachFindD2 = arrayCellTrackingPreviousMap [counterY][counterX+1], attachFindD3 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingPreviousMap [counterY][counterX], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingPreviousMap [counterY][counterX+1], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachFindD = arrayCellTrackingPreviousMap [counterY][counterX], attachFindD2 = arrayCellTrackingPreviousMap [counterY][counterX+1], attachFindD3 = attachedNumberListCount/5;
                                                attachPointCount++;
                                            }
                                        }
                                        else if (attachPointCount == 0) attachedNumberList [attachFindD3*5+2]++, attachPointCount++;
                                    }
                                    
                                    if (counterY+1 < trackAreaSize && counterX+1 < trackAreaSize && arrayCellTrackingPreviousMap [counterY+1][counterX+1] > 0 && arrayCellTrackingPreviousMap [counterY+1][counterX+1] != connectTemp){
                                        if (attachFindE != arrayCellTrackingPreviousMap [counterY][counterX] || attachFindE2 != arrayCellTrackingPreviousMap [counterY+1][counterX+1]){
                                            findFlag = 0;
                                            
                                            for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                                                if (attachedNumberList [counter1*5] == arrayCellTrackingPreviousMap [counterY][counterX] && attachedNumberList [counter1*5+1] == arrayCellTrackingPreviousMap [counterY+1][counterX+1]){
                                                    if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                                    findFlag = 1, attachFindE = arrayCellTrackingPreviousMap [counterY][counterX], attachFindE2 = arrayCellTrackingPreviousMap [counterY+1][counterX+1], attachFindE3 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingPreviousMap [counterY][counterX], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingPreviousMap [counterY+1][counterX+1], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachFindE = arrayCellTrackingPreviousMap [counterY][counterX], attachFindE2 = arrayCellTrackingPreviousMap [counterY+1][counterX+1], attachFindE3 = attachedNumberListCount/5;
                                                attachPointCount++;
                                            }
                                        }
                                        else if (attachPointCount == 0) attachedNumberList [attachFindE3*5+2]++, attachPointCount++;
                                    }
                                    
                                    if (counterY+1 < trackAreaSize && arrayCellTrackingPreviousMap [counterY+1][counterX] > 0 && arrayCellTrackingPreviousMap [counterY+1][counterX] != connectTemp){
                                        if (attachFindF != arrayCellTrackingPreviousMap [counterY][counterX] || attachFindF2 != arrayCellTrackingPreviousMap [counterY+1][counterX]){
                                            findFlag = 0;
                                            
                                            for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                                                if (attachedNumberList [counter1*5] == arrayCellTrackingPreviousMap [counterY][counterX] && attachedNumberList [counter1*5+1] == arrayCellTrackingPreviousMap [counterY+1][counterX]){
                                                    if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                                    findFlag = 1, attachFindF = arrayCellTrackingPreviousMap [counterY][counterX], attachFindF2 = arrayCellTrackingPreviousMap [counterY+1][counterX], attachFindF3 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingPreviousMap [counterY][counterX], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingPreviousMap [counterY+1][counterX], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachFindF = arrayCellTrackingPreviousMap [counterY][counterX], attachFindF2 = arrayCellTrackingPreviousMap [counterY+1][counterX], attachFindF3 = attachedNumberListCount/5;
                                                attachPointCount++;
                                            }
                                        }
                                        else if (attachPointCount == 0) attachedNumberList [attachFindF3*5+2]++, attachPointCount++;
                                    }
                                    
                                    if (counterY+1 < trackAreaSize && counterX-1 >= 0 && arrayCellTrackingPreviousMap [counterY+1][counterX-1] > 0 && arrayCellTrackingPreviousMap [counterY+1][counterX-1] != connectTemp){
                                        if (attachFindG != arrayCellTrackingPreviousMap [counterY][counterX] || attachFindG2 != arrayCellTrackingPreviousMap [counterY+1][counterX-1]){
                                            findFlag = 0;
                                            
                                            for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                                                if (attachedNumberList [counter1*5] == arrayCellTrackingPreviousMap [counterY][counterX] && attachedNumberList [counter1*5+1] == arrayCellTrackingPreviousMap [counterY+1][counterX-1]){
                                                    if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                                    findFlag = 1, attachFindG = arrayCellTrackingPreviousMap [counterY][counterX], attachFindG2 = arrayCellTrackingPreviousMap [counterY+1][counterX-1], attachFindB3 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingPreviousMap [counterY][counterX], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingPreviousMap [counterY+1][counterX-1], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachFindG = arrayCellTrackingPreviousMap [counterY][counterX], attachFindG2 = arrayCellTrackingPreviousMap [counterY+1][counterX-1], attachFindG3 = attachedNumberListCount/5;
                                                attachPointCount++;
                                            }
                                        }
                                        else if (attachPointCount == 0) attachedNumberList [attachFindG3*5+2]++, attachPointCount++;
                                    }
                                    
                                    if (counterX-1 >= 0 && arrayCellTrackingPreviousMap [counterY][counterX-1] > 0 && arrayCellTrackingPreviousMap [counterY][counterX-1] != connectTemp){
                                        if (attachFindH != arrayCellTrackingPreviousMap [counterY][counterX] || attachFindH2 != arrayCellTrackingPreviousMap [counterY][counterX-1]){
                                            findFlag = 0;
                                            
                                            for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                                                if (attachedNumberList [counter1*5] == arrayCellTrackingPreviousMap [counterY][counterX] && attachedNumberList [counter1*5+1] == arrayCellTrackingPreviousMap [counterY][counterX-1]){
                                                    if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                                    findFlag = 1, attachFindH = arrayCellTrackingPreviousMap [counterY][counterX], attachFindH2 = arrayCellTrackingPreviousMap [counterY][counterX-1], attachFindH3 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingPreviousMap [counterY][counterX], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingPreviousMap [counterY][counterX-1], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachFindH = arrayCellTrackingPreviousMap [counterY][counterX], attachFindH2 = arrayCellTrackingPreviousMap [counterY][counterX-1], attachFindH3 = attachedNumberListCount/5;
                                                attachPointCount++;
                                            }
                                        }
                                        else if (attachPointCount == 0) attachedNumberList [attachFindH3*5+2]++, attachPointCount++;
                                    }
                                }
                            }
                        }
                    }
                    else if (processType == 2){
                        int connectTemp = 0;
                        int attachPointCount = 0;
                        
                        for (int counterY = 0; counterY < trackAreaSize; counterY++){
                            for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                if (arrayCellTrackingCurrentMap [counterY][counterX] != 0){
                                    if (attachedNumberListLimit-10 < attachedNumberListCount){
                                        errorNoHold = 42;
                                        int *arrayUpDate = new int [attachedNumberListCount+10];
                                        
                                        for (int counter1 = 0; counter1 < attachedNumberListCount; counter1++) arrayUpDate [counter1] = attachedNumberList [counter1];
                                        
                                        delete [] attachedNumberList;
                                        errorNoHold = 43;
                                        attachedNumberList = new int [attachedNumberListLimit+5000];
                                        attachedNumberListLimit = attachedNumberListLimit+5000;
                                        
                                        for (int counter1 = 0; counter1 < attachedNumberListCount; counter1++) attachedNumberList [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    connectTemp = arrayCellTrackingCurrentMap [counterY][counterX];
                                    attachPointCount = 0;
                                    
                                    if (counterY-1 >= 0 && counterX-1 >= 0 && arrayCellTrackingCurrentMap [counterY-1][counterX-1] != 0 && arrayCellTrackingCurrentMap [counterY-1][counterX-1] != connectTemp){
                                        if (attachFindA != arrayCellTrackingCurrentMap [counterY][counterX] || attachFindA2 != arrayCellTrackingCurrentMap [counterY-1][counterX-1]){
                                            findFlag = 0;
                                            
                                            for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                                                if (attachedNumberList [counter1*5] == arrayCellTrackingCurrentMap [counterY][counterX] && attachedNumberList [counter1*5+1] == arrayCellTrackingCurrentMap [counterY-1][counterX-1]){
                                                    if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                                    findFlag = 1, attachFindA = arrayCellTrackingCurrentMap [counterY][counterX], attachFindA2 = arrayCellTrackingCurrentMap [counterY-1][counterX-1], attachFindA3 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingCurrentMap [counterY][counterX], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingCurrentMap [counterY-1][counterX-1], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachFindA = arrayCellTrackingCurrentMap [counterY][counterX], attachFindA2 = arrayCellTrackingCurrentMap [counterY-1][counterX-1], attachFindA3 = attachedNumberListCount/5;
                                                attachPointCount++;
                                            }
                                        }
                                        else if (attachPointCount == 0) attachedNumberList [attachFindA3*5+2]++, attachPointCount++;
                                    }
                                    
                                    if (counterY-1 >= 0 && arrayCellTrackingCurrentMap [counterY-1][counterX] != 0 && arrayCellTrackingCurrentMap [counterY-1][counterX] != connectTemp){
                                        if (attachFindB != arrayCellTrackingCurrentMap [counterY][counterX] || attachFindB2 != arrayCellTrackingCurrentMap [counterY-1][counterX]){
                                            findFlag = 0;
                                            
                                            for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                                                if (attachedNumberList [counter1*5] == arrayCellTrackingCurrentMap [counterY][counterX] && attachedNumberList [counter1*5+1] == arrayCellTrackingCurrentMap [counterY-1][counterX]){
                                                    if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                                    findFlag = 1, attachFindB = arrayCellTrackingCurrentMap [counterY][counterX], attachFindB2 = arrayCellTrackingCurrentMap [counterY-1][counterX], attachFindB3 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingCurrentMap [counterY][counterX], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingCurrentMap [counterY-1][counterX], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachFindB = arrayCellTrackingCurrentMap [counterY][counterX], attachFindB2 = arrayCellTrackingCurrentMap [counterY-1][counterX], attachFindB3 = attachedNumberListCount/5;
                                                attachPointCount++;
                                            }
                                        }
                                        else if (attachPointCount == 0) attachedNumberList [attachFindB3*5+2]++, attachPointCount++;
                                    }
                                    
                                    if (counterY-1 >= 0 && counterX+1 < trackAreaSize && arrayCellTrackingCurrentMap [counterY-1][counterX+1] != 0 && arrayCellTrackingCurrentMap [counterY-1][counterX+1] != connectTemp){
                                        if (attachFindC != arrayCellTrackingCurrentMap [counterY][counterX] || attachFindC2 != arrayCellTrackingCurrentMap [counterY-1][counterX+1]){
                                            findFlag = 0;
                                            
                                            for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                                                if (attachedNumberList [counter1*5] == arrayCellTrackingCurrentMap [counterY][counterX] && attachedNumberList [counter1*5+1] == arrayCellTrackingCurrentMap [counterY-1][counterX+1]){
                                                    if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                                    findFlag = 1, attachFindC = arrayCellTrackingCurrentMap [counterY][counterX], attachFindC2 = arrayCellTrackingCurrentMap [counterY-1][counterX+1], attachFindC3 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingCurrentMap [counterY][counterX], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingCurrentMap [counterY-1][counterX+1], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachFindC = arrayCellTrackingCurrentMap [counterY][counterX], attachFindC2 = arrayCellTrackingCurrentMap [counterY-1][counterX+1], attachFindC3 = attachedNumberListCount/5;
                                                attachPointCount++;
                                            }
                                        }
                                        else if (attachPointCount == 0) attachedNumberList [attachFindC3*5+2]++, attachPointCount++;
                                    }
                                    
                                    if (counterX+1 < trackAreaSize && arrayCellTrackingCurrentMap [counterY][counterX+1] != 0 && arrayCellTrackingCurrentMap [counterY][counterX+1] != connectTemp){
                                        if (attachFindD != arrayCellTrackingCurrentMap [counterY][counterX] || attachFindD2 != arrayCellTrackingCurrentMap [counterY][counterX+1]){
                                            findFlag = 0;
                                            
                                            for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                                                if (attachedNumberList [counter1*5] == arrayCellTrackingCurrentMap [counterY][counterX] && attachedNumberList [counter1*5+1] == arrayCellTrackingCurrentMap [counterY][counterX+1]){
                                                    if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                                    findFlag = 1, attachFindD = arrayCellTrackingCurrentMap [counterY][counterX], attachFindD2 = arrayCellTrackingCurrentMap [counterY][counterX+1], attachFindD3 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingCurrentMap [counterY][counterX], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingCurrentMap [counterY][counterX+1], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachFindD = arrayCellTrackingCurrentMap [counterY][counterX], attachFindD2 = arrayCellTrackingCurrentMap [counterY][counterX+1], attachFindD3 = attachedNumberListCount/5;
                                                attachPointCount++;
                                            }
                                        }
                                        else if (attachPointCount == 0) attachedNumberList [attachFindD3*5+2]++, attachPointCount++;
                                    }
                                    
                                    if (counterY+1 < trackAreaSize && counterX+1 < trackAreaSize && arrayCellTrackingCurrentMap [counterY+1][counterX+1] != 0 && arrayCellTrackingCurrentMap [counterY+1][counterX+1] != connectTemp){
                                        if (attachFindE != arrayCellTrackingCurrentMap [counterY][counterX] || attachFindE2 != arrayCellTrackingCurrentMap [counterY+1][counterX+1]){
                                            findFlag = 0;
                                            
                                            for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                                                if (attachedNumberList [counter1*5] == arrayCellTrackingCurrentMap [counterY][counterX] && attachedNumberList [counter1*5+1] == arrayCellTrackingCurrentMap [counterY+1][counterX+1]){
                                                    if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                                    findFlag = 1, attachFindE = arrayCellTrackingCurrentMap [counterY][counterX], attachFindE2 = arrayCellTrackingCurrentMap [counterY+1][counterX+1], attachFindE3 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingCurrentMap [counterY][counterX], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingCurrentMap [counterY+1][counterX+1], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachFindE = arrayCellTrackingCurrentMap [counterY][counterX], attachFindE2 = arrayCellTrackingCurrentMap [counterY+1][counterX+1], attachFindE3 = attachedNumberListCount/5;
                                                attachPointCount++;
                                            }
                                        }
                                        else if (attachPointCount == 0) attachedNumberList [attachFindE3*5+2]++, attachPointCount++;
                                    }
                                    
                                    if (counterY+1 < trackAreaSize && arrayCellTrackingCurrentMap [counterY+1][counterX] != 0 && arrayCellTrackingCurrentMap [counterY+1][counterX] != connectTemp){
                                        if (attachFindF != arrayCellTrackingCurrentMap [counterY][counterX] || attachFindF2 != arrayCellTrackingCurrentMap [counterY+1][counterX]){
                                            findFlag = 0;
                                            
                                            for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                                                if (attachedNumberList [counter1*5] == arrayCellTrackingCurrentMap [counterY][counterX] && attachedNumberList [counter1*5+1] == arrayCellTrackingCurrentMap [counterY+1][counterX]){
                                                    if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                                    findFlag = 1, attachFindF = arrayCellTrackingCurrentMap [counterY][counterX], attachFindF2 = arrayCellTrackingCurrentMap [counterY+1][counterX], attachFindF3 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingCurrentMap [counterY][counterX], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingCurrentMap [counterY+1][counterX], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachFindF = arrayCellTrackingCurrentMap [counterY][counterX], attachFindF2 = arrayCellTrackingCurrentMap [counterY+1][counterX], attachFindF3 = attachedNumberListCount/5;
                                                attachPointCount++;
                                            }
                                        }
                                        else if (attachPointCount == 0) attachedNumberList [attachFindF3*5+2]++, attachPointCount++;
                                    }
                                    
                                    if (counterY+1 < trackAreaSize && counterX-1 >= 0 && arrayCellTrackingCurrentMap [counterY+1][counterX-1] != 0 && arrayCellTrackingCurrentMap [counterY+1][counterX-1] != connectTemp){
                                        if (attachFindG != arrayCellTrackingCurrentMap [counterY][counterX] || attachFindG2 != arrayCellTrackingCurrentMap [counterY+1][counterX-1]){
                                            findFlag = 0;
                                            
                                            for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                                                if (attachedNumberList [counter1*5] == arrayCellTrackingCurrentMap [counterY][counterX] && attachedNumberList [counter1*5+1] == arrayCellTrackingCurrentMap [counterY+1][counterX-1]){
                                                    if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                                    findFlag = 1, attachFindG = arrayCellTrackingCurrentMap [counterY][counterX], attachFindG2 = arrayCellTrackingCurrentMap [counterY+1][counterX-1], attachFindB3 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingCurrentMap [counterY][counterX], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingCurrentMap [counterY+1][counterX-1], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachFindG = arrayCellTrackingCurrentMap [counterY][counterX], attachFindG2 = arrayCellTrackingCurrentMap [counterY+1][counterX-1], attachFindG3 = attachedNumberListCount/5;
                                                attachPointCount++;
                                            }
                                        }
                                        else if (attachPointCount == 0) attachedNumberList [attachFindG3*5+2]++, attachPointCount++;
                                    }
                                    
                                    if (counterX-1 >= 0 && arrayCellTrackingCurrentMap [counterY][counterX-1] != 0 && arrayCellTrackingCurrentMap [counterY][counterX-1] != connectTemp){
                                        if (attachFindH != arrayCellTrackingCurrentMap [counterY][counterX] || attachFindH2 != arrayCellTrackingCurrentMap [counterY][counterX-1]){
                                            findFlag = 0;
                                            
                                            for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                                                if (attachedNumberList [counter1*5] == arrayCellTrackingCurrentMap [counterY][counterX] && attachedNumberList [counter1*5+1] == arrayCellTrackingCurrentMap [counterY][counterX-1]){
                                                    if (attachPointCount == 0) attachedNumberList [counter1*5+2]++, attachPointCount++;
                                                    findFlag = 1, attachFindH = arrayCellTrackingCurrentMap [counterY][counterX], attachFindH2 = arrayCellTrackingCurrentMap [counterY][counterX-1], attachFindH3 = counter1;
                                                    break;
                                                }
                                            }
                                            
                                            if (findFlag == 0){
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingCurrentMap [counterY][counterX], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = arrayCellTrackingCurrentMap [counterY][counterX-1], attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 1, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachedNumberList [attachedNumberListCount] = 0, attachedNumberListCount++;
                                                attachFindH = arrayCellTrackingCurrentMap [counterY][counterX], attachFindH2 = arrayCellTrackingCurrentMap [counterY][counterX-1], attachFindH3 = attachedNumberListCount/5;
                                                attachPointCount++;
                                            }
                                        }
                                        else if (attachPointCount == 0) attachedNumberList [attachFindH3*5+2]++, attachPointCount++;
                                    }
                                }
                            }
                        }
                    }
                    
                    //1. connect No, 2. attached connect No, 3. attach Length, 4. Connect No line length, 5, attached connect No line length
                    
                    //for (int counterA = 1; counterA < attachedNumberListCount/5; counterA++){
                    //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<attachedNumberList [counterA*5+counterB];
                    //	cout<<" attachedNumberList "<<counterA<<" "<<endl;
                    //}
                    
                    errorNoHold = 44;
                    int *lineLength = new int [maxCount+5];
                    
                    for (int counter1 = 0; counter1 < maxCount+5; counter1++) lineLength [counter1] = 0;
                    
                    //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                    //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrevious [counterA*6+counterB];
                    //    cout<<" arrayCellTrackingPrevious "<<counterA<<endl;
                    //}
                    
                    if (processType == 1 || processType == 3){
                        for (int counter1 = 0; counter1 < cellTrackingPreviousCount/6; counter1++){
                            if (arrayCellTrackingPrevious [counter1*6+5] == 0 || arrayCellTrackingPrevious [counter1*6+5] == 1){
                                lineLength [arrayCellTrackingPrevious [counter1*6+3]]++;
                            }
                        }
                    }
                    else if (processType == 2){
                        for (int counter1 = 0; counter1 < cellTrackingCurrentCount/6; counter1++){
                            if (arrayCellTrackingCurrent [counter1*6+5] == 0 || arrayCellTrackingCurrent [counter1*6+5] == 1){
                                lineLength [arrayCellTrackingCurrent [counter1*6+3]]++;
                            }
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                        attachedNumberList [counter1*5+3] = lineLength [attachedNumberList [counter1*5]];
                        attachedNumberList [counter1*5+4] = lineLength [attachedNumberList [counter1*5+1]];
                    }
                    
                    delete [] lineLength;
                    
                    if (processType == 3){
                        if (cellAttachStatus == 0){
                            errorNoHold = 45;
                            arrayAttachTable = new int [(attachedNumberListCount/5)*6+50];
                            cellAttachCount = 0;
                            cellAttachLimit = (attachedNumberListCount/5)*6+50;
                            cellAttachStatus = 1;
                        }
                        
                        if (cellAttachCount+(attachedNumberListCount/5)*6+10 > cellAttachLimit){
                            errorNoHold = 46;
                            int *arraySourceTemp = new int [cellAttachCount+50];
                            for (int counter1 = 0; counter1 < cellAttachCount; counter1++) arraySourceTemp [counter1] = arrayAttachTable [counter1];
                            
                            delete [] arrayAttachTable;
                            errorNoHold = 47;
                            arrayAttachTable = new int [cellAttachLimit+(attachedNumberListCount/5)*6+50];
                            cellAttachLimit = cellAttachLimit+(attachedNumberListCount/5)*6+50;
                            
                            for (int counter1 = 0; counter1 < cellAttachCount; counter1++) arrayAttachTable [counter1] = arraySourceTemp [counter1];
                            delete [] arraySourceTemp;
                        }
                        
                        for (int counter1 = 0; counter1 < attachedNumberListCount/5; counter1++){
                            arrayAttachTable [cellAttachCount] = roundStatus-1, cellAttachCount++;
                            arrayAttachTable [cellAttachCount] = attachedNumberList [counter1*5], cellAttachCount++;
                            arrayAttachTable [cellAttachCount] = attachedNumberList [counter1*5+1], cellAttachCount++;
                            arrayAttachTable [cellAttachCount] = attachedNumberList [counter1*5+2], cellAttachCount++;
                            arrayAttachTable [cellAttachCount] = attachedNumberList [counter1*5+3], cellAttachCount++;
                            arrayAttachTable [cellAttachCount] = attachedNumberList [counter1*5+4], cellAttachCount++;
                        }
                        
                        //for (int counterA = 1; counterA < cellAttachCount/6; counterA++){
                        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayAttachTable [counterA*6+counterB];
                        //	cout<<" arrayAttachTable "<<counterA<<" "<<endl;
                        //}
                    }
                    
                    //for (int counterA = 0; counterA < attachedNumberListCount/5; counterA++){
                    //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<attachedNumberList [counterA*5+counterB];
                    //	cout<<" attachedNumberList "<<counterA<<" "<<endl;
                    //}
                    
                    //------Copy List to List2, which is use for groupLink determination------
                    errorNoHold = 48;
                    int *attachedNumberList2 = new int [attachedNumberListCount+2];
                    
                    for (int counterY = 0; counterY < attachedNumberListCount+2; counterY++) attachedNumberList2 [counterY] = 0;
                    for (int counterY = 0; counterY < attachedNumberListCount; counterY++) attachedNumberList2 [counterY] = attachedNumberList [counterY];
                    
                    //for (int counterA = 0; counterA < attachedNumberListCount/5; counterA++){
                    //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<attachedNumberList2 [counterA*5+counterB];
                    //	cout<<" attachedNumberList2 "<<counterA<<" "<<endl;
                    //}
                    
                    //------GroupLink Determination------
                    int maxEntry = 0;
                    
                    if (maxCount > attachedNumberListCount/5) maxEntry = maxCount;
                    else maxEntry = attachedNumberListCount/5;
                    
                    errorNoHold = 49;
                    int *listMaking = new int [maxEntry+2];
                    errorNoHold = 50;
                    int *listMaking2 = new int [maxEntry+2];
                    errorNoHold = 51;
                    int *groupLink = new int [maxEntry+2];
                    
                    int listCount = 0;
                    
                    for (int counter1 = 0; counter1 < maxCount+2; counter1++){
                        groupLink [counter1] = 0;
                        listMaking2 [counter1] = 0;
                        listMaking [counter1] = 0;
                    }
                    
                    int newLinkEntry1 = 0;
                    int terminationFlag = 0;
                    int newLinkEntry2 = 0;
                    
                    for (int counter1 = 1; counter1 < maxCount+1; counter1++){
                        newLinkEntry1 = 0;
                        
                        for (int counter2 = 0; counter2 < attachedNumberListCount/5; counter2++){
                            if (attachedNumberList2 [counter2*5] == counter1 && attachedNumberList2 [counter2*5+2] != 0){
                                listMaking [newLinkEntry1] = attachedNumberList2 [counter2*5+1];
                                attachedNumberList2 [counter2*5+2] = 0;
                                newLinkEntry1++;
                            }
                        }
                        
                        if (newLinkEntry1 != 0){
                            listCount++;
                            groupLink [counter1] = listCount;
                            
                            for (int counter2 = 0; counter2 < newLinkEntry1; counter2++) groupLink [listMaking [counter2]] = listCount;
                            
                            for (int counter2 = 0; counter2 < newLinkEntry1; counter2++){
                                if (listMaking [counter2] != 0){
                                    groupLink [listMaking [counter2]] = listCount;
                                    
                                    for (int counter3 = 1; counter3 < attachedNumberListCount/5; counter3++){
                                        if (counter3 == counter1 && attachedNumberList2 [counter3*5+1] != 0) attachedNumberList2 [counter3*5+2] = 0;
                                    }
                                }
                            }
                            
                            do{
                                
                                terminationFlag = 1;
                                newLinkEntry2 = 0;
                                
                                for (int counter2 = 0; counter2 < newLinkEntry1; counter2++){
                                    for (int counter3 = 0; counter3 < attachedNumberListCount/5; counter3++){
                                        if (attachedNumberList2 [counter3*5] == listMaking [counter2] && attachedNumberList2 [counter3*5+2] != 0){
                                            listMaking2 [newLinkEntry2] = attachedNumberList2 [counter3*5+1];
                                            attachedNumberList2 [counter3*5+2] = 0;
                                            newLinkEntry2++;
                                        }
                                    }
                                    
                                    groupLink [listMaking [counter2]] = listCount;
                                    
                                    for (int counter3 = 0; counter3 < newLinkEntry2; counter3++) groupLink [listMaking2 [counter3]] = listCount;
                                }
                                
                                if (newLinkEntry2 == 0) terminationFlag = 0;
                                else{
                                    
                                    for (int counter2 = 0; counter2 < newLinkEntry2; counter2++) listMaking [counter2] = listMaking2 [counter2];
                                    
                                    newLinkEntry1 = newLinkEntry2;
                                }
                                
                            } while (terminationFlag == 1);
                        }
                    }
                    
                    delete [] listMaking;
                    delete [] listMaking2;
                    
                    for (int counter1 = 1; counter1 < maxCount+1; counter1++){
                        if (groupLink [counter1] == 0 && areaIntensityList [counter1*2] != 0){
                            listCount++;
                            groupLink [counter1] = listCount;
                        }
                    }
                    
                    delete [] attachedNumberList2;
                    
                    //for (int counterA = 1; counterA < maxCount+1; counterA++) cout<<" "<<counterA<<" "<<groupLink [counterA]<<" GroupLink"<<endl;
                    
                    //------Group List Initialize------
                    errorNoHold = 53;
                    int *groupList = new int [maxCount+2];
                    errorNoHold = 54;
                    int *groupList2 = new int [maxCount+2];
                    errorNoHold = 55;
                    int *groupRound = new int [maxCount+2];
                    
                    for (int counter1 = 0; counter1 < maxCount+2; counter1++){
                        groupList [counter1] = 0;
                        groupList2 [counter1] = 0;
                        groupRound [counter1] = 0;
                    }
                    
                    //------Main Process------
                    int groupEntryCount = 1;
                    int existFindFlag = 0;
                    int entryConnectNumber = 0;
                    int numberOfEntry = 0;
                    int collectCount = 0;
                    int terminationFlag1 = 0;
                    int tempGroupNumber = 0; //------Hold group number for attached group------
                    int largestConnect = 0;
                    int largestConnectCount = 0; //------Largest Area connect number------
                    int attachEntry = 0;
                    int connectTotalTemp1 = 0;
                    int connectTotalTemp2 = 0;
                    int attachTemp = 0;
                    int numberOfassociates = 0;
                    int groupNoTemp = 0;
                    int groupSource = 0;
                    
                    double ratio1 = 0;
                    double ratio2 = 0;
                    
                    for (int counter1 = 0; counter1 < 7; counter1++){ //------Process from 240, 220, 200, MapA, MapB, MapC------
                        do{
                            
                            terminationFlag = 1;
                            entryConnectNumber = 0;
                            
                            //for (int counterA = 1; counterA < maxCount+1; counterA++){
                            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<intensityHistogramList [counterA*7+counterB];
                            //	cout<<" intensityHistogramList "<<counterA<<" "<<endl;
                            //}
                            
                            for (int counter2 = 1; counter2 < maxCount+1; counter2++){ //------Do until e.g. 240 entry become Zero------
                                if (intensityHistogramList [counter2*7+counter1] != 0){ //------Find Entry------
                                    entryConnectNumber = intensityHistogramList [counter2*7+counter1];
                                    break;
                                }
                            }
                            
                            // cout<<entryConnectNumber <<" entry-if 0 go next round"<<endl;
                            
                            if (entryConnectNumber == 0) terminationFlag = 0;
                            else{
                                
                                numberOfEntry = 0;
                                
                                for (int counter2 = 1; counter2 < maxCount+1; counter2++){
                                    if (intensityHistogramList [counter2*7+counter1] == entryConnectNumber) numberOfEntry++; //------EntryNumber related to the Connect group------
                                }
                                
                                // cout<<groupEntryCount<<" GroupNumber "<<numberOfEntry<<" EntryNumber"<<endl;
                                
                                if (numberOfEntry == 0 && existFindFlag == 0){
                                    groupList [entryConnectNumber] = groupEntryCount;
                                    groupRound [entryConnectNumber] = counter1;
                                    
                                    //cout<<entryConnectNumber<<" EntryConnNo"<<endl;
                                    
                                    groupEntryCount++; //------Only one entry, set group number------
                                }
                                else if (numberOfEntry > 0){
                                    collectCount = 0;
                                    errorNoHold = 56;
                                    int *collectConnect = new int [numberOfEntry+10]; //------All connect data overlapped with connect------
                                    
                                    for (int counter2 = 0; counter2 < numberOfEntry+10; counter2++) collectConnect [counter2] = 0;
                                    
                                    for (int counter2 = 1; counter2 < maxCount+1; counter2++){ //------All entry number Data Set into >> collectConnect []------
                                        if (intensityHistogramList [counter2*7+counter1] == entryConnectNumber){
                                            collectConnect [collectCount] = counter2; //------Save position on Histogram list, equivalent to connect no--------
                                            intensityHistogramList [counter2*7+counter1] = 0;
                                            collectCount++;
                                        }
                                    }
                                    
                                    do{ //------Do until all entry numbers are processed------
                                        
                                        terminationFlag1 = 1;
                                        existFindFlag = 0;
                                        errorNoHold = 57;
                                        int *groupListAttach = new int [maxCount+1];
                                        
                                        for (int counter2 = 0; counter2 < maxCount+1; counter2++) groupListAttach [counter2] = 0;
                                        
                                        tempGroupNumber = groupEntryCount; //------Hold group number for attached group------
                                        largestConnect = 0;
                                        largestConnectCount = 0; //------Largest Area connect number------
                                        
                                        // cout<<tempGroupNumber<<" tempGroupNo "<<endl;
                                        
                                        for (int counter2 = 0; counter2 < numberOfEntry; counter2++){ //------Largest connect group number------
                                            if (collectConnect [counter2] != 0){
                                                if (areaIntensityList [collectConnect [counter2]*2] > largestConnect){
                                                    largestConnect = areaIntensityList [collectConnect [counter2]*2];
                                                    largestConnectCount = collectConnect [counter2];
                                                }
                                            }
                                        }
                                        
                                        if (groupList [largestConnectCount] != 0) existFindFlag = 1; //------If already processed, set the flag------
                                        
                                        for (int counter2 = 0; counter2 < numberOfEntry; counter2++){ //------Remove the largest from collectConnect []------
                                            if (collectConnect [counter2] == largestConnectCount){
                                                collectConnect [counter2] = 0;
                                                break;
                                            }
                                        }
                                        
                                        if (largestConnectCount != 0 && existFindFlag == 0){
                                            groupList [largestConnectCount] = groupEntryCount; //------Set largest to grouplist []------
                                            groupRound [largestConnectCount] = counter1;
                                            groupEntryCount++;
                                        }
                                        
                                        //cout<<largestConnectCount<<" LargestCONNECTNO "<<endl;
                                        //for (int counterA = 0; counterA < numberOfEntry; counterA++) cout<<counterA<<" "<<collectConnect [counterA]<<" CollectConnect1"<<endl;
                                        
                                        if (largestConnectCount == 0) terminationFlag1 = 0;
                                        else{
                                            
                                            attachEntry = 0;
                                            errorNoHold = 58;
                                            int *attachSelect = new int [numberOfEntry*5+2];
                                            
                                            for (int counter2 = 0; counter2 < numberOfEntry*5+2; counter2++) attachSelect [counter2] = 0;
                                            
                                            for (int counter2 = 0; counter2 < attachedNumberListCount/5; counter2++){ //------Enter connect number attached with Largest Connect, remove from collectConnect []------
                                                if (attachedNumberList [counter2*5+1] == largestConnectCount){
                                                    for (int counter3 = 0; counter3 < numberOfEntry; counter3++){
                                                        if (collectConnect [counter3] == attachedNumberList [counter2*5]){
                                                            attachSelect [attachEntry] = attachedNumberList [counter2*5], attachEntry++;
                                                            attachSelect [attachEntry] = attachedNumberList [counter2*5+1], attachEntry++;
                                                            attachSelect [attachEntry] = attachedNumberList [counter2*5+2], attachEntry++;
                                                            attachSelect [attachEntry] = attachedNumberList [counter2*5+3], attachEntry++;
                                                            attachSelect [attachEntry] = attachedNumberList [counter2*5+4], attachEntry++;
                                                            collectConnect [counter3] = 0;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            //for (int counterA = 0; counterA < attachEntry/5; counterA++){
                                            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<attachSelect [counterA*5+counterB];
                                            //    cout<<" attachSelect "<<counterA<<" "<<endl;
                                            //}
                                            
                                            for (int counter2 = 0; counter2 < numberOfEntry; counter2++){
                                                if (attachSelect [counter2*5] != 0 && groupList [attachSelect [counter2*5]] != 0 && existFindFlag == 0){
                                                    attachSelect [counter2*5] = 0;
                                                    attachEntry = attachEntry-5;
                                                }
                                            }
                                            
                                            if (attachEntry != 0){
                                                if (existFindFlag == 1){
                                                    
                                                    //cout<<"EXIST FIANL"<<endl;
                                                    
                                                    for (int counter2 = 0; counter2 < numberOfEntry; counter2++){
                                                        if (attachSelect [counter2*5] != 0 && groupList [attachSelect [counter2*5]] != 0){
                                                            connectTotalTemp1 = attachSelect [counter2*5+3];
                                                            connectTotalTemp2 = attachSelect [counter2*5+4];
                                                            attachTemp = attachSelect [counter2*5+2];
                                                            
                                                            ratio1 = attachTemp/(double)connectTotalTemp1;
                                                            ratio2 = attachTemp/(double)connectTotalTemp2;
                                                            
                                                            if ((ratio1 > 0.2 && ratio1 < 0.6 && ratio2 > 0.2 && ratio2 < 0.6) || (ratio1 > 0.2 && ratio1 < 0.6 && ratio2 < 0.2) || (ratio1 < 0.2 && ratio2 > 0.2 && ratio2 < 0.6) || ratio1 >= 0.6 || ratio2 >= 0.6){
                                                                numberOfassociates = 0;
                                                                groupNoTemp = groupList [attachSelect [counter2*5]];
                                                                groupSource = groupList [largestConnectCount];
                                                                
                                                                if (groupNoTemp == groupSource || groupNoTemp == groupSource*-1) groupListAttach [attachSelect [counter2*5]] = groupList [attachSelect [counter2*5]];
                                                                else{
                                                                    
                                                                    for (int counter3 = 1; counter3 < maxCount+1; counter3++){
                                                                        if (groupList [counter3] == groupNoTemp || groupList [counter3] == groupNoTemp*-1) numberOfassociates++;
                                                                    }
                                                                    
                                                                    if (numberOfassociates < 3){
                                                                        for (int counter3 = 1; counter3 < maxCount+1; counter3++){
                                                                            if (groupList [counter3] == groupNoTemp || groupList [counter3] == groupNoTemp*-1){
                                                                                if (groupList [largestConnectCount] > 0) groupListAttach [counter3] = groupList [largestConnectCount]*-1;
                                                                                else groupListAttach [counter3] = groupList [largestConnectCount];
                                                                            }
                                                                        }
                                                                    }
                                                                    else groupListAttach [attachSelect [counter2*5]] = groupList [attachSelect [counter2*5]];
                                                                }
                                                            }
                                                            else groupListAttach [attachSelect [counter2*5]] = groupList [attachSelect [counter2*5]];
                                                        }
                                                        else if (attachSelect [counter2*5] != 0 && groupList [attachSelect [counter2*5]] == 0){
                                                            if (groupList [largestConnectCount] > 0) groupListAttach [attachSelect [counter2*5]] = groupList [largestConnectCount]*-1;
                                                            else groupListAttach [attachSelect [counter2*5]] = groupList [largestConnectCount];
                                                        }
                                                    }
                                                }
                                                else{
                                                    
                                                    //cout<<" NON EXIST FINAL"<<endl;
                                                    
                                                    if (processType == 1 || processType == 3){
                                                        for (int counter2 = 0; counter2 < numberOfEntry; counter2++){ //------Enter process result of attached connect with largest enter >> newGroups []------
                                                            if (attachSelect [counter2*5] != 0){
                                                                if (arrayCellTrackingPreviousAss [(largestConnectCount-1)*6+3] == arrayCellTrackingPreviousAss [(attachSelect [counter2*5]-1)*6+3] && arrayCellTrackingPreviousAss [(largestConnectCount-1)*6+3] != 0 && arrayCellTrackingPreviousAss [(attachSelect [counter2*5]-1)*6+3] != 0){
                                                                    if (arrayCellTrackingPreviousAss [(largestConnectCount-1)*6+4] > 5 || arrayCellTrackingPreviousAss [(attachSelect [counter2*5]-1)*6+4] > 5) groupListAttach [attachSelect [counter2*5]] = tempGroupNumber*-1;
                                                                    else groupListAttach [attachSelect [counter2*5]] = groupEntryCount, groupEntryCount++;
                                                                }
                                                                else groupListAttach [attachSelect [counter2*5]] = tempGroupNumber*-1;
                                                            }
                                                        }
                                                    }
                                                    else if (processType == 2){
                                                        for (int counter2 = 0; counter2 < numberOfEntry; counter2++){ //------Enter process result of attached connect with largest enter >> newGroups []------
                                                            if (attachSelect [counter2*5] != 0){
                                                                if (arrayCellTrackingCurrentAss [(largestConnectCount-1)*6+3] == arrayCellTrackingCurrentAss [(attachSelect [counter2*5]-1)*6+3] && arrayCellTrackingCurrentAss [(largestConnectCount-1)*6+3] != 0 && arrayCellTrackingCurrentAss [(attachSelect [counter2*5]-1)*6+3] != 0){
                                                                    if (arrayCellTrackingCurrentAss [(largestConnectCount-1)*6+4] > 5 || arrayCellTrackingCurrentAss [(attachSelect [counter2*5]-1)*6+4] > 5) groupListAttach [attachSelect [counter2*5]] = tempGroupNumber*-1;
                                                                    else groupListAttach [attachSelect [counter2*5]] = groupEntryCount, groupEntryCount++;
                                                                }
                                                                else groupListAttach [attachSelect [counter2*5]] = tempGroupNumber*-1;
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                //for (int counterA = 0; counterA < numberOfEntry; counterA++) cout<<counterA<<" "<<collectConnect [counterA]<<" collectConnect2"<<endl;
                                                //for (int counterA = 0; counterA < maxCount+1; counterA++) cout<<counterA<<" "<<groupListAttach [counterA]<<" groupAttList"<<endl;
                                                //for (int counterA = 1; counterA < maxCount+1; counterA++) cout<<counterA<<" "<<groupList [counterA]<<" GroupLisst1"<<endl;
                                                
                                                for (int counter2 = 1; counter2 < maxCount+1; counter2++){
                                                    if (groupListAttach [counter2] != 0){
                                                        groupList [counter2] = groupListAttach [counter2];
                                                        groupRound [counter2] = counter1;
                                                    }
                                                }
                                                
                                                //cout<<groupEntryCount<<" groupEntryCountFinal"<<endl;
                                            }
                                            
                                            delete [] attachSelect;
                                        }
                                        
                                        delete [] groupListAttach;
                                        
                                    } while (terminationFlag1 == 1);
                                    
                                    delete [] collectConnect;
                                }
                            }
                            
                            //for (int counterA = 1; counterA < maxCount+1; counterA++) cout<<counterA<<" "<<groupList [counterA]<<" GroupList_End_Connect"<<endl;
                            
                        } while (terminationFlag == 1);
                        
                        //for (int counterA = 1; counterA < maxCount+1; counterA++) cout<<" Round "<<counter1<<" "<<counterA<<" "<<groupList [counterA]<<" GroupList_End_Round"<<endl;
                    }
                    
                    //for (int counterA = 1; counterA < maxCount+1; counterA++) cout<<" "<<counterA<<" "<<groupList [counterA]<<" groupList"<<endl;
                    
                    delete [] attachedNumberList;
                    
                    int withinIntensityLargest = 0;
                    int withinIntensityCount = 0;
                    
                    for (int counter1 = 1; counter1 < maxCount+1; counter1++){
                        if (groupList [counter1] > 0){
                            withinIntensityLargest = 0;
                            withinIntensityCount = 0;
                            
                            //cout<<withinGroupNumber<<" "<<withinArea<<" "<<withinIntensity<<" Area_Int_within"<<endl;
                            
                            for (int counter2 = 1; counter2 < maxCount+1; counter2++){
                                if (groupList [counter2] == groupList [counter1]*-1){
                                    if (areaIntensityList [counter2*2] > areaIntensityList [counter1*2]*0.8 && areaIntensityList [counter2*2+1] > areaIntensityList [counter1*2+1] && areaIntensityList [counter2*2+1] < 220 && areaIntensityList [counter2*2+1]-areaIntensityList [counter1*2+1] > 30){
                                        if (withinIntensityLargest < areaIntensityList [counter2*2]){
                                            withinIntensityLargest = areaIntensityList [counter2*2];
                                            withinIntensityCount = counter2;
                                        }
                                        
                                        //cout<<withinIntensityLargest<<" "<<withinIntensityCount<<" Area_Int_within2"<<endl;
                                    }
                                }
                            }
                            
                            for (int counter2 = 1; counter2 < maxCount+1; counter2++){
                                if (groupList [counter2] == groupList [counter1] || groupList [counter2] == groupList [counter1]*-1) groupList2 [counter2] = groupList [counter2];
                            }
                            
                            if (withinIntensityLargest != 0){
                                groupList2 [counter1] = groupList2 [counter1]*-1;
                                groupList2 [withinIntensityCount] = groupList2 [withinIntensityCount]*-1;
                            }
                        }
                    }
                    
                    //for (int counterA = 1; counterA < maxCount+1; counterA++) cout<<" "<<counterA<<" "<<groupList2 [counterA]<<" groupList2"<<endl;
                    
                    if (processType == 1 || processType == 3){
                        if (groupInfoPreviousStatus == 0){
                            errorNoHold = 59;
                            arrayGroupInfoPrevious = new int [maxCount*10+50];
                            groupInfoPreviousCount = 0;
                            groupInfoPreviousStatus = 1;
                            groupInfoPreviousSizeHold = maxCount*10+50;
                        }
                        else if (groupInfoPreviousStatus == 1 && groupInfoPreviousSizeHold < maxCount*5){
                            delete [] arrayGroupInfoPrevious;
                            
                            errorNoHold = 60;
                            arrayGroupInfoPrevious = new int [maxCount*10+50];
                            groupInfoPreviousCount = 0;
                            groupInfoPreviousSizeHold = maxCount*10+50;
                        }
                        else groupInfoPreviousCount = 0;
                        
                        for (int counter1 = 1; counter1 < maxCount+1; counter1++){
                            arrayGroupInfoPrevious [groupInfoPreviousCount] = groupList2 [counter1], groupInfoPreviousCount++;
                            arrayGroupInfoPrevious [groupInfoPreviousCount] = groupRound [counter1], groupInfoPreviousCount++;
                            arrayGroupInfoPrevious [groupInfoPreviousCount] = groupLink [counter1], groupInfoPreviousCount++;
                            arrayGroupInfoPrevious [groupInfoPreviousCount] = 0, groupInfoPreviousCount++;
                            arrayGroupInfoPrevious [groupInfoPreviousCount] = 0, groupInfoPreviousCount++;
                        }
                        
                        //for (int counterA = 0; counterA < groupInfoPreviousCount/5; counterA++){
                        //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayGroupInfoPrevious [counterA*5+counterB];
                        //    cout<<" arrayGroupInfoPrevious "<<counterA<<" "<<endl;
                        //}
                    }
                    else if (processType == 2){
                        if (groupInfoCurrentStatus == 0){
                            errorNoHold = 61;
                            arrayGroupInfoCurrent = new int [maxCount*6+50];
                            groupInfoCurrentCount = 0;
                            groupInfoCurrentStatus = 1;
                            groupInfoCurrentSizeHold = maxCount*6+50;
                        }
                        else if (groupInfoCurrentStatus == 1 && groupInfoCurrentSizeHold < maxCount*3){
                            delete [] arrayGroupInfoCurrent;
                            
                            errorNoHold = 62;
                            arrayGroupInfoCurrent = new int [maxCount*6+50];
                            groupInfoCurrentCount = 0;
                            groupInfoCurrentSizeHold = maxCount*6+50;
                        }
                        else groupInfoCurrentCount = 0;
                        
                        for (int counter1 = 1; counter1 < maxCount+1; counter1++){
                            arrayGroupInfoCurrent [groupInfoCurrentCount] = groupList2 [counter1], groupInfoCurrentCount++;
                            arrayGroupInfoCurrent [groupInfoCurrentCount] = groupRound [counter1], groupInfoCurrentCount++;
                            arrayGroupInfoCurrent [groupInfoCurrentCount] = groupLink [counter1], groupInfoCurrentCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < groupInfoCurrentCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayGroupInfoCurrent [counterA*3+counterB];
                    //    cout<<" arrayGroupInfoCurrent "<<counterA<<" "<<endl;
                    //}
                    
                    delete [] groupLink;
                    delete [] intensityHistogramList;
                    delete [] intensityHistogramList2;
                    delete [] areaIntensityList;
                    delete [] groupList;
                    delete [] groupList2;
                    delete [] groupRound;
                    
                    connectDetect = 1;
                }
            }
            
            errorNoHold = 0;
            subCompletionFlag3 = 0;
        }
        catch (int errorCheckThrow){
            if (errorNoHold >= 1000 && errorNoHold < 2000){
                string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
                mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                time_t rawtime;
                struct tm * timeinfo;
                time (&rawtime);
                timeinfo = localtime ( &rawtime );
                
                int tsec = timeinfo -> tm_sec;
                int tmin = timeinfo -> tm_min;
                int thour = timeinfo -> tm_hour;
                int tday = timeinfo -> tm_mday;
                int tmon = timeinfo -> tm_mon;
                
                string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
                
                errorPath = errorPath+"/Cell_CarvingTableInterpretation01 "+dateTime;
                
                ofstream oin2;
                oin2.open(errorPath.c_str(), ios::out);
                oin2<<"TableInterpretation-interpretationFirst"<<endl;
                oin2<<errorNoHold<<endl;
                oin2<<analysisImageName<<endl;
                oin2<<analysisID<<endl;
                oin2<<treatmentNameHold<<endl;
                oin2<<cellLineageNoHold<<endl;
                oin2<<cellNoHold<<endl;
                oin2<<dateTime<<endl;
                oin2<<(xyPositionCenterPreviousCount/6-1)*6+4<<endl;
                oin2<<xyPositionCenterPreviousSizeHold<<endl;
                oin2<<(xyPositionCenterCurrentCount/6-1)*6+4<<endl;
                oin2<<xyPositionCenterCurrentCount<<endl;
                oin2<<xyPositionCenterCurrentSizeHold<<endl;
                oin2<<positionReviseCount<<endl;
                oin2<<associatedDataCount<<endl;
                oin2<<gravityCenterRevCount<<endl;
                oin2<<timeSelectedCount<<endl;
                oin2<<connectLineageRelCount<<endl;
                
                if (errorNoHold == 1000) oin2<<"Map pointer error"<<endl;
                else if (errorNoHold == 1001) oin2<<"Array size error"<<endl;
                else if (errorNoHold == 1002) oin2<<"Map pointer error"<<endl;
                else if (errorNoHold == 1003) oin2<<"Array size error"<<endl;
                oin2.close();
            }
            
            if (errorNoHold == 0) errorNoHold = 1000;
            
            subCompletionFlag3 = 0;
        }
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingTableInterpretation02 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"TableInterpretation-interpretationFirst"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
        
        subCompletionFlag3 = 0;
    }
    
    return connectDetect;
}

-(void)interpretationMain2{
    try{
        try{
            
            errorNoHold = 0;
            int errorCheckThrow = 0;
            subCompletionFlag3 = 1;
            
            //-------Target connect no get----------
            int targetNo = 0;
            int targetAverage = 0;
            
            for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                if (arrayCellTrackingTable [counter1*15] == roundStatus-1 && arrayCellTrackingTable [counter1*15+7] == 1){
                    targetAverage = arrayCellTrackingTable [counter1*15+6];
                    break;
                }
            }
            
            for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                if (arrayCellTrackingTable [counter1*15] == roundStatus && arrayCellTrackingTable [counter1*15+7] == 1){
                    targetNo = arrayCellTrackingTable [counter1*15+2];
                    break;
                }
            }
            
            //cout<<targetNo<<" "<<targetAverage<<" "<<roundStatus<<" Target "<<endl;
            
            //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
            //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
            //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
            //}
            
            // for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
            //     cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
            // }
            
            //for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrevious [counterA*6+counterB];
            //	cout<<" arrayCellTrackingPrevious "<<counterA<<endl;
            //}
            
            //-------Target connect No get----------
            int noOfPrevious = 0;
            int noOfNext = 0;
            int extensionData = 0;
            
            for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                if (arrayCellTrackingTable [counter1*15] == roundStatus-1 && arrayCellTrackingTable [counter1*15+7] == 1 && extensionData == 0){
                    if (arrayCellTrackingTable [counter1*15+10] != 0) noOfNext++;
                    if (arrayCellTrackingTable [counter1*15+11] != 0) noOfNext++;
                    extensionData = arrayCellTrackingTable [counter1*15+2];
                }
                else if (arrayCellTrackingTable [counter1*15] == roundStatus-1 && extensionData != 0 && extensionData == arrayCellTrackingTable [counter1*15+2]){
                    if (arrayCellTrackingTable [counter1*15+10] != 0) noOfNext++;
                    if (arrayCellTrackingTable [counter1*15+11] != 0) noOfNext++;
                }
            }
            
            if (noOfNext == 1){
                extensionData = 0;
                
                for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                    if (arrayCellTrackingTable [counter1*15] == roundStatus && arrayCellTrackingTable [counter1*15+7] == 1 && extensionData == 0){
                        if (arrayCellTrackingTable [counter1*15+12] != 0) noOfPrevious++;
                        if (arrayCellTrackingTable [counter1*15+13] != 0) noOfPrevious++;
                        extensionData = arrayCellTrackingTable [counter1*15+2];
                    }
                    else if (arrayCellTrackingTable [counter1*15] == roundStatus && extensionData != 0 && extensionData == arrayCellTrackingTable [counter1*15+2]){
                        if (arrayCellTrackingTable [counter1*15+12] != 0) noOfPrevious++;
                        if (arrayCellTrackingTable [counter1*15+13] != 0) noOfPrevious++;
                    }
                }
            }
            
            //cout<<noOfPrevious<<" "<<noOfNext<<" PrevNext"<<endl;
            
            double patternResult = 0;
            int findOrder = 0;
            int targetMitosisStatus1 = 0;
            int targetMitosisStatus2 = 0;
            int processType = 0;
            int targetConnect = 0;
            int secondaryCutOff = 0;
            
            if (mitosisValueHold+25 > 255) secondaryCutOff = 255;
            
            for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                if (arrayCellTrackingTable [counter1*15] == roundStatus-1 && arrayCellTrackingTable [counter1*15+3] != 0){
                    processType = 2;
                    targetConnect = arrayXYPositionCenterPrevious [findOrder*6+4];
                    
                    findOrder++;
                    
                    mitosisPattern = [[MitosisPattern alloc] init];
                    patternResult = [mitosisPattern mitosisPatternMain:targetConnect:processType];
                    
                    do{
                    } while (subCompletionFlag2 == 1);
                    
                    if (errorNoHold != 0){
                        errorNoHold = errorNoHold+2000;
                        throw errorCheckThrow;
                    }
                    
                    //cout<<patternResult<<" "<<cutOff4<<" "<<cutOff2<<"  "<<cutOff3<<" "<<arrayCellTrackingTable [counter1*15+6]<<" "<<arrayCellTrackingTable [counter1*15+7]<<" "<<roundStatus-1<<" "<<mitosisValueHold<<" "<<mitosisSDHold<<"  Mitosis1"<<endl;
                    
                    if (patternResult != 0 && patternResult < 0.15 && arrayCellTrackingTable [counter1*15+6] >= mitosisValueHold){
                        arrayCellTrackingTable [counter1*15+8] = 6; //========================Mitosis cut off
                    }
                    else if (patternResult != 0 && patternResult >= 0.15 && patternResult < mitosisSDHold && arrayCellTrackingTable [counter1*15+6] > cutOff4){ //========================Mitosis cut off
                        if (arrayCellTrackingTable [counter1*15+6] >= mitosisValueHold) arrayCellTrackingTable [counter1*15+8] = 6;
                        else if (arrayCellTrackingTable [counter1*15+6] < 150) arrayCellTrackingTable [counter1*15+8] = 2;
                        else arrayCellTrackingTable [counter1*15+8] = 1;
                    }
                    else if (patternResult != 0 && patternResult >= mitosisSDHold && patternResult < 0.5 && arrayCellTrackingTable [counter1*15+6] > cutOff4){ //========================mitosis cut off
                        if (arrayCellTrackingTable [counter1*15+6] >= secondaryCutOff) arrayCellTrackingTable [counter1*15+8] = 1;
                        else if (arrayCellTrackingTable [counter1*15+6] >= 150 && arrayCellTrackingTable [counter1*15+6] < 225) arrayCellTrackingTable [counter1*15+8] = 2;
                    }
                    else if (patternResult != 0 && patternResult >= 0.5 && patternResult < 0.75 && arrayCellTrackingTable [counter1*15+6] > cutOff3){ //========================Mitosis cut off
                        arrayCellTrackingTable [counter1*15+8] = 3;
                    }
                    else if (patternResult != 0 && patternResult >= 0.75 && arrayCellTrackingTable [counter1*15+6] > cutOff3){ //========================Mitosis cut off
                        arrayCellTrackingTable [counter1*15+8] = 4;
                    }
                    
                    if (arrayCellTrackingTable [counter1*15+7] == 1) targetMitosisStatus1 = arrayCellTrackingTable [counter1*15+8];
                }
                else if (arrayCellTrackingTable [counter1*15] == roundStatus && arrayCellTrackingTable [counter1*15+3] != 0){
                    processType = 1;
                    targetConnect = arrayCellTrackingTable [counter1*15+2];
                    
                    mitosisPattern = [[MitosisPattern alloc] init];
                    patternResult = [mitosisPattern mitosisPatternMain:targetConnect:processType];
                    
                    do{
                    } while (subCompletionFlag2 == 1);
                    
                    if (errorNoHold != 0){
                        errorNoHold = errorNoHold+2000;
                        throw errorCheckThrow;
                    }
                    
                    //cout<<patternResult<<" "<<cutOff4<<" "<<cutOff2<<"  "<<cutOff3<<" "<<arrayCellTrackingTable [counter1*15+6]<<" "<<arrayCellTrackingTable [counter1*15+7]<<" "<<roundStatus<<" "<<mitosisValueHold<<" Mitosis2"<<endl;
                    
                    if (patternResult != 0 && patternResult < 0.15 && arrayCellTrackingTable [counter1*15+6] >= mitosisValueHold){
                        arrayCellTrackingTable [counter1*15+8] = 6; //========================Mitosis cut off
                    }
                    else if (patternResult != 0 && patternResult >= 0.15 && patternResult < mitosisSDHold && arrayCellTrackingTable [counter1*15+6] > cutOff4){ //========================Mitosis cut off
                        if (arrayCellTrackingTable [counter1*15+6] >= mitosisValueHold) arrayCellTrackingTable [counter1*15+8] = 6;
                        else if (arrayCellTrackingTable [counter1*15+6] < 150) arrayCellTrackingTable [counter1*15+8] = 2;
                        else arrayCellTrackingTable [counter1*15+8] = 1;
                    }
                    else if (patternResult != 0 && patternResult >= mitosisSDHold && patternResult < 0.5 && arrayCellTrackingTable [counter1*15+6] > cutOff4){ //========================Mitosis cut off
                        if (arrayCellTrackingTable [counter1*15+6] >= secondaryCutOff) arrayCellTrackingTable [counter1*15+8] = 1;
                        else if (arrayCellTrackingTable [counter1*15+6] >= 150 && arrayCellTrackingTable [counter1*15+6] < 225) arrayCellTrackingTable [counter1*15+8] = 2;
                    }
                    else if (patternResult != 0 && patternResult >= 0.5 && patternResult < 0.75 && arrayCellTrackingTable [counter1*15+6] > cutOff3){ //========================Mitosis cut off
                        arrayCellTrackingTable [counter1*15+8] = 3;
                    }
                    else if (patternResult != 0 && patternResult >= 0.75 && arrayCellTrackingTable [counter1*15+6] > cutOff3){ //========================Mitosis cut off
                        arrayCellTrackingTable [counter1*15+8] = 4;
                    }
                    
                    if (arrayCellTrackingTable [counter1*15+7] == 1) targetMitosisStatus2 = arrayCellTrackingTable [counter1*15+8];
                }
            }
            
            string cellLineExtract = cellLineageNoHold.substr(1);
            string cellNoExtract = cellNoHold.substr(1);
            
            int mitosisCheck = 0;
            int mitosisCheck2 = 0;
            
            for (int counter1 = 0; counter1 < mitosisParameterCount/4; counter1++){
                if (arrayMitosisParameter [counter1*4+2] == imageNumberInt) mitosisCheck = 1;
                if (arrayMitosisParameter [counter1*4+2] == imageNumberInt+1) mitosisCheck2 = 1;
            }
            
            if (mitosisParameterCount+10 > mitosisParameterLimit){
                errorNoHold = 63;
                int *arrayUpDate = new int [mitosisParameterCount+10];
                
                for (int counter1 = 0; counter1 < mitosisParameterCount; counter1++) arrayUpDate [counter1] = arrayMitosisParameter [counter1];
                
                delete [] arrayMitosisParameter;
                errorNoHold = 64;
                arrayMitosisParameter = new int [mitosisParameterLimit+50];
                mitosisParameterLimit = mitosisParameterLimit+50;
                
                for (int counter1 = 0; counter1 < mitosisParameterCount; counter1++) arrayMitosisParameter [counter1] = arrayUpDate [counter1];
                delete [] arrayUpDate;
            }
            
            if (imageNumberInt-timeEventEntryHold <= 50 && (eventTypeEntryHold == 31 || eventTypeEntryHold == 41 || eventTypeEntryHold == 51)){
                targetMitosisStatus1 = 0;
            }
            
            if (imageNumberInt+1-timeEventEntryHold <= 50 && (eventTypeEntryHold == 31 || eventTypeEntryHold == 41 || eventTypeEntryHold == 51)){
                targetMitosisStatus2 = 0;
            }
            
            if (roundStatus == 2 && mitosisParameterCount != 0){
                int mitosisFindFlag = 0;
                
                for (int counter1 = 0; counter1 < mitosisParameterCount/4; counter1++){
                    if (arrayMitosisParameter [counter1*4+3] == 10 && mitosisFindFlag == 0){
                        arrayMitosisParameter [counter1*4+3] = 5;
                        mitosisFindFlag = 1;
                    }
                    else if (mitosisFindFlag == 1) arrayMitosisParameter [counter1*4+3] = 5;
                }
                
                if (mitosisFindFlag == 1){
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (arrayCellTrackingTable [counter1*15] == roundStatus-1 && arrayCellTrackingTable [counter1*15+7] == 1){
                            arrayCellTrackingTable [counter1*15+8] = 5;
                            break;
                        }
                    }
                }
            }
            
            if (mitosisCheck == 1){
                for (int counter1 = 0; counter1 < mitosisParameterCount/4; counter1++){
                    if (arrayMitosisParameter [counter1*4+2] == imageNumberInt && arrayMitosisParameter [counter1*4+3] != 5){
                        arrayMitosisParameter [counter1*4] = atoi(cellLineExtract.c_str());
                        arrayMitosisParameter [counter1*4+1] = atoi(cellNoExtract.c_str());
                        arrayMitosisParameter [counter1*4+2] = imageNumberInt;
                        arrayMitosisParameter [counter1*4+3] = targetMitosisStatus1;
                    }
                }
            }
            else if (mitosisCheck == 0){
                arrayMitosisParameter [mitosisParameterCount] = atoi(cellLineExtract.c_str()), mitosisParameterCount++;
                arrayMitosisParameter [mitosisParameterCount] = atoi(cellNoExtract.c_str()), mitosisParameterCount++;
                arrayMitosisParameter [mitosisParameterCount] = imageNumberInt, mitosisParameterCount++;
                arrayMitosisParameter [mitosisParameterCount] = targetMitosisStatus1, mitosisParameterCount++;
            }
            
            if (mitosisCheck2 == 1){
                for (int counter1 = 0; counter1 < mitosisParameterCount/4; counter1++){
                    if (arrayMitosisParameter [counter1*4+2] == imageNumberInt+1 && arrayMitosisParameter [counter1*4+3] != 5){
                        arrayMitosisParameter [counter1*4] = atoi(cellLineExtract.c_str());
                        arrayMitosisParameter [counter1*4+1] = atoi(cellNoExtract.c_str());
                        arrayMitosisParameter [counter1*4+2] = imageNumberInt+1;
                        arrayMitosisParameter [counter1*4+3] = targetMitosisStatus2;
                    }
                }
            }
            else if (mitosisCheck2 == 0){
                arrayMitosisParameter [mitosisParameterCount] = atoi(cellLineExtract.c_str()), mitosisParameterCount++;
                arrayMitosisParameter [mitosisParameterCount] = atoi(cellNoExtract.c_str()), mitosisParameterCount++;
                arrayMitosisParameter [mitosisParameterCount] = imageNumberInt+1, mitosisParameterCount++;
                arrayMitosisParameter [mitosisParameterCount] = targetMitosisStatus2, mitosisParameterCount++;
            }
            
            //for (int counterA = 0; counterA < mitosisParameterCount/4; counterA++){
            //     for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisParameter [counterA*4+counterB];
            //     cout<<" arrayMitosisParameter "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
            //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
            //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
            //    cout<<" arrayEventSequence "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                if (arrayEventSequence [counter1*4] == imageNumberInt && arrayEventSequence [counter1*4+1] == 6){
                    for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                        if (arrayCellTrackingTable [counter2*15] == roundStatus-1 && arrayCellTrackingTable [counter1*15+7] == 1){
                            arrayCellTrackingTable [counter1*15+8] = 5;
                            break;
                        }
                    }
                }
            }
            
            //--------Round No entry, previous----------
            if (timeEventEntryHold == imageNumberInt){ //------Time one, first time set-------
                for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                    if (arrayCellTrackingTable [counter1*15] == roundStatus-1){
                        for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                            if (arrayTimeSelected [counter2*10+8] == arrayCellTrackingTable [counter1*15+2]){
                                if (arrayTimeSelected [counter2*10] == 7) arrayCellTrackingTable [counter1*15+14] = 2000;
                                else if (arrayTimeSelected [counter2*10] == 1) arrayCellTrackingTable [counter1*15+14] = 1001;
                                else arrayCellTrackingTable [counter1*15+14] = 1;
                                
                                break;
                            }
                        }
                    }
                }
            }
            else{
                
                for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                    if (arrayCellTrackingTable [counter1*15] == roundStatus-1) arrayCellTrackingTable [counter1*15+14] = 0;
                }
                
                int connectNoTemp = 0;
                int roundCount = 0;
                int areaPrevious = 0;
                
                for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                    if (arrayCellTrackingTable [counter1*15] == roundStatus-2){
                        connectNoTemp = arrayCellTrackingTable [counter1*15+10];
                        roundCount = arrayCellTrackingTable [counter1*15+14];
                        
                        for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                            if (arrayCellTrackingTable [counter2*15] == roundStatus-1 && arrayCellTrackingTable [counter1*15+7] == 1 && arrayCellTrackingTable [counter2*15+7] == 1 && arrayCellTrackingTable [counter2*15+2] != connectNoTemp){
                                arrayCellTrackingTable [counter1*15+10] = arrayCellTrackingTable [counter2*15+2];
                                connectNoTemp = arrayCellTrackingTable [counter1*15+10];
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                            if (arrayCellTrackingTable [counter2*15] == roundStatus-1 && arrayCellTrackingTable [counter2*15+2] == connectNoTemp){
                                if (arrayCellTrackingTable [counter2*15+14] != 0 && arrayCellTrackingTable [counter1*15+7] == 0){
                                    if (arrayCellTrackingTable [counter2*15+14] < roundCount){
                                        if (roundCount == 2000) arrayCellTrackingTable [counter2*15+14] = 2000;
                                        else if (roundCount > 1000 && roundCount < 1010) arrayCellTrackingTable [counter2*15+14] = roundCount+1;
                                        else if (roundCount == 1010 && arrayCellTrackingTable [counter2*15+7] == 1) arrayCellTrackingTable [counter2*15+14] = 2000;
                                        else if (roundCount == 1010 && arrayCellTrackingTable [counter2*15+7] == 0) arrayCellTrackingTable [counter2*15+14] = roundCount+1;
                                        else arrayCellTrackingTable [counter2*15+14] = roundCount+1;
                                        
                                        arrayCellTrackingTable [counter2*15+12] = arrayCellTrackingTable [counter1*15+2];
                                        
                                        for (int counter3 = 0; counter3 < cellTrackingTableCount/15; counter3++){
                                            if (arrayCellTrackingTable [counter3*15] == roundStatus-2 && arrayCellTrackingTable [counter3*15+2] == arrayCellTrackingTable [counter2*15+12]){
                                                arrayCellTrackingTable [counter3*15+10] = 0;
                                                break;
                                            }
                                        }
                                    }
                                    else if (arrayCellTrackingTable [counter2*15+14] == roundCount-1){
                                        areaPrevious = 0;
                                        
                                        for (int counter3 = 0; counter3 < cellTrackingTableCount/15; counter3++){
                                            if (arrayCellTrackingTable [counter3*15] == roundStatus-2 && arrayCellTrackingTable [counter3*15+2] == arrayCellTrackingTable [counter2*15+12]){
                                                areaPrevious = arrayCellTrackingTable [counter3*15+5];
                                                break;
                                            }
                                        }
                                        
                                        if (arrayCellTrackingTable [counter1*15+5] > areaPrevious){
                                            if (roundCount == 2000) arrayCellTrackingTable [counter2*15+14] = 2000;
                                            else if (roundCount > 1000 && roundCount < 1010) arrayCellTrackingTable [counter2*15+14] = roundCount+1;
                                            else if (roundCount == 1010 && arrayCellTrackingTable [counter2*15+7] == 1) arrayCellTrackingTable [counter2*15+14] = 2000;
                                            else if (roundCount == 1010 && arrayCellTrackingTable [counter2*15+7] == 0) arrayCellTrackingTable [counter2*15+14] = roundCount+1;
                                            else arrayCellTrackingTable [counter2*15+14] = roundCount+1;
                                            
                                            arrayCellTrackingTable [counter2*15+12] = arrayCellTrackingTable [counter1*15+2];
                                            
                                            for (int counter3 = 0; counter3 < cellTrackingTableCount/15; counter3++){
                                                if (arrayCellTrackingTable [counter3*15] == roundStatus-2 && arrayCellTrackingTable [counter3*15+2] == arrayCellTrackingTable [counter2*15+12]){
                                                    arrayCellTrackingTable [counter3*15+10] = 0;
                                                    break;
                                                }
                                            }
                                        }
                                        else arrayCellTrackingTable [counter1*15+10] = 0;
                                    }
                                    else arrayCellTrackingTable [counter1*15+10] = 0;
                                }
                                else{
                                    
                                    if (roundCount == 2000) arrayCellTrackingTable [counter2*15+14] = 2000;
                                    else if (roundCount > 1000 && roundCount < 1010) arrayCellTrackingTable [counter2*15+14] = roundCount+1;
                                    else if (roundCount == 1010 && arrayCellTrackingTable [counter2*15+7] == 1) arrayCellTrackingTable [counter2*15+14] = 2000;
                                    else if (roundCount == 1010 && arrayCellTrackingTable [counter2*15+7] == 0) arrayCellTrackingTable [counter2*15+14] = roundCount+1;
                                    else arrayCellTrackingTable [counter2*15+14] = roundCount+1;
                                    
                                    arrayCellTrackingTable [counter2*15+12] = arrayCellTrackingTable [counter1*15+2];
                                }
                                
                                break;
                            }
                        }
                    }
                }
                
                for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                    if (arrayCellTrackingTable [counter1*15] == roundStatus-1 && arrayCellTrackingTable [counter1*15+14] == 0){
                        for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                            if (arrayTimeSelected [counter2*10+8] == arrayCellTrackingTable [counter1*15+2]){
                                if (arrayTimeSelected [counter2*10] == 7) arrayCellTrackingTable [counter1*15+14] = 2000;
                                else if (arrayTimeSelected [counter2*10] == 1) arrayCellTrackingTable [counter1*15+14] = 1001;
                                else arrayCellTrackingTable [counter1*15+14] = 1;
                                
                                break;
                            }
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
            //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
            //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
            //}
            
            //--------Round No entry, current----------
            //*******RoundStatus, Previous check, if multiple Previous are found, select largest cont No*********
            //*******Then remove numbers except largest one from RoundStatus and RoundStatus-1*******
            
            int connectNoTemp = 0;
            int connectNoCount = 0;
            int previousNoTempCount = 0;
            int largestPreviousNo = 0;
            int largestPreviousConnect = 0;
            int largestPreviousCount = 0;
            int largestPreviousArea = 0;
            int connectPrevious = 0;
            int entryCount = 0;
            int entryConnectNo = 0;
            
            for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                if (arrayCellTrackingTable [counter1*15] == roundStatus && connectNoTemp != arrayCellTrackingTable [counter1*15+2]){
                    connectNoTemp = arrayCellTrackingTable [counter1*15+2];
                    connectNoCount = 0;
                    
                    for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                        if (arrayCellTrackingTable [counter2*15] == roundStatus && arrayCellTrackingTable [counter2*15+2] == connectNoTemp){
                            if (arrayCellTrackingTable [counter2*15+12] != 0) connectNoCount++;
                            if (arrayCellTrackingTable [counter2*15+13] != 0) connectNoCount++;
                        }
                    }
                    
                    if (connectNoTemp == 0) arrayCellTrackingTable [counter1*15+14] = 1;
                    else{
                        
                        errorNoHold = 65;
                        int *prevNoTemp = new int [connectNoCount*2+1];
                        previousNoTempCount = 0;
                        
                        for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                            if (arrayCellTrackingTable [counter2*15] == roundStatus && arrayCellTrackingTable [counter2*15+2] == connectNoTemp){
                                if (arrayCellTrackingTable [counter2*15+12] != 0){
                                    prevNoTemp [previousNoTempCount] = arrayCellTrackingTable [counter2*15+12], previousNoTempCount++;
                                    prevNoTemp [previousNoTempCount] = 0, previousNoTempCount++;
                                }
                                if (arrayCellTrackingTable [counter2*15+13] != 0){
                                    prevNoTemp [previousNoTempCount] = arrayCellTrackingTable [counter2*15+13], previousNoTempCount++;
                                    prevNoTemp [previousNoTempCount] = 0, previousNoTempCount++;
                                }
                            }
                        }
                        
                        largestPreviousNo = 0;
                        largestPreviousConnect = 0;
                        largestPreviousCount = 0;
                        largestPreviousArea = 0;
                        
                        for (int counter2 = 0; counter2 < previousNoTempCount/2; counter2++){
                            connectPrevious = prevNoTemp [counter2*2];
                            entryCount = 0;
                            entryConnectNo = 0;
                            
                            for (int counter3 = 0; counter3 < cellTrackingTableCount/15; counter3++){
                                if (arrayCellTrackingTable [counter3*15] == roundStatus-1 && entryConnectNo == 0){
                                    entryConnectNo = arrayCellTrackingTable [counter3*15+2];
                                    entryCount++;
                                    
                                    if (entryCount == connectPrevious){
                                        if (largestPreviousNo < arrayCellTrackingTable [counter3*15+14]){
                                            largestPreviousNo = arrayCellTrackingTable [counter3*15+14];
                                            largestPreviousConnect = arrayCellTrackingTable [counter3*15+2];
                                            largestPreviousCount = connectPrevious;
                                            largestPreviousArea = arrayCellTrackingTable [counter3*15+5];
                                        }
                                        else if (largestPreviousNo == arrayCellTrackingTable [counter3*15+14]){
                                            if (largestPreviousArea < arrayCellTrackingTable [counter3*15+5]){
                                                largestPreviousNo = arrayCellTrackingTable [counter3*15+14];
                                                largestPreviousConnect = arrayCellTrackingTable [counter3*15+2];
                                                largestPreviousCount = connectPrevious;
                                                largestPreviousArea = arrayCellTrackingTable [counter3*15+5];
                                            }
                                        }
                                        
                                        prevNoTemp [counter2*2+1] = arrayCellTrackingTable [counter3*15+2];
                                        
                                        break;
                                    }
                                }
                                else if (arrayCellTrackingTable [counter3*15] == roundStatus-1 && arrayCellTrackingTable [counter3*15+2] != entryConnectNo){
                                    entryConnectNo = arrayCellTrackingTable [counter3*15+2];
                                    entryCount++;
                                    
                                    if (entryCount == connectPrevious){
                                        if (largestPreviousNo < arrayCellTrackingTable [counter3*15+14]){
                                            largestPreviousNo = arrayCellTrackingTable [counter3*15+14];
                                            largestPreviousConnect = arrayCellTrackingTable [counter3*15+2];
                                            largestPreviousCount = connectPrevious;
                                            largestPreviousArea = arrayCellTrackingTable [counter3*15+5];
                                        }
                                        else if (largestPreviousNo == arrayCellTrackingTable [counter3*15+14]){
                                            if (largestPreviousArea < arrayCellTrackingTable [counter3*15+5]){
                                                largestPreviousNo = arrayCellTrackingTable [counter3*15+14];
                                                largestPreviousConnect = arrayCellTrackingTable [counter3*15+2];
                                                largestPreviousCount = connectPrevious;
                                                largestPreviousArea = arrayCellTrackingTable [counter3*15+5];
                                            }
                                        }
                                        
                                        prevNoTemp [counter2*2+1] = arrayCellTrackingTable [counter3*15+2];
                                        
                                        break;
                                    }
                                }
                            }
                        }
                        
                        //cout<<largestPreviousNo<<" "<<largestPreviousConnect<<" "<<largestPreviousCount<<"  "<<largestPreviousArea<< "  Number"<<endl;
                        
                        if (largestPreviousNo == 2000) arrayCellTrackingTable [counter1*15+14] = 2000;
                        else if (largestPreviousNo > 1000 && largestPreviousNo < 1010) arrayCellTrackingTable [counter1*15+14] = largestPreviousNo+1;
                        else if (largestPreviousNo == 1010 && arrayCellTrackingTable [counter1*15+7] == 1) arrayCellTrackingTable [counter1*15+14] = 2000;
                        else if (largestPreviousNo == 1010 && arrayCellTrackingTable [counter1*15+7] == 0) arrayCellTrackingTable [counter1*15+14] = largestPreviousNo+1;
                        else arrayCellTrackingTable [counter1*15+14] = largestPreviousNo+1;
                        
                        //-------Non target, keep one connect, remove others, remove next: change prev connect to actual connect no------
                        for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                            if (arrayCellTrackingTable [counter2*15] == roundStatus-1 && arrayCellTrackingTable [counter2*15+7] != 1){
                                for (int counter3 = 0; counter3 < previousNoTempCount/2; counter3++){
                                    if (arrayCellTrackingTable [counter2*15] == roundStatus-1 && prevNoTemp [counter3*2+1] == arrayCellTrackingTable [counter2*15+10] && largestPreviousConnect != prevNoTemp [counter3*2+1] && connectNoTemp == arrayCellTrackingTable [counter2*15+10]){
                                        arrayCellTrackingTable [counter2*15+10] = 0;
                                    }
                                    
                                    if (arrayCellTrackingTable [counter2*15] == roundStatus-1 && prevNoTemp [counter3*2+1] == arrayCellTrackingTable [counter2*15+11] && largestPreviousConnect != prevNoTemp [counter3*2+1] && connectNoTemp == arrayCellTrackingTable [counter2*15+10]){
                                        arrayCellTrackingTable [counter2*15+10] = 0;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < cellTrackingTableCount/15; counter3++){
                                    if (arrayCellTrackingTable [counter3*15] == roundStatus){
                                        if (arrayCellTrackingTable [counter2*15+2] == connectNoTemp){
                                            if (arrayCellTrackingTable [counter2*15+10] != largestPreviousCount) arrayCellTrackingTable [counter2*15+10] = 0;
                                            if (arrayCellTrackingTable [counter2*15+11] != largestPreviousCount) arrayCellTrackingTable [counter2*15+11] = 0;
                                        }
                                    }
                                }
                            }
                        }
                        
                        delete [] prevNoTemp;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
            //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
            //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
            //}
            
            connectNoTemp = 0;
            int targetConnectNo = 0;
            
            for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                if (arrayCellTrackingTable [counter1*15] == roundStatus-1 && connectNoTemp != arrayCellTrackingTable [counter1*15+2]){
                    connectNoTemp = arrayCellTrackingTable [counter1*15+2];
                    connectNoCount = 0;
                    
                    for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                        if (arrayCellTrackingTable [counter2*15] == roundStatus-1 && arrayCellTrackingTable [counter2*15+2] == connectNoTemp){
                            if (arrayCellTrackingTable [counter2*15+10] != 0) connectNoCount++;
                            if (arrayCellTrackingTable [counter2*15+11] != 0) connectNoCount++;
                        }
                    }
                    
                    if (connectNoCount > 1 && arrayCellTrackingTable [counter1*15+7] != 1){
                        targetConnectNo = 0;
                        
                        for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                            if (arrayCellTrackingTable [counter2*15] == roundStatus && arrayCellTrackingTable [counter2*15+7] == 1){
                                targetConnectNo = arrayCellTrackingTable [counter2*15+2];
                                
                                break;
                            }
                        }
                        
                        if (targetConnectNo != 0){
                            for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                                if (arrayCellTrackingTable [counter2*15] == roundStatus-1 && arrayCellTrackingTable [counter2*15+10] != 0 && arrayCellTrackingTable [counter2*15+10] != targetConnectNo && arrayCellTrackingTable [counter2*15+2] == connectNoTemp){
                                    arrayCellTrackingTable [counter2*15+10] = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellTrackingTableCount/15; counter3++){
                                        if (arrayCellTrackingTable [counter3*15] == roundStatus && arrayCellTrackingTable [counter3*15+2] == arrayCellTrackingTable [counter2*15+10]){
                                            arrayCellTrackingTable [counter3*15+12] = 0;
                                            arrayCellTrackingTable [counter3*15+13] = 0;
                                            arrayCellTrackingTable [counter3*15+14] = 1;
                                        }
                                    }
                                }
                                
                                if (arrayCellTrackingTable [counter2*15] == roundStatus-1 && arrayCellTrackingTable [counter2*15+11] != 0 && arrayCellTrackingTable [counter2*15+11] != targetConnectNo && arrayCellTrackingTable [counter2*15+2] == connectNoTemp){
                                    arrayCellTrackingTable [counter2*15+11] = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellTrackingTableCount/15; counter3++){
                                        if (arrayCellTrackingTable [counter3*15] == roundStatus && arrayCellTrackingTable [counter3*15+2] == arrayCellTrackingTable [counter2*15+11]){
                                            arrayCellTrackingTable [counter3*15+12] = 0;
                                            arrayCellTrackingTable [counter3*15+13] = 0;
                                            arrayCellTrackingTable [counter3*15+14] = 1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
            //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
            //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
            //}
            
            //-------If 10, 11: e.g. 0, 8, change to 8, 0---------
            errorNoHold = 66;
            int *nextShift = new int [cellTrackingTableCount*2+10];
            errorNoHold = 67;
            int *previousShift = new int [cellTrackingTableCount*2+10];
            
            int nextShiftCount = 0;
            int previousShiftCount = 0;
            int entryNextCount = 0;
            int entryPreviousCount = 0;
            
            for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                if (arrayCellTrackingTable [counter1*15] == roundStatus-1 && connectNoTemp != arrayCellTrackingTable [counter1*15+2]){
                    if (arrayCellTrackingTable [counter1*15+7] != 1){
                        connectNoTemp = arrayCellTrackingTable [counter1*15+2];
                        
                        for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                            nextShift [counter2] = 0;
                            previousShift [counter2] = 0;
                        }
                        
                        nextShiftCount = 0;
                        previousShiftCount = 0;
                        
                        for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                            if (arrayCellTrackingTable [counter2*15] == roundStatus-1 && arrayCellTrackingTable [counter2*15+2] == connectNoTemp){
                                if (arrayCellTrackingTable [counter2*15+10] != 0){
                                    nextShift [nextShiftCount] = arrayCellTrackingTable [counter2*15+10], nextShiftCount++;
                                    arrayCellTrackingTable [counter2*15+10] = 0;
                                }
                                if (arrayCellTrackingTable [counter2*15+11] != 0){
                                    nextShift [nextShiftCount] = arrayCellTrackingTable [counter2*15+11], nextShiftCount++;
                                    arrayCellTrackingTable [counter2*15+11] = 0;
                                }
                                if (arrayCellTrackingTable [counter2*15+12] != 0){
                                    previousShift [previousShiftCount] = arrayCellTrackingTable [counter2*15+12], previousShiftCount++;
                                    arrayCellTrackingTable [counter2*15+12] = 0;
                                }
                                if (arrayCellTrackingTable [counter2*15+13] != 0){
                                    previousShift [previousShiftCount] = arrayCellTrackingTable [counter2*15+13], previousShiftCount++;
                                    arrayCellTrackingTable [counter2*15+13] = 0;
                                }
                            }
                        }
                        
                        entryNextCount = 0;
                        entryPreviousCount = 0;
                        
                        for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                            if (arrayCellTrackingTable [counter2*15] == roundStatus-1 && arrayCellTrackingTable [counter2*15+2] == connectNoTemp){
                                if (nextShift [entryNextCount] != 0) arrayCellTrackingTable [counter2*15+10] = nextShift [entryNextCount];
                                entryNextCount++;
                                
                                if (nextShift [entryNextCount] != 0) arrayCellTrackingTable [counter2*15+11] = nextShift [entryNextCount];
                                entryNextCount++;
                            }
                            
                            if (arrayCellTrackingTable [counter2*15] == roundStatus-1 && arrayCellTrackingTable [counter2*15+2] == connectNoTemp){
                                if (previousShift [entryPreviousCount] != 0) arrayCellTrackingTable [counter2*15+12] = previousShift [entryPreviousCount];
                                entryPreviousCount++;
                                
                                if (previousShift [entryPreviousCount] != 0) arrayCellTrackingTable [counter2*15+13] = previousShift [entryPreviousCount];
                                entryPreviousCount++;
                            }
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
            //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
            //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                if (arrayCellTrackingTable [counter1*15] == roundStatus && connectNoTemp != arrayCellTrackingTable [counter1*15+2]){
                    if (arrayCellTrackingTable [counter1*15+7] != 1){
                        connectNoTemp = arrayCellTrackingTable [counter1*15+2];
                        
                        for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++) previousShift [counter2] = 0;
                        
                        previousShiftCount = 0;
                        
                        for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                            if (arrayCellTrackingTable [counter2*15] == roundStatus && arrayCellTrackingTable [counter2*15+2] == connectNoTemp){
                                if (arrayCellTrackingTable [counter2*15+12] != 0){
                                    previousShift [previousShiftCount] = arrayCellTrackingTable [counter2*15+12], previousShiftCount++;
                                    arrayCellTrackingTable [counter2*15+12] = 0;
                                }
                                
                                if (arrayCellTrackingTable [counter2*15+13] != 0){
                                    previousShift [previousShiftCount] = arrayCellTrackingTable [counter2*15+13], previousShiftCount++;
                                    arrayCellTrackingTable [counter2*15+13] = 0;
                                }
                            }
                        }
                        
                        entryPreviousCount = 0;
                        
                        for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                            if (arrayCellTrackingTable [counter2*15] == roundStatus && arrayCellTrackingTable [counter2*15+2] == connectNoTemp){
                                if (previousShift [entryPreviousCount] != 0) arrayCellTrackingTable [counter2*15+12] = previousShift [entryPreviousCount];
                                entryPreviousCount++;
                                
                                if (previousShift [entryPreviousCount] != 0) arrayCellTrackingTable [counter2*15+13] = previousShift [entryPreviousCount];
                                entryPreviousCount++;
                            }
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
            //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
            //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
            //}
            
            delete [] nextShift;
            delete [] previousShift;
            
            for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                if (arrayCellTrackingTable [counter1*15] == roundStatus && arrayCellTrackingTable [counter1*15+14] == 0){
                    for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                        if (arrayTimeSelected [counter2*10+8] == arrayCellTrackingTable [counter1*15+2]){
                            if (arrayTimeSelected [counter2*10] == 7) arrayCellTrackingTable [counter1*15+14] = 2000;
                            else if (arrayTimeSelected [counter2*10] == 1) arrayCellTrackingTable [counter1*15+14] = 1001;
                            else arrayCellTrackingTable [counter1*15+14] = 1;
                            
                            break;
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
            //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
            //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
            //}
            
            //-------Remove if second, third... Next and Previous = 0---------
            errorNoHold = 68;
            
            int *arrayCellTrackingTableTemp = new int [cellTrackingTableCount+50];
            int cellTrackingTableTempCount = 0;
            
            for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                if ((arrayCellTrackingTable [counter1*15+3] != 0 && arrayCellTrackingTable [counter1*15+4] != 0) || (arrayCellTrackingTable [counter1*15+3] == 0 && arrayCellTrackingTable [counter1*15+4] == 0 && (arrayCellTrackingTable [counter1*15+10] != 0 || arrayCellTrackingTable [counter1*15+11] != 0 || arrayCellTrackingTable [counter1*15+12] != 0 || arrayCellTrackingTable [counter1*15+13] != 0))){
                    arrayCellTrackingTableTemp [cellTrackingTableTempCount] = arrayCellTrackingTable [counter1*15], cellTrackingTableTempCount++; //------Round number------
                    arrayCellTrackingTableTemp [cellTrackingTableTempCount] = arrayCellTrackingTable [counter1*15+1], cellTrackingTableTempCount++; //------Image number------
                    arrayCellTrackingTableTemp [cellTrackingTableTempCount] = arrayCellTrackingTable [counter1*15+2], cellTrackingTableTempCount++; //------Connect number------
                    arrayCellTrackingTableTemp [cellTrackingTableTempCount] = arrayCellTrackingTable [counter1*15+3], cellTrackingTableTempCount++; //------X position------
                    arrayCellTrackingTableTemp [cellTrackingTableTempCount] = arrayCellTrackingTable [counter1*15+4], cellTrackingTableTempCount++; //------Y position------
                    arrayCellTrackingTableTemp [cellTrackingTableTempCount] = arrayCellTrackingTable [counter1*15+5], cellTrackingTableTempCount++; //------Area------
                    arrayCellTrackingTableTemp [cellTrackingTableTempCount] = arrayCellTrackingTable [counter1*15+6], cellTrackingTableTempCount++; //------Intensity------
                    arrayCellTrackingTableTemp [cellTrackingTableTempCount] = arrayCellTrackingTable [counter1*15+7], cellTrackingTableTempCount++; //------Target------
                    arrayCellTrackingTableTemp [cellTrackingTableTempCount] = arrayCellTrackingTable [counter1*15+8], cellTrackingTableTempCount++; //------Mitosis status------
                    arrayCellTrackingTableTemp [cellTrackingTableTempCount] = arrayCellTrackingTable [counter1*15+9], cellTrackingTableTempCount++; //------Divide/Fuse/Check------
                    arrayCellTrackingTableTemp [cellTrackingTableTempCount] = arrayCellTrackingTable [counter1*15+10], cellTrackingTableTempCount++; //------Next1------
                    arrayCellTrackingTableTemp [cellTrackingTableTempCount] = arrayCellTrackingTable [counter1*15+11], cellTrackingTableTempCount++; //------Next2------
                    arrayCellTrackingTableTemp [cellTrackingTableTempCount] = arrayCellTrackingTable [counter1*15+12], cellTrackingTableTempCount++; //------Previous1------
                    arrayCellTrackingTableTemp [cellTrackingTableTempCount] = arrayCellTrackingTable [counter1*15+13], cellTrackingTableTempCount++; //------Previous2------
                    arrayCellTrackingTableTemp [cellTrackingTableTempCount] = arrayCellTrackingTable [counter1*15+14], cellTrackingTableTempCount++; //------Done------
                }
            }
            
            cellTrackingTableCount = 0;
            
            for (int counter1 = 0; counter1 < cellTrackingTableTempCount; counter1++) arrayCellTrackingTable [cellTrackingTableCount] = arrayCellTrackingTableTemp [counter1], cellTrackingTableCount++;
            
            delete [] arrayCellTrackingTableTemp;
            
            //-------Mitosis cell death status get----------
            int roundStatusHold = 1;
            errorNoHold = 69;
            int *mitosisCellDeathStatus = new int [mitosisParameterCount+2];
            
            for (int counter1 = 0; counter1 < mitosisParameterCount+2; counter1++) mitosisCellDeathStatus [counter1] = 0;
            
            for (int counter1 = 0; counter1 < mitosisParameterCount/4; counter1++){
                mitosisCellDeathStatus [roundStatusHold] = arrayMitosisParameter [counter1*4+3], roundStatusHold++;
            }
            
            int mitosisCount = 0;
            int cellDeathCount = 0;
            
            for (int counter1 = 1; counter1 < mitosisParameterCount/4; counter1++){
                if (mitosisCount != 1000 && (mitosisCellDeathStatus [counter1] == 1 || mitosisCellDeathStatus [counter1] == 2 ||  mitosisCellDeathStatus [counter1] == 6)) mitosisCount++;
                else if (mitosisCellDeathStatus [counter1] == 5) mitosisCount = 1000;
                else if (mitosisCellDeathStatus [counter1] == 3 || mitosisCellDeathStatus [counter1] == 4) cellDeathCount++;
            }
            
            //for (int counter1 = 1; counter1 <= roundStatus; counter1++){
            //    cout<<counter1<<" "<<mitosisCellDeathStatus [counter1]<<" Status"<<endl;
            //}
            
            //cout<<mitosisCount<<" "<<cellDeathCount<<" "<<noOfPrevious<<" "<<noOfNext<<" "<<targetNo<<" mitDeth"<<endl;
            
            //********Division check**********
            if ((noOfPrevious == 1 || noOfPrevious == 0) && noOfNext > 1 && targetNo != 0){
                if (mitosisCount == 1000){
                    int nextNumberRecheck = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (roundStatus == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+7] == 1){
                            if (arrayCellTrackingTable [counter1*15+6] < targetAverage-50){
                                arrayCellTrackingTable [counter1*15+7] = 2;
                                nextNumberRecheck++;
                            }
                        }
                    }
                    
                    //---------If the number of next is 0 or 1, check status----------
                    if (noOfNext-nextNumberRecheck == 1){
                        int firstDivisionFlag = 0;
                        
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (roundStatus == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+7] == 1 && firstDivisionFlag == 0){
                                arrayCellTrackingTable [counter1*15+7] = 1;
                                arrayCellTrackingTable [counter1*15+9] = 1006;
                                trackHoldFlag = 1006;
                                firstDivisionFlag = 1;
                            }
                            else if (roundStatus == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+7] == 1 && firstDivisionFlag == 1){
                                arrayCellTrackingTable [counter1*15+7] = 0;
                            }
                            
                            if (roundStatus == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+7] == 2) arrayCellTrackingTable [counter1*15+7] = 0;
                        }
                    }
                    else if (noOfNext-nextNumberRecheck == 0){
                        int largestArea = 0;
                        int largestCount = 0;
                        
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (roundStatus == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+7] == 2){
                                if (arrayCellTrackingTable [counter1*15+5] > largestArea){
                                    largestArea = arrayCellTrackingTable [counter1*15+5];
                                    largestCount = counter1;
                                }
                                
                                arrayCellTrackingTable [counter1*15+7] = 1;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (roundStatus == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+7] == 1){
                                if (counter1 != largestCount) arrayCellTrackingTable [counter1*15+7] = 0;
                            }
                        }
                    }
                    else{ //------Set DV--------
                        
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (roundStatus == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+7] == 1){
                                if (noOfNext-nextNumberRecheck >= 5){
                                    arrayCellTrackingTable [counter1*15+9] = 5;
                                    trackHoldFlag = 5;
                                }
                                else{
                                    
                                    arrayCellTrackingTable [counter1*15+9] = noOfNext-nextNumberRecheck;
                                    trackHoldFlag = noOfNext-nextNumberRecheck;
                                }
                                
                                if (roundStatus == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+7] == 2) arrayCellTrackingTable [counter1*15+7] = 0;
                            }
                        }
                    }
                }
                else if (mitosisCount != 1000){
                    int extensionData2 = 0;
                    int noOfNext2 = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (arrayCellTrackingTable [counter1*15] == roundStatus-1 && arrayCellTrackingTable [counter1*15+7] == 1 && extensionData2 == 0){
                            if (arrayCellTrackingTable [counter1*15+10] != 0) noOfNext2++;
                            if (arrayCellTrackingTable [counter1*15+11] != 0) noOfNext2++;
                            extensionData2 = arrayCellTrackingTable [counter1*15+2];
                        }
                        else if (arrayCellTrackingTable [counter1*15] == roundStatus-1 && extensionData2 != 0 && extensionData2 == arrayCellTrackingTable [counter1*15+2]){
                            if (arrayCellTrackingTable [counter1*15+10] != 0) noOfNext2++;
                            if (arrayCellTrackingTable [counter1*15+11] != 0) noOfNext2++;
                        }
                    }
                    
                    int previousTargetNo = 0;
                    
                    errorNoHold = 70;
                    int *nextConnect = new int [noOfNext2*4+5];
                    int nextConnectCount = 0;
                    errorNoHold = 71;
                    int *nextOverlap = new int [noOfNext2+5];
                    int previousInt = 0;
                    
                    for (int counter1 = 0; counter1 < noOfNext2+5; counter1++) nextOverlap [counter1] = 0;
                    
                    //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
                    //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
                    //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (roundStatus == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+7] == 1){
                            nextConnect [nextConnectCount] = arrayCellTrackingTable [counter1*15+2], nextConnectCount++;
                            nextConnect [nextConnectCount] = arrayCellTrackingTable [counter1*15+5], nextConnectCount++;
                            nextConnect [nextConnectCount] = arrayCellTrackingTable [counter1*15+6], nextConnectCount++;
                            nextConnect [nextConnectCount] = 0, nextConnectCount++;
                        }
                        
                        if (roundStatus-1 == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+7] == 1){
                            previousTargetNo = arrayCellTrackingTable [counter1*15+2];
                            previousInt = arrayCellTrackingTable [counter1*15+6];
                        }
                    }
                    
                    for (int counterY = 0; counterY < trackAreaSize; counterY++){
                        for (int counterX = 0; counterX < trackAreaSize; counterX++){
                            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] == previousTargetNo && arrayCellTrackingCurrentMap [counterY][counterX] != 0){
                                for (int counter1 = 0; counter1 < nextConnectCount/4; counter1++){
                                    if (nextConnect [counter1*4] == arrayCellTrackingCurrentMap [counterY][counterX]){
                                        nextOverlap [counter1]++;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    
                    int mainOverlap = 0;
                    int mainOverlapCount = 0;
                    
                    for (int counter1 = 0; counter1 < nextConnectCount/4; counter1++){
                        if (nextOverlap [counter1] > mainOverlap){
                            mainOverlap = nextOverlap [counter1];
                            mainOverlapCount = counter1;
                        }
                    }
                    
                    nextOverlap [mainOverlapCount] = 0;
                    
                    for (int counter1 = 0; counter1 < nextConnectCount/4; counter1++){
                        if (nextOverlap [counter1] != 0 && nextOverlap [counter1]/(double)mainOverlap < 0.5) nextOverlap [counter1] = 0;
                    }
                    
                    int fusionCountNumber = 0;
                    int cutOffRangeLow = 0;
                    int cutOffRangeHigh = 0;
                    
                    if (previousInt > 150 && previousInt < 200){
                        cutOffRangeLow = previousInt-40;
                        cutOffRangeHigh = 220;
                    }
                    else if (previousInt <= 150){
                        cutOffRangeLow = 50;
                        cutOffRangeHigh = 200;
                    }
                    else if (previousInt >= 200){
                        cutOffRangeLow = previousInt-40;
                        cutOffRangeHigh = 250;
                    }
                    
                    for (int counter1 = 0; counter1 < nextConnectCount/4; counter1++){
                        if (nextConnect [counter1*4+2] < cutOffRangeHigh && nextConnect [counter1*4+2] > cutOffRangeLow){
                            if (mainOverlapCount == counter1){
                                nextConnect [counter1*4+3] = 1;
                                fusionCountNumber++;
                            }
                            else if (nextOverlap [counter1] != 0) nextConnect [counter1*4+3] = 1, fusionCountNumber++;
                        }
                    }
                    
                    //for (int counter1 = 0; counter1 < nextConnectCount/4; counter1++){
                    //    cout<<nextConnect [counter1*4]<<" "<<nextConnect [counter1*4+1]<<" "<<nextConnect [counter1*4+2]<<" "<<nextConnect [counter1*4+3]<<" Next"<<endl;
                    //}
                    
                    if (fusionCountNumber == 0){ //--------For check--------
                        int firstDivisionFlag = 0;
                        
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (roundStatus == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+7] == 1 && firstDivisionFlag == 0){
                                arrayCellTrackingTable [counter1*15+9] = 1007;
                                trackHoldFlag = 1007;
                                firstDivisionFlag = 1;
                            }
                            else if (roundStatus == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+7] == 1 && firstDivisionFlag == 0){
                                arrayCellTrackingTable [counter1*15+7] = 0;
                            }
                        }
                    }
                    else if (fusionCountNumber == 1){ //--------Select Connect and continue--------
                        int connectNoRemain = 0;
                        
                        for (int counter1 = 0; counter1 < nextConnectCount/4; counter1++){
                            if (nextConnect [counter1*4+3] == 1){
                                connectNoRemain = nextConnect [counter1*4];
                                break;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (roundStatus-1 == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+10] != connectNoRemain && arrayCellTrackingTable [counter1*15+10] != 0){
                                arrayCellTrackingTable [counter1*15+10] = 0;
                            }
                            
                            if (roundStatus-1 == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+11] != connectNoRemain && arrayCellTrackingTable [counter1*15+11] != 0){
                                arrayCellTrackingTable [counter1*15+11] = 0;
                            }
                            
                            if (roundStatus == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+2] != connectNoRemain && arrayCellTrackingTable [counter1*15+7] == 1){
                                arrayCellTrackingTable [counter1*15+7] = 0;
                            }
                        }
                    }
                    else{
                        
                        int firstDivisionFlag = 0;
                        
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (roundStatus == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+7] == 1 && firstDivisionFlag == 0){
                                arrayCellTrackingTable [counter1*15+9] = 1012;
                                trackHoldFlag = 1012;
                                firstDivisionFlag = 1;
                            }
                            else if (roundStatus == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+7] == 1 && firstDivisionFlag == 0){
                                arrayCellTrackingTable [counter1*15+7] = 0;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < nextConnectCount/4; counter1++){
                            if (nextConnect [counter1*4+3] == 1){
                                arrayPartnerInfo [partnerInfoCount] = nextConnect [counter1*4], partnerInfoCount++;
                            }
                        }
                    }
                    
                    delete [] nextConnect;
                    delete [] nextOverlap;
                }
            }
            
            //**********Cell Fusion CONT**********
            if (noOfPrevious > 1 && targetNo != 0){
                errorNoHold = 72;
                int *previousList = new int [(noOfPrevious+1)*6+5]; //------1. last encounter connect no, 2. Round no, 3. Done no, 4. first encounter Connect No, 5. first done No, 6. first encounter position-------
                int previousListCount = 0;
                
                int extensionTemp = 0;
                
                for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                    if (roundStatus == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+7] == 1 && extensionTemp == 0){
                        if (arrayCellTrackingTable [counter1*15+12] != 0){
                            previousList [previousListCount] = arrayCellTrackingTable [counter1*15+12], previousListCount++;
                            previousList [previousListCount] = 0, previousListCount++;
                            previousList [previousListCount] = 0, previousListCount++;
                            previousList [previousListCount] = 0, previousListCount++;
                            previousList [previousListCount] = 0, previousListCount++;
                            previousList [previousListCount] = arrayCellTrackingTable [counter1*15+12], previousListCount++;
                        }
                        if (arrayCellTrackingTable [counter1*15+13] != 0){
                            previousList [previousListCount] = arrayCellTrackingTable [counter1*15+13], previousListCount++;
                            previousList [previousListCount] = 0, previousListCount++;
                            previousList [previousListCount] = 0, previousListCount++;
                            previousList [previousListCount] = 0, previousListCount++;
                            previousList [previousListCount] = 0, previousListCount++;
                            previousList [previousListCount] = arrayCellTrackingTable [counter1*15+13], previousListCount++;
                        }
                        
                        extensionTemp = arrayCellTrackingTable [counter1*15+2];
                    }
                    else if (roundStatus == arrayCellTrackingTable [counter1*15] && extensionTemp != 0 && extensionTemp == arrayCellTrackingTable [counter1*15+2]){
                        if (arrayCellTrackingTable [counter1*15+12] != 0){
                            previousList [previousListCount] = arrayCellTrackingTable [counter1*15+12], previousListCount++;
                            previousList [previousListCount] = 0, previousListCount++;
                            previousList [previousListCount] = 0, previousListCount++;
                            previousList [previousListCount] = 0, previousListCount++;
                            previousList [previousListCount] = 0, previousListCount++;
                            previousList [previousListCount] = arrayCellTrackingTable [counter1*15+12], previousListCount++;
                        }
                        if (arrayCellTrackingTable [counter1*15+13] != 0){
                            previousList [previousListCount] = arrayCellTrackingTable [counter1*15+13], previousListCount++;
                            previousList [previousListCount] = 0, previousListCount++;
                            previousList [previousListCount] = 0, previousListCount++;
                            previousList [previousListCount] = 0, previousListCount++;
                            previousList [previousListCount] = 0, previousListCount++;
                            previousList [previousListCount] = arrayCellTrackingTable [counter1*15+13], previousListCount++;
                        }
                    }
                }
                
                for (int counter1 = 0; counter1 < previousListCount/6; counter1++){
                    entryCount = 0;
                    
                    for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                        if (arrayCellTrackingTable [counter2*15] == roundStatus-1){
                            entryCount++;
                            
                            if (entryCount == previousList [counter1*6]){
                                if (arrayCellTrackingTable [counter2*15+7] == 1) previousList [counter1*5] = 0;
                                else{
                                    
                                    previousList [counter1*6] = arrayCellTrackingTable [counter2*15+2];
                                    previousList [counter1*6+1] = roundStatus-1;
                                    previousList [counter1*6+2] = arrayCellTrackingTable [counter2*15+14];
                                    previousList [counter1*6+3] = arrayCellTrackingTable [counter2*15+2];
                                    previousList [counter1*6+4] = arrayCellTrackingTable [counter2*15+14];
                                }
                                
                                break;
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < previousListCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<previousList [counterA*6+counterB];
                //    cout<<" previousList "<<counterA<<" "<<endl;
                //}
                
                //1. connect No, 2. attached connect No, 3. attach Length, 4. Connect No line length, 5, attached connect No line length
                
                int roundNumber = 0;
                int newPreviousNo = 0;
                int newDoneNo = 0;
                int attachFlag = 0;
                
                for (int counter1 = 0; counter1 < previousListCount/6; counter1++){
                    connectPrevious = previousList [counter1*6];
                    roundNumber = roundStatus-1;
                    
                    if (connectPrevious != 0){
                        for (int counter2 = cellTrackingTableCount/15; counter2 >= 0; counter2--){
                            if (roundNumber == arrayCellTrackingTable [counter2*15] && arrayCellTrackingTable [counter2*15+7] == 1){
                                newPreviousNo = 0;
                                newDoneNo = 0;
                                
                                for (int counter3 = 0; counter3 < cellTrackingTableCount/15; counter3++){
                                    if (roundNumber == arrayCellTrackingTable [counter3*15] && arrayCellTrackingTable [counter3*15+2] == connectPrevious){
                                        newPreviousNo = arrayCellTrackingTable [counter3*15+12];
                                        newDoneNo = arrayCellTrackingTable [counter3*15+14];
                                        break;
                                    }
                                }
                                
                                if (newPreviousNo != 0 || roundNumber == 1){
                                    attachFlag = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellAttachCount/6; counter3++){
                                        if (arrayAttachTable [counter3*6] == roundNumber){
                                            if ((arrayAttachTable [counter3*6+1] == connectPrevious && arrayAttachTable [counter3*6+2] == arrayCellTrackingTable [counter2*15+2]) || (arrayAttachTable [counter3*6+2] == connectPrevious && arrayAttachTable [counter3*6+1] == arrayCellTrackingTable [counter2*15+2])){
                                                if (arrayAttachTable [counter3*6+3] > 50 && arrayAttachTable [counter3*6+3]/(double)arrayAttachTable [counter3*6+4] > 0.5 && arrayAttachTable [counter3*6+3]/(double)arrayAttachTable [counter3*6+5] > 0.5){
                                                    attachFlag = 1;
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                    
                                    if (attachFlag == 1){
                                        previousList [counter1*6] = connectPrevious;
                                        previousList [counter1*6+1] = roundNumber;
                                        previousList [counter1*6+2] = newDoneNo;
                                        
                                        if (arrayCellTrackingTable [counter2*15+12] == 0 || roundNumber == 1){
                                            break;
                                        }
                                        else{
                                            
                                            connectPrevious = newPreviousNo;
                                            roundNumber--;
                                        }
                                    }
                                    else{
                                        
                                        break;
                                    }
                                }
                                else{
                                    
                                    break;
                                }
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < previousListCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<previousList [counterA*6+counterB];
                //    cout<<" previousList "<<counterA<<" "<<endl;
                //}
                
                int statusSetFlag = 0;
                
                if (timeOneHold+10 <= imageNumberInt){
                    string connectRelationPath;
                    
                    long sizeForCopy = 0;
                    unsigned long readPosition = 0;
                    
                    int connectLineageRelTempCount = 0;
                    int redoImagePosition = 0;
                    int stepCount = 0;
                    int finData [19];
                    int fuseLineageNo = 0;
                    int fuseCellNo = 0;
                    int findEvents = 0;
                    
                    ifstream fin;
                    
                    for (int counter1 = 0; counter1 < previousListCount/6; counter1++){
                        if (previousList [counter1*6] != 0){
                            redoImagePosition = imageNumberInt-(roundStatus-previousList [counter1*6+1])+1;
                            
                            if (redoImagePosition == 1 && roundStatus > 3 && previousList [counter1*6+2] > 1000 && previousList [counter1*6+2] != 2000 && (statusSetFlag == 0 || statusSetFlag == 2) && trackHoldFlag != 1010){ //-------Lineage Fuse, back to Tracking Control-----
                                string extension3 = to_string(timeOneHold);
                                
                                if (extension3.length() == 1) extension3 = "000"+extension3;
                                else if (extension3.length() == 2) extension3 = "00"+extension3;
                                else if (extension3.length() == 3) extension3 = "0"+extension3;
                                
                                connectRelationPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension3+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
                                
                                struct stat sizeOfFile;
                                
                                if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                else{
                                    
                                    errorNoHold = 1000;
                                    throw errorCheckThrow;
                                }
                                
                                errorNoHold = 73;
                                int *arrayConnectLineageRelTemp = new int [sizeForCopy+50];
                                connectLineageRelTempCount = 0;
                                
                                if (sizeForCopy != 0){
                                    fin.open(connectRelationPath .c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        errorNoHold = 74;
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                                            usleep(50000);
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            
                                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                                                errorNoHold = 1001;
                                                throw errorCheckThrow;
                                            }
                                        }
                                        
                                        fin.close();
                                        
                                        readPosition = 0;
                                        stepCount = 0;
                                        
                                        do{
                                            
                                            if (stepCount == 0){
                                                finData [0] = uploadTemp [readPosition], readPosition++;
                                                finData [1] = uploadTemp [readPosition], readPosition++;
                                                finData [2] = uploadTemp [readPosition], readPosition++; //--1 Ling no
                                                finData [3] = uploadTemp [readPosition], readPosition++;
                                                finData [4] = uploadTemp [readPosition], readPosition++;
                                                finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                                                finData [6] = uploadTemp [readPosition], readPosition++;
                                                finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                                                finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                                                finData [9] = uploadTemp [readPosition], readPosition++;
                                                finData [10] = uploadTemp [readPosition], readPosition++;
                                                finData [11] = uploadTemp [readPosition], readPosition++;
                                                finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                                                finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                                                finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                                                
                                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                                finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                                                finData [7] = finData [6]*256+finData [7];
                                                
                                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                                
                                                if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                                else{
                                                    
                                                    arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [2], connectLineageRelTempCount++;
                                                    arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [5], connectLineageRelTempCount++;
                                                    arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [7], connectLineageRelTempCount++;
                                                    arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [12], connectLineageRelTempCount++;
                                                    arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [13], connectLineageRelTempCount++;
                                                    arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [14], connectLineageRelTempCount++;
                                                }
                                            }
                                            
                                        } while (stepCount != 3);
                                        
                                        delete [] uploadTemp;
                                    }
                                    else{
                                        
                                        errorNoHold = 1002;
                                        throw errorCheckThrow;
                                    }
                                }
                                
                                fuseLineageNo = 0;
                                fuseCellNo = 0;
                                
                                for (int counter2 = 0; counter2 < connectLineageRelTempCount/6; counter2++){
                                    if (arrayConnectLineageRelTemp [counter2*6+1] == previousList [counter1*6]){
                                        fuseLineageNo = arrayConnectLineageRelTemp [counter2*6];
                                        fuseCellNo = arrayConnectLineageRelTemp [counter2*6+3];
                                        break;
                                    }
                                }
                                
                                delete [] arrayConnectLineageRelTemp;
                                
                                findEvents = 0;
                                
                                for (int counter2 = 0; counter2 < lineageDataCount/8; counter2++){
                                    if (arrayLineageData [counter2*8+5] == fuseCellNo && arrayLineageData [counter2*8+6] == fuseLineageNo){
                                        if (arrayLineageData [counter2*8+3] == 92 || arrayLineageData [counter2*8+3] == 31 || arrayLineageData [counter2*8+3] == 41 || arrayLineageData [counter2*8+3] == 51){
                                            findEvents = 1;
                                            break;
                                        }
                                    }
                                }
                                
                                if (findEvents == 0){
                                    arrayCellTrackingTable [counter1*15+9] = 1010;
                                    statusAdditionalInfo = previousList [counter1*6];
                                    trackHoldFlag = 1010;
                                    statusSetFlag = 1;
                                }
                            }
                            else if (redoImagePosition == 1 && roundStatus > 3 && previousList [counter1*6+2] < 1000 && trackHoldFlag != 1010 && trackHoldFlag != 1011 && retryInfoHold == 0){ //------Fuse redo-----
                                arrayCellTrackingTable [counter1*15+9] = 1011;
                                fusionPartnerCellNo = previousList [counter1*6]; //-------Connect No--------
                                statusAdditionalInfo = previousList [counter1*6+2]; //-------Round No------
                                trackHoldFlag = 1011;
                                statusSetFlag = 2;
                                
                                retryInfoHold = 1;
                            }
                        }
                    }
                }
                
                if (statusSetFlag == 0){
                    int overTwoThousandCount = 0;
                    
                    for (int counter1 = 0; counter1 < previousListCount/6; counter1++){
                        if (previousList [counter1*6+2] == 2000) overTwoThousandCount++;
                    }
                    
                    if (overTwoThousandCount == 1){ //------Fusion set-------
                        int fuseCellConnectNo = 0;
                        
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (roundStatus == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+7] == 1 && fusionMarkSetFlag == 0){
                                for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                                    if (roundStatus-1 == arrayCellTrackingTable [counter2*15] && arrayCellTrackingTable [counter2*15+7] == 1) arrayCellTrackingTable [counter2*15+9] = -3;
                                }
                                
                                trackHoldFlag = -3;
                                
                                fuseCellConnectNo = 0;
                                
                                for (int counter2 = 0; counter2 < previousListCount/6; counter2++){
                                    if (previousList [counter2*6+2] == 2000){
                                        fuseCellConnectNo = previousList [counter2*6+3];
                                        break;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < connectLineageRelCount/6; counter2++){
                                    if (arrayConnectLineageRel [counter2*6+1] == fuseCellConnectNo){
                                        fusionPartnerLine = arrayConnectLineageRel [counter2*6];
                                        fusionPartnerCellNo = arrayConnectLineageRel [counter2*6+4];
                                        break;
                                    }
                                }
                                
                                if (fusionPartnerLine == 0){
                                    for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                                        if (roundStatus-1 == arrayCellTrackingTable [counter2*15] && arrayCellTrackingTable [counter2*15+7] == 1) arrayCellTrackingTable [counter2*15+9] = -2;
                                    }
                                    
                                    trackHoldFlag = -2;
                                }
                            }
                        }
                    }
                    else if (overTwoThousandCount > 1){
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (roundStatus == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+7] == 1){
                                arrayCellTrackingTable [counter1*15+9] = 1009;
                                trackHoldFlag = 1009;
                            }
                        }
                    }
                    else{
                        
                        int previousTargetConnect = 0;
                        int previousEntryCount = 0;
                        
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (roundStatus-1 == arrayCellTrackingTable [counter1*15]){
                                previousEntryCount++;
                                
                                if (arrayCellTrackingTable [counter1*15+7] == 1){
                                    previousTargetConnect = previousEntryCount;
                                    break;
                                }
                            }
                        }
                        
                        int currentTargetConnect = 0;
                        
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (roundStatus == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+7] == 1){
                                currentTargetConnect = arrayCellTrackingTable [counter1*15+2];
                                break;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (roundStatus == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+2] == currentTargetConnect){
                                arrayCellTrackingTable [counter1*15+12] = 0;
                                arrayCellTrackingTable [counter1*15+13] = 0;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (roundStatus == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+7] == 1){
                                arrayCellTrackingTable [counter1*15+12] = previousTargetConnect;
                                break;
                            }
                        }
                    }
                }
                
                delete [] previousList;
            }
            
            //**********Lost**********
            if (targetNo == 0){ //--------Will Check Lost/Fusion at the Area cut with Current, enter at roundStatus-1-------
                for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                    if (roundStatus-1 == arrayCellTrackingTable [counter1*15] && arrayCellTrackingTable [counter1*15+7] == 1){
                        arrayCellTrackingTable [counter1*15+9] = 0;
                        arrayCellTrackingTable [counter1*15+14] = 1008;
                        trackHoldFlag = 1008;
                    }
                }
            }
            
            //cout<<noOfPrevious<<" "<<noOfNext<<" "<<targetNo<<" No"<<endl;
            
            //**********No Event occurs**********
            if ((noOfPrevious == 0 || noOfPrevious == 1) && noOfNext == 1 && targetNo != 0){
                int mitosisSetStatus = 0;
                int cellDeathSetStatus = 0;
                int settingPoint = 0;
                
                if (mitosisCount == 1000){ //-----Mitosis already set-------
                    mitosisSetStatus = 4;
                }
                
                if (mitosisCount != 0 && cellDeathCount == 0){ //-----Mitosis/no cell death case-------
                    int mitosisContinueCount = 0;
                    int mitosisContinueHold = 0;
                    int mitosisOneContinueCount = 0;
                    int mitosisOneContinueHold = 0;
                    int mitosisSixContinueCount = 0;
                    int totalMitosisCount = 0;
                    int nonMitosisContinueCount = 0;
                    int nonMitosisContinueHold = 0;
                    int mitosisLastPoint = 0;
                    int mitosisOnePoint = 0;
                    int mitosisSixPoint = 0;
                    
                    for (int counter1 = mitosisParameterCount/4-1; counter1 > 0; counter1--){
                        if (mitosisCellDeathStatus [counter1] == 1 || mitosisCellDeathStatus [counter1] == 2 || mitosisCellDeathStatus [counter1] == 6){
                            mitosisContinueCount++; //-------Contentious detection check, Mitosis-------
                            totalMitosisCount++;
                            
                            if (mitosisLastPoint == 0) mitosisLastPoint = counter1;
                        }
                        else if (mitosisCellDeathStatus [counter1] == 0){
                            if (mitosisContinueHold < mitosisContinueCount) mitosisContinueHold = mitosisContinueCount;
                            
                            mitosisContinueCount = 0;
                        }
                        
                        if (mitosisCellDeathStatus [counter1] == 1){
                            mitosisOneContinueCount++; //-------Contentious detection check, Mitosis-------
                            mitosisOnePoint = counter1;
                        }
                        
                        if (mitosisCellDeathStatus [counter1] == 6){
                            mitosisSixPoint = counter1;
                            mitosisSixContinueCount++; //-------Contentious detection check, Mitosis-------
                        }
                        
                        if (mitosisCellDeathStatus [counter1] == 0) nonMitosisContinueCount++; //-------Contentious detection check, non-Mitosis-------
                        else if (mitosisCellDeathStatus [counter1] != 0){
                            if (nonMitosisContinueHold < nonMitosisContinueCount) nonMitosisContinueHold = nonMitosisContinueCount;
                        }
                    }
                    
                    //cout<<mitosisSixPoint<<" "<<mitosisOnePoint<<" "<<" mitosis "<<mitosisSetStatus<<" "<<endl;
                    
                    if (mitosisSetStatus != 4){
                        if (mitosisSixContinueCount >= 1){
                            mitosisSetStatus = 1;
                            settingPoint = mitosisSixPoint;
                        }
                        else if (mitosisOneContinueHold >= 3){
                            mitosisSetStatus = 1; //--------More than 4 detection, Mitosis set-------
                            settingPoint = mitosisOnePoint;
                        }
                        else if (totalMitosisCount >= 6 && nonMitosisContinueHold >= 8){
                            if (mitosisLastPoint <= roundStatus-nonMitosisContinueHold) mitosisSetStatus = 2; //=========Set IP, StatusCheck Return=========
                            else mitosisSetStatus = 0;
                        }
                        else mitosisSetStatus = 0;
                    }
                }
                else if (mitosisCount == 0 && cellDeathCount != 0){ //-------No mitosis/cell death case---------
                    int cellDeathContinueCount = 0;
                    int cellDeathContinueHold = 0;
                    int cellDeathFourContinueCount = 0;
                    int cellDeathFourContinueHold = 0;
                    int cellDeathTotalCount = 0;
                    int cellDeathLast = 0;
                    int cellDeathStart = 0;
                    
                    for (int counter1 = mitosisParameterCount/4-1; counter1 > 0; counter1--){
                        if (counter1 == mitosisParameterCount/4-1) cellDeathLast = mitosisCellDeathStatus [counter1];
                        
                        if (mitosisCellDeathStatus [counter1] == 3 || mitosisCellDeathStatus [counter1] == 4){
                            cellDeathContinueCount++;
                            cellDeathTotalCount++;
                        }
                        else if (mitosisCellDeathStatus [counter1] == 0){
                            if (cellDeathContinueHold < cellDeathContinueCount) cellDeathContinueHold = cellDeathContinueCount;
                            
                            cellDeathContinueCount = 0;
                        }
                        
                        if (mitosisCellDeathStatus [counter1] == 4) cellDeathFourContinueCount++;
                        else if (mitosisCellDeathStatus [counter1] == 0){
                            if (cellDeathFourContinueHold < cellDeathFourContinueCount) cellDeathFourContinueHold = cellDeathFourContinueCount;
                            
                            cellDeathFourContinueCount = 0;
                        }
                        
                        cellDeathStart = mitosisCellDeathStatus [counter1];
                    }
                    
                    //cout<<cellDeathFourContinueHold<<" "<<cellDeathContinueHold<<" "<<cellDeathTotalCount<<" "<<cellDeathLast<<" "<<cellDeathStart<<"  Info"<<endl;
                    
                    if (cellDeathFourContinueHold >= 6) cellDeathSetStatus = 1;
                    else if (cellDeathContinueHold >= 7) cellDeathSetStatus = 1; //-------Continue to check------
                    else if (cellDeathTotalCount >= 7 && cellDeathLast == 3) cellDeathSetStatus = 1; //-------Cell death set------
                    else if (cellDeathTotalCount >= 7 && cellDeathLast == 0) cellDeathSetStatus = 3; //=======StatusCheck Return=======
                    else  cellDeathSetStatus = 0;
                    
                    if (cellDeathStart != 0 && cellDeathSetStatus == 1) cellDeathSetStatus = 2; //=======Debris Set, StatusCheck Return=========
                }
                else if (mitosisCount != 0 && cellDeathCount != 0){ //-----Both Found----------
                    int mitosisContinueCount = 0;
                    int mitosisContinueHold = 0;
                    int mitosisOneContinueCount = 0;
                    int mitosisOneContinueHold = 0;
                    int mitosisSixContinueCount = 0;
                    int totalMitosisCount = 0;
                    int nonMitosisContinueCount = 0;
                    int nonMitosisContinueHold = 0;
                    int mitosisLastPoint = 0;
                    int mitosisOnePoint = 0;
                    int mitosisSixPoint = 0;
                    int cellDeathContinueCount = 0;
                    int cellDeathContinueHold = 0;
                    int cellDeathFourContinueCount = 0;
                    int cellDeathFourContinueHold = 0;
                    int cellDeathTotalCount = 0;
                    int cellDeathLast = 0;
                    int cellDeathStart = 0;
                    
                    for (int counter1 = mitosisParameterCount/4-1; counter1 > 0; counter1--){ //-------Find First and Last Status--------
                        if (counter1 == mitosisParameterCount/4-1) cellDeathLast = mitosisCellDeathStatus [counter1];
                        
                        if (mitosisCellDeathStatus [counter1] == 1 || mitosisCellDeathStatus [counter1] == 2 || mitosisCellDeathStatus [counter1] == 6){
                            mitosisContinueCount++; //-------Contentious detection check, Mitosis-------
                            totalMitosisCount++;
                            
                            if (mitosisLastPoint == 0) mitosisLastPoint = counter1;
                        }
                        else if (mitosisCellDeathStatus [counter1] == 0 || mitosisCellDeathStatus [counter1] == 3 || mitosisCellDeathStatus [counter1] == 4){
                            if (mitosisContinueHold < mitosisContinueCount) mitosisContinueHold = mitosisContinueCount;
                            
                            mitosisContinueCount = 0;
                        }
                        
                        if (mitosisCellDeathStatus [counter1] == 1){
                            mitosisOneContinueCount++; //-------Contentious detection check, Mitosis-------
                            mitosisOnePoint = counter1;
                        }
                        
                        if (mitosisCellDeathStatus [counter1] == 6){
                            mitosisSixContinueCount++; //-------Contentious detection check, Mitosis-------
                            mitosisSixPoint = counter1;
                        }
                        
                        if (mitosisCellDeathStatus [counter1] == 0) nonMitosisContinueCount++; //-------Contentious detection check, non-Mitosis-------
                        else if (mitosisCellDeathStatus [counter1] != 0){
                            if (nonMitosisContinueHold < nonMitosisContinueCount) nonMitosisContinueHold = nonMitosisContinueCount;
                        }
                        
                        if (mitosisCellDeathStatus [counter1] == 3 || mitosisCellDeathStatus [counter1] == 4){
                            cellDeathContinueCount++;
                            cellDeathTotalCount++;
                        }
                        else if (mitosisCellDeathStatus [counter1] == 0 || mitosisCellDeathStatus [counter1] == 1 || mitosisCellDeathStatus [counter1] == 2 || mitosisCellDeathStatus [counter1] == 6){
                            if (cellDeathContinueHold < cellDeathContinueCount) cellDeathContinueHold = cellDeathContinueCount;
                            
                            cellDeathContinueCount = 0;
                        }
                        
                        if (mitosisCellDeathStatus [counter1] == 4) cellDeathFourContinueCount++;
                        else if (mitosisCellDeathStatus [counter1] == 0 || mitosisCellDeathStatus [counter1] == 1 || mitosisCellDeathStatus [counter1] == 2 || mitosisCellDeathStatus [counter1] == 6){
                            if (cellDeathFourContinueHold < cellDeathFourContinueCount) cellDeathFourContinueHold = cellDeathFourContinueCount;
                            
                            cellDeathFourContinueCount = 0;
                        }
                        
                        cellDeathStart = mitosisCellDeathStatus [counter1];
                    }
                    
                    if (mitosisContinueHold < 3 && cellDeathContinueHold >= 6){ //------Last, Cell Death---------
                        if (cellDeathFourContinueHold >= 6 && mitosisSetStatus != 4) cellDeathSetStatus = 1;
                        else if (cellDeathFourContinueHold >= 6 && mitosisSetStatus == 4) cellDeathSetStatus = 6;
                        else if (cellDeathContinueHold >= 7 && mitosisSetStatus != 4) cellDeathSetStatus = 1;
                        else if (cellDeathContinueHold >= 7 && mitosisSetStatus == 4) cellDeathSetStatus = 6;
                        else if (cellDeathTotalCount >= 7 && cellDeathLast == 3 && mitosisSetStatus == 4) cellDeathSetStatus = 6;
                        else if (cellDeathTotalCount >= 7 && cellDeathLast == 3 && mitosisSetStatus != 4) cellDeathSetStatus = 1; //-------Cell death set------
                        else if (cellDeathTotalCount >= 7 && cellDeathLast != 3) cellDeathSetStatus = 3; //=======StatusCheck Return=======
                        else cellDeathSetStatus = 0;
                        
                        if (cellDeathStart != 0 && cellDeathSetStatus == 1) cellDeathSetStatus = 2; //=======Debris Set, StatusCheck Return=========
                    }
                    else if (mitosisContinueHold >= 3 && cellDeathContinueHold < 6){
                        if (mitosisSetStatus != 4){
                            if (mitosisSixContinueCount >= 1){
                                mitosisSetStatus = 1;
                                settingPoint = mitosisSixPoint;
                            }
                            else if (mitosisOneContinueHold >= 3){
                                mitosisSetStatus = 1; //--------More than 4 detection, Mitosis set-------
                                settingPoint = mitosisOnePoint;
                            }
                            else if (totalMitosisCount >= 6 && nonMitosisContinueHold >= 8){
                                if (mitosisLastPoint < roundStatus-nonMitosisContinueHold) mitosisSetStatus = 2; //=========Set IP, StatusCheck Return=========
                                else mitosisSetStatus = 0;
                            }
                            else mitosisSetStatus = 0;
                            
                            //cout<<mitosisSixPoint<<" "<<mitosisOnePoint<<" "<<mitosisContPoint<<" mitosis"<<endl;
                        }
                    }
                    else if (mitosisContinueHold < 3 && cellDeathContinueHold < 6){
                        if (totalMitosisCount > 4 && cellDeathTotalCount > 6 && mitosisSetStatus != 4) cellDeathSetStatus = 5; //=======Cell Death StatusCheck Return=======
                        else if (totalMitosisCount > 4 && cellDeathTotalCount > 6 && mitosisSetStatus == 4) cellDeathSetStatus = 6; //=======Cell Death StatusCheck Return=======
                    }
                }
                
                //======mitosisSetStatus: 0: cont, 1. Set, 2:IP (STR), 3:Mitosis clear (STR), 4:Mitosis already set========
                //======cellDeathSetStatus: 0: cont, 1. Set, 2:Debris (STR), 3:Cell death clear (STR), 4:Mitosis/Cell death Mix (STR), 5:Cell death Set (STR)========
                
                if (mitosisSetStatus == 1 && mitosisOffFlag == 0){
                    int settingPointImageNo = 0;
                    
                    //for (int counterA = 0; counterA < mitosisParameterCount/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisParameter [counterA*4+counterB];
                    //    cout<<" mitosisParameterCount "<<counterA<<endl;
                    //}
                    
                    settingPoint = arrayMitosisParameter [(settingPoint-1)*4+2];
                    
                    for (int counter1 = 0; counter1 < mitosisParameterCount/4; counter1++){
                        if (arrayMitosisParameter [counter1*4+2] < settingPoint){
                            arrayMitosisParameter [counter1*4+3] = 0;
                        }
                        else if (arrayMitosisParameter [counter1*4+2] == settingPoint){
                            arrayMitosisParameter [counter1*4+3] = 5;
                            settingPointImageNo = arrayMitosisParameter [counter1*4+2];
                        }
                        else if (arrayMitosisParameter [counter1*4+2] > settingPoint){
                            arrayMitosisParameter [counter1*4+3] = 5;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < mitosisParameterCount/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisParameter [counterA*4+counterB];
                    //    cout<<" arrayMitosisParameter "<<counterA<<endl;
                    //}
                    
                    if (settingPointImageNo != 0 && settingPointImageNo < imageNumberInt-roundStatus+2){
                        outsideSettingFlag = 1;
                        statusAdditionalInfo = settingPointImageNo; //-------Image no------
                    }
                    
                    if (outsideSettingFlag == 0){
                        int firstMitosisFind = 0;
                        
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (arrayCellTrackingTable [counter1*15+7] == 1 && arrayCellTrackingTable [counter1*15+1] == settingPointImageNo && firstMitosisFind == 0){
                                arrayCellTrackingTable [counter1*15+8] = 5;
                                statusAdditionalInfo = arrayCellTrackingTable [counter1*15+1];
                                trackHoldFlag = 100;
                                firstMitosisFind = 1;
                            }
                            else if (arrayCellTrackingTable [counter1*15+7] == 1 && firstMitosisFind == 1) arrayCellTrackingTable [counter1*15+8] = 5;
                            else arrayCellTrackingTable [counter1*15+8] = 0;
                        }
                    }
                    else{
                        
                        int firstMitosisFind = 0;
                        
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (arrayCellTrackingTable [counter1*15+7] == 1 && firstMitosisFind == 0){
                                arrayCellTrackingTable [counter1*15+8] = 5;
                                trackHoldFlag = 100;
                                firstMitosisFind = 1;
                            }
                            else if (arrayCellTrackingTable [counter1*15+7] == 1 && firstMitosisFind == 1) arrayCellTrackingTable [counter1*15+8] = 5;
                        }
                    }
                }
                else if (mitosisSetStatus == 2){
                    int firstMitosisFind = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (arrayCellTrackingTable [counter1*15+7] == 1 && (arrayCellTrackingTable [counter1*15+8] == 2 || arrayCellTrackingTable [counter1*15+8] == 1) && firstMitosisFind == 0){
                            arrayCellTrackingTable [counter1*15+8] = 1;
                            firstMitosisFind = 1;
                        }
                        else if (arrayCellTrackingTable [counter1*15+7] == 1 && (arrayCellTrackingTable [counter1*15+8] == 2 || arrayCellTrackingTable [counter1*15+8] == 1) && firstMitosisFind == 1){
                            arrayCellTrackingTable [counter1*15+8] = 1;
                        }
                        else if (arrayCellTrackingTable [counter1*15+7] == 1 && arrayCellTrackingTable [counter1*15+8] == 0 && firstMitosisFind == 1){
                            arrayCellTrackingTable [counter1*15+8] = 0;
                            firstMitosisFind = 2;
                        }
                        else arrayCellTrackingTable [counter1*15+8] = 0;
                    }
                    
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (arrayCellTrackingTable [counter1*15+7] == 1 && arrayCellTrackingTable [counter1*15+8] == 1){
                            arrayCellTrackingTable [counter1*15+9] = 1000;
                            trackHoldFlag = 1000;
                            break;
                        }
                    }
                }
                else if (mitosisSetStatus == 3){
                    int firstMitosisFind = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (arrayCellTrackingTable [counter1*15+7] == 1 && (arrayCellTrackingTable [counter1*15+8] == 2 || arrayCellTrackingTable [counter1*15+8] == 1) && firstMitosisFind == 0){
                            arrayCellTrackingTable [counter1*15+8] = 0;
                            arrayCellTrackingTable [counter1*15+9] = 1001;
                            trackHoldFlag = 1001;
                            firstMitosisFind = 1;
                        }
                        else arrayCellTrackingTable [counter1*15+8] = 0;
                    }
                }
                else if (mitosisSetStatus == 4 && cellDeathSetStatus != 6){
                    int firstMitosisFind = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (arrayCellTrackingTable [counter1*15+7] == 1 && (arrayCellTrackingTable [counter1*15+8] == 2 || arrayCellTrackingTable [counter1*15+8] == 1 || arrayCellTrackingTable [counter1*15+8] == 6) && firstMitosisFind == 0){
                            arrayCellTrackingTable [counter1*15+8] = 5;
                            firstMitosisFind = 1;
                        }
                        else if (arrayCellTrackingTable [counter1*15+7] == 1 && arrayCellTrackingTable [counter1*15+8] == 5 && firstMitosisFind == 0) firstMitosisFind = 1;
                        else if (arrayCellTrackingTable [counter1*15+7] == 1 && firstMitosisFind == 1) arrayCellTrackingTable [counter1*15+8] = 5;
                        else arrayCellTrackingTable [counter1*15+8] = 0;
                    }
                    
                    int findFlag = 0;
                    
                    for (int counter1 = 0; counter1 < mitosisParameterCount/4; counter1++){
                        if (findFlag == 0 && arrayMitosisParameter [counter1*4+3] == 5) findFlag = 1;
                        else if (findFlag == 1) arrayMitosisParameter [counter1*4+3] = 5;
                    }
                }
                else if (cellDeathSetStatus == 6){
                    int firstMitosisFind = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (arrayCellTrackingTable [counter1*15+7] == 1 && (arrayCellTrackingTable [counter1*15+8] == 3 || arrayCellTrackingTable [counter1*15+8] == 4) && firstMitosisFind == 0){
                            arrayCellTrackingTable [counter1*15+9] = 1002;
                            trackHoldFlag = 1002;
                            firstMitosisFind = 1;
                        }
                    }
                }
                else if (cellDeathSetStatus == 1){
                    int findFlag = 0;
                    int settingPointImageNo = 0;
                    
                    for (int counter1 = 0; counter1 < mitosisParameterCount/4; counter1++){
                        if (findFlag == 0 && (arrayMitosisParameter [counter1*4+3] == 4 || arrayMitosisParameter [counter1*4+3] == 3)){
                            arrayMitosisParameter [counter1*4+3] = 8;
                            settingPointImageNo = arrayMitosisParameter [counter1*4+2];
                            findFlag = 1;
                        }
                        else if (findFlag == 1) arrayMitosisParameter [counter1*4+3] = 8;
                    }
                    
                    if (settingPointImageNo != 0 && settingPointImageNo < imageNumberInt-roundStatus+2){
                        outsideSettingFlag = 1;
                        
                        for (int counter1 = 0; counter1 < mitosisParameterCount/4; counter1++){
                            if (arrayMitosisParameter [counter1*4+2] < imageNumberInt-roundStatus+2) arrayMitosisParameter [counter1*4+3] = 0;
                        }
                    }
                    
                    if (outsideSettingFlag == 0){
                        int firstCellDeathFind = 0;
                        
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (arrayCellTrackingTable [counter1*15+7] == 1 && (arrayCellTrackingTable [counter1*15+8] == 4 || arrayCellTrackingTable [counter1*15+8] == 3) && firstCellDeathFind == 0){
                                arrayCellTrackingTable [counter1*15+8] = 8;
                                arrayCellTrackingTable [counter1*15+9] = 10;
                                trackHoldFlag = 10;
                                firstCellDeathFind = 1;
                            }
                            else if (arrayCellTrackingTable [counter1*15+7] == 1 && firstCellDeathFind == 1) arrayCellTrackingTable [counter1*15+8] = 8;
                            else arrayCellTrackingTable [counter1*15+8] = 0;
                        }
                    }
                    else{
                        
                        int firstCellDeathFind = 0;
                        
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (arrayCellTrackingTable [counter1*15+7] == 1 && (arrayCellTrackingTable [counter1*15+8] == 4 || arrayCellTrackingTable [counter1*15+8] == 3) && firstCellDeathFind == 0){
                                arrayCellTrackingTable [counter1*15+8] = 8;
                                arrayCellTrackingTable [counter1*15+9] = 1005;
                                trackHoldFlag = 1005;
                                firstCellDeathFind = 1;
                            }
                            else if (arrayCellTrackingTable [counter1*15+7] == 1 && firstCellDeathFind == 1) arrayCellTrackingTable [counter1*15+8] = 8;
                            else arrayCellTrackingTable [counter1*15+8] = 0;
                        }
                    }
                }
                else if (cellDeathSetStatus == 2){
                    int firstCellDeathFind = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (arrayCellTrackingTable [counter1*15+7] == 1 && (arrayCellTrackingTable [counter1*15+8] == 4 || arrayCellTrackingTable [counter1*15+8] == 3) && firstCellDeathFind == 0){
                            arrayCellTrackingTable [counter1*15+8] = 7;
                            arrayCellTrackingTable [counter1*15+9] = 1003;
                            trackHoldFlag = 1003;
                            firstCellDeathFind = 1;
                        }
                        else if (arrayCellTrackingTable [counter1*15+7] == 1 && (arrayCellTrackingTable [counter1*15+8] == 4 || arrayCellTrackingTable [counter1*15+8] == 3) && firstCellDeathFind == 1){
                            arrayCellTrackingTable [counter1*15+8] = 7;
                        }
                        else if (arrayCellTrackingTable [counter1*15+7] == 1 && arrayCellTrackingTable [counter1*15+8] == 0 && firstCellDeathFind == 1){
                            arrayCellTrackingTable [counter1*15+8] = 0;
                            firstCellDeathFind = 2;
                        }
                        else arrayCellTrackingTable [counter1*15+8] = 0;
                    }
                    
                    int findFlag = 0;
                    
                    for (int counter1 = 0; counter1 < mitosisParameterCount/4; counter1++){
                        if (findFlag == 0 && (arrayMitosisParameter [counter1*4+3] == 4 || arrayMitosisParameter [counter1*4+3] == 3)){
                            arrayMitosisParameter [counter1*4+3] = 7;
                            findFlag = 1;
                        }
                        else if (findFlag == 1) arrayMitosisParameter [counter1*4+3] = 7;
                    }
                }
                else if (cellDeathSetStatus == 3){
                    int firstCellDeathFind = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (arrayCellTrackingTable [counter1*15+7] == 1 && arrayCellTrackingTable [counter1*15+8] != 0 && firstCellDeathFind == 0){
                            arrayCellTrackingTable [counter1*15+8] = 0;
                            arrayCellTrackingTable [counter1*15+9] = 1004;
                            trackHoldFlag = 1004;
                            firstCellDeathFind = 1;
                        }
                        else arrayCellTrackingTable [counter1*15+8] = 0;
                    }
                }
                else if (cellDeathSetStatus == 5){
                    int firstCellDeathFind = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (arrayCellTrackingTable [counter1*15+7] == 1 && (arrayCellTrackingTable [counter1*15+8] == 4 || arrayCellTrackingTable [counter1*15+8] == 3) && firstCellDeathFind == 0){
                            arrayCellTrackingTable [counter1*15+8] = 8;
                            arrayCellTrackingTable [counter1*15+9] = 1005;
                            trackHoldFlag = 1005;
                            firstCellDeathFind = 1;
                        }
                        else if (arrayCellTrackingTable [counter1*15+7] == 1 && firstCellDeathFind == 1) arrayCellTrackingTable [counter1*15+8] = 8;
                        else arrayCellTrackingTable [counter1*15+8] = 0;
                    }
                    
                    int findFlag = 0;
                    
                    for (int counter1 = 0; counter1 < mitosisParameterCount/4; counter1++){
                        if (findFlag == 0 && (arrayMitosisParameter [counter1*4+3] == 4 || arrayMitosisParameter [counter1*4+3] == 3)){
                            arrayMitosisParameter [counter1*4+3] = 8;
                            findFlag = 1;
                        }
                        else if (findFlag == 1) arrayMitosisParameter [counter1*4+3] = 8;
                    }
                }
            }
            
            delete [] mitosisCellDeathStatus;
            
            //for (int counterA = 0; counterA < mitosisParameterCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisParameter [counterA*4+counterB];
            //    cout<<" arrayMitosisParameter "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
            //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
            //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
            //}
            
            errorNoHold = 0;
            subCompletionFlag3 = 0;
        }
        catch (int errorCheckThrow){
            if (errorNoHold >= 1000 && errorNoHold < 2000){
                string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
                mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                time_t rawtime;
                struct tm * timeinfo;
                time (&rawtime);
                timeinfo = localtime ( &rawtime );
                
                int tsec = timeinfo -> tm_sec;
                int tmin = timeinfo -> tm_min;
                int thour = timeinfo -> tm_hour;
                int tday = timeinfo -> tm_mday;
                int tmon = timeinfo -> tm_mon;
                
                string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
                
                errorPath = errorPath+"/Cell_CarvingTableInterpretation03 "+dateTime;
                
                ofstream oin2;
                oin2.open(errorPath.c_str(), ios::out);
                oin2<<"TableInterpretation-interpretationMain2"<<endl;
                oin2<<errorNoHold<<endl;
                oin2<<analysisImageName<<endl;
                oin2<<analysisID<<endl;
                oin2<<treatmentNameHold<<endl;
                oin2<<cellLineageNoHold<<endl;
                oin2<<cellNoHold<<endl;
                oin2<<dateTime<<endl;
                
                if (errorNoHold == 1000) oin2<<"ConnectRel data open-error"<<endl;
                else if (errorNoHold == 1001) oin2<<"ConnectRel data uploading error"<<endl;
                else if (errorNoHold == 1002) oin2<<"ConnectRel data open-error"<<endl;
                oin2.close();
            }
            
            if (errorNoHold == 0) errorNoHold = 1000;
            
            subCompletionFlag3 = 0;
        }
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingTableInterpretation04 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"TableInterpretation-interpretationMain2"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
        
        subCompletionFlag3 = 0;
    }
}

@end
