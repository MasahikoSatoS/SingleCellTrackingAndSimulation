//
//  ImageFileUpLoad.h
//  Cell_Carving
//
//  Created by Masahiko Sato on 2016-02-10.
//
//

#ifndef IMAGEFILEUPLOAD_H
#define IMAGEFILEUPLOAD_H
#import "Controller.h"
#endif

@interface ImageFileUpLoad : NSObject{
}

-(void)fileUploadMain;

@end
