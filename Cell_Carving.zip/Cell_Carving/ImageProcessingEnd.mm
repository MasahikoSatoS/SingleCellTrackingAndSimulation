//
//  ImageProcessingEnd.m
//  Cell_Carving
//
//  Created by Masahiko Sato on 2015-12-18.
//
//

#import "ImageProcessingEnd.h"

NSString *notificationToImageProcessingEnd = @"notoficationExecuteImageProcessingEnd";

@implementation ImageProcessingEnd

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToImageProcessingEnd object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    try{
        try{
            
            errorNoHold = 0;
            int errorCheckThrow = 0;
            
            //---------Fluorescent Image Find--------
            fluorescentDetectionDisplay1 = 0;
            
            string extensionString2 = to_string (imageNumberInt);
            
            if (extensionString2.length() == 1) extensionString2 = "000"+extensionString2;
            else if (extensionString2.length() == 2) extensionString2 = "00"+extensionString2;
            else if (extensionString2.length() == 3) extensionString2 = "0"+extensionString2;
            
            int fluorescentDisplayFind1 = 0;
            int fluorescentDisplayFind2 = 0;
            int fluorescentDisplayFind3 = 0;
            int fluorescentDisplayFind4 = 0;
            int fluorescentDisplayFind5 = 0;
            int fluorescentDisplayFind6 = 0;
            
            ifstream fin;
            
            string extension2 = to_string (fluorescentNo1);
            string fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName1+".tif";
            
            fin.open(fluorescentPath1.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName1+".bmp";
            }
            else fin.close();
            
            extension2 = to_string (fluorescentNo2);
            string fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName2+".tif";
            
            fin.open(fluorescentPath2.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName2+".bmp";
            }
            else fin.close();
            
            extension2 = to_string (fluorescentNo3);
            string fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName3+".tif";
            
            fin.open(fluorescentPath3.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName3+".bmp";
            }
            else fin.close();
            
            extension2 = to_string (fluorescentNo4);
            string fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName4+".tif";
            
            fin.open(fluorescentPath4.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName4+".bmp";
            }
            else fin.close();
            
            extension2 = to_string (fluorescentNo5);
            string fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName5+".tif";
            
            fin.open(fluorescentPath5.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName5+".bmp";
            }
            else fin.close();
            
            extension2 = to_string (fluorescentNo6);
            string fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName6+".tif";
            
            fin.open(fluorescentPath6.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName6+".bmp";
            }
            else fin.close();
            
            struct stat sizeOfFile;
            
            if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind1 = 1;
            }
            if (stat(fluorescentPath2.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind2 = 1;
            }
            if (stat(fluorescentPath3.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind3 = 1;
            }
            if (stat(fluorescentPath4.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind4 = 1;
            }
            if (stat(fluorescentPath5.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind5 = 1;
            }
            if (stat(fluorescentPath6.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind6 = 1;
            }
            
            if (fluorescentDisplayFind1 == 1 || fluorescentDisplayFind2 == 1 || fluorescentDisplayFind3 == 1 || fluorescentDisplayFind4 == 1 || fluorescentDisplayFind5 == 1 || fluorescentDisplayFind6 == 1) fluorescentDetectionDisplay1 = 1;
            
            if (fluorescentDetectionDisplay1 == 1){
                string expandDataPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extensionString2+"_"+analysisID+"_"+treatmentNameHold+"_ExtendLineData";
                
                long sizeForCopy = 0;
                long size1 = 0;
                long size2 = 0;
                int checkFlag = 0;
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    sizeForCopy = 0;
                    
                    if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter1 == 0) size1 = sizeForCopy;
                        else if (counter1 == 1) size2 = sizeForCopy;
                        else if (counter1 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter1 == 3) size1 = sizeForCopy;
                        else if (counter1 == 4) size2 = sizeForCopy;
                        else if (counter1 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                if (stat(expandDataPath.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                    errorNoHold = 1000;
                    throw errorCheckThrow;
                }
                
                if (checkFlag == 1){
                    if (expandLineFluorescentStatus == 0){
                        errorNoHold = 1;
                        expandLineFluorescent = new int [sizeForCopy+50];
                        expandLineFluorescentCount = 0;
                        expandLineFluorescentLimit = (int)sizeForCopy+50;
                        expandLineFluorescentStatus = 1;
                        expandLineFluorescentSizeHold = (int)sizeForCopy+50;
                    }
                    else if (expandLineFluorescentStatus == 1 && expandLineFluorescentSizeHold < sizeForCopy){
                        delete [] expandLineFluorescent;
                        
                        errorNoHold = 2;
                        expandLineFluorescent = new int [sizeForCopy+50];
                        expandLineFluorescentCount = 0;
                        expandLineFluorescentLimit = (int)sizeForCopy+50;
                        expandLineFluorescentSizeHold = (int)sizeForCopy+50;
                    }
                    else expandLineFluorescentCount = 0;
                    
                    fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [8];
                        
                        errorNoHold = 3;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                    errorNoHold = 1002;
                                    throw errorCheckThrow;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1 X position
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y position
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                else{
                                    
                                    expandLineFluorescent [expandLineFluorescentCount] = finData [1], expandLineFluorescentCount++;
                                    expandLineFluorescent [expandLineFluorescentCount] = finData [3], expandLineFluorescentCount++;
                                    expandLineFluorescent [expandLineFluorescentCount] = finData [6], expandLineFluorescentCount++;
                                    expandLineFluorescent [expandLineFluorescentCount] = finData [7], expandLineFluorescentCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                    }
                    else{
                        
                        errorNoHold = 1003;
                        throw errorCheckThrow;
                    }
                }
                else if (expandLineFluorescentStatus == 0){
                    errorNoHold = 4;
                    expandLineFluorescent = new int [500];
                    expandLineFluorescentCount = 0;
                    expandLineFluorescentLimit = 500;
                    expandLineFluorescentStatus = 1;
                    expandLineFluorescentSizeHold = 500;
                }
                else expandLineFluorescentCount = 0;
                
                //for (int counterA = 0; counterA < expandLineFluorescentCount/4; counterA++){
                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandLineFluorescent [counterA*4+counterB];
                //    cout<<" expandLineFluorescent "<<counterA<<endl;
                // }
                
                expandDataPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extensionString2+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
                
                sizeForCopy = 0;
                
                if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (expandLineFluorescentDataStatus == 0){
                        errorNoHold = 5;
                        expandLineFluorescentData = new int [sizeForCopy+50];
                        expandLineFluorescentDataCount = 0;
                        expandLineFluorescentDataStatus = 1;
                        expandLineFluorescentDataLimit = (int)sizeForCopy+50;
                        expandLineFluorescentDataSizeHold = (int)sizeForCopy+50;
                    }
                    else if (expandLineFluorescentDataStatus == 1 && expandLineFluorescentDataSizeHold < sizeForCopy){
                        delete [] expandLineFluorescentData;
                        
                        errorNoHold = 6;
                        expandLineFluorescentData = new int [sizeForCopy+50];
                        expandLineFluorescentDataCount = 0;
                        expandLineFluorescentDataLimit = (int)sizeForCopy+50;
                        expandLineFluorescentDataSizeHold = (int)sizeForCopy+50;
                    }
                    else expandLineFluorescentDataCount = 0;
                    
                    fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [8];
                        
                        errorNoHold = 7;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                errorNoHold = 1004;
                                throw errorCheckThrow;
                            }
                        }
                        
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pix
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                else{
                                    
                                    expandLineFluorescentData [expandLineFluorescentDataCount] = finData [2], expandLineFluorescentDataCount++;
                                    expandLineFluorescentData [expandLineFluorescentDataCount] = finData [3], expandLineFluorescentDataCount++;
                                    expandLineFluorescentData [expandLineFluorescentDataCount] = finData [4], expandLineFluorescentDataCount++;
                                    expandLineFluorescentData [expandLineFluorescentDataCount] = finData [7], expandLineFluorescentDataCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                    }
                    else{
                        
                        errorNoHold = 1005;
                        throw errorCheckThrow;
                    }
                }
                else if (expandLineFluorescentDataStatus == 0){
                    errorNoHold = 8;
                    expandLineFluorescentData = new int [150];
                    expandLineFluorescentDataCount = 0;
                    expandLineFluorescentDataStatus = 1;
                    expandLineFluorescentDataLimit = 150;
                    expandLineFluorescentDataSizeHold = 150;
                }
                else  expandLineFluorescentDataCount = 0;
                
                //for (int counterA = 0; counterA < expandLineFluorescentDataCount/4; counterA++){
                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandLineFluorescentData [counterA*4+counterB];
                //    cout<<" expandLineFluorescentData "<<counterA<<endl;
                //}
                
                if (fluorescentMapStatus1 == 0 && fluorescentEntryCount >= 1){
                    fluorescentMapStatus1 = 1;
                    
                    errorNoHold = 9;
                    fluorescentMap1 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 10;
                        fluorescentMap1 [counter1] = new int [imageDimension+1];
                    }
                    
                    fluorescentMapSizeHold = imageDimension;
                }
                else if (fluorescentMapStatus1 == 1 && fluorescentEntryCount >= 1){
                    if (fluorescentMapSizeHold < imageDimension){
                        for (int counter1 = 0; counter1 < fluorescentMapSizeHold+1; counter1++) delete [] fluorescentMap1 [counter1];
                        delete [] fluorescentMap1;
                        
                        errorNoHold = 11;
                        fluorescentMap1 = new int *[imageDimension+1];
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                            errorNoHold = 12;
                            fluorescentMap1 [counter1] = new int [imageDimension+1];
                        }
                        
                        fluorescentMapSizeHold = imageDimension;
                    }
                }
                
                if (fluorescentMapStatus2 == 0 && fluorescentEntryCount >= 2){
                    fluorescentMapStatus2 = 1;
                    
                    errorNoHold = 13;
                    fluorescentMap2 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 14;
                        fluorescentMap2 [counter1] = new int [imageDimension+1];
                    }
                }
                else if (fluorescentMapStatus2 == 1 && fluorescentEntryCount >= 2){
                    if (fluorescentMapSizeHold < imageDimension){
                        for (int counter1 = 0; counter1 < fluorescentMapSizeHold+1; counter1++) delete [] fluorescentMap2 [counter1];
                        delete [] fluorescentMap2;
                        
                        errorNoHold = 15;
                        fluorescentMap2 = new int *[imageDimension+1];
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                            errorNoHold = 16;
                            fluorescentMap2 [counter1] = new int [imageDimension+1];
                        }
                    }
                }
                
                if (fluorescentMapStatus3 == 0 && fluorescentEntryCount >= 3){
                    fluorescentMapStatus3 = 1;
                    
                    errorNoHold = 17;
                    fluorescentMap3 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 18;
                        fluorescentMap3 [counter1] = new int [imageDimension+1];
                    }
                }
                else if (fluorescentMapStatus3 == 1 && fluorescentEntryCount >= 3){
                    if (fluorescentMapSizeHold < imageDimension){
                        for (int counter1 = 0; counter1 < fluorescentMapSizeHold+1; counter1++) delete [] fluorescentMap3 [counter1];
                        delete [] fluorescentMap3;
                        
                        errorNoHold = 19;
                        fluorescentMap3 = new int *[imageDimension+1];
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                            errorNoHold = 20;
                            fluorescentMap3 [counter1] = new int [imageDimension+1];
                        }
                        
                        fluorescentMapSizeHold = imageDimension;
                    }
                }
                
                if (fluorescentMapStatus4 == 0 && fluorescentEntryCount >= 4){
                    fluorescentMapStatus4 = 1;
                    
                    errorNoHold = 21;
                    fluorescentMap4 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 22;
                        fluorescentMap4 [counter1] = new int [imageDimension+1];
                    }
                }
                else if (fluorescentMapStatus4 == 1 && fluorescentEntryCount >= 4){
                    if (fluorescentMapSizeHold < imageDimension){
                        for (int counter1 = 0; counter1 < fluorescentMapSizeHold+1; counter1++) delete [] fluorescentMap4 [counter1];
                        delete [] fluorescentMap4;
                        
                        errorNoHold = 23;
                        fluorescentMap4 = new int *[imageDimension+1];
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                            errorNoHold = 24;
                            fluorescentMap4 [counter1] = new int [imageDimension+1];
                        }
                        
                        fluorescentMapSizeHold = imageDimension;
                    }
                }
                
                if (fluorescentMapStatus5 == 0 && fluorescentEntryCount >= 5){
                    fluorescentMapStatus5 = 1;
                    
                    errorNoHold = 25;
                    fluorescentMap5 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 26;
                        fluorescentMap5 [counter1] = new int [imageDimension+1];
                    }
                }
                else if (fluorescentMapStatus5 == 1 && fluorescentEntryCount >= 5){
                    if (fluorescentMapSizeHold < imageDimension){
                        for (int counter1 = 0; counter1 < fluorescentMapSizeHold+1; counter1++) delete [] fluorescentMap5 [counter1];
                        delete [] fluorescentMap5;
                        
                        errorNoHold = 27;
                        fluorescentMap5 = new int *[imageDimension+1];
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                            errorNoHold = 28;
                            fluorescentMap5 [counter1] = new int [imageDimension+1];
                        }
                        
                        fluorescentMapSizeHold = imageDimension;
                    }
                }
                
                if (fluorescentMapStatus6 == 0 && fluorescentEntryCount >= 6){
                    fluorescentMapStatus6 = 1;
                    
                    errorNoHold = 29;
                    fluorescentMap6 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 30;
                        fluorescentMap6 [counter1] = new int [imageDimension+1];
                    }
                }
                else if (fluorescentMapStatus6 == 1 && fluorescentEntryCount >= 6){
                    if (fluorescentMapSizeHold < imageDimension){
                        for (int counter1 = 0; counter1 < fluorescentMapSizeHold+1; counter1++) delete [] fluorescentMap6 [counter1];
                        delete [] fluorescentMap6;
                        
                        errorNoHold = 31;
                        fluorescentMap6 = new int *[imageDimension+1];
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                            errorNoHold = 32;
                            fluorescentMap6 [counter1] = new int [imageDimension+1];
                        }
                        
                        fluorescentMapSizeHold = imageDimension;
                    }
                }
                
                if (fluorescentEntryCount >= 1){
                    extension2 = to_string(fluorescentNo1);
                    
                    string fluorescentNewPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName1+".tif";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath1.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    if (stat(fluorescentNewPath1.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                        errorNoHold = 1006;
                        throw errorCheckThrow;
                    }
                    
                    if (checkFlag == 1){
                        fin.open(fluorescentNewPath1.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int imageWidthEntry = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            int imageDimensionReadCount = 0;
                            
                            unsigned long headPosition = 0;
                            
                            errorNoHold = 33;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath1.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                imageDimensionReadCount = 0;
                                imageWidthEntry = 0;
                                
                                if (tifImageColorGray == 0){
                                    for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                        fluorescentMap1 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                                else if (tifImageColorGray == 1){
                                    for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                        value0 = uploadTemp [counter3];
                                        value1 = uploadTemp [counter3+1];
                                        value2 = uploadTemp [counter3+2];
                                        
                                        fluorescentMap1 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        fluorescentNewPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName1+".bmp";
                        
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath1.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            errorNoHold = 34;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath1.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                int imageDimensionReadCount = 0;
                                
                                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                        fluorescentMap1 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            else{
                                
                                errorNoHold = 1007;
                                throw errorCheckThrow;
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < 500; counterA++){
                    //	for (int counterB = 0; counterB < 500; counterB++) cout<<" "<<fluorescentMap1 [counterA][counterB];
                    //	cout<<" fluorescentMap1 "<<counterA<<endl;
                    //}
                }
                
                if (fluorescentEntryCount >= 2){
                    extension2 = to_string(fluorescentNo2);
                    
                    string fluorescentNewPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName2+".tif";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath2.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    if (stat(fluorescentNewPath2.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                        errorNoHold = 1008;
                        throw errorCheckThrow;
                    }
                    
                    if (checkFlag == 1){
                        fin.open(fluorescentNewPath2.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int imageWidthEntry = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            int imageDimensionReadCount = 0;
                            
                            unsigned long headPosition = 0;
                            
                            errorNoHold = 35;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                imageDimensionReadCount = 0;
                                imageWidthEntry = 0;
                                
                                if (tifImageColorGray == 0){
                                    for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                        fluorescentMap2 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                                else if (tifImageColorGray == 1){
                                    for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                        value0 = uploadTemp [counter3];
                                        value1 = uploadTemp [counter3+1];
                                        value2 = uploadTemp [counter3+2];
                                        
                                        fluorescentMap2 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        fluorescentNewPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName2+".bmp";
                        
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath2.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            errorNoHold = 36;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                int imageDimensionReadCount = 0;
                                
                                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                        fluorescentMap2 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            else{
                                
                                errorNoHold = 1009;
                                throw errorCheckThrow;
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                }
                
                if (fluorescentEntryCount >= 3){
                    extension2 = to_string(fluorescentNo3);
                    
                    string fluorescentNewPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName3+".tif";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath3.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    if (stat(fluorescentNewPath3.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                        errorNoHold = 1010;
                        throw errorCheckThrow;
                    }
                    
                    if (checkFlag == 1){
                        fin.open(fluorescentNewPath3.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int imageWidthEntry = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            int imageDimensionReadCount = 0;
                            
                            unsigned long headPosition = 0;
                            
                            errorNoHold = 37;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath3.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                imageDimensionReadCount = 0;
                                imageWidthEntry = 0;
                                
                                if (tifImageColorGray == 0){
                                    for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                        fluorescentMap3 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                                else if (tifImageColorGray == 1){
                                    for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                        value0 = uploadTemp [counter3];
                                        value1 = uploadTemp [counter3+1];
                                        value2 = uploadTemp [counter3+2];
                                        
                                        fluorescentMap3 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        fluorescentNewPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName3+".bmp";
                        
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath3.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            errorNoHold = 38;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath3.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                int imageDimensionReadCount = 0;
                                
                                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                        fluorescentMap3 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            else{
                                
                                errorNoHold = 1011;
                                throw errorCheckThrow;
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                }
                
                if (fluorescentEntryCount >= 4){
                    extension2 = to_string(fluorescentNo4);
                    
                    string fluorescentNewPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName4+".tif";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath4.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    if (stat(fluorescentNewPath4.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                        errorNoHold = 1012;
                        throw errorCheckThrow;
                    }
                    
                    if (checkFlag == 1){
                        fin.open(fluorescentNewPath4.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int imageWidthEntry = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            int imageDimensionReadCount = 0;
                            
                            unsigned long headPosition = 0;
                            
                            errorNoHold = 39;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath4.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                imageDimensionReadCount = 0;
                                imageWidthEntry = 0;
                                
                                if (tifImageColorGray == 0){
                                    for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                        fluorescentMap4 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                                else if (tifImageColorGray == 1){
                                    for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                        value0 = uploadTemp [counter3];
                                        value1 = uploadTemp [counter3+1];
                                        value2 = uploadTemp [counter3+2];
                                        
                                        fluorescentMap4 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        fluorescentNewPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName4+".bmp";
                        
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath4.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            errorNoHold = 40;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath4.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                int imageDimensionReadCount = 0;
                                
                                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                        fluorescentMap4 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            else{
                                
                                errorNoHold = 1013;
                                throw errorCheckThrow;
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                }
                
                if (fluorescentEntryCount >= 5){
                    extension2 = to_string(fluorescentNo5);
                    
                    string fluorescentNewPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName5+".tif";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath5.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    if (stat(fluorescentNewPath5.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                        errorNoHold = 1014;
                        throw errorCheckThrow;
                    }
                    
                    if (checkFlag == 1){
                        fin.open(fluorescentNewPath5.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int imageWidthEntry = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            int imageDimensionReadCount = 0;
                            
                            unsigned long headPosition = 0;
                            
                            errorNoHold = 41;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath5.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                imageDimensionReadCount = 0;
                                imageWidthEntry = 0;
                                
                                if (tifImageColorGray == 0){
                                    for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                        fluorescentMap5 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                                else if (tifImageColorGray == 1){
                                    for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                        value0 = uploadTemp [counter3];
                                        value1 = uploadTemp [counter3+1];
                                        value2 = uploadTemp [counter3+2];
                                        
                                        fluorescentMap5 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        fluorescentNewPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName5+".bmp";
                        
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath5.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            errorNoHold = 42;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath5.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                int imageDimensionReadCount = 0;
                                
                                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                        fluorescentMap5 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            else{
                                
                                errorNoHold = 1015;
                                throw errorCheckThrow;
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                }
                
                if (fluorescentEntryCount >= 6){
                    extension2 = to_string(fluorescentNo6);
                    
                    string fluorescentNewPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName6+".tif";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath6.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    if (stat(fluorescentNewPath6.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                        errorNoHold = 1016;
                        throw errorCheckThrow;
                    }
                    
                    if (checkFlag == 1){
                        fin.open(fluorescentNewPath6.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int imageWidthEntry = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            int imageDimensionReadCount = 0;
                            
                            unsigned long headPosition = 0;
                            
                            errorNoHold = 43;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath6.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                imageDimensionReadCount = 0;
                                imageWidthEntry = 0;
                                
                                if (tifImageColorGray == 0){
                                    for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                        fluorescentMap6 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                                else if (tifImageColorGray == 1){
                                    for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                        value0 = uploadTemp [counter3];
                                        value1 = uploadTemp [counter3+1];
                                        value2 = uploadTemp [counter3+2];
                                        
                                        fluorescentMap6 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        fluorescentNewPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName6+".bmp";
                        
                        if (stat(fluorescentNewPath6.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            errorNoHold = 44;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath6.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                int imageDimensionReadCount = 0;
                                
                                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                        fluorescentMap6 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            else{
                                
                                errorNoHold = 1017;
                                throw errorCheckThrow;
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                }
                
                [self fluorescentProcess];
                if (errorNoHold != 0){
                    errorNoHold = errorNoHold+2000;
                    throw errorCheckThrow;
                }
            }
            
            trackHoldFlag = 0;
            
            //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
            //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
            //}
            
            string cellLineageExtract = cellLineageNoHold.substr(1);
            string cellNumberExtract = cellNoHold.substr(1);
            int cellLineageTempInt = atoi(cellLineageExtract.c_str());
            int cellNumberTempInt = atoi(cellNumberExtract.c_str());
            
            //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
            //    cout<<" arrayLineageData "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < lineageStartEndCount/8; counterA++){
            // 	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageStartEnd [counterA*8 +counterB];
            //	cout<<" arrayLineageStartEnd "<<counterA<<endl;
            //}
            
            eventSequenceCount = 0;
            
            int breakFlag = 0;
            
            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                if (imageNumberInt >= arrayLineageStartEnd [counter1*8+5] && imageNumberInt <= arrayLineageStartEnd [counter1*8+7] && cellLineageTempInt == arrayLineageStartEnd [counter1*8] && cellNumberTempInt == arrayLineageStartEnd [counter1*8+1]){
                    
                    for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                        if (arrayLineageData [counter2*8+2] == imageNumberInt){
                            arrayEventSequence [0] = arrayLineageData [counter2*8+2], eventSequenceCount++;
                            arrayEventSequence [1] = arrayLineageData [counter2*8+3], eventSequenceCount++;
                            arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++;
                            arrayEventSequence [eventSequenceCount] = cellNumberTempInt, eventSequenceCount++;
                            
                            breakFlag = 1;
                            break;
                        }
                    }
                }
                
                if (breakFlag == 1){
                    break;
                }
            }
            
            //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
            //    cout<<" arrayEventSequence "<<counterA<<endl;
            //}
            
            int targetConnect = 0;
            
            for (int counter1 = 0; counter1 < xyPositionCenterPreviousCount/6; counter1++){
                if (arrayXYPositionCenterPrevious [counter1*6+5] == 1) targetConnect = arrayXYPositionCenterPrevious [counter1*6+4];
            }
            
            errorNoHold = 45;
            arrayReferenceLine = new int [cellTrackingPreviousCount+50];
            referenceLineCount = 0;
            referenceLineLimit = cellTrackingPreviousCount+50;
            
            for (int counter1 = 0; counter1 < cellTrackingPreviousCount/6; counter1++){
                if (arrayCellTrackingPrevious [counter1*6+3] == targetConnect){
                    if (referenceLineCount+2 > referenceLineLimit){
                        [self referenceLineCountUpDate];
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                    }
                    
                    arrayReferenceLine [referenceLineCount] = arrayCellTrackingPrevious [counter1*6], referenceLineCount++;
                    arrayReferenceLine [referenceLineCount] = arrayCellTrackingPrevious [counter1*6+1], referenceLineCount++;
                }
            }
            
            //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
            //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
            //}
            
            int cutOffAdjust = -1;
            
            overlapCheck = [[OverlapCheck alloc] init];
            [overlapCheck overlapCheckMain:cutOffAdjust];
            
            do{
            } while(subCompletionFlag == 1);
            
            if (errorNoHold != 0){
                errorNoHold = errorNoHold+2000;
                throw errorCheckThrow;
            }
            
            //cout<<trackHoldFlag<<" "<<roundStatus<<" AF_overlap"<<endl;
            
            //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
            //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
            //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //    cout<<" arrayTimeSelected "<<counterA+1<<endl;
            //}
            
            if (trackHoldFlag == 0){
                gravityCenterXHold1 = 0;
                gravityCenterYHold1 = 0;
                gravityAverageHold1 = 0;
                gravityCellNo1 = 0;
                
                sleepingPosition = 24;
                
                cutOffAdjust = -1;
                int processPreviousType = 0;
                averageHold = 0;
                
                areaCut = [[AreaCut alloc] init];
                [areaCut circleCut:targetCellStatus:cutOffAdjust:processPreviousType]; //-------Return Results, No of Previous Connect of Target-------
                
                do{
                } while(subCompletionFlag == 1);
                
                if (errorNoHold != 0){
                    errorNoHold = errorNoHold+2000;
                    throw errorCheckThrow;
                }
                
                if (trackHoldFlag == 3000){
                    trackHoldFlag = 0;
                    processPreviousType = 1;
                    averageHold = 0;
                    
                    cutOffAdjust = (int)(averageHold*0.5);
                    
                    areaCut = [[AreaCut alloc] init];
                    [areaCut circleCut:targetCellStatus:cutOffAdjust:processPreviousType]; //-------Return Results, No of Previous Connect of Target-------
                    
                    do{
                    } while(subCompletionFlag == 1);
                    
                    if (errorNoHold != 0){
                        errorNoHold = errorNoHold+2000;
                        throw errorCheckThrow;
                    }
                    
                    if (trackHoldFlag == 3000){
                        trackHoldFlag = 0;
                        processPreviousType = 1;
                        cutOffAdjust = (int)(averageHold*0.1);
                        
                        areaCut = [[AreaCut alloc] init];
                        [areaCut circleCut:targetCellStatus:cutOffAdjust:processPreviousType]; //-------Return Results, No of Previous Connect of Target-------
                        
                        do{
                        } while(subCompletionFlag == 1);
                        
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                    }
                }
            }
            
            delete [] arrayReferenceLine;
            
            if (trackHoldFlag == 0){
                int processType = 1;
                trackingDataSave = [[TrackingDataSave alloc] init];
                [trackingDataSave trackingDataSaveTemp:processType];
                
                do{
                } while(subCompletionFlag == 1);
                
                if (errorNoHold != 0){
                    errorNoHold = errorNoHold+2000;
                    throw errorCheckThrow;
                }
                
                returnMessage = "IM";
                returnMessageTime = to_string(imageNumberInt);
                returnMessageExt = "0";
                
                firstCommunication = 4;
            }
            
            if (trackHoldFlag == 3000){
                returnMessage = "TM";
                returnMessageTime = to_string(imageNumberInt);
                returnMessageExt = "0";
                
                firstCommunication = 4;
            }
            
            errorNoHold = 0;
        }
        catch (int errorCheckThrow){
            if (errorNoHold >= 1000 && errorNoHold < 2000){
                string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
                mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                time_t rawtime;
                struct tm * timeinfo;
                time (&rawtime);
                timeinfo = localtime ( &rawtime );
                
                int tsec = timeinfo -> tm_sec;
                int tmin = timeinfo -> tm_min;
                int thour = timeinfo -> tm_hour;
                int tday = timeinfo -> tm_mday;
                int tmon = timeinfo -> tm_mon;
                
                string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
                
                errorPath = errorPath+"/Cell_CarvingImageProcessingEnd01 "+dateTime;
                
                ofstream oin2;
                oin2.open(errorPath.c_str(), ios::out);
                oin2<<"ImageProcessingEnd"<<endl;
                oin2<<errorNoHold<<endl;
                oin2<<analysisImageName<<endl;
                oin2<<analysisID<<endl;
                oin2<<treatmentNameHold<<endl;
                oin2<<cellLineageNoHold<<endl;
                oin2<<cellNoHold<<endl;
                oin2<<dateTime<<endl;
                
                if (errorNoHold == 1000) oin2<<"ExpandLine reading error"<<endl;
                else if (errorNoHold == 1002) oin2<<"ExpandLine uploading error"<<endl;
                else if (errorNoHold == 1003) oin2<<"ExpandLine open-error"<<endl;
                else if (errorNoHold == 1004) oin2<<"ExpandArea uploading error"<<endl;
                else if (errorNoHold == 1005) oin2<<"ExpandArea open-error"<<endl;
                else if (errorNoHold >= 1006 && errorNoHold >= 1017) oin2<<"Fluorescent image (tif/bmp) open-error"<<endl;
                oin2.close();
            }
            
            emergencyExit = 1;
            firstCommunication = 20;
        }
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingImageProcessingEnd02 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"ImageProcessingEnd"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        emergencyExit = 1;
        firstCommunication = 20;
    }
}

-(void)fluorescentProcess{
    try{
        
        errorNoHold = 0;
        
        ifstream fin;
        
        string extension = to_string(imageNumberInt);
        
        if (extension.length() == 1) extension = "000"+extension;
        else if (extension.length() == 2) extension = "00"+extension;
        else if (extension.length() == 3) extension = "0"+extension;
        
        string extension2 = to_string(fluorescentNo1);
        
        string fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+".tif";
        
        fin.open(fluorescentPath1.c_str(), ios::in);
        
        if (!fin.is_open()){
            fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+".bmp";
        }
        else fin.close();
        
        struct stat sizeOfFile;
        
        if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0){
            int matchFind = 0;
            
            for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                if (arrayFluorescentCutOff [counter1*7] == imageNumberInt){
                    fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                    fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                    fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                    fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                    fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                    fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                    matchFind = 1;
                    break;
                }
            }
            
            if (matchFind == 0){
                string cutOffPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
                
                if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                    int nearestCount = 0;
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                        if (arrayFluorescentCutOff [counter1*7] < imageNumberInt){
                            if (nearestCount < arrayFluorescentCutOff [counter1*7]){
                                nearestCount = arrayFluorescentCutOff [counter1*7];
                                fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                                fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                                fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                            }
                        }
                    }
                    
                    if (fluorescentCutOffStatus == 0){
                        errorNoHold = 46;
                        arrayFluorescentCutOff = new int [imageEndHold*7];
                        fluorescentCutOffCount = 0;
                        fluorescentCutOffStatus = 1;
                    }
                    
                    if (nearestCount != 0){
                        arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberInt, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
                    }
                    else{
                        
                        arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberInt, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    }
                    
                    ofstream oin;
                    oin.open(cutOffPath.c_str(), ios::out);
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                    oin<<"End"<<endl;
                    oin.close();
                }
                else{
                    
                    fluorescentCutOff1 = 150;
                    fluorescentCutOff2 = 150;
                    fluorescentCutOff3 = 150;
                    fluorescentCutOff4 = 150;
                    fluorescentCutOff5 = 150;
                    fluorescentCutOff6 = 150;
                    
                    if (fluorescentCutOffStatus == 0){
                        errorNoHold = 47;
                        arrayFluorescentCutOff = new int [imageEndHold*4];
                        fluorescentCutOffCount = 0;
                        fluorescentCutOffStatus = 1;
                    }
                    
                    arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberInt, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    
                    ofstream oin;
                    oin.open(cutOffPath.c_str(), ios::out);
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                    oin<<"End"<<endl;
                    oin.close();
                }
            }
        }
        
        errorNoHold = 0;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingImageProcessingEnd03 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"ImageProcessingEnd-fluorescentProcess"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
    }
}

-(void)referenceLineCountUpDate{
    try{
        
        errorNoHold = 0;
        
        int *arrayUpDate = new int [referenceLineCount+10];
        
        for (int counter1 = 0; counter1 < referenceLineCount; counter1++) arrayUpDate [counter1] = arrayReferenceLine [counter1];
        
        delete [] arrayReferenceLine;
        arrayReferenceLine = new int [referenceLineLimit+5000];
        referenceLineLimit = referenceLineLimit+5000;
        
        for (int counter1 = 0; counter1 < referenceLineCount; counter1++) arrayReferenceLine [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingImageProcessingEnd04 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"ImageProcessingEnd-referenceLineCountUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToImageProcessingEnd object:nil];
}

@end
