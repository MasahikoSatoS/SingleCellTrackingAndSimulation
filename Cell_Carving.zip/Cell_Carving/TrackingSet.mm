//
// TrackingSet.mm
// Cell_Carving
//
// Created by Masahiko Sato on 12/12/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "TrackingSet.h"

@implementation TrackingSet

-(int)trackingSetMain:(int)processTime :(int)imageNo{
    int upLoadCheck = 0;
    
    try{
        try{
            
            errorNoHold = 0;
            int errorCheckThrow = 0;
            sleepingPosition = 9;
            subCompletionFlag = 1;
            
            struct stat sizeOfFile;
            
            if (processTime == 1){
                ifstream fin;
                string extension;
                
                if (imageNo == 0) extension = to_string(imageNumberInt);
                else extension = to_string(imageNo);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                string connectDataPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+extension+"_"+analysisImageName+"_"+treatmentNameHold+"_MasterData";
                string connectDataRevPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                
                long sizeForCopy = 0;
                long sizeForCopy2 = 0;
                long size1 = 0;
                long size2 = 0;
                int checkFlag = 0;
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    sizeForCopy = 0;
                    
                    if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    else if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter1 == 0) size1 = sizeForCopy;
                        else if (counter1 == 1) size2 = sizeForCopy;
                        else if (counter1 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter1 == 3) size1 = sizeForCopy;
                        else if (counter1 == 4) size2 = sizeForCopy;
                        else if (counter1 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                if (checkFlag == 0){
                    errorNoHold = 1000;
                    throw errorCheckThrow;
                }
                
                positionReviseCount = 0;
                gravityCenterRevCount = 0;
                associatedDataCount = 0;
                
                if (checkFlag == 1){
                    if (positionReviseStatus == 0){
                        errorNoHold = 1;
                        arrayPositionRevise = new int [sizeForCopy+50];
                        positionReviseCount = 0;
                        positionReviseStatus = 1;
                        positionReviseLimit = (int)sizeForCopy+50;
                        positionReviseSizeHold = (int)sizeForCopy+50;
                    }
                    else if (positionReviseStatus == 1 && positionReviseSizeHold < sizeForCopy){
                        delete [] arrayPositionRevise;
                        
                        errorNoHold = 2;
                        arrayPositionRevise = new int [sizeForCopy+50];
                        positionReviseCount = 0;
                        positionReviseLimit = (int)sizeForCopy+50;
                        positionReviseSizeHold = (int)sizeForCopy+50;
                    }
                    else positionReviseCount = 0;
                    
                    sizeForCopy2 = (long)(sizeForCopy*(double)0.1);
                    
                    if (gravityCenterRevStatus == 0){
                        errorNoHold = 3;
                        arrayGravityCenterRev = new int [sizeForCopy2+50];
                        gravityCenterRevCount = 0;
                        gravityCenterRevStatus = 1;
                        gravityCenterRevLimit = (int)sizeForCopy2+50;
                    }
                    else if (gravityCenterRevStatus == 1 && gravityCenterRevSizeHold < sizeForCopy2){
                        delete [] arrayGravityCenterRev;
                        
                        errorNoHold = 4;
                        arrayGravityCenterRev = new int [sizeForCopy2+50];
                        gravityCenterRevCount = 0;
                        gravityCenterRevLimit = (int)sizeForCopy2+50;
                        gravityCenterRevSizeHold = (int)sizeForCopy2+50;
                    }
                    else gravityCenterRevCount = 0;
                    
                    sizeForCopy2 = (long)(sizeForCopy*(double)0.1+50);
                    
                    if (associatedDataStatus == 0){
                        errorNoHold = 5;
                        arrayAssociatedData = new int [sizeForCopy2+50];
                        associatedDataCount = 0;
                        associatedDataStatus = 1;
                        associatedDataLimit = (int)sizeForCopy2+50;
                        associatedDataSizeHold = (int)sizeForCopy2+50;
                    }
                    else if (associatedDataStatus == 1 && associatedDataSizeHold < sizeForCopy2){
                        errorNoHold = 6;
                        arrayAssociatedData = new int [sizeForCopy2+50];
                        associatedDataCount = 0;
                        associatedDataLimit = (int)sizeForCopy2+50;
                        associatedDataSizeHold = (int)sizeForCopy2+50;
                    }
                    else associatedDataCount = 0;
                    
                    fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [17];
                        
                        errorNoHold = 7;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                    errorNoHold = 1001;
                                    throw errorCheckThrow;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        upLoadCheck++;
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--5
                                finData [13] = uploadTemp [readPosition], readPosition++; //--6
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++;
                                finData [16] = uploadTemp [readPosition], readPosition++; //--7
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                else{
                                    
                                    arrayPositionRevise [positionReviseCount] = finData [1], positionReviseCount++;
                                    arrayPositionRevise [positionReviseCount] = finData [3], positionReviseCount++;
                                    arrayPositionRevise [positionReviseCount] = finData [4], positionReviseCount++;
                                    arrayPositionRevise [positionReviseCount] = finData [7], positionReviseCount++;
                                    arrayPositionRevise [positionReviseCount] = finData [12], positionReviseCount++;
                                    arrayPositionRevise [positionReviseCount] = finData [13], positionReviseCount++;
                                    arrayPositionRevise [positionReviseCount] = finData [16], positionReviseCount++;
                                }
                            }
                            else if (stepCount == 1){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                finData [9] = finData [8]*256+finData [9];
                                
                                
                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                else{
                                    
                                    if (associatedDataCount+10 > associatedDataLimit){
                                        [self associatedDataUpDate];
                                        
                                        if (errorNoHold != 0){
                                            errorNoHold = errorNoHold+2000;
                                            throw errorCheckThrow;
                                        }
                                    }
                                    
                                    arrayAssociatedData [associatedDataCount] = finData [2], associatedDataCount++;
                                    arrayAssociatedData [associatedDataCount] = finData [3], associatedDataCount++;
                                    arrayAssociatedData [associatedDataCount] = finData [4], associatedDataCount++;
                                    arrayAssociatedData [associatedDataCount] = finData [7], associatedDataCount++;
                                    arrayAssociatedData [associatedDataCount] = finData [9], associatedDataCount++;
                                    arrayAssociatedData [associatedDataCount] = finData [10], associatedDataCount++;
                                }
                            }
                            else if (stepCount == 2){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                else{
                                    
                                    if (gravityCenterRevCount+10 > gravityCenterRevLimit){
                                        [self gravityCenterRevUpDate];
                                        
                                        if (errorNoHold != 0){
                                            errorNoHold = errorNoHold+2000;
                                            throw errorCheckThrow;
                                        }
                                    }
                                    
                                    arrayGravityCenterRev [gravityCenterRevCount] = finData [1], gravityCenterRevCount++;
                                    arrayGravityCenterRev [gravityCenterRevCount] = finData [3], gravityCenterRevCount++;
                                    arrayGravityCenterRev [gravityCenterRevCount] = finData [6], gravityCenterRevCount++;
                                    arrayGravityCenterRev [gravityCenterRevCount] = finData [7], gravityCenterRevCount++;
                                    arrayGravityCenterRev [gravityCenterRevCount] = finData [10], gravityCenterRevCount++;
                                    arrayGravityCenterRev [gravityCenterRevCount] = finData [11], gravityCenterRevCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                    }
                    else{
                        
                        fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            int finData [11];
                            
                            errorNoHold = 8;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 ){
                                        errorNoHold = 1002;
                                        throw errorCheckThrow;
                                    }
                                }
                            }
                            
                            fin.close();
                            
                            upLoadCheck++;
                            
                            unsigned long readPosition = 0;
                            int stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [4] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--3
                                    finData [8] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [9] = uploadTemp [readPosition], readPosition++;
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                    else{
                                        
                                        arrayPositionRevise [positionReviseCount] = finData [1], positionReviseCount++; //------X position------
                                        arrayPositionRevise [positionReviseCount] = finData [3], positionReviseCount++; //------Y position------
                                        arrayPositionRevise [positionReviseCount] = finData [4], positionReviseCount++; //------Value------
                                        arrayPositionRevise [positionReviseCount] = finData [7], positionReviseCount++; //------Connect No------
                                        arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //------Cell No------
                                        arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //------Status------
                                        arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //------Lineage no------
                                    }
                                }
                                else if (stepCount == 1){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++;
                                    finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                    finData [8] = uploadTemp [readPosition], readPosition++;
                                    finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                    finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                    
                                    finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                    finData [9] = finData [8]*256+finData [9];
                                    
                                    if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                    else{
                                        
                                        if (associatedDataCount+10 > associatedDataLimit){
                                            [self associatedDataUpDate];
                                            
                                            if (errorNoHold != 0){
                                                errorNoHold = errorNoHold+2000;
                                                throw errorCheckThrow;
                                            }
                                        }
                                        
                                        arrayAssociatedData [associatedDataCount] = finData [2], associatedDataCount++;
                                        arrayAssociatedData [associatedDataCount] = finData [3], associatedDataCount++;
                                        arrayAssociatedData [associatedDataCount] = finData [4], associatedDataCount++;
                                        arrayAssociatedData [associatedDataCount] = finData [7], associatedDataCount++;
                                        arrayAssociatedData [associatedDataCount] = finData [9], associatedDataCount++;
                                        arrayAssociatedData [associatedDataCount] = finData [10], associatedDataCount++;
                                    }
                                }
                                else if (stepCount == 2){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [4] = uploadTemp [readPosition], readPosition++;
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                    finData [8] = uploadTemp [readPosition], readPosition++;
                                    finData [9] = uploadTemp [readPosition], readPosition++;
                                    finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                    finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                    else{
                                        
                                        if (gravityCenterRevCount+10 > gravityCenterRevLimit){
                                            [self gravityCenterRevUpDate];
                                            
                                            if (errorNoHold != 0){
                                                errorNoHold = errorNoHold+2000;
                                                throw errorCheckThrow;
                                            }
                                        }
                                        
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [1], gravityCenterRevCount++;
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [3], gravityCenterRevCount++;
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [6], gravityCenterRevCount++;
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [7], gravityCenterRevCount++;
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [10], gravityCenterRevCount++;
                                        arrayGravityCenterRev [gravityCenterRevCount] = 0, gravityCenterRevCount++;
                                    }
                                }
                                
                            } while (stepCount != 3);
                            
                            delete [] uploadTemp;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
                //    cout<<" arrayPositionRevise "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < associatedDataCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayAssociatedData [counterA*6+counterB];
                //    cout<<" arrayAssociatedData "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
                //    cout<<" arrayGravityCenterRev "<<counterA<<endl;
                //}
                
                //------Masater Data Status UpLoad------
                string connectStatusDataPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
                
                sizeForCopy = 0;
                timeSelectedCount = 0;
                
                if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy < gravityCenterRevCount*2) sizeForCopy = gravityCenterRevCount*2;
                
                fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    if (timeSelectedStatus == 0){
                        errorNoHold = 9;
                        arrayTimeSelected = new int [sizeForCopy+50];
                        timeSelectedCount = 0;
                        timeSelectedStatus = 1;
                        timeSelectedLimit = (int)sizeForCopy+50;
                        timeSelectedSizeHold = (int)sizeForCopy+50;
                    }
                    else if (timeSelectedStatus == 1 && timeSelectedSizeHold < sizeForCopy){
                        delete [] arrayTimeSelected;
                        
                        errorNoHold = 10;
                        arrayTimeSelected = new int [sizeForCopy+50];
                        timeSelectedCount = 0;
                        timeSelectedLimit = (int)sizeForCopy+50;
                        timeSelectedSizeHold = (int)sizeForCopy+50;
                    }
                    else timeSelectedCount = 0;
                    
                    int finData [19];
                    
                    errorNoHold = 11;
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                            errorNoHold = 1003;
                            throw errorCheckThrow;
                        }
                    }
                    
                    fin.close();
                    
                    upLoadCheck++;
                    
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                            finData [7] = uploadTemp [readPosition], readPosition++;
                            finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                            finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                            finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                            finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                            finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                            finData [13] = uploadTemp [readPosition], readPosition++;
                            finData [14] = uploadTemp [readPosition], readPosition++;
                            finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                            finData [16] = uploadTemp [readPosition], readPosition++;
                            finData [17] = uploadTemp [readPosition], readPosition++;
                            finData [18] = uploadTemp [readPosition], readPosition++; //--11 Ling no
                            
                            finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            finData [8] = finData [7]*256+finData [8];
                            finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                            finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                            
                            if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                            else{
                                
                                arrayTimeSelected [timeSelectedCount] = finData [0], timeSelectedCount++; //------Selected, removed, eliminated status------
                                arrayTimeSelected [timeSelectedCount] = finData [3], timeSelectedCount++; //------When new line is created, enter line number which creates------
                                arrayTimeSelected [timeSelectedCount] = finData [6], timeSelectedCount++; //------PositionRevise Start------
                                arrayTimeSelected [timeSelectedCount] = finData [8], timeSelectedCount++; //------Cut line number------
                                arrayTimeSelected [timeSelectedCount] = finData [9], timeSelectedCount++; //------X Start------
                                arrayTimeSelected [timeSelectedCount] = finData [10], timeSelectedCount++; //------X End------
                                arrayTimeSelected [timeSelectedCount] = finData [11], timeSelectedCount++; //------Y Start------
                                arrayTimeSelected [timeSelectedCount] = finData [12], timeSelectedCount++; //------Y End------
                                arrayTimeSelected [timeSelectedCount] = finData [15], timeSelectedCount++; //------Connect------
                                arrayTimeSelected [timeSelectedCount] = finData [18], timeSelectedCount++; //------Lineage------
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    upLoadCheck++;
                    
                    if (timeSelectedStatus == 0){
                        errorNoHold = 12;
                        arrayTimeSelected = new int [gravityCenterRevCount*2+50];
                        timeSelectedCount = 0;
                        timeSelectedStatus = 1;
                        timeSelectedLimit = gravityCenterRevCount*2+50;
                        timeSelectedSizeHold = gravityCenterRevCount*2+50;
                    }
                    else if (timeSelectedStatus == 1 && timeSelectedSizeHold < gravityCenterRevCount){
                        delete [] arrayTimeSelected;
                        
                        errorNoHold = 13;
                        arrayTimeSelected = new int [gravityCenterRevCount*2+50];
                        timeSelectedCount = 0;
                        timeSelectedLimit = gravityCenterRevCount*2+50;
                        timeSelectedSizeHold = gravityCenterRevCount*2+50;
                    }
                    else timeSelectedCount = 0;
                    
                    for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){ //------Counter number corresponds to connect No------
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------Selected, removed, eliminated status------
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------When new line is created, enter line number which creates------
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------Top position of each connect------
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------Cut line number------
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------X Start------
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------X End------
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------Y Start------
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------Y End------
                        arrayTimeSelected [timeSelectedCount] = counter1+1, timeSelectedCount++; //------Connect------
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //------Lineage------
                    }
                    
                    int valueTemp = 0;
                    
                    for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                        if (arrayPositionRevise [counter1*7+3] != valueTemp){
                            valueTemp = arrayPositionRevise [counter1*7+3];
                            arrayTimeSelected [(valueTemp-1)*10+2] = counter1;
                            
                            if (arrayPositionRevise [counter1*7+5] == 0) arrayTimeSelected [(valueTemp-1)*10] = 0;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                //    cout<<" arrayTimeSelected "<<counterA<<endl;
                //}
                
                string connectRelationPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
                
                sizeForCopy = 0;
                connectLineageRelCount = 0;
                
                if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (connectLineageRelStatus == 0){
                        errorNoHold = 14;
                        arrayConnectLineageRel = new int [sizeForCopy+50];
                        connectLineageRelCount = 0;
                        connectLineageRelStatus = 1;
                        connectLineageRelLimit = (int)sizeForCopy+50;
                        connectLineageRelSizeHold = (int)sizeForCopy+50;
                    }
                    else if (connectLineageRelStatus == 1 && connectLineageRelSizeHold < sizeForCopy){
                        delete [] arrayConnectLineageRel;
                        
                        errorNoHold = 15;
                        arrayConnectLineageRel = new int [sizeForCopy+50];
                        connectLineageRelCount = 0;
                        connectLineageRelLimit = (int)sizeForCopy+50;
                        connectLineageRelSizeHold = (int)sizeForCopy+50;
                    }
                    else connectLineageRelCount = 0;
                    
                    fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [19];
                        
                        errorNoHold = 16;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                                errorNoHold = 1004;
                                throw errorCheckThrow;
                            }
                        }
                        
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1 Ling no
                                finData [3] = uploadTemp [readPosition], readPosition++;
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                                finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                                finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                                finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                                finData [7] = finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                else{
                                    
                                    arrayConnectLineageRel [connectLineageRelCount] = finData [2], connectLineageRelCount++;
                                    arrayConnectLineageRel [connectLineageRelCount] = finData [5], connectLineageRelCount++;
                                    arrayConnectLineageRel [connectLineageRelCount] = finData [7], connectLineageRelCount++;
                                    arrayConnectLineageRel [connectLineageRelCount] = finData [12], connectLineageRelCount++;
                                    arrayConnectLineageRel [connectLineageRelCount] = finData [13], connectLineageRelCount++;
                                    arrayConnectLineageRel [connectLineageRelCount] = finData [14], connectLineageRelCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                    }
                    else connectLineageRelCount = 0;
                }
                else if (connectLineageRelStatus == 0){
                    errorNoHold = 17;
                    arrayConnectLineageRel = new int [5000];
                    connectLineageRelCount = 0;
                    connectLineageRelStatus = 1;
                    connectLineageRelLimit = 5000;
                    connectLineageRelSizeHold = 5000;
                }
                else connectLineageRelCount = 0;
                
                if (eventSequenceStatus == 0){
                    errorNoHold = 18;
                    arrayEventSequence = new int [5000];
                    eventSequenceCount = 0;
                    eventSequenceLimit = 5000;
                    eventSequenceStatus = 1;
                }
                
                //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
                //    cout<<" arrayConnectLineageRel "<<counterA<<endl;
                //}
                
                string mapPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+extension+"_"+analysisImageName+"_"+treatmentNameHold+"_Map";
                string revisedMapPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_RevisedMap";
                
                if (mapLoadingStatusPrev == 0){
                    errorNoHold = 19;
                    revisedMap = new int *[imageDimension+1];
                    errorNoHold = 20;
                    revisedWorkingMap = new int *[imageDimension+1];
                    
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 21;
                        revisedMap [counter1] = new int [imageDimension+1];
                        errorNoHold = 22;
                        revisedWorkingMap [counter1] = new int [imageDimension+1];
                    }
                    
                    mapLoadingStatusPrev = 1;
                    revisedMapSizeHold = imageDimension;
                }
                else if (mapLoadingStatusPrev == 1 && revisedMapSizeHold < imageDimension){
                    for (int counter1 = 0; counter1 < revisedMapSizeHold+1; counter1++){
                        delete [] revisedMap [counter1];
                        delete [] revisedWorkingMap [counter1];
                    }
                    
                    delete [] revisedMap;
                    delete [] revisedWorkingMap;
                    
                    errorNoHold = 23;
                    revisedMap = new int *[imageDimension+1];
                    errorNoHold = 24;
                    revisedWorkingMap = new int *[imageDimension+1];
                    
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 25;
                        revisedMap [counter1] = new int [imageDimension+1];
                        errorNoHold = 26;
                        revisedWorkingMap [counter1] = new int [imageDimension+1];
                    }
                    
                    revisedMapSizeHold = imageDimension;
                }
                
                int readBit [4];
                int yDimensionCount;
                int xDimensionCount;
                int pixelData;
                
                long sizeTotal = (long)(imageDimension*imageDimension*4);
                
                errorNoHold = 27;
                uint8_t *upload2 = new uint8_t [sizeTotal+50];
                
                //---------Revised Map----------
                fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    fin.read((char*)upload2, sizeTotal+1);
                    fin.close();
                    
                    upLoadCheck++;
                    
                    yDimensionCount = 0;
                    xDimensionCount = 0;
                    
                    for (int counter1 = 0; counter1 < sizeTotal; counter1 = counter1+4){
                        readBit [0] = upload2[counter1];
                        readBit [1] = upload2[counter1+1];
                        readBit [2] = upload2[counter1+2];
                        readBit [3] = upload2[counter1+3];
                        
                        pixelData = readBit [0]*65536+readBit [1]*256+readBit [2];
                        
                        for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                            revisedMap [yDimensionCount][xDimensionCount] = pixelData;
                            revisedWorkingMap [yDimensionCount][xDimensionCount] = pixelData, xDimensionCount++;
                        }
                        
                        if (xDimensionCount == imageDimension){
                            xDimensionCount = 0;
                            yDimensionCount++;
                            
                            if (yDimensionCount == imageDimension){
                                break;
                            }
                        }
                    }
                }
                else{
                    
                    fin.open(mapPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)upload2, sizeTotal+1);
                        fin.close();
                        
                        upLoadCheck++;
                        
                        yDimensionCount = 0;
                        xDimensionCount = 0;
                        
                        for (int counter1 = 0; counter1 < sizeTotal; counter1 = counter1+4){
                            readBit [0] = upload2[counter1];
                            readBit [1] = upload2[counter1+1];
                            readBit [2] = upload2[counter1+2];
                            readBit [3] = upload2[counter1+3];
                            
                            pixelData = readBit [0]*65536+readBit [1]*256+readBit [2];
                            
                            for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                                revisedMap [yDimensionCount][xDimensionCount] = pixelData;
                                revisedWorkingMap [yDimensionCount][xDimensionCount] = pixelData, xDimensionCount++;
                            }
                            
                            if (xDimensionCount == imageDimension){
                                xDimensionCount = 0;
                                yDimensionCount++;
                                
                                if (yDimensionCount == imageDimension){
                                    break;
                                }
                            }
                        }
                    }
                    else{
                        
                        errorNoHold = 1005;
                        throw errorCheckThrow;
                    }
                }
                
                //for (int counterA = 0; counterA < 200; counterA++){
                //    for (int counterB = 0; counterB < 200; counterB++) cout<<" "<<revisedMap [counterA][counterB];
                //    cout<<" revisedMap "<<counterA<<endl;
                //}
                
                delete [] upload2;
            }
            
            //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
            //   for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
            //   cout<<" arrayConnectLineageRel "<<counterA<<endl;
            //}
            
            if (positionReviseCount == 0 || associatedDataCount == 0 || gravityCenterRevCount == 0 || timeSelectedCount == 0 || connectLineageRelCount == 0 || associatedDataCount/6 != timeSelectedCount/10 || gravityCenterRevCount/6 != timeSelectedCount/10){
                errorNoHold = 1006;
                throw errorCheckThrow;
            }
            else{
                
                string cellLineageExtract = cellLineageNoHold.substr(1);
                string cellNoExtract = cellNoHold.substr(1);
                int lineageAmendTemp = atoi(cellLineageExtract.c_str());
                int cellAmendTemp = atoi(cellNoExtract.c_str());
                
                //cout<<lineageAmendTemp<<" "<<cellAmendTemp<<" LineageNo"<<endl;
                
                targetConnectInitial = 0;
                
                for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                    if (arrayConnectLineageRel [counter1*6] == lineageAmendTemp && arrayConnectLineageRel [counter1*6+3] == cellAmendTemp){
                        targetConnectInitial = arrayConnectLineageRel [counter1*6+1];
                        break;
                    }
                }
                
                for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                    if (arrayGravityCenterRev [counter1*6+4] == targetConnectInitial){
                        xGravityCenter = arrayGravityCenterRev [counter1*6];
                        yGravityCenter = arrayGravityCenterRev [counter1*6+1];
                        break;
                    }
                }
                
                if (processTime == 1 || processTime == 2){
                    if (sectionMapLoadingStatusPrev == 0){
                        sectionMapLoadingStatusPrev = 1;
                        cellTrackingPreviousMapSizeHold = trackAreaSize;
                        
                        errorNoHold = 28;
                        arrayCellTrackingPreviousMap = new int *[trackAreaSize+4];
                        
                        for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++){
                            errorNoHold = 29;
                            arrayCellTrackingPreviousMap [counter1] = new int [trackAreaSize+4];
                        }
                    }
                    else if (sectionMapLoadingStatusPrev == 1 && 300 < cellTrackingPreviousMapSizeHold && 300 > trackAreaSize){
                        for (int counter1 = 0; counter1 < cellTrackingPreviousMapSizeHold+4; counter1++){
                            delete [] arrayCellTrackingPreviousMap [counter1];
                        }
                        
                        delete [] arrayCellTrackingPreviousMap;
                        
                        cellTrackingPreviousMapSizeHold = trackAreaSize;
                        
                        errorNoHold = 30;
                        arrayCellTrackingPreviousMap = new int *[trackAreaSize+4];
                        
                        for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++){
                            errorNoHold = 31;
                            arrayCellTrackingPreviousMap [counter1] = new int [trackAreaSize+4];
                        }
                    }
                    else if (sectionMapLoadingStatusPrev == 1 && cellTrackingPreviousMapSizeHold < trackAreaSize){
                        for (int counter1 = 0; counter1 < cellTrackingPreviousMapSizeHold+4; counter1++){
                            delete [] arrayCellTrackingPreviousMap [counter1];
                        }
                        
                        delete [] arrayCellTrackingPreviousMap;
                        
                        cellTrackingPreviousMapSizeHold = trackAreaSize;
                        
                        errorNoHold = 32;
                        arrayCellTrackingPreviousMap = new int *[trackAreaSize+4];
                        
                        for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++){
                            errorNoHold = 33;
                            arrayCellTrackingPreviousMap [counter1] = new int [trackAreaSize+4];
                        }
                    }
                }
                
                if (cellTrackingPreviousStatus == 0){
                    errorNoHold = 34;
                    arrayCellTrackingPrevious = new int [positionReviseCount*3+50];
                    cellTrackingPreviousCount = 0;
                    cellTrackingPreviousStatus = 1;
                    cellTrackingPreviousSizeHold = positionReviseCount*3+50;
                }
                else if (cellTrackingPreviousStatus == 1 && cellTrackingPreviousSizeHold < positionReviseCount){
                    delete [] arrayCellTrackingPrevious;
                    
                    errorNoHold = 35;
                    arrayCellTrackingPrevious = new int [positionReviseCount*3+50];
                    cellTrackingPreviousCount = 0;
                    cellTrackingPreviousSizeHold = positionReviseCount*3+50;
                }
                else cellTrackingPreviousCount = 0;
                
                if (xyPositionCenterPreviousStatus == 0){
                    errorNoHold = 36;
                    arrayXYPositionCenterPrevious = new int [gravityCenterRevCount*3+50];
                    xyPositionCenterPreviousCount = 0;
                    xyPositionCenterPreviousStatus = 1;
                    xyPositionCenterPreviousSizeHold = gravityCenterRevCount*3+50;
                }
                else if (xyPositionCenterPreviousStatus == 1 && xyPositionCenterPreviousSizeHold < gravityCenterRevCount){
                    delete [] arrayXYPositionCenterPrevious;
                    
                    errorNoHold = 37;
                    arrayXYPositionCenterPrevious = new int [gravityCenterRevCount*3+50];
                    xyPositionCenterPreviousCount = 0;
                    xyPositionCenterPreviousSizeHold = gravityCenterRevCount*3+50;
                }
                else xyPositionCenterPreviousCount = 0;
                
                if (cellTrackingPreviousAssStatus == 0){
                    errorNoHold = 38;
                    arrayCellTrackingPreviousAss = new int [associatedDataCount*3+50];
                    cellTrackingPreviousAssCount = 0;
                    cellTrackingPreviousAssStatus = 1;
                    cellTrackingPreviousAssSizeHold = associatedDataCount*3+50;
                }
                else if (cellTrackingPreviousAssStatus == 1 && cellTrackingPreviousAssSizeHold < associatedDataCount){
                    delete [] arrayCellTrackingPreviousAss;
                    
                    errorNoHold = 39;
                    arrayCellTrackingPreviousAss = new int [associatedDataCount*3+50];
                    cellTrackingPreviousAssCount = 0;
                    cellTrackingPreviousAssSizeHold = associatedDataCount*3+50;
                }
                else cellTrackingPreviousAssCount = 0;
                
                //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
                //    cout<<" arrayGravityCenterRev "<<counterA<<endl;
                //}
                
                //for (int counterA = 1200; counterA < 1250; counterA++){
                //    for (int counterB = 1900; counterB < 1950; counterB++) cout<<" "<<revisedMap [counterA][counterB];
                //    cout<<" revisedMap "<<counterA<<endl;
                //}
                
                //for (int counterA = 1200; counterA < 1250; counterA++){
                //    for (int counterB = 1900; counterB < 1950; counterB++) cout<<" "<<revisedWorkingMap [counterA][counterB];
                //    cout<<" revisedWorkingMap "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                //    cout<<" arrayTimeSelected "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
                //    cout<<" arrayPositionRevise "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
                //    cout<<" arrayConnectLineageRel "<<counterA<<endl;
                //}
                
                int lessThanTen = 0;
                int endPosition = 0;
                int saveFlag = 0;
                int connectTimeStatus = 0;
                
                for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                    if (arrayTimeSelected [counter1*10] != 3 && arrayTimeSelected [counter1*10] != 4){
                        if (counter1 == timeSelectedCount/10-1) endPosition = positionReviseCount/7-1;
                        else endPosition = arrayTimeSelected [(counter1+1)*10+2]-1;
                        
                        connectTimeStatus = arrayTimeSelected [counter1*10+8];
                        
                        if(endPosition < arrayTimeSelected [counter1*10+2]) endPosition = positionReviseCount/7-1;
                        
                        saveFlag = 0;
                        
                        for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 <= endPosition; counter2++){
                            if (connectTimeStatus == arrayPositionRevise [counter2*7+3] && arrayPositionRevise [counter2*7]-horizontalStart >= 0 && arrayPositionRevise [counter2*7]-horizontalStart < trackAreaSize && arrayPositionRevise [counter2*7+1]-verticalStart >= 0 && arrayPositionRevise [counter2*7+1]-verticalStart < trackAreaSize){
                                saveFlag++;
                            }
                        }
                        
                        if (saveFlag != 0 || targetConnectInitial == arrayTimeSelected [counter1*10+8]){
                            for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 <= endPosition; counter2++){
                                if (connectTimeStatus == arrayPositionRevise [counter2*7+3]){
                                    arrayCellTrackingPrevious [cellTrackingPreviousCount] = arrayPositionRevise [counter2*7], cellTrackingPreviousCount++;
                                    arrayCellTrackingPrevious [cellTrackingPreviousCount] = arrayPositionRevise [counter2*7+1], cellTrackingPreviousCount++;
                                    arrayCellTrackingPrevious [cellTrackingPreviousCount] = arrayPositionRevise [counter2*7+2], cellTrackingPreviousCount++;
                                    arrayCellTrackingPrevious [cellTrackingPreviousCount] = arrayPositionRevise [counter2*7+3], cellTrackingPreviousCount++;
                                    arrayCellTrackingPrevious [cellTrackingPreviousCount] = arrayTimeSelected [counter1*10], cellTrackingPreviousCount++; //------Set Cell Status 7 or 1------
                                    arrayCellTrackingPrevious [cellTrackingPreviousCount] = arrayPositionRevise [counter2*7+5], cellTrackingPreviousCount++;
                                }
                            }
                            
                            for (int counter2 = 0; counter2 < gravityCenterRevCount/6; counter2++){
                                if (connectTimeStatus == arrayGravityCenterRev [counter2*6+4]){
                                    arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = arrayGravityCenterRev [counter2*6], xyPositionCenterPreviousCount++;
                                    arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = arrayGravityCenterRev [counter2*6+1], xyPositionCenterPreviousCount++;
                                    arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = arrayGravityCenterRev [counter2*6+2], xyPositionCenterPreviousCount++;
                                    arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = arrayGravityCenterRev [counter2*6+3], xyPositionCenterPreviousCount++;
                                    arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = arrayGravityCenterRev [counter2*6+4], xyPositionCenterPreviousCount++;
                                    
                                    if (targetConnectInitial == arrayPositionRevise [arrayTimeSelected [counter1*10+2]*7+3]) arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = 1, xyPositionCenterPreviousCount++; //------Target set 1------
                                    else arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = 0, xyPositionCenterPreviousCount++;
                                }
                            }
                            
                            for (int counter2 = 0; counter2 < associatedDataCount/6; counter2++){
                                if (connectTimeStatus == arrayAssociatedData [counter2*6]){
                                    arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = arrayAssociatedData [counter2*6], cellTrackingPreviousAssCount++;
                                    arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = arrayAssociatedData [counter2*6+1], cellTrackingPreviousAssCount++;
                                    arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = arrayAssociatedData [counter2*6+2], cellTrackingPreviousAssCount++;
                                    arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = arrayAssociatedData [counter2*6+3], cellTrackingPreviousAssCount++;
                                    arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = arrayAssociatedData [counter2*6+4], cellTrackingPreviousAssCount++;
                                    arrayCellTrackingPreviousAss [cellTrackingPreviousAssCount] = arrayAssociatedData [counter2*6+5], cellTrackingPreviousAssCount++;
                                }
                            }
                        }
                        
                        if (arrayTimeSelected [counter1*10+8] == targetConnectInitial && (arrayTimeSelected [counter1*10] == 7 || arrayTimeSelected [counter1*10] == 1)) lessThanTen = 1;
                    }
                }
                
                //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrevious [counterA*6+counterB];
                //    cout<<" arrayCellTrackingPrevious "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < cellTrackingPreviousAssCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPreviousAss [counterA*6+counterB];
                //    cout<<" arrayCellTrackingPreviousAss "<<counterA<<endl;
                //}
                
                if (connectNoHoldStatus == 0){
                    errorNoHold = 40;
                    connectNoHold = new int [xyPositionCenterPreviousCount*3+50];
                    connectNoHoldCount = 0;
                    connectNoHoldStatus = 1;
                    connectNoHoldSizeHold = xyPositionCenterPreviousCount*3+50;
                }
                else if (connectNoHoldStatus == 1 && connectNoHoldSizeHold < xyPositionCenterPreviousCount){
                    delete [] connectNoHold;
                    
                    errorNoHold = 41;
                    connectNoHold = new int [xyPositionCenterPreviousCount*3+50];
                    connectNoHoldCount = 0;
                    connectNoHoldSizeHold = xyPositionCenterPreviousCount*3+50;
                }
                else connectNoHoldCount = 0;
                
                for (int counter1 = 0; counter1 < xyPositionCenterPreviousCount/6; counter1++) connectNoHold [counter1] = arrayXYPositionCenterPrevious [counter1*6+4], connectNoHoldCount++;
                
                //for (int counter1 = 0; counter1 < connectNoHoldCount; counter1++)cout<<connectNoHold [counter1]<<" connectNoHold"<<endl;
                
                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    for (int counterX = 0; counterX < trackAreaSize; counterX++) arrayCellTrackingPreviousMap [counterY][counterX] = 0;
                }
                
                int findFlag = 0;
                
                for (int counterY = verticalStart; counterY < verticalStart+trackAreaSize; counterY++){
                    for (int counterX = horizontalStart; counterX < horizontalStart+trackAreaSize; counterX++){
                        if (counterY < 0 || counterY >= imageDimension || counterX < 0 || counterX >= imageDimension){
                            arrayCellTrackingPreviousMap [counterY-verticalStart][counterX-horizontalStart] = 0;
                        }
                        else{
                            
                            findFlag = 0;
                            
                            if (revisedWorkingMap [counterY][counterX] != 0){
                                for (int counter1 = 0; counter1 < xyPositionCenterPreviousCount/6; counter1++){
                                    if (arrayXYPositionCenterPrevious [counter1*6+4] == revisedWorkingMap [counterY][counterX]){
                                        findFlag = 1;
                                        break;
                                    }
                                }
                            }
                            
                            if (counterY >= 0 && counterY < imageDimension && counterX >= 0 && counterX < imageDimension){
                                if (findFlag == 1) arrayCellTrackingPreviousMap [counterY-verticalStart][counterX-horizontalStart] = revisedWorkingMap [counterY][counterX];
                                else arrayCellTrackingPreviousMap [counterY-verticalStart][counterX-horizontalStart] = 0;
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                //    for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingPreviousMap [counterA][counterB];
                //    cout<<" arrayCellTrackingPreviousMap "<<counterA<<endl;
                //}
                
                if (processTime == 3){ //-------For redo----------
                    tableInterpretation = [[TableInterpretation alloc] init];
                    [tableInterpretation interpretationFirst:processTime];
                    
                    do{
                    } while(subCompletionFlag3 == 1);
                    
                    if (errorNoHold != 0){
                        errorNoHold = errorNoHold+2000;
                        throw errorCheckThrow;
                    }
                }
                
                //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                //}
                
                errorNoHold = 42;
                int *connectedPixels = new int [gravityCenterRevCount/6+1];
                
                for (int counter1 = 0; counter1 < gravityCenterRevCount/6+1; counter1++) connectedPixels [counter1] = 0;
                
                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                        if (arrayCellTrackingPreviousMap [counterY][counterX] > 0) connectedPixels [arrayCellTrackingPreviousMap [counterY][counterX]]++;
                    }
                }
                
                //------Map UpDate------
                int connectTemp = 1;
                
                for (int counter1 = 1; counter1 < gravityCenterRevCount/6+1; counter1++){
                    if (connectedPixels [counter1] != 0){
                        connectedPixels [counter1] = connectTemp;
                        connectTemp++;
                    }
                }
                
                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                        if (arrayCellTrackingPreviousMap [counterY][counterX] > 0) arrayCellTrackingPreviousMap [counterY][counterX] = connectedPixels [arrayCellTrackingPreviousMap [counterY][counterX]];
                    }
                }
                
                for (int counter1 = 0; counter1 < xyPositionCenterPreviousCount/6; counter1++){
                    if (arrayXYPositionCenterPrevious [counter1*6+4] != 0) arrayXYPositionCenterPrevious [counter1*6+4] = connectedPixels [arrayXYPositionCenterPrevious [counter1*6+4]];
                }
                
                for (int counter1 = 0; counter1 < cellTrackingPreviousCount/6; counter1++){
                    if (arrayCellTrackingPrevious [counter1*6+3] != 0){
                        arrayCellTrackingPrevious [counter1*6+3] = connectedPixels [arrayCellTrackingPrevious [counter1*6+3]];
                    }
                }
                
                //for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrevious [counterA*6+counterB];
                //    cout<<" arrayCellTrackingPrevious "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < cellTrackingPreviousAssCount/6; counter1++){
                    if (arrayCellTrackingPreviousAss [counter1*6] != 0) arrayCellTrackingPreviousAss [counter1*6] = connectedPixels [arrayCellTrackingPreviousAss [counter1*6]];
                }
                
                //for (int counterA = 0; counterA < cellTrackingPreviousAssCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPreviousAss [counterA*6+counterB];
                //    cout<<" arrayCellTrackingPreviousAss "<<counterA<<endl;
                //}
                
                delete [] connectedPixels;
                
                if (upLoadCheck == 3 && lessThanTen == 0) upLoadCheck = 15; //-----Set if cell is Not selected and image number is less than ten from Time one-------
                else if (upLoadCheck < 3 && lessThanTen == 0) upLoadCheck = 20; //-----Set if cell is Not selected and image number is less than ten from Time one, file up load error-------
                
                //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                //}
                
                // for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                //     cout<<" arrayTimeSelected "<<counterA<<endl;
                // }
                
                // for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
                //     for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
                //     cout<<" arrayGravityCenterRev "<<counterA<<endl;
                // }
            }
            
            sleepingPosition = 10;
            errorNoHold = 0;
            subCompletionFlag = 0;
        }
        catch (int errorCheckThrow){
            if (errorNoHold >= 1000 && errorNoHold < 2000){
                string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
                mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                time_t rawtime;
                struct tm * timeinfo;
                time (&rawtime);
                timeinfo = localtime ( &rawtime );
                
                int tsec = timeinfo -> tm_sec;
                int tmin = timeinfo -> tm_min;
                int thour = timeinfo -> tm_hour;
                int tday = timeinfo -> tm_mday;
                int tmon = timeinfo -> tm_mon;
                
                string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
                
                errorPath = errorPath+"/Cell_CarvingTrackingSet01 "+dateTime;
                
                string extension;
                
                if (imageNo == 0) extension = to_string(imageNumberInt);
                else extension = to_string(imageNo);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                ofstream oin2;
                oin2.open(errorPath.c_str(), ios::out);
                oin2<<"TrackingSet"<<endl;
                oin2<<errorNoHold<<endl;
                oin2<<analysisImageName<<endl;
                oin2<<analysisID<<endl;
                oin2<<treatmentNameHold<<endl;
                oin2<<cellLineageNoHold<<endl;
                oin2<<cellNoHold<<endl;
                oin2<<dateTime<<endl;
                oin2<<positionReviseCount<<endl;
                oin2<<associatedDataCount<<endl;
                oin2<<gravityCenterRevCount<<endl;
                oin2<<timeSelectedCount<<endl;
                oin2<<connectLineageRelCount<<endl;
                oin2<<trackingExitCount<<endl;
                
                if (errorNoHold == 1000) oin2<<"MasterData/Revise reading error"<<endl;
                else if (errorNoHold == 1001) oin2<<"MasterDataRevise uploading error"<<endl;
                else if (errorNoHold == 1002) oin2<<"MasterData uploading error"<<endl;
                else if (errorNoHold == 1003) oin2<<"Status data uploading error"<<endl;
                else if (errorNoHold == 1004) oin2<<"ConnectRel data uploading error"<<endl;
                else if (errorNoHold == 1005) oin2<<"Map open-error"<<endl;
                else if (errorNoHold == 1006) oin2<<"Array size error"<<endl;
                oin2.close();
            }
            
            if (errorNoHold == 0) errorNoHold = 1000;
            
            subCompletionFlag = 0;
        }
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingTrackingSet02 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"TrackingSet"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
        
        subCompletionFlag = 0;
    }
    
    return upLoadCheck; //------Total 10------
}

-(void)gravityCenterRevUpDate{
    try{
        
        errorNoHold = 0;
        
        int *arrayUpDate = new int [gravityCenterRevCount+10];
        
        for (int counter1 = 0; counter1 < gravityCenterRevCount; counter1++) arrayUpDate [counter1] = arrayGravityCenterRev [counter1];
        
        delete [] arrayGravityCenterRev;
        arrayGravityCenterRev = new int [gravityCenterRevLimit*3+2000];
        gravityCenterRevLimit = gravityCenterRevLimit*3+2000;
        
        for (int counter1 = 0; counter1 < gravityCenterRevCount; counter1++) arrayGravityCenterRev [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
        
        gravityCenterRevSizeHold = gravityCenterRevLimit*3+2000;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingTrackingSet03 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"TrackingSet-gravityCenterRevUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

-(void)associatedDataUpDate{
    try{
        
        errorNoHold = 0;
        
        int *arrayUpDate = new int [associatedDataCount+10];
        
        for (int counter1 = 0; counter1 < associatedDataCount; counter1++) arrayUpDate [counter1] = arrayAssociatedData [counter1];
        
        delete [] arrayAssociatedData;
        arrayAssociatedData = new int [associatedDataLimit*3+2000];
        associatedDataLimit = associatedDataLimit*3+2000;
        
        for (int counter1 = 0; counter1 < associatedDataCount; counter1++) arrayAssociatedData [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
        
        associatedDataSizeHold = associatedDataLimit*3+2000;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingTrackingSet04 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"TrackingSet-associatedDataUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

@end
