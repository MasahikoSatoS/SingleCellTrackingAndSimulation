//
//  NewLineSet.h
//  Cell_Carving
//
//  Created by Masahiko Sato on 2015-04-22.
//
//

#ifndef NEWLINESET_H
#define NEWLINESET_H
#import "Controller.h"
#endif

@interface NewLineSet : NSObject{
}

-(void)newLineSetMain;

@end
