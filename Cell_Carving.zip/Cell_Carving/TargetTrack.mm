//
// TargetTrack.mm
// cell_carving
//
// Created by Masahiko Sato on 02/01/12.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#import "TargetTrack.h"

@implementation TargetTrack

-(int)targetTrackProcess{
    //for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrevious [counterA*6+counterB];
    //	cout<<" arrayCellTrackingPrevious "<<counterA<<endl;
    //}
    
    //------Target Set------
    targetPointerTrack = 0;
    
    try{
        try{
            
            errorNoHold = 0;
            int errorCheckThrow = 0;
            subCompletionFlag = 1;
            
            for (int counter1 = 0; counter1 < xyPositionCenterPreviousCount/6; counter1++){
                if (arrayXYPositionCenterPrevious [counter1*6+5] == 1) targetPointerTrack = arrayXYPositionCenterPrevious [counter1*6+4];
            }
            
            //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
            //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < cellTrackingCurrentCount/6; counterA++){
            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrent [counterA*6+counterB];
            //	cout<<" arrayCellTrackingCurrent "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
            //    cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < trackAreaSize; counterA++){
            //	for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingCurrentMap [counterA][counterB];
            //	cout<<" arrayCellTrackingCurrentMap "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < trackAreaSize; counterA++){
            //    for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingPreviousMap [counterA][counterB];
            //    cout<<" arrayCellTrackingPreviousMap "<<counterA<<endl;
            //}
            
            //cout<<targetPointer<<" TARG1"<<endl;
            
            //for (int counterA = 0; counterA < cellTrackingPreviousAssCount/6; counterA++){
            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPreviousAss [counterA*6+counterB];
            //	cout<<" arrayCellTrackingPreviousAss "<<counterA<<endl;
            //}
            
            if (targetPointerTrack != 0){
                //------Number of lines------
                int lineNumberPrevious = cellTrackingPreviousAssCount/6;
                int lineNumberCurrent = cellTrackingCurrentAssCount/6;
                
                //cout<<lineNumberPrevious<<" "<<lineNumberCurrent<<" Prev_Curr_LineNo"<<endl;
                
                //------Previous Data, total pix, average------
                errorNoHold = 1;
                arrayPreviousTableTrack = new int [lineNumberPrevious*2+10];
                errorNoHold = 2;
                arrayPreviousTableTrackTotal = new double [lineNumberPrevious+5];
                errorNoHold = 3;
                arrayPreviousAverageTrack = new double [lineNumberPrevious+5];
                
                for (int counter1 = 0; counter1 < lineNumberPrevious+5; counter1++){
                    arrayPreviousTableTrack [counter1*2] = 0;
                    arrayPreviousTableTrack [counter1*2+1] = counter1;
                    arrayPreviousTableTrackTotal [counter1] = 0;
                    arrayPreviousAverageTrack [counter1] = 0;
                }
                
                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                        if (arrayCellTrackingPreviousMap [counterY][counterX] > 0){
                            arrayPreviousTableTrack [arrayCellTrackingPreviousMap [counterY][counterX]*2]++;
                            
                            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                arrayPreviousTableTrackTotal [arrayCellTrackingPreviousMap [counterY][counterX]] = arrayPreviousTableTrackTotal [arrayCellTrackingPreviousMap [counterY][counterX]]+sourceImage [mapPositionPointer][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                            }
                        }
                    }
                }
                
                for (int counter1 = 1; counter1 < lineNumberPrevious+1; counter1++){
                    if (arrayPreviousTableTrack [counter1*2] > 10) arrayPreviousAverageTrack [counter1] = arrayPreviousTableTrackTotal [counter1]/(double)arrayPreviousTableTrack [counter1*2];
                    else{
                        
                        arrayPreviousAverageTrack [counter1] = 0;
                        arrayPreviousTableTrack [counter1*2] = 0;
                    }
                }
                
                //------Remove "Below" pix from Connect Pre Map------
                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                        if (arrayCellTrackingPreviousMap [counterY][counterX] > 0 && arrayPreviousTableTrack [arrayCellTrackingPreviousMap [counterY][counterX]*2] == 0) arrayCellTrackingPreviousMap [counterY][counterX] = 0;
                    }
                }
                
                //for (int counterA = 1; counterA < lineNumberPrevious+1; counterA ++){
                //	cout<<" TotalPoint "<<arrayPreviousTableTrack [counterA*2]<<" ConnectNO "<<arrayPreviousTableTrack [counterA*2+1];
                //    cout<<" TotalValue "<<arrayPreviousTableTrackTotal [counterA]<<" Average "<<arrayPreviousAverageTrack [counterA];
                //    cout<<" PreviouTable First"<<endl;
                //}
                
                //------Current Data, total pix, average, SD calculation------
                errorNoHold = 4;
                arrayCurrentTableTrack = new int [lineNumberCurrent*2+10];
                errorNoHold = 5;
                arrayCurrentTableTrackTotal = new double [lineNumberCurrent+5];
                errorNoHold = 6;
                arrayCurrentAverageTrack = new double [lineNumberCurrent+5];
                errorNoHold = 7;
                double *currentSD = new double [lineNumberCurrent+5];
                errorNoHold = 8;
                int *currentTotalForSD = new int [lineNumberCurrent+5];
                
                for (int counter1 = 0; counter1 < lineNumberCurrent+5; counter1++){
                    arrayCurrentTableTrack [counter1*2] = 0;
                    arrayCurrentTableTrack [counter1*2+1] = counter1;
                    arrayCurrentTableTrackTotal [counter1] = 0;
                    arrayCurrentAverageTrack [counter1] = 0;
                    currentTotalForSD [counter1] = 0;
                    currentSD [counter1] = 0;
                }
                
                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                        if (arrayCellTrackingCurrentMap [counterY][counterX] != 0){
                            arrayCurrentTableTrack [arrayCellTrackingCurrentMap [counterY][counterX]*2]++;
                            
                            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                arrayCurrentTableTrackTotal [arrayCellTrackingCurrentMap [counterY][counterX]] = arrayCurrentTableTrackTotal [arrayCellTrackingCurrentMap [counterY][counterX]]+sourceImage [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                            }
                        }
                    }
                }
                
                for (int counter1 = 1; counter1 < lineNumberCurrent+1; counter1++){
                    if (arrayCurrentTableTrack [counter1*2] != 0) arrayCurrentAverageTrack [counter1] = arrayCurrentTableTrackTotal [counter1]/(double)arrayCurrentTableTrack [counter1*2];
                    else arrayCurrentAverageTrack [counter1] = 0;
                }
                
                int currentValue = 0;
                double currentOriginal = 0;
                
                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                        if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                            currentValue = arrayCellTrackingCurrentMap [counterY][counterX];
                            currentOriginal = sourceImage [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                            
                            if (currentValue != 0) currentTotalForSD [currentValue] = currentTotalForSD [currentValue]+(int)(currentOriginal-arrayCurrentAverageTrack [currentValue])*(int)(currentOriginal-arrayCurrentAverageTrack [currentValue]);
                        }
                    }
                }
                
                for (int counter1 = 1; counter1 < lineNumberCurrent+1; counter1++){
                    if (arrayCurrentAverageTrack [counter1] != 0) currentSD [counter1] = sqrt(currentTotalForSD [counter1]/(double)(arrayCurrentTableTrack [counter1*2]-1));
                    else currentSD [counter1] = 0;
                }
                
                //------Remove area below 150 and low SD: put "0" in Current Table------
                for (int counter1 = 1; counter1 < lineNumberCurrent+1; counter1++){
                    if (currentSD [counter1] < 10 && arrayCurrentAverageTrack [counter1] > 90 && arrayCurrentAverageTrack [counter1] < 110) arrayCurrentTableTrack [counter1*2] = 0;
                    if (arrayCurrentTableTrack [counter1*2] < 10) arrayCurrentTableTrack [counter1*2] = 0;
                }
                
                //------Remove "Below" pixels from Connect Map------
                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                        if (arrayCurrentTableTrack [arrayCellTrackingCurrentMap [counterY][counterX]*2] == 0) arrayCellTrackingCurrentMap [counterY][counterX] = 0;
                    }
                }
                
                //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                //	for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingCurrentMap [counterA][counterB];
                //	cout<<" arrayCellTrackingCurrentMap "<<counterA<<endl;
                //}
                
                //for (int counterA = 1; counterA < lineNumberCurrent+1; counterA++){
                //    cout<<" TotalPoint "<<arrayCurrentTableTrack [counterA*2]<<" ConnectNO "<<arrayCurrentTableTrack [counterA*2+1];
                //    cout<<" TotalValue "<<arrayCurrentTableTrackTotal [counterA]<<" Average "<<arrayCurrentTableTrackTotal [counterA];
                //    cout<<" CurrentTable First"<<endl;
                //}
                
                //------Overlap Set------
                errorNoHold = 9;
                int **overlapData = new int *[lineNumberPrevious+1];
                errorNoHold = 10;
                int **overlapIntensity = new int *[lineNumberPrevious+1];
                errorNoHold = 11;
                int **overlapPercent = new int *[lineNumberPrevious+1];
                
                for (int counter1 = 0; counter1 < lineNumberPrevious+1; counter1++){
                    errorNoHold = 12;
                    overlapData [counter1] = new int [lineNumberCurrent+1];
                    errorNoHold = 13;
                    overlapIntensity [counter1] = new int [lineNumberCurrent+1];
                    errorNoHold = 14;
                    overlapPercent [counter1] = new int [lineNumberCurrent+1];
                }
                
                for (int counterY = 0; counterY < lineNumberPrevious+1; counterY++){
                    for (int counterX = 0; counterX < lineNumberCurrent+1; counterX++){
                        overlapData [counterY][counterX] = 0;
                        overlapIntensity [counterY][counterX] = 0;
                        overlapPercent [counterY][counterX] = 0;
                    }
                }
                
                int previousValue = 0;
                
                for (int counterY = 0; counterY < trackAreaSize; counterY++){
                    for (int counterX = 0; counterX < trackAreaSize; counterX++){
                        currentValue = arrayCellTrackingCurrentMap [counterY][counterX];
                        previousValue = arrayCellTrackingPreviousMap [counterY][counterX];
                        
                        if (previousValue > 0 && currentValue > 0){
                            overlapData [previousValue][currentValue]++;
                            
                            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                overlapIntensity [previousValue][currentValue] = overlapIntensity [previousValue][currentValue]+sourceImage [mapPositionPointerCurrent][(counterY+verticalStart)*imageDimension+counterX+horizontalStart];
                            }
                        }
                    }
                }
                
                for (int counterY = 1; counterY < lineNumberPrevious+1; counterY++){
                    for (int counterX = 1; counterX < lineNumberCurrent+1; counterX++){
                        if (overlapData [counterY][counterX] > 0 && arrayPreviousTableTrack [counterY*2] > 0){
                            overlapIntensity [counterY][counterX] = (int)(overlapIntensity [counterY][counterX]/(double)overlapData [counterY][counterX]);
                        }
                        if (overlapData [counterY][counterX] > 0 && arrayPreviousTableTrack [counterY*2] > 0){
                            overlapPercent [counterY][counterX] = (int)(overlapData [counterY][counterX]/(double)arrayPreviousTableTrack [counterY*2]*100);
                        }
                    }
                }
                
                maxTargetEntryTrack = 0;
                int dataTemp2 = 0;
                
                for (int counterY = 1; counterY < lineNumberPrevious+1; counterY++){
                    dataTemp2 = 0;
                    
                    for (int counterX = 1; counterX < lineNumberCurrent+1; counterX++){
                        if (overlapData [counterY][counterX] != 0 && arrayCurrentTableTrack [counterX*2] > 0) dataTemp2++;
                    }
                    
                    if (dataTemp2 > maxTargetEntryTrack) maxTargetEntryTrack = dataTemp2;
                }
                
                //for (int counterA = 1; counterA < lineNumberPrevious+1; counterA++){
                //	for (int counterB = 1; counterB < lineNumberCurrent+1; counterB++) cout<<" "<<overlapData [counterA][counterB];
                //	cout<<" OverlapData "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                //}
                
                int maxEntryTemp = maxTargetEntryTrack;
                
                if (maxEntryTemp != 0){
                    //------Sort Current based on area------
                    //*****1. prev no, 2. Entry count, 0, 1, 2..., 3. current no/overlap intensity/area etc*******
                    
                    errorNoHold = 15;
                    int **overlapNumber2 = new int *[lineNumberPrevious+1];
                    errorNoHold = 16;
                    int **overlapData2 = new int *[lineNumberPrevious+1];
                    errorNoHold = 17;
                    int **overlapIntensity2 = new int *[lineNumberPrevious+1];
                    errorNoHold = 18;
                    int **overlapPercent2 = new int *[lineNumberPrevious+1];
                    
                    for (int counter1 = 0; counter1 < lineNumberPrevious+1; counter1++){
                        errorNoHold = 19;
                        overlapNumber2 [counter1] = new int [maxEntryTemp+1];
                        errorNoHold = 20;
                        overlapData2 [counter1] = new int [maxEntryTemp+1];
                        errorNoHold = 21;
                        overlapIntensity2 [counter1] = new int [maxEntryTemp+1];
                        errorNoHold = 22;
                        overlapPercent2 [counter1] = new int [maxEntryTemp+1];
                    }
                    
                    for (int counterY = 1; counterY < lineNumberPrevious+1; counterY++){
                        for (int counterX = 0; counterX < maxEntryTemp+1; counterX++){
                            overlapNumber2 [counterY][counterX] = 0;
                            overlapData2 [counterY][counterX] = 0;
                            overlapIntensity2 [counterY][counterX] = 0;
                            overlapPercent2 [counterY][counterX] = 0;
                        }
                    }
                    
                    //------Sort------
                    int entryCount = 0;
                    int terminationFlag1 = 0;
                    int sortFindFlag = 0;
                    int overlapMax = 0;
                    int overlapCount = 0;
                    
                    for (int counter1 = 1; counter1 < lineNumberPrevious+1; counter1++){
                        entryCount = 0;
                        
                        do{
                            
                            terminationFlag1 = 1;
                            sortFindFlag = 0;
                            overlapMax = 0;
                            overlapCount = 0;
                            
                            for (int counter2 = 1; counter2 < lineNumberCurrent+1; counter2++){
                                if (overlapMax < overlapPercent [counter1][counter2] && overlapPercent [counter1][counter2] != 0){
                                    overlapMax = overlapPercent [counter1][counter2];
                                    overlapCount = counter2;
                                    sortFindFlag = 1;
                                }
                            }
                            
                            if (sortFindFlag == 1){
                                overlapNumber2 [counter1][entryCount] = overlapCount;
                                overlapData2 [counter1][entryCount] = overlapData [counter1][overlapCount];
                                overlapIntensity2 [counter1][entryCount] = overlapIntensity [counter1][overlapCount];
                                overlapPercent2 [counter1][entryCount] = overlapMax;
                                overlapPercent [counter1][overlapCount] = 0;
                                entryCount++;
                            }
                            else terminationFlag1 = 0;
                            
                        } while (terminationFlag1 == 1);
                    }
                    
                    //------Sort Result Verification------
                    errorNoHold = 23;
                    int *numberTemp = new int [maxEntryTemp+1];
                    errorNoHold = 24;
                    int *overlapDataTemp = new int [maxEntryTemp+1];
                    errorNoHold = 25;
                    int *overlapIntensityTemp = new int [maxEntryTemp+1];
                    errorNoHold = 26;
                    int *overlapPercentTemp = new int [maxEntryTemp+1];
                    
                    int connectPrevious = 0;
                    int passFlag = 0;
                    int passFlag2 = 0;
                    int newMainNumber = 0;
                    int mainNumberCount = 0;
                    int connectPrevious2 = 0;
                    
                    for (int counterY = 1; counterY < lineNumberPrevious+1; counterY++){
                        connectPrevious = overlapNumber2 [counterY][0];
                        passFlag = 0;
                        
                        if (arrayPreviousAverageTrack [counterY] > cutOff2){
                            if (arrayCurrentAverageTrack [connectPrevious] > cutOff2 && arrayCurrentTableTrack [connectPrevious*2] > arrayPreviousTableTrack [counterY*2]*0.6 && arrayCurrentTableTrack [connectPrevious*2] <= arrayPreviousTableTrack [counterY*2]*1.4){
                                passFlag = 1;
                            }
                        }
                        if (arrayPreviousAverageTrack [counterY] <= cutOff2 && arrayPreviousAverageTrack [counterY] > cutOff4){
                            if (arrayCurrentAverageTrack [connectPrevious] <= cutOff2 && arrayCurrentAverageTrack [connectPrevious] > cutOff4 && arrayCurrentTableTrack [connectPrevious*2] > arrayPreviousTableTrack [counterY*2]*0.6 && arrayCurrentTableTrack [connectPrevious*2] <= arrayPreviousTableTrack [counterY*2]*1.4){
                                passFlag = 1;
                            }
                            if (arrayCurrentAverageTrack [connectPrevious] <= cutOff4 && arrayCurrentTableTrack [connectPrevious*2] > arrayPreviousTableTrack [counterY*2]*0.8 && arrayCurrentTableTrack [connectPrevious*2] <= arrayPreviousTableTrack [counterY*2]*1.4){
                                passFlag = 1;
                            }
                            if (arrayCurrentAverageTrack [connectPrevious] > cutOff2 && arrayCurrentTableTrack [connectPrevious*2] > arrayPreviousTableTrack [counterY*2]*0.6 && arrayCurrentTableTrack [connectPrevious*2] <= arrayPreviousTableTrack [counterY*2]*1.2){
                                passFlag = 1;
                            }
                        }
                        if (arrayPreviousAverageTrack [counterY] <= 190){
                            if (arrayCurrentAverageTrack [connectPrevious] <= cutOff2 && arrayCurrentAverageTrack [connectPrevious] > cutOff4 && arrayCurrentTableTrack [connectPrevious*2] > arrayPreviousTableTrack [counterY*2]*0.6 && arrayCurrentTableTrack [connectPrevious*2] <= arrayPreviousTableTrack [counterY*2]*1.3){
                                passFlag = 1;
                            }
                            if (arrayCurrentAverageTrack [connectPrevious] <= cutOff4 && arrayCurrentTableTrack [connectPrevious*2] > arrayPreviousTableTrack [counterY*2]*0.6 && arrayCurrentTableTrack [connectPrevious*2] <= arrayPreviousTableTrack [counterY*2]*1.4){
                                passFlag = 1;
                            }
                            if (arrayCurrentAverageTrack [connectPrevious] > cutOff2 && arrayCurrentTableTrack [connectPrevious*2] > arrayPreviousTableTrack [counterY*2]*0.4 && arrayCurrentTableTrack [connectPrevious*2] <= arrayPreviousTableTrack [counterY*2]){
                                passFlag = 1;
                            }
                        }
                        
                        if (passFlag == 0){
                            passFlag2 = 0;
                            newMainNumber = 0;
                            mainNumberCount = 0;
                            
                            for (int counterX = 0; counterX < maxEntryTemp; counterX++){
                                if (overlapNumber2 [counterY][counterX] != 0){
                                    connectPrevious2 = overlapNumber2 [counterY][counterX];
                                    mainNumberCount = counterX;
                                    
                                    if (arrayPreviousAverageTrack [counterY] > cutOff2){
                                        if (arrayCurrentAverageTrack [connectPrevious2] > cutOff2 && arrayCurrentTableTrack [connectPrevious2*2] > arrayPreviousTableTrack [counterY*2]*0.6 && arrayCurrentTableTrack [connectPrevious2*2] <= arrayPreviousTableTrack [counterY*2]*1.4){
                                            passFlag2 = 1, newMainNumber = connectPrevious2;
                                            break;
                                        }
                                    }
                                    if (arrayPreviousAverageTrack [counterY] <= cutOff2 && arrayPreviousAverageTrack [counterY] > cutOff4){
                                        if (arrayCurrentAverageTrack [connectPrevious2] <= cutOff2 && arrayCurrentAverageTrack [connectPrevious2] > cutOff4 && arrayCurrentTableTrack [connectPrevious2*2] > arrayPreviousTableTrack [counterY*2]*0.6 && arrayCurrentTableTrack [connectPrevious2*2] <= arrayPreviousTableTrack [counterY*2]*1.4){
                                            passFlag2 = 1, newMainNumber = connectPrevious2;
                                            break;
                                        }
                                        if (arrayCurrentAverageTrack [connectPrevious2] <= cutOff4 && arrayCurrentTableTrack [connectPrevious2*2] > arrayPreviousTableTrack [counterY*2]*0.8 && arrayCurrentTableTrack [connectPrevious2*2] <= arrayPreviousTableTrack [counterY*2]*1.4){
                                            passFlag2 = 1, newMainNumber = connectPrevious2;
                                            break;
                                        }
                                        if (arrayCurrentAverageTrack [connectPrevious2] > cutOff2 && arrayCurrentTableTrack [connectPrevious2*2] > arrayPreviousTableTrack [counterY*2]*0.6 && arrayCurrentTableTrack [connectPrevious2*2] <= arrayPreviousTableTrack [counterY*2]*1.2){
                                            passFlag2 = 1, newMainNumber = connectPrevious2;
                                            break;
                                        }
                                    }
                                    if (arrayPreviousAverageTrack [counterY] <= cutOff4){
                                        if (arrayCurrentAverageTrack [connectPrevious2] <= cutOff2 && arrayCurrentAverageTrack [connectPrevious2] > cutOff4 && arrayCurrentTableTrack [connectPrevious2*2] > arrayPreviousTableTrack [counterY*2]*0.6 && arrayCurrentTableTrack [connectPrevious2*2] <= arrayPreviousTableTrack [counterY*2]*1.3){
                                            passFlag2 = 1, newMainNumber = connectPrevious2;
                                            break;
                                        }
                                        if (arrayCurrentAverageTrack [connectPrevious2] <= cutOff4 && arrayCurrentTableTrack [connectPrevious2*2] > arrayPreviousTableTrack [counterY*2]*0.6 && arrayCurrentTableTrack [connectPrevious2*2] <= arrayPreviousTableTrack [counterY*2]*1.4){
                                            passFlag2 = 1, newMainNumber = connectPrevious2;
                                            break;
                                        }
                                        if (arrayCurrentAverageTrack [connectPrevious2] > cutOff2 && arrayCurrentTableTrack [connectPrevious2*2] > arrayPreviousTableTrack [counterY*2]*0.4 && arrayCurrentTableTrack [connectPrevious2*2] <= arrayPreviousTableTrack [counterY*2]){
                                            passFlag2 = 1, newMainNumber = connectPrevious2;
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            if (passFlag2 == 1){
                                for (int counterX = 0; counterX < maxEntryTemp; counterX++){
                                    numberTemp [counterX] = 0;
                                    overlapDataTemp [counterX] = 0;
                                    overlapIntensityTemp [counterX] = 0;
                                    overlapPercentTemp [counterX] = 0;
                                }
                                
                                for (int counterX = 0; counterX < maxEntryTemp; counterX++){
                                    if (newMainNumber != overlapNumber2 [counterY][counterX]){
                                        numberTemp [counterX] = overlapNumber2 [counterY][counterX];
                                        overlapDataTemp [counterX] = overlapData2 [counterY][counterX];
                                        overlapIntensityTemp [counterX] = overlapIntensity2 [counterY][counterX];
                                        overlapPercentTemp [counterX] = overlapPercent2 [counterY][counterX];
                                    }
                                }
                                
                                overlapNumber2 [counterY][0] = overlapNumber2 [counterY][mainNumberCount];
                                overlapData2 [counterY][0] = overlapData2 [counterY][mainNumberCount];
                                overlapIntensity2 [counterY][0] = overlapIntensity2 [counterY][mainNumberCount];
                                overlapPercent2 [counterY][0] = overlapPercent2 [counterY][mainNumberCount];
                                entryCount = 1;
                                
                                for (int counterX = 0; counterX < maxEntryTemp; counterX++){
                                    if (numberTemp [counterX] != 0){
                                        overlapNumber2 [counterY][entryCount] = numberTemp [counterX];
                                        overlapData2 [counterY][entryCount] = overlapDataTemp [counterX];
                                        overlapIntensity2 [counterY][entryCount] = overlapIntensityTemp [counterX];
                                        overlapPercent2 [counterY][entryCount] = overlapPercentTemp [counterX];
                                        entryCount++;
                                    }
                                }
                            }
                        }
                    }
                    
                    delete [] numberTemp;
                    delete [] overlapDataTemp;
                    delete [] overlapIntensityTemp;
                    delete [] overlapPercentTemp;
                    
                    //for (int counterA = 1; counterA < lineNumberPrevious+1; counterA++){
                    //	for (int counterB = 0; counterB < maxTargetEntry; counterB++){
                    //		cout<<counterA<<" "<<counterB<<" Area2 "<<overlapData2 [counterA][counterB]<<" Intensity "<<overlapIntensity2 [counterA][counterB];
                    //        cout<<" Percent "<<overlapPercent2 [counterA][counterB]<<" Number "<<overlapNumber2 [counterA][counterB]<<" Overlap First5"<<endl;
                    //	}
                    //}
                    
                    errorNoHold = 27;
                    arrayOverlapNumberTrack = new int [lineNumberPrevious*maxEntryTemp*3+10];
                    int overlapNumberCount = 0;
                    errorNoHold = 28;
                    arrayOverlapPixelAreaTrack = new int [lineNumberPrevious*maxEntryTemp*3+10];
                    int overlapPixelAreaCount = 0;
                    errorNoHold = 29;
                    arrayOverlapPixelIntensityTrack = new int [lineNumberPrevious*maxEntryTemp*3+10];
                    int overlapPixelIntensityCount = 0;
                    errorNoHold = 30;
                    arrayOverlapPercentTrack = new int [lineNumberPrevious*maxEntryTemp*3+10];
                    int overlapPercentCount = 0;
                    
                    for (int counterY = 1; counterY < lineNumberPrevious+1; counterY++){
                        entryCount = 1;
                        
                        arrayOverlapNumberTrack [overlapNumberCount] = counterY, overlapNumberCount++;
                        arrayOverlapNumberTrack [overlapNumberCount] = 0, overlapNumberCount++;
                        arrayOverlapNumberTrack [overlapNumberCount] = overlapNumber2 [counterY][0], overlapNumberCount++;
                        
                        arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = counterY, overlapPixelAreaCount++;
                        arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = 0, overlapPixelAreaCount++;
                        arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = overlapData2 [counterY][0], overlapPixelAreaCount++;
                        
                        arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = counterY, overlapPixelIntensityCount++;
                        arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = 0, overlapPixelIntensityCount++;
                        arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = overlapIntensity2 [counterY][0], overlapPixelIntensityCount++;
                        
                        arrayOverlapPercentTrack [overlapPercentCount] = counterY, overlapPercentCount++;
                        arrayOverlapPercentTrack [overlapPercentCount] = 0, overlapPercentCount++;
                        arrayOverlapPercentTrack [overlapPercentCount] = overlapPercent2 [counterY][0], overlapPercentCount++;
                        
                        for (int counterX = 1; counterX < maxEntryTemp; counterX++){
                            if (overlapNumber2 [counterY][counterX] > 0 && overlapData2 [counterY][counterX] > 10 && arrayCurrentTableTrack [overlapNumber2 [counterY][counterX]*2] > 0 && arrayCurrentTableTrack [overlapNumber2 [counterY][counterX]*2+1] > 0){
                                arrayOverlapNumberTrack [overlapNumberCount] = counterY, overlapNumberCount++;
                                arrayOverlapNumberTrack [overlapNumberCount] = entryCount, overlapNumberCount++;
                                arrayOverlapNumberTrack [overlapNumberCount] = overlapNumber2 [counterY][counterX], overlapNumberCount++;
                                
                                arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = counterY, overlapPixelAreaCount++;
                                arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = entryCount, overlapPixelAreaCount++;
                                arrayOverlapPixelAreaTrack [overlapPixelAreaCount] = overlapData2 [counterY][counterX], overlapPixelAreaCount++;
                                
                                arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = counterY, overlapPixelIntensityCount++;
                                arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = entryCount, overlapPixelIntensityCount++;
                                arrayOverlapPixelIntensityTrack [overlapPixelIntensityCount] = overlapIntensity2 [counterY][counterX], overlapPixelIntensityCount++;
                                
                                arrayOverlapPercentTrack [overlapPercentCount] = counterY, overlapPercentCount++;
                                arrayOverlapPercentTrack [overlapPercentCount] = entryCount, overlapPercentCount++;
                                arrayOverlapPercentTrack [overlapPercentCount] = overlapPercent2 [counterY][counterX], overlapPercentCount++;
                                
                                entryCount++;
                            }
                        }
                    }
                    
                    overlapNumberCountTrack = overlapNumberCount;
                    overlapPixelAreaCountTrack = overlapPixelAreaCount;
                    overlapPixelIntensityCountTrack = overlapPixelIntensityCount;
                    overlapPercentCountTrack = overlapPercentCount;
                    
                    //for (int counterA = 0; counterA < overlapNumberCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapNumberTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapNumberTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < overlapPixelAreaCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelAreaTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapPixelAreaTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < overlapPixelIntensityCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelIntensityTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapPixelIntensityTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < overlapPercentCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPercentTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapPercentTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 1; counterA < lineNumberPrevious+1; counterA++){
                    //	for (int counterB = 0; counterB < maxTargetEntry; counterB++){
                    //		cout<<counterA<<" "<<counterB<<" Area2 "<<overlapData2 [counterA][counterB]<<" Intensity "<<overlapIntensity2 [counterA][counterB];
                    //        cout<<" Percent "<<overlapPercent2 [counterA][counterB]<<" Number "<<overlapNumber2 [counterA][counterB]<<" Overlap First4"<<endl;
                    //	}
                    //}
                    
                    for (int counter1 = 0; counter1 < lineNumberPrevious+1; counter1++){
                        delete [] overlapNumber2 [counter1];
                        delete [] overlapData2 [counter1];
                        delete [] overlapIntensity2 [counter1];
                        delete [] overlapPercent2 [counter1];
                    }
                    
                    delete [] overlapNumber2;
                    delete [] overlapData2;
                    delete [] overlapIntensity2;
                    delete [] overlapPercent2;
                    
                    //for (int counterA = 0; counterA < overlapPixelIntensityCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelIntensityTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapPixelIntensityTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                    //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                    //}
                    
                    //------Gravity center------
                    //*********1. X position, 2. Y position, 3. Total pix, 4. Average, 5. Connect No, 6. Target*********
                    
                    errorNoHold = 31;
                    int *arrayCellTrackingCurrentTemp2 = new int [xyPositionCenterCurrentCount+50];
                    int cellTrackingCurrentTempCount2 = 0;
                    
                    for (int counter1 = 0; counter1 < xyPositionCenterCurrentCount/6; counter1++){
                        if (arrayCurrentTableTrack [arrayXYPositionCenterCurrent [counter1*6+4]*2] != 0){
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterCurrent [counter1*6], cellTrackingCurrentTempCount2++;
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterCurrent [counter1*6+1], cellTrackingCurrentTempCount2++;
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterCurrent [counter1*6+2], cellTrackingCurrentTempCount2++;
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterCurrent [counter1*6+3], cellTrackingCurrentTempCount2++;
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterCurrent [counter1*6+4], cellTrackingCurrentTempCount2++;
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterCurrent [counter1*6+5], cellTrackingCurrentTempCount2++;
                        }
                    }
                    
                    if (xyPositionCenterCurrentStatus == 0){
                        errorNoHold = 32;
                        arrayXYPositionCenterCurrent = new int [cellTrackingCurrentTempCount2*3+50];
                        xyPositionCenterCurrentCount = 0;
                        xyPositionCenterCurrentStatus = 1;
                        xyPositionCenterCurrentSizeHold = cellTrackingCurrentTempCount2*3+50;
                    }
                    else if (xyPositionCenterCurrentStatus == 1 && xyPositionCenterCurrentSizeHold < cellTrackingCurrentTempCount2){
                        delete [] arrayXYPositionCenterCurrent;
                        
                        errorNoHold = 33;
                        arrayXYPositionCenterCurrent = new int [cellTrackingCurrentTempCount2*3+50];
                        xyPositionCenterCurrentCount = 0;
                        xyPositionCenterCurrentSizeHold = cellTrackingCurrentTempCount2*3+50;
                    }
                    else xyPositionCenterCurrentCount = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingCurrentTempCount2; counter1++) arrayXYPositionCenterCurrent [xyPositionCenterCurrentCount] = arrayCellTrackingCurrentTemp2 [counter1], xyPositionCenterCurrentCount++;
                    
                    delete [] arrayCellTrackingCurrentTemp2;
                    
                    //for (int counterA = 0; counterA < overlapPixelIntensityCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelIntensityTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapPixelIntensityTrack "<<counterA<<endl;
                    //}
                    
                    errorNoHold = 34;
                    arrayCellTrackingCurrentTemp2 = new int [xyPositionCenterPreviousCount+50];
                    cellTrackingCurrentTempCount2 = 0;
                    
                    for (int counter1 = 0; counter1 < xyPositionCenterPreviousCount/6; counter1++){
                        if (arrayPreviousTableTrack [arrayXYPositionCenterPrevious [counter1*6+4]*2] != 0){
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterPrevious [counter1*6], cellTrackingCurrentTempCount2++;
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterPrevious [counter1*6+1], cellTrackingCurrentTempCount2++;
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterPrevious [counter1*6+2], cellTrackingCurrentTempCount2++;
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterPrevious [counter1*6+3], cellTrackingCurrentTempCount2++;
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterPrevious [counter1*6+4], cellTrackingCurrentTempCount2++;
                            arrayCellTrackingCurrentTemp2 [cellTrackingCurrentTempCount2] = arrayXYPositionCenterPrevious [counter1*6+5], cellTrackingCurrentTempCount2++;
                        }
                    }
                    
                    if (xyPositionCenterPreviousStatus == 0){
                        errorNoHold = 35;
                        arrayXYPositionCenterPrevious = new int [cellTrackingCurrentTempCount2*3+100];
                        xyPositionCenterPreviousCount = 0;
                        xyPositionCenterPreviousStatus = 1;
                        xyPositionCenterPreviousSizeHold = cellTrackingCurrentTempCount2*3+100;
                    }
                    else if (xyPositionCenterPreviousStatus == 1 && xyPositionCenterPreviousSizeHold < cellTrackingCurrentTempCount2){
                        delete [] arrayXYPositionCenterPrevious;
                        
                        errorNoHold = 36;
                        arrayXYPositionCenterPrevious = new int [cellTrackingCurrentTempCount2*3+100];
                        xyPositionCenterPreviousCount = 0;
                        xyPositionCenterPreviousSizeHold = cellTrackingCurrentTempCount2*3+100;
                    }
                    else xyPositionCenterPreviousCount = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingCurrentTempCount2; counter1++) arrayXYPositionCenterPrevious [xyPositionCenterPreviousCount] = arrayCellTrackingCurrentTemp2 [counter1], xyPositionCenterPreviousCount++;
                    
                    delete [] arrayCellTrackingCurrentTemp2;
                    
                    //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                    //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
                    //	cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                    //	cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingCurrentCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrent [counterA*6+counterB];
                    //	cout<<" arrayCellTrackingCurrent "<<counterA<<endl;
                    //}
                    
                    //------Line Data------
                    errorNoHold = 37;
                    int *arrayCellTrackingTemp = new int [cellTrackingCurrentCount+50];
                    int cellTrackingTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingCurrentCount/6; counter1++){
                        if (arrayCurrentTableTrack [arrayCellTrackingCurrent [counter1*6+3]*2] != 0){
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingCurrent [counter1*6], cellTrackingTempCount++;
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingCurrent [counter1*6+1], cellTrackingTempCount++;
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingCurrent [counter1*6+2], cellTrackingTempCount++;
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingCurrent [counter1*6+3], cellTrackingTempCount++;
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingCurrent [counter1*6+4], cellTrackingTempCount++;
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingCurrent [counter1*6+5], cellTrackingTempCount++;
                        }
                    }
                    
                    cellTrackingCurrentCount = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingTempCount; counter1++){
                        arrayCellTrackingCurrent [cellTrackingCurrentCount] = arrayCellTrackingTemp [counter1], cellTrackingCurrentCount++;
                    }
                    
                    delete [] arrayCellTrackingTemp;
                    errorNoHold = 38;
                    arrayCellTrackingTemp = new int [cellTrackingPreviousCount+50];
                    cellTrackingTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingPreviousCount/6; counter1++){
                        if (arrayPreviousTableTrack [arrayCellTrackingPrevious [counter1*6+3]*2] != 0){
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingPrevious [counter1*6], cellTrackingTempCount++;
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingPrevious [counter1*6+1], cellTrackingTempCount++;
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingPrevious [counter1*6+2], cellTrackingTempCount++;
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingPrevious [counter1*6+3], cellTrackingTempCount++;
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingPrevious [counter1*6+4], cellTrackingTempCount++;
                            arrayCellTrackingTemp [cellTrackingTempCount] = arrayCellTrackingPrevious [counter1*6+5], cellTrackingTempCount++;
                        }
                    }
                    
                    cellTrackingPreviousCount = 0;
                    for (int counter1 = 0; counter1 < cellTrackingTempCount; counter1++){
                        arrayCellTrackingPrevious [cellTrackingPreviousCount] = arrayCellTrackingTemp [counter1], cellTrackingPreviousCount++;
                    }
                    
                    delete [] arrayCellTrackingTemp;
                    
                    //for (int counterA = 0; counterA < overlapPixelIntensityCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelIntensityTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapPixelIntensityTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrevious [counterA*6+counterB];
                    //	cout<<" arrayCellTrackingPrevious "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingCurrentCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrent [counterA*6+counterB];
                    //	cout<<" arrayCellTrackingCurrent "<<counterA<<endl;
                    //}
                    
                    int findNumber = 0;
                    int findCount = 0;
                    int largestArea = 0;
                    int largestCount = 0;
                    
                    for (int counter1 = 1; counter1 < groupInfoCurrentCount/3+1; counter1++){ //-------If Current Table entry is "0", removing (making 0) of corresponding group list------
                        if (arrayCurrentTableTrack [counter1*2] == 0){
                            if (arrayGroupInfoCurrent [counter1*3] < 0) arrayGroupInfoCurrent [counter1*3] = 0; //-----if it < 0 (attached sub), make it 0-----
                            else{
                                
                                findNumber = 0;
                                findCount = 0;
                                
                                for (int counter2 = 1; counter2 < groupInfoCurrentCount/3+1; counter2++){
                                    if (arrayGroupInfoCurrent [counter2*3] == arrayGroupInfoCurrent [counter1*3]*-1){
                                        findCount = counter2;
                                        findNumber++;
                                    }
                                }
                                
                                if (findNumber == 1){
                                    arrayGroupInfoCurrent [counter1*3] = 0;
                                    arrayGroupInfoCurrent [findCount*3] = arrayGroupInfoCurrent [findCount*3]*-1; //-----If it > 0, and found one additional < -1, making 0 that correspond to > 0, and < 0 makes > 0 -----
                                }
                                if (findNumber > 1){ //------If there are more than one < 0, search largest one----
                                    largestArea = 0;
                                    largestCount = 0;
                                    
                                    for (int counter2 = 1; counter2 < groupInfoCurrentCount/3+1; counter2++){
                                        if (arrayGroupInfoCurrent [counter2*3] == arrayGroupInfoCurrent [counter1*3]*-1){
                                            if (largestArea < arrayCurrentTableTrack [counter2*2]){
                                                largestArea = arrayCurrentTableTrack [counter2*2];
                                                largestCount = counter2;
                                            }
                                        }
                                    }
                                    
                                    arrayGroupInfoCurrent [counter1*3] = 0; //-----Make > 0 to 0
                                    arrayGroupInfoCurrent [largestCount*3] = arrayGroupInfoCurrent [largestCount*3]*-1; //------Make largest < 0 to > 0----------
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < groupInfoCurrentCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayGroupInfoCurrent [counterA*3+counterB];
                    //	cout<<" arrayGroupInfoCurrent "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < overlapPixelIntensityCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelIntensityTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapPixelIntensityTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                    //	cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 1; counterA < lineNumberPrevious+1; counterA ++){
                    //	cout<<" TotalPoint "<<arrayPreviousTableTrack [counterA*2]<<" ConnNO "<<arrayPreviousTableTrack [counterA*2+1]<<" TotalValue "<<arrayPreviousTableTrackTotal [counterA]<<
                    //	" Average "<<arrayPreviousAverageTrack [counterA]<<" PreTable First6 "<<endl;
                    //}
                    
                    if (roundStatus == 2){
                        string cellLineageExtract = cellLineageNoHold.substr(1);
                        string cellNumberExtract = cellNoHold.substr(1);
                        int cellLineageTempInt = atoi(cellLineageExtract.c_str());
                        int cellNumberTempInt = atoi(cellNumberExtract.c_str());
                        
                        eventSequenceCount = 0;
                        
                        int occupyCheck = 0;
                        
                        for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                            if (imageNumberInt >= arrayLineageStartEnd [counter1*8+5] && imageNumberInt <= arrayLineageStartEnd [counter1*8+7] && cellLineageTempInt == arrayLineageStartEnd [counter1*8] && cellNumberTempInt == arrayLineageStartEnd [counter1*8+1]){
                                
                                for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                                    if (arrayLineageData [counter2*8+2] == imageNumberInt){
                                        arrayEventSequence [0] = arrayLineageData [counter2*8+2], eventSequenceCount++;
                                        arrayEventSequence [1] = arrayLineageData [counter2*8+3], eventSequenceCount++;
                                        arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++;
                                        arrayEventSequence [eventSequenceCount] = cellNumberTempInt, eventSequenceCount++;
                                        break;
                                    }
                                }
                            }
                            if (occupyCheck == 1){
                                break;
                            }
                        }
                        
                        // for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
                        // 	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
                        // 	cout<<" arrayEventSequence "<<counterA<<endl;
                        //}
                        
                        for (int counter1 = 1; counter1 < groupInfoPreviousCount/5+1; counter1++){ //------If previous Table is O, modify Group table, if "0" correspond to "1, 2, 3", search -1, -2 etc, then, change to 1, 2, 3.
                            if (arrayPreviousTableTrack [counter1*2] == 0){
                                if (arrayGroupInfoPrevious [counter1*5] < 0) arrayGroupInfoPrevious [counter1*5] = 0;
                                else{
                                    
                                    findNumber = 0;
                                    findCount = 0;
                                    
                                    for (int counter2 = 1; counter2 < groupInfoPreviousCount/5+1; counter2++){
                                        if (arrayGroupInfoPrevious [counter2*5] == arrayGroupInfoPrevious [counter1*5]*-1){
                                            findCount = counter2;
                                            findNumber++;
                                        }
                                    }
                                    
                                    if (findNumber == 1){
                                        arrayGroupInfoPrevious [counter1*5] = 0;
                                        arrayGroupInfoPrevious [findCount*5] = arrayGroupInfoPrevious [findCount*5]*-1;
                                    }
                                    if (findNumber > 1){
                                        largestArea = 0;
                                        largestCount = 0;
                                        
                                        for (int counter2 = 1; counter2 < groupInfoPreviousCount/5+1; counter2++){
                                            if (arrayGroupInfoPrevious [counter2*5] == arrayGroupInfoPrevious [counter1*5]*-1){
                                                if (largestArea < arrayPreviousTableTrack [counter2*2]){
                                                    largestArea = arrayPreviousTableTrack [counter2*2];
                                                    largestCount = counter2;
                                                }
                                            }
                                        }
                                        
                                        arrayGroupInfoPrevious [counter1*5] = 0;
                                        arrayGroupInfoPrevious [largestCount*5] = arrayGroupInfoPrevious [largestCount*5]*-1;
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < groupInfoPreviousCount/5; counterA++){
                        //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayGroupInfoPrevious [counterA*5+counterB];
                        //    cout<<" arrayGroupInfoPrevious "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < overlapPixelIntensityCount/3; counterA++){
                        //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelIntensityTrack [counterA*3+counterB];
                        //	cout<<" arrayOverlapPixelIntensityTrack "<<counterA<<endl;
                        //}
                        
                        int findCellStatus = 0;
                        int findLingNo = 0;
                        
                        for (int counter1 = 0; counter1 < connectNoHoldCount; counter1++){
                            findCellStatus = 0;
                            findLingNo = 0;
                            
                            for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                                if ((arrayTimeSelected [counter2*10] == 7 || arrayTimeSelected [counter2*10] == 1) && arrayTimeSelected [counter2*10+8] == connectNoHold [counter1]){
                                    findLingNo = arrayTimeSelected [counter2*10+9];
                                    
                                    if (arrayTimeSelected [counter2*10] == 7) findCellStatus = 1;
                                    else if (arrayTimeSelected [counter2*10] == 1) findCellStatus = 2;
                                    break;
                                }
                            }
                            
                            if (findLingNo != 0){
                                if (findCellStatus == 1) arrayGroupInfoPrevious [counter1*5+4] = 2000; //------Done------
                                else if (findCellStatus == 2) arrayGroupInfoPrevious [counter1*5+4] = 1001; //------Done------
                            }
                        }
                        
                        int groupInvert = 0;
                        
                        for (int counter1 = 0; counter1 < groupInfoPreviousCount/5; counter1++){
                            if (targetPointerTrack == counter1+1 && arrayGroupInfoPrevious [counter1*5] < 0) groupInvert = arrayGroupInfoPrevious [counter1*5]*-1;
                        }
                        
                        if (groupInvert != 0){
                            for (int counter1 = 0; counter1 < groupInfoPreviousCount/5; counter1++){
                                if (targetPointerTrack == counter1+1 && arrayGroupInfoPrevious [counter1*5] < 0) arrayGroupInfoPrevious [counter1*5] = groupInvert;
                                else if (arrayGroupInfoPrevious [counter1*5] == groupInvert) arrayGroupInfoPrevious [counter1*5] = groupInvert*-1;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < groupInfoPreviousCount/5; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayGroupInfoPrevious [counterA*5+counterB];
                    //    cout<<" arrayGroupInfoPrevious "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < overlapPixelIntensityCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelIntensityTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapPixelIntensityTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < overlapPixelIntensityCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelIntensityTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapPixelIntensityTrack "<<counterA<<endl;
                    //}
                    
                    if (roundStatus > 2){
                        //for (int counterA = 0; counterA < groupInfoPreviousCount/5; counterA++){
                        //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayGroupInfoPrevious [counterA*5+counterB];
                        //    cout<<" arrayGroupInfoPrevious "<<counterA<<endl;
                        //}
                        
                        for (int counter1 = 0; counter1 < groupInfoPreviousCount/5; counter1++) arrayGroupInfoPrevious [counter1*5+4] = -1;
                        
                        //for (int counterA = 0; counterA < groupInfoPreviousCount/5; counterA++){
                        //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayGroupInfoPrevious [counterA*5+counterB];
                        //    cout<<" arrayGroupInfoPrevious "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
                        //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
                        //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
                        //}
                        
                        //for (int counter1 = 0; counter1 < connectNoHoldCount; counter1++)cout<<connectNoHold [counter1]<<" NumberHold"<<endl;
                        
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (arrayCellTrackingTable [counter1*15] == roundStatus-1){
                                for (int counter2 = 0; counter2 < connectNoHoldCount; counter2++){
                                    if (connectNoHold [counter2] == arrayCellTrackingTable [counter1*15+10]){
                                        arrayGroupInfoPrevious [counter2*5+3] = arrayCellTrackingTable [counter1*15+8];
                                        arrayGroupInfoPrevious [counter2*5+4] = arrayCellTrackingTable [counter1*15+14];
                                        break;
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < groupInfoPreviousCount/5; counterA++){
                        //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayGroupInfoPrevious [counterA*5+counterB];
                        //    cout<<" arrayGroupInfoPrevious "<<counterA<<endl;
                        //}
                        
                        int findFlag = 0;
                        int findCellStatus = 0;
                        
                        for (int counter1 = 0; counter1 < groupInfoPreviousCount/5; counter1++){
                            if (arrayGroupInfoPrevious [counter1*5+4] == -1){
                                findFlag = 0;
                                findCellStatus = 0;
                                
                                for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                                    if ((arrayTimeSelected [counter2*10] == 7 || arrayTimeSelected [counter2*10] == 1) && arrayTimeSelected [counter2*10+8] == connectNoHold [counter1]){
                                        findFlag = 1;
                                        
                                        if (arrayTimeSelected [counter2*10] == 7) findCellStatus = 1;
                                        else if (arrayTimeSelected [counter2*10] == 1) findCellStatus = 2;
                                        break;
                                    }
                                }
                                
                                if (findFlag == 1){
                                    if (findCellStatus == 1) arrayGroupInfoPrevious [counter1*5+4] = 2000; //------Done------
                                    else if (findCellStatus == 2){
                                        if (connectNoHold [counter1] == targetConnectInitial){
                                            for (int counter2 = 0; counter2 < cellTrackingTableCount/15; counter2++){
                                                if (arrayCellTrackingTable [counter2*15] == roundStatus-2 && arrayCellTrackingTable [counter2*15+7] == 1){
                                                    if (arrayCellTrackingTable [counter2*15+14] == 2000) arrayGroupInfoPrevious [counter1*5+4] = 2000;
                                                    else arrayGroupInfoPrevious [counter1*5+4] = arrayCellTrackingTable [counter2*15+14]+1;
                                                    break;
                                                }
                                            }
                                        }
                                        else arrayGroupInfoPrevious [counter1*5+4] = 1001; //------Done------
                                    }
                                }
                                else arrayGroupInfoPrevious [counter1*5+4] = 1;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < groupInfoPreviousCount/5; counterA++){
                    //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayGroupInfoPrevious [counterA*5+counterB];
                    //	cout<<" arrayGroupInfoPrevious "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingCurrentAssCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrentAss [counterA*6+counterB];
                    //	cout<<" arrayCellTrackingCurrentAss "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                    //  	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                    // 	cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingCurrentCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrent [counterA*6+counterB];
                    //	cout<<" arrayCellTrackingCurrent "<<counterA<<endl;
                    //}
                    
                    // for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
                    //	cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
                    //}
                    
                    errorNoHold = 39;
                    int **arrayCellTrackingPreviousMapHold2 = new int *[trackAreaSize+1];
                    
                    for (int counter1 = 0; counter1 < trackAreaSize+1; counter1++){
                        errorNoHold = 40;
                        arrayCellTrackingPreviousMapHold2 [counter1] = new int [trackAreaSize+1];
                    }
                    
                    for (int counterY = 0; counterY < trackAreaSize; counterY++){
                        for (int counterX = 0; counterX < trackAreaSize; counterX++){
                            arrayCellTrackingPreviousMapHold2 [counterY][counterX] = arrayCellTrackingPreviousMap [counterY][counterX];
                        }
                    }
                    
                    int targetPointerHold = targetPointerTrack;
                    
                    //==========Previous Process==========
                    int roundTwo = 1;
                    targetPrevious = [[TargetPrevious alloc] init];
                    [targetPrevious targetPreviousMain:roundTwo];
                    
                    do{
                    } while (subCompletionFlag2 == 1);
                    
                    if (errorNoHold != 0){
                        errorNoHold = errorNoHold+2000;
                        throw errorCheckThrow;
                    }
                    
                    //cout<<p_variablesSet -> _maxTargetEntry<<" "<<p_variablesSet ->_targetPointer<<" Target2"<<endl;
                    
                    //for (int counterA = 0; counterA < groupInfoCurrentCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayGroupInfoCurrent [counterA*3+counterB];
                    //    cout<<" arrayGroupInfoCurrent "<<counterA<<endl;
                    // }
                    
                    //for (int counterA = 0; counterA < groupInfoPreviousCount/5; counterA++){
                    //  for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayGroupInfoPrevious [counterA*5+counterB];
                    //   cout<<" arrayGroupInfoPrevious "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrevious [counterA*6+counterB];
                    //	cout<<" arrayCellTrackingPrevious "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                    //	cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingCurrentCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrent [counterA*6+counterB];
                    //	cout<<" arrayCellTrackingCurrent "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
                    //	cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingCurrentAssCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrentAss [counterA*6+counterB];
                    //	cout<<" arrayCellTrackingCurrentAss "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingPreviousAssCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPreviousAss [counterA*6+counterB];
                    //	cout<<" arrayCellTrackingPreviousAss "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < p_variablesSet ->_overlapNumberCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapNumberTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapNumberTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < p_variablesSet ->_overlapPixelIntensityCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelIntensityTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapPixelIntensityTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < p_variablesSet ->_overlapPixelAreaCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPixelAreaTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapPixelAreaTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < p_variablesSet ->_overlapPercentCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayOverlapPercentTrack [counterA*3+counterB];
                    //	cout<<" arrayOverlapPercentTrack "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrevious [counterA*6+counterB];
                    //    cout<<" arrayCellTrackingPrevious "<<counterA<<endl;
                    //}
                    
                    // cout<<p_variablesSet ->_targetPointer<<" Target_Current"<<endl;
                    
                    //==========Current process==========
                    errorNoHold = 41;
                    arrayNoMergeTableTrack = new int [500];
                    noMergeTableCountTrack = 0;
                    noMergeTableLimitTrack = 500;
                    
                    targetCurrent = [[TargetCurrent alloc] init];
                    [targetCurrent targetCurrentMain:roundTwo];
                    
                    do{
                    } while (subCompletionFlag2 == 1);
                    
                    if (errorNoHold != 0){
                        errorNoHold = errorNoHold+2000;
                        throw errorCheckThrow;
                    }
                    
                    int maxConnectNumberList = timeSelectedCount/10;
                    
                    //=======Next find=======
                    errorNoHold = 42;
                    int *connectNextTargetGet = new int [maxConnectNumberList+1];
                    
                    for (int counter1 = 0; counter1 < maxConnectNumberList+1; counter1++) connectNextTargetGet [counter1] = 0;
                    
                    for (int counterY = 0; counterY < trackAreaSize; counterY++){
                        for (int counterX = 0; counterX < trackAreaSize; counterX++){
                            if (arrayCellTrackingPreviousMapHold2 [counterY][counterX] == targetPointerHold){
                                if (arrayCellTrackingPreviousMap [counterY][counterX] != 0){
                                    connectNextTargetGet [arrayCellTrackingPreviousMap [counterY][counterX]]++;
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                    //	for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingCurrentMap [counterA][counterB];
                    //	cout<<" arrayCellTrackingCurrentMap "<<counterA<<endl;
                    //}
                    
                    //for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                    //    cout<<counter1<<" "<<connectNextTargetGet [counter1]<<" connectNextTargetGet"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < connectLineageRelCurrentCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRelCurrent [counterA*6+counterB];
                    // 	cout<<" arrayConnectLineageRelCurrent "<<counterA<<endl;
                    // }
                    
                    int largestConfirm = 0;
                    int largestConfirmCount = 0;
                    
                    for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                        if (connectNextTargetGet [counter1] > largestConfirm){
                            largestConfirm = connectNextTargetGet [counter1];
                            largestConfirmCount = counter1;
                        }
                    }
                    
                    if (largestConfirmCount != targetPointerTrack){
                        for (int counter1 = 0; counter1 < xyPositionCenterPreviousCount/6; counter1++){
                            if (arrayXYPositionCenterPrevious [counter1*6+4] == targetPointerTrack) arrayXYPositionCenterPrevious [counter1*6+5] = 0;
                            
                            if (arrayXYPositionCenterPrevious [counter1*6+4] == largestConfirmCount) arrayXYPositionCenterPrevious [counter1*6+5] = 1;
                        }
                        
                        targetPointerTrack = largestConfirmCount;
                    }
                    
                    //for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                    //    cout<<counter1<<" "<<connectNextTargetGet [counter1]<<" connectNextTargetGet"<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < trackAreaSize+1; counter1++) delete [] arrayCellTrackingPreviousMapHold2 [counter1];
                    
                    delete [] arrayCellTrackingPreviousMapHold2;
                    delete [] arrayOverlapNumberTrack;
                    delete [] arrayOverlapPixelAreaTrack;
                    delete [] arrayOverlapPixelIntensityTrack;
                    delete [] arrayOverlapPercentTrack;
                    delete [] arrayNoMergeTableTrack;
                    delete [] connectNextTargetGet;
                }
                else trackHoldFlag = 4000; //===========Loading error============
                
                for (int counter1 = 0; counter1 < lineNumberPrevious+1; counter1++){
                    delete [] overlapData [counter1];
                    delete [] overlapIntensity [counter1];
                    delete [] overlapPercent [counter1];
                }
                
                delete [] overlapData;
                delete [] overlapIntensity;
                delete [] overlapPercent;
                
                delete [] arrayPreviousTableTrack;
                delete [] arrayPreviousTableTrackTotal;
                delete [] arrayPreviousAverageTrack;
                delete [] arrayCurrentTableTrack;
                delete [] arrayCurrentTableTrackTotal;
                delete [] arrayCurrentAverageTrack;
                delete [] currentSD;
                delete [] currentTotalForSD;
            }
            else trackHoldFlag = 3000;
            
            errorNoHold = 0;
            subCompletionFlag = 0;
        }
        catch (int errorCheckThrow){
            if (errorNoHold == 0) errorNoHold = 1000;
            
            subCompletionFlag = 0;
        }
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingTargetTrack "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"TargetTrack"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
        
        subCompletionFlag = 0;
    }
    
    return targetPointerTrack;
}

@end
