//
// TargetCurrent.h
// cell_carving
//
// Created by Masahiko Sato on 13/06/04.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef TARGETCURRENT_H
#define TARGETCURRENT_H
#import "Controller.h"
#endif

@interface TargetCurrent : NSObject{
    id tableInterpretation;
    id gapFill;
}

-(void)targetCurrentMain:(int)roundTwo;

@end
