//
// TrackingSetCurrent.h
// Cell_Carving
//
// Created by Masahiko Sato on 15/12/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef TRACKINGSETCURRENT_H
#define TRACKINGSETCURRENT_H
#import "Controller.h"
#endif

@interface TrackingSetCurrent : NSObject{
}

-(void)trackingSetCurrentMain:(int)processTime;
-(void)associatedDataCurrUpDate;
-(void)gravityCenterRevCurrentUpDate;

@end
