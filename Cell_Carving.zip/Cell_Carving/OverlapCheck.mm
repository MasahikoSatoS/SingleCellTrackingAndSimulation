//
//  OverlapCheck.m
//  Cell_Carving
//
//  Created by Masahiko Sato on 2015-05-20.
//
//

#import "OverlapCheck.h"

@implementation OverlapCheck

-(void)overlapCheckMain :(int)cutOffAdjust{
    try{
        try{
            
            errorNoHold = 0;
            int errorCheckThrow = 0;
            subCompletionFlag = 1;
            
            string connectDataRevPath;
            string connectStatusDataPath;
            string connectRelationPath;
            string mapTempPath;
            string extension;
            string cellLineageExtract = cellLineageNoHold.substr(1);
            string cellNumberExtract = cellNoHold.substr(1);
            int cellLineageTempInt = atoi(cellLineageExtract.c_str());
            int cellNumberTempInt = atoi(cellNumberExtract.c_str());
            
            struct stat sizeOfFile;
            
            ifstream fin;
            
            long sizeForCopy = 0;
            
            if ((roundStatus == 2 && imageNumberInt == timeEventEntryHold) || (roundStatus == 2 && imageNumberInt > timeEventEntryHold && cellStatusLoading == 1)){
                extension = to_string(imageNumberInt);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                connectDataRevPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"07_Cell_Tracking_Data"+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                connectStatusDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"07_Cell_Tracking_Data"+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
                connectRelationPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"07_Cell_Tracking_Data"+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
            }
            else if (roundStatus == 2 && imageNumberInt > timeEventEntryHold && cellStatusLoading == 0){
                extension = to_string(imageNumberInt-1);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                connectDataRevPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"07_Cell_Tracking_Data"+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                connectStatusDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"07_Cell_Tracking_Data"+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
                connectRelationPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"07_Cell_Tracking_Data"+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
                mapTempPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"07_Cell_Tracking_Data"+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_RevisedMap";
            }
            else if (roundStatus > 2){
                extension = to_string(imageNumberInt-1);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                connectDataRevPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"07_Cell_Tracking_Data"+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_MasterDataTemp";
                connectStatusDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"07_Cell_Tracking_Data"+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_StatusTemp";
                connectRelationPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"07_Cell_Tracking_Data"+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ConnectLineageRelTemp";
            }
            
            long size1 = 0;
            long size2 = 0;
            int checkFlag = 0;
            
            for (int counter1 = 0; counter1 < 6; counter1++){
                sizeForCopy = 0;
                
                if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter1 == 0) size1 = sizeForCopy;
                    else if (counter1 == 1) size2 = sizeForCopy;
                    else if (counter1 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter1 == 3) size1 = sizeForCopy;
                    else if (counter1 == 4) size2 = sizeForCopy;
                    else if (counter1 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            if (checkFlag == 0){
                errorNoHold = 1000;
                throw errorCheckThrow;
            }
            
            if (checkFlag == 1){
                errorNoHold = 1;
                int *arrayPositionReviseTemp = new int [sizeForCopy+50];
                int positionReviseTempCount = 0;
                
                long sizeForCopy2 = (long)(sizeForCopy*(double)0.1)+50;
                errorNoHold = 2;
                int *arrayGravityCenterRevTemp = new int [sizeForCopy2*2+50];
                int gravityCenterRevTempCount = 0;
                int gravityCenterRevTempLimit = (int)sizeForCopy2*2+50;
                
                fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    int finData [17];
                    
                    errorNoHold = 3;
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                errorNoHold = 1001;
                                throw errorCheckThrow;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++;
                            finData [11] = uploadTemp [readPosition], readPosition++;
                            finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                            finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                            finData [14] = uploadTemp [readPosition], readPosition++;
                            finData [15] = uploadTemp [readPosition], readPosition++;
                            finData [16] = uploadTemp [readPosition], readPosition++; //--7 Ling no
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            
                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                            
                            finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                            else{
                                
                                arrayPositionReviseTemp [positionReviseTempCount] = finData [1], positionReviseTempCount++;
                                arrayPositionReviseTemp [positionReviseTempCount] = finData [3], positionReviseTempCount++;
                                arrayPositionReviseTemp [positionReviseTempCount] = finData [4], positionReviseTempCount++;
                                arrayPositionReviseTemp [positionReviseTempCount] = finData [7], positionReviseTempCount++;
                                arrayPositionReviseTemp [positionReviseTempCount] = finData [12], positionReviseTempCount++;
                                arrayPositionReviseTemp [positionReviseTempCount] = finData [13], positionReviseTempCount++;
                                arrayPositionReviseTemp [positionReviseTempCount] = finData [16], positionReviseTempCount++;
                            }
                        }
                        else if (stepCount == 1){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++;
                            finData [9] = uploadTemp [readPosition], readPosition++; //--5
                            finData [10] = uploadTemp [readPosition], readPosition++; //--6
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            finData [9] = finData [8]*256+finData [9];
                            
                            if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                        }
                        else if (stepCount == 2){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++; //--3
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++;
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++; //--5
                            finData [11] = uploadTemp [readPosition], readPosition++; //--6
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                            else{
                                
                                if (gravityCenterRevTempCount+1 > gravityCenterRevTempLimit){
                                    errorNoHold = 4;
                                    int *arrayUpDate = new int [gravityCenterRevTempCount+10];
                                    
                                    for (int counter1 = 0; counter1 < gravityCenterRevTempCount; counter1++) arrayUpDate [counter1] = arrayGravityCenterRev [counter1];
                                    
                                    delete [] arrayGravityCenterRevTemp;
                                    errorNoHold = 5;
                                    arrayGravityCenterRevTemp = new int [gravityCenterRevTempLimit+2000];
                                    gravityCenterRevTempLimit = gravityCenterRevTempLimit+2000;
                                    
                                    for (int counter1 = 0; counter1 < gravityCenterRevTempCount; counter1++) arrayGravityCenterRevTemp [counter1] = arrayUpDate [counter1];
                                    delete [] arrayUpDate;
                                }
                                
                                arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [1], gravityCenterRevTempCount++;
                                arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [3], gravityCenterRevTempCount++;
                                arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [6], gravityCenterRevTempCount++;
                                arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [7], gravityCenterRevTempCount++;
                                arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [10], gravityCenterRevTempCount++;
                                arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [11], gravityCenterRevTempCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    errorNoHold = 1002;
                    throw errorCheckThrow;
                }
                
                //for (int counterA = 0; counterA < positionReviseTempCount/7; counterA++){
                //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionReviseTemp [counterA*7+counterB];
                //	cout<<" arrayPositionReviseTemp "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < associatedDataCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayAssociatedData [counterA*6+counterB];
                //	cout<<" arrayAssociatedData "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < gravityCenterRevTempCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRevTemp [counterA*6+counterB];
                //	cout<<" arrayGravityCenterRevTemp "<<counterA<<endl;
                //}
                
                if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                else{
                    
                    errorNoHold = 1003;
                    throw errorCheckThrow;
                }
                
                if (sizeForCopy < gravityCenterRevTempCount*2) sizeForCopy = gravityCenterRevTempCount*2;
                
                errorNoHold = 6;
                int *arrayTimeSelectedTemp = new int [sizeForCopy+50];
                int timeSelectedTempCount = 0;
                
                fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    int finData [19];
                    
                    errorNoHold = 7;
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                            errorNoHold = 1004;
                            throw errorCheckThrow;
                        }
                    }
                    
                    fin.close();
                    
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                            finData [7] = uploadTemp [readPosition], readPosition++;
                            finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                            finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                            finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                            finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                            finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                            finData [13] = uploadTemp [readPosition], readPosition++;
                            finData [14] = uploadTemp [readPosition], readPosition++;
                            finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                            finData [16] = uploadTemp [readPosition], readPosition++;
                            finData [17] = uploadTemp [readPosition], readPosition++;
                            finData [18] = uploadTemp [readPosition], readPosition++; //--11 Ling no
                            
                            finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            finData [8] = finData [7]*256+finData [8];
                            finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                            finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                            
                            if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                            else{
                                
                                arrayTimeSelectedTemp [timeSelectedTempCount] = finData [0], timeSelectedTempCount++; //------Selected, removed, eliminated status------
                                arrayTimeSelectedTemp [timeSelectedTempCount] = finData [3], timeSelectedTempCount++; //------When new line is created, enter line number which creates------
                                arrayTimeSelectedTemp [timeSelectedTempCount] = finData [6], timeSelectedTempCount++; //------PositionRevise Start------
                                arrayTimeSelectedTemp [timeSelectedTempCount] = finData [8], timeSelectedTempCount++; //------Cut line number------
                                arrayTimeSelectedTemp [timeSelectedTempCount] = finData [9], timeSelectedTempCount++; //------X Start------
                                arrayTimeSelectedTemp [timeSelectedTempCount] = finData [10], timeSelectedTempCount++; //------X End------
                                arrayTimeSelectedTemp [timeSelectedTempCount] = finData [11], timeSelectedTempCount++; //------Y Start------
                                arrayTimeSelectedTemp [timeSelectedTempCount] = finData [12], timeSelectedTempCount++; //------Y End------
                                arrayTimeSelectedTemp [timeSelectedTempCount] = finData [15], timeSelectedTempCount++; //------Connect------
                                arrayTimeSelectedTemp [timeSelectedTempCount] = finData [18], timeSelectedTempCount++; //------Lineage------
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    errorNoHold = 1005;
                    throw errorCheckThrow;
                }
                
                //for (int counterA = 0; counterA < timeSelectedTempCount/10; counterA++){
                //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelectedTemp [counterA*10+counterB];
                //	cout<<" arrayTimeSelectedTemp "<<counterA<<endl;
                //}
                
                if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                else{
                    
                    errorNoHold = 1006;
                    throw errorCheckThrow;
                }
                
                errorNoHold = 8;
                int *arrayConnectLineageRelTemp = new int [sizeForCopy+50];
                int connectLineageRelTempCount = 0;
                
                fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    int finData [19];
                    
                    errorNoHold = 9;
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                            errorNoHold = 1007;
                            throw errorCheckThrow;
                        }
                    }
                    
                    fin.close();
                    
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Ling no
                            finData [3] = uploadTemp [readPosition], readPosition++;
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                            finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++;
                            finData [11] = uploadTemp [readPosition], readPosition++;
                            finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                            finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                            finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                            finData [7] = finData [6]*256+finData [7];
                            
                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                            
                            if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                            else{
                                
                                arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [2], connectLineageRelTempCount++;
                                arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [5], connectLineageRelTempCount++;
                                arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [7], connectLineageRelTempCount++;
                                arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [12], connectLineageRelTempCount++;
                                arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [13], connectLineageRelTempCount++;
                                arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [14], connectLineageRelTempCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    errorNoHold = 1008;
                    throw errorCheckThrow;
                }
                
                //for (int counterA = 0; counterA < connectLineageRelTempCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRelTemp [counterA*6+counterB];
                //	cout<<" arrayConnectLineageRelTemp "<<counterA<<endl;
                //}
                
                int connectNoCheck = 0;
                
                for (int counter1 = 0; counter1 < connectLineageRelTempCount/6; counter1++){
                    if (arrayConnectLineageRelTemp [counter1*6] == cellLineageTempInt && arrayConnectLineageRelTemp [counter1*6+3] == cellNumberTempInt){
                        connectNoCheck = arrayConnectLineageRelTemp [counter1*6+1];
                        break;
                    }
                }
                
                int cellDeterminationCheck = 0;
                
                for (int counter1 = 0; counter1 < timeSelectedTempCount/10; counter1++){
                    if (arrayTimeSelectedTemp [counter1*10+8] == connectNoCheck){
                        cellDeterminationCheck = arrayTimeSelectedTemp [counter1*10];
                        break;
                    }
                }
                
                int sourceAreaTemp = 0;
                int gravityCenterPrevX = 0;
                int gravityCenterPrevY = 0;
                
                for (int counter1 = 0; counter1 < gravityCenterRevTempCount/6; counter1++){
                    if (arrayGravityCenterRevTemp [counter1*6+4] == connectNoCheck){
                        sourceAreaTemp = arrayGravityCenterRevTemp [counter1*6+2];
                        gravityCenterPrevX = arrayGravityCenterRevTemp [counter1*6];
                        gravityCenterPrevY = arrayGravityCenterRevTemp [counter1*6+1];
                        break;
                    }
                }
                
                errorNoHold = 10;
                int *arrayReferenceLineTemp = new int [positionReviseTempCount+50];
                int referenceLineTempCount = 0;
                int referenceLineTempLimit = positionReviseTempCount+50;
                
                for (int counter1 = 0; counter1 < positionReviseTempCount/7; counter1++){
                    if (arrayPositionReviseTemp [counter1*7+3] == connectNoCheck){
                        if (referenceLineTempCount+2 > referenceLineLimit){
                            errorNoHold = 11;
                            int *arrayUpDate = new int [referenceLineTempCount+10];
                            
                            for (int counter2 = 0; counter2 < referenceLineTempCount; counter2++) arrayUpDate [counter2] = arrayReferenceLineTemp [counter2];
                            
                            delete [] arrayReferenceLineTemp;
                            errorNoHold = 12;
                            arrayReferenceLineTemp = new int [referenceLineTempLimit+5000];
                            referenceLineTempLimit = referenceLineTempLimit+5000;
                            
                            for (int counter2 = 0; counter2 < referenceLineTempCount; counter2++) arrayReferenceLineTemp [counter2] = arrayUpDate [counter2];
                            delete [] arrayUpDate;
                        }
                        
                        arrayReferenceLineTemp [referenceLineTempCount] = arrayPositionReviseTemp [counter1*7], referenceLineTempCount++;
                        arrayReferenceLineTemp [referenceLineTempCount] = arrayPositionReviseTemp [counter1*7+1], referenceLineTempCount++;
                    }
                }
                
                delete [] arrayPositionReviseTemp;
                delete [] arrayGravityCenterRevTemp;
                
                int maxPointDimX = 0;
                int maxPointDimY = 0;
                int minPointDimX = 1000000;
                int minPointDimY = 1000000;
                
                for (int counter1 = 0; counter1 < referenceLineTempCount/2; counter1++){
                    if (maxPointDimX < arrayReferenceLineTemp [counter1*2]) maxPointDimX = arrayReferenceLineTemp [counter1*2];
                    if (minPointDimX > arrayReferenceLineTemp [counter1*2]) minPointDimX = arrayReferenceLineTemp [counter1*2];
                    if (maxPointDimY < arrayReferenceLineTemp [counter1*2+1]) maxPointDimY = arrayReferenceLineTemp [counter1*2+1];
                    if (minPointDimY > arrayReferenceLineTemp [counter1*2+1]) minPointDimY = arrayReferenceLineTemp [counter1*2+1];
                }
                
                int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                int verticalLength = (maxPointDimY-minPointDimY)/2*2;
                int dimension = 0;
                
                if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
                if (horizontalLength < verticalLength) dimension = verticalLength+30;
                
                dimension = (dimension/2)*2;
                
                int horizontalStart2 = minPointDimX-(dimension-horizontalLength)/2;
                int verticalStart2 = minPointDimY-(dimension-verticalLength)/2;
                
                //cout<<horizontalStart2<<" "<<verticalStart2<<" "<<dimension<<" hol-ver-dim"<<endl;
                
                errorNoHold = 13;
                int **connectivityMapPrimary = new int *[dimension+1];
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++){
                    errorNoHold = 14;
                    connectivityMapPrimary [counter1] = new int [dimension+1];
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) connectivityMapPrimary [counterY][counterX] = 0;
                }
                
                for (int counter1 = 0; counter1 < referenceLineTempCount/2; counter1++){
                    if (arrayReferenceLineTemp [counter1*2]-horizontalStart2 >= 0 && arrayReferenceLineTemp [counter1*2]-horizontalStart2 < dimension && arrayReferenceLineTemp [counter1*2+1]-verticalStart2 >= 0 && arrayReferenceLineTemp [counter1*2+1]-verticalStart2 < dimension) connectivityMapPrimary [arrayReferenceLineTemp [counter1*2+1]-verticalStart2][arrayReferenceLineTemp [counter1*2]-horizontalStart2] = 1;
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapPrimary [counterA][counterB];
                //	cout<<" connectivityMapPrimary "<<counterA<<endl;
                //}
                
                //------Fill inside------
                errorNoHold = 15;
                int *connectAnalysisX = new int [dimension*4];
                errorNoHold = 16;
                int *connectAnalysisY = new int [dimension*4];
                errorNoHold = 17;
                int *connectAnalysisTempX = new int [dimension*4];
                errorNoHold = 18;
                int *connectAnalysisTempY = new int [dimension*4];
                
                int connectivityNumber = -3;
                int connectAnalysisCount = 0;
                int terminationFlag = 0;
                int connectAnalysisTempCount = 0;
                int xSource = 0;
                int ySource = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapPrimary [counterY][counterX] == 0){
                            connectivityNumber = connectivityNumber+2;
                            connectAnalysisCount = 0;
                            
                            if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMapPrimary [counterY][counterX] = connectivityNumber;
                            if (counterY-1 >= 0 && connectivityMapPrimary [counterY-1][counterX] == 0){
                                connectivityMapPrimary [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension && connectivityMapPrimary [counterY][counterX+1] == 0){
                                connectivityMapPrimary [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && connectivityMapPrimary [counterY+1][counterX] == 0){
                                connectivityMapPrimary [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && connectivityMapPrimary [counterY][counterX-1] == 0){
                                connectivityMapPrimary [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                        xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                        
                                        if (ySource-1 >= 0 && connectivityMapPrimary [ySource-1][xSource] == 0){
                                            connectivityMapPrimary [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension && connectivityMapPrimary [ySource][xSource+1] == 0){
                                            connectivityMapPrimary [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && connectivityMapPrimary [ySource+1][xSource] == 0){
                                            connectivityMapPrimary [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && connectivityMapPrimary [ySource][xSource-1] == 0){
                                            connectivityMapPrimary [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                        connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                delete [] connectAnalysisX;
                delete [] connectAnalysisY;
                delete [] connectAnalysisTempX;
                delete [] connectAnalysisTempY;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapPrimary [counterY][counterX] == -1) connectivityMapPrimary [counterY][counterX] = 0;
                        else connectivityMapPrimary [counterY][counterX] = 1;
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapPrimary [counterA][counterB];
                //	cout<<" connectivityMapPrimary "<<counterA<<endl;
                //}
                
                int startY = 0;
                int endY = 0;
                int startX = 0;
                int endX = 0;
                
                if (minPointDimY-30 >= 0) startY = minPointDimY-30;
                else startY = 0;
                
                if (maxPointDimY+30 < imageDimension) endY = maxPointDimY+31;
                else endY = imageDimension;
                
                if (minPointDimX-30 >= 0) startX = minPointDimX-30;
                else startX = 0;
                
                if (maxPointDimX+30 < imageDimension) endX = maxPointDimX+31;
                else endX = imageDimension;
                
                int maxConnectRevise = 0;
                
                for (int counterY = 0; counterY < imageDimension; counterY++){
                    for (int counterX = 0; counterX < imageDimension; counterX++){
                        if (revisedWorkingMap [counterY][counterX] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY][counterX];
                    }
                }
                
                errorNoHold = 19;
                int *findReviseConnect = new int [maxConnectRevise+5];
                for (int counter1 = 0; counter1 < maxConnectRevise+5; counter1++) findReviseConnect [counter1] = 0;
                
                for (int counterY = startY; counterY < endY; counterY++){
                    for (int counterX = startX; counterX < endX; counterX++){
                        if (counterY-verticalStart2 >= 0 && counterY-verticalStart2 < dimension && counterX-horizontalStart2 >= 0 && counterX-horizontalStart2 < dimension){
                            if (revisedWorkingMap [counterY][counterX] != 0 && connectivityMapPrimary [counterY-verticalStart2][counterX-horizontalStart2] == 1){
                                findReviseConnect [revisedWorkingMap [counterY][counterX]]++;
                            }
                        }
                    }
                }
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++) delete [] connectivityMapPrimary [counter1];
                delete [] connectivityMapPrimary;
                
                for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                    if (findReviseConnect [arrayTimeSelected [counter1*10+8]] != 0){
                        if (arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7) findReviseConnect [arrayTimeSelected [counter1*10+8]] = 0;
                    }
                }
                
                for (int counter1 = 0; counter1 < maxConnectRevise+5; counter1++){
                    if (findReviseConnect [counter1] != 0 && findReviseConnect [counter1] < sourceAreaTemp*(percentOverlap/(double)100)) findReviseConnect [counter1] = 0;
                }
                
                maxPointDimX = 0;
                maxPointDimY = 0;
                minPointDimX = 1000000;
                minPointDimY = 1000000;
                
                for (int counterY = 0; counterY < imageDimension; counterY++){
                    for (int counterX = 0; counterX < imageDimension; counterX++){
                        if (findReviseConnect [revisedWorkingMap [counterY][counterX]] != 0){
                            if (maxPointDimX < counterX) maxPointDimX = counterX;
                            if (minPointDimX > counterX) minPointDimX = counterX;
                            if (maxPointDimY < counterY) maxPointDimY = counterY;
                            if (minPointDimY > counterY) minPointDimY = counterY;
                        }
                    }
                }
                
                for (int counter1 = 0; counter1 < referenceLineTempCount/2; counter1++){
                    if (maxPointDimX < arrayReferenceLineTemp [counter1*2]) maxPointDimX = arrayReferenceLineTemp [counter1*2];
                    if (minPointDimX > arrayReferenceLineTemp [counter1*2]) minPointDimX = arrayReferenceLineTemp [counter1*2];
                    if (maxPointDimY < arrayReferenceLineTemp [counter1*2+1]) maxPointDimY = arrayReferenceLineTemp [counter1*2+1];
                    if (minPointDimY > arrayReferenceLineTemp [counter1*2+1]) minPointDimY = arrayReferenceLineTemp [counter1*2+1];
                }
                
                for (int counter1 = 0; counter1 < referenceLineCount/2; counter1++){
                    if (maxPointDimX < arrayReferenceLine [counter1*2]) maxPointDimX = arrayReferenceLine [counter1*2];
                    if (minPointDimX > arrayReferenceLine [counter1*2]) minPointDimX = arrayReferenceLine [counter1*2];
                    if (maxPointDimY < arrayReferenceLine [counter1*2+1]) maxPointDimY = arrayReferenceLine [counter1*2+1];
                    if (minPointDimY > arrayReferenceLine [counter1*2+1]) minPointDimY = arrayReferenceLine [counter1*2+1];
                }
                
                if (cutOffAdjust != -1){
                    if (optionalShiftOrientation == 1){
                        minPointDimX = minPointDimX-(int)((maxPointDimX-minPointDimX)*(optionalShiftPercent/(double)100));
                        
                        if (minPointDimX < 0) minPointDimX = 0;
                    }
                    else if (optionalShiftOrientation == 2){
                        minPointDimY = minPointDimY-(int)((maxPointDimY-minPointDimY)*(optionalShiftPercent/(double)100));
                        
                        if (minPointDimY < 0) minPointDimY = 0;
                    }
                    else if (optionalShiftOrientation == 3){
                        maxPointDimX = maxPointDimX+(int)((maxPointDimX-minPointDimX)*(optionalShiftPercent/(double)100));
                        
                        if (maxPointDimX > imageDimension) maxPointDimX = imageDimension;
                    }
                    else if (optionalShiftOrientation == 4){
                        maxPointDimY = maxPointDimY+(int)((maxPointDimY-minPointDimY)*(optionalShiftPercent/(double)100));
                        
                        if (maxPointDimY > imageDimension) maxPointDimY = imageDimension;
                    }
                }
                
                horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                verticalLength = (maxPointDimY-minPointDimY)/2*2;
                dimension = 0;
                
                if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
                if (horizontalLength < verticalLength) dimension = verticalLength+30;
                
                dimension = (dimension/2)*2;
                
                horizontalStart2 = minPointDimX-(dimension-horizontalLength)/2;
                verticalStart2 = minPointDimY-(dimension-verticalLength)/2;
                
                errorNoHold = 20;
                int **previousMap3A = new int *[dimension+4]; //========Previous map========
                errorNoHold = 21;
                int **previousMap3ATemp1 = new int *[dimension+4];
                errorNoHold = 22;
                int **previousMap3ATemp2 = new int *[dimension+4];
                errorNoHold = 23;
                int **previousMap4A = new int *[dimension+4];
                errorNoHold = 24;
                int **previousMap5A = new int *[dimension+4];
                errorNoHold = 25;
                int **connectivityUpdate5 = new int *[dimension+4];
                
                for (int counter1 = 0; counter1 < dimension+4; counter1++){
                    errorNoHold = 26;
                    previousMap3A [counter1] = new int [dimension+4];
                    errorNoHold = 27;
                    previousMap3ATemp1 [counter1] = new int [dimension+4];
                    errorNoHold = 28;
                    previousMap3ATemp2 [counter1] = new int [dimension+4];
                    errorNoHold = 29;
                    previousMap4A [counter1] = new int [dimension+4];
                    errorNoHold = 30;
                    previousMap5A [counter1] = new int [dimension+4];
                    errorNoHold = 31;
                    connectivityUpdate5 [counter1] = new int [dimension+4];
                }
                
                for (int counterY = 0; counterY < dimension+4; counterY++){
                    for (int counterX = 0; counterX < dimension+4; counterX++){
                        previousMap3A [counterY][counterX] = 0;
                        previousMap3ATemp1 [counterY][counterX] = 0;
                        previousMap3ATemp2 [counterY][counterX] = 0;
                        previousMap4A [counterY][counterX] = 0;
                        previousMap5A [counterY][counterX] = 0;
                    }
                }
                
                for (int counter1 = 0; counter1 < referenceLineTempCount/2; counter1++){
                    if (arrayReferenceLineTemp [counter1*2]-horizontalStart2 >= 0 && arrayReferenceLineTemp [counter1*2]-horizontalStart2 < dimension && arrayReferenceLineTemp [counter1*2+1]-verticalStart2 >= 0 && arrayReferenceLineTemp [counter1*2+1]-verticalStart2 < dimension) previousMap3A [arrayReferenceLineTemp [counter1*2+1]-verticalStart2][arrayReferenceLineTemp [counter1*2]-horizontalStart2] = 1;
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3A [counterA][counterB];
                // 	cout<<" previousMap3A "<<counterA<<endl;
                //}
                
                delete [] arrayReferenceLineTemp;
                
                errorNoHold = 32;
                connectAnalysisX = new int [(dimension+2)*4];
                errorNoHold = 33;
                connectAnalysisY = new int [(dimension+2)*4];
                errorNoHold = 34;
                connectAnalysisTempX = new int [(dimension+2)*4];
                errorNoHold = 35;
                connectAnalysisTempY = new int [(dimension+2)*4];
                
                connectivityNumber = -3;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (previousMap3A [counterY][counterX] == 0){
                            connectivityNumber = connectivityNumber+2;
                            previousMap3A [counterY][counterX] = connectivityNumber;
                            
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && previousMap3A [counterY-1][counterX] == 0){
                                previousMap3A [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension && previousMap3A [counterY][counterX+1] == 0){
                                previousMap3A [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && previousMap3A [counterY+1][counterX] == 0){
                                previousMap3A [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && previousMap3A [counterY][counterX-1] == 0){
                                previousMap3A [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                        xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                        
                                        if (ySource-1 >= 0 && previousMap3A [ySource-1][xSource] == 0){
                                            previousMap3A [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension && previousMap3A [ySource][xSource+1] == 0){
                                            previousMap3A [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && previousMap3A [ySource+1][xSource] == 0){
                                            previousMap3A [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && previousMap3A [ySource][xSource-1] == 0){
                                            previousMap3A [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                        connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //------Remove connectivity groups, which attach edge, extract inner part of Linked Line------
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (previousMap3A [counterY][counterX] == -1) previousMap3A [counterY][counterX] = 0;
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3A [counterA][counterB];
                //    cout<<" previousMap3A "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < referenceLineCount/2; counter1++){
                    if (arrayReferenceLine [counter1*2]-horizontalStart2 >= 0 && arrayReferenceLine [counter1*2]-horizontalStart2 < dimension && arrayReferenceLine [counter1*2+1]-verticalStart2 >= 0 && arrayReferenceLine [counter1*2+1]-verticalStart2 < dimension) previousMap4A [arrayReferenceLine [counter1*2+1]-verticalStart2][arrayReferenceLine [counter1*2]-horizontalStart2] = 1;
                }
                
                if (cutOffAdjust != -1){
                    int shift = 0;
                    
                    if (optionalShiftOrientation == 1){
                        shift = ((int)((maxPointDimX-minPointDimX)*(optionalShiftPercent/(double)100))/2);
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (previousMap4A [counterY][counterX] == 1 || previousMap4A [counterY][counterX] == 3){
                                    if (previousMap4A [counterY][counterX-shift] == 0){
                                        previousMap4A [counterY][counterX-shift] = 2;
                                    }
                                    else if (previousMap4A [counterY][counterX-shift] == 1){
                                        previousMap4A [counterY][counterX-shift] = 3;
                                    }
                                    
                                    if (previousMap4A [counterY][counterX] == 1) previousMap4A [counterY][counterX] = 0;
                                }
                            }
                        }
                    }
                    else if (optionalShiftOrientation == 2){
                        shift = ((int)((maxPointDimY-minPointDimY)*(optionalShiftPercent/(double)100))/2);
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (previousMap4A [counterY][counterX] == 1 || previousMap4A [counterY][counterX] == 3){
                                    if (previousMap4A [counterY-shift][counterX] == 0){
                                        previousMap4A [counterY-shift][counterX] = 2;
                                    }
                                    else if (previousMap4A [counterY-shift][counterX] == 1){
                                        previousMap4A [counterY-shift][counterX] = 3;
                                    }
                                    
                                    if (previousMap4A [counterY][counterX] == 1) previousMap4A [counterY][counterX] = 0;
                                }
                            }
                        }
                    }
                    else if (optionalShiftOrientation == 3){
                        shift = ((int)((maxPointDimX-minPointDimX)*(optionalShiftPercent/(double)100))/2);
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (previousMap4A [counterY][counterX] == 1 || previousMap4A [counterY][counterX] == 3){
                                    if (previousMap4A [counterY][counterX+shift] == 0){
                                        previousMap4A [counterY][counterX+shift] = 2;
                                    }
                                    else if (previousMap4A [counterY][counterX+shift] == 1){
                                        previousMap4A [counterY][counterX+shift] = 3;
                                    }
                                    
                                    if (previousMap4A [counterY][counterX] == 1) previousMap4A [counterY][counterX] = 0;
                                }
                            }
                        }
                    }
                    else if (optionalShiftOrientation == 4){
                        shift = ((int)((maxPointDimY-minPointDimY)*(optionalShiftPercent/(double)100))/2);
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (previousMap4A [counterY][counterX] == 1 || previousMap4A [counterY][counterX] == 3){
                                    if (previousMap4A [counterY+shift][counterX] == 0){
                                        previousMap4A [counterY+shift][counterX] = 2;
                                    }
                                    else if (previousMap4A [counterY+shift][counterX] == 1){
                                        previousMap4A [counterY+shift][counterX] = 3;
                                    }
                                    
                                    if (previousMap4A [counterY][counterX] == 1) previousMap4A [counterY][counterX] = 0;
                                }
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3A [counterA][counterB];
                //    cout<<" previousMap3A "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap4A [counterA][counterB];
                //    cout<<" previousMap4A "<<counterA<<endl;
                //}
                
                connectivityNumber = -3;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (previousMap4A [counterY][counterX] == 0){
                            connectivityNumber = connectivityNumber+2;
                            previousMap4A [counterY][counterX] = connectivityNumber;
                            
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && previousMap4A [counterY-1][counterX] == 0){
                                previousMap4A [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension && previousMap4A [counterY][counterX+1] == 0){
                                previousMap4A [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && previousMap4A [counterY+1][counterX] == 0){
                                previousMap4A [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && previousMap4A [counterY][counterX-1] == 0){
                                previousMap4A [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                        xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                        
                                        if (ySource-1 >= 0 && previousMap4A [ySource-1][xSource] == 0){
                                            previousMap4A [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension && previousMap4A [ySource][xSource+1] == 0){
                                            previousMap4A [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && previousMap4A [ySource+1][xSource] == 0){
                                            previousMap4A [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && previousMap4A [ySource][xSource-1] == 0){
                                            previousMap4A [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                        connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //------Remove connectivity groups, which attach edge, extract inner part of Linked Line------
                int areaCountCurrent = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (previousMap4A [counterY][counterX] == -1) previousMap4A [counterY][counterX] = 0;
                        else{
                            
                            previousMap4A [counterY][counterX] = -1;
                            areaCountCurrent++;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //   for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap4A [counterA][counterB];
                //   cout<<" previousMap4A "<<counterA<<endl;
                //}
                
                if (minPointDimY-30 >= 0) startY = minPointDimY-30;
                else startY = 0;
                
                if (maxPointDimY+30 < imageDimension) endY = maxPointDimY+31;
                else endY = imageDimension;
                
                if (minPointDimX-30 >= 0) startX = minPointDimX-30;
                else startX = 0;
                
                if (maxPointDimX+30 < imageDimension) endX = maxPointDimX+31;
                else endX = imageDimension;
                
                for (int counterY = startY; counterY < endY; counterY++){
                    for (int counterX = startX; counterX < endX; counterX++){
                        if (findReviseConnect [revisedWorkingMap [counterY][counterX]] != 0){
                            if (counterY-verticalStart2 > 0 && counterY-verticalStart2 < dimension && counterX-horizontalStart2 > 0 && counterX-horizontalStart2 < dimension)
                                previousMap4A [counterY-verticalStart2][counterX-horizontalStart2] = -1;
                        }
                    }
                }
                
                delete [] findReviseConnect;
                
                int totalConnectNo = 0;
                
                connectivityNumber = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (previousMap4A [counterY][counterX] == -1){
                            connectivityNumber++;
                            previousMap4A [counterY][counterX] = connectivityNumber;
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && counterX-1 >= 0 && previousMap4A [counterY-1][counterX-1] == -1){
                                previousMap4A [counterY-1][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && previousMap4A [counterY-1][counterX] == -1){
                                previousMap4A [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && counterX+1 < dimension && previousMap4A [counterY-1][counterX+1] == -1){
                                previousMap4A [counterY-1][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension && previousMap4A [counterY][counterX+1] == -1){
                                previousMap4A [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && counterX+1 < dimension && previousMap4A [counterY+1][counterX+1] == -1){
                                previousMap4A [counterY+1][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && previousMap4A [counterY+1][counterX] == -1){
                                previousMap4A [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && counterX-1 >= 0 && previousMap4A [counterY+1][counterX-1] == -1){
                                previousMap4A [counterY+1][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && previousMap4A [counterY][counterX-1] == -1){
                                previousMap4A [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                        xSource = connectAnalysisX [counter1];
                                        ySource = connectAnalysisY [counter1];
                                        
                                        if (ySource-1 >= 0 && xSource-1 >= 0 && previousMap4A [ySource-1][xSource-1] == -1){
                                            previousMap4A [ySource-1][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && previousMap4A [ySource-1][xSource] == -1){
                                            previousMap4A [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && xSource+1 < dimension && previousMap4A [ySource-1][xSource+1] == -1){
                                            previousMap4A [ySource-1][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension && previousMap4A [ySource][xSource+1] == -1){
                                            previousMap4A [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 > dimension && xSource+1 < dimension && previousMap4A [ySource+1][xSource+1] == -1){
                                            previousMap4A [ySource+1][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && previousMap4A [ySource+1][xSource] == -1){
                                            previousMap4A [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && xSource-1 >= 0 && previousMap4A [ySource+1][xSource-1] == -1){
                                            previousMap4A [ySource+1][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && previousMap4A [ySource][xSource-1] == -1){
                                            previousMap4A [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                        connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                totalConnectNo = connectivityNumber;
                
                int maxConnectNumberList = timeSelectedCount/10;
                
                errorNoHold = 36;
                int *overlapList = new int [maxConnectNumberList+2];
                errorNoHold = 37;
                int *overlapList2 = new int [maxConnectNumberList+2];
                int overlapListCount2 = 0;
                errorNoHold = 38;
                int *overlapList3 = new int [maxConnectNumberList+2];
                
                for (int counter1 = 0; counter1 < maxConnectNumberList+2; counter1++){
                    overlapList [counter1] = 0;
                    overlapList2 [counter1] = 0;
                    overlapList3 [counter1] = 0;
                }
                
                //---------Background image set----------
                errorNoHold = 39;
                int **rangeMatrix = new int *[dimension+4];
                
                for (int counter1 = 0; counter1 < dimension+4; counter1++){
                    errorNoHold = 40;
                    rangeMatrix [counter1] = new int [dimension+4];
                }
                
                connectivityNumber = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                            if (cutOffAdjust == -1){
                                if (sourceImage [mapPositionPointer][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] == 100) rangeMatrix [counterY][counterX] = 0;
                                else if (sourceImage [mapPositionPointer][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] < cutStatusDic) rangeMatrix [counterY][counterX] = 0;
                                else rangeMatrix [counterY][counterX] = -150;
                            }
                            else{
                                
                                if (sourceImage [mapPositionPointer][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] < cutOffAdjust) rangeMatrix [counterY][counterX] = 0;
                                else rangeMatrix [counterY][counterX] = -150;
                            }
                            
                            averageHold = averageHold+sourceImage [mapPositionPointer][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2];
                        }
                        else rangeMatrix [counterY][counterX] = 0;
                    }
                }
                
                averageHold = averageHold/(double)(dimension*dimension);
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<rangeMatrix [counterA][counterB];
                //    cout<<" rangeMatrix "<<counterA<<endl;
                //}
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (rangeMatrix [counterY][counterX] == -150){
                            connectivityNumber++;
                            rangeMatrix [counterY][counterX] = connectivityNumber;
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrix [counterY-1][counterX-1] == -150){
                                rangeMatrix [counterY-1][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && rangeMatrix [counterY-1][counterX] == -150){
                                rangeMatrix [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && counterX+1 < dimension && rangeMatrix [counterY-1][counterX+1] == -150){
                                rangeMatrix [counterY-1][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension && rangeMatrix [counterY][counterX+1] == -150){
                                rangeMatrix [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && counterX+1 < dimension && rangeMatrix [counterY+1][counterX+1] == -150){
                                rangeMatrix [counterY+1][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && rangeMatrix [counterY+1][counterX] == -150){
                                rangeMatrix [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && counterX-1 >= 0 && rangeMatrix [counterY+1][counterX-1] == -150){
                                rangeMatrix [counterY+1][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && rangeMatrix [counterY][counterX-1] == -150){
                                rangeMatrix [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                        
                                        if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrix [ySource-1][xSource-1] == -150){
                                            rangeMatrix [ySource-1][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && rangeMatrix [ySource-1][xSource] == -150){
                                            rangeMatrix [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && xSource+1 < dimension && rangeMatrix [ySource-1][xSource+1] == -150){
                                            rangeMatrix [ySource-1][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension && rangeMatrix [ySource][xSource+1] == -150){
                                            rangeMatrix [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 > dimension && xSource+1 < dimension && rangeMatrix [ySource+1][xSource+1] == -150){
                                            rangeMatrix [ySource+1][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && rangeMatrix [ySource+1][xSource] == -150){
                                            rangeMatrix [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && xSource-1 >= 0 && rangeMatrix [ySource+1][xSource-1] == -150){
                                            rangeMatrix [ySource+1][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && rangeMatrix [ySource][xSource-1] == -150){
                                            rangeMatrix [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //------Determine number of pixels------
                errorNoHold = 41;
                int *connectedPixels = new int [connectivityNumber+50];
                
                for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPixels [counter2] = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (rangeMatrix [counterY][counterX] != 0) connectedPixels [rangeMatrix [counterY][counterX]]++;
                    }
                }
                
                //------Map up-date------
                int connectTemp = 1;
                
                for (int counter2 = 1; counter2 <= connectivityNumber; counter2++){
                    if (connectedPixels [counter2] < 10) connectedPixels [counter2] = 0;
                    else{
                        
                        connectedPixels [counter2] = connectTemp;
                        connectTemp++;
                    }
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if ((connectTemp = rangeMatrix [counterY][counterX]) != 0) rangeMatrix [counterY][counterX] = connectedPixels [connectTemp];
                        else rangeMatrix [counterY][counterX] = 0;
                    }
                }
                
                delete [] connectedPixels;
                
                //---------Merge map 3 and 4------------
                if (mapMergeStatus == 1){
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (previousMap4A [counterY][counterX] != 0) previousMap3A [counterY][counterX] = 1;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3A [counterA][counterB];
                //    cout<<" previousMap3A "<<counterA<<endl;
                //}
                
                //-------Create overlap list and remove out fit pix from previousMap3A----------
                int valueTempHold = -1;
                int valueTempHoldStatus = 0;
                int valueMapTemp = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension && previousMap3A [counterY][counterX] != 0){
                            if (rangeMatrix [counterY][counterX] == 0) previousMap3A [counterY][counterX] = 0;
                            
                            valueMapTemp = revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2];
                            
                            if (valueMapTemp != 0){
                                overlapList [valueMapTemp]++;
                                overlapList3 [valueMapTemp] = rangeMatrix [counterY][counterX];
                            }
                            
                            if (valueMapTemp != 0 && valueTempHold != valueMapTemp){
                                valueTempHold = valueMapTemp;
                                valueTempHoldStatus = 0;
                                
                                for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                                    if (valueMapTemp != targetConnectInitial && arrayConnectLineageRel [counter1*6+1] == valueMapTemp){
                                        previousMap3A [counterY][counterX] = 0;
                                        overlapList [valueMapTemp] = 0;
                                        valueTempHoldStatus = 1;
                                        break;
                                    }
                                }
                            }
                            else if (valueTempHoldStatus == 1){
                                previousMap3A [counterY][counterX] = 0;
                                overlapList [valueMapTemp] = 0;
                            }
                        }
                    }
                }
                
                for (int counter1 = 0; counter1 < dimension+4; counter1++){
                    delete [] rangeMatrix [counter1];
                }
                
                delete [] rangeMatrix;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (previousMap3A [counterY][counterX] != 0) previousMap3A [counterY][counterX] = -1;
                    }
                }
                
                //-------Select Largest pix from previousMap3A---------
                connectivityNumber = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (previousMap3A [counterY][counterX] == -1){
                            connectivityNumber++;
                            previousMap3A [counterY][counterX] = connectivityNumber;
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && counterX-1 >= 0 && previousMap3A [counterY-1][counterX-1] == -1){
                                previousMap3A [counterY-1][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && previousMap3A [counterY-1][counterX] == -1){
                                previousMap3A [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && counterX+1 < dimension && previousMap3A [counterY-1][counterX+1] == -1){
                                previousMap3A [counterY-1][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension && previousMap3A [counterY][counterX+1] == -1){
                                previousMap3A [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && counterX+1 < dimension && previousMap3A [counterY+1][counterX+1] == -1){
                                previousMap3A [counterY+1][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && previousMap3A [counterY+1][counterX] == -1){
                                previousMap3A [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && counterX-1 >= 0 && previousMap3A [counterY+1][counterX-1] == -1){
                                previousMap3A [counterY+1][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && previousMap3A [counterY][counterX-1] == -1){
                                previousMap3A [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                        xSource = connectAnalysisX [counter1];
                                        ySource = connectAnalysisY [counter1];
                                        
                                        if (ySource-1 >= 0 && xSource-1 >= 0 && previousMap3A [ySource-1][xSource-1] == -1){
                                            previousMap3A [ySource-1][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && previousMap3A [ySource-1][xSource] == -1){
                                            previousMap3A [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && xSource+1 < dimension && previousMap3A [ySource-1][xSource+1] == -1){
                                            previousMap3A [ySource-1][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension && previousMap3A [ySource][xSource+1] == -1){
                                            previousMap3A [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 > dimension && xSource+1 < dimension && previousMap3A [ySource+1][xSource+1] == -1){
                                            previousMap3A [ySource+1][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && previousMap3A [ySource+1][xSource] == -1){
                                            previousMap3A [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && xSource-1 >= 0 && previousMap3A [ySource+1][xSource-1] == -1){
                                            previousMap3A [ySource+1][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && previousMap3A [ySource][xSource-1] == -1){
                                            previousMap3A [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                        connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                if (totalConnectNo < connectivityNumber) totalConnectNo = connectivityNumber;
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3A [counterA][counterB];
                //    cout<<" previousMap3A "<<counterA<<endl;
                //}
                
                connectedPixels = new int [totalConnectNo+4];
                errorNoHold = 42;
                int *connectedPixels2 = new int [totalConnectNo+4];
                errorNoHold = 43;
                int *connectedPixels3 = new int [totalConnectNo+4];
                errorNoHold = 44;
                int *connectedPixelsOverlap = new int [totalConnectNo+4];
                
                for (int counter1 = 0; counter1 <= totalConnectNo; counter1++){
                    connectedPixels [counter1] = 0;
                    connectedPixels2 [counter1] = 0;
                    connectedPixels3 [counter1] = 0;
                    connectedPixelsOverlap [counter1] = 0;
                }
                
                for (int counterY= 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (previousMap3A [counterY][counterX] != 0){
                            connectedPixels [previousMap3A [counterY][counterX]]++;
                            connectedPixels2 [previousMap3A [counterY][counterX]]++;
                        }
                        
                        if (previousMap4A [counterY][counterX] != 0) connectedPixels3 [previousMap4A [counterY][counterX]]++;
                        
                        if (previousMap3A [counterY][counterX] != 0 && previousMap4A [counterY][counterX] != 0) connectedPixelsOverlap [previousMap3A [counterY][counterX]] = previousMap4A [counterY][counterX];
                    }
                }
                
                for (int counter1 = 1; counter1 <= totalConnectNo; counter1++){
                    if (connectedPixels [counter1] != 0 && connectedPixelsOverlap [counter1] == 0) connectedPixels [counter1] = 0;
                }
                
                delete [] connectedPixelsOverlap;
                
                int largestConnect3A = 0;
                int secondConnect3A = 0;
                int largestConnect4A = 0;
                int secondConnect4A = 0;
                int largestConnectCount3A = 0;
                int secondConnectCount3A = 0;
                int largestConnectCount4A = 0;
                
                for (int counter1 = 1; counter1 <= totalConnectNo; counter1++){
                    if (connectedPixels [counter1] > largestConnect3A){
                        largestConnect3A = connectedPixels [counter1];
                        largestConnectCount3A = counter1;
                    }
                    
                    if (connectedPixels3 [counter1] > largestConnect4A){
                        largestConnect4A = connectedPixels3 [counter1];
                        largestConnectCount4A = counter1;
                    }
                }
                
                connectedPixels [largestConnectCount3A] = 0;
                connectedPixels3 [largestConnectCount4A] = 0;
                
                for (int counter1 = 1; counter1 <= totalConnectNo; counter1++){
                    if (connectedPixels [counter1] > secondConnect3A){
                        secondConnect3A = connectedPixels [counter1];
                        secondConnectCount3A = counter1;
                    }
                    
                    if (connectedPixels3 [counter1] > secondConnect4A) secondConnect4A = connectedPixels3 [counter1];
                }
                
                if (largestConnectCount3A != largestConnectCount4A){
                    if (largestConnect3A-20 < secondConnect3A && largestConnect3A+20 > secondConnect3A && secondConnect3A > 40){
                        largestConnect3A = secondConnect3A;
                        largestConnectCount3A = secondConnectCount3A;
                    }
                }
                
                if (largestConnect3A > 40){
                    largestConnect3A = 0;
                    largestConnectCount3A = 0;
                    
                    for (int counter1 = 1; counter1 <= totalConnectNo; counter1++){
                        if (connectedPixels2 [counter1] > largestConnect3A){
                            largestConnect3A = connectedPixels2 [counter1];
                            largestConnectCount3A = counter1;
                        }
                    }
                }
                
                delete [] connectedPixels;
                delete [] connectedPixels2;
                delete [] connectedPixels3;
                
                if (largestConnect3A < 60 && gravityCentreMoveLimitFlag == 1){
                    errorNoHold = 45;
                    int **mapHoldTemp = new int *[dimension+1];
                    
                    for (int counter1 = 0; counter1 < dimension+1; counter1++){
                        errorNoHold = 46;
                        mapHoldTemp [counter1] = new int [dimension+1];
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            mapHoldTemp [counterY][counterX] = 0;
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension-2; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (previousMap3A [counterY][counterX] != 0) mapHoldTemp [counterY+2][counterX] = 1;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<mapHoldTemp [counterA][counterB];
                    //    cout<<" mapHoldTemp "<<counterA<<endl;
                    //}
                    
                    for (int counterY = 2; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (previousMap3A [counterY][counterX] != 0) mapHoldTemp [counterY-2][counterX] = 1;
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension-2; counterX++){
                            if (previousMap3A [counterY][counterX] != 0) mapHoldTemp [counterY][counterX+2] = 1;
                        }
                    }
                    
                    for (int counterY = 2; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (previousMap3A [counterY][counterX] != 0) mapHoldTemp [counterY][counterX-2] = 1;
                        }
                    }
                    
                    largestConnect3A = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (mapHoldTemp [counterY][counterX] != 0){
                                previousMap3A [counterY][counterX] = 1;
                                largestConnect3A++;
                            }
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < dimension+1; counter1++) delete [] mapHoldTemp [counter1];
                    
                    delete [] mapHoldTemp;
                }
                
                if (largestConnect3A > 40){
                    for (int counterY= 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (previousMap3A [counterY][counterX] != 0 && previousMap3A [counterY][counterX] != largestConnectCount3A) previousMap3A [counterY][counterX] = 0;
                            else if (previousMap3A [counterY][counterX] == largestConnectCount3A) previousMap3A [counterY][counterX] = 1;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3A [counterA][counterB];
                    //    cout<<" previousMap3A "<<counterA<<endl;
                    //}
                    
                    //===========Fill zero, remove 3 round around connect group, find largest connect, reconstruct connect==========
                    
                    //-------Zero Fill-------
                    for (int counterX = 0; counterX < dimension+2; counterX++){
                        for (int counterY = 0; counterY < dimension+2; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            connectivityUpdate5 [counterY+1][counterX+1] = previousMap3A [counterY][counterX];
                        }
                    }
                    
                    connectivityNumber = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                            if (connectivityUpdate5 [counterY2][counterX2] == 0){
                                connectivityNumber--;
                                connectAnalysisCount = 0;
                                
                                connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                                
                                if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                                    connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                }
                                if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                    connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                    connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                }
                                if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                    connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                            
                                            if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                                connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                                connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                                connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                                connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension+2; counterA++){
                    //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                    //	cout<<" connectivityUpdate5 "<<counterA<<endl;
                    //}
                    
                    int connectTemp2 = 0;
                    
                    if (connectivityNumber < -1){
                        errorNoHold = 47;
                        int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                        
                        for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
                        
                        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                                
                                if (connectTemp2 < -1){
                                    connectTemp2 = connectTemp2*-1;
                                    
                                    if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                }
                            }
                        }
                        
                        int zeroFillFlag = 0;
                        
                        for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                            if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
                        }
                        
                        if (zeroFillFlag == 1){
                            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                    connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                                    
                                    if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                                }
                            }
                            
                            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                    if (connectivityUpdate5 [counterY2][counterX2] > 0) previousMap3A [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                                }
                            }
                        }
                        
                        delete [] connectCheckArray;
                    }
                    
                    for (int counterY= 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (previousMap3A [counterY][counterX] != 0){
                                previousMap3A [counterY][counterX] = 1;
                                previousMap3ATemp1 [counterY][counterX] = 1;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3A [counterA][counterB];
                    //    cout<<" previousMap3A "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    // 	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3ATemp1 [counterA][counterB];
                    //	cout<<" previousMap3ATemp1 "<<counterA<<endl;
                    //}
                    
                    int zeroFaceFind = 0;
                    
                    for (int counter1 = 0; counter1 < 3; counter1++){
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (previousMap3ATemp1 [counterY][counterX] == 1){
                                    zeroFaceFind = 0;
                                    
                                    if (counterY-1 >= 0 && counterX-1 >= 0 && previousMap3ATemp1 [counterY-1][counterX-1] == 0) zeroFaceFind++;
                                    if (counterY-1 >= 0 && previousMap3ATemp1 [counterY-1][counterX] == 0) zeroFaceFind++;
                                    if (counterY-1 >= 0 && counterX+1 < dimension && previousMap3ATemp1 [counterY-1][counterX+1] == 0) zeroFaceFind++;
                                    if (counterX+1 < dimension && previousMap3ATemp1 [counterY][counterX+1] == 0) zeroFaceFind++;
                                    if (counterY+1 < dimension && counterX+1 < dimension && previousMap3ATemp1 [counterY+1][counterX+1] == 0) zeroFaceFind++;
                                    if (counterY+1 < dimension && previousMap3ATemp1 [counterY+1][counterX] == 0) zeroFaceFind++;
                                    if (counterY+1 < dimension && counterX-1 >= 0 && previousMap3ATemp1 [counterY+1][counterX-1] == 0) zeroFaceFind++;
                                    if (counterX-1 >= 0 && previousMap3ATemp1 [counterY][counterX-1] == 0) zeroFaceFind++;
                                    
                                    if (zeroFaceFind >= 2) previousMap3ATemp2 [counterY][counterX] = 1;
                                }
                            }
                        }
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (previousMap3ATemp2 [counterY][counterX] == 1){
                                    previousMap3ATemp1 [counterY][counterX] = 0;
                                    previousMap3ATemp2 [counterY][counterX] = 2;
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3ATemp1 [counterA][counterB];
                    //    cout<<" previousMap3ATemp1 "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3ATemp2 [counterA][counterB];
                    //    cout<<" previousMap3ATemp2 "<<counterA<<endl;
                    //}
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (previousMap3ATemp1 [counterY][counterX] == 1) previousMap3ATemp1 [counterY][counterX] = -1;
                        }
                    }
                    
                    connectivityNumber = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (previousMap3ATemp1 [counterY][counterX] == -1){
                                connectivityNumber++;
                                previousMap3ATemp1 [counterY][counterX] = connectivityNumber;
                                connectAnalysisCount = 0;
                                
                                if (counterY-1 >= 0 && counterX-1 >= 0 && previousMap3ATemp1 [counterY-1][counterX-1] == -1){
                                    previousMap3ATemp1 [counterY-1][counterX-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterY-1 >= 0 && previousMap3ATemp1 [counterY-1][counterX] == -1){
                                    previousMap3ATemp1 [counterY-1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterY-1 >= 0 && counterX+1 < dimension && previousMap3ATemp1 [counterY-1][counterX+1] == -1){
                                    previousMap3ATemp1 [counterY-1][counterX+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterX+1 < dimension && previousMap3ATemp1 [counterY][counterX+1] == -1){
                                    previousMap3ATemp1 [counterY][counterX+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimension && counterX+1 < dimension && previousMap3ATemp1 [counterY+1][counterX+1] == -1){
                                    previousMap3ATemp1 [counterY+1][counterX+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimension && previousMap3ATemp1 [counterY+1][counterX] == -1){
                                    previousMap3ATemp1 [counterY+1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimension && counterX-1 >= 0 && previousMap3ATemp1 [counterY+1][counterX-1] == -1){
                                    previousMap3ATemp1 [counterY+1][counterX-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterX-1 >= 0 && previousMap3ATemp1 [counterY][counterX-1] == -1){
                                    previousMap3ATemp1 [counterY][counterX-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                            
                                            if (ySource-1 >= 0 && xSource-1 >= 0 && previousMap3ATemp1 [ySource-1][xSource-1] == -1){
                                                previousMap3ATemp1 [ySource-1][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (ySource-1 >= 0 && previousMap3ATemp1 [ySource-1][xSource] == -1){
                                                previousMap3ATemp1 [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (ySource-1 >= 0 && xSource+1 < dimension && previousMap3ATemp1 [ySource-1][xSource+1] == -1){
                                                previousMap3ATemp1 [ySource-1][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && previousMap3ATemp1 [ySource][xSource+1] == -1){
                                                previousMap3ATemp1 [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 > dimension && xSource+1 < dimension && previousMap3ATemp1 [ySource+1][xSource+1] == -1){
                                                previousMap3ATemp1 [ySource+1][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && previousMap3ATemp1 [ySource+1][xSource] == -1){
                                                previousMap3ATemp1 [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && xSource-1 >= 0 && previousMap3ATemp1 [ySource+1][xSource-1] == -1){
                                                previousMap3ATemp1 [ySource+1][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && previousMap3ATemp1 [ySource][xSource-1] == -1){
                                                previousMap3ATemp1 [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3ATemp1 [counterA][counterB];
                    //    cout<<" previousMap3ATemp1 "<<counterA<<endl;
                    //}
                    
                    if (connectivityNumber > 1 && gravityCentreMoveLimitFlag == 0){
                        errorNoHold = 48;
                        connectedPixels = new int [(connectivityNumber+1)*2+4];
                        
                        for (int counter1 = 0; counter1 < (connectivityNumber+1)*2+4; counter1++) connectedPixels [counter1] = 0;
                        
                        for (int counterY= 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (previousMap3ATemp1 [counterY][counterX] != 0) connectedPixels [previousMap3ATemp1 [counterY][counterX]*2]++;
                            }
                        }
                        
                        largestConnect3A = 0;
                        largestConnectCount3A = 0;
                        
                        for (int counter1 = 0; counter1 <= connectivityNumber; counter1++){
                            if (connectedPixels [counter1*2] > largestConnect3A){
                                largestConnect3A = connectedPixels [counter1*2];
                                largestConnectCount3A = counter1;
                            }
                        }
                        
                        for (int counterY= 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (previousMap3ATemp2 [counterY][counterX] == 2){
                                    previousMap3ATemp1 [counterY][counterX] = connectivityNumber+1;
                                    previousMap3ATemp2 [counterY][counterX] = 0;
                                }
                            }
                        }
                        
                        for (int counterY= 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++) previousMap3ATemp2 [counterY][counterX] = previousMap3ATemp1 [counterY][counterX];
                        }
                        
                        terminationFlag = 0;
                        int startOrder = 1;
                        int findFreePoint = 0;
                        int connectNo = 0;
                        int remainingCheck = 0;
                        
                        do{
                            
                            for (int counter1 = startOrder; counter1 <= connectivityNumber; counter1++){
                                connectNo = counter1;
                                
                                if (connectedPixels [counter1*2+1] == 0){
                                    findFreePoint = 0;
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (previousMap3ATemp1 [counterY][counterX] == connectNo){
                                                if (counterY-1 >= 0 && counterX-1 >= 0 && previousMap3ATemp1 [counterY-1][counterX-1] > connectivityNumber){
                                                    previousMap3ATemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                                }
                                                if (counterY-1 >= 0 && previousMap3ATemp1 [counterY-1][counterX] > connectivityNumber){
                                                    previousMap3ATemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                                }
                                                if (counterY-1 >= 0 && counterX+1 < dimension && previousMap3ATemp1 [counterY-1][counterX+1] > connectivityNumber){
                                                    previousMap3ATemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                                }
                                                if (counterX+1 < dimension && previousMap3ATemp1 [counterY][counterX+1] > connectivityNumber){
                                                    previousMap3ATemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                                }
                                                if (counterY+1 < dimension && counterX+1 < dimension && previousMap3ATemp1 [counterY+1][counterX+1] > connectivityNumber){
                                                    previousMap3ATemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                                }
                                                if (counterY+1 < dimension && previousMap3ATemp1 [counterY+1][counterX] > connectivityNumber){
                                                    previousMap3ATemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                                }
                                                if (counterY+1 < dimension && counterX-1 >= 0 && previousMap3ATemp1 [counterY+1][counterX-1] > connectivityNumber){
                                                    previousMap3ATemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                                }
                                                if (counterX-1 >= 0 && previousMap3ATemp1 [counterY][counterX-1] > connectivityNumber){
                                                    previousMap3ATemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                                }
                                            }
                                        }
                                    }
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (previousMap3ATemp2 [counterY][counterX] != 0) previousMap3ATemp1 [counterY][counterX] = previousMap3ATemp2 [counterY][counterX];
                                        }
                                    }
                                    
                                    if (findFreePoint == 0) connectedPixels [counter1*2+1] = 1;
                                }
                            }
                            
                            for (int counter1 = 1; counter1 < startOrder; counter1++){
                                connectNo = counter1;
                                
                                if (connectedPixels [counter1*2+1] == 0){
                                    findFreePoint = 0;
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (previousMap3ATemp1 [counterY][counterX] == connectNo){
                                                if (counterY-1 >= 0 && counterX-1 >= 0 && previousMap3ATemp1 [counterY-1][counterX-1] > connectivityNumber){
                                                    previousMap3ATemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                                }
                                                if (counterY-1 >= 0 && previousMap3ATemp1 [counterY-1][counterX] > connectivityNumber){
                                                    previousMap3ATemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                                }
                                                if (counterY-1 >= 0 && counterX+1 < dimension && previousMap3ATemp1 [counterY-1][counterX+1] > connectivityNumber){
                                                    previousMap3ATemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                                }
                                                if (counterX+1 < dimension && previousMap3ATemp1 [counterY][counterX+1] > connectivityNumber){
                                                    previousMap3ATemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                                }
                                                if (counterY+1 < dimension && counterX+1 < dimension && previousMap3ATemp1 [counterY+1][counterX+1] > connectivityNumber){
                                                    previousMap3ATemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                                }
                                                if (counterY+1 < dimension && previousMap3ATemp1 [counterY+1][counterX] > connectivityNumber){
                                                    previousMap3ATemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                                }
                                                if (counterY+1 < dimension && counterX-1 >= 0 && previousMap3ATemp1 [counterY+1][counterX-1] > connectivityNumber){
                                                    previousMap3ATemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                                }
                                                if (counterX-1 >= 0 && previousMap3ATemp1 [counterY][counterX-1] > connectivityNumber){
                                                    previousMap3ATemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                                }
                                            }
                                        }
                                    }
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (previousMap3ATemp2 [counterY][counterX] != 0) previousMap3ATemp1 [counterY][counterX] = previousMap3ATemp2 [counterY][counterX];
                                        }
                                    }
                                    
                                    if (findFreePoint == 0) connectedPixels [counter1*2+1] = 1;
                                }
                            }
                            
                            remainingCheck = 0;
                            
                            for (int counter1 = 1; counter1 <= connectivityNumber; counter1++){
                                if (connectedPixels [counter1*2+1] == 0) remainingCheck = 1;
                            }
                            
                            if (remainingCheck == 0) terminationFlag = 1;
                            
                            startOrder++;
                            
                            if (startOrder == connectivityNumber+1) startOrder = 0;
                            
                        } while (terminationFlag == 0);
                        
                        delete [] connectedPixels;
                        
                        for (int counterY= 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (previousMap3ATemp1 [counterY][counterX] != largestConnectCount3A) previousMap3A [counterY][counterX] = 0;
                                else previousMap3ATemp1 [counterY][counterX] = 0;
                            }
                        }
                    }
                    else{
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (previousMap3ATemp1 [counterY][counterX] == 1) previousMap3ATemp1 [counterY][counterX] = 0;
                            }
                        }
                    }
                    
                    int sourceArea2 = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (previousMap3A [counterY][counterX] != 0) sourceArea2++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3A [counterA][counterB];
                    //	cout<<" previousMap3A "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3ATemp1 [counterA][counterB];
                    //	cout<<" previousMap3ATemp1 "<<counterA<<endl;
                    //}
                    
                    if (roundStatus == 2 && imageNumberInt > timeEventEntryHold && cellStatusLoading == 0){
                        if (putativeMapStatus == 0){
                            errorNoHold = 49;
                            putativeMap = new int *[imageDimension+1];
                            for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                                errorNoHold = 50;
                                putativeMap [counter1] = new int [imageDimension+1];
                            }
                            
                            putativeMapStatus = 1;
                            putativeMapSizeHold = imageDimension;
                        }
                        else if (putativeMapStatus == 1 && 300 < putativeMapSizeHold && 300 > imageDimension){
                            for (int counter1 = 0; counter1 < putativeMapSizeHold+1; counter1++) delete [] putativeMap [counter1];
                            delete [] putativeMap;
                            
                            putativeMapSizeHold = imageDimension;
                            
                            errorNoHold = 51;
                            putativeMap = new int *[imageDimension+1];
                            for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                                errorNoHold = 52;
                                putativeMap [counter1] = new int [imageDimension+1];
                            }
                        }
                        else if (putativeMapStatus == 1 && putativeMapSizeHold < imageDimension){
                            for (int counter1 = 0; counter1 < putativeMapSizeHold+1; counter1++) delete [] putativeMap [counter1];
                            delete [] putativeMap;
                            
                            errorNoHold = 53;
                            putativeMap = new int *[imageDimension+1];
                            for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                                errorNoHold = 54;
                                putativeMap [counter1] = new int [imageDimension+1];
                            }
                            
                            putativeMapSizeHold = imageDimension;
                        }
                        
                        errorNoHold = 55;
                        int **mapTempImage = new int *[imageDimension+1];
                        
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                            errorNoHold = 56;
                            mapTempImage [counter1] = new int [imageDimension+1];
                        }
                        
                        for (int counterY = 0; counterY < imageDimension+1; counterY++){
                            for (int counterX = 0; counterX < imageDimension+1; counterX++){
                                putativeMap [counterY][counterX] = 0;
                                mapTempImage [counterY][counterX] = 0;
                            }
                        }
                        
                        long sizeTotal = (long)(imageDimension*imageDimension*4);
                        
                        errorNoHold = 57;
                        uint8_t *upload2 = new uint8_t [sizeTotal+50];
                        
                        //---------Revised Map----------
                        fin.open(mapTempPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)upload2, sizeTotal+1);
                            fin.close();
                            
                            int readBit [4];
                            int yDimensionCount = 0;
                            int xDimensionCount = 0;
                            int pixelData = 0;
                            
                            for (int counter1 = 0; counter1 < sizeTotal; counter1 = counter1+4){
                                readBit [0] = upload2[counter1];
                                readBit [1] = upload2[counter1+1];
                                readBit [2] = upload2[counter1+2];
                                readBit [3] = upload2[counter1+3];
                                
                                pixelData = readBit [0]*65536+readBit [1]*256+readBit [2];
                                
                                for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                                    mapTempImage [yDimensionCount][xDimensionCount] = pixelData, xDimensionCount++;
                                }
                                
                                if (xDimensionCount == imageDimension){
                                    xDimensionCount = 0;
                                    yDimensionCount++;
                                    
                                    if (yDimensionCount == imageDimension){
                                        break;
                                    }
                                }
                            }
                        }
                        else{
                            
                            errorNoHold = 1009;
                            throw errorCheckThrow;
                        }
                        
                        delete [] upload2;
                        
                        //int **sourceImageTest = new int *[dimension+1]; //=======For check
                        
                        //for (int counter1 = 0; counter1 < dimension+1; counter1++){
                        //    sourceImageTest [counter1] = new int [dimension+1];
                        //}
                        
                        //for (int counterY = 0; counterY < dimension; counterY++){
                        //    for (int counterX = 0; counterX < dimension; counterX++){
                        //        sourceImageTest [counterY][counterX] = 0;
                        //    }
                        //}
                        
                        //for (int counterY = 0; counterY < imageDimension; counterY++){
                        //    for (int counterX = 0; counterX < imageDimension; counterX++){
                        //        if (counterY-verticalStart2 >= 0 && counterY-verticalStart2 < dimension && counterX-horizontalStart2 >= 0 && counterX-horizontalStart2 < dimension){
                        //            if (mapTempImage [counterY][counterX] != 0){
                        //                sourceImageTest [counterY-verticalStart2][counterX-horizontalStart2] = mapTempImage [counterY][counterX];
                        //            }
                        //        }
                        //    }
                        //}
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<sourceImageTest [counterA][counterB];
                        //    cout<<" sourceImageTest "<<counterA<<endl;
                        //}
                        
                        //for (int counter1 = 0; counter1 < dimension+1; counter1++){
                        //    delete [] sourceImageTest [counter1];
                        //}
                        
                        //delete [] sourceImageTest;
                        
                        //==================
                        
                        errorNoHold = 58;
                        int **mapProcessImage = new int *[dimension+1];
                        for (int counter1 = 0; counter1 < dimension+1; counter1++){
                            errorNoHold = 59;
                            mapProcessImage [counter1] = new int [dimension+1];
                        }
                        
                        for (int counterY = 0; counterY < dimension+1; counterY++){
                            for (int counterX = 0; counterX < dimension+1; counterX++) mapProcessImage [counterY][counterX] = 0;
                        }
                        
                        //for (int counterA = 0; counterA < 200; counterA++){
                        //	for (int counterB = 0; counterB < 200; counterB++) cout<<" "<<revisedMap [counterA][counterB];
                        //	cout<<" revisedMap1 "<<counterA<<endl;
                        //}
                        
                        for (int counterY = 0; counterY < imageDimension; counterY++){
                            for (int counterX = 0; counterX < imageDimension; counterX++){
                                putativeMap [counterY][counterX] = 0;
                                
                                if (counterY-verticalStart2 >= 0 && counterY-verticalStart2 < dimension && counterX-horizontalStart2 >= 0 && counterX-horizontalStart2 < dimension){
                                    mapProcessImage [counterY-verticalStart2][counterX-horizontalStart2] = mapTempImage [counterY][counterX];
                                }
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] mapTempImage [counter1];
                        delete [] mapTempImage;
                        
                        maxConnectRevise = 0;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (mapProcessImage [counterY][counterX] > maxConnectRevise) maxConnectRevise = mapProcessImage [counterY][counterX];
                            }
                        }
                        
                        errorNoHold = 60;
                        int *findConnectNo = new int [maxConnectRevise+5];
                        for (int counter1 = 0; counter1 < maxConnectRevise+5; counter1++) findConnectNo [counter1] = 0;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (mapProcessImage [counterY][counterX] != 0) findConnectNo [mapProcessImage [counterY][counterX]]++;
                            }
                        }
                        
                        int extendConnectCount = 0;
                        
                        for (int counter1 = 1; counter1 < maxConnectRevise+1; counter1++){
                            if (findConnectNo [counter1] != 0 && connectNoCheck != counter1) extendConnectCount++;
                        }
                        
                        errorNoHold = 61;
                        int *extendConnectList = new int [extendConnectCount+1];
                        extendConnectCount = 0;
                        
                        for (int counter1 = 1; counter1 < maxConnectRevise+1; counter1++){
                            if (findConnectNo [counter1] != 0 && connectNoCheck != counter1){
                                extendConnectList [extendConnectCount] = counter1, extendConnectCount++;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < timeSelectedTempCount/10; counter1++){
                            for (int counter2 = 0; counter2 < extendConnectCount; counter2++){
                                if (extendConnectList [counter2] == arrayTimeSelectedTemp [counter1*10+8]){
                                    if (arrayTimeSelectedTemp [counter1*10] == 0 || arrayTimeSelectedTemp [counter1*10] == 3 || arrayTimeSelectedTemp [counter1*10] == 4 || arrayTimeSelectedTemp [counter1*10] == 2){ extendConnectList [counter2] = 0;
                                        
                                        break;
                                    }
                                }
                            }
                        }
                        
                        int connectFind = 0;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                connectFind = 0;
                                
                                for (int counter1 = 0; counter1 < extendConnectCount; counter1++){
                                    if (extendConnectList [counter1] == mapProcessImage [counterY][counterX]) connectFind = 1;
                                }
                                
                                if (connectFind == 0) mapProcessImage [counterY][counterX] = 0;
                            }
                        }
                        
                        delete [] findConnectNo;
                        delete [] extendConnectList;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                                    putativeMap [counterY+verticalStart2][counterX+horizontalStart2] = mapProcessImage [counterY][counterX]*-1;
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<< mapProcessImage [counterA][counterB];
                        //    cout<<"  mapProcessImage "<<counterA<<endl;
                        //}
                        
                        for (int counter1 = 0; counter1 < dimension+1; counter1++) delete [] mapProcessImage [counter1];
                        delete [] mapProcessImage;
                    }
                    
                    if (sourceArea2 != 0){
                        errorNoHold = 62;
                        int *overlapList5 = new int [maxConnectNumberList+2];
                        errorNoHold = 63;
                        int *overlapList6 = new int [maxConnectNumberList+2];
                        
                        for (int counter1 = 0; counter1 < maxConnectNumberList+2; counter1++){
                            overlapList5 [counter1] = 0;
                            overlapList6 [counter1] = 0;
                        }
                        
                        for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                            if (overlapList [counter1] != 0) overlapList2 [overlapListCount2] = counter1, overlapListCount2++;
                        }
                        
                        //for (int counterA = 0; counterA < overlapListCount2; counterA++){
                        //    cout<<counterA<<" "<<overlapList2 [counterA]<<" Overlap2"<<endl;
                        //}
                        
                        for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                            for (int counter2 = 0; counter2 < overlapListCount2; counter2++){
                                if (arrayGravityCenterRev [counter1*6+4] == overlapList2 [counter2]) overlapList6 [counter2] = arrayGravityCenterRev [counter1*6+3];
                            }
                        }
                        
                        //for (int counterA = 0; counterA < overlapListCount2; counterA++){
                        //  cout<<counterA<<" "<<overlapList6 [counterA]<<" Overlap6"<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap4A [counterA][counterB];
                        //    cout<<" previousMap4A "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3A [counterA][counterB];
                        //    cout<<" previousMap3A "<<counterA<<endl;
                        //}
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < dimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < dimension && revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2] != 0){
                                    for (int counter1 = 0; counter1 < overlapListCount2; counter1++){
                                        if (revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2] == overlapList2 [counter1]){
                                            if (previousMap3A [counterY][counterX] != 1) previousMap3A [counterY][counterX] = overlapList2 [counter1]*-1;
                                            previousMap5A [counterY][counterX] = overlapList2 [counter1]*-1;
                                        }
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3A [counterA][counterB];
                        //    cout<<" previousMap3A "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap5A [counterA][counterB];
                        //    cout<<" previousMap5A "<<counterA<<endl;
                        //}
                        
                        errorNoHold = 64;
                        int **sourceImageTemp = new int *[dimension+1];
                        for (int counter1 = 0; counter1 < dimension+1; counter1++){
                            errorNoHold = 65;
                            sourceImageTemp [counter1] = new int [dimension+1];
                        }
                        
                        for (int counterY = 0; counterY < dimension+1; counterY++){
                            for (int counterX = 0; counterX < dimension+1; counterX++) sourceImageTemp [counterY][counterX] = 0;
                        }
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                                    sourceImageTemp [counterY][counterX] = sourceImage [mapPositionPointer][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2];
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<sourceImageTemp [counterA][counterB];
                        //    cout<<" sourceImageTemp "<<counterA<<endl;
                        //}
                        
                        errorNoHold = 66;
                        int **connectivityMap2 = new int *[dimension+1];
                        errorNoHold = 67;
                        int **connectivityCount = new int *[dimension+1];
                        
                        for (int counter1 = 0; counter1 < dimension+1; counter1++){
                            errorNoHold = 68;
                            connectivityMap2 [counter1] = new int [dimension+1];
                            errorNoHold = 69;
                            connectivityCount [counter1] = new int [dimension+1];
                        }
                        
                        for (int counterY = 0; counterY < dimension+1; counterY++){
                            for (int counterX = 0; counterX < dimension+1; counterX++){
                                connectivityMap2 [counterY][counterX] = 0;
                                connectivityCount [counterY][counterX] = 0;
                            }
                        }
                        
                        int overlap = 0;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (previousMap3A [counterY][counterX] == 1 && previousMap4A [counterY][counterX] != 0) overlap++;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3A [counterA][counterB];
                        //    cout<<" previousMap3A "<<counterA<<endl;
                        //}
                        
                        double areaPercentage = overlap/(double)sourceArea2;
                        
                        if ((roundStatus == 2 && imageNumberInt == timeEventEntryHold) || (roundStatus == 2 && imageNumberInt > timeEventEntryHold && cellStatusLoading == 1)){
                            if (areaPercentage > 0.8){
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++){
                                        if (previousMap3A [counterY][counterX] == 10 || previousMap3A [counterY][counterX] == 1) previousMap3A [counterY][counterX] = 1;
                                        else previousMap3A [counterY][counterX] = 0;
                                    }
                                }
                            }
                            else{
                                
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++){
                                        if (previousMap3A [counterY][counterX] == 1) previousMap3A [counterY][counterX] = 1;
                                        else previousMap3A [counterY][counterX] = 0;
                                    }
                                }
                            }
                            
                            if (putativeMapStatus == 0){
                                errorNoHold = 70;
                                putativeMap = new int *[imageDimension+1];
                                for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                                    errorNoHold = 71;
                                    putativeMap [counter1] = new int [imageDimension+1];
                                }
                                
                                putativeMapStatus = 1;
                                putativeMapSizeHold = imageDimension;
                            }
                            else if (putativeMapStatus == 1 && 300 < putativeMapSizeHold && 300 > imageDimension){
                                for (int counter1 = 0; counter1 < putativeMapSizeHold+1; counter1++) delete [] putativeMap [counter1];
                                delete [] putativeMap;
                                
                                putativeMapSizeHold = imageDimension;
                                
                                errorNoHold = 72;
                                putativeMap = new int *[imageDimension+1];
                                for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                                    errorNoHold = 73;
                                    putativeMap [counter1] = new int [imageDimension+1];
                                }
                            }
                            else if (putativeMapStatus == 1 && putativeMapSizeHold < imageDimension){
                                for (int counter1 = 0; counter1 < putativeMapSizeHold+1; counter1++) delete [] putativeMap [counter1];
                                delete [] putativeMap;
                                
                                errorNoHold = 74;
                                putativeMap = new int *[imageDimension+1];
                                for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                                    errorNoHold = 75;
                                    putativeMap [counter1] = new int [imageDimension+1];
                                }
                                
                                putativeMapSizeHold = imageDimension;
                            }
                            
                            maxConnectRevise = 0;
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                                        if (revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2];
                                    }
                                }
                            }
                            
                            for (int counterY = 0; counterY < imageDimension; counterY++){
                                for (int counterX = 0; counterX < imageDimension; counterX++) putativeMap [counterY][counterX] = 0;
                            }
                            
                            //for (int counterA = 0; counterA < dimension; counterA++){
                            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<revisedWorkingMap [counterA][counterB];
                            //    cout<<" revisedWorkingMap "<<counterA<<endl;
                            //}
                            
                            errorNoHold = 76;
                            int *findConnectNo = new int [maxConnectRevise+5];
                            for (int counter1 = 0; counter1 < maxConnectRevise+5; counter1++) findConnectNo [counter1] = 0;
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                                        if (revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2] != 0){
                                            findConnectNo [revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2]]++;
                                        }
                                    }
                                }
                            }
                            
                            int extendConnectCount = 0;
                            
                            for (int counter1 = 1; counter1 < maxConnectRevise+1; counter1++){
                                if (findConnectNo [counter1] != 0 && connectNoCheck != counter1) extendConnectCount++;
                            }
                            
                            errorNoHold = 77;
                            int *extendConnectList = new int [extendConnectCount+1];
                            extendConnectCount = 0;
                            
                            for (int counter1 = 1; counter1 < maxConnectRevise+1; counter1++){
                                if (findConnectNo [counter1] != 0 && connectNoCheck != counter1) extendConnectList [extendConnectCount] = counter1, extendConnectCount++;
                            }
                            
                            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                                for (int counter2 = 0; counter2 < extendConnectCount; counter2++){
                                    if (extendConnectList [counter2] == arrayTimeSelected [counter1*10+8]){
                                        if (arrayTimeSelected [counter1*10] == 0 || arrayTimeSelected [counter1*10] == 3 || arrayTimeSelected [counter1*10] == 4 || arrayTimeSelected [counter1*10] == 2){
                                            extendConnectList [counter2] = 0;
                                        }
                                        
                                        break;
                                    }
                                }
                            }
                            
                            int connectFind = 0;
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension && revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2] != 0){
                                        connectFind = 0;
                                        
                                        for (int counter1 = 0; counter1 < extendConnectCount; counter1++){
                                            if (extendConnectList [counter1] == revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2]) connectFind = 1;
                                        }
                                        
                                        if (connectFind == 0) putativeMap [counterY+verticalStart2][counterX+horizontalStart2] = 0;
                                        else putativeMap [counterY+verticalStart2][counterX+horizontalStart2] = revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2]*-1;
                                    }
                                }
                            }
                            
                            //int **sourceImageTest = new int *[dimension+1]; //=======For check
                            
                            //for (int counter1 = 0; counter1 < dimension+1; counter1++){
                            //    sourceImageTest [counter1] = new int [dimension+1];
                            //}
                            
                            //for (int counterY = 0; counterY < dimension; counterY++){
                            //    for (int counterX = 0; counterX < dimension; counterX++){
                            //        sourceImageTest [counterY][counterX] = 0;
                            //    }
                            //}
                            
                            //for (int counterY = 0; counterY < imageDimension; counterY++){
                            //    for (int counterX = 0; counterX < imageDimension; counterX++){
                            //        if (counterY-verticalStart2 >= 0 && counterY-verticalStart2 < dimension && counterX-horizontalStart2 >= 0 && counterX-horizontalStart2 < dimension){
                            //            if (putativeMap [counterY][counterX] != 0){
                            //                sourceImageTest [counterY-verticalStart2][counterX-horizontalStart2] = putativeMap [counterY][counterX];
                            //            }
                            //        }
                            //    }
                            //}
                            
                            // for (int counterA = 0; counterA < dimension; counterA++){
                            //   	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<sourceImageTest [counterA][counterB];
                            //   	cout<<" sourceImage "<<counterA<<endl;
                            // }
                            
                            //for (int counter1 = 0; counter1 < dimension+1; counter1++){
                            //    delete [] sourceImageTest [counter1];
                            // }
                            
                            // delete [] sourceImageTest;
                            
                            //===============
                            
                            delete [] findConnectNo;
                            delete [] extendConnectList;
                        }
                        else{
                            
                            errorNoHold = 78;
                            int **mapProcessImage = new int *[dimension+1];
                            
                            for (int counter1 = 0; counter1 < dimension+1; counter1++){
                                errorNoHold = 79;
                                mapProcessImage [counter1] = new int [dimension+1];
                            }
                            
                            for (int counterY = 0; counterY < dimension+1; counterY++){
                                for (int counterX = 0; counterX < dimension+1; counterX++) mapProcessImage [counterY][counterX] = 0;
                            }
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                                        mapProcessImage [counterY][counterX] = putativeMap [counterY+verticalStart2][counterX+horizontalStart2];
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < dimension; counterA++){
                            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<mapProcessImage [counterA][counterB];
                            //    cout<<" mapProcessImage "<<counterA<<endl;
                            // }
                            
                            maxConnectRevise = 0;
                            int putativeConnectMax = 0;
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (mapProcessImage [counterY][counterX] > 0 && mapProcessImage [counterY][counterX] > maxConnectRevise) maxConnectRevise = mapProcessImage [counterY][counterX];
                                    if (mapProcessImage [counterY][counterX] < 0 && mapProcessImage [counterY][counterX]*-1 > putativeConnectMax) putativeConnectMax = mapProcessImage [counterY][counterX]*-1;
                                }
                            }
                            
                            if (maxConnectRevise == 0) maxConnectRevise = 2;
                            
                            errorNoHold = 80;
                            int *findConnectNo = new int [putativeConnectMax+5];
                            for (int counter1 = 0; counter1 < putativeConnectMax+5; counter1++) findConnectNo [counter1] = 0;
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (mapProcessImage [counterY][counterX] < 0) findConnectNo [mapProcessImage [counterY][counterX]*-1]++;
                                }
                            }
                            
                            int extendConnectCount = 0;
                            
                            for (int counter1 = 1; counter1 < putativeConnectMax+1; counter1++){
                                if (findConnectNo [counter1] != 0) extendConnectCount++;
                            }
                            
                            errorNoHold = 81;
                            int *extendConnectList = new int [extendConnectCount*2+4];
                            extendConnectCount = 0;
                            
                            for (int counter1 = 1; counter1 < putativeConnectMax+1; counter1++){
                                if (findConnectNo [counter1] != 0){
                                    extendConnectList [extendConnectCount] = counter1, extendConnectCount++;
                                    extendConnectList [extendConnectCount] = 0, extendConnectCount++;
                                }
                            }
                            
                            int lineageNoTemp = 0;
                            int cellNoTemp = 0;
                            int newConnectNo = 0;
                            
                            for (int counter1 = 0; counter1 < timeSelectedTempCount/10; counter1++){
                                for (int counter2 = 0; counter2 < extendConnectCount/2; counter2++){
                                    if (extendConnectList [counter2*2] == arrayTimeSelectedTemp [counter1*10+8]){
                                        lineageNoTemp = 0;
                                        cellNoTemp = 0;
                                        
                                        for (int counter3 = 0; counter3 < connectLineageRelTempCount/6; counter3++){
                                            if (arrayConnectLineageRelTemp [counter3*6+1] == arrayTimeSelectedTemp [counter1*10+8]){
                                                lineageNoTemp = arrayConnectLineageRelTemp [counter3*6];
                                                cellNoTemp = arrayConnectLineageRelTemp [counter3*6+3];
                                                break;
                                            }
                                        }
                                        
                                        newConnectNo = 0;
                                        
                                        for (int counter3 = 0; counter3 < connectLineageRelCount/6; counter3++){
                                            if (arrayConnectLineageRel [counter3*6] == lineageNoTemp && arrayConnectLineageRel [counter3*6+3] == cellNoTemp){
                                                newConnectNo = arrayConnectLineageRel [counter3*6+1];
                                                break;
                                            }
                                        }
                                        
                                        if (newConnectNo != 0) extendConnectList [counter2*2+1] = newConnectNo*-1;
                                        else{
                                            
                                            maxConnectRevise++;
                                            extendConnectList [counter2*2+1] = maxConnectRevise;
                                        }
                                        
                                        break;
                                    }
                                }
                            }
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                                        if (extendConnectList [counter1*2] == mapProcessImage [counterY][counterX]*-1 && extendConnectList [counter1*2+1] != 0){
                                            mapProcessImage [counterY][counterX] = extendConnectList [counter1*2+1];
                                        }
                                    }
                                }
                            }
                            
                            delete [] findConnectNo;
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (previousMap3A [counterY][counterX] != 1 && mapProcessImage [counterY][counterX] > 0 && previousMap3ATemp1 [counterY][counterX] == 0) previousMap3A [counterY][counterX] = mapProcessImage [counterY][counterX];
                                    else if (previousMap3A [counterY][counterX] != 1 && previousMap4A [counterY][counterX] != 0 && mapProcessImage [counterY][counterX] == 0 && previousMap3ATemp1 [counterY][counterX] == 0) previousMap3A [counterY][counterX] = 2;
                                    else if (previousMap3A [counterY][counterX] != 1 && previousMap4A [counterY][counterX] != 0 && mapProcessImage [counterY][counterX] == 0 && previousMap3ATemp1 [counterY][counterX] != 0) previousMap3A [counterY][counterX] = -1;
                                }
                            }
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (previousMap3A [counterY][counterX] != 1 && previousMap3A [counterY][counterX] != 2 && previousMap3A [counterY][counterX] <= -1){
                                        connectivityMap2 [counterY][counterX] = -1;
                                    }
                                    else connectivityMap2 [counterY][counterX] = 0;
                                }
                            }
                            
                            connectivityNumber = 0;
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (connectivityMap2 [counterY][counterX] == -1){
                                        connectivityNumber++;
                                        connectivityMap2 [counterY][counterX] = connectivityNumber;
                                        connectAnalysisCount = 0;
                                        
                                        if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMap2 [counterY-1][counterX-1] == -1){
                                            connectivityMap2 [counterY-1][counterX-1] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                        }
                                        if (counterY-1 >= 0 && connectivityMap2 [counterY-1][counterX] == -1){
                                            connectivityMap2 [counterY-1][counterX] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                        }
                                        if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMap2 [counterY-1][counterX+1] == -1){
                                            connectivityMap2 [counterY-1][counterX+1] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                        }
                                        if (counterX+1 < dimension && connectivityMap2 [counterY][counterX+1] == -1){
                                            connectivityMap2 [counterY][counterX+1] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                        }
                                        if (counterY+1 < dimension && counterX+1 < dimension && connectivityMap2 [counterY+1][counterX+1] == -1){
                                            connectivityMap2 [counterY+1][counterX+1] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                        }
                                        if (counterY+1 < dimension && connectivityMap2 [counterY+1][counterX] == -1){
                                            connectivityMap2 [counterY+1][counterX] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                        }
                                        if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMap2 [counterY+1][counterX-1] == -1){
                                            connectivityMap2 [counterY+1][counterX-1] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                        }
                                        if (counterX-1 >= 0 && connectivityMap2 [counterY][counterX-1] == -1){
                                            connectivityMap2 [counterY][counterX-1] = connectivityNumber;
                                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                        }
                                        
                                        if (connectAnalysisCount != 0){
                                            do{
                                                
                                                terminationFlag = 1;
                                                connectAnalysisTempCount = 0;
                                                
                                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                                    
                                                    if (ySource-1 >= 0 && xSource-1 >= 0 && connectivityMap2 [ySource-1][xSource-1] == -1){
                                                        connectivityMap2 [ySource-1][xSource-1] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                    }
                                                    if (ySource-1 >= 0 && connectivityMap2 [ySource-1][xSource] == -1){
                                                        connectivityMap2 [ySource-1][xSource] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                    }
                                                    if (ySource-1 >= 0 && xSource+1 < dimension && connectivityMap2 [ySource-1][xSource+1] == -1){
                                                        connectivityMap2 [ySource-1][xSource+1] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                    }
                                                    if (xSource+1 < dimension && connectivityMap2 [ySource][xSource+1] == -1){
                                                        connectivityMap2 [ySource][xSource+1] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                    }
                                                    if (ySource+1 > dimension && xSource+1 < dimension && connectivityMap2 [ySource+1][xSource+1] == -1){
                                                        connectivityMap2 [ySource+1][xSource+1] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                    }
                                                    if (ySource+1 < dimension && connectivityMap2 [ySource+1][xSource] == -1){
                                                        connectivityMap2 [ySource+1][xSource] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                    }
                                                    if (ySource+1 < dimension && xSource-1 >= 0 && connectivityMap2 [ySource+1][xSource-1] == -1){
                                                        connectivityMap2 [ySource+1][xSource-1] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                    }
                                                    if (xSource-1 >= 0 && connectivityMap2 [ySource][xSource-1] == -1){
                                                        connectivityMap2 [ySource][xSource-1] = connectivityNumber;
                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                    }
                                                }
                                                
                                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                                }
                                                
                                                connectAnalysisCount = connectAnalysisTempCount;
                                                
                                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                                
                                            } while (terminationFlag == 1);
                                        }
                                    }
                                }
                            }
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (previousMap3A [counterY][counterX] == 1 || previousMap3A [counterY][counterX] == 2) connectivityMap2 [counterY][counterX] = -1;
                                }
                            }
                            
                            int otherGroupFind = 0;
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (connectivityMap2 [counterY][counterX] == -1){
                                        if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMap2 [counterY-1][counterX-1] > 0){
                                            otherGroupFind = 1;
                                            break;
                                        }
                                        if (counterY-1 >= 0 && connectivityMap2 [counterY-1][counterX] > 0){
                                            otherGroupFind = 1;
                                            break;
                                        }
                                        if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMap2 [counterY-1][counterX+1] > 0){
                                            otherGroupFind = 1;
                                            break;
                                        }
                                        if (counterX+1 < dimension && connectivityMap2 [counterY][counterX+1] > 0){
                                            otherGroupFind = 1;
                                            break;
                                        }
                                        if (counterY+1 < dimension && counterX+1 < dimension && connectivityMap2 [counterY+1][counterX+1] > 0){
                                            otherGroupFind = 1;
                                            break;
                                        }
                                        if (counterY+1 < dimension && connectivityMap2 [counterY+1][counterX] > 0){
                                            otherGroupFind = 1;
                                            break;
                                        }
                                        if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMap2 [counterY+1][counterX-1] > 0){
                                            otherGroupFind = 1;
                                            break;
                                        }
                                        if (counterX-1 >= 0 && connectivityMap2 [counterY][counterX-1] > 0){
                                            otherGroupFind = 1;
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++) connectivityMap2 [counterY][counterX] = previousMap3A [counterY][counterX];
                            }
                            
                            errorNoHold = 82;
                            int *extendConnectList2 = new int [maxConnectRevise*2+4];
                            int extendConnectCount2 = 0;
                            
                            for (int counter1 = 0; counter1 < maxConnectRevise; counter1++){
                                extendConnectList2 [extendConnectCount2] = counter1+1, extendConnectCount2++;
                                extendConnectList2 [extendConnectCount2] = 0, extendConnectCount2++;
                            }
                            
                            extendConnectList2 [3] = 1;
                            
                            gravityCenterPrevX = gravityCenterPrevX-horizontalStart2;
                            gravityCenterPrevY = gravityCenterPrevY-verticalStart2;
                            
                            int expansionArea = sourceAreaTemp-sourceArea2;
                            int expansionAreaAdjust = 0;
                            int expansionAccumulate = 0;
                            
                            if (cellDeterminationCheck == 7) expansionAreaAdjust = (int)(expansionArea*(1-areaPercentage));
                            else expansionAreaAdjust = (int)(expansionArea*(1-areaPercentage)*1.5);
                            
                            //cout<<sourceAreaTemp<<" "<<sourceAreaTemp*0.5<<" "<<sourceAreaTemp*0.25<<" "<<sourceArea2<<" "<<areaPercentage<<" "<<expansionArea<<" "<<expansionAreaAdjust<<" sourceinfo"<<endl;
                            
                            //for (int counterA = 0; counterA < dimension; counterA++){
                            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3A [counterA][counterB];
                            //    cout<<" previousMap3A "<<counterA<<endl;
                            //}
                            
                            if ((expansionAreaAdjust > 0 && previousMap3A [gravityCenterPrevY][gravityCenterPrevX] != 1) || otherGroupFind == 1){
                                int findFreePoint = 0;
                                int minusEdgePoint = 0;
                                int twoEdgePoint = 0;
                                int setRound = 0;
                                
                                if (otherGroupFind == 1){
                                    terminationFlag = 0;
                                    
                                    do{
                                        
                                        findFreePoint = 0;
                                        
                                        for (int counterY = 2; counterY < dimension-2; counterY++){
                                            for (int counterX = 2; counterX < dimension-2; counterX++){
                                                if (previousMap3A [counterY][counterX] == 1){
                                                    if (counterY-1 >= 0 && counterX-1 >= 0){
                                                        if (previousMap3ATemp1 [counterY-1][counterX-1] == 0 && previousMap3A [counterY-1][counterX-1] == 2){
                                                            if (connectivityMap2 [counterY-1][counterX-1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY-1][counterX-1] = 1;
                                                        }
                                                    }
                                                    if (counterY-1 >= 0){
                                                        if (previousMap3ATemp1 [counterY-1][counterX] == 0 && previousMap3A [counterY-1][counterX] == 2){
                                                            if (connectivityMap2 [counterY-1][counterX] != 1) findFreePoint = 1;
                                                            
                                                            connectivityMap2 [counterY-1][counterX] = 1;
                                                        }
                                                    }
                                                    if (counterY-1 >= 0 && counterX+1 < dimension){
                                                        if (previousMap3ATemp1 [counterY-1][counterX+1] == 0 && previousMap3A [counterY-1][counterX+1] == 2){
                                                            if (connectivityMap2 [counterY-1][counterX+1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY-1][counterX+1] = 1;
                                                        }
                                                    }
                                                    if (counterX+1 < dimension){
                                                        if (previousMap3ATemp1 [counterY][counterX+1] == 0 && previousMap3A [counterY][counterX+1] == 2){
                                                            if (connectivityMap2 [counterY][counterX+1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY][counterX+1] = 1;
                                                        }
                                                    }
                                                    if (counterY+1 < dimension && counterX+1 < dimension){
                                                        if (previousMap3ATemp1 [counterY+1][counterX+1] == 0 && previousMap3A [counterY+1][counterX+1] == 2){
                                                            if (connectivityMap2 [counterY+1][counterX+1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY+1][counterX+1] = 1;
                                                        }
                                                    }
                                                    if (counterY+1 < dimension){
                                                        if (previousMap3ATemp1 [counterY+1][counterX] == 0 && previousMap3A [counterY+1][counterX] == 2){
                                                            if (connectivityMap2 [counterY+1][counterX] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY+1][counterX] = 1;
                                                        }
                                                    }
                                                    if (counterY+1 < dimension && counterX-1 >= 0){
                                                        if (previousMap3ATemp1 [counterY+1][counterX-1] == 0 && previousMap3A [counterY+1][counterX-1] == 2){
                                                            if (connectivityMap2 [counterY+1][counterX-1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY+1][counterX-1] = 1;
                                                        }
                                                    }
                                                    if (counterX-1 >= 0){
                                                        if (previousMap3ATemp1 [counterY][counterX-1] == 0 && previousMap3A [counterY][counterX-1] == 2){
                                                            if (connectivityMap2 [counterY][counterX-1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY][counterX-1] = 1;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (findFreePoint != 0){
                                            for (int counterY = 0; counterY < dimension; counterY++){
                                                for (int counterX = 0; counterX < dimension; counterX++) previousMap3A [counterY][counterX] = connectivityMap2 [counterY][counterX];
                                            }
                                        }
                                        else terminationFlag = 1;
                                        
                                    } while (terminationFlag == 0);
                                }
                                else if (sourceAreaTemp*0.5 <= sourceArea2){
                                    terminationFlag = 0;
                                    
                                    do{
                                        
                                        findFreePoint = 0;
                                        minusEdgePoint = 0;
                                        twoEdgePoint = 0;
                                        setRound = roundStatus%2;
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++) connectivityCount [counterY][counterX] = 0;
                                        }
                                        
                                        for (int counterY = 2; counterY < dimension-2; counterY++){
                                            for (int counterX = 2; counterX < dimension-2; counterX++){
                                                if (previousMap3A [counterY][counterX] == 1){
                                                    if (counterY-1 >= 0 && counterX-1 >= 0){
                                                        if (previousMap3ATemp1 [counterY-1][counterX-1] == 0 && previousMap3A [counterY-1][counterX-1] == 2){
                                                            if (connectivityMap2 [counterY-1][counterX-1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY-1][counterX-1] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY-1][counterX-1] < 0 && connectivityCount [counterY-1][counterX-1] == 0) minusEdgePoint++;
                                                        if (previousMap3A [counterY-1][counterX-1] == 2 && connectivityCount [counterY-1][counterX-1] == 0) twoEdgePoint++;
                                                        if (previousMap3A [counterY-1][counterX-1] != 1 && connectivityCount [counterY-1][counterX-1] == 0){
                                                            connectivityCount [counterY-1][counterX-1] = 1;
                                                        }
                                                    }
                                                    if (counterY-1 >= 0){
                                                        if (previousMap3ATemp1 [counterY-1][counterX] == 0 && previousMap3A [counterY-1][counterX] == 2){
                                                            if (connectivityMap2 [counterY-1][counterX] != 1) findFreePoint = 1;
                                                            
                                                            connectivityMap2 [counterY-1][counterX] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY-1][counterX] < 0 && connectivityCount [counterY-1][counterX] == 0) minusEdgePoint++;
                                                        if (previousMap3A [counterY-1][counterX] == 2 && connectivityCount [counterY-1][counterX] == 0) twoEdgePoint++;
                                                        if (previousMap3A [counterY-1][counterX] != 1 && connectivityCount [counterY-1][counterX] == 0){
                                                            connectivityCount [counterY-1][counterX] = 1;
                                                        }
                                                    }
                                                    if (counterY-1 >= 0 && counterX+1 < dimension){
                                                        if (previousMap3ATemp1 [counterY-1][counterX+1] == 0 && previousMap3A [counterY-1][counterX+1] == 2){
                                                            if (connectivityMap2 [counterY-1][counterX+1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY-1][counterX+1] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY-1][counterX+1] < 0 && connectivityCount [counterY-1][counterX+1] == 0) minusEdgePoint++;
                                                        if (previousMap3A [counterY-1][counterX+1] == 2 && connectivityCount [counterY-1][counterX+1] == 0) twoEdgePoint++;
                                                        if (previousMap3A [counterY-1][counterX+1] != 1 && connectivityCount [counterY-1][counterX+1] == 0){
                                                            connectivityCount [counterY-1][counterX+1] = 1;
                                                        }
                                                    }
                                                    if (counterX+1 < dimension){
                                                        if (previousMap3ATemp1 [counterY][counterX+1] == 0 && previousMap3A [counterY][counterX+1] == 2){
                                                            if (connectivityMap2 [counterY][counterX+1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY][counterX+1] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY][counterX+1] < 0 && connectivityCount [counterY][counterX+1] == 0) minusEdgePoint++;
                                                        if (previousMap3A [counterY][counterX+1] == 2 && connectivityCount [counterY][counterX+1] == 0) twoEdgePoint++;
                                                        if (previousMap3A [counterY][counterX+1] != 1 && connectivityCount [counterY][counterX+1] == 0){
                                                            connectivityCount [counterY][counterX+1] = 1;
                                                        }
                                                    }
                                                    if (counterY+1 < dimension && counterX+1 < dimension){
                                                        if (previousMap3ATemp1 [counterY+1][counterX+1] == 0 && previousMap3A [counterY+1][counterX+1] == 2){
                                                            if (connectivityMap2 [counterY+1][counterX+1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY+1][counterX+1] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY+1][counterX+1] < 0 && connectivityCount [counterY+1][counterX+1] == 0) minusEdgePoint++;
                                                        if (previousMap3A [counterY+1][counterX+1] == 2 && connectivityCount [counterY+1][counterX+1] == 0) twoEdgePoint++;
                                                        if (previousMap3A [counterY+1][counterX+1] != 1 && connectivityCount [counterY+1][counterX+1] == 0){
                                                            connectivityCount [counterY+1][counterX+1] = 1;
                                                        }
                                                    }
                                                    if (counterY+1 < dimension){
                                                        if (previousMap3ATemp1 [counterY+1][counterX] == 0 && previousMap3A [counterY+1][counterX] == 2){
                                                            if (connectivityMap2 [counterY+1][counterX] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY+1][counterX] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY+1][counterX] < 0 && connectivityCount [counterY+1][counterX] == 0) minusEdgePoint++;
                                                        if (previousMap3A [counterY+1][counterX] == 2 && connectivityCount [counterY+1][counterX] == 0) twoEdgePoint++;
                                                        if (previousMap3A [counterY+1][counterX] != 1 && connectivityCount [counterY+1][counterX] == 0){
                                                            connectivityCount [counterY+1][counterX] = 1;
                                                        }
                                                    }
                                                    if (counterY+1 < dimension && counterX-1 >= 0){
                                                        if (previousMap3ATemp1 [counterY+1][counterX-1] == 0 && previousMap3A [counterY+1][counterX-1] == 2){
                                                            if (connectivityMap2 [counterY+1][counterX-1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY+1][counterX-1] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY+1][counterX-1] < 0 && connectivityCount [counterY+1][counterX-1] == 0) minusEdgePoint++;
                                                        if (previousMap3A [counterY+1][counterX-1] == 2 && connectivityCount [counterY+1][counterX-1] == 0) twoEdgePoint++;
                                                        if (previousMap3A [counterY+1][counterX-1] != 1 && connectivityCount [counterY+1][counterX-1] == 0){
                                                            connectivityCount [counterY+1][counterX-1] = 1;
                                                        }
                                                    }
                                                    if (counterX-1 >= 0){
                                                        if (previousMap3ATemp1 [counterY][counterX-1] == 0 && previousMap3A [counterY][counterX-1] == 2){
                                                            if (connectivityMap2 [counterY][counterX-1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY][counterX-1] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY][counterX-1] < 0 && connectivityCount [counterY][counterX-1] == 0) minusEdgePoint++;
                                                        if (previousMap3A [counterY][counterX-1] == 2 && connectivityCount [counterY][counterX-1] == 0) twoEdgePoint++;
                                                        if (previousMap3A [counterY][counterX-1] != 1 && connectivityCount [counterY][counterX-1] == 0){
                                                            connectivityCount [counterY][counterX-1] = 1;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (findFreePoint != 0){
                                            for (int counterY = 0; counterY < dimension; counterY++){
                                                for (int counterX = 0; counterX < dimension; counterX++) previousMap3A [counterY][counterX] = connectivityMap2 [counterY][counterX];
                                            }
                                            
                                            expansionAccumulate = expansionAccumulate+findFreePoint;
                                            
                                            if (setRound == 0 && (minusEdgePoint*0.1 > twoEdgePoint || expansionAccumulate > expansionArea)) terminationFlag = 1;
                                            else if (setRound == 1 && (minusEdgePoint*0.1 > twoEdgePoint || expansionAccumulate > expansionArea*0.8)) terminationFlag = 1;
                                        }
                                        else terminationFlag = 1;
                                        
                                    } while (terminationFlag == 0);
                                }
                                else if (sourceAreaTemp*0.5 > sourceArea2 && sourceAreaTemp*0.25 <= sourceArea2){
                                    terminationFlag = 0;
                                    
                                    do{
                                        
                                        findFreePoint = 0;
                                        
                                        for (int counterY = 2; counterY < dimension-2; counterY++){
                                            for (int counterX = 2; counterX < dimension-2; counterX++) connectivityCount [counterY][counterX] = 0;
                                        }
                                        
                                        for (int counterY = 2; counterY < dimension-2; counterY++){
                                            for (int counterX = 2; counterX < dimension-2; counterX++){
                                                if (previousMap3A [counterY][counterX] == 1){
                                                    if (counterY-1 >= 0 && counterX-1 >= 0){
                                                        if (previousMap3ATemp1 [counterY-1][counterX-1] == 0 && previousMap3A [counterY-1][counterX-1] >= 2){
                                                            if (connectivityMap2 [counterY-1][counterX-1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY-1][counterX-1] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY-1][counterX-1] != 1 && connectivityCount [counterY-1][counterX-1] == 0){
                                                            connectivityCount [counterY-1][counterX-1] = 1;
                                                        }
                                                    }
                                                    if (counterY-1 >= 0){
                                                        if (previousMap3ATemp1 [counterY-1][counterX] == 0 && previousMap3A [counterY-1][counterX] >= 2){
                                                            if (connectivityMap2 [counterY-1][counterX] != 1) findFreePoint = 1;
                                                            
                                                            connectivityMap2 [counterY-1][counterX] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY-1][counterX] != 1 && connectivityCount [counterY-1][counterX] == 0){
                                                            connectivityCount [counterY-1][counterX] = 1;
                                                        }
                                                    }
                                                    if (counterY-1 >= 0 && counterX+1 < dimension){
                                                        if (previousMap3ATemp1 [counterY-1][counterX+1] == 0 && previousMap3A [counterY-1][counterX+1] >= 2){
                                                            if (connectivityMap2 [counterY-1][counterX+1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY-1][counterX+1] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY-1][counterX+1] != 1 && connectivityCount [counterY-1][counterX+1] == 0){
                                                            connectivityCount [counterY-1][counterX+1] = 1;
                                                        }
                                                    }
                                                    if (counterX+1 < dimension){
                                                        if (previousMap3ATemp1 [counterY][counterX+1] == 0 && previousMap3A [counterY][counterX+1] >= 2){
                                                            if (connectivityMap2 [counterY][counterX+1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY][counterX+1] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY][counterX+1] != 1 && connectivityCount [counterY][counterX+1] == 0){
                                                            connectivityCount [counterY][counterX+1] = 1;
                                                        }
                                                    }
                                                    if (counterY+1 < dimension && counterX+1 < dimension){
                                                        if (previousMap3ATemp1 [counterY+1][counterX+1] == 0 && previousMap3A [counterY+1][counterX+1] >= 2){
                                                            if (connectivityMap2 [counterY+1][counterX+1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY+1][counterX+1] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY+1][counterX+1] != 1 && connectivityCount [counterY+1][counterX+1] == 0){
                                                            connectivityCount [counterY+1][counterX+1] = 1;
                                                        }
                                                    }
                                                    if (counterY+1 < dimension){
                                                        if (previousMap3ATemp1 [counterY+1][counterX] == 0 && previousMap3A [counterY+1][counterX] >= 2){
                                                            if (connectivityMap2 [counterY+1][counterX] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY+1][counterX] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY+1][counterX] != 1 && connectivityCount [counterY+1][counterX] == 0){
                                                            connectivityCount [counterY+1][counterX] = 1;
                                                        }
                                                    }
                                                    if (counterY+1 < dimension && counterX-1 >= 0){
                                                        if (previousMap3ATemp1 [counterY+1][counterX-1] == 0 && previousMap3A [counterY+1][counterX-1] >= 2){
                                                            if (connectivityMap2 [counterY+1][counterX-1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY+1][counterX-1] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY+1][counterX-1] != 1 && connectivityCount [counterY+1][counterX-1] == 0){
                                                            connectivityCount [counterY+1][counterX-1] = 1;
                                                        }
                                                    }
                                                    if (counterX-1 >= 0){
                                                        if (previousMap3ATemp1 [counterY][counterX-1] == 0 && previousMap3A [counterY][counterX-1] >= 2){
                                                            if (connectivityMap2 [counterY][counterX-1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY][counterX-1] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY][counterX-1] != 1 && connectivityCount [counterY][counterX-1] == 0){
                                                            connectivityCount [counterY][counterX-1] = 1;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (findFreePoint != 0){
                                            for (int counterY = 0; counterY < dimension; counterY++){
                                                for (int counterX = 0; counterX < dimension; counterX++) previousMap3A [counterY][counterX] = connectivityMap2 [counterY][counterX];
                                            }
                                            
                                            expansionAccumulate = expansionAccumulate+findFreePoint;
                                            
                                            if (expansionAccumulate > expansionAreaAdjust) terminationFlag = 1;
                                        }
                                        else terminationFlag = 1;
                                        
                                    } while (terminationFlag == 0);
                                }
                                else if (sourceAreaTemp*0.25 > sourceArea2){
                                    terminationFlag = 0;
                                    
                                    do{
                                        
                                        findFreePoint = 0;
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++) connectivityCount [counterY][counterX] = 0;
                                        }
                                        
                                        for (int counterY = 2; counterY < dimension-2; counterY++){
                                            for (int counterX = 2; counterX < dimension-2; counterX++){
                                                if (previousMap3A [counterY][counterX] == 1){
                                                    if (counterY-1 >= 0 && counterX-1 >= 0){
                                                        if (previousMap3ATemp1 [counterY-1][counterX-1] == 0 && previousMap3A [counterY-1][counterX-1] >= 2){
                                                            if (connectivityMap2 [counterY-1][counterX-1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY-1][counterX-1] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY-1][counterX-1] != 1 && connectivityCount [counterY-1][counterX-1] == 0){
                                                            connectivityCount [counterY-1][counterX-1] = 1;
                                                        }
                                                    }
                                                    if (counterY-1 >= 0){
                                                        if (previousMap3ATemp1 [counterY-1][counterX] == 0 && previousMap3A [counterY-1][counterX] >= 2){
                                                            if (connectivityMap2 [counterY-1][counterX] != 1) findFreePoint = 1;
                                                            
                                                            connectivityMap2 [counterY-1][counterX] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY-1][counterX] != 1 && connectivityCount [counterY-1][counterX] == 0){
                                                            connectivityCount [counterY-1][counterX] = 1;
                                                        }
                                                    }
                                                    if (counterY-1 >= 0 && counterX+1 < dimension){
                                                        if (previousMap3ATemp1 [counterY-1][counterX+1] == 0 && previousMap3A [counterY-1][counterX+1] >= 2){
                                                            if (connectivityMap2 [counterY-1][counterX+1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY-1][counterX+1] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY-1][counterX+1] != 1 && connectivityCount [counterY-1][counterX+1] == 0){
                                                            connectivityCount [counterY-1][counterX+1] = 1;
                                                        }
                                                    }
                                                    if (counterX+1 < dimension){
                                                        if (previousMap3ATemp1 [counterY][counterX+1] == 0 && previousMap3A [counterY][counterX+1] >= 2){
                                                            if (connectivityMap2 [counterY][counterX+1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY][counterX+1] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY][counterX+1] != 1 && connectivityCount [counterY][counterX+1] == 0){
                                                            connectivityCount [counterY][counterX+1] = 1;
                                                        }
                                                    }
                                                    if (counterY+1 < dimension && counterX+1 < dimension){
                                                        if (previousMap3ATemp1 [counterY+1][counterX+1] == 0 && previousMap3A [counterY+1][counterX+1] >= 2){
                                                            if (connectivityMap2 [counterY+1][counterX+1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY+1][counterX+1] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY+1][counterX+1] != 1 && connectivityCount [counterY+1][counterX+1] == 0){
                                                            connectivityCount [counterY+1][counterX+1] = 1;
                                                        }
                                                    }
                                                    if (counterY+1 < dimension){
                                                        if (previousMap3ATemp1 [counterY+1][counterX] == 0 && previousMap3A [counterY+1][counterX] >= 2){
                                                            if (connectivityMap2 [counterY+1][counterX] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY+1][counterX] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY+1][counterX] != 1 && connectivityCount [counterY+1][counterX] == 0){
                                                            connectivityCount [counterY+1][counterX] = 1;
                                                        }
                                                    }
                                                    if (counterY+1 < dimension && counterX-1 >= 0){
                                                        if (previousMap3ATemp1 [counterY+1][counterX-1] == 0 && previousMap3A [counterY+1][counterX-1] >= 2){
                                                            if (connectivityMap2 [counterY+1][counterX-1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY+1][counterX-1] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY+1][counterX-1] != 1 && connectivityCount [counterY+1][counterX-1] == 0){
                                                            connectivityCount [counterY+1][counterX-1] = 1;
                                                        }
                                                    }
                                                    if (counterX-1 >= 0){
                                                        if (previousMap3ATemp1 [counterY][counterX-1] == 0 && previousMap3A [counterY][counterX-1] >= 2){
                                                            if (connectivityMap2 [counterY][counterX-1] != 1) findFreePoint++;
                                                            
                                                            connectivityMap2 [counterY][counterX-1] = 1;
                                                        }
                                                        
                                                        if (previousMap3A [counterY][counterX-1] != 1 && connectivityCount [counterY][counterX-1] == 0){
                                                            connectivityCount [counterY][counterX-1] = 1;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (findFreePoint != 0){
                                            for (int counterY = 0; counterY < dimension; counterY++){
                                                for (int counterX = 0; counterX < dimension; counterX++) previousMap3A [counterY][counterX] = connectivityMap2 [counterY][counterX];
                                            }
                                            
                                            expansionAccumulate = expansionAccumulate+findFreePoint;
                                            
                                            if (expansionAccumulate > expansionAreaAdjust || expansionAccumulate > sourceArea2*3) terminationFlag = 1;
                                        }
                                        else terminationFlag = 1;
                                        
                                    } while (terminationFlag == 0);
                                }
                            }
                            
                            //for (int counterA = 0; counterA < dimension; counterA++){
                            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3A [counterA][counterB];
                            //    cout<<" mapreviousMap3A "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < dimension; counterA++){
                            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap2 [counterA][counterB];
                            //    cout<<" connectivityMap2 "<<counterA<<endl;
                            //}
                            
                            expansionArea = (int)((expansionArea-expansionAccumulate)*1.5);
                            
                            if (expansionArea > 0){
                                terminationFlag = 0;
                                int areaExpansionTotal = 0;
                                int startOrder = 0;
                                int findFreePoint = 0;
                                int connectNo = 0;
                                int mapConnectNo = 0;
                                int remainingCheck = 0;
                                
                                do{
                                    
                                    for (int counter1 = startOrder; counter1 < extendConnectCount2/2; counter1++){
                                        connectNo = extendConnectList2 [counter1*2];
                                        
                                        if (extendConnectList2 [counter1*2+1] == 0){
                                            findFreePoint = 0;
                                            
                                            for (int counterY = 2; counterY < dimension-2; counterY++){
                                                for (int counterX = 2; counterX < dimension-2; counterX++){
                                                    mapConnectNo = previousMap3A [counterY][counterX];
                                                    
                                                    if (mapConnectNo == connectNo){
                                                        if (counterY-1 >= 0 && counterX-1 >= 0 && ((mapConnectNo != 1 && (previousMap3A [counterY-1][counterX-1] < 0 || previousMap3A [counterY-1][counterX-1] == 2)) || (mapConnectNo == 1 && previousMap3A [counterY-1][counterX-1] == 2))){
                                                            connectivityMap2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                                            
                                                            if (connectNo == 1 && previousMap3A [counterY-1][counterX-1] != 1) areaExpansionTotal++;
                                                        }
                                                        if (counterY-1 >= 0 && ((mapConnectNo != 1 && (previousMap3A [counterY-1][counterX] < 0 || previousMap3A [counterY-1][counterX] == 2)) || (mapConnectNo == 1 && previousMap3A [counterY-1][counterX] == 2))){
                                                            connectivityMap2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                                            
                                                            if (connectNo == 1 && previousMap3A [counterY-1][counterX] != 1) areaExpansionTotal++;
                                                        }
                                                        if (counterY-1 >= 0 && counterX+1 < dimension && ((mapConnectNo != 1 && (previousMap3A [counterY-1][counterX+1] < 0 || previousMap3A [counterY-1][counterX+1] == 2)) || (mapConnectNo == 1 && previousMap3A [counterY-1][counterX+1] == 2))){
                                                            connectivityMap2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                                            
                                                            if (connectNo == 1 && previousMap3A [counterY-1][counterX+1] != 1) areaExpansionTotal++;
                                                        }
                                                        if (counterX+1 < dimension && ((mapConnectNo != 1 && (previousMap3A [counterY][counterX+1] < 0 || previousMap3A [counterY][counterX+1] == 2)) || (mapConnectNo == 1 && previousMap3A [counterY][counterX+1] == 2))){
                                                            connectivityMap2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                                            
                                                            if (connectNo == 1 && previousMap3A [counterY][counterX+1] != 1) areaExpansionTotal++;
                                                        }
                                                        if (counterY+1 < dimension && counterX+1 < dimension && ((mapConnectNo != 1 && (previousMap3A [counterY+1][counterX+1] < 0 || previousMap3A [counterY+1][counterX+1] == 2)) || (mapConnectNo == 1 && previousMap3A [counterY+1][counterX+1] == 2))){
                                                            connectivityMap2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                                            
                                                            if (connectNo == 1 && previousMap3A [counterY+1][counterX+1] != 1) areaExpansionTotal++;
                                                        }
                                                        if (counterY+1 < dimension && ((mapConnectNo != 1 && (previousMap3A [counterY+1][counterX] < 0 || previousMap3A [counterY+1][counterX] == 2)) || (mapConnectNo == 1 && previousMap3A [counterY+1][counterX] == 2))){
                                                            connectivityMap2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                                            
                                                            if (connectNo == 1 && previousMap3A [counterY+1][counterX] != 1) areaExpansionTotal++;
                                                        }
                                                        if (counterY+1 < dimension && counterX-1 >= 0 && ((mapConnectNo != 1 && (previousMap3A [counterY+1][counterX-1] < 0 || previousMap3A [counterY+1][counterX-1] == 2)) || (mapConnectNo == 1 && previousMap3A [counterY+1][counterX-1] == 2))){
                                                            connectivityMap2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                                            
                                                            if (connectNo == 1 && previousMap3A [counterY+1][counterX-1] != 1) areaExpansionTotal++;
                                                        }
                                                        if (counterX-1 >= 0 && ((mapConnectNo != 1 && (previousMap3A [counterY][counterX-1] < 0 || previousMap3A [counterY][counterX-1] == 2)) || (mapConnectNo == 1 && previousMap3A [counterY][counterX-1] == 2))){
                                                            connectivityMap2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                                            
                                                            if (connectNo == 1 && previousMap3A [counterY][counterX-1] != 1) areaExpansionTotal++;
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            for (int counterY = 0; counterY < dimension; counterY++){
                                                for (int counterX = 0; counterX < dimension; counterX++) previousMap3A [counterY][counterX] = connectivityMap2 [counterY][counterX];
                                            }
                                            
                                            if (findFreePoint == 0) extendConnectList2 [counter1*2+1] = 1;
                                            
                                            if (expansionArea < areaExpansionTotal) extendConnectList2 [counter1*2+1] = 1;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < startOrder; counter1++){
                                        connectNo = extendConnectList2 [counter1*2];
                                        
                                        if (extendConnectList2 [counter1*2+1] == 0){
                                            findFreePoint = 0;
                                            
                                            for (int counterY = 2; counterY < dimension-2; counterY++){
                                                for (int counterX = 2; counterX < dimension-2; counterX++){
                                                    mapConnectNo = previousMap3A [counterY][counterX];
                                                    
                                                    if (mapConnectNo == connectNo){
                                                        if (counterY-1 >= 0 && counterX-1 >= 0 && ((mapConnectNo != 1 && (previousMap3A [counterY-1][counterX-1] < 0 || previousMap3A [counterY-1][counterX-1] == 2)) || (mapConnectNo == 1 && previousMap3A [counterY-1][counterX-1] == 2))){
                                                            connectivityMap2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                                            
                                                            if (connectNo == 1 && previousMap3A [counterY-1][counterX-1] != 1) areaExpansionTotal++;
                                                        }
                                                        if (counterY-1 >= 0 && ((mapConnectNo != 1 && (previousMap3A [counterY-1][counterX] < 0 || previousMap3A [counterY-1][counterX] == 2)) || (mapConnectNo == 1 && previousMap3A [counterY-1][counterX] == 2))){
                                                            connectivityMap2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                                            
                                                            if (connectNo == 1 && previousMap3A [counterY-1][counterX] != 1) areaExpansionTotal++;
                                                        }
                                                        if (counterY-1 >= 0 && counterX+1 < dimension && ((mapConnectNo != 1 && (previousMap3A [counterY-1][counterX+1] < 0 || previousMap3A [counterY-1][counterX+1] == 2)) || (mapConnectNo == 1 && previousMap3A [counterY-1][counterX+1] == 2))){
                                                            connectivityMap2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                                            
                                                            if (connectNo == 1 && previousMap3A [counterY-1][counterX+1] != 1) areaExpansionTotal++;
                                                        }
                                                        if (counterX+1 < dimension && ((mapConnectNo != 1 && (previousMap3A [counterY][counterX+1] < 0 || previousMap3A [counterY][counterX+1] == 2)) || (mapConnectNo == 1 && previousMap3A [counterY][counterX+1] == 2))){
                                                            connectivityMap2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                                            
                                                            if (connectNo == 1 && previousMap3A [counterY][counterX+1] != 1) areaExpansionTotal++;
                                                        }
                                                        if (counterY+1 < dimension && counterX+1 < dimension && ((mapConnectNo != 1 && (previousMap3A [counterY+1][counterX+1] < 0 || previousMap3A [counterY+1][counterX+1] == 2)) || (mapConnectNo == 1 && previousMap3A [counterY+1][counterX+1] == 2))){
                                                            connectivityMap2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                                            
                                                            if (connectNo == 1 && previousMap3A [counterY+1][counterX+1] != 1) areaExpansionTotal++;
                                                        }
                                                        if (counterY+1 < dimension && ((mapConnectNo != 1 && (previousMap3A [counterY+1][counterX] < 0 || previousMap3A [counterY+1][counterX] == 2)) || (mapConnectNo == 1 && previousMap3A [counterY+1][counterX] == 2))){
                                                            connectivityMap2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                                            
                                                            if (connectNo == 1 && previousMap3A [counterY+1][counterX] != 1) areaExpansionTotal++;
                                                        }
                                                        if (counterY+1 < dimension && counterX-1 >= 0 && ((mapConnectNo != 1 && (previousMap3A [counterY+1][counterX-1] < 0 || previousMap3A [counterY+1][counterX-1] == 2)) || (mapConnectNo == 1 && previousMap3A [counterY+1][counterX-1] == 2))){
                                                            connectivityMap2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                                            
                                                            if (connectNo == 1 && previousMap3A [counterY+1][counterX-1] != 1) areaExpansionTotal++;
                                                        }
                                                        if (counterX-1 >= 0 && ((mapConnectNo != 1 && (previousMap3A [counterY][counterX-1] < 0 || previousMap3A [counterY][counterX-1] == 2)) || (mapConnectNo == 1 && previousMap3A [counterY][counterX-1] == 2))){
                                                            connectivityMap2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                                            
                                                            if (connectNo == 1 && previousMap3A [counterY][counterX-1] != 1) areaExpansionTotal++;
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            for (int counterY = 0; counterY < dimension; counterY++){
                                                for (int counterX = 0; counterX < dimension; counterX++) previousMap3A [counterY][counterX] = connectivityMap2 [counterY][counterX];
                                            }
                                            
                                            if (findFreePoint == 0) extendConnectList2 [counter1*2+1] = 1;
                                            
                                            if (expansionArea < areaExpansionTotal) extendConnectList2 [counter1*2+1] = 1;
                                        }
                                    }
                                    
                                    remainingCheck = 0;
                                    
                                    for (int counter1 = 0; counter1 < extendConnectCount2/2; counter1++){
                                        if (extendConnectList2 [counter1*2+1] == 0) remainingCheck = 1;
                                    }
                                    
                                    if (remainingCheck == 0) terminationFlag = 1;
                                    
                                    startOrder++;
                                    
                                    if (startOrder == extendConnectCount2/2) startOrder = 0;
                                    
                                } while (terminationFlag == 0);
                            }
                            
                            for (int counterY = 0; counterY < imageDimension; counterY++){
                                for (int counterX = 0; counterX < imageDimension; counterX++) putativeMap [counterY][counterX] = 0;
                            }
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                                        if (previousMap3A [counterY][counterX] != 1 && previousMap3A [counterY][counterX] != 2 && previousMap3A [counterY][counterX] != -1) putativeMap [counterY+verticalStart2][counterX+horizontalStart2] = previousMap3A [counterY][counterX];
                                        
                                        for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                                            if (extendConnectList [counter1*2+1]*-1 == revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2]){
                                                putativeMap [counterY+verticalStart2][counterX+horizontalStart2] = revisedWorkingMap [counterY+verticalStart2][counterX+horizontalStart2] *-1;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < dimension+1; counter1++) delete [] mapProcessImage [counter1];
                            
                            delete [] mapProcessImage;
                            delete [] extendConnectList2;
                            delete [] extendConnectList;
                        }
                        
                        delete [] overlapList5;
                        delete [] overlapList6;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (previousMap3A [counterY][counterX] != 1) previousMap3A [counterY][counterX] = 0;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3A [counterA][counterB];
                        //    cout<<" mapreviousMap3A "<<counterA<<endl;
                        //}
                        
                        //-------Zero Fill-------
                        for (int counterX = 0; counterX < dimension+2; counterX++){
                            for (int counterY = 0; counterY < dimension+2; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
                        }
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                connectivityUpdate5 [counterY+1][counterX+1] = previousMap3A [counterY][counterX];
                            }
                        }
                        
                        connectivityNumber = 0;
                        
                        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                if (connectivityUpdate5 [counterY2][counterX2] == 0){
                                    connectivityNumber--;
                                    connectAnalysisCount = 0;
                                    
                                    connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                                    
                                    if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                                        connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                    }
                                    if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                        connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                    }
                                    if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                        connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                    }
                                    if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                        connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                    }
                                    
                                    if (connectAnalysisCount != 0){
                                        do{
                                            
                                            terminationFlag = 1;
                                            connectAnalysisTempCount = 0;
                                            
                                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                                
                                                if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                                    connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                                    connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                                    connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                                    connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                            }
                                            
                                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                            }
                                            
                                            connectAnalysisCount = connectAnalysisTempCount;
                                            
                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension+2; counterA++){
                        //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                        //	cout<<" connectivityUpdate5 "<<counterA<<endl;
                        //}
                        
                        if (connectivityNumber < -1){
                            errorNoHold = 83;
                            int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                            
                            for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
                            
                            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                    connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                                    
                                    if (connectTemp2 < -1){
                                        connectTemp2 = connectTemp2*-1;
                                        
                                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                    }
                                }
                            }
                            
                            int zeroFillFlag = 0;
                            
                            for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                                if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
                            }
                            
                            if (zeroFillFlag == 1){
                                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                        connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                                        
                                        if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                                    }
                                }
                                
                                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                        if (connectivityUpdate5 [counterY2][counterX2] > 0) previousMap3A [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                                    }
                                }
                            }
                            
                            delete [] connectCheckArray;
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3A [counterA][counterB];
                        //    cout<<" previousMap3A "<<counterA<<endl;
                        //}
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (previousMap3A [counterY][counterX] != 0){
                                    if (counterX+1 < dimension && previousMap3A [counterY][counterX+1] == 0) previousMap3A [counterY][counterX] = -1;
                                    else if (counterY+1 < dimension && previousMap3A [counterY+1][counterX] == 0) previousMap3A [counterY][counterX] = -1;
                                    else if (counterX-1 >= 0 && previousMap3A [counterY][counterX-1] == 0) previousMap3A [counterY][counterX] = -1;
                                    else if (counterY-1 >= 0 && previousMap3A [counterY-1][counterX] == 0) previousMap3A [counterY][counterX] = -1;
                                }
                            }
                        }
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (previousMap3A [counterY][counterX] > 0) previousMap3A [counterY][counterX] = 0;
                                if (previousMap3A [counterY][counterX] < 0) previousMap3A [counterY][counterX] = 1;
                            }
                        }
                        
                        connectivityNumber = 0;
                        
                        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                if (previousMap3A [counterY2][counterX2] == 0){
                                    connectivityNumber--;
                                    connectAnalysisCount = 0;
                                    
                                    previousMap3A [counterY2][counterX2] = connectivityNumber;
                                    
                                    if (counterY2-1 >= 0 && previousMap3A [counterY2-1][counterX2] == 0){
                                        previousMap3A [counterY2-1][counterX2] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                    }
                                    if (counterX2+1 < dimension && previousMap3A [counterY2][counterX2+1] == 0){
                                        previousMap3A [counterY2][counterX2+1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                    }
                                    if (counterY2+1 < dimension && previousMap3A [counterY2+1][counterX2] == 0){
                                        previousMap3A [counterY2+1][counterX2] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                    }
                                    if (counterX2-1 >= 0 && previousMap3A [counterY2][counterX2-1] == 0){
                                        previousMap3A [counterY2][counterX2-1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                    }
                                    
                                    if (connectAnalysisCount != 0){
                                        do{
                                            
                                            terminationFlag = 1;
                                            connectAnalysisTempCount = 0;
                                            
                                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                                
                                                if (ySource-1 >= 0 && previousMap3A [ySource-1][xSource] == 0){
                                                    previousMap3A [ySource-1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (xSource+1 < dimension && previousMap3A [ySource][xSource+1] == 0){
                                                    previousMap3A [ySource][xSource+1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 < dimension && previousMap3A [ySource+1][xSource] == 0){
                                                    previousMap3A [ySource+1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (xSource-1 >= 0 && previousMap3A [ySource][xSource-1] == 0){
                                                    previousMap3A [ySource][xSource-1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                            }
                                            
                                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                            }
                                            
                                            connectAnalysisCount = connectAnalysisTempCount;
                                            
                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                    }
                                }
                            }
                        }
                        
                        //------Determine number of pixels------
                        connectivityNumber = connectivityNumber*-1;
                        
                        errorNoHold = 84;
                        connectedPixels2 = new int [connectivityNumber+50];
                        
                        for (int counter1 = 0; counter1 < connectivityNumber+50; counter1++) connectedPixels2 [counter1] = 0;
                        
                        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                if (previousMap3A [counterY2][counterX2] < -1) connectedPixels2 [previousMap3A [counterY2][counterX2]*-1]++;
                            }
                        }
                        
                        errorNoHold = 85;
                        int **newConnectivityMapTemp = new int *[dimension+4];
                        for (int counter1 = 0; counter1 < dimension+4; counter1++){
                            errorNoHold = 86;
                            newConnectivityMapTemp [counter1] = new int [dimension+4];
                        }
                        
                        for (int counterY = 0; counterY < dimension+4; counterY++){
                            for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
                        }
                        
                        int largestConnect = 0;
                        int largestConnectNo = 0;
                        
                        for (int counter1 = 2; counter1 <= connectivityNumber; counter1++){
                            if (connectedPixels2 [counter1] > largestConnect){
                                largestConnect = connectedPixels2 [counter1];
                                largestConnectNo = counter1;
                            }
                        }
                        
                        delete [] connectedPixels2;
                        
                        if (largestConnect != 0){
                            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                    if (previousMap3A [counterY2][counterX2] == largestConnectNo*-1){
                                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && previousMap3A [counterY2-1][counterX2-1] == 1){
                                            newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                                            previousMap3A [counterY2-1][counterX2-1] = 0;
                                        }
                                        if (counterY2-1 >= 0 && previousMap3A [counterY2-1][counterX2] == 1){
                                            newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                                            previousMap3A [counterY2-1][counterX2] = 0;
                                        }
                                        if (counterY2-1 >= 0 && counterX2+1 < dimension && previousMap3A [counterY2-1][counterX2+1] == 1){
                                            newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                                            previousMap3A [counterY2-1][counterX2+1] = 0;
                                        }
                                        if (counterX2+1 < dimension && previousMap3A [counterY2][counterX2+1] == 1){
                                            newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                                            previousMap3A [counterY2][counterX2+1] = 0;
                                        }
                                        if (counterY2+1 < dimension && counterX2+1 < dimension && previousMap3A [counterY2+1][counterX2+1] == 1){
                                            newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                                            previousMap3A [counterY2+1][counterX2+1] = 0;
                                        }
                                        if (counterY2+1 < dimension && previousMap3A [counterY2+1][counterX2] == 1){
                                            newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                                            previousMap3A [counterY2+1][counterX2] = 0;
                                        }
                                        if (counterY2+1 < dimension && counterX2-1 >= 0 && previousMap3A [counterY2+1][counterX2-1] == 1){
                                            newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                                            previousMap3A [counterY2+1][counterX2-1] = 0;
                                        }
                                        if (counterX2-1 >= 0 && previousMap3A [counterY2][counterX2-1] == 1){
                                            newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                                            previousMap3A [counterY2][counterX2-1] = 0;
                                        }
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < dimension; counterA++){
                            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<< previousMap3A [counterA][counterB];
                            //    cout<<" previousMap3A "<<counterA<<endl;
                            //}
                            
                            int xPositionTempStart = 0;
                            int yPositionTempStart = 0;
                            int lineSize = 0;
                            
                            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                    if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                                        previousMap3A [counterY2][counterX2] = 1;
                                        
                                        xPositionTempStart = counterX2;
                                        yPositionTempStart = counterY2;
                                        lineSize++;
                                    }
                                    else previousMap3A [counterY2][counterX2] = 0;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < dimension; counterA++){
                            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<< previousMap3A [counterA][counterB];
                            //    cout<<" previousMap3A "<<counterA<<endl;
                            //}
                            
                            int constructedLineCount = 0;
                            int findFlag = 0;
                            
                            errorNoHold = 87;
                            int *arrayNewLines = new int [lineSize*2+50];
                            
                            previousMap3A [yPositionTempStart][xPositionTempStart] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart2, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart2, constructedLineCount++;
                            
                            do{
                                
                                findFlag = 0;
                                terminationFlag = 0;
                                
                                if (xPositionTempStart+1 < dimension){
                                    if (previousMap3A [yPositionTempStart][xPositionTempStart+1] == 1){
                                        previousMap3A [yPositionTempStart][xPositionTempStart+1] = -1;
                                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart2, constructedLineCount++;
                                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart2, constructedLineCount++;
                                        xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                    }
                                }
                                if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                                    if (previousMap3A [yPositionTempStart+1][xPositionTempStart+1] == 1){
                                        previousMap3A [yPositionTempStart+1][xPositionTempStart+1] = -1;
                                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart2, constructedLineCount++;
                                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart2, constructedLineCount++;
                                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                    }
                                }
                                if (yPositionTempStart+1 < dimension && findFlag == 0){
                                    if (previousMap3A [yPositionTempStart+1][xPositionTempStart] == 1){
                                        previousMap3A [yPositionTempStart+1][xPositionTempStart] = -1;
                                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart2, constructedLineCount++;
                                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart2, constructedLineCount++;
                                        yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                    }
                                }
                                if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                                    if (previousMap3A [yPositionTempStart+1][xPositionTempStart-1] == 1){
                                        previousMap3A [yPositionTempStart+1][xPositionTempStart-1] = -1;
                                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart2, constructedLineCount++;
                                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart2, constructedLineCount++;
                                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                    }
                                }
                                if (xPositionTempStart-1 >= 0 && findFlag == 0){
                                    if (previousMap3A [yPositionTempStart][xPositionTempStart-1] == 1){
                                        previousMap3A [yPositionTempStart][xPositionTempStart-1] = -1;
                                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart2, constructedLineCount++;
                                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart2, constructedLineCount++;
                                        xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                    }
                                }
                                if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                                    if (previousMap3A [yPositionTempStart-1][xPositionTempStart-1] == 1){
                                        previousMap3A [yPositionTempStart-1][xPositionTempStart-1] = -1;
                                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart2, constructedLineCount++;
                                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart2, constructedLineCount++;
                                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                    }
                                }
                                if (yPositionTempStart-1 >= 0 && findFlag == 0){
                                    if (previousMap3A [yPositionTempStart-1][xPositionTempStart] == 1){
                                        previousMap3A [yPositionTempStart-1][xPositionTempStart] = -1;
                                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart2, constructedLineCount++;
                                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart2, constructedLineCount++;
                                        yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                    }
                                }
                                if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                                    if (previousMap3A [yPositionTempStart-1][xPositionTempStart+1] == 1){
                                        previousMap3A [yPositionTempStart-1][xPositionTempStart+1] = -1;
                                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart2, constructedLineCount++;
                                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart2, constructedLineCount++;
                                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                                    }
                                }
                                
                            } while (terminationFlag == 1);
                            
                            //===========
                            //int aa = arrayNewLines [0];
                            //int bb = arrayNewLines [1];
                            
                            //int cc = arrayNewLines [(constructedLineCount/2-1)*2];
                            //int dd = arrayNewLines [(constructedLineCount/2-1)*2+1];
                            
                            //int findLink = 0;
                            
                            //if (cc-1 == aa && dd-1 == bb) findLink = 1;
                            // else  if (cc == aa && dd-1 == bb) findLink = 1;
                            // else  if (cc+1 == aa && dd-1 == bb) findLink = 1;
                            // else  if (cc+1 == aa && dd == bb) findLink = 1;
                            // else  if (cc+1 == aa && dd+1 == bb) findLink = 1;
                            // else  if (cc == aa && dd+1 == bb) findLink = 1;
                            // else  if (cc-1 == aa && dd+1 == bb) findLink = 1;
                            // else  if (cc-1 == aa && dd == bb) findLink = 1;
                            
                            // if (findLink == 0){
                            //     for (int counterA = 0; counterA < dimension; counterA++){
                            //         for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<previousMap3A [counterA][counterB];
                            //         cout<<" previousMap3A "<<counterA<<endl;
                            //     }
                            // }
                            
                            //==========
                            
                            if (cutOffAdjust == -1){
                                delete [] arrayReferenceLine;
                                errorNoHold = 88;
                                arrayReferenceLine = new int [constructedLineCount+50];
                                referenceLineCount = 0;
                                referenceLineLimit = constructedLineCount+50;
                                
                                for (int counter1 = 0; counter1 < constructedLineCount/2; counter1++){
                                    arrayReferenceLine [referenceLineCount] = arrayNewLines [counter1*2], referenceLineCount++;
                                    arrayReferenceLine [referenceLineCount] = arrayNewLines [counter1*2+1], referenceLineCount++;
                                }
                            }
                            else{
                                
                                for (int counter1 = 0; counter1 < constructedLineCount/2; counter1++){
                                    if (optionalLineDataCount+10 > optionalLineDataLimit){
                                        errorNoHold = 89;
                                        int *arrayUpDate = new int [optionalLineDataCount+10];
                                        
                                        for (int counter2 = 0; counter2 < optionalLineDataCount; counter2++) arrayUpDate [counter2] = arrayOptionalLineData [counter2];
                                        
                                        delete [] arrayOptionalLineData;
                                        errorNoHold = 90;
                                        arrayOptionalLineData = new int [optionalLineDataLimit+2000];
                                        optionalLineDataLimit = optionalLineDataLimit+2000;
                                        
                                        for (int counter2 = 0; counter2 < optionalLineDataCount; counter2++) arrayOptionalLineData [counter2] = arrayUpDate [counter2];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    arrayOptionalLineData [optionalLineDataCount] = arrayNewLines [counter1*2], optionalLineDataCount++;
                                    arrayOptionalLineData [optionalLineDataCount] = arrayNewLines [counter1*2+1], optionalLineDataCount++;
                                    arrayOptionalLineData [optionalLineDataCount] = optionalShiftOrientation, optionalShiftOrientation++;
                                }
                            }
                            
                            delete [] arrayNewLines;
                        }
                        else trackHoldFlag = 3000;
                        
                        for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] newConnectivityMapTemp [counter1];
                        delete [] newConnectivityMapTemp;
                        
                        for (int counter1 = 0; counter1 < dimension+1; counter1++){
                            delete [] connectivityMap2 [counter1];
                            delete [] sourceImageTemp [counter1];
                            delete [] connectivityCount [counter1];
                        }
                        
                        delete [] connectivityMap2;
                        delete [] sourceImageTemp;
                        delete [] connectivityCount;
                    }
                    else trackHoldFlag = 3000;
                }
                else trackHoldFlag = 3000;
                
                delete [] arrayTimeSelectedTemp;
                delete [] arrayConnectLineageRelTemp;
                
                for (int counter1 = 0; counter1 < dimension+4; counter1++){
                    delete [] previousMap3A [counter1];
                    delete [] previousMap3ATemp1 [counter1];
                    delete [] previousMap3ATemp2 [counter1];
                    delete [] previousMap4A [counter1];
                    delete [] previousMap5A [counter1];
                    delete [] connectivityUpdate5 [counter1];
                }
                
                delete [] previousMap3A;
                delete [] previousMap3ATemp1;
                delete [] previousMap3ATemp2;
                delete [] previousMap4A;
                delete [] previousMap5A;
                delete [] connectivityUpdate5;
                
                delete [] connectAnalysisX;
                delete [] connectAnalysisY;
                delete [] connectAnalysisTempX;
                delete [] connectAnalysisTempY;
                
                delete [] overlapList;
                delete [] overlapList2;
                delete [] overlapList3;
            }
            else{
                
                errorNoHold = 1010;
                throw errorCheckThrow;
            }
            
            errorNoHold = 0;
            subCompletionFlag = 0;
        }
        catch (int errorCheckThrow){
            if (errorNoHold >= 1000 && errorNoHold < 2000){
                string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
                mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                time_t rawtime;
                struct tm * timeinfo;
                time (&rawtime);
                timeinfo = localtime ( &rawtime );
                
                int tsec = timeinfo -> tm_sec;
                int tmin = timeinfo -> tm_min;
                int thour = timeinfo -> tm_hour;
                int tday = timeinfo -> tm_mday;
                int tmon = timeinfo -> tm_mon;
                
                string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
                
                errorPath = errorPath+"/Cell_CarvingOverlapCheck01 "+dateTime;
                
                ofstream oin2;
                oin2.open(errorPath.c_str(), ios::out);
                oin2<<"OverlapCheck"<<endl;
                oin2<<errorNoHold<<endl;
                oin2<<analysisImageName<<endl;
                oin2<<analysisID<<endl;
                oin2<<treatmentNameHold<<endl;
                oin2<<cellLineageNoHold<<endl;
                oin2<<cellNoHold<<endl;
                oin2<<dateTime<<endl;
                
                if (errorNoHold == 1000) oin2<<"MasterDataRevise reading error"<<endl;
                else if (errorNoHold == 1001) oin2<<"MasterDataRevise uploading error"<<endl;
                else if (errorNoHold == 1002) oin2<<"MasterDataRevise open-error"<<endl;
                else if (errorNoHold == 1003) oin2<<"Status data reading error"<<endl;
                else if (errorNoHold == 1004) oin2<<"Status data uploading error"<<endl;
                else if (errorNoHold == 1005) oin2<<"Status data open-error"<<endl;
                else if (errorNoHold == 1006) oin2<<"ConnectLineageRel data reading error"<<endl;
                else if (errorNoHold == 1007) oin2<<"ConnectLineageRel data loading error"<<endl;
                else if (errorNoHold == 1008) oin2<<"ConnectLineageRel data open-error"<<endl;
                else if (errorNoHold == 1009) oin2<<"RevisedMap open-error"<<endl;
                else if (errorNoHold == 1010) oin2<<"MasterDataRevise open-error"<<endl;
                oin2.close();
                
                subCompletionFlag = 0;
            }
        }
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingOverlapCheck02 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"OverlapCheck"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
        
        subCompletionFlag = 0;
    }
}

@end
