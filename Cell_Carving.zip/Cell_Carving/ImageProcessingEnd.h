//
//  ImageProcessingEnd.h
//  Cell_Carving
//
//  Created by Masahiko Sato on 2015-12-18.
//
//

#ifndef IMAGEPROCESSINGEND_H
#define IMAGEPROCESSINGEND_H
#import "Controller.h"
#endif

@interface ImageProcessingEnd : NSObject{
    id overlapCheck;
    id areaCut;
    id trackingDataSave;
}

-(id)init;
-(void)dealloc;
-(void)fluorescentProcess;
-(void)referenceLineCountUpDate;

@end
