//
// ImageProcessing.mm
// cell_carving
//
// Created by Masahiko Sato on 10/07/11.
// Copyright 2011 Masahiko Sato All rights reserved.
//

#import "ImageProcessing.h"

NSString *notificationToImageProcessing = @"notoficationExecuteImageProcessing";

@implementation ImageProcessing

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToImageProcessing object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    try{
        try{
            
            errorNoHold = 0;
            int errorCheckThrow = 0;
            sleepingPosition = 13;
            
            string cellLineageExtract = cellLineageNoHold.substr(1);
            string cellNumberExtract = cellNoHold.substr(1);
            int cellLineageTempInt = atoi(cellLineageExtract.c_str());
            int cellNumberTempInt = atoi(cellNumberExtract.c_str());
            
            trackingExitCount++;
            
            //clock_t time1, time2, time3, time4, time5, time6, time7;
            //time1 = clock();
            
            //cout<<",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,, "<<roundStatus<<endl;
            
            //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
            //    cout<<" arrayConnectLineageRel"<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //    cout<<" arrayTimeSelected "<<counterA<<endl;
            //}
            
            //---------Fluorescent Image Find--------
            fluorescentDetectionDisplay1 = 0;
            fluorescentDetectionDisplay2 = 0;
            
            string extensionString2 = to_string (imageNumberInt);
            
            if (extensionString2.length() == 1) extensionString2 = "000"+extensionString2;
            else if (extensionString2.length() == 2) extensionString2 = "00"+extensionString2;
            else if (extensionString2.length() == 3) extensionString2 = "0"+extensionString2;
            
            int fluorescentDisplayFind1 = 0;
            int fluorescentDisplayFind2 = 0;
            int fluorescentDisplayFind3 = 0;
            int fluorescentDisplayFind4 = 0;
            int fluorescentDisplayFind5 = 0;
            int fluorescentDisplayFind6 = 0;
            
            ifstream fin;
            
            string extension2 = to_string (fluorescentNo1);
            string fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName1+".tif";
            
            fin.open(fluorescentPath1.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName1+".bmp";
            }
            else fin.close();
            
            extension2 = to_string (fluorescentNo2);
            string fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName2+".tif";
            
            fin.open(fluorescentPath2.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName2+".bmp";
            }
            else fin.close();
            
            extension2 = to_string (fluorescentNo3);
            string fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName3+".tif";
            
            fin.open(fluorescentPath3.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName3+".bmp";
            }
            else fin.close();
            
            extension2 = to_string (fluorescentNo4);
            string fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName4+".tif";
            
            fin.open(fluorescentPath4.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName4+".bmp";
            }
            else fin.close();
            
            extension2 = to_string (fluorescentNo5);
            string fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName5+".tif";
            
            fin.open(fluorescentPath5.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName5+".bmp";
            }
            else fin.close();
            
            extension2 = to_string (fluorescentNo6);
            string fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName6+".tif";
            
            fin.open(fluorescentPath6.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName6+".bmp";
            }
            else fin.close();
            
            struct stat sizeOfFile;
            
            if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind1 = 1;
            }
            if (stat(fluorescentPath2.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind2 = 1;
            }
            if (stat(fluorescentPath3.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind3 = 1;
            }
            if (stat(fluorescentPath4.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind4 = 1;
            }
            if (stat(fluorescentPath5.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind5 = 1;
            }
            if (stat(fluorescentPath6.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind6 = 1;
            }
            
            if (fluorescentDisplayFind1 == 1 || fluorescentDisplayFind2 == 1 || fluorescentDisplayFind3 == 1 || fluorescentDisplayFind4 == 1 || fluorescentDisplayFind5 == 1 || fluorescentDisplayFind6 == 1) fluorescentDetectionDisplay1 = 1;
            
            string extensionString3 = to_string (imageNumberInt+1);
            
            if (extensionString3.length() == 1) extensionString3 = "000"+extensionString3;
            else if (extensionString3.length() == 2) extensionString3 = "00"+extensionString3;
            else if (extensionString3.length() == 3) extensionString3 = "0"+extensionString3;
            
            fluorescentDisplayFind1 = 0;
            fluorescentDisplayFind2 = 0;
            fluorescentDisplayFind3 = 0;
            fluorescentDisplayFind4 = 0;
            fluorescentDisplayFind5 = 0;
            fluorescentDisplayFind6 = 0;
            
            extension2 = to_string (fluorescentNo1);
            fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName1+".tif";
            
            fin.open(fluorescentPath1.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName1+".bmp";
            }
            else fin.close();
            
            extension2 = to_string (fluorescentNo2);
            fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName2+".tif";
            
            fin.open(fluorescentPath2.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName2+".bmp";
            }
            else fin.close();
            
            extension2 = to_string (fluorescentNo3);
            fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName3+".tif";
            
            fin.open(fluorescentPath3.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName3+".bmp";
            }
            else fin.close();
            
            extension2 = to_string (fluorescentNo4);
            fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName4+".tif";
            
            fin.open(fluorescentPath4.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName4+".bmp";
            }
            else fin.close();
            
            extension2 = to_string (fluorescentNo5);
            fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName5+".tif";
            
            fin.open(fluorescentPath5.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName5+".bmp";
            }
            else fin.close();
            
            extension2 = to_string (fluorescentNo6);
            fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName6+".tif";
            
            fin.open(fluorescentPath6.c_str(), ios::in);
            
            if (!fin.is_open()){
                fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName6+".bmp";
            }
            else fin.close();
            
            if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind1 = 1;
            }
            if (stat(fluorescentPath2.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind2 = 1;
            }
            if (stat(fluorescentPath3.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind3 = 1;
            }
            if (stat(fluorescentPath4.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind4 = 1;
            }
            if (stat(fluorescentPath5.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind5 = 1;
            }
            if (stat(fluorescentPath6.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind6 = 1;
            }
            
            if (fluorescentDisplayFind1 == 1 || fluorescentDisplayFind2 == 1 || fluorescentDisplayFind3 == 1 || fluorescentDisplayFind4 == 1 || fluorescentDisplayFind5 == 1 || fluorescentDisplayFind6 == 1) fluorescentDetectionDisplay2 = 1;
            
            long sizeForCopy = 0;
            
            if (fluorescentDetectionDisplay1 == 1){
                string expandDataPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extensionString2+"_"+analysisID+"_"+treatmentNameHold+"_ExtendLineData";
                
                long size1 = 0;
                long size2 = 0;
                int checkFlag = 0;
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    sizeForCopy = 0;
                    
                    if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter1 == 0) size1 = sizeForCopy;
                        else if (counter1 == 1) size2 = sizeForCopy;
                        else if (counter1 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter1 == 3) size1 = sizeForCopy;
                        else if (counter1 == 4) size2 = sizeForCopy;
                        else if (counter1 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                if (stat(expandDataPath.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                    errorNoHold = 1000;
                    throw errorCheckThrow;
                }
                
                if (checkFlag == 1){
                    if (expandLineFluorescentStatus == 0){
                        errorNoHold = 1;
                        expandLineFluorescent = new int [sizeForCopy+50];
                        expandLineFluorescentCount = 0;
                        expandLineFluorescentLimit = (int)sizeForCopy+50;
                        expandLineFluorescentStatus = 1;
                        expandLineFluorescentSizeHold = (int)sizeForCopy+50;
                    }
                    else if (expandLineFluorescentStatus == 1 && expandLineFluorescentSizeHold < sizeForCopy){
                        delete [] expandLineFluorescent;
                        
                        errorNoHold = 2;
                        expandLineFluorescent = new int [sizeForCopy+50];
                        expandLineFluorescentCount = 0;
                        expandLineFluorescentLimit = (int)sizeForCopy+50;
                        expandLineFluorescentSizeHold = (int)sizeForCopy+50;
                    }
                    else expandLineFluorescentCount = 0;
                    
                    fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [8];
                        
                        errorNoHold = 3;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                    errorNoHold = 1002;
                                    throw errorCheckThrow;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1 X position
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y position
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                else{
                                    
                                    expandLineFluorescent [expandLineFluorescentCount] = finData [1], expandLineFluorescentCount++;
                                    expandLineFluorescent [expandLineFluorescentCount] = finData [3], expandLineFluorescentCount++;
                                    expandLineFluorescent [expandLineFluorescentCount] = finData [6], expandLineFluorescentCount++;
                                    expandLineFluorescent [expandLineFluorescentCount] = finData [7], expandLineFluorescentCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                    }
                    else{
                        
                        errorNoHold = 1003;
                        throw errorCheckThrow;
                    }
                }
                else if (expandLineFluorescentStatus == 0){
                    errorNoHold = 4;
                    expandLineFluorescent = new int [500];
                    expandLineFluorescentCount = 0;
                    expandLineFluorescentLimit = 500;
                    expandLineFluorescentStatus = 1;
                    expandLineFluorescentSizeHold = 500;
                }
                else expandLineFluorescentCount = 0;
                
                //for (int counterA = 0; counterA < expandLineFluorescentCount/4; counterA++){
                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandLineFluorescent [counterA*4+counterB];
                //    cout<<" expandLineFluorescent "<<counterA<<endl;
                //}
                
                expandDataPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extensionString2+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
                
                sizeForCopy = 0;
                
                if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (expandLineFluorescentDataStatus == 0){
                        errorNoHold = 5;
                        expandLineFluorescentData = new int [sizeForCopy+50];
                        expandLineFluorescentDataCount = 0;
                        expandLineFluorescentDataStatus = 1;
                        expandLineFluorescentDataLimit = (int)sizeForCopy+50;
                        expandLineFluorescentDataSizeHold = (int)sizeForCopy+50;
                    }
                    else if (expandLineFluorescentDataStatus == 1 && expandLineFluorescentDataSizeHold < sizeForCopy){
                        delete [] expandLineFluorescentData;
                        
                        errorNoHold = 6;
                        expandLineFluorescentData = new int [sizeForCopy+50];
                        expandLineFluorescentDataCount = 0;
                        expandLineFluorescentDataLimit = (int)sizeForCopy+50;
                        expandLineFluorescentDataSizeHold = (int)sizeForCopy+50;
                    }
                    else expandLineFluorescentDataCount = 0;
                    
                    fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [8];
                        
                        errorNoHold = 7;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                errorNoHold = 1004;
                                throw errorCheckThrow;
                            }
                        }
                        
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pix
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                else{
                                    
                                    expandLineFluorescentData [expandLineFluorescentDataCount] = finData [2], expandLineFluorescentDataCount++;
                                    expandLineFluorescentData [expandLineFluorescentDataCount] = finData [3], expandLineFluorescentDataCount++;
                                    expandLineFluorescentData [expandLineFluorescentDataCount] = finData [4], expandLineFluorescentDataCount++;
                                    expandLineFluorescentData [expandLineFluorescentDataCount] = finData [7], expandLineFluorescentDataCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                    }
                    else{
                        
                        errorNoHold = 1005;
                        throw errorCheckThrow;
                    }
                }
                else if (expandLineFluorescentDataStatus == 0){
                    errorNoHold = 8;
                    expandLineFluorescentData = new int [150];
                    expandLineFluorescentDataCount = 0;
                    expandLineFluorescentDataStatus = 1;
                    expandLineFluorescentDataLimit = 150;
                    expandLineFluorescentDataSizeHold = 150;
                }
                else expandLineFluorescentDataCount = 0;
                
                //for (int counterA = 0; counterA < expandLineFluorescentDataCount/4; counterA++){
                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandLineFluorescentData [counterA*4+counterB];
                //    cout<<" expandLineFluorescentData "<<counterA<<endl;
                //}
                
                if (fluorescentMapStatus1 == 0 && fluorescentEntryCount >= 1){
                    fluorescentMapStatus1 = 1;
                    
                    errorNoHold = 9;
                    fluorescentMap1 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 10;
                        fluorescentMap1 [counter1] = new int [imageDimension+1];
                    }
                    
                    fluorescentMapSizeHold = imageDimension;
                }
                else if (fluorescentMapStatus1 == 1 && fluorescentEntryCount >= 1){
                    if (fluorescentMapSizeHold < imageDimension){
                        for (int counter1 = 0; counter1 < fluorescentMapSizeHold+1; counter1++) delete [] fluorescentMap1 [counter1];
                        delete [] fluorescentMap1;
                        
                        errorNoHold = 11;
                        fluorescentMap1 = new int *[imageDimension+1];
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                            errorNoHold = 12;
                            fluorescentMap1 [counter1] = new int [imageDimension+1];
                        }
                        
                        fluorescentMapSizeHold = imageDimension;
                    }
                }
                
                if (fluorescentMapStatus2 == 0 && fluorescentEntryCount >= 2){
                    fluorescentMapStatus2 = 1;
                    
                    errorNoHold = 13;
                    fluorescentMap2 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 14;
                        fluorescentMap2 [counter1] = new int [imageDimension+1];
                    }
                }
                else if (fluorescentMapStatus2 == 1 && fluorescentEntryCount >= 2){
                    if (fluorescentMapSizeHold < imageDimension){
                        for (int counter1 = 0; counter1 < fluorescentMapSizeHold+1; counter1++) delete [] fluorescentMap2 [counter1];
                        delete [] fluorescentMap2;
                        
                        errorNoHold = 15;
                        fluorescentMap2 = new int *[imageDimension+1];
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                            errorNoHold = 16;
                            fluorescentMap2 [counter1] = new int [imageDimension+1];
                        }
                    }
                }
                
                if (fluorescentMapStatus3 == 0 && fluorescentEntryCount >= 3){
                    fluorescentMapStatus3 = 1;
                    
                    errorNoHold = 17;
                    fluorescentMap3 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 18;
                        fluorescentMap3 [counter1] = new int [imageDimension+1];
                    }
                }
                else if (fluorescentMapStatus3 == 1 && fluorescentEntryCount >= 3){
                    if (fluorescentMapSizeHold < imageDimension){
                        for (int counter1 = 0; counter1 < fluorescentMapSizeHold+1; counter1++) delete [] fluorescentMap3 [counter1];
                        delete [] fluorescentMap3;
                        
                        errorNoHold = 19;
                        fluorescentMap3 = new int *[imageDimension+1];
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                            errorNoHold = 20;
                            fluorescentMap3 [counter1] = new int [imageDimension+1];
                        }
                    }
                }
                
                if (fluorescentMapStatus4 == 0 && fluorescentEntryCount >= 4){
                    fluorescentMapStatus4 = 1;
                    
                    errorNoHold = 21;
                    fluorescentMap4 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 22;
                        fluorescentMap4 [counter1] = new int [imageDimension+1];
                    }
                }
                else if (fluorescentMapStatus4 == 1 && fluorescentEntryCount >= 4){
                    if (fluorescentMapSizeHold < imageDimension){
                        for (int counter1 = 0; counter1 < fluorescentMapSizeHold+1; counter1++) delete [] fluorescentMap4 [counter1];
                        delete [] fluorescentMap4;
                        
                        errorNoHold = 23;
                        fluorescentMap4 = new int *[imageDimension+1];
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                            errorNoHold = 24;
                            fluorescentMap4 [counter1] = new int [imageDimension+1];
                        }
                    }
                }
                
                if (fluorescentMapStatus5 == 0 && fluorescentEntryCount >= 5){
                    fluorescentMapStatus5 = 1;
                    
                    errorNoHold = 25;
                    fluorescentMap5 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 26;
                        fluorescentMap5 [counter1] = new int [imageDimension+1];
                    }
                }
                else if (fluorescentMapStatus5 == 1 && fluorescentEntryCount >= 5){
                    if (fluorescentMapSizeHold < imageDimension){
                        for (int counter1 = 0; counter1 < fluorescentMapSizeHold+1; counter1++) delete [] fluorescentMap5 [counter1];
                        delete [] fluorescentMap5;
                        
                        errorNoHold = 27;
                        fluorescentMap5 = new int *[imageDimension+1];
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                            errorNoHold = 28;
                            fluorescentMap5 [counter1] = new int [imageDimension+1];
                        }
                    }
                }
                
                if (fluorescentMapStatus6 == 0 && fluorescentEntryCount >= 6){
                    fluorescentMapStatus6 = 1;
                    
                    errorNoHold = 29;
                    fluorescentMap6 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 30;
                        fluorescentMap6 [counter1] = new int [imageDimension+1];
                    }
                }
                else if (fluorescentMapStatus6 == 1 && fluorescentEntryCount >= 6){
                    if (fluorescentMapSizeHold < imageDimension){
                        for (int counter1 = 0; counter1 < fluorescentMapSizeHold+1; counter1++) delete [] fluorescentMap6 [counter1];
                        delete [] fluorescentMap6;
                        
                        errorNoHold = 31;
                        fluorescentMap6 = new int *[imageDimension+1];
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                            errorNoHold = 32;
                            fluorescentMap6 [counter1] = new int [imageDimension+1];
                        }
                    }
                }
                
                if (fluorescentEntryCount >= 1){
                    extension2 = to_string(fluorescentNo1);
                    string fluorescentNewPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName1+".tif";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath1.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    if (stat(fluorescentNewPath1.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                        errorNoHold = 1006;
                        throw errorCheckThrow;
                    }
                    
                    if (checkFlag == 1){
                        fin.open(fluorescentNewPath1.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int imageWidthEntry = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            int imageDimensionReadCount = 0;
                            
                            unsigned long headPosition = 0;
                            
                            errorNoHold = 33;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath1.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                imageDimensionReadCount = 0;
                                imageWidthEntry = 0;
                                
                                if (tifImageColorGray == 0){
                                    for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                        fluorescentMap1 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                                else if (tifImageColorGray == 1){
                                    for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                        value0 = uploadTemp [counter3];
                                        value1 = uploadTemp [counter3+1];
                                        value2 = uploadTemp [counter3+2];
                                        
                                        fluorescentMap1 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        fluorescentNewPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName1+".bmp";
                        
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath1.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            errorNoHold = 34;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath1.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                int imageDimensionReadCount = 0;
                                
                                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                        fluorescentMap1 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            else{
                                
                                errorNoHold = 1007;
                                throw errorCheckThrow;
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < 500; counterA++){
                    //	for (int counterB = 0; counterB < 500; counterB++) cout<<" "<<fluorescentMap1 [counterA][counterB];
                    //	cout<<" fluorescentMap1 "<<counterA<<endl;
                    //}
                }
                
                if (fluorescentEntryCount >= 2){
                    extension2 = to_string(fluorescentNo2);
                    string fluorescentNewPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName2+".tif";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath2.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    if (stat(fluorescentNewPath2.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                        errorNoHold = 1008;
                        throw errorCheckThrow;
                    }
                    
                    if (checkFlag == 1){
                        fin.open(fluorescentNewPath2.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int imageWidthEntry = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            int imageDimensionReadCount = 0;
                            
                            unsigned long headPosition = 0;
                            
                            errorNoHold = 35;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                imageDimensionReadCount = 0;
                                imageWidthEntry = 0;
                                
                                if (tifImageColorGray == 0){
                                    for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                        fluorescentMap2 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                                else if (tifImageColorGray == 1){
                                    for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                        value0 = uploadTemp [counter3];
                                        value1 = uploadTemp [counter3+1];
                                        value2 = uploadTemp [counter3+2];
                                        
                                        fluorescentMap2 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        fluorescentNewPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName2+".bmp";
                        
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath2.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            errorNoHold = 36;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                int imageDimensionReadCount = 0;
                                
                                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                        fluorescentMap2 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            else{
                                
                                errorNoHold = 1009;
                                throw errorCheckThrow;
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                }
                
                if (fluorescentEntryCount >= 3){
                    extension2 = to_string(fluorescentNo3);
                    string fluorescentNewPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName3+".tif";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath3.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    if (stat(fluorescentNewPath3.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                        errorNoHold = 1010;
                        throw errorCheckThrow;
                    }
                    
                    if (checkFlag == 1){
                        fin.open(fluorescentNewPath3.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int imageWidthEntry = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            int imageDimensionReadCount = 0;
                            
                            unsigned long headPosition = 0;
                            
                            errorNoHold = 37;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath3.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                imageDimensionReadCount = 0;
                                imageWidthEntry = 0;
                                
                                if (tifImageColorGray == 0){
                                    for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                        fluorescentMap3 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                                else if (tifImageColorGray == 1){
                                    for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                        value0 = uploadTemp [counter3];
                                        value1 = uploadTemp [counter3+1];
                                        value2 = uploadTemp [counter3+2];
                                        
                                        fluorescentMap3 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        fluorescentNewPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName3+".bmp";
                        
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath3.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            errorNoHold = 38;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath3.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                int imageDimensionReadCount = 0;
                                
                                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                        fluorescentMap3 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            else{
                                
                                errorNoHold = 1011;
                                throw errorCheckThrow;
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                }
                
                if (fluorescentEntryCount >= 4){
                    extension2 = to_string(fluorescentNo4);
                    string fluorescentNewPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName4+".tif";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath4.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    if (stat(fluorescentNewPath4.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                        errorNoHold = 1012;
                        throw errorCheckThrow;
                    }
                    
                    if (checkFlag == 1){
                        fin.open(fluorescentNewPath4.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int imageWidthEntry = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            int imageDimensionReadCount = 0;
                            
                            unsigned long headPosition = 0;
                            
                            errorNoHold = 39;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath4.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                imageDimensionReadCount = 0;
                                imageWidthEntry = 0;
                                
                                if (tifImageColorGray == 0){
                                    for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                        fluorescentMap4 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                                else if (tifImageColorGray == 1){
                                    for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                        value0 = uploadTemp [counter3];
                                        value1 = uploadTemp [counter3+1];
                                        value2 = uploadTemp [counter3+2];
                                        
                                        fluorescentMap4 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        fluorescentNewPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName4+".bmp";
                        
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath4.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            errorNoHold = 40;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath4.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                int imageDimensionReadCount = 0;
                                
                                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                        fluorescentMap4 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            else{
                                
                                errorNoHold = 1013;
                                throw errorCheckThrow;
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                }
                
                if (fluorescentEntryCount >= 5){
                    extension2 = to_string(fluorescentNo5);
                    string fluorescentNewPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName5+".tif";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath5.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    if (stat(fluorescentNewPath5.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                        errorNoHold = 1014;
                        throw errorCheckThrow;
                    }
                    
                    if (checkFlag == 1){
                        fin.open(fluorescentNewPath5.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int imageWidthEntry = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            int imageDimensionReadCount = 0;
                            
                            unsigned long headPosition = 0;
                            
                            errorNoHold = 41;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath5.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                imageDimensionReadCount = 0;
                                imageWidthEntry = 0;
                                
                                if (tifImageColorGray == 0){
                                    for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                        fluorescentMap5 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                                else if (tifImageColorGray == 1){
                                    for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                        value0 = uploadTemp [counter3];
                                        value1 = uploadTemp [counter3+1];
                                        value2 = uploadTemp [counter3+2];
                                        
                                        fluorescentMap5 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        fluorescentNewPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName5+".bmp";
                        
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath5.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            errorNoHold = 42;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath5.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                int imageDimensionReadCount = 0;
                                
                                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                        fluorescentMap5 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            else{
                                
                                errorNoHold = 1015;
                                throw errorCheckThrow;
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                }
                
                if (fluorescentEntryCount >= 6){
                    extension2 = to_string(fluorescentNo6);
                    string fluorescentNewPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName6+".tif";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath6.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    if (stat(fluorescentNewPath6.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                        errorNoHold = 1016;
                        throw errorCheckThrow;
                    }
                    
                    if (checkFlag == 1){
                        fin.open(fluorescentNewPath6.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int imageWidthEntry = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            int imageDimensionReadCount = 0;
                            
                            unsigned long headPosition = 0;
                            
                            errorNoHold = 43;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath6.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                imageDimensionReadCount = 0;
                                imageWidthEntry = 0;
                                
                                if (tifImageColorGray == 0){
                                    for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                        fluorescentMap6 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                                else if (tifImageColorGray == 1){
                                    for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                        value0 = uploadTemp [counter3];
                                        value1 = uploadTemp [counter3+1];
                                        value2 = uploadTemp [counter3+2];
                                        
                                        fluorescentMap6 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        fluorescentNewPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName6+".bmp";
                        
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath6.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            errorNoHold = 44;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath6.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                int imageDimensionReadCount = 0;
                                
                                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                        fluorescentMap6 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            else{
                                
                                errorNoHold = 1017;
                                throw errorCheckThrow;
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                }
                
                [self fluorescentProcess];
                if (errorNoHold != 0){
                    errorNoHold = errorNoHold+2000;
                    throw errorCheckThrow;
                }
            }
            
            //for (int counterA = 0; counterA < expandLineFluorescentCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandLineFluorescent [counterA*4+counterB];
            //    cout<<" expandLineFluorescent "<<counterA<<endl;
            //}
            
            if (fluorescentDetectionDisplay2 == 1){
                string expandDataPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extensionString3+"_"+analysisID+"_"+treatmentNameHold+"_ExtendLineData";
                
                long size1 = 0;
                long size2 = 0;
                int checkFlag = 0;
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    sizeForCopy = 0;
                    
                    if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter1 == 0) size1 = sizeForCopy;
                        else if (counter1 == 1) size2 = sizeForCopy;
                        else if (counter1 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter1 == 3) size1 = sizeForCopy;
                        else if (counter1 == 4) size2 = sizeForCopy;
                        else if (counter1 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                if (stat(expandDataPath.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                    errorNoHold = 1018;
                    throw errorCheckThrow;
                }
                
                if (checkFlag == 1){
                    if (expandLineFluorescentCurrentStatus == 0){
                        errorNoHold = 45;
                        expandLineFluorescentCurrent = new int [sizeForCopy+50];
                        expandLineFluorescentCurrentCount = 0;
                        expandLineFluorescentCurrentStatus = 1;
                        expandLineFluorescentCurrentLimit = (int)sizeForCopy+50;
                        expandLineFluorescentCurrentSizeHold = (int)sizeForCopy+50;
                    }
                    else if (expandLineFluorescentCurrentStatus == 1 && expandLineFluorescentCurrentSizeHold < sizeForCopy){
                        delete [] expandLineFluorescentCurrent;
                        
                        errorNoHold = 46;
                        expandLineFluorescentCurrent = new int [sizeForCopy+50];
                        expandLineFluorescentCurrentCount = 0;
                        expandLineFluorescentCurrentLimit = (int)sizeForCopy+50;
                        expandLineFluorescentCurrentSizeHold = (int)sizeForCopy+50;
                    }
                    else expandLineFluorescentCurrentCount = 0;
                    
                    fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [8];
                        
                        errorNoHold = 47;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                    errorNoHold = 1019;
                                    throw errorCheckThrow;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1 X position
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y position
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                else{
                                    
                                    expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = finData [1], expandLineFluorescentCurrentCount++;
                                    expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = finData [3], expandLineFluorescentCurrentCount++;
                                    expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = finData [6], expandLineFluorescentCurrentCount++;
                                    expandLineFluorescentCurrent [expandLineFluorescentCurrentCount] = finData [7], expandLineFluorescentCurrentCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                    }
                    else{
                        
                        errorNoHold = 1020;
                        throw errorCheckThrow;
                    }
                }
                else if (expandLineFluorescentCurrentStatus == 0){
                    errorNoHold = 48;
                    expandLineFluorescentCurrent = new int [500];
                    expandLineFluorescentCurrentCount = 0;
                    expandLineFluorescentCurrentStatus = 1;
                    expandLineFluorescentCurrentLimit = 500;
                    expandLineFluorescentCurrentSizeHold = 500;
                }
                else expandLineFluorescentCurrentCount = 0;
                
                expandDataPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extensionString3+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
                
                sizeForCopy = 0;
                
                if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (checkFlag == 1){
                    if (expandLineFluorescentDataCurrentStatus == 0){
                        errorNoHold = 49;
                        expandLineFluorescentDataCurrent = new int [sizeForCopy+50];
                        expandLineFluorescentDataCurrentCount = 0;
                        expandLineFluorescentDataCurrentStatus = 1;
                        expandLineFluorescentDataCurrentLimit = (int)sizeForCopy+50;
                        expandLineFluorescentDataCurrentSizeHold = (int)sizeForCopy+50;
                    }
                    else if (expandLineFluorescentDataCurrentStatus == 1 &&  expandLineFluorescentDataCurrentSizeHold < sizeForCopy){
                        delete [] expandLineFluorescentDataCurrent;
                        
                        errorNoHold = 50;
                        expandLineFluorescentDataCurrent = new int [sizeForCopy+50];
                        expandLineFluorescentDataCurrentCount = 0;
                        expandLineFluorescentDataCurrentLimit = (int)sizeForCopy+50;
                        expandLineFluorescentDataCurrentSizeHold = (int)sizeForCopy+50;
                    }
                    else expandLineFluorescentDataCurrentCount = 0;
                    
                    fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [8];
                        
                        errorNoHold = 51;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                errorNoHold = 1021;
                                throw errorCheckThrow;
                            }
                        }
                        
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pix
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                else{
                                    
                                    expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = finData [2], expandLineFluorescentDataCurrentCount++;
                                    expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = finData [3], expandLineFluorescentDataCurrentCount++;
                                    expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = finData [4], expandLineFluorescentDataCurrentCount++;
                                    expandLineFluorescentDataCurrent [expandLineFluorescentDataCurrentCount] = finData [7], expandLineFluorescentDataCurrentCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                    }
                    else{
                        
                        errorNoHold = 1022;
                        throw errorCheckThrow;
                    }
                }
                else if (expandLineFluorescentDataCurrentStatus == 0){
                    errorNoHold = 52;
                    expandLineFluorescentDataCurrent = new int [150];
                    expandLineFluorescentDataCurrentCount = 0;
                    expandLineFluorescentDataCurrentStatus = 1;
                    expandLineFluorescentDataCurrentLimit = 150;
                    expandLineFluorescentDataCurrentSizeHold = 150;
                }
                else expandLineFluorescentDataCurrentCount = 0;
                
                if (fluorescentMapCurrentStatus1 == 0 && fluorescentEntryCount >= 1){
                    fluorescentMapCurrentStatus1 = 1;
                    
                    errorNoHold = 53;
                    fluorescentMapCurrent1 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 54;
                        fluorescentMapCurrent1 [counter1] = new int [imageDimension+1];
                    }
                    
                    fluorescentMapCurrentSizeHold = imageDimension;
                }
                else if (fluorescentMapCurrentStatus1 == 1 && fluorescentEntryCount >= 1){
                    if (fluorescentMapCurrentSizeHold < imageDimension){
                        for (int counter1 = 0; counter1 < fluorescentMapCurrentSizeHold+1; counter1++) delete [] fluorescentMapCurrent1 [counter1];
                        delete [] fluorescentMapCurrent1;
                        
                        errorNoHold = 55;
                        fluorescentMapCurrent1 = new int *[imageDimension+1];
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                            errorNoHold = 56;
                            fluorescentMapCurrent1 [counter1] = new int [imageDimension+1];
                        }
                        
                        fluorescentMapCurrentSizeHold = imageDimension;
                    }
                }
                
                if (fluorescentMapCurrentStatus2 == 0 && fluorescentEntryCount >= 2){
                    fluorescentMapCurrentStatus2 = 1;
                    
                    errorNoHold = 57;
                    fluorescentMapCurrent2 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 58;
                        fluorescentMapCurrent2 [counter1] = new int [imageDimension+1];
                    }
                }
                else if (fluorescentMapCurrentStatus2 == 1 && fluorescentEntryCount >= 2){
                    if (fluorescentMapCurrentSizeHold < imageDimension){
                        for (int counter1 = 0; counter1 < fluorescentMapCurrentSizeHold+1; counter1++) delete [] fluorescentMapCurrent2 [counter1];
                        delete [] fluorescentMapCurrent2;
                        
                        errorNoHold = 59;
                        fluorescentMapCurrent2 = new int *[imageDimension+1];
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                            errorNoHold = 60;
                            fluorescentMapCurrent2 [counter1] = new int [imageDimension+1];
                        }
                    }
                }
                
                if (fluorescentMapCurrentStatus3 == 0 && fluorescentEntryCount >= 3){
                    fluorescentMapCurrentStatus3 = 1;
                    
                    errorNoHold = 61;
                    fluorescentMapCurrent3 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 62;
                        fluorescentMapCurrent3 [counter1] = new int [imageDimension+1];
                    }
                }
                else if (fluorescentMapCurrentStatus3 == 1 && fluorescentEntryCount >= 3){
                    if (fluorescentMapCurrentSizeHold < imageDimension){
                        for (int counter1 = 0; counter1 < fluorescentMapCurrentSizeHold+1; counter1++) delete [] fluorescentMapCurrent3 [counter1];
                        delete [] fluorescentMapCurrent3;
                        
                        errorNoHold = 63;
                        fluorescentMapCurrent3 = new int *[imageDimension+1];
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                            errorNoHold = 64;
                            fluorescentMapCurrent3 [counter1] = new int [imageDimension+1];
                        }
                    }
                }
                
                if (fluorescentMapCurrentStatus4 == 0 && fluorescentEntryCount >= 4){
                    fluorescentMapCurrentStatus4 = 1;
                    
                    errorNoHold = 65;
                    fluorescentMapCurrent4 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 66;
                        fluorescentMapCurrent4 [counter1] = new int [imageDimension+1];
                    }
                }
                else if (fluorescentMapCurrentStatus4 == 1 && fluorescentEntryCount >= 4){
                    if (fluorescentMapCurrentSizeHold < imageDimension){
                        for (int counter1 = 0; counter1 < fluorescentMapCurrentSizeHold+1; counter1++) delete [] fluorescentMapCurrent4 [counter1];
                        delete [] fluorescentMapCurrent4;
                        
                        errorNoHold = 67;
                        fluorescentMapCurrent4 = new int *[imageDimension+1];
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                            errorNoHold = 68;
                            fluorescentMapCurrent4 [counter1] = new int [imageDimension+1];
                        }
                    }
                }
                
                if (fluorescentMapCurrentStatus5 == 0 && fluorescentEntryCount >= 5){
                    fluorescentMapCurrentStatus5 = 1;
                    
                    errorNoHold = 69;
                    fluorescentMapCurrent5 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 70;
                        fluorescentMapCurrent5 [counter1] = new int [imageDimension+1];
                    }
                }
                else if (fluorescentMapCurrentStatus5 == 1 && fluorescentEntryCount >= 5){
                    if (fluorescentMapCurrentSizeHold < imageDimension){
                        for (int counter1 = 0; counter1 < fluorescentMapCurrentSizeHold+1; counter1++) delete [] fluorescentMapCurrent5 [counter1];
                        delete [] fluorescentMapCurrent5;
                        
                        errorNoHold = 71;
                        fluorescentMapCurrent5 = new int *[imageDimension+1];
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                            errorNoHold = 72;
                            fluorescentMapCurrent5 [counter1] = new int [imageDimension+1];
                        }
                    }
                }
                
                if (fluorescentMapCurrentStatus6 == 0 && fluorescentEntryCount >= 6){
                    fluorescentMapCurrentStatus6 = 1;
                    
                    errorNoHold = 73;
                    fluorescentMapCurrent6 = new int *[imageDimension+1];
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        errorNoHold = 74;
                        fluorescentMapCurrent6 [counter1] = new int [imageDimension+1];
                    }
                }
                else if (fluorescentMapCurrentStatus6 == 1 && fluorescentEntryCount >= 6){
                    if (fluorescentMapCurrentSizeHold < imageDimension){
                        for (int counter1 = 0; counter1 < fluorescentMapCurrentSizeHold+1; counter1++) delete [] fluorescentMapCurrent6 [counter1];
                        delete [] fluorescentMapCurrent6;
                        
                        errorNoHold = 75;
                        fluorescentMapCurrent6 = new int *[imageDimension+1];
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                            errorNoHold = 76;
                            fluorescentMapCurrent6 [counter1] = new int [imageDimension+1];
                        }
                    }
                }
                
                if (fluorescentEntryCount >= 1){
                    extension2 = to_string(fluorescentNo1);
                    string fluorescentNewPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName1+".tif";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath1.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    if (stat(fluorescentNewPath1.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                        errorNoHold = 1023;
                        throw errorCheckThrow;
                    }
                    
                    if (checkFlag == 1){
                        fin.open(fluorescentNewPath1.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int imageWidthEntry = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            int imageDimensionReadCount = 0;
                            
                            unsigned long headPosition = 0;
                            
                            errorNoHold = 77;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath1.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                imageDimensionReadCount = 0;
                                imageWidthEntry = 0;
                                
                                if (tifImageColorGray == 0){
                                    for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                        fluorescentMapCurrent1 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                                else if (tifImageColorGray == 1){
                                    for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                        value0 = uploadTemp [counter3];
                                        value1 = uploadTemp [counter3+1];
                                        value2 = uploadTemp [counter3+2];
                                        
                                        fluorescentMapCurrent1 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        fluorescentNewPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName1+".bmp";
                        
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath1.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            errorNoHold = 78;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath1.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                int imageDimensionReadCount = 0;
                                
                                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                        fluorescentMapCurrent1 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            else{
                                
                                errorNoHold = 1024;
                                throw errorCheckThrow;
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                }
                
                if (fluorescentEntryCount >= 2){
                    extension2 = to_string(fluorescentNo2);
                    string fluorescentNewPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName2+".tif";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath2.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    if (stat(fluorescentNewPath2.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                        errorNoHold = 1025;
                        throw errorCheckThrow;
                    }
                    
                    if (checkFlag == 1){
                        fin.open(fluorescentNewPath2.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int imageWidthEntry = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            int imageDimensionReadCount = 0;
                            
                            unsigned long headPosition = 0;
                            
                            errorNoHold = 79;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                imageDimensionReadCount = 0;
                                imageWidthEntry = 0;
                                
                                if (tifImageColorGray == 0){
                                    for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                        fluorescentMapCurrent2 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                                else if (tifImageColorGray == 1){
                                    for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                        value0 = uploadTemp [counter3];
                                        value1 = uploadTemp [counter3+1];
                                        value2 = uploadTemp [counter3+2];
                                        
                                        fluorescentMapCurrent2 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        fluorescentNewPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName2+".bmp";
                        
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath2.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            errorNoHold = 80;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                int imageDimensionReadCount = 0;
                                
                                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                        fluorescentMapCurrent2 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            else{
                                
                                errorNoHold = 1026;
                                throw errorCheckThrow;
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                }
                
                if (fluorescentEntryCount >= 3){
                    extension2 = to_string(fluorescentNo3);
                    string fluorescentNewPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName3+".tif";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath3.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    if (stat(fluorescentNewPath3.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                        errorNoHold = 1027;
                        throw errorCheckThrow;
                    }
                    
                    if (checkFlag == 1){
                        fin.open(fluorescentNewPath3.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int imageWidthEntry = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            int imageDimensionReadCount = 0;
                            
                            unsigned long headPosition = 0;
                            
                            errorNoHold = 81;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath3.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                imageDimensionReadCount = 0;
                                imageWidthEntry = 0;
                                
                                if (tifImageColorGray == 0){
                                    for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                        fluorescentMapCurrent3 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                                else if (tifImageColorGray == 1){
                                    for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                        value0 = uploadTemp [counter3];
                                        value1 = uploadTemp [counter3+1];
                                        value2 = uploadTemp [counter3+2];
                                        
                                        fluorescentMapCurrent3 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        fluorescentNewPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName3+".bmp";
                        
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath3.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            errorNoHold = 82;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath3.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                int imageDimensionReadCount = 0;
                                
                                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                        fluorescentMapCurrent3 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            else{
                                
                                errorNoHold = 1028;
                                throw errorCheckThrow;
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                }
                
                if (fluorescentEntryCount >= 4){
                    extension2 = to_string(fluorescentNo4);
                    string fluorescentNewPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName4+".tif";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath4.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    if (stat(fluorescentNewPath4.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                        errorNoHold = 1029;
                        throw errorCheckThrow;
                    }
                    
                    if (checkFlag == 1){
                        fin.open(fluorescentNewPath4.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int imageWidthEntry = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            int imageDimensionReadCount = 0;
                            
                            unsigned long headPosition = 0;
                            
                            errorNoHold = 83;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath4.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                imageDimensionReadCount = 0;
                                imageWidthEntry = 0;
                                
                                if (tifImageColorGray == 0){
                                    for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                        fluorescentMapCurrent4 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                                else if (tifImageColorGray == 1){
                                    for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                        value0 = uploadTemp [counter3];
                                        value1 = uploadTemp [counter3+1];
                                        value2 = uploadTemp [counter3+2];
                                        
                                        fluorescentMapCurrent4 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        fluorescentNewPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName4+".bmp";
                        
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath4.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            errorNoHold = 84;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath4.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                int imageDimensionReadCount = 0;
                                
                                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                        fluorescentMapCurrent4 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            else{
                                
                                errorNoHold = 1030;
                                throw errorCheckThrow;
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                }
                
                if (fluorescentEntryCount >= 5){
                    extension2 = to_string(fluorescentNo5);
                    string fluorescentNewPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName5+".tif";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath5.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    if (stat(fluorescentNewPath5.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                        errorNoHold = 1031;
                        throw errorCheckThrow;
                    }
                    
                    if (checkFlag == 1){
                        fin.open(fluorescentNewPath5.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int imageWidthEntry = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            int imageDimensionReadCount = 0;
                            
                            unsigned long headPosition = 0;
                            
                            errorNoHold = 85;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath5.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                imageDimensionReadCount = 0;
                                imageWidthEntry = 0;
                                
                                if (tifImageColorGray == 0){
                                    for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                        fluorescentMapCurrent5 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                                else if (tifImageColorGray == 1){
                                    for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                        value0 = uploadTemp [counter3];
                                        value1 = uploadTemp [counter3+1];
                                        value2 = uploadTemp [counter3+2];
                                        
                                        fluorescentMapCurrent5 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        fluorescentNewPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName5+".bmp";
                        
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath5.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            errorNoHold = 86;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath5.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                int imageDimensionReadCount = 0;
                                
                                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                        fluorescentMapCurrent5 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            else{
                                
                                errorNoHold = 1032;
                                throw errorCheckThrow;
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                }
                
                if (fluorescentEntryCount >= 6){
                    extension2 = to_string(fluorescentNo6);
                    string fluorescentNewPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName6+".tif";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath6.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    if (stat(fluorescentNewPath6.c_str(), &sizeOfFile) == 0 && checkFlag == 0){
                        errorNoHold = 1033;
                        throw errorCheckThrow;
                    }
                    
                    if (checkFlag == 1){
                        fin.open(fluorescentNewPath6.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int imageWidthEntry = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            int imageDimensionReadCount = 0;
                            
                            unsigned long headPosition = 0;
                            
                            errorNoHold = 87;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath6.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                imageDimensionReadCount = 0;
                                imageWidthEntry = 0;
                                
                                if (tifImageColorGray == 0){
                                    for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                        fluorescentMapCurrent6 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                                else if (tifImageColorGray == 1){
                                    for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                        value0 = uploadTemp [counter3];
                                        value1 = uploadTemp [counter3+1];
                                        value2 = uploadTemp [counter3+2];
                                        
                                        fluorescentMapCurrent6 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        fluorescentNewPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString3+"_"+extension2+"_"+fluorescentName6+".bmp";
                        
                        sizeForCopy = 0;
                        
                        if (stat(fluorescentNewPath6.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            errorNoHold = 88;
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(fluorescentNewPath6.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                int imageDimensionReadCount = 0;
                                
                                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                        fluorescentMapCurrent6 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            else{
                                
                                errorNoHold = 1034;
                                throw errorCheckThrow;
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                }
                
                [self fluorescentProcess2];
                if (errorNoHold != 0){
                    errorNoHold = errorNoHold+2000;
                    throw errorCheckThrow;
                }
            }
            
            //time2 = clock();
            
            sleepingPosition = 14;
            int targetPointer = 0;
            int processTime = 1;
            trackingSetCurrent = [[TrackingSetCurrent alloc] init];
            [trackingSetCurrent trackingSetCurrentMain:processTime];
            
            do{
            } while(subCompletionFlag == 1);
            
            if (errorNoHold != 0){
                errorNoHold = errorNoHold+2000;
                throw errorCheckThrow;
            }
            
            sleepingPosition = 15;
            
            if (xyPositionCenterCurrentCount == 0) trackHoldFlag = 3000;
            else trackHoldFlag = 0;
            
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //    cout<<" arrayTimeSelected "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < imageDimension; counterA++){
            //    for (int counterB = 0; counterB < imageDimension; counterB++){
            //        if (revisedMap [counterA][counterB] == 2528) cout<<revisedMap [counterA][counterB]<<" rrevisedMap"<<endl;
            //    }
            //}
            
            //time3 = clock();
            
            //cout<<"  TimeDDD "<<time3-time2<<" "<<endl;
            
            //for (int counterA = 0; counterA < trackAreaSize; counterA++){
            //	for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingCurrentMap [counterA][counterB];
            //	cout<<" arrayCellTrackingCurrentMap "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < trackAreaSize; counterA++){
            //	for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingPreviousMap [counterA][counterB];
            //	cout<<" arrayCellTrackingPreviousMap "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrevious [counterA*6+counterB];
            //    cout<<" arrayCellTrackingPrevious "<<counterA<<" X, Y, Val, Conn, StEd, Round"<<endl;
            //}
            
            errorNoHold = 89;
            arrayPartnerInfo = new int [20];
            
            for (int counter1 = 0; counter1 < 20; counter1++) arrayPartnerInfo [counter1] = 0;
            
            partnerInfoCount = 0;
            statusAdditionalInfo = 0;
            
            int previousConnectNo = 0;
            int targetCellStatusTemp = 0;
            
            gravityCenterEntryType = 0;
            int processType = 2;
            
            //for (int counterA = 0; counterA < mitosisParameterCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisParameter [counterA*4+counterB];
            //    cout<<" arrayMitosisParameter "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
            //    cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
            //   for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
            //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < timeSelectedCurrentCount/10; counterA++){
            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelectedCurrent [counterA*10+counterB];
            //    cout<<" arrayTimeSelectedCurrent "<<counterA<<endl;
            //}
            
            sleepingPosition = 16;
            
            if (trackHoldFlag == 0){
                tableInterpretation = [[TableInterpretation alloc] init];
                int connectDetect = [tableInterpretation interpretationFirst:processType];
                
                do{
                } while (subCompletionFlag3 == 1);
                
                if (errorNoHold != 0){
                    errorNoHold = errorNoHold+2000;
                    throw errorCheckThrow;
                }
                
                sleepingPosition = 17;
                
                if (connectDetect == 0 && roundStatus == 2) trackHoldFlag = 3000;
                else if (connectDetect == 0 && roundStatus != 2) trackHoldFlag = 3500;
            }
            
            if (trackHoldFlag == 0){
                sleepingPosition = 18;
                targetTrack = [[TargetTrack alloc] init];
                targetPointer = [targetTrack targetTrackProcess]; //--------Determine Previous connect---------
                
                do{
                } while (subCompletionFlag == 1);
                
                if (errorNoHold != 0){
                    errorNoHold = errorNoHold+2000;
                    throw errorCheckThrow;
                }
                
                sleepingPosition = 19;
                
                //cout<<trackHoldFlag<<" A3"<<endl;
                
                if (targetPointer == 0 && roundStatus == 2) trackHoldFlag = 3000;
                else if (targetPointer == 0 && roundStatus != 2) trackHoldFlag = 3500;
                
                if (trackHoldFlag == 0){ //---------TargetTrack may return -1:loading error--------
                    //--------Ref line Set--------
                    
                    //cout<<retryFlag<<" "<<targetPointer<<" Retry"<<endl;
                    
                    if (retryFlag == 0){
                        
                        //for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrevious [counterA*6+counterB];
                        //    cout<<" arrayCellTrackingPrevious "<<counterA<<endl;
                        //}
                        
                        errorNoHold = 90;
                        arrayReferenceLine = new int [cellTrackingPreviousCount+50];
                        referenceLineCount = 0;
                        referenceLineLimit = cellTrackingPreviousCount+50;
                        
                        for (int counter1 = 0; counter1 < cellTrackingPreviousCount/6; counter1++){
                            if (arrayCellTrackingPrevious [counter1*6+3] == targetPointer){
                                if (referenceLineCount+2 > referenceLineLimit){
                                    [self referenceLineCountUpDate];
                                    if (errorNoHold != 0){
                                        errorNoHold = errorNoHold+2000;
                                        throw errorCheckThrow;
                                    }
                                }
                                
                                arrayReferenceLine [referenceLineCount] = arrayCellTrackingPrevious [counter1*6], referenceLineCount++;
                                arrayReferenceLine [referenceLineCount] = arrayCellTrackingPrevious [counter1*6+1], referenceLineCount++;
                            }
                        }
                    }
                    else{ //-------Connect Main target, set at trackHoldFlag = 1011------
                        
                        sleepingPosition = 20;
                        
                        newLineSet = [[NewLineSet alloc] init];
                        [newLineSet newLineSetMain];
                        
                        do{
                        } while (subCompletionFlag == 1);
                        
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                        
                        fusionPartnerCellNo = 0; //------Connect fused------
                        
                        sleepingPosition = 21;
                    }
                    
                    //for (int counterA = 0; counterA < referenceLineCount/2; counterA++){
                    //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<arrayReferenceLine [counterA*2+counterB];
                    //    cout<<" arrayReferenceLine "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
                    //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
                    //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                    //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                    //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                    //    cout<<" arrayTimeSelected "<<counterA<<endl;
                    //}
                    
                    if (roundStatus != 2){
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (arrayCellTrackingTable [counter1*15] == roundStatus-1 && arrayCellTrackingTable [counter1*15+7] == 1){
                                if (arrayCellTrackingTable [counter1*15+14] == 2000) targetCellStatusTemp = 2000;
                                else if (arrayCellTrackingTable [counter1*15+14] > 1000) targetCellStatusTemp = arrayCellTrackingTable [counter1*15+14];
                                else targetCellStatusTemp = arrayCellTrackingTable [counter1*15+14];
                            }
                        }
                        
                        if (targetCellStatus < 1000 && targetCellStatusTemp < 1000) targetCellStatus = targetCellStatusTemp;
                        else if (targetCellStatus < 1000 && targetCellStatusTemp > 1000 && targetCellStatusTemp != 2000) targetCellStatus = targetCellStatusTemp;
                        else if (targetCellStatus < 1000 && targetCellStatusTemp == 2000) targetCellStatus = targetCellStatusTemp;
                        else if (targetCellStatus < 2000 && targetCellStatusTemp < 1000) targetCellStatus = 1000;
                        else if (targetCellStatus < 2000 && targetCellStatusTemp > 1000 && targetCellStatusTemp != 2000) targetCellStatus = targetCellStatusTemp;
                        else if (targetCellStatus < 2000 && targetCellStatusTemp == 2000) targetCellStatus = targetCellStatusTemp;
                        else if (targetCellStatus == 2000 && targetCellStatusTemp < 1000) targetCellStatus = 2000;
                        else if (targetCellStatus == 2000 && targetCellStatusTemp > 1000 && targetCellStatusTemp != 2000) targetCellStatus = 2000;
                        else if (targetCellStatus == 2000 && targetCellStatusTemp == 2000) targetCellStatus = targetCellStatusTemp;
                    }
                    else{
                        
                        targetCellStatus = 0;
                        
                        int connectNoTemp = 0;
                        
                        for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                            if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt){
                                connectNoTemp = arrayConnectLineageRel [counter1*6+1];
                                break;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                            if (arrayTimeSelected [counter1*10+8] == connectNoTemp){
                                if (arrayTimeSelected [counter1*10] == 1) targetCellStatus = 1000;
                                else if (arrayTimeSelected [counter1*10] == 7) targetCellStatus = 2000;
                                
                                break;
                            }
                        }
                    }
                    
                    //time4 = clock();
                    
                    sleepingPosition = 22;
                    
                    int currentResetFlag = 0;
                    int forceSet = 0;
                    
                    if (retryFlag == 0){
                        int cutOffAdjust = -1;
                        averageHold = 0;
                        trackHoldFlag = 0;
                        
                        overlapCheck = [[OverlapCheck alloc] init];
                        [overlapCheck overlapCheckMain:cutOffAdjust];
                        
                        do{
                        } while (subCompletionFlag == 1);
                        
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                        
                        if (trackHoldFlag == 3000 && gravityCentreMoveLimitFlag == 1){
                            trackHoldFlag = 0;
                            cutOffAdjust = (int)(averageHold*0.5);
                            
                            if (optionalShiftPercent != 0){
                                double averageOverlayHold [4];
                                double averageHoldTemp = averageHold;
                                
                                errorNoHold = 91;
                                arrayOptionalLineData = new int [1000];
                                optionalLineDataCount = 0;
                                optionalLineDataLimit = 1000;
                                
                                for (int counter1 = 0; counter1 < 4; counter1++){
                                    if (counter1 == 0){
                                        optionalShiftOrientation = 1;
                                    }
                                    else if (counter1 == 1){
                                        optionalShiftOrientation = 2;
                                    }
                                    else if (counter1 == 2){
                                        optionalShiftOrientation = 3;
                                    }
                                    else if (counter1 == 3){
                                        optionalShiftOrientation = 4;
                                    }
                                    
                                    averageHold = 0;
                                    
                                    overlapCheck = [[OverlapCheck alloc] init];
                                    [overlapCheck overlapCheckMain:cutOffAdjust];
                                    
                                    do{
                                    } while (subCompletionFlag == 1);
                                    
                                    if (errorNoHold != 0){
                                        errorNoHold = errorNoHold+2000;
                                        throw errorCheckThrow;
                                    }
                                    
                                    averageOverlayHold [counter1] = averageHold;
                                }
                                
                                int averageHoldDifferences = 0;
                                int averageHoldDifferencesPosition = 0;
                                
                                for (int counter1 = 0; counter1 < 4; counter1++){
                                    if (averageHoldDifferences < abs(averageHoldTemp-averageOverlayHold [counter1]) && averageHoldTemp-averageOverlayHold [counter1] < 40){
                                        averageHoldDifferences = (int)(abs(averageHoldTemp-averageOverlayHold [counter1]));
                                        averageHoldDifferencesPosition = counter1;
                                    }
                                }
                                
                                int optionalLineDataNumber = 0;
                                
                                for (int counter1 = 0; counter1 < optionalLineDataCount/3; counter1++){
                                    if (arrayOptionalLineData [counter1*3+2] == averageHoldDifferencesPosition){
                                        optionalLineDataNumber++;
                                    }
                                }
                                
                                if (optionalLineDataNumber != 0){
                                    delete [] arrayReferenceLine;
                                    
                                    errorNoHold = 92;
                                    arrayReferenceLine = new int [optionalLineDataNumber+50];
                                    referenceLineCount = 0;
                                    referenceLineLimit = optionalLineDataNumber+50;
                                    
                                    for (int counter1 = 0; counter1 < optionalLineDataCount/3; counter1++){
                                        if (arrayOptionalLineData [counter1*3+2] == averageHoldDifferencesPosition){
                                            arrayReferenceLine [referenceLineCount] = arrayOptionalLineData [counter1*3], referenceLineCount++;
                                            arrayReferenceLine [referenceLineCount] = arrayOptionalLineData [counter1*3+1], referenceLineCount++;
                                        }
                                    }
                                    
                                    delete [] arrayOptionalLineData;
                                    
                                    averageHold = averageOverlayHold [averageHoldDifferencesPosition];
                                }
                            }
                            else{
                                
                                averageHold = 0;
                                
                                overlapCheck = [[OverlapCheck alloc] init];
                                [overlapCheck overlapCheckMain:cutOffAdjust];
                                
                                do{
                                } while (subCompletionFlag == 1);
                                
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                            }
                            
                            if (trackHoldFlag != 3000){
                                int processType2 = 3;
                                int targetStatus2 = 0;
                                trackHoldFlag = 0;
                                
                                cutOffAdjust = (int)(averageHold*0.5);
                                
                                areaCutCurrent = [[AreaCutCurrent alloc] init];
                                [areaCutCurrent circleCut:processType2:targetStatus2:cutOffAdjust]; //------trackHoldFlag 3000, 3002, 3003-------
                                
                                do{
                                } while (subCompletionFlag == 1);
                                
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                                
                                if (trackHoldFlag != 3000) forceSet = 1;
                                
                                currentResetFlag = 1;
                            }
                            
                            if (trackHoldFlag == 3000 && gravityCentreMoveLimitFlag == 1){
                                trackHoldFlag = 0;
                                averageHold = 0;
                                
                                cutOffAdjust = (int)(averageHold*0.1);
                                
                                if (optionalShiftPercent != 0){
                                    double averageOverlayHold [4];
                                    double averageHoldTemp = averageHold;
                                    
                                    errorNoHold = 93;
                                    arrayOptionalLineData = new int [1000];
                                    optionalLineDataCount = 0;
                                    optionalLineDataLimit = 1000;
                                    
                                    for (int counter1 = 0; counter1 < 4; counter1++){
                                        if (counter1 == 0){
                                            optionalShiftOrientation = 1;
                                        }
                                        else if (counter1 == 1){
                                            optionalShiftOrientation = 2;
                                        }
                                        else if (counter1 == 2){
                                            optionalShiftOrientation = 3;
                                        }
                                        else if (counter1 == 3){
                                            optionalShiftOrientation = 4;
                                        }
                                        
                                        averageHold = 0;
                                        
                                        overlapCheck = [[OverlapCheck alloc] init];
                                        [overlapCheck overlapCheckMain:cutOffAdjust];
                                        
                                        do{
                                        } while (subCompletionFlag == 1);
                                        
                                        if (errorNoHold != 0){
                                            errorNoHold = errorNoHold+2000;
                                            throw errorCheckThrow;
                                        }
                                        
                                        averageOverlayHold [counter1] = averageHold;
                                    }
                                    
                                    int averageHoldDifferences = 0;
                                    int averageHoldDifferencesPosition = 0;
                                    
                                    for (int counter1 = 0; counter1 < 4; counter1++){
                                        if (averageHoldDifferences < abs(averageHoldTemp-averageOverlayHold [counter1]) && averageHoldTemp-averageOverlayHold [counter1] < 40){
                                            averageHoldDifferences = (int)(abs(averageHoldTemp-averageOverlayHold [counter1]));
                                            averageHoldDifferencesPosition = counter1;
                                        }
                                    }
                                    
                                    int optionalLineDataNumber = 0;
                                    
                                    for (int counter1 = 0; counter1 < optionalLineDataCount/3; counter1++){
                                        if (arrayOptionalLineData [counter1*3+2] == averageHoldDifferencesPosition){
                                            optionalLineDataNumber++;
                                        }
                                    }
                                    
                                    if (optionalLineDataNumber != 0){
                                        delete [] arrayReferenceLine;
                                        
                                        errorNoHold = 94;
                                        arrayReferenceLine = new int [optionalLineDataNumber+50];
                                        referenceLineCount = 0;
                                        referenceLineLimit = optionalLineDataNumber+50;
                                        
                                        for (int counter1 = 0; counter1 < optionalLineDataCount/3; counter1++){
                                            if (arrayOptionalLineData [counter1*3+2] == averageHoldDifferencesPosition){
                                                arrayReferenceLine [referenceLineCount] = arrayOptionalLineData [counter1*3], referenceLineCount++;
                                                arrayReferenceLine [referenceLineCount] = arrayOptionalLineData [counter1*3+1], referenceLineCount++;
                                            }
                                        }
                                        
                                        delete [] arrayOptionalLineData;
                                        
                                        averageHold = averageOverlayHold [averageHoldDifferencesPosition];
                                    }
                                }
                                else{
                                    
                                    averageHold = 0;
                                    
                                    overlapCheck = [[OverlapCheck alloc] init];
                                    [overlapCheck overlapCheckMain:cutOffAdjust];
                                    
                                    do{
                                    } while (subCompletionFlag == 1);
                                    
                                    if (errorNoHold != 0){
                                        errorNoHold = errorNoHold+2000;
                                        throw errorCheckThrow;
                                    }
                                }
                                
                                if (trackHoldFlag != 3000){
                                    int processType2 = 3;
                                    int targetStatus2 = 0;
                                    trackHoldFlag = 0;
                                    
                                    cutOffAdjust = (int)(averageHold*0.1);
                                    
                                    areaCutCurrent = [[AreaCutCurrent alloc] init];
                                    [areaCutCurrent circleCut:processType2:targetStatus2:cutOffAdjust]; //------trackHoldFlag 3000, 3002, 3003-------
                                    
                                    do{
                                    } while (subCompletionFlag == 1);
                                    
                                    if (errorNoHold != 0){
                                        errorNoHold = errorNoHold+2000;
                                        throw errorCheckThrow;
                                    }
                                    
                                    if (trackHoldFlag != 3000) forceSet = 1;
                                    
                                    currentResetFlag = 1;
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                    //    for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingCurrentMap [counterA][counterB];
                    //    cout<<" arrayCellTrackingCurrentMap "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                    //    for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingPreviousMap [counterA][counterB];
                    //    cout<<" arrayCellTrackingPreviousMap "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                    //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                    //    cout<<" arrayTimeSelected "<<counterA<<endl;
                    //}
                    
                    if (retryFlag == 0 && gravityCentreMoveLimitFlag == 1 && currentResetFlag == 0){
                        errorNoHold = 95;
                        int *currentTempList = new int [cellTrackingCurrentAssCount/6+10];
                        
                        for (int counter1 = 0; counter1 < cellTrackingCurrentAssCount/6+10; counter1++) currentTempList [counter1] = 0;
                        
                        for (int counterY = 0; counterY < trackAreaSize; counterY++){
                            for (int counterX = 0; counterX < trackAreaSize; counterX++){
                                if (arrayCellTrackingPreviousMap [counterY][counterX] == targetPointer){
                                    if (arrayCellTrackingCurrentMap [counterY][counterX] != 0){
                                        currentTempList [arrayCellTrackingCurrentMap [counterY][counterX]]++;
                                    }
                                }
                            }
                        }
                        
                        int largestCurrentOverlap = 0;
                        
                        for (int counter1 = 1; counter1 <= cellTrackingCurrentAssCount/6; counter1++){
                            if (currentTempList [counter1] > largestCurrentOverlap) largestCurrentOverlap = currentTempList [counter1];
                        }
                        
                        if (largestCurrentOverlap < 75){
                            int processType2 = 3;
                            int targetStatus2 = 0;
                            int cutOffAdjust = -1;
                            trackHoldFlag = 0;
                            averageCurrentHold = 0;
                            
                            areaCutCurrent = [[AreaCutCurrent alloc] init];
                            [areaCutCurrent circleCut:processType2:targetStatus2:cutOffAdjust]; //------trackHoldFlag 3000, 3002, 3003-------
                            
                            do{
                            } while (subCompletionFlag == 1);
                            
                            if (errorNoHold != 0){
                                errorNoHold = errorNoHold+2000;
                                throw errorCheckThrow;
                            }
                            
                            if (trackHoldFlag != 3000) forceSet = 1;
                            
                            if (trackHoldFlag == 3000){
                                processType2 = 3;
                                targetStatus2 = 0;
                                trackHoldFlag = 0;
                                
                                cutOffAdjust = (int)(averageCurrentHold*0.5);
                                
                                areaCutCurrent = [[AreaCutCurrent alloc] init];
                                [areaCutCurrent circleCut:processType2:targetStatus2:cutOffAdjust]; //------trackHoldFlag 3000, 3002, 3003-------
                                
                                do{
                                } while (subCompletionFlag == 1);
                                
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                                
                                if (trackHoldFlag != 3000) forceSet = 1;
                                
                                if (trackHoldFlag == 3000){
                                    processType2 = 3;
                                    targetStatus2 = 0;
                                    trackHoldFlag = 0;
                                    
                                    cutOffAdjust = (int)(averageCurrentHold*0.2);
                                    
                                    areaCutCurrent = [[AreaCutCurrent alloc] init];
                                    [areaCutCurrent circleCut:processType2:targetStatus2:cutOffAdjust]; //------trackHoldFlag 3000, 3002, 3003-------
                                    
                                    do{
                                    } while (subCompletionFlag == 1);
                                    
                                    if (errorNoHold != 0){
                                        errorNoHold = errorNoHold+2000;
                                        throw errorCheckThrow;
                                    }
                                    
                                    if (trackHoldFlag != 3000) forceSet = 1;
                                }
                            }
                        }
                        
                        delete [] currentTempList;
                    }
                    
                    sleepingPosition = 23;
                    
                    retryFlag = 0;
                    
                    if (trackHoldFlag != 0 && roundStatus != 2) trackHoldFlag = 3500;
                    
                    //for (int counterA = 0; counterA < referenceLineCount/2; counterA++){
                    //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<arrayReferenceLine [counterA*2+counterB];
                    //    cout<<" arrayReferenceLine "<<counterA<<endl;
                    //}
                    
                    //cout<<trackHoldFlag<<" "<<roundStatus<<" AF_overlap"<<endl;
                    
                    //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
                    //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
                    //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
                    //}
                    
                    if (trackHoldFlag == 0){
                        gravityCenterXHold1 = 0;
                        gravityCenterYHold1 = 0;
                        gravityAverageHold1 = 0;
                        gravityCellNo1 = 0;
                        
                        sleepingPosition = 24;
                        
                        int cutOffAdjust = -1;
                        int processPreviousType = 0;
                        averageHold = 0;
                        
                        areaCut = [[AreaCut alloc] init];
                        previousConnectNo = [areaCut circleCut:targetCellStatus:cutOffAdjust:processPreviousType]; //-------Return Results, No of Previous Connect of Target-------
                        
                        do{
                        } while (subCompletionFlag == 1);
                        
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                        
                        //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                        //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                        //    cout<<" arrayTimeSelected "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
                        //    cout<<" arrayGravityCenterRev "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < imageDimension; counterA++){
                        //    for (int counterB = 0; counterB < imageDimension; counterB++){
                        //        if (revisedWorkingMap [counterA][counterB] == 2675) cout<<revisedWorkingMap [counterA][counterB]<<" revisedWorkingMap"<<endl;
                        //    }
                        //}
                        
                        if (trackHoldFlag == 3000 && gravityCentreMoveLimitFlag == 1){
                            trackHoldFlag = 0;
                            processPreviousType = 1;
                            
                            cutOffAdjust = (int)(averageHold*0.5);
                            
                            averageHold = 0;
                            
                            areaCut = [[AreaCut alloc] init];
                            previousConnectNo = [areaCut circleCut:targetCellStatus:cutOffAdjust:processPreviousType]; //-------Return Results, No of Previous Connect of Target-------
                            
                            do{
                            } while (subCompletionFlag == 1);
                            
                            if (errorNoHold != 0){
                                errorNoHold = errorNoHold+2000;
                                throw errorCheckThrow;
                            }
                            
                            if (trackHoldFlag != 3000) forceSet = 1;
                            
                            if (trackHoldFlag == 3000 && gravityCentreMoveLimitFlag == 1){
                                trackHoldFlag = 0;
                                processPreviousType = 1;
                                
                                cutOffAdjust = (int)(averageHold*0.5);
                                
                                areaCut = [[AreaCut alloc] init];
                                previousConnectNo = [areaCut circleCut:targetCellStatus:cutOffAdjust:processPreviousType]; //-------Return Results, No of Previous Connect of Target-------
                                
                                do{
                                } while (subCompletionFlag == 1);
                                
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                                
                                if (trackHoldFlag != 3000) forceSet = 1;
                                
                                if (trackHoldFlag == 3000 && gravityCentreMoveLimitFlag == 1){
                                    trackHoldFlag = 0;
                                    processPreviousType = 1;
                                    
                                    cutOffAdjust = (int)(averageHold*0.1);
                                    
                                    areaCut = [[AreaCut alloc] init];
                                    previousConnectNo = [areaCut circleCut:targetCellStatus:cutOffAdjust:processPreviousType]; //-------Return Results, No of Previous Connect of Target-------
                                    
                                    do{
                                    } while (subCompletionFlag == 1);
                                    
                                    if (errorNoHold != 0){
                                        errorNoHold = errorNoHold+2000;
                                        throw errorCheckThrow;
                                    }
                                    
                                    if (trackHoldFlag != 3000) forceSet = 1;
                                }
                            }
                        }
                        
                        if (trackHoldFlag != 0 && roundStatus != 2) trackHoldFlag = 3500;
                        
                        sleepingPosition = 25;
                        
                        //cout<<previousConnectNo<<" previousConnectNo"<<endl;
                        
                        //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
                        //    cout<<" arrayGravityCenterRev "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
                        //    cout<<" arrayConnectLineageRel "<<counterA<<endl;
                        //}
                        
                        //time5 = clock();
                        
                        if (trackHoldFlag == 0){
                            sleepingPosition = 26;
                            processType = 3;
                            int imageNo = 0;
                            
                            trackingSet = [[TrackingSet alloc] init];
                            [trackingSet trackingSetMain:processType:imageNo];
                            
                            do{
                            } while (subCompletionFlag == 1);
                            
                            if (errorNoHold != 0){
                                errorNoHold = errorNoHold+2000;
                                throw errorCheckThrow;
                            }
                            
                            sleepingPosition = 27;
                            
                            processType = 1;
                            tableInterpretation = [[TableInterpretation alloc] init];
                            [tableInterpretation interpretationFirst:processType];
                            
                            do{
                            } while (subCompletionFlag3 == 1);
                            
                            if (errorNoHold != 0){
                                errorNoHold = errorNoHold+2000;
                                throw errorCheckThrow;
                            }
                            
                            sleepingPosition = 28;
                            
                            processType = 2;
                            trackingSetCurrent = [[TrackingSetCurrent alloc] init];
                            [trackingSetCurrent trackingSetCurrentMain:processType];
                            
                            do{
                            } while (subCompletionFlag == 1);
                            
                            if (errorNoHold != 0){
                                errorNoHold = errorNoHold+2000;
                                throw errorCheckThrow;
                            }
                            
                            if (xyPositionCenterCurrentCount == 0) trackHoldFlag = 3000;
                            else trackHoldFlag = 0;
                            
                            sleepingPosition = 29;
                            
                            if (trackHoldFlag == 0){
                                processType = 2;
                                tableInterpretation = [[TableInterpretation alloc] init];
                                [tableInterpretation interpretationFirst:processType];
                                
                                do{
                                } while (subCompletionFlag3 == 1);
                                
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                                
                                sleepingPosition = 30;
                                
                                //for (int counterA = 0; counterA < xyPositionCenterPreviousCount/6; counterA++){
                                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterPrevious [counterA*6+counterB];
                                //    cout<<" arrayXYPositionCenterPrevious "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
                                //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
                                //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
                                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
                                //    cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
                                //}
                                
                                //cout<<trackHoldFlag<<" "<<roundStatus<<" HoldFlag3"<<endl;
                                
                                int targetPointer2 = 0;
                                targetTrack2 = [[TargetTrack2 alloc] init];
                                targetPointer2 = [targetTrack2 targetTrackProcess:forceSet]; //-------The Previous will not be changed, the current may be changed--------
                                
                                do{
                                } while (subCompletionFlag == 1);
                                
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                                
                                sleepingPosition = 31;
                                
                                if (targetPointer2 == 0) trackHoldFlag = 3000;
                            }
                            
                            if (trackHoldFlag == 0){
                                sleepingPosition = 32;
                                generateInterpretTable = [[GenerateInterpretTable alloc] init];
                                [generateInterpretTable trackTableGenerate];
                                
                                do{
                                } while (subCompletionFlag == 1);
                                
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                                
                                statusAdditionalInfo = 0;
                                fusionPartnerLine = 0;
                                fusionPartnerCellNo = 0;
                                
                                sleepingPosition = 33;
                                sleepingPosition = 34;
                                
                                tableInterpretation = [[TableInterpretation alloc] init];
                                [tableInterpretation interpretationMain2];
                                
                                do{
                                } while (subCompletionFlag3 == 1);
                                
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                                
                                sleepingPosition = 35;
                                
                                //time6 = clock();
                            }
                        }
                    }
                    
                    delete [] arrayReferenceLine;
                }
                else if (retryFlag != 0){
                    retryFlag = 0;
                    delete [] arrayReferenceLine;
                }
            }
            
            //for (int counterA = 0; counterA < timeSelectedCurrentCount/10; counterA++){
            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelectedCurrent [counterA*10+counterB];
            //    cout<<" arrayTimeSelectedCurrent "<<counterA<<endl;
            //}
            
            //cout<<trackHoldFlag<<" "<<roundStatus<<" HoldFlagFinal"<<endl;
            
            //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
            //    cout<<" arrayEventSequence "<<counterA<<endl;
            //}
            
            sleepingPosition = 36;
            
            if (trackHoldFlag == 100 && outsideSettingFlag == 1){
                int eventTypeMitosis = 0;
                int eventTypeMitosis2 = 0;
                
                for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                    if (arrayLineageStartEnd [counter1*8] == cellLineageTempInt && arrayLineageStartEnd [counter1*8+1] == cellNumberTempInt){
                        for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                            if (arrayLineageData [counter2*8+2] == statusAdditionalInfo){
                                eventTypeMitosis = arrayLineageData [counter2*8+3];
                            }
                            if (arrayLineageData [counter2*8+2] == statusAdditionalInfo+1){
                                eventTypeMitosis2 = arrayLineageData [counter2*8+3];
                            }
                        }
                    }
                }
                
                int newSettingPosition = 0;
                
                if (eventTypeMitosis != 2){
                    if (eventTypeMitosis2 != 2) trackHoldFlag = 101;
                    else newSettingPosition = statusAdditionalInfo+1;
                }
                else newSettingPosition = statusAdditionalInfo;
                
                int fusionFind = 0;
                
                for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                    if (arrayLineageStartEnd [counter1*8] == cellLineageTempInt && arrayLineageStartEnd [counter1*8+1] == cellNumberTempInt){
                        for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                            if (arrayLineageData [counter2*8+2] >= newSettingPosition && arrayLineageData [counter2*8+3] == 92){
                                fusionFind = 1;
                            }
                        }
                    }
                }
                
                if (fusionFind == 1) trackHoldFlag = 101;
                
                if (trackHoldFlag == 100){
                    for (int counter1 = 0; counter1 < mitosisParameterCount/4; counter1++){
                        if (arrayMitosisParameter [counter1*4+2] < newSettingPosition) arrayMitosisParameter [counter1*4+3] = 0;
                        else if (arrayMitosisParameter [counter1*4+2] >= newSettingPosition) arrayMitosisParameter [counter1*4+3] = 5;
                    }
                    
                    returnMessage = "RM";
                    returnMessageTime = "0";
                    returnMessageExt = to_string(newSettingPosition);
                    
                    firstCommunication = 4;
                }
                else if (trackHoldFlag == 101){
                    for (int counter1 = 0; counter1 < mitosisParameterCount/4; counter1++){
                        if (arrayMitosisParameter [counter1*4+3] == 5) arrayMitosisParameter [counter1*4+3] = 1;
                    }
                    
                    //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
                    //    cout<<" arrayEventSequence "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < mitosisParameterCount/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisParameter [counterA*4+counterB];
                    //    cout<<" arrayMitosisParameter "<<counterA<<endl;
                    //}
                    
                    processType = 1;
                    trackingDataSave = [[TrackingDataSave alloc] init];
                    [trackingDataSave trackingDataSaveTemp:processType];
                    
                    do{
                    } while (subCompletionFlag == 1);
                    
                    if (errorNoHold != 0){
                        errorNoHold = errorNoHold+2000;
                        throw errorCheckThrow;
                    }
                    
                    returnMessage = "MF";
                    returnMessageTime = to_string(imageNumberInt);
                    returnMessageExt = "0";
                    
                    firstCommunication = 4;
                }
                
                trackHoldFlag = 50; //-------End--------
            }
            
            sleepingPosition = 37;
            
            if (trackHoldFlag == 0 || trackHoldFlag == -2 || trackHoldFlag == -3 || trackHoldFlag == 100 || trackHoldFlag == 1012){
                int currentConnectNo = 0;
                
                if (trackHoldFlag == 1012){
                    trackHoldFlag = 0;
                    retryFlag = -10;
                    
                    newLineSet = [[NewLineSet alloc] init];
                    [newLineSet newLineSetMain]; //-------Ref will be set------
                    
                    do{
                    } while (subCompletionFlag == 1);
                    
                    if (errorNoHold != 0){
                        errorNoHold = errorNoHold+2000;
                        throw errorCheckThrow;
                    }
                    
                    retryFlag = 0;
                    
                    //for (int counterA = 0; counterA < referenceLineCount/2; counterA++){
                    //	for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<arrayReferenceLine [counterA*2+counterB];
                    //	cout<<" arrayReferenceLine "<<counterA<<endl;
                    //}
                    
                    if (trackHoldFlag != 3000){
                        targetCellStatus = 0;
                        
                        if (roundStatus != 2){
                            for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                                if (arrayCellTrackingTable [counter1*15] == roundStatus-1 && arrayCellTrackingTable [counter1*15+7] == 1){
                                    if (arrayCellTrackingTable [counter1*15+14] == 2000) targetCellStatus = 2000;
                                    else if (arrayCellTrackingTable [counter1*15+14] > 1000) targetCellStatus = arrayCellTrackingTable [counter1*15+14];
                                    else targetCellStatus = arrayCellTrackingTable [counter1*15+14];
                                }
                            }
                        }
                        else{
                            
                            int connectNoTemp = 0;
                            
                            for (int counter1 = 0; counter1 < connectLineageRelCurrentCount/6; counter1++){
                                if (arrayConnectLineageRelCurrent [counter1*6] == cellLineageTempInt && arrayConnectLineageRelCurrent [counter1*6+3] == cellNumberTempInt){
                                    connectNoTemp = arrayConnectLineageRelCurrent [counter1*6+1];
                                    break;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < timeSelectedCurrentCount/10; counter1++){
                                if (arrayTimeSelectedCurrent [counter1*10+8] == connectNoTemp){
                                    if (arrayTimeSelectedCurrent [counter1*10] == 1) targetCellStatus = 1000;
                                    else if (arrayTimeSelectedCurrent [counter1*10] == 7) targetCellStatus = 2000;
                                    
                                    break;
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
                        //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
                        //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
                        //}
                        
                        processType = 2; //------1: fusion, 2: non-fusion-------
                        
                        gravityCenterEntryType = 1;
                        gravityCenterXCurrentHold1 = 0;
                        gravityCenterYCurrentHold1 = 0;
                        gravityAverageCurrentHold1 = 0;
                        gravityCellNoCurrent1 = 0;
                        gravityCenterXCurrentHold2 = 0;
                        gravityCenterYCurrentHold2 = 0;
                        gravityAverageCurrentHold2 = 0;
                        gravityCellNoCurrent2 = 0;
                        gravityCenterXCurrentHold3 = 0;
                        gravityCenterYCurrentHold3 = 0;
                        gravityAverageCurrentHold3 = 0;
                        gravityCellNoCurrent3 = 0;
                        gravityCenterXCurrentHold4 = 0;
                        gravityCenterYCurrentHold4 = 0;
                        gravityAverageCurrentHold4 = 0;
                        gravityCellNoCurrent4 = 0;
                        
                        int cutOffAdjust = -1;
                        
                        areaCutCurrent = [[AreaCutCurrent alloc] init];
                        currentConnectNo = [areaCutCurrent circleCut:processType:targetCellStatus:cutOffAdjust]; //------trackHoldFlag 3000, 3002, 3003-------
                        
                        do{
                        } while (subCompletionFlag == 1);
                        
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                        
                        delete [] arrayReferenceLine;
                    }
                    
                    if (trackHoldFlag != 3000 && trackHoldFlag != 3002 && trackHoldFlag != 3003) trackHoldFlag = 0;
                }
                else{
                    
                    //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
                    //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
                    //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
                    //}
                    
                    targetCellStatus = 0;
                    
                    if (roundStatus != 2){
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (arrayCellTrackingTable [counter1*15] == roundStatus-1 && arrayCellTrackingTable [counter1*15+7] == 1){
                                if (arrayCellTrackingTable [counter1*15+14] == 2000) targetCellStatus = 2000;
                                else if (arrayCellTrackingTable [counter1*15+14] > 1000) targetCellStatus = arrayCellTrackingTable [counter1*15+14];
                                else targetCellStatus = arrayCellTrackingTable [counter1*15+14];
                            }
                        }
                    }
                    else{
                        
                        int connectNoTemp = 0;
                        
                        for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                            if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt){
                                connectNoTemp = arrayConnectLineageRel [counter1*6+1];
                                break;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                            if (arrayTimeSelected [counter1*10+8] == connectNoTemp){
                                if (arrayTimeSelected [counter1*10] == 1) targetCellStatus = 1000;
                                else if (arrayTimeSelected [counter1*10] == 7) targetCellStatus = 2000;
                                
                                break;
                            }
                        }
                    }
                    
                    int targetPointer2 = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (arrayCellTrackingTable [counter1*15] == roundStatus && arrayCellTrackingTable [counter1*15+7] == 1){
                            targetPointer2 = arrayCellTrackingTable [counter1*15+2];
                            break;
                        }
                    }
                    
                    //cout<<targetPointer<<" "<<targetPointer2<<" Pointer"<<endl;
                    
                    //for (int counterA = 0; counterA < cellTrackingCurrentCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingCurrent [counterA*6+counterB];
                    //	cout<<" arrayCellTrackingCurrent "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < trackAreaSize; counterA++){
                    //	for (int counterB = 0; counterB < trackAreaSize; counterB++) cout<<" "<<arrayCellTrackingCurrentMap [counterA][counterB];
                    //	cout<<" arrayCellTrackingCurrentMap "<<counterA<<endl;
                    //}
                    
                    errorNoHold = 96;
                    arrayReferenceLine = new int [cellTrackingCurrentCount+50];
                    referenceLineCount = 0;
                    referenceLineLimit = cellTrackingCurrentCount+50;
                    
                    for (int counter1 = 0; counter1 < cellTrackingCurrentCount/6; counter1++){
                        if (arrayCellTrackingCurrent [counter1*6+3] == targetPointer2){
                            if (referenceLineCount+2 > referenceLineLimit){
                                [self referenceLineCountUpDate];
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                            }
                            
                            arrayReferenceLine [referenceLineCount] = arrayCellTrackingCurrent [counter1*6], referenceLineCount++;
                            arrayReferenceLine [referenceLineCount] = arrayCellTrackingCurrent [counter1*6+1], referenceLineCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < referenceLineCount/2; counterA++){
                    //	for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<arrayReferenceLine [counterA*2+counterB];
                    //	cout<<" arrayReferenceLine "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < timeSelectedCurrentCount/10; counterA++){
                    //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelectedCurrent [counterA*10+counterB];
                    //	cout<<" arrayTimeSelectedCurrent "<<counterA+1<<" "<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
                    //    cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
                    //}
                    
                    processType = 2; //------1: fusion, 2: non-fusion-------
                    
                    gravityCenterEntryType = 1;
                    gravityCenterXCurrentHold1 = 0;
                    gravityCenterYCurrentHold1 = 0;
                    gravityAverageCurrentHold1 = 0;
                    gravityCellNoCurrent1 = 0;
                    gravityCenterXCurrentHold2 = 0;
                    gravityCenterYCurrentHold2 = 0;
                    gravityAverageCurrentHold2 = 0;
                    gravityCellNoCurrent2 = 0;
                    gravityCenterXCurrentHold3 = 0;
                    gravityCenterYCurrentHold3 = 0;
                    gravityAverageCurrentHold3 = 0;
                    gravityCellNoCurrent3 = 0;
                    gravityCenterXCurrentHold4 = 0;
                    gravityCenterYCurrentHold4 = 0;
                    gravityAverageCurrentHold4 = 0;
                    gravityCellNoCurrent4 = 0;
                    
                    int trackingHoldFlagHold = trackHoldFlag;
                    
                    if (referenceLineCount != 0){
                        int cutOffAdjust = -1;
                        areaCutCurrent = [[AreaCutCurrent alloc] init];
                        currentConnectNo = [areaCutCurrent circleCut:processType:targetCellStatus:cutOffAdjust]; //------trackHoldFlag 3000, 3002, 3003-------
                        
                        do{
                        } while (subCompletionFlag == 1);
                        
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                    }
                    else trackHoldFlag = 3000;
                    
                    if (trackHoldFlag == 3000 && gravityCentreMoveLimitFlag == 1){
                        trackHoldFlag = trackingHoldFlagHold;
                        
                        targetPointer2 = 0;
                        
                        for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                            if (arrayCellTrackingTable [counter1*15] == roundStatus-1){
                                if (arrayCellTrackingTable [counter1*15+7] == 1){
                                    targetPointer2 = arrayCellTrackingTable [counter1*15+2];
                                    break;
                                }
                            }
                        }
                        
                        delete [] arrayReferenceLine;
                        
                        errorNoHold = 97;
                        arrayReferenceLine = new int [cellTrackingPreviousCount+50];
                        referenceLineCount = 0;
                        referenceLineLimit = cellTrackingPreviousCount+50;
                        
                        for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                            if (arrayPositionRevise [counter1*7+3] == targetPointer2){
                                if (referenceLineCount+2 > referenceLineLimit){
                                    [self referenceLineCountUpDate];
                                    if (errorNoHold != 0){
                                        errorNoHold = errorNoHold+2000;
                                        throw errorCheckThrow;
                                    }
                                }
                                
                                arrayReferenceLine [referenceLineCount] = arrayPositionRevise [counter1*7], referenceLineCount++;
                                arrayReferenceLine [referenceLineCount] = arrayPositionRevise [counter1*7+1], referenceLineCount++;
                            }
                        }
                        
                        if (referenceLineCount != 0){
                            int cutOffAdjust = -1;
                            averageCurrentHold = 0;
                            
                            areaCutCurrent = [[AreaCutCurrent alloc] init];
                            currentConnectNo = [areaCutCurrent circleCut:processType:targetCellStatus:cutOffAdjust]; //------trackHoldFlag 3000, 3002, 3003-------
                            
                            do{
                            } while (subCompletionFlag == 1);
                            
                            if (errorNoHold != 0){
                                errorNoHold = errorNoHold+2000;
                                throw errorCheckThrow;
                            }
                            
                            if (trackHoldFlag == 3000 && gravityCentreMoveLimitFlag == 1){
                                cutOffAdjust = (int)(averageCurrentHold*0.5);
                                averageCurrentHold = 0;
                                trackHoldFlag = 0;
                                
                                areaCutCurrent = [[AreaCutCurrent alloc] init];
                                currentConnectNo = [areaCutCurrent circleCut:processType:targetCellStatus:cutOffAdjust]; //------trackHoldFlag 3000, 3002, 3003-------
                                
                                do{
                                } while (subCompletionFlag == 1);
                                
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                                
                                if (trackHoldFlag == 3000 && gravityCentreMoveLimitFlag == 1){
                                    cutOffAdjust = (int)(averageCurrentHold*0.1);
                                    averageCurrentHold = 0;
                                    trackHoldFlag = 0;
                                    
                                    areaCutCurrent = [[AreaCutCurrent alloc] init];
                                    currentConnectNo = [areaCutCurrent circleCut:processType:targetCellStatus:cutOffAdjust]; //------trackHoldFlag 3000, 3002, 3003-------
                                    
                                    do{
                                    } while (subCompletionFlag == 1);
                                    
                                    if (errorNoHold != 0){
                                        errorNoHold = errorNoHold+2000;
                                        throw errorCheckThrow;
                                    }
                                }
                            }
                        }
                        else trackHoldFlag = 3000;
                        
                        if (trackHoldFlag == 3000) trackHoldFlag = 1008;
                    }
                    
                    delete [] arrayReferenceLine;
                }
                
                //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
                //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
                //	cout<<" arrayPositionRevise "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                //	cout<<" arrayTimeSelected "<<counterA+1<<" "<<counter1<<endl;
                //}
                
                //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
                //	cout<<" arrayConnectLineageRel "<<counterA+1<<endl;
                //}
                
                //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
                //	cout<<" arrayGravityCenterRev "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < xyPositionCenterCurrentCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayXYPositionCenterCurrent [counterA*6+counterB];
                //    cout<<" arrayXYPositionCenterCurrent "<<counterA<<endl;
                //}
                
                if (trackHoldFlag == 0 || trackHoldFlag == -2 || trackHoldFlag == -3 || trackHoldFlag == 100){
                    string extension = to_string(imageNumberInt+2);
                    
                    if (extension.length() == 1) extension = "000"+extension;
                    else if (extension.length() == 2) extension = "00"+extension;
                    else if (extension.length() == 3) extension = "0"+extension;
                    
                    string connectDataPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+extension+"_"+analysisImageName+"_"+treatmentNameHold+"_MasterData";
                    
                    if (stat(connectDataPath.c_str(), &sizeOfFile) == -1 || trackingLimit == imageNumberInt+1) trackHoldFlag = 5000;
                    
                    if (trackHoldFlag == 0 || trackHoldFlag == -2 || trackHoldFlag == -3 || trackHoldFlag == 100){
                        processType = 1;
                        trackingDataSave = [[TrackingDataSave alloc] init];
                        [trackingDataSave trackingDataSaveTemp:processType];
                        
                        do{
                        } while(subCompletionFlag == 1);
                        
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                        
                        if (displayDataStatus == 0){
                            errorNoHold = 98;
                            arrayDisplayData = new int [positionReviseCount*3+50];
                            displayDataCount = 0;
                            displayDataStatus = 1;
                            displayDataSizeHold = positionReviseCount*3+50;
                        }
                        else if (displayDataStatus == 1 && displayDataSizeHold < positionReviseCount){
                            delete [] arrayDisplayData;
                            
                            errorNoHold = 99;
                            arrayDisplayData = new int [positionReviseCount*3+50];
                            displayDataCount = 0;
                            displayDataSizeHold = positionReviseCount*3+50;
                        }
                        else displayDataCount = 0;
                        
                        for (int counter1 = 0; counter1 < positionReviseCount; counter1++) arrayDisplayData [displayDataCount] = arrayPositionRevise [counter1], displayDataCount++;
                        
                        if (displayRelStatus == 0){
                            errorNoHold = 100;
                            arrayDisplayRel = new int [connectLineageRelCount*3+50];
                            displayRelCount = 0;
                            displayRelStatus = 1;
                            displayRelSizeHold = connectLineageRelCount*3+50;
                        }
                        else if (displayRelStatus == 1 && displayRelSizeHold < connectLineageRelCount){
                            delete [] arrayDisplayRel;
                            
                            errorNoHold = 101;
                            arrayDisplayRel = new int [connectLineageRelCount*3+50];
                            displayRelCount = 0;
                            displayRelSizeHold = connectLineageRelCount*3+50;
                        }
                        else displayRelCount = 0;
                        
                        for (int counter1 = 0; counter1 < connectLineageRelCount; counter1++) arrayDisplayRel [displayRelCount] = arrayConnectLineageRel [counter1], displayRelCount++;
                        
                        if (displayGravityCenterStatus == 0){
                            errorNoHold = 102;
                            arrayDisplayGravityCenter = new int [gravityCenterRevCount*3+50];
                            displayGravityCenterCount = 0;
                            displayGravityCenterStatus = 1;
                            displayGravityCenterSizeHold = gravityCenterRevCount*3+50;
                        }
                        else if (displayGravityCenterStatus == 1 && displayGravityCenterSizeHold < gravityCenterRevCount){
                            delete [] arrayDisplayGravityCenter;
                            
                            errorNoHold = 103;
                            arrayDisplayGravityCenter = new int [gravityCenterRevCount*3+50];
                            displayGravityCenterCount = 0;
                            displayGravityCenterSizeHold = gravityCenterRevCount*3+50;
                        }
                        else displayGravityCenterCount = 0;
                        
                        for (int counter1 = 0; counter1 < gravityCenterRevCount; counter1++) arrayDisplayGravityCenter [displayGravityCenterCount] = arrayGravityCenterRev [counter1], displayGravityCenterCount++;
                        
                        trackAreaSizeDisplay = trackAreaSize;
                        xTrackingPosition = xGravityCenter;
                        yTrackingPosition = imageDimension-yGravityCenter;
                        
                        xDisplayPosition = horizontalStart;
                        yDisplayPosition = imageDimension-verticalStart;
                        
                        mapPositionPointerHold = mapPositionPointer;
                        verticalPositionHold = verticalStart;
                        
                        int maxPointDimX2 = 0;
                        int maxPointDimY2 = 0;
                        int minPointDimX2 = 1000000;
                        int minPointDimY2 = 1000000;
                        int endPosition = 0;
                        
                        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                            if (arrayTimeSelected [counter1*10+8] == previousConnectNo){
                                if (counter1 == timeSelectedCount/10-1) endPosition = positionReviseCount/7-1;
                                else endPosition = arrayTimeSelected [(counter1+1)*10+2]-1;
                                
                                for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 <= endPosition; counter2++){
                                    if (maxPointDimX2 < arrayPositionRevise [counter2*7]) maxPointDimX2 = arrayPositionRevise [counter2*7];
                                    if (minPointDimX2 > arrayPositionRevise [counter2*7]) minPointDimX2 = arrayPositionRevise [counter2*7];
                                    if (maxPointDimY2 < arrayPositionRevise [counter2*7+1]) maxPointDimY2 = arrayPositionRevise [counter2*7+1];
                                    if (minPointDimY2 > arrayPositionRevise [counter2*7+1]) minPointDimY2 = arrayPositionRevise [counter2*7+1];
                                }
                                
                                break;
                            }
                        }
                        
                        //cout<<xGravityCenter<<" "<<yGravityCenter<<" "<<trackAreaSize<<" Center"<<endl;
                        
                        //for (int counterA = 0; counterA < displayDataCount/7; counterA++){
                        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayDisplayData [counterA*7+counterB];
                        //	cout<<" arrayDisplayData "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < displayRelCount/6; counterA++){
                        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayDisplayRel [counterA*6+counterB];
                        //	cout<<" arrayDisplayRel "<<counterA<<endl;
                        //}
                        
                        // for (int counterA = 0; counterA < displayGravityCenterCount/6; counterA++){
                        //  	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
                        //  	cout<<" arrayGravityCenterRev "<<counterA<<endl;
                        // }
                        
                        for (int counterY = 0; counterY < imageDimension; counterY++){
                            for (int counterX = 0; counterX < imageDimension; counterX++){
                                revisedMap [counterY][counterX] = revisedMapCurrent [counterY][counterX];
                                revisedWorkingMap [counterY][counterX] = revisedMapCurrent [counterY][counterX];
                            }
                        }
                        
                        if (positionReviseStatus == 0){
                            errorNoHold = 104;
                            arrayPositionRevise = new int [positionReviseCurrentCount*3+50];
                            positionReviseCount = 0;
                            positionReviseStatus = 1;
                            positionReviseLimit = positionReviseCurrentCount*3+50;
                            positionReviseSizeHold = positionReviseCurrentCount*3+50;
                        }
                        else if (positionReviseStatus == 1 && positionReviseSizeHold < positionReviseCurrentCount){
                            delete [] arrayPositionRevise;
                            
                            errorNoHold = 105;
                            arrayPositionRevise = new int [positionReviseCurrentCount*3+50];
                            positionReviseCount = 0;
                            positionReviseLimit = positionReviseCurrentCount*3+50;
                            positionReviseSizeHold = positionReviseCurrentCount*3+50;
                        }
                        else positionReviseCount = 0;
                        
                        for (int counter1 = 0; counter1 < positionReviseCurrentCount; counter1++) arrayPositionRevise [positionReviseCount] = arrayPositionReviseCurrent [counter1], positionReviseCount++;
                        
                        if (associatedDataStatus == 0){
                            errorNoHold = 106;
                            arrayAssociatedData = new int [associatedDataCurrCount*3+50];
                            associatedDataCount = 0;
                            associatedDataStatus = 1;
                            associatedDataLimit = associatedDataCurrCount*3+50;
                            associatedDataSizeHold = associatedDataCurrCount*3+50;
                        }
                        else if (associatedDataStatus == 1 && associatedDataSizeHold < associatedDataCurrCount){
                            delete [] arrayAssociatedData;
                            
                            errorNoHold = 107;
                            arrayAssociatedData = new int [associatedDataCurrCount*3+50];
                            associatedDataCount = 0;
                            associatedDataLimit = associatedDataCurrCount*3+50;
                            associatedDataSizeHold = associatedDataCurrCount*3+50;
                        }
                        else associatedDataCount = 0;
                        
                        for (int counter1 = 0; counter1 < associatedDataCurrCount; counter1++) arrayAssociatedData [associatedDataCount] = arrayAssociatedDataCurr [counter1], associatedDataCount++;
                        
                        if (gravityCenterRevStatus == 0){
                            errorNoHold = 108;
                            arrayGravityCenterRev = new int [gravityCenterRevCurrentCount*3+50];
                            gravityCenterRevCount = 0;
                            gravityCenterRevStatus = 1;
                            gravityCenterRevLimit = gravityCenterRevCurrentCount*3+50;
                        }
                        else if (gravityCenterRevStatus == 1 && gravityCenterRevSizeHold < gravityCenterRevCurrentCount){
                            delete [] arrayGravityCenterRev;
                            
                            errorNoHold = 109;
                            arrayGravityCenterRev = new int [gravityCenterRevCurrentCount*3+50];
                            gravityCenterRevCount = 0;
                            gravityCenterRevLimit = gravityCenterRevCurrentCount*3+50;
                            gravityCenterRevSizeHold = gravityCenterRevCurrentCount*3+50;
                        }
                        else gravityCenterRevCount = 0;
                        
                        for (int counter1 = 0; counter1 < gravityCenterRevCurrentCount; counter1++) arrayGravityCenterRev [gravityCenterRevCount] = arrayGravityCenterRevCurrent [counter1], gravityCenterRevCount++;
                        
                        if (timeSelectedStatus == 0){
                            errorNoHold = 110;
                            arrayTimeSelected = new int [timeSelectedCurrentCount*3+50];
                            timeSelectedCount = 0;
                            timeSelectedStatus = 1;
                            timeSelectedLimit = timeSelectedCurrentCount*3+50;
                            timeSelectedSizeHold = timeSelectedCurrentCount*3+50;
                        }
                        else if (timeSelectedStatus == 1 && timeSelectedSizeHold < timeSelectedCurrentCount){
                            delete [] arrayTimeSelected;
                            
                            errorNoHold = 111;
                            arrayTimeSelected = new int [timeSelectedCurrentCount*3+50];
                            timeSelectedCount = 0;
                            timeSelectedLimit = timeSelectedCurrentCount*3+50;
                            timeSelectedSizeHold = timeSelectedCurrentCount*3+50;
                        }
                        else timeSelectedCount = 0;
                        
                        for (int counter1 = 0; counter1 < timeSelectedCurrentCount; counter1++) arrayTimeSelected [timeSelectedCount] = arrayTimeSelectedCurrent [counter1], timeSelectedCount++;
                        
                        if (connectLineageRelStatus == 0){
                            errorNoHold = 112;
                            arrayConnectLineageRel = new int [connectLineageRelCurrentCount*3+50];
                            connectLineageRelCount = 0;
                            connectLineageRelStatus = 1;
                            connectLineageRelLimit = connectLineageRelCurrentCount*3+50;
                            connectLineageRelSizeHold = connectLineageRelCurrentCount*3+50;
                        }
                        else if (connectLineageRelStatus == 1 && connectLineageRelSizeHold < connectLineageRelCurrentCount){
                            delete [] arrayConnectLineageRel;
                            
                            errorNoHold = 113;
                            arrayConnectLineageRel = new int [connectLineageRelCurrentCount*3+50];
                            connectLineageRelCount = 0;
                            connectLineageRelLimit = connectLineageRelCurrentCount*3+50;
                            connectLineageRelSizeHold = connectLineageRelCurrentCount*3+50;
                        }
                        else connectLineageRelCount = 0;
                        
                        for (int counter1 = 0; counter1 < connectLineageRelCurrentCount; counter1++) arrayConnectLineageRel [connectLineageRelCount] = arrayConnectLineageRelCurrent [counter1], connectLineageRelCount++;
                        
                        if (eventSequenceCount+4 > eventSequenceLimit){
                            [self eventSequenceUpDate];
                            if (errorNoHold != 0){
                                errorNoHold = errorNoHold+2000;
                                throw errorCheckThrow;
                            }
                        }
                        
                        arrayEventSequence [eventSequenceCount] = imageNumberInt+1, eventSequenceCount++; //------Image no------
                        arrayEventSequence [eventSequenceCount] = 2, eventSequenceCount++;
                        arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++; //------Lineage no------
                        arrayEventSequence [eventSequenceCount] = cellNumberTempInt, eventSequenceCount++; //------Cell no------
                        
                        gravityCenterXHold1 = gravityCenterXCurrentHold1;
                        gravityCenterYHold1 = gravityCenterYCurrentHold1;
                        gravityAverageHold1 = gravityAverageCurrentHold1;
                        gravityCellNo1 = gravityCellNoCurrent1;
                        
                        if (trackHoldFlag == 100){
                            int firstMitosisFindFlag = 0;
                            int mitosisSetFlag = 0;
                            int mitosisImageNo = 0;
                            
                            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                                if (arrayEventSequence [counter1*4] == statusAdditionalInfo) firstMitosisFindFlag = 1;
                                
                                if (firstMitosisFindFlag == 1){
                                    if (arrayEventSequence [counter1*4+1] == 2){
                                        arrayEventSequence [counter1*4+1] = 6;
                                        mitosisImageNo = arrayEventSequence [counter1*4];
                                        mitosisSetFlag = 1;
                                        break;
                                    }
                                }
                            }
                            
                            if (firstMitosisFindFlag == 1 && mitosisSetFlag == 0) trackHoldFlag = 101;
                            
                            if (trackHoldFlag == 100 && mitosisSetFlag == 1){
                                for (int counter1 = 0; counter1 < mitosisParameterCount/4; counter1++){
                                    if (arrayMitosisParameter [counter1*4+2] < mitosisImageNo) arrayMitosisParameter [counter1*4+3] = 0;
                                    else if (arrayMitosisParameter [counter1*4+2] >= mitosisImageNo) arrayMitosisParameter [counter1*4+3] = 5;
                                }
                            }
                            else if (trackHoldFlag == 101){
                                for (int counter1 = 0; counter1 < mitosisParameterCount/4; counter1++){
                                    if (arrayMitosisParameter [counter1*4+3] == 5) arrayMitosisParameter [counter1*4+3] = 1;
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
                        //    cout<<" arrayEventSequence "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < mitosisParameterCount/4; counterA++){
                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisParameter [counterA*4+counterB];
                        //    cout<<" arrayMitosisParameter "<<counterA<<endl;
                        //}
                        
                        if (trackHoldFlag == -2 || trackHoldFlag == -3){
                            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                                if (arrayEventSequence [counter1*4] == imageNumberInt+1){
                                    if (arrayEventSequence [counter1*4+1] == 2) arrayEventSequence [counter1*4+1] = 10;
                                }
                            }
                        }
                        
                        if (trackHoldFlag == -3){
                            if (fusionPartnerStatus == 0){
                                errorNoHold = 114;
                                arrayFusionPartner = new int [30];
                                fusionPartnerLimit = 30;
                                fusionPartnerCount = 0;
                                fusionPartnerStatus = 1;
                            }
                            else fusionPartnerCount = 0;
                            
                            if (fusionPartnerLimit < fusionPartnerCount+3){
                                errorNoHold = 115;
                                int *arrayUpDate = new int [fusionPartnerCount+10];
                                
                                for (int counter1 = 0; counter1 < fusionPartnerCount; counter1++) arrayUpDate [counter1] = arrayFusionPartner [counter1];
                                
                                delete [] arrayFusionPartner;
                                errorNoHold = 116;
                                arrayFusionPartner = new int [fusionPartnerLimit+30];
                                fusionPartnerLimit = fusionPartnerLimit+30;
                                
                                for (int counter1 = 0; counter1 < fusionPartnerCount; counter1++) arrayFusionPartner [counter1] = arrayUpDate [counter1];
                                delete [] arrayUpDate;
                            }
                            
                            arrayFusionPartner [fusionPartnerCount] = imageNumberInt+1, fusionPartnerCount++;
                            arrayFusionPartner [fusionPartnerCount] = fusionPartnerLine, fusionPartnerCount++;
                            arrayFusionPartner [fusionPartnerCount] = fusionPartnerCellNo, fusionPartnerCount++;
                            
                            //for (int counterA = 0; counterA < fusionPartnerCount/3; counterA++){
                            //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayFusionPartner [counterA*3+counterB];
                            // 	cout<<" arrayFusionPartner "<<counterA<<endl;
                            //}
                        }
                        
                        if (trackHoldFlag != 101){
                            if (exitRequest == 1) firstCommunication = 4;
                            else{
                                
                                int maxPointDimX = 0;
                                int maxPointDimY = 0;
                                int minPointDimX = 1000000;
                                int minPointDimY = 1000000;
                                
                                for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                                    if (arrayTimeSelected [counter1*10+8] == currentConnectNo){
                                        if (counter1 == timeSelectedCount/10-1) endPosition = positionReviseCount/7-1;
                                        else endPosition = arrayTimeSelected [(counter1+1)*10+2]-1;
                                        
                                        for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 <= endPosition; counter2++){
                                            if (maxPointDimX < arrayPositionRevise [counter2*7]) maxPointDimX = arrayPositionRevise [counter2*7];
                                            if (minPointDimX > arrayPositionRevise [counter2*7]) minPointDimX = arrayPositionRevise [counter2*7];
                                            if (maxPointDimY < arrayPositionRevise [counter2*7+1]) maxPointDimY = arrayPositionRevise [counter2*7+1];
                                            if (minPointDimY > arrayPositionRevise [counter2*7+1]) minPointDimY = arrayPositionRevise [counter2*7+1];
                                        }
                                        
                                        break;
                                    }
                                }
                                
                                if (maxPointDimX < maxPointDimX2) maxPointDimX = maxPointDimX2;
                                if (minPointDimX > minPointDimX2) minPointDimX = minPointDimX2;
                                if (maxPointDimY < maxPointDimY2) maxPointDimY = maxPointDimY2;
                                if (minPointDimY > minPointDimY2) minPointDimY = minPointDimY2;
                                
                                //------Determine the dimension of cell------
                                horizontalStart = 0;
                                verticalStart = 0;
                                int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                                int verticalLength = (maxPointDimY-minPointDimY)/2*2;
                                
                                if (horizontalLength >= verticalLength) trackAreaSize = horizontalLength+30;
                                if (horizontalLength < verticalLength) trackAreaSize = verticalLength+30;
                                
                                if (trackAreaSize < 128) trackAreaSize = 128;
                                else trackAreaSize = (trackAreaSize/2)*2;
                                
                                horizontalStart = minPointDimX-(trackAreaSize-horizontalLength)/2;
                                verticalStart = minPointDimY-(trackAreaSize-verticalLength)/2;
                                
                                if (horizontalLength < 0 || verticalLength < 0){
                                    errorNoHold = 2000;
                                    throw errorCheckThrow;
                                }
                                
                                if (sectionMapLoadingStatusPrev == 0){
                                    sectionMapLoadingStatusPrev = 1;
                                    cellTrackingPreviousMapSizeHold = trackAreaSize;
                                    
                                    errorNoHold = 117;
                                    arrayCellTrackingPreviousMap = new int *[trackAreaSize+4];
                                    
                                    for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++){
                                        errorNoHold = 118;
                                        arrayCellTrackingPreviousMap [counter1] = new int [trackAreaSize+4];
                                    }
                                }
                                else if (sectionMapLoadingStatusPrev == 1 && 300 < cellTrackingPreviousMapSizeHold && 300 > trackAreaSize){
                                    for (int counter1 = 0; counter1 < cellTrackingPreviousMapSizeHold+4; counter1++){
                                        delete [] arrayCellTrackingPreviousMap [counter1];
                                    }
                                    
                                    delete [] arrayCellTrackingPreviousMap;
                                    
                                    errorNoHold = 119;
                                    cellTrackingPreviousMapSizeHold = trackAreaSize;
                                    arrayCellTrackingPreviousMap = new int *[trackAreaSize+4];
                                    
                                    for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++){
                                        errorNoHold = 120;
                                        arrayCellTrackingPreviousMap [counter1] = new int [trackAreaSize+4];
                                    }
                                }
                                else if (sectionMapLoadingStatusPrev == 1 && cellTrackingPreviousMapSizeHold < trackAreaSize){
                                    for (int counter1 = 0; counter1 < cellTrackingPreviousMapSizeHold+4; counter1++){
                                        delete [] arrayCellTrackingPreviousMap [counter1];
                                    }
                                    
                                    delete [] arrayCellTrackingPreviousMap;
                                    
                                    cellTrackingPreviousMapSizeHold = trackAreaSize;
                                    
                                    errorNoHold = 121;
                                    arrayCellTrackingPreviousMap = new int *[trackAreaSize+4];
                                    
                                    for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++){
                                        errorNoHold = 122;
                                        arrayCellTrackingPreviousMap [counter1] = new int [trackAreaSize+4];
                                    }
                                }
                                
                                if (sectionMapLoadingStatus == 0){
                                    errorNoHold = 123;
                                    arrayCellTrackingCurrentMap = new int *[trackAreaSize+4];
                                    
                                    for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++){
                                        errorNoHold = 124;
                                        arrayCellTrackingCurrentMap [counter1] = new int [trackAreaSize+4];
                                    }
                                    
                                    sectionMapLoadingStatus = 1;
                                    cellTrackingCurrentMapSizeHold = trackAreaSize;
                                }
                                else if (sectionMapLoadingStatus == 1 && 300 < cellTrackingCurrentMapSizeHold && 300 > trackAreaSize){
                                    for (int counter1 = 0; counter1 < cellTrackingCurrentMapSizeHold+4; counter1++){
                                        delete [] arrayCellTrackingCurrentMap [counter1];
                                    }
                                    
                                    delete [] arrayCellTrackingCurrentMap;
                                    
                                    cellTrackingCurrentMapSizeHold = trackAreaSize;
                                    
                                    errorNoHold = 125;
                                    arrayCellTrackingCurrentMap = new int *[trackAreaSize+4];
                                    
                                    for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++){
                                        errorNoHold = 126;
                                        arrayCellTrackingCurrentMap [counter1] = new int [trackAreaSize+4];
                                    }
                                }
                                else if (sectionMapLoadingStatus == 1 && cellTrackingCurrentMapSizeHold < trackAreaSize){
                                    for (int counter1 = 0; counter1 < cellTrackingCurrentMapSizeHold+4; counter1++){
                                        delete [] arrayCellTrackingCurrentMap [counter1];
                                    }
                                    
                                    delete [] arrayCellTrackingCurrentMap;
                                    
                                    cellTrackingCurrentMapSizeHold = trackAreaSize;
                                    
                                    errorNoHold = 127;
                                    arrayCellTrackingCurrentMap = new int *[trackAreaSize+4];
                                    
                                    for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++){
                                        errorNoHold = 128;
                                        arrayCellTrackingCurrentMap [counter1] = new int [trackAreaSize+4];
                                    }
                                }
                                
                                firstCommunication = 6;
                            }
                            
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSourceImage object:self];
                        }
                        else{
                            
                            processType = 2;
                            trackingDataSave = [[TrackingDataSave alloc] init];
                            [trackingDataSave trackingDataSaveTemp:processType];
                            
                            do{
                            } while (subCompletionFlag == 1);
                            
                            if (errorNoHold != 0){
                                errorNoHold = errorNoHold+2000;
                                throw errorCheckThrow;
                            }
                            
                            if (eventSequenceCount+4 > eventSequenceLimit){
                                [self eventSequenceUpDate];
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                            }
                            
                            arrayEventSequence [eventSequenceCount] = imageNumberInt+1, eventSequenceCount++; //------Image no------
                            arrayEventSequence [eventSequenceCount] = 2, eventSequenceCount++; //------Event type------
                            arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++; //------Lineage no------
                            arrayEventSequence [eventSequenceCount] = cellNumberTempInt, eventSequenceCount++; //------Cell no------
                            
                            returnMessage = "MF";
                            returnMessageTime = extension;
                            returnMessageExt = "0";
                        }
                    }
                    else if (trackHoldFlag == 5000){
                        processType = 1;
                        trackingDataSave = [[TrackingDataSave alloc] init];
                        [trackingDataSave trackingDataSaveTemp:processType];
                        
                        do{
                        } while (subCompletionFlag == 1);
                        
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                        
                        processType = 2;
                        trackingDataSave = [[TrackingDataSave alloc] init];
                        [trackingDataSave trackingDataSaveTemp:processType];
                        
                        do{
                        } while (subCompletionFlag == 1);
                        
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                        
                        if (eventSequenceCount+4 > eventSequenceLimit){
                            [self eventSequenceUpDate];
                            if (errorNoHold != 0){
                                errorNoHold = errorNoHold+2000;
                                throw errorCheckThrow;
                            }
                        }
                        
                        arrayEventSequence [eventSequenceCount] = imageNumberInt+1, eventSequenceCount++; //------Image no------
                        arrayEventSequence [eventSequenceCount] = 2, eventSequenceCount++;
                        arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++; //------Lineage no------
                        arrayEventSequence [eventSequenceCount] = cellNumberTempInt, eventSequenceCount++; //------Cell no------
                        
                        if (trackHoldFlag == 100){
                            int firstMitosisFindFlag = 0;
                            int mitosisSetFlag = 0;
                            int mitosisImageNo = 0;
                            
                            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                                if (arrayEventSequence [counter1*4] == statusAdditionalInfo) firstMitosisFindFlag = 1;
                                
                                if (firstMitosisFindFlag == 1){
                                    if (arrayEventSequence [counter1*4+1] == 2){
                                        arrayEventSequence [counter1*4+1] = 6;
                                        mitosisSetFlag = 1;
                                        mitosisImageNo = arrayEventSequence [counter1*4];
                                        break;
                                    }
                                }
                            }
                            
                            if (firstMitosisFindFlag == 1 && mitosisSetFlag == 0) trackHoldFlag = 101;
                            
                            if (trackHoldFlag == 100 && mitosisSetFlag == 1){
                                for (int counter1 = 0; counter1 < mitosisParameterCount/4; counter1++){
                                    if (arrayMitosisParameter [counter1*4+2] < mitosisImageNo) arrayMitosisParameter [counter1*4+3] = 0;
                                    else if (arrayMitosisParameter [counter1*4+2] >= mitosisImageNo) arrayMitosisParameter [counter1*4+3] = 5;
                                }
                            }
                            else if (trackHoldFlag == 101){
                                for (int counter1 = 0; counter1 < mitosisParameterCount/4; counter1++){
                                    if (arrayMitosisParameter [counter1*4+3] == 5) arrayMitosisParameter [counter1*4+3] = 1;
                                }
                            }
                        }
                        
                        if (trackHoldFlag == -2 || trackHoldFlag == -3){
                            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                                if (arrayEventSequence [counter1*4] == imageNumberInt+1){
                                    if (arrayEventSequence [counter1*4+1] == 2) arrayEventSequence [counter1*4+1] = 10;
                                }
                            }
                        }
                        
                        if (trackHoldFlag == -3){
                            if (fusionPartnerStatus == 0){
                                errorNoHold = 129;
                                arrayFusionPartner = new int [30];
                                fusionPartnerLimit = 30;
                                fusionPartnerCount = 0;
                                fusionPartnerStatus = 1;
                            }
                            else fusionPartnerCount = 0;
                            
                            if (fusionPartnerLimit < fusionPartnerCount+3){
                                errorNoHold = 130;
                                int *arrayUpDate = new int [fusionPartnerCount+10];
                                
                                for (int counter1 = 0; counter1 < fusionPartnerCount; counter1++) arrayUpDate [counter1] = arrayFusionPartner [counter1];
                                
                                delete [] arrayFusionPartner;
                                errorNoHold = 131;
                                arrayFusionPartner = new int [fusionPartnerLimit+30];
                                fusionPartnerLimit = fusionPartnerLimit+30;
                                
                                for (int counter1 = 0; counter1 < fusionPartnerCount; counter1++) arrayFusionPartner [counter1] = arrayUpDate [counter1];
                                delete [] arrayUpDate;
                            }
                            
                            arrayFusionPartner [fusionPartnerCount] = imageNumberInt+1, fusionPartnerCount++;
                            arrayFusionPartner [fusionPartnerCount] = fusionPartnerLine, fusionPartnerCount++;
                            arrayFusionPartner [fusionPartnerCount] = fusionPartnerCellNo, fusionPartnerCount++;
                        }
                        
                        if (trackHoldFlag != 101){
                            returnMessage = "NX";
                            returnMessageTime = to_string(imageNumberInt+1);
                            returnMessageExt = "0";
                            firstCommunication = 4;
                        }
                        else{
                            
                            returnMessage = "NM";
                            returnMessageTime = to_string(imageNumberInt+1);
                            returnMessageExt = "0";
                            firstCommunication = 4;
                        }
                    }
                }
            }
            
            sleepingPosition = 38;
            
            if (trackHoldFlag == 2 || trackHoldFlag == 3 || trackHoldFlag == 4 || trackHoldFlag == 5){
                processType = 1;
                trackingDataSave = [[TrackingDataSave alloc] init];
                [trackingDataSave trackingDataSaveTemp:processType];
                
                do{
                } while (subCompletionFlag == 1);
                
                if (errorNoHold != 0){
                    errorNoHold = errorNoHold+2000;
                    throw errorCheckThrow;
                }
                
                //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
                //    cout<<" arrayEventSequence "<<counterA<<endl;
                //}
                
                int divisionSetFlag = 0;
                
                for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                    if (arrayEventSequence [counter1*4] == imageNumberInt){
                        if (arrayEventSequence [counter1*4+1] == 2){
                            divisionSetFlag = 1;
                            
                            break;
                        }
                        else if (roundStatus-2 > 1){
                            if (arrayEventSequence [counter1*4+1] == 6){
                                for (int counter2 = 0; counter2 < eventSequenceCount/4; counter2++){
                                    if (arrayEventSequence [counter2*4] == imageNumberInt-1){
                                        if (arrayEventSequence [counter2*4+1] == 2){
                                            arrayEventSequence [counter2*4+1] = 6;
                                            arrayEventSequence [counter1*4+1] = 2;
                                            divisionSetFlag = 1;
                                        }
                                        else trackHoldFlag = 60;
                                    }
                                }
                            }
                            else trackHoldFlag = 60;
                        }
                        else trackHoldFlag = 60;
                    }
                }
                
                if (divisionSetFlag == 1 && (trackHoldFlag == 2 || trackHoldFlag == 3 || trackHoldFlag == 4)){
                    int entryCount = 0;
                    int divisionConnectInfo [4] = {0,0,0,0};
                    
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (arrayCellTrackingTable [counter1*15] == roundStatus && arrayCellTrackingTable [counter1*15+7] == 1) divisionConnectInfo [entryCount] = arrayCellTrackingTable [counter1*15+2], entryCount++;
                    }
                    
                    int newCellNumber1 = 0;
                    int newCellNumber2 = 0;
                    int newCellNumber3 = 0;
                    int newCellNumber4 = 0;
                    
                    if (trackHoldFlag == 2){
                        newCellNumber1 = [self primaryAddition];
                        newCellNumber2 = [self primarySubt];
                        
                        string extension1 = to_string(newCellNumber1);
                        extension2 = to_string(newCellNumber2);
                        
                        if (newCellNumber1 >= 0){
                            if (extension1.length() == 1) extension1 = "C00000000"+extension1;
                            else if (extension1.length() == 2) extension1 = "C0000000"+extension1;
                            else if (extension1.length() == 3) extension1 = "C000000"+extension1;
                            else if (extension1.length() == 4) extension1 = "C00000"+extension1;
                            else if (extension1.length() == 5) extension1 = "C0000"+extension1;
                            else if (extension1.length() == 6) extension1 = "C000"+extension1;
                            else if (extension1.length() == 7) extension1 = "C00"+extension1;
                            else if (extension1.length() == 8) extension1 = "C0"+extension1;
                            else if (extension1.length() == 9) extension1 = "C"+extension1;
                        }
                        else if (newCellNumber1 < 0){
                            extension1 = extension1.substr(1);
                            if (extension1.length() == 1) extension1 = "C-00000000"+extension1;
                            else if (extension1.length() == 2) extension1 = "C-0000000"+extension1;
                            else if (extension1.length() == 3) extension1 = "C-000000"+extension1;
                            else if (extension1.length() == 4) extension1 = "C-00000"+extension1;
                            else if (extension1.length() == 5) extension1 = "C-0000"+extension1;
                            else if (extension1.length() == 6) extension1 = "C-000"+extension1;
                            else if (extension1.length() == 7) extension1 = "C-00"+extension1;
                            else if (extension1.length() == 8) extension1 = "C-0"+extension1;
                            else if (extension1.length() == 9) extension1 = "C-"+extension1;
                        }
                        
                        if (newCellNumber2 >= 0){
                            if (extension2.length() == 1) extension2 = "C00000000"+extension2;
                            else if (extension2.length() == 2) extension2 = "C0000000"+extension2;
                            else if (extension2.length() == 3) extension2 = "C000000"+extension2;
                            else if (extension2.length() == 4) extension2 = "C00000"+extension2;
                            else if (extension2.length() == 5) extension2 = "C0000"+extension2;
                            else if (extension2.length() == 6) extension2 = "C000"+extension2;
                            else if (extension2.length() == 7) extension2 = "C00"+extension2;
                            else if (extension2.length() == 8) extension2 = "C0"+extension2;
                            else if (extension2.length() == 9) extension2 = "C"+extension2;
                        }
                        else if (newCellNumber2 < 0){
                            extension2 = extension2.substr(1);
                            if (extension2.length() == 1) extension2 = "C-00000000"+extension2;
                            else if (extension2.length() == 2) extension2 = "C-0000000"+extension2;
                            else if (extension2.length() == 3) extension2 = "C-000000"+extension2;
                            else if (extension2.length() == 4) extension2 = "C-00000"+extension2;
                            else if (extension2.length() == 5) extension2 = "C-0000"+extension2;
                            else if (extension2.length() == 6) extension2 = "C-000"+extension2;
                            else if (extension2.length() == 7) extension2 = "C-00"+extension2;
                            else if (extension2.length() == 8) extension2 = "C-0"+extension2;
                            else if (extension2.length() == 9) extension2 = "C-"+extension2;
                        }
                        
                        cellNoHoldDiv1 = extension1;
                        cellNoHoldDiv2 = extension2;
                    }
                    else if (trackHoldFlag == 3){
                        newCellNumber1 = [self primaryAddition];
                        newCellNumber2 = [self primarySubt];
                        newCellNumber3 = [self secondaryAddition];
                        
                        string extension1 = to_string(newCellNumber1);
                        extension2 = to_string(newCellNumber2);
                        string extension3 = to_string(newCellNumber3);
                        
                        if (newCellNumber1 >= 0){
                            if (extension1.length() == 1) extension1 = "C00000000"+extension1;
                            else if (extension1.length() == 2) extension1 = "C0000000"+extension1;
                            else if (extension1.length() == 3) extension1 = "C000000"+extension1;
                            else if (extension1.length() == 4) extension1 = "C00000"+extension1;
                            else if (extension1.length() == 5) extension1 = "C0000"+extension1;
                            else if (extension1.length() == 6) extension1 = "C000"+extension1;
                            else if (extension1.length() == 7) extension1 = "C00"+extension1;
                            else if (extension1.length() == 8) extension1 = "C0"+extension1;
                            else if (extension1.length() == 9) extension1 = "C"+extension1;
                        }
                        else if (newCellNumber1 < 0){
                            extension1 = extension1.substr(1);
                            if (extension1.length() == 1) extension1 = "C-00000000"+extension1;
                            else if (extension1.length() == 2) extension1 = "C-0000000"+extension1;
                            else if (extension1.length() == 3) extension1 = "C-000000"+extension1;
                            else if (extension1.length() == 4) extension1 = "C-00000"+extension1;
                            else if (extension1.length() == 5) extension1 = "C-0000"+extension1;
                            else if (extension1.length() == 6) extension1 = "C-000"+extension1;
                            else if (extension1.length() == 7) extension1 = "C-00"+extension1;
                            else if (extension1.length() == 8) extension1 = "C-0"+extension1;
                            else if (extension1.length() == 9) extension1 = "C-"+extension1;
                        }
                        
                        if (newCellNumber2 >= 0){
                            if (extension2.length() == 1) extension2 = "C00000000"+extension2;
                            else if (extension2.length() == 2) extension2 = "C0000000"+extension2;
                            else if (extension2.length() == 3) extension2 = "C000000"+extension2;
                            else if (extension2.length() == 4) extension2 = "C00000"+extension2;
                            else if (extension2.length() == 5) extension2 = "C0000"+extension2;
                            else if (extension2.length() == 6) extension2 = "C000"+extension2;
                            else if (extension2.length() == 7) extension2 = "C00"+extension2;
                            else if (extension2.length() == 8) extension2 = "C0"+extension2;
                            else if (extension2.length() == 9) extension2 = "C"+extension2;
                        }
                        else if (newCellNumber2 < 0){
                            extension2 = extension2.substr(1);
                            if (extension2.length() == 1) extension2 = "C-00000000"+extension2;
                            else if (extension2.length() == 2) extension2 = "C-0000000"+extension2;
                            else if (extension2.length() == 3) extension2 = "C-000000"+extension2;
                            else if (extension2.length() == 4) extension2 = "C-00000"+extension2;
                            else if (extension2.length() == 5) extension2 = "C-0000"+extension2;
                            else if (extension2.length() == 6) extension2 = "C-000"+extension2;
                            else if (extension2.length() == 7) extension2 = "C-00"+extension2;
                            else if (extension2.length() == 8) extension2 = "C-0"+extension2;
                            else if (extension2.length() == 9) extension2 = "C-"+extension2;
                        }
                        
                        if (newCellNumber3 >= 0){
                            if (extension3.length() == 1) extension3 = "C00000000"+extension3;
                            else if (extension3.length() == 2) extension3 = "C0000000"+extension3;
                            else if (extension3.length() == 3) extension3 = "C000000"+extension3;
                            else if (extension3.length() == 4) extension3 = "C00000"+extension3;
                            else if (extension3.length() == 5) extension3 = "C0000"+extension3;
                            else if (extension3.length() == 6) extension3 = "C000"+extension3;
                            else if (extension3.length() == 7) extension3 = "C00"+extension3;
                            else if (extension3.length() == 8) extension3 = "C0"+extension3;
                            else if (extension3.length() == 9) extension3 = "C"+extension3;
                        }
                        else if (newCellNumber3 < 0){
                            extension3 = extension3.substr(1);
                            if (extension3.length() == 1) extension3 = "C-00000000"+extension3;
                            else if (extension3.length() == 2) extension3 = "C-0000000"+extension3;
                            else if (extension3.length() == 3) extension3 = "C-000000"+extension3;
                            else if (extension3.length() == 4) extension3 = "C-00000"+extension3;
                            else if (extension3.length() == 5) extension3 = "C-0000"+extension3;
                            else if (extension3.length() == 6) extension3 = "C-000"+extension3;
                            else if (extension3.length() == 7) extension3 = "C-00"+extension3;
                            else if (extension3.length() == 8) extension3 = "C-0"+extension3;
                            else if (extension3.length() == 9) extension3 = "C-"+extension3;
                        }
                        
                        cellNoHoldDiv1 = extension1;
                        cellNoHoldDiv2 = extension2;
                        cellNoHoldDiv3 = extension3;
                    }
                    else if (trackHoldFlag == 4){
                        newCellNumber1 = [self primaryAddition];
                        newCellNumber2 = [self primarySubt];
                        newCellNumber3 = [self secondaryAddition];
                        newCellNumber4 = [self secondarySubt];
                        
                        string extension1 = to_string(newCellNumber1);
                        extension2 = to_string(newCellNumber2);
                        string extension3 = to_string(newCellNumber3);
                        string extension4 = to_string(newCellNumber4);
                        
                        if (newCellNumber1 >= 0){
                            if (extension1.length() == 1) extension1 = "C00000000"+extension1;
                            else if (extension1.length() == 2) extension1 = "C0000000"+extension1;
                            else if (extension1.length() == 3) extension1 = "C000000"+extension1;
                            else if (extension1.length() == 4) extension1 = "C00000"+extension1;
                            else if (extension1.length() == 5) extension1 = "C0000"+extension1;
                            else if (extension1.length() == 6) extension1 = "C000"+extension1;
                            else if (extension1.length() == 7) extension1 = "C00"+extension1;
                            else if (extension1.length() == 8) extension1 = "C0"+extension1;
                            else if (extension1.length() == 9) extension1 = "C"+extension1;
                        }
                        else if (newCellNumber1 < 0){
                            extension1 = extension1.substr(1);
                            if (extension1.length() == 1) extension1 = "C-00000000"+extension1;
                            else if (extension1.length() == 2) extension1 = "C-0000000"+extension1;
                            else if (extension1.length() == 3) extension1 = "C-000000"+extension1;
                            else if (extension1.length() == 4) extension1 = "C-00000"+extension1;
                            else if (extension1.length() == 5) extension1 = "C-0000"+extension1;
                            else if (extension1.length() == 6) extension1 = "C-000"+extension1;
                            else if (extension1.length() == 7) extension1 = "C-00"+extension1;
                            else if (extension1.length() == 8) extension1 = "C-0"+extension1;
                            else if (extension1.length() == 9) extension1 = "C-"+extension1;
                        }
                        
                        if (newCellNumber2 >= 0){
                            if (extension2.length() == 1) extension2 = "C00000000"+extension2;
                            else if (extension2.length() == 2) extension2 = "C0000000"+extension2;
                            else if (extension2.length() == 3) extension2 = "C000000"+extension2;
                            else if (extension2.length() == 4) extension2 = "C00000"+extension2;
                            else if (extension2.length() == 5) extension2 = "C0000"+extension2;
                            else if (extension2.length() == 6) extension2 = "C000"+extension2;
                            else if (extension2.length() == 7) extension2 = "C00"+extension2;
                            else if (extension2.length() == 8) extension2 = "C0"+extension2;
                            else if (extension2.length() == 9) extension2 = "C"+extension2;
                        }
                        else if (newCellNumber2 < 0){
                            extension2 = extension2.substr(1);
                            if (extension2.length() == 1) extension2 = "C-00000000"+extension2;
                            else if (extension2.length() == 2) extension2 = "C-0000000"+extension2;
                            else if (extension2.length() == 3) extension2 = "C-000000"+extension2;
                            else if (extension2.length() == 4) extension2 = "C-00000"+extension2;
                            else if (extension2.length() == 5) extension2 = "C-0000"+extension2;
                            else if (extension2.length() == 6) extension2 = "C-000"+extension2;
                            else if (extension2.length() == 7) extension2 = "C-00"+extension2;
                            else if (extension2.length() == 8) extension2 = "C-0"+extension2;
                            else if (extension2.length() == 9) extension2 = "C-"+extension2;
                        }
                        
                        if (newCellNumber3 >= 0){
                            if (extension3.length() == 1) extension3 = "C00000000"+extension3;
                            else if (extension3.length() == 2) extension3 = "C0000000"+extension3;
                            else if (extension3.length() == 3) extension3 = "C000000"+extension3;
                            else if (extension3.length() == 4) extension3 = "C00000"+extension3;
                            else if (extension3.length() == 5) extension3 = "C0000"+extension3;
                            else if (extension3.length() == 6) extension3 = "C000"+extension3;
                            else if (extension3.length() == 7) extension3 = "C00"+extension3;
                            else if (extension3.length() == 8) extension3 = "C0"+extension3;
                            else if (extension3.length() == 9) extension3 = "C"+extension3;
                        }
                        else if (newCellNumber3 < 0){
                            extension3 = extension3.substr(1);
                            if (extension3.length() == 1) extension3 = "C-00000000"+extension3;
                            else if (extension3.length() == 2) extension3 = "C-0000000"+extension3;
                            else if (extension3.length() == 3) extension3 = "C-000000"+extension3;
                            else if (extension3.length() == 4) extension3 = "C-00000"+extension3;
                            else if (extension3.length() == 5) extension3 = "C-0000"+extension3;
                            else if (extension3.length() == 6) extension3 = "C-000"+extension3;
                            else if (extension3.length() == 7) extension3 = "C-00"+extension3;
                            else if (extension3.length() == 8) extension3 = "C-0"+extension3;
                            else if (extension3.length() == 9) extension3 = "C-"+extension3;
                        }
                        
                        if (newCellNumber4 >= 0){
                            if (extension4.length() == 1) extension4 = "C00000000"+extension4;
                            else if (extension4.length() == 2) extension4 = "C0000000"+extension4;
                            else if (extension4.length() == 3) extension4 = "C000000"+extension4;
                            else if (extension4.length() == 4) extension4 = "C00000"+extension4;
                            else if (extension4.length() == 5) extension4 = "C0000"+extension4;
                            else if (extension4.length() == 6) extension4 = "C000"+extension4;
                            else if (extension4.length() == 7) extension4 = "C00"+extension4;
                            else if (extension4.length() == 8) extension4 = "C0"+extension4;
                            else if (extension4.length() == 9) extension4 = "C"+extension4;
                        }
                        else if (newCellNumber4 < 0){
                            extension4 = extension4.substr(1);
                            if (extension4.length() == 1) extension4 = "C-00000000"+extension4;
                            else if (extension4.length() == 2) extension4 = "C-0000000"+extension4;
                            else if (extension4.length() == 3) extension4 = "C-000000"+extension4;
                            else if (extension4.length() == 4) extension4 = "C-00000"+extension4;
                            else if (extension4.length() == 5) extension4 = "C-0000"+extension4;
                            else if (extension4.length() == 6) extension4 = "C-000"+extension4;
                            else if (extension4.length() == 7) extension4 = "C-00"+extension4;
                            else if (extension4.length() == 8) extension4 = "C-0"+extension4;
                            else if (extension4.length() == 9) extension4 = "C-"+extension4;
                        }
                        
                        cellNoHoldDiv1 = extension1;
                        cellNoHoldDiv2 = extension2;
                        cellNoHoldDiv3 = extension3;
                        cellNoHoldDiv4 = extension4;
                    }
                    
                    int cellEntryNo = 0;
                    string cellNoHoldOriginal = cellNoHold;
                    
                    gravityCenterXCurrentHold1 = 0;
                    gravityCenterYCurrentHold1 = 0;
                    gravityAverageCurrentHold1 = 0;
                    gravityCellNoCurrent1 = 0;
                    gravityCenterXCurrentHold2 = 0;
                    gravityCenterYCurrentHold2 = 0;
                    gravityAverageCurrentHold2 = 0;
                    gravityCellNoCurrent2 = 0;
                    gravityCenterXCurrentHold3 = 0;
                    gravityCenterYCurrentHold3 = 0;
                    gravityAverageCurrentHold3 = 0;
                    gravityCellNoCurrent3 = 0;
                    gravityCenterXCurrentHold4 = 0;
                    gravityCenterYCurrentHold4 = 0;
                    gravityAverageCurrentHold4 = 0;
                    gravityCellNoCurrent4 = 0;
                    
                    int trackingHoldFlagTemp = trackHoldFlag;
                    
                    for (int counter1 = 0; counter1 < trackingHoldFlagTemp; counter1++){
                        if (counter1 == 0) cellNoHold = cellNoHoldDiv1;
                        else if (counter1 == 1) cellNoHold = cellNoHoldDiv2;
                        else if (counter1 == 2) cellNoHold = cellNoHoldDiv3;
                        else if (counter1 == 3) cellNoHold = cellNoHoldDiv4;
                        
                        errorNoHold = 132;
                        arrayReferenceLine = new int [cellTrackingCurrentCount+50];
                        referenceLineCount = 0;
                        referenceLineLimit = cellTrackingCurrentCount+50;
                        
                        for (int counter2 = 0; counter2 < cellTrackingCurrentCount/6; counter2++){
                            if (arrayCellTrackingCurrent [counter2*6+3] == divisionConnectInfo [counter1]){
                                if (referenceLineCount+2 > referenceLineLimit) [self referenceLineCountUpDate];
                                
                                arrayReferenceLine [referenceLineCount] = arrayCellTrackingCurrent [counter2*6], referenceLineCount++;
                                arrayReferenceLine [referenceLineCount] = arrayCellTrackingCurrent [counter2*6+1], referenceLineCount++;
                            }
                        }
                        
                        // for (int counterA = 0; counterA < referenceLineCount/2; counterA++){
                        //  	for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<arrayReferenceLine [counterA*2+counterB];
                        //  	cout<<" arrayReferenceLine "<<counterA<<endl;
                        // }
                        
                        gravityCenterEntryType = counter1+1;
                        processType = 2;
                        int targetStatus = 2000;
                        int cutOffAdjust = -1;
                        
                        areaCutCurrent = [[AreaCutCurrent alloc] init];
                        [areaCutCurrent circleCut:processType:targetStatus:cutOffAdjust];
                        
                        do{
                        } while (subCompletionFlag == 1);
                        
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                        
                        delete [] arrayReferenceLine;
                        
                        if (trackHoldFlag != 3000) cellEntryNo++;
                    }
                    
                    cellNoHold = cellNoHoldOriginal;
                    
                    if (cellEntryNo > 1){
                        processType = 2;
                        trackingDataSave = [[TrackingDataSave alloc] init];
                        [trackingDataSave trackingDataSaveTemp:processType];
                        
                        do{
                        } while (subCompletionFlag == 1);
                        
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                        
                        string extension = to_string(imageNumberInt+1);
                        
                        if (cellEntryNo == 2){
                            if (eventSequenceCount+8 > eventSequenceLimit){
                                [self eventSequenceUpDate];
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                            }
                            
                            arrayEventSequence [eventSequenceCount] = imageNumberInt+1, eventSequenceCount++; //------Image no------
                            arrayEventSequence [eventSequenceCount] = 32, eventSequenceCount++; //------Event type------
                            arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++; //------Lineage no------
                            arrayEventSequence [eventSequenceCount] = newCellNumber1, eventSequenceCount++; //------Cell no------
                            
                            arrayEventSequence [eventSequenceCount] = imageNumberInt+1, eventSequenceCount++; //------Image no------
                            arrayEventSequence [eventSequenceCount] = 33, eventSequenceCount++; //------Event type------
                            arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++; //------Lineage no------
                            arrayEventSequence [eventSequenceCount] = newCellNumber2, eventSequenceCount++; //------Cell no------
                            
                            returnMessage = "BD";
                            returnMessageTime = extension;
                            returnMessageExt = "0";
                        }
                        else if (cellEntryNo == 3){
                            if (eventSequenceCount+12 > eventSequenceLimit){
                                [self eventSequenceUpDate];
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                            }
                            
                            arrayEventSequence [eventSequenceCount] = imageNumberInt+1, eventSequenceCount++; //------Image no------
                            arrayEventSequence [eventSequenceCount] = 42, eventSequenceCount++; //------Event type------
                            arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++; //------Lineage no------
                            arrayEventSequence [eventSequenceCount] = newCellNumber1, eventSequenceCount++; //------Cell no------
                            
                            arrayEventSequence [eventSequenceCount] = imageNumberInt+1, eventSequenceCount++; //------Image no------
                            arrayEventSequence [eventSequenceCount] = 43, eventSequenceCount++; //------Event type------
                            arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++; //------Lineage no------
                            arrayEventSequence [eventSequenceCount] = newCellNumber2, eventSequenceCount++; //------Cell no------
                            
                            arrayEventSequence [eventSequenceCount] = imageNumberInt+1, eventSequenceCount++; //------Image no------
                            arrayEventSequence [eventSequenceCount] = 44, eventSequenceCount++; //------Event type------
                            arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++; //------Lineage no------
                            arrayEventSequence [eventSequenceCount] = newCellNumber3, eventSequenceCount++; //------Cell no------
                            
                            returnMessage = "TD";
                            returnMessageTime = extension;
                            returnMessageExt = "0";
                        }
                        else if (cellEntryNo == 4){
                            if (eventSequenceCount+16 > eventSequenceLimit){
                                [self eventSequenceUpDate];
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                            }
                            
                            arrayEventSequence [eventSequenceCount] = imageNumberInt+1, eventSequenceCount++; //------Image no------
                            arrayEventSequence [eventSequenceCount] = 52, eventSequenceCount++; //------Event type------
                            arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++; //------Lineage no------
                            arrayEventSequence [eventSequenceCount] = newCellNumber1, eventSequenceCount++; //------Cell no------
                            
                            arrayEventSequence [eventSequenceCount] = imageNumberInt+1, eventSequenceCount++; //------Image no------
                            arrayEventSequence [eventSequenceCount] = 53, eventSequenceCount++; //------Event type------
                            arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++; //------Lineage no------
                            arrayEventSequence [eventSequenceCount] = newCellNumber2, eventSequenceCount++; //------Cell no------
                            
                            arrayEventSequence [eventSequenceCount] = imageNumberInt+1, eventSequenceCount++; //------Image no------
                            arrayEventSequence [eventSequenceCount] = 54, eventSequenceCount++; //------Event type------
                            arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++; //------Lineage no------
                            arrayEventSequence [eventSequenceCount] = newCellNumber3, eventSequenceCount++; //------Cell no------
                            
                            arrayEventSequence [eventSequenceCount] = imageNumberInt+1, eventSequenceCount++; //------Image no------
                            arrayEventSequence [eventSequenceCount] = 55, eventSequenceCount++; //------Event type------
                            arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++; //------Lineage no------
                            arrayEventSequence [eventSequenceCount] = newCellNumber4, eventSequenceCount++; //------Cell no------
                            
                            returnMessage = "HD";
                            returnMessageTime = extension;
                            returnMessageExt = "0";
                        }
                        
                        //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
                        //    cout<<" arrayEventSequence "<<counterA<<endl;
                        //}
                        
                        firstCommunication = 4;
                    }
                    else{
                        
                        returnMessage = "DL";
                        returnMessageTime = to_string(imageNumberInt);
                        returnMessageExt = "0";
                        
                        firstCommunication = 4;
                    }
                }
                else{
                    
                    if (divisionSetFlag == 0){
                        returnMessage = "NS";
                        returnMessageTime = to_string(imageNumberInt);
                        returnMessageExt = "0";
                        
                        firstCommunication = 4;
                    }
                    else{
                        
                        returnMessage = "MD";
                        returnMessageTime = to_string(imageNumberInt);
                        returnMessageExt = "0";
                        
                        firstCommunication = 4;
                    }
                }
            }
            
            sleepingPosition = 39;
            
            if (trackHoldFlag == 10 || trackHoldFlag == 1000 || trackHoldFlag == 1001 || trackHoldFlag == 1002 || trackHoldFlag == 1003 || trackHoldFlag == 1004 || trackHoldFlag == 1005){
                processType = 1;
                trackingDataSave = [[TrackingDataSave alloc] init];
                [trackingDataSave trackingDataSaveTemp:processType];
                
                do{
                } while (subCompletionFlag == 1);
                
                if (errorNoHold != 0){
                    errorNoHold = errorNoHold+2000;
                    throw errorCheckThrow;
                }
                
                int targetConnectNo = 0;
                
                for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                    if (arrayCellTrackingTable [counter1*15] == roundStatus && arrayCellTrackingTable [counter1*15+7] == 1){
                        targetConnectNo = arrayCellTrackingTable [counter1*15+2];
                        break;
                    }
                }
                
                //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
                //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
                //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < cellTrackingPreviousCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayCellTrackingPrevious [counterA*6+counterB];
                //	cout<<" arrayCellTrackingPrevious "<<counterA<<endl;
                //}
                
                errorNoHold = 133;
                arrayReferenceLine = new int [cellTrackingCurrentCount+50];
                referenceLineCount = 0;
                referenceLineLimit = cellTrackingCurrentCount+50;
                
                for (int counter1 = 0; counter1 < cellTrackingCurrentCount/6; counter1++){
                    if (arrayCellTrackingCurrent [counter1*6+3] == targetConnectNo){
                        if (referenceLineCount+2 > referenceLineLimit){
                            [self referenceLineCountUpDate];
                            if (errorNoHold != 0){
                                errorNoHold = errorNoHold+2000;
                                throw errorCheckThrow;
                            }
                        }
                        
                        arrayReferenceLine [referenceLineCount] = arrayCellTrackingCurrent [counter1*6], referenceLineCount++;
                        arrayReferenceLine [referenceLineCount] = arrayCellTrackingCurrent [counter1*6+1], referenceLineCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < referenceLineCount/2; counterA++){
                //	for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<arrayReferenceLine [counterA*2+counterB];
                //	cout<<" arrayReferenceLine "<<counterA<<endl;
                //}
                
                targetCellStatus = 0;
                
                if (roundStatus != 2){
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (arrayCellTrackingTable [counter1*15] == roundStatus-1 && arrayCellTrackingTable [counter1*15+7] == 1){
                            if (arrayCellTrackingTable [counter1*15+14] == 2000) targetCellStatus = 2000;
                            else if (arrayCellTrackingTable [counter1*15+14] > 1000) targetCellStatus = arrayCellTrackingTable [counter1*15+14];
                            else targetCellStatus = arrayCellTrackingTable [counter1*15+14];
                        }
                    }
                }
                else{
                    
                    int connectNoTemp = 0;
                    
                    for (int counter1 = 0; counter1 < connectLineageRelCurrentCount/6; counter1++){
                        if (arrayConnectLineageRelCurrent [counter1*6] == cellLineageTempInt && arrayConnectLineageRelCurrent [counter1*6+3] == cellNumberTempInt){
                            connectNoTemp = arrayConnectLineageRelCurrent [counter1*6+1];
                            break;
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < timeSelectedCurrentCount/10; counter1++){
                        if (arrayTimeSelectedCurrent [counter1*10+8] == connectNoTemp){
                            if (arrayTimeSelectedCurrent [counter1*10] == 1) targetCellStatus = 1000;
                            else if (arrayTimeSelectedCurrent [counter1*10] == 7) targetCellStatus = 2000;
                            
                            break;
                        }
                    }
                }
                
                processType = 2; //------1: fusion, 2: non-fusion-------
                
                gravityCenterEntryType = 1;
                gravityCenterXCurrentHold1 = 0;
                gravityCenterYCurrentHold1 = 0;
                gravityAverageCurrentHold1 = 0;
                gravityCellNoCurrent1 = 0;
                gravityCenterXCurrentHold2 = 0;
                gravityCenterYCurrentHold2 = 0;
                gravityAverageCurrentHold2 = 0;
                gravityCellNoCurrent2 = 0;
                gravityCenterXCurrentHold3 = 0;
                gravityCenterYCurrentHold3 = 0;
                gravityAverageCurrentHold3 = 0;
                gravityCellNoCurrent3 = 0;
                gravityCenterXCurrentHold4 = 0;
                gravityCenterYCurrentHold4 = 0;
                gravityAverageCurrentHold4 = 0;
                gravityCellNoCurrent4 = 0;
                
                int cutOffAdjust = -1;
                
                areaCutCurrent = [[AreaCutCurrent alloc] init];
                [areaCutCurrent circleCut:processType:targetCellStatus:cutOffAdjust]; //------trackHoldFlag 3000, 3002, 3003-------
                
                do{
                } while (subCompletionFlag == 1);
                
                if (errorNoHold != 0){
                    errorNoHold = errorNoHold+2000;
                    throw errorCheckThrow;
                }
                
                delete [] arrayReferenceLine;
                
                trackingDataSave = [[TrackingDataSave alloc] init];
                [trackingDataSave trackingDataSaveTemp:processType];
                
                do{
                } while (subCompletionFlag == 1);
                
                if (errorNoHold != 0){
                    errorNoHold = errorNoHold+2000;
                    throw errorCheckThrow;
                }
                
                string extension = to_string(imageNumberInt+1);
                
                if (trackHoldFlag == 10){
                    //------CD last point: detection+2--------
                    
                    int firstMitosisForCD = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (arrayCellTrackingTable [counter1*15+9] == 10){
                            firstMitosisForCD = arrayCellTrackingTable [counter1*15];
                            break;
                        }
                    }
                    
                    if (eventSequenceCount+4 > eventSequenceLimit){
                        [self eventSequenceUpDate];
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                    }
                    
                    arrayEventSequence [eventSequenceCount] = imageNumberInt+1, eventSequenceCount++; //------Image no------
                    arrayEventSequence [eventSequenceCount] = 2, eventSequenceCount++; //------Event type------
                    arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++; //------Lineage no------
                    arrayEventSequence [eventSequenceCount] = cellNumberTempInt, eventSequenceCount++; //------Cell no------
                    
                    if (arrayEventSequence [(firstMitosisForCD+1)*4+1] == 2) arrayEventSequence [(firstMitosisForCD+1)*4+1] = 7;
                    else arrayEventSequence [(firstMitosisForCD+2)*4+1] = 7;
                    
                    returnMessage = "CD";
                    returnMessageTime = extension;
                    returnMessageExt = "0";
                    
                    //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
                    //    cout<<" arrayEventSequence "<<counterA<<endl;
                    //}
                }
                else if (trackHoldFlag == 1000){
                    int firstMitosisForIP = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (arrayCellTrackingTable [counter1*15+9] == 1000){
                            firstMitosisForIP = arrayCellTrackingTable [counter1*15];
                            break;
                        }
                    }
                    
                    if (eventSequenceCount+4 > eventSequenceLimit){
                        [self eventSequenceUpDate];
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                    }
                    
                    arrayEventSequence [eventSequenceCount] = imageNumberInt+1, eventSequenceCount++; //------Image no------
                    arrayEventSequence [eventSequenceCount] = 2, eventSequenceCount++; //------Event type------
                    arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++; //------Lineage no------
                    arrayEventSequence [eventSequenceCount] = cellNumberTempInt, eventSequenceCount++; //------Cell no------
                    
                    arrayEventSequence [(firstMitosisForIP-1)*4+1] = 6;
                    
                    returnMessage = "IP";
                    returnMessageTime = extension;
                    returnMessageExt = "0";
                }
                else if (trackHoldFlag == 1001){
                    if (eventSequenceCount+4 > eventSequenceLimit){
                        [self eventSequenceUpDate];
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                    }
                    
                    arrayEventSequence [eventSequenceCount] = imageNumberInt+1, eventSequenceCount++; //------Image no------
                    arrayEventSequence [eventSequenceCount] = 2, eventSequenceCount++; //------Event type------
                    arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++; //------Lineage no------
                    arrayEventSequence [eventSequenceCount] = cellNumberTempInt, eventSequenceCount++; //------Cell no------
                    
                    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                        if (arrayEventSequence [counter1*4+1] == 6){
                            arrayEventSequence [(counter1+1)*4+1] = 2;
                            break;
                        }
                    }
                    
                    returnMessage = "MC";
                    returnMessageTime = extension;
                    returnMessageExt = "0";
                }
                else if (trackHoldFlag == 1002){
                    int firstMitosisForMD = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (arrayCellTrackingTable [counter1*15+9] == 1002){
                            firstMitosisForMD = arrayCellTrackingTable [counter1*15];
                            break;
                        }
                    }
                    
                    if (eventSequenceCount+4 > eventSequenceLimit){
                        [self eventSequenceUpDate];
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                    }
                    
                    arrayEventSequence [eventSequenceCount] = imageNumberInt+1, eventSequenceCount++; //------Image no------
                    arrayEventSequence [eventSequenceCount] = 2, eventSequenceCount++; //------Event type------
                    arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++; //------Lineage no------
                    arrayEventSequence [eventSequenceCount] = cellNumberTempInt, eventSequenceCount++; //------Cell no------
                    
                    if (arrayEventSequence [(firstMitosisForMD+1)*4+1] == 2) arrayEventSequence [(firstMitosisForMD+1)*4+1] = 7;
                    else arrayEventSequence [(firstMitosisForMD+2)*4+1] = 7;
                    
                    returnMessage = "AC";
                    returnMessageTime = extension;
                    returnMessageExt = "0";
                }
                else if (trackHoldFlag == 1003){
                    int firstMitosisForDB = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (arrayCellTrackingTable [counter1*15+9] == 1003){
                            firstMitosisForDB = arrayCellTrackingTable [counter1*15];
                            break;
                        }
                    }
                    
                    if (eventSequenceCount+4 > eventSequenceLimit){
                        [self eventSequenceUpDate];
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                    }
                    
                    arrayEventSequence [eventSequenceCount] = imageNumberInt+1, eventSequenceCount++; //------Image no------
                    arrayEventSequence [eventSequenceCount] = 2, eventSequenceCount++; //------Event type------
                    arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++; //------Lineage no------
                    arrayEventSequence [eventSequenceCount] = cellNumberTempInt, eventSequenceCount++; //------Cell no------
                    
                    if (arrayEventSequence [(firstMitosisForDB+1)*4+1] == 2) arrayEventSequence [(firstMitosisForDB+1)*4+1] = 7;
                    else arrayEventSequence [(firstMitosisForDB+2)*4+1] = 7;
                    
                    returnMessage = "DB";
                    returnMessageTime = extension;
                    returnMessageExt = "0";
                }
                else if (trackHoldFlag == 1004){
                    if (eventSequenceCount+4 > eventSequenceLimit){
                        [self eventSequenceUpDate];
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                    }
                    
                    arrayEventSequence [eventSequenceCount] = imageNumberInt+1, eventSequenceCount++; //------Image no------
                    arrayEventSequence [eventSequenceCount] = 2, eventSequenceCount++; //------Event type------
                    arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++; //------Lineage no------
                    arrayEventSequence [eventSequenceCount] = cellNumberTempInt, eventSequenceCount++; //------Cell no------
                    
                    returnMessage = "RC";
                    returnMessageTime = extension;
                    returnMessageExt = "0";
                }
                else if (trackHoldFlag == 1005){
                    int firstMitosisForRD = 0;
                    
                    for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                        if (arrayCellTrackingTable [counter1*15+9] == 1005){
                            firstMitosisForRD = arrayCellTrackingTable [counter1*15];
                            break;
                        }
                    }
                    
                    if (eventSequenceCount+4 > eventSequenceLimit){
                        [self eventSequenceUpDate];
                        if (errorNoHold != 0){
                            errorNoHold = errorNoHold+2000;
                            throw errorCheckThrow;
                        }
                    }
                    
                    arrayEventSequence [eventSequenceCount] = imageNumberInt+1, eventSequenceCount++; //------Image no------
                    arrayEventSequence [eventSequenceCount] = 2, eventSequenceCount++; //------Event type------
                    arrayEventSequence [eventSequenceCount] = cellLineageTempInt, eventSequenceCount++; //------Lineage no------
                    arrayEventSequence [eventSequenceCount] = cellNumberTempInt, eventSequenceCount++; //------Cell no------
                    
                    if (arrayEventSequence [(firstMitosisForRD+1)*4+1] == 2) arrayEventSequence [(firstMitosisForRD+1)*4+1] = 7;
                    else arrayEventSequence [(firstMitosisForRD+2)*4+1] = 7;
                    
                    returnMessage = "SC";
                    returnMessageTime = extension;
                    returnMessageExt = "0";
                }
                
                firstCommunication = 4;
            }
            
            sleepingPosition = 40;
            
            if (trackHoldFlag == 1008){
                processType = 1;
                trackingDataSave = [[TrackingDataSave alloc] init];
                [trackingDataSave trackingDataSaveTemp:processType];
                
                do{
                } while (subCompletionFlag == 1);
                
                if (errorNoHold != 0){
                    errorNoHold = errorNoHold+2000;
                    throw errorCheckThrow;
                }
                
                int targetPointerPrevious = 0;
                int entryCountPrevious = 0;
                
                for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                    if (arrayCellTrackingTable [counter1*15] == roundStatus-1 && arrayCellTrackingTable [counter1*15+3] != 0){
                        entryCountPrevious++;
                        
                        if (arrayCellTrackingTable [counter1*15+7] == 1){
                            targetPointerPrevious = entryCountPrevious;
                            break;
                        }
                    }
                }
                
                //cout<<entryCountPrevious<<" "<<targetPointerPrevious<<"  entry"<<endl;
                
                errorNoHold = 134;
                arrayReferenceLine = new int [cellTrackingPreviousCount+50];
                referenceLineCount = 0;
                referenceLineLimit = cellTrackingPreviousCount+50;
                
                for (int counter1 = 0; counter1 < cellTrackingPreviousCount/6; counter1++){
                    if (arrayCellTrackingPrevious [counter1*6+3] == targetPointerPrevious){
                        if (referenceLineCount+2 > referenceLineLimit){
                            [self referenceLineCountUpDate];
                            if (errorNoHold != 0){
                                errorNoHold = errorNoHold+2000;
                                throw errorCheckThrow;
                            }
                        }
                        
                        arrayReferenceLine [referenceLineCount] = arrayCellTrackingPrevious [counter1*6], referenceLineCount++;
                        arrayReferenceLine [referenceLineCount] = arrayCellTrackingPrevious [counter1*6+1], referenceLineCount++;
                    }
                }
                
                int maxPointDimX = 0;
                int maxPointDimY = 0;
                int minPointDimX = 1000000;
                int minPointDimY = 1000000;
                
                for (int counter1 = 0; counter1 < referenceLineCount/2; counter1++){
                    if (maxPointDimX < arrayReferenceLine [counter1*2]) maxPointDimX = arrayReferenceLine [counter1*2];
                    if (minPointDimX > arrayReferenceLine [counter1*2]) minPointDimX = arrayReferenceLine [counter1*2];
                    if (maxPointDimY < arrayReferenceLine [counter1*2+1]) maxPointDimY = arrayReferenceLine [counter1*2+1];
                    if (minPointDimY > arrayReferenceLine [counter1*2+1]) minPointDimY = arrayReferenceLine [counter1*2+1];
                }
                
                int dimensionTemp = 0;
                
                int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                int verticalLength = (maxPointDimY-minPointDimY)/2*2;
                
                if (horizontalLength >= verticalLength) dimensionTemp = horizontalLength+30;
                if (horizontalLength < verticalLength) dimensionTemp = verticalLength+30;
                
                dimensionTemp = (dimensionTemp/2)*2;
                
                int horizontalStart2 = minPointDimX-(dimensionTemp-horizontalLength)/2;
                int verticalStart2 = minPointDimY-(dimensionTemp-verticalLength)/2;
                
                if (dimensionTemp > 0){
                    if (connectivityMapCutStatus == 0){
                        errorNoHold = 135;
                        connectivityMapCut = new int *[dimensionTemp+1];
                        for (int counter1 = 0; counter1 < dimensionTemp+1; counter1++){
                            errorNoHold = 136;
                            connectivityMapCut [counter1] = new int [dimensionTemp+1];
                        }
                        
                        connectivityMapCutStatus = 1;
                        connectivityMapCutSizeHold = dimensionTemp;
                    }
                    else if (connectivityMapCutStatus == 1 && 300 < connectivityMapCutSizeHold && 300 > dimensionTemp){
                        for (int counter1 = 0; counter1 < connectivityMapCutSizeHold+1; counter1++) delete [] connectivityMapCut [counter1];
                        delete [] connectivityMapCut;
                        
                        connectivityMapCutSizeHold = dimensionTemp;
                        
                        errorNoHold = 137;
                        connectivityMapCut = new int *[dimensionTemp+1];
                        for (int counter1 = 0; counter1 < dimensionTemp+1; counter1++){
                            errorNoHold = 138;
                            connectivityMapCut [counter1] = new int [dimensionTemp+1];
                        }
                    }
                    else if (connectivityMapCutStatus == 1 && connectivityMapCutSizeHold < dimensionTemp){
                        for (int counter1 = 0; counter1 < connectivityMapCutSizeHold+1; counter1++) delete [] connectivityMapCut [counter1];
                        delete [] connectivityMapCut;
                        
                        errorNoHold = 139;
                        connectivityMapCut = new int *[dimensionTemp+1];
                        for (int counter1 = 0; counter1 < dimensionTemp+1; counter1++){
                            errorNoHold = 140;
                            connectivityMapCut [counter1] = new int [dimensionTemp+1];
                        }
                        
                        connectivityMapCutSizeHold = dimensionTemp;
                    }
                    
                    for (int counterY = 0; counterY < dimensionTemp+1; counterY++){
                        for (int counterX = 0; counterX < dimensionTemp+1; counterX++) connectivityMapCut [counterY][counterX] = 0;
                    }
                    
                    for (int counter1 = 0; counter1 < referenceLineCount/2; counter1++){
                        connectivityMapCut [arrayReferenceLine [counter1*2+1]-verticalStart2][arrayReferenceLine [counter1*2]-horizontalStart2] = 1;
                    }
                    
                    //for (int counterA = 0; counterA < dimensionTemp; counterA++){
                    //	for (int counterB = 0; counterB < dimensionTemp; counterB++) cout<<" "<<connectivityMapCut [counterA][counterB];
                    //	cout<<" connectivityMapCut "<<counterA<<endl;
                    //}
                    
                    //------Fill inside------
                    errorNoHold = 141;
                    int *connectAnalysisX = new int [dimensionTemp*4];
                    errorNoHold = 142;
                    int *connectAnalysisY = new int [dimensionTemp*4];
                    errorNoHold = 143;
                    int *connectAnalysisTempX = new int [dimensionTemp*4];
                    errorNoHold = 144;
                    int *connectAnalysisTempY = new int [dimensionTemp*4];
                    
                    int connectivityNumber = -3;
                    int connectAnalysisCount = 0;
                    int terminationFlag = 0;
                    int connectAnalysisTempCount = 0;
                    int xSource = 0;
                    int ySource = 0;
                    
                    for (int counterY = 0; counterY < dimensionTemp; counterY++){
                        for (int counterX = 0; counterX < dimensionTemp; counterX++){
                            if (connectivityMapCut [counterY][counterX] == 0){
                                connectivityNumber = connectivityNumber+2;
                                connectAnalysisCount = 0;
                                
                                if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMapCut [counterY][counterX] = connectivityNumber;
                                if (counterY-1 >= 0 && connectivityMapCut [counterY-1][counterX] == 0){
                                    connectivityMapCut [counterY-1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterX+1 < dimensionTemp && connectivityMapCut [counterY][counterX+1] == 0){
                                    connectivityMapCut [counterY][counterX+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimensionTemp && connectivityMapCut [counterY+1][counterX] == 0){
                                    connectivityMapCut [counterY+1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterX-1 >= 0 && connectivityMapCut [counterY][counterX-1] == 0){
                                    connectivityMapCut [counterY][counterX-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                            
                                            if (ySource-1 >= 0 && connectivityMapCut [ySource-1][xSource] == 0){
                                                connectivityMapCut [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimensionTemp && connectivityMapCut [ySource][xSource+1] == 0){
                                                connectivityMapCut [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimensionTemp && connectivityMapCut [ySource+1][xSource] == 0){
                                                connectivityMapCut [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && connectivityMapCut [ySource][xSource-1] == 0){
                                                connectivityMapCut [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimensionTemp; counterY++){
                        for (int counterX = 0; counterX < dimensionTemp; counterX++){
                            if (connectivityMapCut [counterY][counterX] == -1) connectivityMapCut [counterY][counterX] = 0;
                            else connectivityMapCut [counterY][counterX] = 1;
                        }
                    }
                    
                    delete [] connectAnalysisX;
                    delete [] connectAnalysisY;
                    delete [] connectAnalysisTempX;
                    delete [] connectAnalysisTempY;
                    
                    //for (int counterA = 0; counterA < dimensionTemp; counterA++){
                    //	for (int counterB = 0; counterB < dimensionTemp; counterB++) cout<<" "<<connectivityMapCut [counterA][counterB];
                    //	cout<<" connectivityMapCut "<<counterA<<endl;
                    //}
                    
                    int maxConnectNumberList = timeSelectedCurrentCount/10;
                    
                    errorNoHold = 145;
                    int *overlapList = new int [maxConnectNumberList+2];
                    errorNoHold = 146;
                    int *overlapList2 = new int [maxConnectNumberList+2];
                    errorNoHold = 147;
                    int *overlapList3 = new int [maxConnectNumberList+2];
                    errorNoHold = 148;
                    int *overlapList4 = new int [maxConnectNumberList+2];
                    errorNoHold = 149;
                    int *overlapList5 = new int [maxConnectNumberList+2];
                    errorNoHold = 150;
                    int *overlapList6 = new int [maxConnectNumberList+2];
                    
                    for (int counter1 = 0; counter1 < maxConnectNumberList+2; counter1++){
                        overlapList [counter1] = 0; //------Overlap connect no and pix-------
                        overlapList2 [counter1] = 0; //------Total area-overlapped-------
                        overlapList3 [counter1] = 0; //------Intensity area-overlapped-------
                        overlapList4 [counter1] = 0; //------Cell status-------
                        overlapList5 [counter1] = 0; //------Cell Ling No-------
                        overlapList6 [counter1] = 0; //------Cell No-------
                    }
                    
                    int closeToEdge = 0;
                    int targetTotalArea = 0;
                    int targetTotalInt = 0;
                    int targetZero = 0;
                    
                    for (int counterY = 0; counterY < dimensionTemp; counterY++){
                        for (int counterX = 0; counterX < dimensionTemp; counterX++){
                            if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension && connectivityMapCut [counterY][counterX] != 0){
                                if (sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2] != 100) targetTotalInt = targetTotalInt+sourceImage [mapPositionPointerCurrent][(counterY+verticalStart2)*imageDimension+counterX+horizontalStart2];
                                if (revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2] == 0) targetZero++;
                                if (counterY+verticalStart2 <= 10 || counterY+verticalStart2 >= imageDimension-10 || counterX+horizontalStart2 <= 10 || counterX+horizontalStart2 >= imageDimension-10) closeToEdge++;
                                if (revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2] != 0) overlapList [revisedMapCurrent [counterY+verticalStart2][counterX+horizontalStart2]]++;
                            }
                            
                            if (connectivityMapCut [counterY][counterX] != 0) targetTotalArea++;
                        }
                    }
                    
                    //cout<<closeToEdge<<" "<<targetTotalArea<<" "<<targetTotalInt<<" "<<targetZero<<" "<<maxConnectNumberList<<" Info"<<endl;
                    
                    //for (int counterA = 0; counterA < gravityCenterRevCurrentCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRevCurrent [counterA*6+counterB];
                    //	cout<<" arrayGravityCenterRevCurrent "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < timeSelectedCurrentCount/10; counterA++){
                    // 	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelectedCurrent [counterA*10+counterB];
                    //	cout<<" arrayTimeSelectedCurrent "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < connectLineageRelCurrentCount/6; counterA++){
                    // 	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRelCurrent [counterA*6+counterB];
                    //	cout<<" arrayConnectLineageRelCurrent "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                        if (overlapList [counter1] != 0){
                            for (int counter2 = 0; counter2 < gravityCenterRevCurrentCount/6; counter2++){
                                if (arrayGravityCenterRevCurrent [counter2*6+4] == counter1){
                                    overlapList2 [counter1] = arrayGravityCenterRevCurrent [counter2*6+2];
                                    overlapList3 [counter1] = arrayGravityCenterRevCurrent [counter2*6+3];
                                    break;
                                }
                            }
                            
                            for (int counter2 = 0; counter2 < timeSelectedCurrentCount/10; counter2++){
                                if (arrayTimeSelectedCurrent [counter2*10+8] == counter1){
                                    overlapList4 [counter1] = arrayTimeSelectedCurrent [counter2*10];
                                    break;
                                }
                            }
                            
                            for (int counter2 = 0; counter2 < connectLineageRelCurrentCount/6; counter2++){
                                if (arrayConnectLineageRelCurrent [counter2*6+1] == counter1){
                                    overlapList5 [counter1] = arrayConnectLineageRelCurrent [counter2*6];
                                    overlapList6 [counter1] = arrayConnectLineageRelCurrent [counter2*6+3];
                                    break;
                                }
                            }
                        }
                    }
                    
                    int targetAverage = (int)(targetTotalInt/(double)targetTotalArea);
                    int processTypeFind = 0;
                    
                    double targetPercent = 0;
                    double refPercent = 0;
                    
                    for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                        if (overlapList [counter1] != 0 && (overlapList4 [counter1] == 7 || overlapList4 [counter1] == 1)){
                            targetPercent = overlapList [counter1]/(double)targetTotalArea;
                            refPercent = overlapList [counter1]/(double)overlapList2 [counter1];
                            
                            if (targetTotalArea > 100 && (targetPercent > 0.8 || refPercent > 0.8)){ //--fusion
                                if (overlapList3 [counter1] > targetAverage-20 && overlapList3 [counter1] < targetAverage+20){
                                    trackHoldFlag = -1;
                                    fusionPartnerLine = overlapList5 [counter1];
                                    fusionPartnerCellNo = overlapList6 [counter1];
                                    processTypeFind++;
                                }
                            }
                            else if (targetTotalArea > 100 &&  (targetPercent > 0.6 && refPercent > 0.6)){
                                if (overlapList3 [counter1] > targetAverage-20 && overlapList3 [counter1] < targetAverage+20){
                                    trackHoldFlag = -1;
                                    fusionPartnerLine = overlapList5 [counter1];
                                    fusionPartnerCellNo = overlapList6 [counter1];
                                    processTypeFind++;
                                }
                            }
                        }
                    }
                    
                    if (processTypeFind == 0){
                        double zeroTargetPercent = targetZero/(double)targetTotalArea;
                        
                        if (zeroTargetPercent > 0.5){ //--fusion
                            trackHoldFlag = 3000;
                        }
                        else if (closeToEdge > 20){
                            trackHoldFlag = 200;
                            
                            arrayEventSequence [eventSequenceCount-3] = 8, eventSequenceCount++; //------Event type------
                            
                            string extension = to_string(imageNumberInt);
                            
                            returnMessage = "OF";
                            returnMessageTime = extension;
                            returnMessageExt = "0";
                            
                            firstCommunication = 4;
                        }
                        else trackHoldFlag = 3000;
                    }
                    
                    if (processTypeFind == 1 && trackHoldFlag == -1){
                        if (timeOneHold+roundStatus-1 > 11){
                            targetCellStatus = 0;
                            
                            if (roundStatus != 2){
                                for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                                    if (arrayCellTrackingTable [counter1*15] == roundStatus-1 && arrayCellTrackingTable [counter1*15+7] == 1){
                                        if (arrayCellTrackingTable [counter1*15+14] == 2000) targetCellStatus = 2000;
                                        else if (arrayCellTrackingTable [counter1*15+14] > 1000) targetCellStatus = arrayCellTrackingTable [counter1*15+14];
                                        else targetCellStatus = arrayCellTrackingTable [counter1*15+14];
                                    }
                                }
                            }
                            else{
                                
                                int connectNoTemp = 0;
                                
                                for (int counter1 = 0; counter1 < connectLineageRelCurrentCount/6; counter1++){
                                    if (arrayConnectLineageRelCurrent [counter1*6] == cellLineageTempInt && arrayConnectLineageRelCurrent [counter1*6+3] == cellNumberTempInt){
                                        connectNoTemp = arrayConnectLineageRelCurrent [counter1*6+1];
                                        break;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < timeSelectedCurrentCount/10; counter1++){
                                    if (arrayTimeSelectedCurrent [counter1*10+8] == connectNoTemp){
                                        if (arrayTimeSelectedCurrent [counter1*10] == 1) targetCellStatus = 1000;
                                        else if (arrayTimeSelectedCurrent [counter1*10] == 7) targetCellStatus = 2000;
                                        
                                        break;
                                    }
                                }
                            }
                            
                            processType = 1; //------1: fusion, 2: non-fusion-------
                            
                            gravityCenterEntryType = 1;
                            gravityCenterXCurrentHold1 = 0;
                            gravityCenterYCurrentHold1 = 0;
                            gravityAverageCurrentHold1 = 0;
                            gravityCellNoCurrent1 = 0;
                            gravityCenterXCurrentHold2 = 0;
                            gravityCenterYCurrentHold2 = 0;
                            gravityAverageCurrentHold2 = 0;
                            gravityCellNoCurrent2 = 0;
                            gravityCenterXCurrentHold3 = 0;
                            gravityCenterYCurrentHold3 = 0;
                            gravityAverageCurrentHold3 = 0;
                            gravityCellNoCurrent3 = 0;
                            gravityCenterXCurrentHold4 = 0;
                            gravityCenterYCurrentHold4 = 0;
                            gravityAverageCurrentHold4 = 0;
                            gravityCellNoCurrent4 = 0;
                            
                            int cutOffAdjust = -1;
                            
                            areaCutCurrent = [[AreaCutCurrent alloc] init];
                            [areaCutCurrent circleCut:processType:targetCellStatus:cutOffAdjust]; //------trackHoldFlag 3000, 3002, 3003-------
                            
                            do{
                            } while (subCompletionFlag == 1);
                            
                            if (errorNoHold != 0){
                                errorNoHold = errorNoHold+2000;
                                throw errorCheckThrow;
                            }
                            
                            if (trackHoldFlag != 3000 && trackHoldFlag != 3002 && trackHoldFlag != 3003){
                                processType = 2;
                                trackingDataSave = [[TrackingDataSave alloc] init];
                                [trackingDataSave trackingDataSaveTemp:processType];
                                
                                do{
                                } while (subCompletionFlag == 1);
                                
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                                
                                if (eventSequenceCount+4 > eventSequenceLimit){
                                    [self eventSequenceUpDate];
                                    if (errorNoHold != 0){
                                        errorNoHold = errorNoHold+2000;
                                        throw errorCheckThrow;
                                    }
                                }
                                
                                arrayEventSequence [eventSequenceCount] = imageNumberInt+1, eventSequenceCount++; //------Image no------
                                arrayEventSequence [eventSequenceCount] = 91, eventSequenceCount++; //------Event type------
                                arrayEventSequence [eventSequenceCount] = fusionPartnerLine, eventSequenceCount++; //------Lineage no------
                                arrayEventSequence [eventSequenceCount] = fusionPartnerCellNo, eventSequenceCount++; //------Cell no------
                                
                                string extension = to_string(imageNumberInt+1);
                                
                                returnMessage = "FC";
                                returnMessageTime = extension;
                                returnMessageExt = "0";
                                
                                firstCommunication = 4;
                            }
                        }
                        else trackHoldFlag = 3000;
                    }
                    
                    if (processTypeFind > 1){
                        trackHoldFlag = -4;
                        
                        string extension = to_string(imageNumberInt);
                        
                        returnMessage = "ME";
                        returnMessageTime = extension;
                        returnMessageExt = "0";
                        
                        firstCommunication = 4;
                    }
                    
                    if (trackHoldFlag == 3000 || trackHoldFlag == 3002 || trackHoldFlag == 3003){
                        string extension = to_string(imageNumberInt);
                        
                        if (trackHoldFlag == 3000){
                            returnMessage = "TL";
                            returnMessageTime = extension;
                            returnMessageExt = "0";
                            
                            firstCommunication = 4;
                        }
                        else if (trackHoldFlag == 3002){
                            returnMessage = "FE";
                            returnMessageTime = extension;
                            returnMessageExt = "0";
                            
                            firstCommunication = 4;
                        }
                        else if (trackHoldFlag == 3003){
                            returnMessage = "FO";
                            returnMessageTime = extension;
                            returnMessageExt = "0";
                            
                            firstCommunication = 4;
                        }
                        
                        trackHoldFlag = 50;
                    }
                    
                    delete [] overlapList;
                    delete [] overlapList2;
                    delete [] overlapList3;
                    delete [] overlapList4;
                    delete [] overlapList5;
                    delete [] overlapList6;
                }
                else trackHoldFlag = 3000;
                
                delete [] arrayReferenceLine;
            }
            
            sleepingPosition = 41;
            
            if (trackHoldFlag == 1010){ //---retry
                returnMessage = "RD";
                returnMessageTime = to_string(imageNumberInt);
                returnMessageExt = to_string(statusAdditionalInfo+imageNumberInt-roundStatus+1);
                
                firstCommunication = 4;
            }
            
            sleepingPosition = 42;
            
            if (trackHoldFlag == 1011){
                int roundNoFuse = statusAdditionalInfo; //-------Round No------
                
                //cout<<fusionPartnerCellNo<<" "<<p_InterpretVariablesSet -> _statusAdditionalInfo<<" "<<trackHoldFlag<<" fusePartner"<<endl;
                
                int entryPreviousCount = 0;
                
                for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                    if (arrayCellTrackingTable [counter1*15] == roundNoFuse) entryPreviousCount++;
                }
                
                int countTemp = 0;
                
                for (int counter1 = 0; counter1 < cellAttachCount/6; counter1++){
                    if (arrayAttachTable [counter1*6] < roundNoFuse) countTemp = countTemp+6;
                }
                
                cellAttachCount = countTemp;
                countTemp = 0;
                
                for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                    if (arrayCellTrackingTable [counter1*15] < roundNoFuse) countTemp = countTemp+15;
                    if (arrayCellTrackingTable [counter1*15] == roundNoFuse && arrayCellTrackingTable [counter1*15+7] == 1) retryFlag = arrayCellTrackingTable [counter1*15+2];
                }
                
                //for (int counterA = 0; counterA < cellTrackingTableCount/15; counterA++){
                //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayCellTrackingTable [counterA*15+counterB];
                //    cout<<" arrayCellTrackingTable "<<counterA<<endl;
                //}
                
                cellTrackingTableCount = countTemp;
                
                for (int counter1 = 0; counter1 < cellTrackingTableCount/15; counter1++){
                    if (arrayCellTrackingTable [counter1*15] == roundNoFuse){
                        arrayCellTrackingTable [counter1*15+12] = 0;
                        arrayCellTrackingTable [counter1*15+13] = 0;
                    }
                }
                
                for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                    if (arrayEventSequence [counter1*4] < roundNoFuse+imageNumberInt-roundStatus+1) arrayEventSequence [counter1*4] = 0; //------Image no------
                }
                
                int maxPointDimX = 0;
                int maxPointDimY = 0;
                int minPointDimX = 1000000;
                int minPointDimY = 1000000;
                
                imageNumberInt = imageNumberInt-(roundStatus-roundNoFuse)+1;
                
                for (int counter1 = 0; counter1 < mapEntryTotal; counter1++){
                    if (imageNoHoldMain [counter1*2] == imageNumberInt) mapPositionPointer = counter1;
                    if (imageNoHoldMain [counter1*2] == imageNumberInt+1) mapPositionPointerCurrent = counter1;
                }
                
                string extension = to_string(imageNumberInt);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                string connectDataTempPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_MasterDataTemp";
                
                long size1 = 0;
                long size2 = 0;
                int checkFlag = 0;
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    sizeForCopy = 0;
                    
                    if (stat(connectDataTempPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter1 == 0) size1 = sizeForCopy;
                        else if (counter1 == 1) size2 = sizeForCopy;
                        else if (counter1 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter1 == 3) size1 = sizeForCopy;
                        else if (counter1 == 4) size2 = sizeForCopy;
                        else if (counter1 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                if (checkFlag == 0){
                    errorNoHold = 1035;
                    throw errorCheckThrow;
                }
                
                if (checkFlag == 1){
                    errorNoHold = 151;
                    int *arrayPositionReviseTemp = new int [sizeForCopy+50];
                    int positionReviseTempCount = 0;
                    
                    fin.open(connectDataTempPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [17];
                        
                        errorNoHold = 152;
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                    errorNoHold = 1036;
                                    throw errorCheckThrow;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--5
                                finData [13] = uploadTemp [readPosition], readPosition++; //--6
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++;
                                finData [16] = uploadTemp [readPosition], readPosition++; //--7
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                else{
                                    
                                    arrayPositionReviseTemp [positionReviseTempCount] = finData [1], positionReviseTempCount++;
                                    arrayPositionReviseTemp [positionReviseTempCount] = finData [3], positionReviseTempCount++;
                                    arrayPositionReviseTemp [positionReviseTempCount] = finData [4], positionReviseTempCount++;
                                    arrayPositionReviseTemp [positionReviseTempCount] = finData [7], positionReviseTempCount++;
                                    arrayPositionReviseTemp [positionReviseTempCount] = finData [12], positionReviseTempCount++;
                                    arrayPositionReviseTemp [positionReviseTempCount] = finData [13], positionReviseTempCount++;
                                    arrayPositionReviseTemp [positionReviseTempCount] = finData [16], positionReviseTempCount++;
                                }
                            }
                            else if (stepCount == 1){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                finData [9] = finData [8]*256+finData [9];
                                
                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                            }
                            else if (stepCount == 2){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                
                                if (finData [1] == 0 && finData [3] == 0) stepCount = 3;
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                        
                        errorNoHold = 153;
                        arrayReferenceLine = new int [positionReviseTempCount+50];
                        referenceLineCount = 0;
                        referenceLineLimit = positionReviseTempCount+50;
                        
                        for (int counter1 = 0; counter1 < positionReviseTempCount/7; counter1++){
                            if (arrayPositionReviseTemp [counter1*7+3] == retryFlag || arrayPositionReviseTemp [counter1*7+3] == fusionPartnerCellNo){
                                if (referenceLineCount+3 > referenceLineLimit){
                                    [self referenceLineCountUpDate];
                                    if (errorNoHold != 0){
                                        errorNoHold = errorNoHold+2000;
                                        throw errorCheckThrow;
                                    }
                                }
                                
                                if (maxPointDimX < arrayPositionReviseTemp [counter1*7]) maxPointDimX = arrayPositionReviseTemp [counter1*7];
                                if (minPointDimX > arrayPositionReviseTemp [counter1*7]) minPointDimX = arrayPositionReviseTemp [counter1*7];
                                if (maxPointDimY < arrayPositionReviseTemp [counter1*7+1]) maxPointDimY = arrayPositionReviseTemp [counter1*7+1];
                                if (minPointDimY > arrayPositionReviseTemp [counter1*7+1]) minPointDimY = arrayPositionReviseTemp [counter1*7+1];
                                
                                arrayReferenceLine [referenceLineCount] = arrayPositionReviseTemp [counter1*7], referenceLineCount++;
                                arrayReferenceLine [referenceLineCount] = arrayPositionReviseTemp [counter1*7+1], referenceLineCount++;
                            }
                        }
                    }
                    
                    delete [] arrayPositionReviseTemp;
                }
                
                if (maxPointDimX > 0 && maxPointDimY > 0 && minPointDimX < 1000000 && minPointDimY < 1000000){
                    roundStatus = roundNoFuse+1;
                    
                    //------Determine the dimension of cell------
                    horizontalStart = 0;
                    verticalStart = 0;
                    int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                    int verticalLength = (maxPointDimY-minPointDimY)/2*2;
                    
                    if (horizontalLength >= verticalLength) trackAreaSize = horizontalLength+30;
                    if (horizontalLength < verticalLength) trackAreaSize = verticalLength+30;
                    
                    if (trackAreaSize < 128) trackAreaSize = 128;
                    else trackAreaSize = (trackAreaSize/2)*2;
                    
                    horizontalStart = minPointDimX-(trackAreaSize-horizontalLength)/2;
                    verticalStart = minPointDimY-(trackAreaSize-verticalLength)/2;
                    
                    if (sectionMapLoadingStatusPrev == 0){
                        sectionMapLoadingStatusPrev = 1;
                        cellTrackingPreviousMapSizeHold = trackAreaSize;
                        
                        errorNoHold = 154;
                        arrayCellTrackingPreviousMap = new int *[trackAreaSize+4];
                        
                        for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++){
                            errorNoHold = 155;
                            arrayCellTrackingPreviousMap [counter1] = new int [trackAreaSize+4];
                        }
                    }
                    else if (sectionMapLoadingStatusPrev == 1 && 300 < cellTrackingPreviousMapSizeHold && 300 > trackAreaSize){
                        for (int counter1 = 0; counter1 < cellTrackingPreviousMapSizeHold+4; counter1++) delete [] arrayCellTrackingPreviousMap [counter1];
                        delete [] arrayCellTrackingPreviousMap;
                        
                        cellTrackingPreviousMapSizeHold = trackAreaSize;
                        
                        errorNoHold = 156;
                        arrayCellTrackingPreviousMap = new int *[trackAreaSize+4];
                        for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++){
                            errorNoHold = 157;
                            arrayCellTrackingPreviousMap [counter1] = new int [trackAreaSize+4];
                        }
                    }
                    else if (sectionMapLoadingStatusPrev == 1 && cellTrackingPreviousMapSizeHold < trackAreaSize){
                        for (int counter1 = 0; counter1 < cellTrackingPreviousMapSizeHold+4; counter1++) delete [] arrayCellTrackingPreviousMap [counter1];
                        delete [] arrayCellTrackingPreviousMap;
                        
                        cellTrackingPreviousMapSizeHold = trackAreaSize;
                        
                        errorNoHold = 158;
                        arrayCellTrackingPreviousMap = new int *[trackAreaSize+4];
                        for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++){
                            errorNoHold = 159;
                            arrayCellTrackingPreviousMap [counter1] = new int [trackAreaSize+4];
                        }
                    }
                    
                    if (sectionMapLoadingStatus == 0){
                        errorNoHold = 160;
                        arrayCellTrackingCurrentMap = new int *[trackAreaSize+4];
                        
                        for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++){
                            errorNoHold = 161;
                            arrayCellTrackingCurrentMap [counter1] = new int [trackAreaSize+4];
                        }
                        
                        sectionMapLoadingStatus = 1;
                        cellTrackingCurrentMapSizeHold = trackAreaSize;
                    }
                    else if (sectionMapLoadingStatus == 1 && 300 < cellTrackingCurrentMapSizeHold && 300 > trackAreaSize){
                        for (int counter1 = 0; counter1 < cellTrackingCurrentMapSizeHold+4; counter1++) delete [] arrayCellTrackingCurrentMap [counter1];
                        delete [] arrayCellTrackingCurrentMap;
                        
                        cellTrackingCurrentMapSizeHold = trackAreaSize;
                        
                        errorNoHold = 162;
                        arrayCellTrackingCurrentMap = new int *[trackAreaSize+4];
                        for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++){
                            errorNoHold = 163;
                            arrayCellTrackingCurrentMap [counter1] = new int [trackAreaSize+4];
                        }
                    }
                    else if (sectionMapLoadingStatus == 1 && cellTrackingCurrentMapSizeHold < trackAreaSize){
                        for (int counter1 = 0; counter1 < cellTrackingCurrentMapSizeHold+4; counter1++) delete [] arrayCellTrackingCurrentMap [counter1];
                        delete [] arrayCellTrackingCurrentMap;
                        
                        cellTrackingCurrentMapSizeHold = trackAreaSize;
                        
                        errorNoHold = 164;
                        arrayCellTrackingCurrentMap = new int *[trackAreaSize+4];
                        for (int counter1 = 0; counter1 < trackAreaSize+4; counter1++){
                            errorNoHold = 165;
                            arrayCellTrackingCurrentMap [counter1] = new int [trackAreaSize+4];
                        }
                    }
                    
                    processTime = 1;
                    int imageNo = 0;
                    trackingSet = [[TrackingSet alloc] init];
                    [trackingSet trackingSetMain:processTime:imageNo];
                    
                    do{
                    } while (subCompletionFlag == 1);
                    
                    if (errorNoHold != 0){
                        errorNoHold = errorNoHold+2000;
                        throw errorCheckThrow;
                    }
                    
                    processType = 1;
                    tableInterpretation = [[TableInterpretation alloc] init];
                    [tableInterpretation interpretationFirst:processType];
                    
                    do{
                    } while (subCompletionFlag == 1);
                    
                    if (errorNoHold != 0){
                        errorNoHold = errorNoHold+2000;
                        throw errorCheckThrow;
                    }
                    
                    mitosisStatusHold = 0;
                    
                    string connectClearPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold;
                    
                    string entry;
                    string removeFilePath;
                    
                    DIR *dir;
                    struct dirent *dent;
                    
                    dir = opendir(connectClearPath.c_str());
                    
                    if (dir != NULL){
                        fileHandlingCount = 0;
                        
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (fileHandlingCount+5 > fileHandlingLimit){
                                [self fileHandlingUpDate];
                                if (errorNoHold != 0){
                                    errorNoHold = errorNoHold+2000;
                                    throw errorCheckThrow;
                                }
                            }
                            
                            arrayFileHandling [fileHandlingCount] = entry, fileHandlingCount++;
                        }
                        
                        closedir(dir);
                        
                        for (int counter1 = 0; counter1 < fileHandlingCount; counter1++){
                            entry = arrayFileHandling [counter1];
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                int findFile1 = (int)entry.find("ConnectLineageRelTemp");
                                int findFile2 = (int)entry.find("CutTemp");
                                int findFile3 = (int)entry.find("GCCurrentTemp");
                                int findFile4 = (int)entry.find("MasterDataTemp");
                                int findFile5 = (int)entry.find("RevisedTempMap");
                                int findFile6 = (int)entry.find("StatusTemp");
                                int findFile7 = (int)entry.find("LinkDataTemp");
                                int findFile8 = (int)entry.find("ExtendAreaDataTemp");
                                int findFile9 = (int)entry.find("ExtendLineDataTemp");
                                int findFile10 = (int)entry.find("EventTemp");
                                int findFile11 = (int)entry.find("MitosisDataTemp");
                                int findFile12 = (int)entry.find("GCCenterInfo");
                                
                                if (findFile1 != -1 || findFile2 != -1 || findFile3 != -1 || findFile4 != -1 || findFile5 != -1 || findFile6 != -1 || findFile7 != -1 || findFile8 != -1 || findFile9 != -1 || findFile10 != -1 || findFile11 != -1 || findFile12 != -1){
                                    removeFilePath = connectClearPath+"/"+entry;
                                    remove (removeFilePath.c_str());
                                }
                            }
                        }
                    }
                    
                    firstCommunication = 11;
                }
                else trackHoldFlag = 3000;
            }
            
            sleepingPosition = 43;
            
            if (trackHoldFlag == 1006 || trackHoldFlag == 1007 || trackHoldFlag == 1009 || trackHoldFlag == 3000 || trackHoldFlag == 3002 || trackHoldFlag == 3003){
                processType = 1;
                trackingDataSave = [[TrackingDataSave alloc] init];
                [trackingDataSave trackingDataSaveTemp:processType];
                
                do{
                } while (subCompletionFlag == 1);
                
                if (errorNoHold != 0){
                    errorNoHold = errorNoHold+2000;
                    throw errorCheckThrow;
                }
                
                string extension = to_string(imageNumberInt);
                
                if (trackHoldFlag == 1006){
                    returnMessage = "CM";
                    returnMessageTime = extension;
                    returnMessageExt = "0";
                    
                    firstCommunication = 4;
                }
                else if (trackHoldFlag == 1007){
                    returnMessage = "CN";
                    returnMessageTime = extension;
                    returnMessageExt = "0";
                    
                    firstCommunication = 4;
                }
                else if (trackHoldFlag == 1009){
                    returnMessage = "FM";
                    returnMessageTime = extension;
                    returnMessageExt = "0";
                    
                    firstCommunication = 4;
                }
                else if (trackHoldFlag == 3000){
                    returnMessage = "TL";
                    returnMessageTime = extension;
                    returnMessageExt = "0";
                    
                    firstCommunication = 4;
                }
                else if (trackHoldFlag == 3002){
                    returnMessage = "FE";
                    returnMessageTime = extension;
                    returnMessageExt = "0";
                    
                    firstCommunication = 4;
                }
                else if (trackHoldFlag == 3003){
                    returnMessage = "FO";
                    returnMessageTime = extension;
                    returnMessageExt = "0";
                    
                    firstCommunication = 4;
                }
            }
            
            sleepingPosition = 44;
            
            if (trackHoldFlag == 4000){
                string extension = to_string(imageNumberInt);
                
                if (roundStatus > 2){
                    processType = 1;
                    trackingDataSave = [[TrackingDataSave alloc] init];
                    [trackingDataSave trackingDataSaveTemp:processType];
                    
                    do{
                    } while (subCompletionFlag == 1);
                    
                    if (errorNoHold != 0){
                        errorNoHold = errorNoHold+2000;
                        throw errorCheckThrow;
                    }
                    
                    returnMessage = "CF";
                    returnMessageTime = extension;
                    returnMessageExt = "0";
                    
                    firstCommunication = 4;
                }
                else{
                    
                    returnMessage = "CL";
                    returnMessageTime = extension;
                    returnMessageExt = "0";
                    
                    firstCommunication = 4;
                }
            }
            
            sleepingPosition = 45;
            
            if (trackHoldFlag == 3500){
                string extension = to_string(imageNumberInt-1);
                
                eventSequenceCount = eventSequenceCount-4;
                
                returnMessage = "TL";
                returnMessageTime = extension;
                returnMessageExt = "0";
                
                firstCommunication = 4;
            }
            
            delete [] arrayPartnerInfo;
            
            //time7 = clock();
            
            //cout<<" A "<<time2-time1<<endl;
            //cout<<" B "<<time3-time2<<endl;
            //cout<<" C "<<time4-time3<<endl;
            //cout<<" D "<<time5-time4<<endl;
            //cout<<" E "<<time6-time5<<endl;
            //cout<<" F "<<time7-time6<<endl;
            
            //NSLog(@"%@", [NSThread callStackSymbols]);
            
            sleepingPosition = 46;
            errorNoHold = 0;
        }
        catch (int errorCheckThrow){
            if (errorNoHold >= 1000 && errorNoHold < 2000){
                string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
                mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                time_t rawtime;
                struct tm * timeinfo;
                time (&rawtime);
                timeinfo = localtime ( &rawtime );
                
                int tsec = timeinfo -> tm_sec;
                int tmin = timeinfo -> tm_min;
                int thour = timeinfo -> tm_hour;
                int tday = timeinfo -> tm_mday;
                int tmon = timeinfo -> tm_mon;
                
                string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
                
                errorPath = errorPath+"/Cell_CarvingImageProcessing01 "+dateTime;
                
                ofstream oin2;
                oin2.open(errorPath.c_str(), ios::out);
                oin2<<"ImageProcessing"<<endl;
                oin2<<errorNoHold<<endl;
                oin2<<analysisImageName<<endl;
                oin2<<analysisID<<endl;
                oin2<<treatmentNameHold<<endl;
                oin2<<cellLineageNoHold<<endl;
                oin2<<cellNoHold<<endl;
                oin2<<dateTime<<endl;
                
                if (errorNoHold == 1000) oin2<<"ExpandLine reading error"<<endl;
                else if (errorNoHold == 1002) oin2<<"ExpandLine uploading error"<<endl;
                else if (errorNoHold == 1003) oin2<<"ExpandLine open-error"<<endl;
                else if (errorNoHold == 1004) oin2<<"ExpandArea uploading error"<<endl;
                else if (errorNoHold == 1005) oin2<<"ExpandArea open-error"<<endl;
                else if (errorNoHold >= 1006 && errorNoHold >= 1017) oin2<<"Fluorescent image (tif/bmp) open-error"<<endl;
                else if (errorNoHold == 1018) oin2<<"ExpandLine reading error"<<endl;
                else if (errorNoHold == 1019) oin2<<"ExpandLine uploading error"<<endl;
                else if (errorNoHold == 1020) oin2<<"ExpandLine open-error"<<endl;
                else if (errorNoHold == 1021) oin2<<"ExpandArea uploading error"<<endl;
                else if (errorNoHold == 1022) oin2<<"ExpandArea open-error"<<endl;
                else if (errorNoHold >= 1023 && errorNoHold >= 1034) oin2<<"Fluorescent image (tif/bmp) open-error"<<endl;
                else if (errorNoHold == 1035) oin2<<"MasterDataTemp reading error"<<endl;
                else if (errorNoHold == 1035) oin2<<"MasterDataTemp uploading error"<<endl;
                oin2.close();
            }
            
            emergencyExit = 1;
            firstCommunication = 20;
        }
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingImageProcessing02 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"ImageProcessing"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        emergencyExit = 1;
        firstCommunication = 20;
    }
}

-(int)primaryAddition{
    string cellNumberExtract = cellNoHold.substr(1);
    int cellNumberTempInt = atoi(cellNumberExtract.c_str());
    int numberLength = (int)cellNumberExtract.length();
    int zeroPoint = -1;
    int digitNumber = 0;
    int checkFlag = 0;
    int newCellNumber = 0;
    
    if (cellNumberTempInt == 0) newCellNumber = -100000000;
    else{
        
        string digitExtract;
        
        for (int counter1 = 0; counter1 < numberLength; counter1++){
            digitExtract = cellNumberExtract.substr((unsigned long)counter1, 1);
            
            if (checkFlag == 0 && digitExtract == "0"){
                zeroPoint = counter1;
                checkFlag = 1;
            }
            else if (checkFlag == 1 && digitExtract != "0"){
                zeroPoint = -1;
                checkFlag = 0;
            }
        }
        
        if (zeroPoint != -1){
            digitNumber = numberLength-zeroPoint;
            
            if (digitNumber == 8) newCellNumber = cellNumberTempInt+10000000;
            else if (digitNumber == 7) newCellNumber = cellNumberTempInt+1000000;
            else if (digitNumber == 6) newCellNumber = cellNumberTempInt+100000;
            else if (digitNumber == 5) newCellNumber = cellNumberTempInt+10000;
            else if (digitNumber == 4) newCellNumber = cellNumberTempInt+1000;
            else if (digitNumber == 3) newCellNumber = cellNumberTempInt+100;
            else if (digitNumber == 2) newCellNumber = cellNumberTempInt+10;
            else if (digitNumber == 1) newCellNumber = cellNumberTempInt+1;
        }
        else{
            
            if (cellNumberExtract.substr(0,1) == "-" && (int)cellNumberExtract.length() == 9){
                cellNumberExtract = "-0"+cellNumberExtract.substr(1);
            }
            else if (cellNumberExtract.substr(0,1) != "-" && (int)cellNumberExtract.length() == 8){
                cellNumberExtract = "0"+cellNumberExtract;
            }
            
            string lineageNumberExtract = cellLineageNoHold.substr(1);
            int cellExtensionEntry = 0;
            
            if (cellNumberTempInt > 0){
                if (cellNumberExtract.substr(0, 1) == "0"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "3"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "30000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "3000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "300"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "30"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "3"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "1" || cellNumberExtract.substr(0, 1) == "2"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "4"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "40000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "4000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "400"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "40"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "4"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "3"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "5"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "50000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "5000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "500"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "50"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "5"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "4"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "6"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "60000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "6000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "600"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "60"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "6"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
            else{
                
                if (cellNumberExtract.substr(1, 1) == "0"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "3"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-30000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-3000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-300"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-30"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-3"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "1" || cellNumberExtract.substr(1, 1) == "2"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "4"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-40000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-4000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-400"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-40"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-4"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "3"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "5"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-50000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-5000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-500"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-50"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-5"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "4"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "6"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-60000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-6000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-600"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-60"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-6"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
        }
    }
    
    return newCellNumber;
}

-(int)primarySubt{
    string cellNumberExtract = cellNoHold.substr(1);
    int cellNumberTempInt = atoi(cellNumberExtract.c_str());
    int numberLength = (int)cellNumberExtract.length();
    int zeroPoint = -1;
    int digitNumber = 0;
    int checkFlag = 0;
    int newCellNumber = 0;
    
    if (cellNumberTempInt == 0) newCellNumber = 100000000;
    else{
        
        string digitExtract;
        
        for (int counter1 = 0; counter1 < numberLength; counter1++){
            digitExtract = cellNumberExtract.substr((unsigned long)counter1, 1);
            
            if (checkFlag == 0 && digitExtract == "0"){
                zeroPoint = counter1;
                checkFlag = 1;
            }
            else if (checkFlag == 1 && digitExtract != "0"){
                zeroPoint = -1;
                checkFlag = 0;
            }
        }
        
        if (zeroPoint != -1){
            digitNumber = numberLength-zeroPoint;
            
            if (digitNumber == 8) newCellNumber = cellNumberTempInt-10000000;
            else if (digitNumber == 7) newCellNumber = cellNumberTempInt-1000000;
            else if (digitNumber == 6) newCellNumber = cellNumberTempInt-100000;
            else if (digitNumber == 5) newCellNumber = cellNumberTempInt-10000;
            else if (digitNumber == 4) newCellNumber = cellNumberTempInt-1000;
            else if (digitNumber == 3) newCellNumber = cellNumberTempInt-100;
            else if (digitNumber == 2) newCellNumber = cellNumberTempInt-10;
            else if (digitNumber == 1) newCellNumber = cellNumberTempInt-1;
        }
        else{
            
            if (cellNumberExtract.substr(0,1) == "-" && (int)cellNumberExtract.length() == 9){
                cellNumberExtract = "-0"+cellNumberExtract.substr(1);
            }
            else if (cellNumberExtract.substr(0,1) != "-" && (int)cellNumberExtract.length() == 8){
                cellNumberExtract = "0"+cellNumberExtract;
            }
            
            string lineageNumberExtract = cellLineageNoHold.substr(1);
            int cellExtensionEntry = 0;
            
            if (cellNumberTempInt > 0){
                if (cellNumberExtract.substr(0, 1) == "0"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "3"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "30000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "3000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "300"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "30"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "3"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "1" || cellNumberExtract.substr(0, 1) == "2"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "4"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "40000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "4000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "400"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "40"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "4"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "3"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "5"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "50000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "5000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "500"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "50"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "5"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "4"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "6"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "60000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "6000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "600"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "60"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "6"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
            else{
                
                if (cellNumberExtract.substr(1, 1) == "0"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "3"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-30000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-3000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-300"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-30"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-3"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "1" || cellNumberExtract.substr(1, 1) == "2"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "4"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-40000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-4000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-400"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-40"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-4"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "3"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "5"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-50000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-5000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-500"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-50"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-5"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "4"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "6"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-60000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-6000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-600"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-60"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-6"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
        }
    }
    
    return newCellNumber;
}

-(int)secondaryAddition{
    string cellNumberExtract = cellNoHold.substr(1);
    int cellNumberTempInt = atoi(cellNumberExtract.c_str());
    int numberLength = (int)cellNumberExtract.length();
    int zeroPoint = -1;
    int digitNumber = 0;
    int checkFlag = 0;
    int newCellNumber = 0;
    
    if (cellNumberTempInt == 0) newCellNumber = -200000000;
    else{
        
        string digitExtract;
        
        for (int counter1 = 0; counter1 < numberLength; counter1++){
            digitExtract = cellNumberExtract.substr((unsigned long)counter1, 1);
            
            if (checkFlag == 0 && digitExtract == "0"){
                zeroPoint = counter1;
                checkFlag = 1;
            }
            else if (checkFlag == 1 && digitExtract != "0"){
                zeroPoint = -1;
                checkFlag = 0;
            }
        }
        
        if (zeroPoint != -1){
            digitNumber = numberLength-zeroPoint;
            
            if (digitNumber == 8) newCellNumber = cellNumberTempInt+20000000;
            else if (digitNumber == 7) newCellNumber = cellNumberTempInt+2000000;
            else if (digitNumber == 6) newCellNumber = cellNumberTempInt+200000;
            else if (digitNumber == 5) newCellNumber = cellNumberTempInt+20000;
            else if (digitNumber == 4) newCellNumber = cellNumberTempInt+2000;
            else if (digitNumber == 3) newCellNumber = cellNumberTempInt+200;
            else if (digitNumber == 2) newCellNumber = cellNumberTempInt+20;
            else if (digitNumber == 1) newCellNumber = cellNumberTempInt+2;
        }
        else{
            
            if (cellNumberExtract.substr(0,1) == "-" && (int)cellNumberExtract.length() == 9){
                cellNumberExtract = "-0"+cellNumberExtract.substr(1);
            }
            else if (cellNumberExtract.substr(0,1) != "-" && (int)cellNumberExtract.length() == 8){
                cellNumberExtract = "0"+cellNumberExtract;
            }
            
            string lineageNumberExtract = cellLineageNoHold.substr(1);
            int cellExtensionEntry = 0;
            
            if (cellNumberTempInt > 0){
                if (cellNumberExtract.substr(0, 1) == "0"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "3"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "30000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "3000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "300"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "30"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "3"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "1" || cellNumberExtract.substr(0, 1) == "2"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "4"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "40000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "4000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "400"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "40"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "4"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "3"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "5"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "50000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "5000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "500"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "50"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "5"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "4"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "6"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "60000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "6000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "600"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "60"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "6"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
            else{
                
                if (cellNumberExtract.substr(1, 1) == "0"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "3"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-30000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-3000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-300"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-30"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-3"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "1" || cellNumberExtract.substr(1, 1) == "2"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "4"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-40000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-4000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-400"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-40"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-4"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "3"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "5"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-50000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-5000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-500"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-50"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-5"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "4"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "6"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-60000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-6000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-600"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-60"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-6"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
        }
    }
    
    return newCellNumber;
}

-(int)secondarySubt{
    string cellNumberExtract = cellNoHold.substr(1);
    int cellNumberTempInt = atoi(cellNumberExtract.c_str());
    int numberLength = (int)cellNumberExtract.length();
    int zeroPoint = -1;
    int digitNumber = 0;
    int checkFlag = 0;
    int newCellNumber = 0;
    
    if (cellNumberTempInt == 0) newCellNumber = 200000000;
    else{
        
        string digitExtract;
        
        for (int counter1 = 0; counter1 < numberLength; counter1++){
            digitExtract = cellNumberExtract.substr((unsigned long)counter1, 1);
            
            if (checkFlag == 0 && digitExtract == "0"){
                zeroPoint = counter1;
                checkFlag = 1;
            }
            else if (checkFlag == 1 && digitExtract != "0"){
                zeroPoint = -1;
                checkFlag = 0;
            }
        }
        
        if (zeroPoint != -1){
            digitNumber = numberLength-zeroPoint;
            
            if (digitNumber == 8) newCellNumber = cellNumberTempInt-20000000;
            else if (digitNumber == 7) newCellNumber = cellNumberTempInt-2000000;
            else if (digitNumber == 6) newCellNumber = cellNumberTempInt-200000;
            else if (digitNumber == 5) newCellNumber = cellNumberTempInt-20000;
            else if (digitNumber == 4) newCellNumber = cellNumberTempInt-2000;
            else if (digitNumber == 3) newCellNumber = cellNumberTempInt-200;
            else if (digitNumber == 2) newCellNumber = cellNumberTempInt-20;
            else if (digitNumber == 1) newCellNumber = cellNumberTempInt-2;
        }
        else{
            
            if (cellNumberExtract.substr(0,1) == "-" && (int)cellNumberExtract.length() == 9){
                cellNumberExtract = "-0"+cellNumberExtract.substr(1);
            }
            else if (cellNumberExtract.substr(0,1) != "-" && (int)cellNumberExtract.length() == 8){
                cellNumberExtract = "0"+cellNumberExtract;
            }
            
            string lineageNumberExtract = cellLineageNoHold.substr(1);
            int cellExtensionEntry = 0;
            
            if (cellNumberTempInt > 0){
                if (cellNumberExtract.substr(0, 1) == "0"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "3"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "30000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "3000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "300"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "30"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "3"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "1" || cellNumberExtract.substr(0, 1) == "2"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "4"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "40000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "4000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "400"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "40"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "4"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "3"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "5"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "50000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "5000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "500"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "50"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "5"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "4"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "6"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "60000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "6000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "600"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "60"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "6"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
            else{
                
                if (cellNumberExtract.substr(1, 1) == "0"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "3"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-30000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-3000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-300"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-30"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-3"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "1" || cellNumberExtract.substr(1, 1) == "2"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "4"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-40000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-4000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-400"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-40"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-4"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "3"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "4"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-50000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-5000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-500"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-50"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-5"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "4"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "6"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-60000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-6000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-600"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-60"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-6"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
        }
    }
    
    return newCellNumber;
}

-(void)fluorescentProcess{
    try{
        
        errorNoHold = 0;
        
        ifstream fin;
        
        string extension = to_string(imageNumberInt);
        
        if (extension.length() == 1) extension = "000"+extension;
        else if (extension.length() == 2) extension = "00"+extension;
        else if (extension.length() == 3) extension = "0"+extension;
        
        string extension2 = to_string(fluorescentNo1);
        string fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+".tif";
        
        fin.open(fluorescentPath1.c_str(), ios::in);
        
        if (!fin.is_open()){
            fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+".bmp";
        }
        else fin.close();
        
        struct stat sizeOfFile;
        
        if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0){
            int matchFind = 0;
            
            for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                if (arrayFluorescentCutOff [counter1*7] == imageNumberInt){
                    fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                    fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                    fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                    fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                    fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                    fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                    matchFind = 1;
                    break;
                }
            }
            
            if (matchFind == 0){
                string cutOffPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
                
                if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                    int nearestCount = 0;
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                        if (arrayFluorescentCutOff [counter1*7] < imageNumberInt){
                            if (nearestCount < arrayFluorescentCutOff [counter1*7]){
                                nearestCount = arrayFluorescentCutOff [counter1*7];
                                fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                                fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                                fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                            }
                        }
                    }
                    
                    if (fluorescentCutOffStatus == 0){
                        errorNoHold = 166;
                        arrayFluorescentCutOff = new int [imageEndHold*7];
                        fluorescentCutOffCount = 0;
                        fluorescentCutOffStatus = 1;
                    }
                    
                    if (nearestCount != 0){
                        arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberInt, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
                    }
                    else{
                        
                        arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberInt, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    }
                    
                    ofstream oin;
                    oin.open(cutOffPath.c_str(), ios::out);
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                    oin<<"End"<<endl;
                    oin.close();
                }
                else{
                    
                    fluorescentCutOff1 = 150;
                    fluorescentCutOff2 = 150;
                    fluorescentCutOff3 = 150;
                    fluorescentCutOff4 = 150;
                    fluorescentCutOff5 = 150;
                    fluorescentCutOff6 = 150;
                    
                    if (fluorescentCutOffStatus == 0){
                        errorNoHold = 167;
                        arrayFluorescentCutOff = new int [imageEndHold*7];
                        fluorescentCutOffCount = 0;
                        fluorescentCutOffStatus = 1;
                    }
                    
                    arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberInt, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    
                    ofstream oin;
                    oin.open(cutOffPath.c_str(), ios::out);
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                    oin<<"End"<<endl;
                    oin.close();
                }
            }
        }
        
        errorNoHold = 0;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingImageProcessing03 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"ImageProcessing-fluorescentProcess1"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
    }
}

-(void)fluorescentProcess2{
    try{
        
        errorNoHold = 0;
        
        ifstream fin;
        
        string extension = to_string(imageNumberInt+1);
        
        if (extension.length() == 1) extension = "000"+extension;
        else if (extension.length() == 2) extension = "00"+extension;
        else if (extension.length() == 3) extension = "0"+extension;
        
        string extension2 = to_string(fluorescentNo1);
        
        string fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+".tif";
        
        fin.open(fluorescentPath1.c_str(), ios::in);
        
        if (!fin.is_open()){
            fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+".bmp";
        }
        else fin.close();
        
        struct stat sizeOfFile;
        
        if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0){
            int matchFind = 0;
            
            for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                if (arrayFluorescentCutOff [counter1*7] == imageNumberInt+1){
                    fluorescentCutOffCurrent1 = arrayFluorescentCutOff [counter1*7+1];
                    fluorescentCutOffCurrent2 = arrayFluorescentCutOff [counter1*7+2];
                    fluorescentCutOffCurrent3 = arrayFluorescentCutOff [counter1*7+3];
                    fluorescentCutOffCurrent4 = arrayFluorescentCutOff [counter1*7+4];
                    fluorescentCutOffCurrent5 = arrayFluorescentCutOff [counter1*7+5];
                    fluorescentCutOffCurrent6 = arrayFluorescentCutOff [counter1*7+6];
                    matchFind = 1;
                    break;
                }
            }
            
            if (matchFind == 0){
                string cutOffPath = trackingDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
                
                if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                    int nearestCount = 0;
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                        if (arrayFluorescentCutOff [counter1*7] < imageNumberInt+1){
                            if (nearestCount < arrayFluorescentCutOff [counter1*7]){
                                nearestCount = arrayFluorescentCutOff [counter1*7];
                                fluorescentCutOffCurrent1 = arrayFluorescentCutOff [counter1*7+1];
                                fluorescentCutOffCurrent2 = arrayFluorescentCutOff [counter1*7+2];
                                fluorescentCutOffCurrent3 = arrayFluorescentCutOff [counter1*7+3];
                                fluorescentCutOffCurrent4 = arrayFluorescentCutOff [counter1*7+4];
                                fluorescentCutOffCurrent5 = arrayFluorescentCutOff [counter1*7+5];
                                fluorescentCutOffCurrent6 = arrayFluorescentCutOff [counter1*7+6];
                            }
                        }
                    }
                    
                    if (fluorescentCutOffStatus == 0){
                        errorNoHold = 168;
                        arrayFluorescentCutOff = new int [imageEndHold*4];
                        fluorescentCutOffCount = 0;
                        fluorescentCutOffStatus = 1;
                    }
                    
                    if (nearestCount != 0){
                        arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberInt+1, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOffCurrent1, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOffCurrent2, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOffCurrent3, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOffCurrent4, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOffCurrent5, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOffCurrent6, fluorescentCutOffCount++;
                    }
                    else{
                        
                        arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberInt+1, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    }
                    
                    ofstream oin;
                    oin.open(cutOffPath.c_str(), ios::out);
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                    oin<<"End"<<endl;
                    oin.close();
                }
                else{
                    
                    fluorescentCutOffCurrent1 = 150;
                    fluorescentCutOffCurrent2 = 150;
                    fluorescentCutOffCurrent3 = 150;
                    fluorescentCutOffCurrent4 = 150;
                    fluorescentCutOffCurrent5 = 150;
                    fluorescentCutOffCurrent6 = 150;
                    
                    if (fluorescentCutOffStatus == 0){
                        errorNoHold = 169;
                        arrayFluorescentCutOff = new int [imageEndHold*7];
                        fluorescentCutOffCount = 0;
                        fluorescentCutOffStatus = 1;
                    }
                    
                    arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberInt+1, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    
                    ofstream oin;
                    oin.open(cutOffPath.c_str(), ios::out);
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                    oin<<"End"<<endl;
                    oin.close();
                }
            }
        }
        
        errorNoHold = 0;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingImageProcessing04 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"ImageProcessing-fluorescentProcess2"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        if (errorNoHold == 0) errorNoHold = 1000;
    }
}

-(void)referenceLineCountUpDate{
    try{
        
        errorNoHold = 0;
        
        int *arrayUpDate = new int [referenceLineCount+10];
        
        for (int counter1 = 0; counter1 < referenceLineCount; counter1++) arrayUpDate [counter1] = arrayReferenceLine [counter1];
        
        delete [] arrayReferenceLine;
        arrayReferenceLine = new int [referenceLineLimit+5000];
        referenceLineLimit = referenceLineLimit+5000;
        
        for (int counter1 = 0; counter1 < referenceLineCount; counter1++) arrayReferenceLine [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingImageProcessing05 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"ImageProcessing-referenceLineCountUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

-(void)eventSequenceUpDate{
    try{
        
        errorNoHold = 0;
        
        int *arrayUpDate = new int [eventSequenceCount+10];
        
        for (int counter1 = 0; counter1 < eventSequenceCount; counter1++) arrayUpDate [counter1] = arrayEventSequence [counter1];
        
        delete [] arrayEventSequence;
        arrayEventSequence = new int [eventSequenceLimit+500];
        eventSequenceLimit = eventSequenceLimit+500;
        
        for (int counter1 = 0; counter1 < eventSequenceCount; counter1++) arrayEventSequence [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingImageProcessing06 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"ImageProcessing-eventSequenceUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

-(void)fileHandlingUpDate{
    try{
        
        errorNoHold = 0;
        
        string *arrayUpDate = new string [fileHandlingCount+10];
        
        for (int counter1 = 0; counter1 < fileHandlingCount; counter1++) arrayUpDate [counter1] = arrayFileHandling [counter1];
        
        delete [] arrayFileHandling;
        arrayFileHandling = new string [fileHandlingLimit+500];
        fileHandlingLimit = fileHandlingLimit+500;
        
        for (int counter1 = 0; counter1 < fileHandlingCount; counter1++) arrayFileHandling [counter1] = arrayUpDate [counter1];
        delete [] arrayUpDate;
    }
    catch (bad_alloc&){
        string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
        mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        time_t rawtime;
        struct tm * timeinfo;
        time (&rawtime);
        timeinfo = localtime ( &rawtime );
        
        int tsec = timeinfo -> tm_sec;
        int tmin = timeinfo -> tm_min;
        int thour = timeinfo -> tm_hour;
        int tday = timeinfo -> tm_mday;
        int tmon = timeinfo -> tm_mon;
        
        string dateTime = "M"+to_string(tmon)+"-D"+to_string(tday)+"-h"+to_string(thour)+"-m"+to_string(tmin)+"-s"+to_string(tsec);
        
        errorPath = errorPath+"/Cell_CarvingImageProcessing07 "+dateTime;
        
        ofstream oin2;
        oin2.open(errorPath.c_str(), ios::out);
        oin2<<"ImageProcessing-fileHandlingUpDate"<<endl;
        oin2<<errorNoHold<<endl;
        oin2<<analysisImageName<<endl;
        oin2<<analysisID<<endl;
        oin2<<treatmentNameHold<<endl;
        oin2<<cellLineageNoHold<<endl;
        oin2<<cellNoHold<<endl;
        oin2<<dateTime<<endl;
        oin2.close();
        
        errorNoHold = 1000;
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToImageProcessing object:nil];
}

@end
