//
// TrackingDataSave.h
// Cell_Carving
//
// Created by Masahiko Sato on 03/01/14.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#ifndef TRAKINGDATASAVE_H
#define TRAKINGDATASAVE_H
#import "Controller.h"
#endif

@interface TrackingDataSave : NSObject{
}

-(void)trackingDataSaveTemp:(int)processType;

@end
