//
//  FluorescentController.m
//  CellMovie
//
//  Created by Masahiko Sato on 10/7/16.
//
//

#import "FluorescentController.h"

NSString *notificationToFluorescentController = @"notificationExecuteFluorescentController";

@implementation FluorescentController

-(id)init{
    self = [super init];
    
    if (self != nil){
        fileNoBMPCount = 0;
        fileTypeTifBmp = 0;
        
        sliderFluorescentMax = 20;
        sliderFluorescentMin = 0.01;
        sliderFluorescentDiff = 19.99;
        sliderBaseMax = 255;
        sliderBaseMin = 0;
        sliderBaseDiff = 255;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToFluorescentController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    adjustWindController = [[NSWindowController alloc] initWithWindowNibName:@"FluoWindow"];
    [adjustWindController showWindow:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentAdjust object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [adjustWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [adjustWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    int baseCutInt = (int)(baseCutFluorescent*1000);
    double baseCutDouble = baseCutInt/(double)1000;
    int fluorescentEnhanceInt = (int)(fluorescentEnhanceFluorescent*1000);
    double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
    
    [tableViewTDList setDataSource:self];
    [tableViewTDList reloadData];
    
    [baseCutValueDisplay setDoubleValue:baseCutDouble];
    [fluorescentValueDisplay setDoubleValue:fluorescentEnhanceDouble];
    [sliderFluorescentCircle setDoubleValue:1];
    [sliderBaseCircle setDoubleValue:1];
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = fileNoBMPCount;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    string displayData1;
    string displayData2;
    
    if (imageLoadFlagFluorescent == 1){
        int bmpFindFlag = 0;
        
        for (int counter1 = 1; counter1 <= maxImageNo; counter1++){
            if (fileList [(counter1-1)*7+1] != ""){
                if ((int)fileList [(counter1-1)*7+1].find("TIF") != -1 || (int)fileList [(counter1-1)*7+1].find("BMP") != -1){
                    if (bmpFindFlag == rowIndex){
                        displayData1 = to_string(counter1);
                        displayData2 = fileList [(counter1-1)*7+1];
                        break;
                    }
                    else bmpFindFlag++;
                }
                
                if (fileList [(counter1-1)*7+2] != ""){
                    if ((int)fileList [(counter1-1)*7+2].find("TIF") != -1 || (int)fileList [(counter1-1)*7+2].find("BMP") != -1){
                        if (bmpFindFlag == rowIndex){
                            displayData1 = to_string(counter1);
                            displayData2 = fileList [(counter1-1)*7+2];
                            break;
                        }
                        else bmpFindFlag++;
                    }
                    
                    if (fileList [(counter1-1)*7+3] != ""){
                        if ((int)fileList [(counter1-1)*7+3].find("TIF") != -1 || (int)fileList [(counter1-1)*7+3].find("BMP") != -1){
                            if (bmpFindFlag == rowIndex){
                                displayData1 = to_string(counter1);
                                displayData2 = fileList [(counter1-1)*7+3];
                                break;
                            }
                            else bmpFindFlag++;
                        }
                        
                        if (fileList [(counter1-1)*7+4] != ""){
                            if ((int)fileList [(counter1-1)*7+4].find("TIF") != -1 || (int)fileList [(counter1-1)*7+4].find("BMP") != -1){
                                if (bmpFindFlag == rowIndex){
                                    displayData1 = to_string(counter1);
                                    displayData2 = fileList [(counter1-1)*7+4];
                                    break;
                                }
                                else bmpFindFlag++;
                            }
                            
                            if (fileList [(counter1-1)*7+5] != ""){
                                if ((int)fileList [(counter1-1)*7+5].find("TIF") != -1 || (int)fileList [(counter1-1)*7+5].find("BMP") != -1){
                                    if (bmpFindFlag == rowIndex){
                                        displayData1 = to_string(counter1);
                                        displayData2 = fileList [(counter1-1)*7+5];
                                        break;
                                    }
                                    else bmpFindFlag++;
                                }
                                
                                if (fileList [(counter1-1)*7+6] != ""){
                                    if ((int)fileList [(counter1-1)*7+6].find("TIF") != -1 || (int)fileList [(counter1-1)*7+6].find("BMP") != -1){
                                        if (bmpFindFlag == rowIndex){
                                            displayData1 = to_string(counter1);
                                            displayData2 = fileList [(counter1-1)*7+6];
                                            break;
                                        }
                                        else bmpFindFlag++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        if ((int)displayData2.find("TIF") != -1){
            displayData2 = displayData2.substr(15, displayData2.find(".TIF")-15)+" R"+displayData2.substr(displayData2.find(".TIF")+4);
            fileTypeTifBmp = 0;
        }
        else if ((int)displayData2.find("BMP") != -1){
            
            displayData2 = displayData2.substr(15, displayData2.find(".BMP")-15)+" R"+displayData2.substr(displayData2.find(".BMP")+4);
            fileTypeTifBmp = 1;
        }
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        [attributes setObject:[NSFont boldSystemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    if (imageLoadFlagFluorescent == 1){
        tableCallFluorescentCount++;
        tableCurrentFluRowHold = rowIndex;
        
        if (tableCallFluorescentCount == 2){
            tableCurrentFluRowHold = rowIndexFluorescentHold;
            string fileNameGet = "";
            
            int bmpFindFlag = 0;
            
            for (int counter1 = 1; counter1 <= maxImageNo; counter1++){
                if (fileList [(counter1-1)*7+1] != ""){
                    if ((int)fileList [(counter1-1)*7+1].find("TIF") != -1 || (int)fileList [(counter1-1)*7+1].find("BMP") != -1){
                        if (bmpFindFlag == rowIndex){
                            fileNameGet = fileList [(counter1-1)*7+1];
                            break;
                        }
                        else bmpFindFlag++;
                    }
                    
                    if (fileList [(counter1-1)*7+2] != ""){
                        if ((int)fileList [(counter1-1)*7+2].find("TIF") != -1 || (int)fileList [(counter1-1)*7+2].find("BMP") != -1){
                            if (bmpFindFlag == rowIndex){
                                fileNameGet = fileList [(counter1-1)*7+2];
                                break;
                            }
                            else bmpFindFlag++;
                        }
                        
                        if (fileList [(counter1-1)*7+3] != ""){
                            if ((int)fileList [(counter1-1)*7+3].find("TIF") != -1 || (int)fileList [(counter1-1)*7+3].find("BMP") != -1){
                                if (bmpFindFlag == rowIndex){
                                    fileNameGet = fileList [(counter1-1)*7+3];
                                    break;
                                }
                                else bmpFindFlag++;
                            }
                        }
                        
                        if (fileList [(counter1-1)*7+4] != ""){
                            if ((int)fileList [(counter1-1)*7+4].find("TIF") != -1 || (int)fileList [(counter1-1)*7+4].find("BMP") != -1){
                                if (bmpFindFlag == rowIndex){
                                    fileNameGet = fileList [(counter1-1)*7+4];
                                    break;
                                }
                                else bmpFindFlag++;
                            }
                            
                            if (fileList [(counter1-1)*7+5] != ""){
                                if ((int)fileList [(counter1-1)*7+5].find("TIF") != -1 || (int)fileList [(counter1-1)*7+5].find("BMP") != -1){
                                    if (bmpFindFlag == rowIndex){
                                        fileNameGet = fileList [(counter1-1)*7+5];
                                        break;
                                    }
                                    else bmpFindFlag++;
                                }
                                
                                if (fileList [(counter1-1)*7+6] != ""){
                                    if ((int)fileList [(counter1-1)*7+6].find("TIF") != -1 || (int)fileList [(counter1-1)*7+6].find("BMP") != -1){
                                        if (bmpFindFlag == rowIndex){
                                            fileNameGet = fileList [(counter1-1)*7+6];
                                            break;
                                        }
                                        else bmpFindFlag++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            if (referenceImageStatusFluorescent == 0){
                arrayReferenceImageFluorescent= new int *[imageSizeFluorescent+5];
                
                for (int counter1 = 0; counter1 < imageSizeFluorescent+5; counter1++){
                    arrayReferenceImageFluorescent [counter1] = new int [imageSizeFluorescent+5];
                }
                
                referenceImageStatusFluorescent = 1;
            }
            
            selectedFile = fileNameGet;
            
            string imageMoviePath = imageDisplayPath+"/"+fileNameGet;
            
            ifstream fin;
            
            if (fileTypeTifBmp == 0){
                //----Tiff reading----
                unsigned long stripFirstAddress = 0;
                unsigned long stripByteCountAddress = 0;
                unsigned long nextAddress = 0;
                unsigned long headPosition = 0;
                unsigned long stripEntry = 0;
                long sizeForCopy = 0;
                
                double xPosition = 0;
                double yPosition = 0;
                
                int imageWidth = 0;
                int imageHeight = 0;
                int imageBit = 0; // Check 8, 16
                int imageCompression = 0; // Check 1
                int photoMetric = 0; //check 0, 1, 2
                int imageDimensionTif = 0;
                int verticalBmp = 0;
                int horizontalBmp = 0;
                int horizontalBmpEntry = 0;
                int endianType = 0;
                int samplePerPix = 0;
                int dataConversion [4];
                int processTypeTif = 1;
                int numberOfLayers = 0;
                
                struct stat sizeOfFile;
                
                if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    fileReadArray = new uint8_t [sizeForCopy+4];
                    fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                    
                    fin.read((char*)fileReadArray, sizeForCopy+4);
                    fin.close();
                    
                    dataConversion [0] = fileReadArray [0];
                    dataConversion [1] = fileReadArray [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    int *arrayExtractedImage3 = new int [100];
                    
                    headPosition = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = fileReadArray [7];
                        dataConversion [1] = fileReadArray [6];
                        dataConversion [2] = fileReadArray [5];
                        dataConversion [3] = fileReadArray [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = fileReadArray [4];
                        dataConversion [1] = fileReadArray [5];
                        dataConversion [2] = fileReadArray [6];
                        dataConversion [3] = fileReadArray [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    if (endianType == 1){
                        tiffFileRead = [[TiffFileRead alloc] init];
                        [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                        
                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                            if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                            else imageDimensionTif = imageHeight;
                            
                            tiffFileRead = [[TiffFileRead alloc] init];
                            delete [] arrayExtractedImage3;
                            
                            arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                        }
                    }
                    else if (endianType == 0){
                        tiffFileRead = [[TiffFileRead alloc] init];
                        [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                        
                        
                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                            if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                            else imageDimensionTif = imageHeight;
                            
                            tiffFileRead = [[TiffFileRead alloc] init];
                            delete [] arrayExtractedImage3;
                            
                            arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                        }
                    }
                    
                    verticalBmp = 0;
                    horizontalBmp = 0;
                    horizontalBmpEntry = 0;
                    
                    for (int counter5 = 0; counter5 < imageWidth*imageHeight; counter5++){
                        if (verticalBmp < imageHeight){
                            if (horizontalBmp < imageWidth){
                                arrayReferenceImageFluorescent [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter5]), horizontalBmpEntry++;
                                horizontalBmp++;
                            }
                            
                            if (horizontalBmp == imageWidth){
                                horizontalBmp = 0;
                                horizontalBmpEntry = 0;
                                verticalBmp++;
                            }
                        }
                    }
                    
                    delete [] fileReadArray;
                    delete [] arrayExtractedImage3;
                }
            }
            else{
                
                long sizeForCopy = 0;
                
                struct stat sizeOfFile;
                
                if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                    fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTempA, sizeForCopy+1);
                        fin.close();
                        
                        int imageDimensionReadCount = 0;
                        
                        for (int counter1 = imageSizeFluorescent-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageSizeFluorescent; counter2++){
                                arrayReferenceImageFluorescent [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageSizeFluorescent+counter2];
                            }
                            
                            imageDimensionReadCount++;
                        }
                    }
                    
                    delete [] uploadTempA;
                }
            }
            
            xMovePositionHoldMain = 0;
            yMovePositionHoldMain = 0;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentAdjust object:self];
        }
        else if (tableCallFluorescentCount == 1){
            tableCurrentFluRowHold = rowIndex;
            
            string fileNameGet = "";
            
            int bmpFindFlag = 0;
            
            for (int counter1 = 1; counter1 <= maxImageNo; counter1++){
                if (fileList [(counter1-1)*7+1] != ""){
                    if ((int)fileList [(counter1-1)*7+1].find("TIF") != -1 || (int)fileList [(counter1-1)*7+1].find("BMP") != -1){
                        if (bmpFindFlag == rowIndex){
                            fileNameGet = fileList [(counter1-1)*7+1];
                            break;
                        }
                        else bmpFindFlag++;
                    }
                    
                    if (fileList [(counter1-1)*7+2] != ""){
                        if ((int)fileList [(counter1-1)*7+2].find("TIF") != -1 || (int)fileList [(counter1-1)*7+2].find("BMP") != -1){
                            if (bmpFindFlag == rowIndex){
                                fileNameGet = fileList [(counter1-1)*7+2];
                                break;
                            }
                            else bmpFindFlag++;
                        }
                        
                        if (fileList [(counter1-1)*7+3] != ""){
                            if ((int)fileList [(counter1-1)*7+3].find("TIF") != -1 || (int)fileList [(counter1-1)*7+3].find("BMP") != -1){
                                if (bmpFindFlag == rowIndex){
                                    fileNameGet = fileList [(counter1-1)*7+3];
                                    break;
                                }
                                else bmpFindFlag++;
                            }
                            
                            if (fileList [(counter1-1)*7+4] != ""){
                                if ((int)fileList [(counter1-1)*7+4].find("TIF") != -1 || (int)fileList [(counter1-1)*7+4].find("BMP") != -1){
                                    if (bmpFindFlag == rowIndex){
                                        fileNameGet = fileList [(counter1-1)*7+4];
                                        break;
                                    }
                                    else bmpFindFlag++;
                                }
                                
                                if (fileList [(counter1-1)*7+5] != ""){
                                    if ((int)fileList [(counter1-1)*7+5].find("TIF") != -1 || (int)fileList [(counter1-1)*7+5].find("BMP") != -1){
                                        if (bmpFindFlag == rowIndex){
                                            fileNameGet = fileList [(counter1-1)*7+5];
                                            break;
                                        }
                                        else bmpFindFlag++;
                                    }
                                    
                                    if (fileList [(counter1-1)*7+6] != ""){
                                        if ((int)fileList [(counter1-1)*7+6].find("TIF") != -1 || (int)fileList [(counter1-1)*7+6].find("BMP") != -1){
                                            if (bmpFindFlag == rowIndex){
                                                fileNameGet = fileList [(counter1-1)*7+6];
                                                break;
                                            }
                                            else bmpFindFlag++;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            if (referenceImageStatusFluorescent == 0){
                arrayReferenceImageFluorescent = new int *[imageSizeFluorescent+5];
                
                for (int counter1 = 0; counter1 < imageSizeFluorescent+5; counter1++){
                    arrayReferenceImageFluorescent [counter1] = new int [imageSizeFluorescent+5];
                }
                
                referenceImageStatusFluorescent = 1;
            }
            
            string imageMoviePath = imageDisplayPath+"/"+fileNameGet;
            
            selectedFile = fileNameGet;
            
            ifstream fin;
            
            if (fileTypeTifBmp == 0){
                //----Tiff reading----
                unsigned long stripFirstAddress = 0;
                unsigned long stripByteCountAddress = 0;
                unsigned long nextAddress = 0;
                unsigned long headPosition = 0;
                unsigned long stripEntry = 0;
                long sizeForCopy = 0;
                
                double xPosition = 0;
                double yPosition = 0;
                
                int imageWidth = 0;
                int imageHeight = 0;
                int imageBit = 0; // Check 8, 16
                int imageCompression = 0; // Check 1
                int photoMetric = 0; //check 0, 1, 2
                int imageDimensionTif = 0;
                int verticalBmp = 0;
                int horizontalBmp = 0;
                int horizontalBmpEntry = 0;
                int endianType = 0;
                int samplePerPix = 0;
                int dataConversion [4];
                int processTypeTif = 1;
                int numberOfLayers = 0;
                
                struct stat sizeOfFile;
                
                if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    fileReadArray = new uint8_t [sizeForCopy+4];
                    fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                    
                    fin.read((char*)fileReadArray, sizeForCopy+4);
                    fin.close();
                    
                    dataConversion [0] = fileReadArray [0];
                    dataConversion [1] = fileReadArray [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    int *arrayExtractedImage3 = new int [100];
                    
                    headPosition = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = fileReadArray [7];
                        dataConversion [1] = fileReadArray [6];
                        dataConversion [2] = fileReadArray [5];
                        dataConversion [3] = fileReadArray [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = fileReadArray [4];
                        dataConversion [1] = fileReadArray [5];
                        dataConversion [2] = fileReadArray [6];
                        dataConversion [3] = fileReadArray [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    if (endianType == 1){
                        tiffFileRead = [[TiffFileRead alloc] init];
                        [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                        
                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                            if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                            else imageDimensionTif = imageHeight;
                            
                            tiffFileRead = [[TiffFileRead alloc] init];
                            delete [] arrayExtractedImage3;
                            
                            arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                        }
                    }
                    else if (endianType == 0){
                        tiffFileRead = [[TiffFileRead alloc] init];
                        [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                        
                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                            if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                            else imageDimensionTif = imageHeight;
                            
                            tiffFileRead = [[TiffFileRead alloc] init];
                            delete [] arrayExtractedImage3;
                            
                            arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                        }
                    }
                    
                    verticalBmp = 0;
                    horizontalBmp = 0;
                    horizontalBmpEntry = 0;
                    
                    for (int counter5 = 0; counter5 < imageWidth*imageHeight; counter5++){
                        if (verticalBmp < imageHeight){
                            if (horizontalBmp < imageWidth){
                                arrayReferenceImageFluorescent [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter5]), horizontalBmpEntry++;
                                horizontalBmp++;
                            }
                            
                            if (horizontalBmp == imageWidth){
                                horizontalBmp = 0;
                                horizontalBmpEntry = 0;
                                verticalBmp++;
                            }
                        }
                    }
                    
                    delete [] fileReadArray;
                    delete [] arrayExtractedImage3;
                }
            }
            else{
                
                long sizeForCopy = 0;
                
                struct stat sizeOfFile;
                
                if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                    fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTempA, sizeForCopy+1);
                        fin.close();
                        
                        int imageDimensionReadCount = 0;
                        
                        for (int counter1 = imageSizeFluorescent-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageSizeFluorescent; counter2++){
                                arrayReferenceImageFluorescent [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageSizeFluorescent+counter2];
                            }
                            
                            imageDimensionReadCount++;
                        }
                    }
                    
                    delete [] uploadTempA;
                }
            }
            
            fluorescentColorNoFluorescent = atoi(fileNameGet.substr(13, 1).c_str());
            
            xMovePositionHoldMain = 0;
            yMovePositionHoldMain = 0;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentAdjust object:self];
        }
    }
    
    return YES;
}

-(IBAction)savePosition:(id)sender{
    if (lastTIFRoundNo != 0 && imageLoadFlagFluorescent == 1){
        if (imageSizeFluorescent != 0 && movieRunningFlag == 0){
            if (dicImageStatusFluorescent == 1 && referenceImageStatusFluorescent == 1){
                if (copyProgressFlag == 0){
                    string timePointNo = to_string(maxImageNo+1);
                    
                    if (timePointNo.length() == 1) timePointNo = "000"+timePointNo;
                    else if (timePointNo.length() == 2) timePointNo = "00"+timePointNo;
                    else if (timePointNo.length() == 3) timePointNo = "0"+timePointNo;
                    
                    string roundNo = to_string(lastTIFRoundNo+1);
                    
                    if (roundNo.length() == 1) roundNo = "0"+roundNo;
                    
                    if (fileTypeTifBmp == 0){
                        fileSavePathHold = imageDisplayPath+"/"+"STimage "+timePointNo+".TIF"+roundNo;
                        
                        double xPosition = 100;
                        double yPosition = 100;
                        
                        int imageBit = 8;
                        int photoMetric = 1;
                        int samplePerPix = 1;
                        int mode = 0;
                        
                        arrayImageFileSave = new int *[imageSizeFluorescent+1];
                        
                        for (int counter3 = 0; counter3 < imageSizeFluorescent+1; counter3++){
                            arrayImageFileSave [counter3] = new int [imageSizeFluorescent+1];
                        }
                        
                        for (int counter3 = 0; counter3 < imageSizeFluorescent; counter3++){
                            for (int counter4 = 0; counter4 < imageSizeFluorescent; counter4++){
                                arrayImageFileSave [counter3][counter4] = arrayDICImageForFluorescent [counter3][counter4];
                            }
                        }
                        
                        singleTiffSave = [[SingleTiffSave alloc] init];
                        [singleTiffSave singleTiffLayerSave:imageSizeFluorescent:imageSizeFluorescent:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:(unsigned long)mode];
                        
                        
                        string stringExtract = selectedFile.substr(12, selectedFile.find(".TIF")-12);
                        
                        fileSavePathHold = imageDisplayPath+"/"+"STimage "+timePointNo+stringExtract+".TIF"+roundNo;
                        
                        for (int counter2 = 0; counter2 < imageSizeFluorescent; counter2++){
                            for (int counter3 = 0; counter3 < imageSizeFluorescent; counter3++){
                                if (counter2-yMovePositionHoldMain >= 0 && counter2-yMovePositionHoldMain < imageSizeFluorescent && counter3+xMovePositionHoldMain >= 0 && counter3+xMovePositionHoldMain < imageSizeFluorescent){
                                    arrayImageFileSave [counter2][counter3] = arrayReferenceImageFluorescent [counter2-yMovePositionHoldMain][counter3+xMovePositionHoldMain];
                                }
                                else arrayImageFileSave [counter2][counter3] = 0;
                            }
                        }
                        
                        singleTiffSave = [[SingleTiffSave alloc] init];
                        [singleTiffSave singleTiffLayerSave:imageSizeFluorescent:imageSizeFluorescent:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:(unsigned long)mode];
                        
                        for (int counter3 = 0; counter3 < imageSizeFluorescent+1; counter3++){
                            delete [] arrayImageFileSave [counter3];
                        }
                        
                        delete [] arrayImageFileSave;
                        
                        string *arrayUpDate = new string [maxImageNo*7+10];
                        
                        for (int counter1 = 0; counter1 < maxImageNo*7; counter1++) arrayUpDate [counter1] = fileList [counter1];
                        
                        delete [] fileList;
                        
                        fileList = new string [(maxImageNo+1)*7+4];
                        
                        for (int counter1 = 0; counter1 < maxImageNo*7; counter1++) fileList [counter1] = arrayUpDate [counter1];
                        delete [] arrayUpDate;
                        
                        fileNoBMPCount++;
                        lastTIFRoundNo++;
                        maxImageNo++;
                        
                        fileList [(maxImageNo-1)*7] = "STimage "+timePointNo+".TIF"+roundNo;
                        fileList [(maxImageNo-1)*7+1] = "STimage "+timePointNo+stringExtract+".TIF"+roundNo;
                        
                        [tableViewTDList reloadData];
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        string imageMoviePath = imageDisplayPath+"/"+"STimage "+timePointNo+".BMP"+roundNo;
                        
                        int totalEntryCount = 0;
                        int value1 = 0;
                        int valueTemp = 0;
                        int value2 = 0;
                        int value3 = 0;
                        int value4 = 0;
                        
                        int totalDataLength = imageSizeFluorescent*imageSizeFluorescent+1500;
                        
                        char *mainDataEntry = new char [totalDataLength];
                        
                        mainDataEntry [totalEntryCount] = 66, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 77, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 54, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 4, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 40, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        value1 = imageSizeFluorescent/16777216;
                        valueTemp = imageSizeFluorescent%16777216;
                        value2 = valueTemp/65536;
                        valueTemp = valueTemp%65536;
                        value3 = valueTemp/256;
                        valueTemp = valueTemp%256;
                        value4 = valueTemp;
                        
                        mainDataEntry [totalEntryCount] = (char)value4, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = (char)value3, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = (char)value2, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = (char)value1, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = (char)value4, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = (char)value3, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = (char)value2, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = (char)value1, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 1, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 8, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        value1 = imageSizeFluorescent*imageSizeFluorescent/16777216;
                        valueTemp = imageSizeFluorescent*imageSizeFluorescent/16777216;
                        value2 = valueTemp/65536;
                        valueTemp = valueTemp%65536;
                        value3 = valueTemp/256;
                        valueTemp = valueTemp%256;
                        value4 = valueTemp;
                        
                        mainDataEntry [totalEntryCount] = (char)value4, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = (char)value3, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = (char)value2, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = (char)value1, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        for (int counter2 = 0; counter2 <= 255; counter2++){
                            mainDataEntry [totalEntryCount] = (char)counter2, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)counter2, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)counter2, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        }
                        
                        for (int counter2 = imageSizeFluorescent-1; counter2 >= 0; counter2--){
                            for (int counter3 = 0; counter3 < imageSizeFluorescent; counter3++){
                                mainDataEntry [totalEntryCount] = (char)arrayDICImageForFluorescent [counter2][counter3], totalEntryCount++;
                            }
                        }
                        
                        mainDataEntry [totalEntryCount] = 88, totalEntryCount++;
                        
                        ofstream outfile2 (imageMoviePath.c_str(), ofstream::binary);
                        
                        if (outfile2.is_open()){
                            outfile2.write (mainDataEntry, totalEntryCount);
                            outfile2.close();
                        }
                        
                        totalEntryCount = 0;
                        
                        string stringExtract = selectedFile.substr(12, selectedFile.find(".BMP")-12);
                        
                        imageMoviePath = imageDisplayPath+"/"+"STimage "+timePointNo+stringExtract+".BMP"+roundNo;
                        
                        mainDataEntry [totalEntryCount] = 66, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 77, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 54, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 4, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 40, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        value1 = imageSizeFluorescent/16777216;
                        valueTemp = imageSizeFluorescent%16777216;
                        value2 = valueTemp/65536;
                        valueTemp = valueTemp%65536;
                        value3 = valueTemp/256;
                        valueTemp = valueTemp%256;
                        value4 = valueTemp;
                        
                        mainDataEntry [totalEntryCount] = (char)value4, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = (char)value3, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = (char)value2, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = (char)value1, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = (char)value4, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = (char)value3, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = (char)value2, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = (char)value1, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 1, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 8, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        value1 = imageSizeFluorescent*imageSizeFluorescent/16777216;
                        valueTemp = imageSizeFluorescent*imageSizeFluorescent%16777216;
                        value2 = valueTemp/65536;
                        valueTemp = valueTemp%65536;
                        value3 = valueTemp/256;
                        valueTemp = valueTemp%256;
                        value4 = valueTemp;
                        
                        mainDataEntry [totalEntryCount] = (char)value4, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = (char)value3, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = (char)value2, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = (char)value1, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        
                        for (int counter2 = 0; counter2 <= 255; counter2++){
                            mainDataEntry [totalEntryCount] = (char)counter2, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)counter2, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)counter2, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                        }
                        
                        for (int counter2 = imageSizeFluorescent-1; counter2 >= 0; counter2--){
                            for (int counter3 = 0; counter3 < imageSizeFluorescent; counter3++){
                                if (counter2-yMovePositionHoldMain >= 0 && counter2-yMovePositionHoldMain < imageSizeFluorescent && counter3+xMovePositionHoldMain >= 0 && counter3+xMovePositionHoldMain < imageSizeFluorescent){
                                    mainDataEntry [totalEntryCount] = (char)arrayReferenceImageFluorescent [counter2-yMovePositionHoldMain][counter3+xMovePositionHoldMain], totalEntryCount++;
                                }
                                else mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            }
                        }
                        
                        mainDataEntry [totalEntryCount] = 88, totalEntryCount++;
                        
                        ofstream outfile3 (imageMoviePath.c_str(), ofstream::binary);
                        
                        if (outfile3.is_open()){
                            outfile3.write (mainDataEntry, totalEntryCount);
                            outfile3.close();
                        }
                        
                        delete [] mainDataEntry;
                        
                        string *arrayUpDate = new string [maxImageNo*7+10];
                        
                        for (int counter1 = 0; counter1 < maxImageNo*7; counter1++) arrayUpDate [counter1] = fileList [counter1];
                        
                        delete [] fileList;
                        
                        fileList = new string [(maxImageNo+1)*7+4];
                        
                        for (int counter1 = 0; counter1 < maxImageNo*7; counter1++) fileList [counter1] = arrayUpDate [counter1];
                        delete [] arrayUpDate;
                        
                        fileNoBMPCount++;
                        lastTIFRoundNo++;
                        maxImageNo++;
                        
                        fileList [(maxImageNo-1)*7] = "STimage "+timePointNo+".BMP"+roundNo;
                        fileList [(maxImageNo-1)*7+1] = "STimage "+timePointNo+stringExtract+".BMP"+roundNo;
                        
                        [tableViewTDList reloadData];
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Copy In Progress"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"IF Image Not Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Image Selected or Movie On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"IF Image Not Found or Loaded Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)moveStatusSet:(id)sender{
    if (lastTIFRoundNo != 0 && imageLoadFlagFluorescent == 1){
        if (dicImageStatusFluorescent == 1 && referenceImageStatusFluorescent == 1){
            if (imageMoveStatusFluorescent == 1){
                imageMoveStatusFluorescent = 0;
                [moveStatusDiaplay setStringValue:@"Both"];
            }
            else if (imageMoveStatusFluorescent == 0){
                imageMoveStatusFluorescent = 1;
                [moveStatusDiaplay setStringValue:@"Fluo"];
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"IF Image Not Loaded"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"IF Image Not Found or Loaded Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageLoad:(id)sender{
    if (lastTIFRoundNo != 0 && imageLoadFlagFluorescent == 0){
        if (imageXYLength != 0 && movieRunningFlag == 0){
            if (copyProgressFlag == 0){
                if (dicImageStatusFluorescent == 1){
                    for (int counter1 = 0; counter1 < imageSizeFluorescent+5; counter1++){
                        delete [] arrayDICImageForFluorescent [counter1];
                    }
                    
                    delete [] arrayDICImageForFluorescent;
                }
                
                if (referenceImageStatusFluorescent == 1){
                    for (int counter1 = 0; counter1 < imageSizeFluorescent+5; counter1++){
                        delete [] arrayReferenceImageFluorescent [counter1];
                    }
                    
                    delete [] arrayReferenceImageFluorescent;
                    
                    referenceImageStatusFluorescent = 0;
                }
                
                imageSizeFluorescent = imageXYLength;
                
                arrayDICImageForFluorescent = new int *[imageSizeFluorescent+5];
                
                for (int counter1 = 0; counter1 < imageSizeFluorescent+5; counter1++){
                    arrayDICImageForFluorescent [counter1] = new int [imageSizeFluorescent+5];
                }
                
                dicImageStatusFluorescent = 1;
                
                fileTypeTifBmp = 0;
                
                if ((int)fileList [(lastDICImageTime-1)*7].find("tif") != -1) fileTypeTifBmp = 0;
                else if ((int)fileList [(lastDICImageTime-1)*7].find("bmp") != -1) fileTypeTifBmp = 1;
                
                string imageMoviePath = imageDisplayPath+"/"+fileList [(lastDICImageTime-1)*7];
                
                ifstream fin;
                
                if (fileTypeTifBmp == 0){
                    unsigned long stripFirstAddress = 0;
                    unsigned long stripByteCountAddress = 0;
                    unsigned long nextAddress = 0;
                    unsigned long headPosition = 0;
                    unsigned long stripEntry = 0;
                    long sizeForCopy = 0;
                    
                    double xPosition = 0;
                    double yPosition = 0;
                    
                    int imageWidth = 0;
                    int imageHeight = 0;
                    int imageBit = 0; // Check 8, 16
                    int imageCompression = 0; // Check 1
                    int photoMetric = 0; //check 0, 1, 2
                    int imageDimensionTif = 0;
                    int verticalBmp = 0;
                    int horizontalBmp = 0;
                    int horizontalBmpEntry = 0;
                    int endianType = 0;
                    int samplePerPix = 0;
                    int dataConversion [4];
                    int processTypeTif = 1;
                    int numberOfLayers = 0;
                    
                    struct stat sizeOfFile;
                    
                    if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        fileReadArray = new uint8_t [sizeForCopy+4];
                        fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                        
                        fin.read((char*)fileReadArray, sizeForCopy+4);
                        fin.close();
                        
                        dataConversion [0] = fileReadArray [0];
                        dataConversion [1] = fileReadArray [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        int *arrayExtractedImage3 = new int [100];
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = fileReadArray [7];
                            dataConversion [1] = fileReadArray [6];
                            dataConversion [2] = fileReadArray [5];
                            dataConversion [3] = fileReadArray [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = fileReadArray [4];
                            dataConversion [1] = fileReadArray [5];
                            dataConversion [2] = fileReadArray [6];
                            dataConversion [3] = fileReadArray [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        if (endianType == 1){
                            tiffFileRead = [[TiffFileRead alloc] init];
                            [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            
                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                else imageDimensionTif = imageHeight;
                                
                                tiffFileRead = [[TiffFileRead alloc] init];
                                delete [] arrayExtractedImage3;
                                
                                arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                            }
                        }
                        else if (endianType == 0){
                            tiffFileRead = [[TiffFileRead alloc] init];
                            [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            
                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                else imageDimensionTif = imageHeight;
                                
                                tiffFileRead = [[TiffFileRead alloc] init];
                                delete [] arrayExtractedImage3;
                                
                                arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                            }
                        }
                        
                        verticalBmp = 0;
                        horizontalBmp = 0;
                        horizontalBmpEntry = 0;
                        
                        for (int counter5 = 0; counter5 < imageWidth*imageHeight; counter5++){
                            if (verticalBmp < imageHeight){
                                if (horizontalBmp < imageWidth){
                                    arrayDICImageForFluorescent [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter5]), horizontalBmpEntry++;
                                    horizontalBmp++;
                                }
                                
                                if (horizontalBmp == imageWidth){
                                    horizontalBmp = 0;
                                    horizontalBmpEntry = 0;
                                    verticalBmp++;
                                }
                            }
                        }
                        
                        delete [] fileReadArray;
                        delete [] arrayExtractedImage3;
                    }
                }
                else{
                    
                    long sizeForCopy = 0;
                    
                    struct stat sizeOfFile;
                    
                    if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                        fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTempA, sizeForCopy+1);
                            fin.close();
                            
                            int imageDimensionReadCount = 0;
                            
                            for (int counter1 = imageSizeFluorescent-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageSizeFluorescent; counter2++){
                                    arrayDICImageForFluorescent [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageSizeFluorescent+counter2];
                                }
                                
                                imageDimensionReadCount++;
                            }
                        }
                        
                        delete [] uploadTempA;
                    }
                }
                
                fileNoBMPCount = 0;
                
                for (int counter1 = 1; counter1 <= maxImageNo; counter1++){
                    if (fileList [(counter1-1)*7+1] != ""){
                        if ((int)fileList [(counter1-1)*7+1].find("TIF") != -1 || (int)fileList [(counter1-1)*7+1].find("BMP") != -1) fileNoBMPCount++;
                        
                        if (fileList [(counter1-1)*7+2] != ""){
                            if ((int)fileList [(counter1-1)*7+2].find("TIF") != -1 || (int)fileList [(counter1-1)*7+2].find("BMP") != -1) fileNoBMPCount++;
                            
                            if (fileList [(counter1-1)*7+3] != ""){
                                if ((int)fileList [(counter1-1)*7+3].find("") != -1 || (int)fileList [(counter1-1)*7+3].find("BMP") != -1) fileNoBMPCount++;
                                
                                if (fileList [(counter1-1)*7+4] != ""){
                                    if ((int)fileList [(counter1-1)*7+4].find("") != -1 || (int)fileList [(counter1-1)*7+4].find("BMP") != -1) fileNoBMPCount++;
                                    
                                    if (fileList [(counter1-1)*7+5] != ""){
                                        if ((int)fileList [(counter1-1)*7+5].find("") != -1 || (int)fileList [(counter1-1)*7+5].find("BMP") != -1) fileNoBMPCount++;
                                        
                                        if (fileList [(counter1-1)*7+6] != ""){
                                            if ((int)fileList [(counter1-1)*7+6].find("") != -1 || (int)fileList [(counter1-1)*7+6].find("BMP") != -1) fileNoBMPCount++;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                selectedFile = "";
                fluorescentColorNoFluorescent = 0;
                imageLoadFlagFluorescent = 1;
                xMovePositionHoldMain = 0;
                yMovePositionHoldMain = 0;
                
                [tableViewTDList reloadData];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentAdjust object:self];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Copy In Progress"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Image Selected or Movie On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"IF Image Loaded"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderAction:(id)sender{
    if (imageLoadFlagFluorescent == 1){
        fluorescentEnhanceFluorescent = [sliderFluorescent doubleValue];
        
        int fluorescentEnhanceInt = (int)(fluorescentEnhanceFluorescent*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [fluorescentValueDisplay setDoubleValue:fluorescentEnhanceDouble];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentAdjust object:self];
    }
}

-(IBAction)sliderActionBase:(id)sender{
    if (imageLoadFlagFluorescent == 1){
        baseCutFluorescent = (int)[sliderBase doubleValue];
        
        int baseCutInt = (int)(baseCutFluorescent*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        
        [baseCutValueDisplay setDoubleValue:baseCutDouble];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentAdjust object:self];
    }
}

-(IBAction)sliderActionCircle:(id)sender{
    if (imageLoadFlagFluorescent == 1){
        double sliderCircleValue = sliderFluorescentMax*[sliderFluorescentCircle doubleValue];
        double sliderCircleValue2 = sliderFluorescentMin/[sliderFluorescentCircle doubleValue];
        double sliderValue = [sliderFluorescent doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderFluorescentDiff;
        
        sliderCircleValue = sliderValue+(sliderFluorescentMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderFluorescentMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderFluorescent setMaxValue:sliderCircleValue];
        [sliderFluorescent setMinValue:sliderCircleValue2];
        
        int fluorescentEnhanceInt = (int)([sliderFluorescent doubleValue]*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [fluorescentValueDisplay setDoubleValue:fluorescentEnhanceDouble];
    }
}

-(IBAction)sliderActionBaseCircle:(id)sender{
    if (imageLoadFlagFluorescent == 1){
        double sliderCircleValue = sliderBaseMax*[sliderBaseCircle doubleValue];
        double sliderCircleValue2 = sliderBaseMin/[sliderBaseCircle doubleValue];
        double sliderValue = [sliderBase doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderBaseDiff;
        
        sliderCircleValue = sliderValue+(sliderBaseMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderBaseMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderBase setMaxValue:sliderCircleValue];
        [sliderBase setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderBase doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [baseCutValueDisplay setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)clearFluorescent:(id)sender{
    if (imageLoadFlagFluorescent == 1){
        baseCutFluorescent = 50;
        fluorescentEnhanceFluorescent = 1;
        
        int baseCutInt = (int)(baseCutFluorescent*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        int fluorescentEnhanceInt = (int)(fluorescentEnhanceFluorescent*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [baseCutValueDisplay setDoubleValue:baseCutDouble];
        [fluorescentValueDisplay setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderFluorescent setDoubleValue:1];
        [sliderBase setDoubleValue:50];
        [sliderFluorescentCircle setDoubleValue:1];
        [sliderBaseCircle setDoubleValue:1];
        
        [sliderFluorescent setMaxValue:sliderFluorescentMax];
        [sliderFluorescent setMinValue:sliderFluorescentMin];
        
        [sliderBase setMaxValue:sliderBaseMax];
        [sliderBase setMinValue:sliderBaseMin];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentAdjust object:self];
    }
}

-(IBAction)changeOrder:(id)sender{
    if (copyProgressFlag == 0){
        if (lastTIFRoundNo != 0 && imageLoadFlagFluorescent == 1){
            string fileNameGet1 = "";
            string fileNameGet2 = "";
            string fileNameGet3 = "";
            string fileNameGet4 = "";
            string fileNameGet5 = "";
            string fileNameGet6 = "";
            string fileNameGet7 = "";
            
            int timePointStart = 0;
            int bmpFindFlag = 0;
            
            for (int counter1 = 1; counter1 <= maxImageNo; counter1++){
                if (fileList [(counter1-1)*7+1] != ""){
                    if ((int)fileList [(counter1-1)*7+1].find("TIF") != -1 || (int)fileList [(counter1-1)*7+1].find("BMP") != -1){
                        if (timePointStart == 0) timePointStart = atoi(fileList [(counter1-1)*7].substr(8, 4).c_str());
                        
                        if (bmpFindFlag == tableCurrentFluRowHold){
                            fileNameGet1 = fileList [(counter1-1)*7];
                            fileNameGet2 = fileList [(counter1-1)*7+1];
                            fileNameGet3 = fileList [(counter1-1)*7+2];
                            fileNameGet4 = fileList [(counter1-1)*7+3];
                            fileNameGet5 = fileList [(counter1-1)*7+4];
                            fileNameGet6 = fileList [(counter1-1)*7+5];
                            fileNameGet7 = fileList [(counter1-1)*7+6];
                            break;
                        }
                        else bmpFindFlag++;
                    }
                    
                    if (fileList [(counter1-1)*7+2] != ""){
                        if ((int)fileList [(counter1-1)*7+2].find("TIF") != -1 || (int)fileList [(counter1-1)*7+2].find("BMP") != -1){
                            if (bmpFindFlag == tableCurrentFluRowHold){
                                fileNameGet1 = fileList [(counter1-1)*7];
                                fileNameGet2 = fileList [(counter1-1)*7+1];
                                fileNameGet3 = fileList [(counter1-1)*7+2];
                                fileNameGet4 = fileList [(counter1-1)*7+3];
                                fileNameGet5 = fileList [(counter1-1)*7+4];
                                fileNameGet6 = fileList [(counter1-1)*7+5];
                                fileNameGet7 = fileList [(counter1-1)*7+6];
                                break;
                            }
                            else bmpFindFlag++;
                        }
                        
                        if (fileList [(counter1-1)*7+3] != ""){
                            if ((int)fileList [(counter1-1)*7+3].find("TIF") != -1 || (int)fileList [(counter1-1)*7+3].find("BMP") != -1){
                                if (bmpFindFlag == tableCurrentFluRowHold){
                                    fileNameGet1 = fileList [(counter1-1)*7];
                                    fileNameGet2 = fileList [(counter1-1)*7+1];
                                    fileNameGet3 = fileList [(counter1-1)*7+2];
                                    fileNameGet4 = fileList [(counter1-1)*7+3];
                                    fileNameGet5 = fileList [(counter1-1)*7+4];
                                    fileNameGet6 = fileList [(counter1-1)*7+5];
                                    fileNameGet7 = fileList [(counter1-1)*7+6];
                                    break;
                                }
                                else bmpFindFlag++;
                            }
                        }
                        
                        if (fileList [(counter1-1)*7+4] != ""){
                            if ((int)fileList [(counter1-1)*7+4].find("TIF") != -1 || (int)fileList [(counter1-1)*7+4].find("BMP") != -1){
                                if (bmpFindFlag == tableCurrentFluRowHold){
                                    fileNameGet1 = fileList [(counter1-1)*7];
                                    fileNameGet2 = fileList [(counter1-1)*7+1];
                                    fileNameGet3 = fileList [(counter1-1)*7+2];
                                    fileNameGet4 = fileList [(counter1-1)*7+3];
                                    fileNameGet5 = fileList [(counter1-1)*7+4];
                                    fileNameGet6 = fileList [(counter1-1)*7+5];
                                    fileNameGet7 = fileList [(counter1-1)*7+6];
                                    break;
                                }
                                else bmpFindFlag++;
                            }
                            
                            if (fileList [(counter1-1)*7+5] != ""){
                                if ((int)fileList [(counter1-1)*7+5].find("TIF") != -1 || (int)fileList [(counter1-1)*7+5].find("BMP") != -1){
                                    if (bmpFindFlag == tableCurrentFluRowHold){
                                        fileNameGet1 = fileList [(counter1-1)*7];
                                        fileNameGet2 = fileList [(counter1-1)*7+1];
                                        fileNameGet3 = fileList [(counter1-1)*7+2];
                                        fileNameGet4 = fileList [(counter1-1)*7+3];
                                        fileNameGet5 = fileList [(counter1-1)*7+4];
                                        fileNameGet6 = fileList [(counter1-1)*7+5];
                                        fileNameGet7 = fileList [(counter1-1)*7+6];
                                        break;
                                    }
                                    else bmpFindFlag++;
                                }
                                
                                if ((int)fileList [(counter1-1)*7+6].find("TIF") != -1 || (int)fileList [(counter1-1)*7+6].find("BMP") != -1){
                                    if (bmpFindFlag == tableCurrentFluRowHold){
                                        fileNameGet1 = fileList [(counter1-1)*7];
                                        fileNameGet2 = fileList [(counter1-1)*7+1];
                                        fileNameGet3 = fileList [(counter1-1)*7+2];
                                        fileNameGet4 = fileList [(counter1-1)*7+3];
                                        fileNameGet5 = fileList [(counter1-1)*7+4];
                                        fileNameGet6 = fileList [(counter1-1)*7+5];
                                        fileNameGet7 = fileList [(counter1-1)*7+6];
                                        break;
                                    }
                                    else bmpFindFlag++;
                                }
                            }
                        }
                    }
                }
            }
            
            string *fileNameListTemp = new string [(fileNoBMPCount+1)*7+7];
            string *fileNameListTemp2 = new string [(fileNoBMPCount+1)*7+7];
            int *roundNoList = new int [fileNoBMPCount+2];
            int *timePointList = new int [maxImageNo+2];
            
            for (int counter1 = 0; counter1 < (fileNoBMPCount+1)*7+7; counter1++){
                fileNameListTemp [counter1] = "";
                fileNameListTemp2 [counter1] = "";
            }
            
            for (int counter1 = 0; counter1 < fileNoBMPCount+2; counter1++) roundNoList [counter1] = 0;
            
            for (int counter1 = 0; counter1 < maxImageNo+2; counter1++) timePointList [counter1] = 0;
            
            int fileEntryCount = 7;
            
            fileNameListTemp [0] = fileNameGet1;
            fileNameListTemp [1] = fileNameGet2;
            fileNameListTemp [2] = fileNameGet3;
            fileNameListTemp [3] = fileNameGet4;
            fileNameListTemp [4] = fileNameGet5;
            fileNameListTemp [5] = fileNameGet6;
            fileNameListTemp [6] = fileNameGet7;
            
            for (int counter1 = 1; counter1 <= maxImageNo; counter1++){
                if (((int)fileList [(counter1-1)*7+1].find("TIF") != -1 || (int)fileList [(counter1-1)*7+1].find("BMP") != -1) && fileList [(counter1-1)*7] != fileNameGet1){
                    fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7], fileEntryCount++;
                    fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+1], fileEntryCount++;
                    fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+2], fileEntryCount++;
                    fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+3], fileEntryCount++;
                    fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+4], fileEntryCount++;
                    fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+5], fileEntryCount++;
                    fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+6], fileEntryCount++;
                }
            }
            
            //for (int counter1 = 0; counterA < fileEntryCount/7; counterA++){
            //    cout<<counterA<<" "<<fileNameListTemp [counterA*7]<<" "<<fileNameListTemp [counterA*7+1]<<" "<<fileNameListTemp [counterA*7+2]<<" "<<fileNameListTemp [counterA*7+3]<<" "<<fileNameListTemp [counterA*7+4]<<" "<<fileNameListTemp [counterA*7+5]<<" "<<fileNameListTemp [counterA*7+6]<<" List"<<endl;
            //}
            
            for (int counter1 = 7; counter1 < fileNoBMPCount*7; counter1++){
                if (fileNameListTemp [counter1] != ""){
                    if (fileTypeTifBmp == 0){
                        roundNoList [atoi(fileNameListTemp [counter1].substr(fileNameListTemp [counter1].find("TIF")+4).c_str())]++;
                        timePointList [atoi(fileNameListTemp [counter1].substr(8, 4).c_str())]++;
                    }
                    else{
                        
                        roundNoList [atoi(fileNameListTemp [counter1].substr(fileNameListTemp [counter1].find("BMP")+4).c_str())]++;
                        timePointList [atoi(fileNameListTemp [counter1].substr(8, 4).c_str())]++;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < fileNoBMPCount+2; counterA++){
            //    cout<<counterA<<" "<<roundNoList [counterA]<<" roundNoList "<<endl;
            //}
            
            //for (int counterA = 0; counterA < maxImageNo+2; counterA++){
            //    cout<<counterA<<" "<<timePointList [counterA]<<" timePointList "<<endl;
            //}
            
            int newRoundNo = 2;
            int newTimeNo = timePointStart+1;
            
            for (int counter1 = 0; counter1 < fileNoBMPCount+2; counter1++){
                if (roundNoList [counter1] != 0){
                    roundNoList [counter1] = newRoundNo;
                    newRoundNo++;
                }
            }
            
            for (int counter1 = 0; counter1 < maxImageNo+2; counter1++){
                if (timePointList [counter1] != 0){
                    timePointList [counter1] = newTimeNo;
                    newTimeNo++;
                }
            }
            
            string timePointString = to_string(timePointStart);
            string roundString;
            int fileEntryCount2 = 0;
            int maxNoTemp = 0;
            
            DIR *dir;
            struct dirent *dent;
            
            if (timePointString.length() == 1) timePointString = "000"+timePointString;
            else if (timePointString.length() == 2) timePointString = "00"+timePointString;
            else if (timePointString.length() == 3) timePointString = "0"+timePointString;
            
            if (fileTypeTifBmp == 0){
                string sourceFileName = imageDisplayPath+"/"+fileNameGet1;
                string destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+".TIF01";
                fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+".TIF01", fileEntryCount2++;
                
                rename (sourceFileName.c_str(), destinationFileName.c_str());
                
                string colorName = fileNameGet2.substr(12, fileNameGet2.find(".TIF")-12);
                sourceFileName = imageDisplayPath+"/"+fileNameGet2;
                destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+colorName+".TIF01";
                
                fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+colorName+".TIF01", fileEntryCount2++;
                
                rename (sourceFileName.c_str(), destinationFileName.c_str());
                
                if (fileNameGet3 != ""){
                    colorName = fileNameGet3.substr(12, fileNameGet3.find(".TIF")-12);
                    sourceFileName = imageDisplayPath+"/"+fileNameGet3;
                    destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+colorName+".TIF01";
                    
                    fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+colorName+".TIF01", fileEntryCount2++;
                    
                    rename (sourceFileName.c_str(), destinationFileName.c_str());
                }
                
                if (fileNameGet4 != ""){
                    colorName = fileNameGet4.substr(12, fileNameGet4.find(".TIF")-12);
                    sourceFileName = imageDisplayPath+"/"+fileNameGet4;
                    destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+colorName+".TIF01";
                    
                    fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+colorName+".TIF01", fileEntryCount2++;
                    
                    rename (sourceFileName.c_str(), destinationFileName.c_str());
                }
                
                if (fileNameGet5 != ""){
                    colorName = fileNameGet5.substr(12, fileNameGet5.find(".TIF")-12);
                    sourceFileName = imageDisplayPath+"/"+fileNameGet5;
                    destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+colorName+".TIF01";
                    
                    fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+colorName+".TIF01", fileEntryCount2++;
                    
                    rename (sourceFileName.c_str(), destinationFileName.c_str());
                }
                
                if (fileNameGet6 != ""){
                    colorName = fileNameGet6.substr(12, fileNameGet6.find(".TIF")-12);
                    sourceFileName = imageDisplayPath+"/"+fileNameGet6;
                    destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+colorName+".TIF01";
                    
                    fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+colorName+".TIF01", fileEntryCount2++;
                    
                    rename (sourceFileName.c_str(), destinationFileName.c_str());
                }
                
                if (fileNameGet7 != ""){
                    colorName = fileNameGet7.substr(12, fileNameGet7.find(".TIF")-12);
                    sourceFileName = imageDisplayPath+"/"+fileNameGet7;
                    destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+colorName+".TIF01";
                    
                    fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+colorName+".TIF01", fileEntryCount2++;
                    
                    rename (sourceFileName.c_str(), destinationFileName.c_str());
                }
                
                int timePointSet = 0;
                int roundSet = 0;
                
                for (int counter1 = 7; counter1 < fileNoBMPCount*7; counter1++){
                    if (fileNameListTemp [counter1] != "" && (int)fileNameListTemp [counter1].find ("TIF") == -1){
                        timePointSet = atoi(fileNameListTemp [counter1].substr(8, 4).c_str());
                        roundSet = atoi(fileNameListTemp [counter1].substr(fileNameListTemp [counter1].find("TIF")+3).c_str());
                        
                        timePointString = to_string(timePointList [timePointSet]);
                        roundString = to_string(roundNoList [roundSet]);
                        
                        if (timePointString.length() == 1) timePointString = "000"+timePointString;
                        else if (timePointString.length() == 2) timePointString = "00"+timePointString;
                        else if (timePointString.length() == 3) timePointString = "0"+timePointString;
                        
                        if (roundString.length() == 1) roundString = "0"+roundString;
                        
                        sourceFileName = imageDisplayPath+"/"+fileNameListTemp [counter1];
                        destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+".TIF"+roundString;
                        
                        fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+".TIF"+roundString, fileEntryCount2++;
                        
                        rename (sourceFileName.c_str(), destinationFileName.c_str());
                    }
                    else if (fileNameListTemp [counter1] != "" && (int)fileNameListTemp [counter1].find ("TIF") != -1){
                        timePointSet = atoi(fileNameListTemp [counter1].substr(8, 4).c_str());
                        roundSet = atoi(fileNameListTemp [counter1].substr(fileNameListTemp [counter1].find("TIF")+3).c_str());
                        colorName = fileNameListTemp [counter1].substr(12, fileNameListTemp [counter1].find(".TIF")-12);
                        
                        timePointString = to_string(timePointList [timePointSet]);
                        roundString = to_string(roundNoList [roundSet]);
                        
                        if (timePointString.length() == 1) timePointString = "000"+timePointString;
                        else if (timePointString.length() == 2) timePointString = "00"+timePointString;
                        else if (timePointString.length() == 3) timePointString = "0"+timePointString;
                        
                        if (roundString.length() == 1) roundString = "0"+roundString;
                        
                        sourceFileName = imageDisplayPath+"/"+fileNameListTemp [counter1];
                        destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+colorName+".TIF"+roundString;
                        
                        fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+colorName+".TIF"+roundString, fileEntryCount2++;
                        
                        rename (sourceFileName.c_str(), destinationFileName.c_str());
                    }
                }
                
                for (int counter1 = 0; counter1 < fileEntryCount2; counter1++){
                    sourceFileName = imageDisplayPath+"/"+fileNameListTemp2 [counter1];
                    destinationFileName = imageDisplayPath+"/"+fileNameListTemp2 [counter1].substr(1);
                    
                    rename (sourceFileName.c_str(), destinationFileName.c_str());
                }
                
                string imageNoTemp;
                lastTIFRoundNo = 0;
                
                dir = opendir(imageDisplayPath.c_str());
                
                if (dir != NULL){
                    string entry;
                    
                    while((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("STimage") != -1){
                                imageNoTemp = entry.substr(8, 4);
                                
                                if (atoi(imageNoTemp.c_str()) > maxNoTemp) maxNoTemp = atoi(imageNoTemp.c_str());
                                if ((int)entry.find("TIF") != -1 && lastTIFRoundNo < atoi(entry.substr(entry.find("TIF")+3).c_str())){
                                    lastTIFRoundNo = atoi(entry.substr(entry.find("TIF")+3).c_str());
                                }
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                maxImageNo = maxNoTemp;
            }
            else{
                
                string sourceFileName = imageDisplayPath+"/"+fileNameGet1;
                string destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+".BMP01";
                fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+".BMP01", fileEntryCount2++;
                
                rename (sourceFileName.c_str(), destinationFileName.c_str());
                
                string colorName = fileNameGet2.substr(12, fileNameGet2.find(".BMP")-12);
                sourceFileName = imageDisplayPath+"/"+fileNameGet2;
                destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+colorName+".BMP01";
                
                fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+colorName+".BMP01", fileEntryCount2++;
                
                rename (sourceFileName.c_str(), destinationFileName.c_str());
                
                if (fileNameGet3 != ""){
                    colorName = fileNameGet3.substr(12, fileNameGet3.find(".BMP")-12);
                    sourceFileName = imageDisplayPath+"/"+fileNameGet3;
                    destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+colorName+".BMP01";
                    
                    fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+colorName+".BMP01", fileEntryCount2++;
                    
                    rename (sourceFileName.c_str(), destinationFileName.c_str());
                }
                
                if (fileNameGet4 != ""){
                    colorName = fileNameGet4.substr(12, fileNameGet4.find(".BMP")-12);
                    sourceFileName = imageDisplayPath+"/"+fileNameGet4;
                    destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+colorName+".BMP01";
                    
                    fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+colorName+".BMP01", fileEntryCount2++;
                    
                    rename (sourceFileName.c_str(), destinationFileName.c_str());
                }
                
                int timePointSet = 0;
                int roundSet = 0;
                
                for (int counter1 = 7; counter1 < fileNoBMPCount*7; counter1++){
                    if (fileNameListTemp [counter1] != "" && (int)fileNameListTemp [counter1].find ("BMP") == -1){
                        timePointSet = atoi(fileNameListTemp [counter1].substr(8, 4).c_str());
                        roundSet = atoi(fileNameListTemp [counter1].substr(fileNameListTemp [counter1].find("BMP")+3).c_str());
                        
                        timePointString = to_string(timePointList [timePointSet]);
                        roundString = to_string(roundNoList [roundSet]);
                        
                        if (timePointString.length() == 1) timePointString = "000"+timePointString;
                        else if (timePointString.length() == 2) timePointString = "00"+timePointString;
                        else if (timePointString.length() == 3) timePointString = "0"+timePointString;
                        
                        if (roundString.length() == 1) roundString = "0"+roundString;
                        
                        sourceFileName = imageDisplayPath+"/"+fileNameListTemp [counter1];
                        destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+".BMP"+roundString;
                        
                        fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+".BMP"+roundString, fileEntryCount2++;
                        
                        rename (sourceFileName.c_str(), destinationFileName.c_str());
                    }
                    else if (fileNameListTemp [counter1] != "" && (int)fileNameListTemp [counter1].find ("BMP") != -1){
                        timePointSet = atoi(fileNameListTemp [counter1].substr(8, 4).c_str());
                        roundSet = atoi(fileNameListTemp [counter1].substr(fileNameListTemp [counter1].find("BMP")+3).c_str());
                        colorName = fileNameListTemp [counter1].substr(12, fileNameListTemp [counter1].find(".BMP")-12);
                        
                        timePointString = to_string(timePointList [timePointSet]);
                        roundString = to_string(roundNoList [roundSet]);
                        
                        if (timePointString.length() == 1) timePointString = "000"+timePointString;
                        else if (timePointString.length() == 2) timePointString = "00"+timePointString;
                        else if (timePointString.length() == 3) timePointString = "0"+timePointString;
                        
                        if (roundString.length() == 1) roundString = "0"+roundString;
                        
                        sourceFileName = imageDisplayPath+"/"+fileNameListTemp [counter1];
                        destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+colorName+".BMP"+roundString;
                        
                        fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+colorName+".BMP"+roundString, fileEntryCount2++;
                        
                        rename (sourceFileName.c_str(), destinationFileName.c_str());
                    }
                }
                
                for (int counter1 = 0; counter1 < fileEntryCount2; counter1++){
                    sourceFileName = imageDisplayPath+"/"+fileNameListTemp2 [counter1];
                    destinationFileName = imageDisplayPath+"/"+fileNameListTemp2 [counter1].substr(1);
                    
                    rename (sourceFileName.c_str(), destinationFileName.c_str());
                }
                
                string imageNoTemp;
                lastTIFRoundNo = 0;
                
                dir = opendir(imageDisplayPath.c_str());
                
                if (dir != NULL){
                    string entry;
                    
                    while((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("STimage") != -1){
                                imageNoTemp = entry.substr(8, 4);
                                
                                if (atoi(imageNoTemp.c_str()) > maxNoTemp) maxNoTemp = atoi(imageNoTemp.c_str());
                                if ((int)entry.find("BMP") != -1 && lastTIFRoundNo < atoi(entry.substr(entry.find("BMP")+3).c_str())){
                                    lastTIFRoundNo = atoi(entry.substr(entry.find("BMP")+3).c_str());
                                }
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                maxImageNo = maxNoTemp;
            }
            
            delete [] fileList;
            
            fileList = new string [maxImageNo*7+4];
            fileListCount = 0;
            
            string *fileListTemp = new string [maxNoTemp*7+4];
            int fileListTempCount = 0;
            
            dir = opendir(imageDisplayPath.c_str());
            
            if (dir != NULL){
                string entry;
                
                while((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if ((int)entry.find("STimage") != -1){
                            fileListTemp [fileListTempCount] = entry, fileListTempCount++;
                        }
                    }
                }
                
                closedir(dir);
            }
            
            //-----Directory Sort----
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < fileListTempCount; counter1++){
                [unsortedArray addObject:@(fileListTemp [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                fileListTemp [counter1] = [unsortedArray [counter1] UTF8String];
            }
            
            for (int counter1 = 0; counter1 < fileListTempCount; counter1++){
                if ((int)fileListTemp [counter1].find("_") == -1){
                    fileList [fileListCount] = fileListTemp [counter1], fileListCount++;
                    fileList [fileListCount] = "", fileListCount++;
                    fileList [fileListCount] = "", fileListCount++;
                    fileList [fileListCount] = "", fileListCount++;
                    fileList [fileListCount] = "", fileListCount++;
                    fileList [fileListCount] = "", fileListCount++;
                    fileList [fileListCount] = "", fileListCount++;
                }
            }
            
            //for (int counterA = 0; counterA < fileListCount/4; counterA++){
            //    cout<<counterA<<" "<<fileList [counterA*7]<<" "<<fileList [counterA*7+1]<<" "<<fileList [counterA*7+2]<<" "<<fileList [counterA*7+3]<<" List"<<endl;
            //}
            
            int timePosition = 0;
            
            for (int counter1 = 0; counter1 < fileListTempCount; counter1++){
                if ((int)fileListTemp [counter1].find("_1_") != -1 || (int)fileListTemp [counter1].find("_2_") != -1 || (int)fileListTemp [counter1].find("_3_") != -1 || (int)fileListTemp [counter1].find("_4_") != -1 || (int)fileListTemp [counter1].find("_5_") != -1 || (int)fileListTemp [counter1].find("_6_") != -1 || (int)fileListTemp [counter1].find("_7_") != -1 || (int)fileListTemp [counter1].find("_8_") != -1 || (int)fileListTemp [counter1].find("_9_") != -1){
                    timePosition = atoi(fileListTemp [counter1].substr(fileListTemp [counter1].find("STimage ")+8, 4).c_str())-1;
                    
                    if (fileList [timePosition*7+1] == "") fileList [timePosition*7+1] = fileListTemp [counter1];
                    else if (fileList [timePosition*7+2] == "") fileList [timePosition*7+2] = fileListTemp [counter1];
                    else if (fileList [timePosition*7+3] == "") fileList [timePosition*7+3] = fileListTemp [counter1];
                    else if (fileList [timePosition*7+4] == "") fileList [timePosition*7+4] = fileListTemp [counter1];
                    else if (fileList [timePosition*7+5] == "") fileList [timePosition*7+5] = fileListTemp [counter1];
                    else if (fileList [timePosition*7+6] == "") fileList [timePosition*7+6] = fileListTemp [counter1];
                }
            }
            
            delete [] fileListTemp;
            
            fileNoBMPCount = 0;
            
            for (int counter1 = 1; counter1 <= maxImageNo; counter1++){
                if (fileList [(counter1-1)*7+1] != ""){
                    if ((int)fileList [(counter1-1)*7+1].find("TIF") != -1 || (int)fileList [(counter1-1)*7+1].find("BMP") != -1) fileNoBMPCount++;
                    
                    if (fileList [(counter1-1)*7+2] != ""){
                        if ((int)fileList [(counter1-1)*7+2].find("TIF") != -1 || (int)fileList [(counter1-1)*7+2].find("BMP") != -1) fileNoBMPCount++;
                        
                        if (fileList [(counter1-1)*7+3] != ""){
                            if ((int)fileList [(counter1-1)*7+3].find("TIF") != -1 || (int)fileList [(counter1-1)*7+3].find("BMP") != -1) fileNoBMPCount++;
                            
                            if (fileList [(counter1-1)*7+4] != ""){
                                if ((int)fileList [(counter1-1)*7+4].find("TIF") != -1 || (int)fileList [(counter1-1)*7+4].find("BMP") != -1) fileNoBMPCount++;
                                
                                if (fileList [(counter1-1)*7+5] != ""){
                                    if ((int)fileList [(counter1-1)*7+5].find("TIF") != -1 || (int)fileList [(counter1-1)*7+5].find("BMP") != -1) fileNoBMPCount++;
                                    
                                    if (fileList [(counter1-1)*7+6] != ""){
                                        if ((int)fileList [(counter1-1)*7+6].find("TIF") != -1 || (int)fileList [(counter1-1)*7+6].find("BMP") != -1) fileNoBMPCount++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            delete [] fileNameListTemp;
            delete [] fileNameListTemp2;
            delete [] roundNoList;
            delete [] timePointList;
            
            selectedFile = "";
            fluorescentColorNoFluorescent = 0;
            xMovePositionHoldMain = 0;
            yMovePositionHoldMain = 0;
            referenceImageStatusFluorescent = 0;
            
            [tableViewTDList reloadData];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentAdjust object:self];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"IF Image Loaded"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)deleteEntry:(id)sender{
    if (copyProgressFlag == 0){
        if (lastTIFRoundNo != 0 && imageLoadFlagFluorescent == 1){
            if (lastTIFRoundNo > 1){
                string fileNameGet1 = "";
                string fileNameGet2 = "";
                string fileNameGet3 = "";
                string fileNameGet4 = "";
                string fileNameGet5 = "";
                string fileNameGet6 = "";
                string fileNameGet7 = "";
                
                int timePointStart = 0;
                int bmpFindFlag = 0;
                
                for (int counter1 = 1; counter1 <= maxImageNo; counter1++){
                    if (fileList [(counter1-1)*7+1] != ""){
                        if ((int)fileList [(counter1-1)*7+1].find("TIF") != -1 || (int)fileList [(counter1-1)*7+1].find("BMP") != -1){
                            if (timePointStart == 0) timePointStart = atoi(fileList [(counter1-1)*7].substr(8, 4).c_str());
                            
                            if (bmpFindFlag == tableCurrentFluRowHold){
                                fileNameGet1 = fileList [(counter1-1)*7];
                                fileNameGet2 = fileList [(counter1-1)*7+1];
                                fileNameGet3 = fileList [(counter1-1)*7+2];
                                fileNameGet4 = fileList [(counter1-1)*7+3];
                                fileNameGet5 = fileList [(counter1-1)*7+4];
                                fileNameGet6 = fileList [(counter1-1)*7+5];
                                fileNameGet7 = fileList [(counter1-1)*7+6];
                                break;
                            }
                            else bmpFindFlag++;
                        }
                        
                        if (fileList [(counter1-1)*7+2] != ""){
                            if ((int)fileList [(counter1-1)*7+2].find("TIF") != -1 || (int)fileList [(counter1-1)*7+2].find("BMP") != -1){
                                if (bmpFindFlag == tableCurrentFluRowHold){
                                    fileNameGet1 = fileList [(counter1-1)*7];
                                    fileNameGet2 = fileList [(counter1-1)*7+1];
                                    fileNameGet3 = fileList [(counter1-1)*7+2];
                                    fileNameGet4 = fileList [(counter1-1)*7+3];
                                    fileNameGet5 = fileList [(counter1-1)*7+4];
                                    fileNameGet6 = fileList [(counter1-1)*7+5];
                                    fileNameGet7 = fileList [(counter1-1)*7+6];
                                    break;
                                }
                                else bmpFindFlag++;
                            }
                            
                            if (fileList [(counter1-1)*7+3] != ""){
                                if ((int)fileList [(counter1-1)*7+3].find("TIF") != -1 || (int)fileList [(counter1-1)*7+3].find("BMP") != -1){
                                    if (bmpFindFlag == tableCurrentFluRowHold){
                                        fileNameGet1 = fileList [(counter1-1)*7];
                                        fileNameGet2 = fileList [(counter1-1)*7+1];
                                        fileNameGet3 = fileList [(counter1-1)*7+2];
                                        fileNameGet4 = fileList [(counter1-1)*7+3];
                                        fileNameGet5 = fileList [(counter1-1)*7+4];
                                        fileNameGet6 = fileList [(counter1-1)*7+5];
                                        fileNameGet7 = fileList [(counter1-1)*7+6];
                                        break;
                                    }
                                    else bmpFindFlag++;
                                }
                                
                                if (fileList [(counter1-1)*7+4] != ""){
                                    if ((int)fileList [(counter1-1)*7+4].find("TIF") != -1 || (int)fileList [(counter1-1)*7+4].find("BMP") != -1){
                                        if (bmpFindFlag == tableCurrentFluRowHold){
                                            fileNameGet1 = fileList [(counter1-1)*7];
                                            fileNameGet2 = fileList [(counter1-1)*7+1];
                                            fileNameGet3 = fileList [(counter1-1)*7+2];
                                            fileNameGet4 = fileList [(counter1-1)*7+3];
                                            fileNameGet5 = fileList [(counter1-1)*7+4];
                                            fileNameGet6 = fileList [(counter1-1)*7+5];
                                            fileNameGet7 = fileList [(counter1-1)*7+6];
                                            break;
                                        }
                                        else bmpFindFlag++;
                                    }
                                    
                                    if (fileList [(counter1-1)*7+5] != ""){
                                        if ((int)fileList [(counter1-1)*7+5].find("TIF") != -1 || (int)fileList [(counter1-1)*7+5].find("BMP") != -1){
                                            if (bmpFindFlag == tableCurrentFluRowHold){
                                                fileNameGet1 = fileList [(counter1-1)*7];
                                                fileNameGet2 = fileList [(counter1-1)*7+1];
                                                fileNameGet3 = fileList [(counter1-1)*7+2];
                                                fileNameGet4 = fileList [(counter1-1)*7+3];
                                                fileNameGet5 = fileList [(counter1-1)*7+4];
                                                fileNameGet6 = fileList [(counter1-1)*7+5];
                                                fileNameGet7 = fileList [(counter1-1)*7+6];
                                                break;
                                            }
                                            else bmpFindFlag++;
                                        }
                                        
                                        if (fileList [(counter1-1)*7+6] != ""){
                                            if ((int)fileList [(counter1-1)*7+6].find("TIF") != -1 || (int)fileList [(counter1-1)*7+6].find("BMP") != -1){
                                                if (bmpFindFlag == tableCurrentFluRowHold){
                                                    fileNameGet1 = fileList [(counter1-1)*7];
                                                    fileNameGet2 = fileList [(counter1-1)*7+1];
                                                    fileNameGet3 = fileList [(counter1-1)*7+2];
                                                    fileNameGet4 = fileList [(counter1-1)*7+3];
                                                    fileNameGet5 = fileList [(counter1-1)*7+4];
                                                    fileNameGet6 = fileList [(counter1-1)*7+5];
                                                    fileNameGet7 = fileList [(counter1-1)*7+6];
                                                    break;
                                                }
                                                else bmpFindFlag++;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                string *fileNameListTemp = new string [(fileNoBMPCount+1)*7+7];
                string *fileNameListTemp2 = new string [(fileNoBMPCount+1)*7+7];
                int *roundNoList = new int [fileNoBMPCount+2];
                int *timePointList = new int [maxImageNo+2];
                
                for (int counter1 = 0; counter1 < (fileNoBMPCount+1)*7+7; counter1++){
                    fileNameListTemp [counter1] = "";
                    fileNameListTemp2 [counter1] = "";
                }
                
                for (int counter1 = 0; counter1 < fileNoBMPCount+2; counter1++) roundNoList [counter1] = 0;
                
                for (int counter1 = 0; counter1 < maxImageNo+2; counter1++) timePointList [counter1] = 0;
                
                int fileEntryCount = 0;
                
                for (int counter1 = 1; counter1 <= maxImageNo; counter1++){
                    if (((int)fileList [(counter1-1)*7+1].find("TIF") != -1 || (int)fileList [(counter1-1)*7+1].find("BMP") != -1) && fileList [(counter1-1)*7] != fileNameGet1){
                        fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7], fileEntryCount++;
                        fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+1], fileEntryCount++;
                        fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+2], fileEntryCount++;
                        fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+3], fileEntryCount++;
                        fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+4], fileEntryCount++;
                        fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+5], fileEntryCount++;
                        fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+6], fileEntryCount++;
                    }
                }
                
                for (int counter1 = 0; counter1 < fileNoBMPCount*7; counter1++){
                    if (fileNameListTemp [counter1] != ""){
                        if (fileTypeTifBmp == 0){
                            roundNoList [atoi(fileNameListTemp [counter1].substr(fileNameListTemp [counter1].find("TIF")+4).c_str())]++;
                            timePointList [atoi(fileNameListTemp [counter1].substr(8, 4).c_str())]++;
                        }
                        else{
                            
                            roundNoList [atoi(fileNameListTemp [counter1].substr(fileNameListTemp [counter1].find("BMP")+4).c_str())]++;
                            timePointList [atoi(fileNameListTemp [counter1].substr(8, 4).c_str())]++;
                        }
                    }
                }
                
                int newRoundNo = 1;
                int newTimeNo = timePointStart;
                
                for (int counter1 = 0; counter1 < fileNoBMPCount+2; counter1++){
                    if (roundNoList [counter1] != 0){
                        roundNoList [counter1] = newRoundNo;
                        newRoundNo++;
                    }
                }
                
                for (int counter1 = 0; counter1 < maxImageNo+2; counter1++){
                    if (timePointList [counter1] != 0){
                        timePointList [counter1] = newTimeNo;
                        newTimeNo++;
                    }
                }
                
                //for (int counterA = 0; counterA < fileNoBMPCount+2; counterA++){
                //    cout<<counterA<<" "<<roundNoList [counterA]<<" roundNoList "<<endl;
                //}
                
                //for (int counterA = 0; counterA < maxImageNo+2; counterA++){
                //    cout<<counterA<<" "<<timePointList [counterA]<<" timePointList "<<endl;
                //}
                
                string timePointString = imageDisplayPath+"/"+fileNameGet1;
                remove (timePointString.c_str());
                
                timePointString = imageDisplayPath+"/"+fileNameGet2;
                remove (timePointString.c_str());
                
                if (fileNameGet3 != ""){
                    timePointString = imageDisplayPath+"/"+fileNameGet3;
                    remove (timePointString.c_str());
                }
                
                if (fileNameGet4 != ""){
                    timePointString = imageDisplayPath+"/"+fileNameGet4;
                    remove (timePointString.c_str());
                }
                
                if (fileNameGet5 != ""){
                    timePointString = imageDisplayPath+"/"+fileNameGet5;
                    remove (timePointString.c_str());
                }
                
                if (fileNameGet6 != ""){
                    timePointString = imageDisplayPath+"/"+fileNameGet6;
                    remove (timePointString.c_str());
                }
                
                if (fileNameGet7 != ""){
                    timePointString = imageDisplayPath+"/"+fileNameGet7;
                    remove (timePointString.c_str());
                }
                
                string roundString;
                string sourceFileName;
                string destinationFileName;
                string colorName;
                
                int timePointSet = 0;
                int roundSet = 0;
                int fileEntryCount2 = 0;
                int maxNoTemp = 0;
                
                DIR *dir;
                struct dirent *dent;
                
                if (fileTypeTifBmp == 0){
                    for (int counter1 = 0; counter1 < fileNoBMPCount*7; counter1++){
                        if (fileNameListTemp [counter1] != "" && (int)fileNameListTemp [counter1].find ("TIF") == -1){
                            timePointSet = atoi(fileNameListTemp [counter1].substr(8, 4).c_str());
                            roundSet = atoi(fileNameListTemp [counter1].substr(fileNameListTemp [counter1].find("TIF")+3).c_str());
                            
                            timePointString = to_string(timePointList [timePointSet]);
                            roundString = to_string(roundNoList [roundSet]);
                            
                            if (timePointString.length() == 1) timePointString = "000"+timePointString;
                            else if (timePointString.length() == 2) timePointString = "00"+timePointString;
                            else if (timePointString.length() == 3) timePointString = "0"+timePointString;
                            
                            if (roundString.length() == 1) roundString = "0"+roundString;
                            
                            sourceFileName = imageDisplayPath+"/"+fileNameListTemp [counter1];
                            destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+".TIF"+roundString;
                            
                            fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+".TIF"+roundString, fileEntryCount2++;
                            
                            rename (sourceFileName.c_str(), destinationFileName.c_str());
                        }
                        else if (fileNameListTemp [counter1] != "" && (int)fileNameListTemp [counter1].find ("TIF") != -1){
                            timePointSet = atoi(fileNameListTemp [counter1].substr(8, 4).c_str());
                            roundSet = atoi(fileNameListTemp [counter1].substr(fileNameListTemp [counter1].find("TIF")+3).c_str());
                            colorName = fileNameListTemp [counter1].substr(12, fileNameListTemp [counter1].find(".TIF")-12);
                            
                            timePointString = to_string(timePointList [timePointSet]);
                            roundString = to_string(roundNoList [roundSet]);
                            
                            if (timePointString.length() == 1) timePointString = "000"+timePointString;
                            else if (timePointString.length() == 2) timePointString = "00"+timePointString;
                            else if (timePointString.length() == 3) timePointString = "0"+timePointString;
                            
                            if (roundString.length() == 1) roundString = "0"+roundString;
                            
                            sourceFileName = imageDisplayPath+"/"+fileNameListTemp [counter1];
                            destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+colorName+".TIF"+roundString;
                            
                            fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+colorName+".TIF"+roundString, fileEntryCount2++;
                            
                            rename (sourceFileName.c_str(), destinationFileName.c_str());
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < fileEntryCount2; counter1++){
                        sourceFileName = imageDisplayPath+"/"+fileNameListTemp2 [counter1];
                        destinationFileName = imageDisplayPath+"/"+fileNameListTemp2 [counter1].substr(1);
                        
                        rename (sourceFileName.c_str(), destinationFileName.c_str());
                    }
                    
                    string imageNoTemp;
                    lastTIFRoundNo = 0;
                    
                    dir = opendir(imageDisplayPath.c_str());
                    
                    if (dir != NULL){
                        string entry;
                        
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if ((int)entry.find("STimage") != -1){
                                    imageNoTemp = entry.substr(8, 4);
                                    
                                    if (atoi(imageNoTemp.c_str()) > maxNoTemp) maxNoTemp = atoi(imageNoTemp.c_str());
                                    if ((int)entry.find("TIF") != -1 && lastTIFRoundNo < atoi(entry.substr(entry.find("TIF")+3).c_str())){
                                        lastTIFRoundNo = atoi(entry.substr(entry.find("TIF")+3).c_str());
                                    }
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    maxImageNo = maxNoTemp;
                }
                else{
                    
                    for (int counter1 = 0; counter1 < fileNoBMPCount*7; counter1++){
                        if (fileNameListTemp [counter1] != "" && (int)fileNameListTemp [counter1].find ("BMP") == -1){
                            timePointSet = atoi(fileNameListTemp [counter1].substr(8, 4).c_str());
                            roundSet = atoi(fileNameListTemp [counter1].substr(fileNameListTemp [counter1].find("BMP")+3).c_str());
                            
                            timePointString = to_string(timePointList [timePointSet]);
                            roundString = to_string(roundNoList [roundSet]);
                            
                            if (timePointString.length() == 1) timePointString = "000"+timePointString;
                            else if (timePointString.length() == 2) timePointString = "00"+timePointString;
                            else if (timePointString.length() == 3) timePointString = "0"+timePointString;
                            
                            if (roundString.length() == 1) roundString = "0"+roundString;
                            
                            sourceFileName = imageDisplayPath+"/"+fileNameListTemp [counter1];
                            destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+".BMP"+roundString;
                            
                            fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+".BMP"+roundString, fileEntryCount2++;
                            
                            rename (sourceFileName.c_str(), destinationFileName.c_str());
                        }
                        else if (fileNameListTemp [counter1] != "" && (int)fileNameListTemp [counter1].find ("BMP") != -1){
                            timePointSet = atoi(fileNameListTemp [counter1].substr(8, 4).c_str());
                            roundSet = atoi(fileNameListTemp [counter1].substr(fileNameListTemp [counter1].find("BMP")+3).c_str());
                            colorName = fileNameListTemp [counter1].substr(12, fileNameListTemp [counter1].find(".BMP")-12);
                            
                            timePointString = to_string(timePointList [timePointSet]);
                            roundString = to_string(roundNoList [roundSet]);
                            
                            if (timePointString.length() == 1) timePointString = "000"+timePointString;
                            else if (timePointString.length() == 2) timePointString = "00"+timePointString;
                            else if (timePointString.length() == 3) timePointString = "0"+timePointString;
                            
                            if (roundString.length() == 1) roundString = "0"+roundString;
                            
                            sourceFileName = imageDisplayPath+"/"+fileNameListTemp [counter1];
                            destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+colorName+".BMP"+roundString;
                            
                            fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+colorName+".BMP"+roundString, fileEntryCount2++;
                            
                            rename (sourceFileName.c_str(), destinationFileName.c_str());
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < fileEntryCount2; counter1++){
                        sourceFileName = imageDisplayPath+"/"+fileNameListTemp2 [counter1];
                        destinationFileName = imageDisplayPath+"/"+fileNameListTemp2 [counter1].substr(1);
                        
                        rename (sourceFileName.c_str(), destinationFileName.c_str());
                    }
                    
                    string imageNoTemp;
                    lastTIFRoundNo = 0;
                    
                    dir = opendir(imageDisplayPath.c_str());
                    
                    if (dir != NULL){
                        string entry;
                        
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if ((int)entry.find("STimage") != -1){
                                    imageNoTemp = entry.substr(8, 4);
                                    
                                    if (atoi(imageNoTemp.c_str()) > maxNoTemp) maxNoTemp = atoi(imageNoTemp.c_str());
                                    if ((int)entry.find("BMP") != -1 && lastTIFRoundNo < atoi(entry.substr(entry.find("BMP")+3).c_str())){
                                        lastTIFRoundNo = atoi(entry.substr(entry.find("BMP")+3).c_str());
                                    }
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    maxImageNo = maxNoTemp;
                }
                
                delete [] fileList;
                
                fileList = new string [maxImageNo*7+4];
                fileListCount = 0;
                
                string *fileListTemp = new string [maxNoTemp*7+4];
                int fileListTempCount = 0;
                
                dir = opendir(imageDisplayPath.c_str());
                
                if (dir != NULL){
                    string entry;
                    
                    while((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("STimage") != -1){
                                fileListTemp [fileListTempCount] = entry, fileListTempCount++;
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                //-----Directory Sort----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < fileListTempCount; counter1++){
                    [unsortedArray addObject:@(fileListTemp [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    fileListTemp [counter1] = [unsortedArray [counter1] UTF8String];
                }
                
                for (int counter1 = 0; counter1 < fileListTempCount; counter1++){
                    if ((int)fileListTemp [counter1].find("_") == -1){
                        fileList [fileListCount] = fileListTemp [counter1], fileListCount++;
                        fileList [fileListCount] = "", fileListCount++;
                        fileList [fileListCount] = "", fileListCount++;
                        fileList [fileListCount] = "", fileListCount++;
                        fileList [fileListCount] = "", fileListCount++;
                        fileList [fileListCount] = "", fileListCount++;
                        fileList [fileListCount] = "", fileListCount++;
                    }
                }
                
                int timePosition = 0;
                
                for (int counter1 = 0; counter1 < fileListTempCount; counter1++){
                    if ((int)fileListTemp [counter1].find("_1_") != -1 || (int)fileListTemp [counter1].find("_2_") != -1 || (int)fileListTemp [counter1].find("_3_") != -1 || (int)fileListTemp [counter1].find("_4_") != -1 || (int)fileListTemp [counter1].find("_5_") != -1 || (int)fileListTemp [counter1].find("_6_") != -1 || (int)fileListTemp [counter1].find("_7_") != -1 || (int)fileListTemp [counter1].find("_8_") != -1 || (int)fileListTemp [counter1].find("_9_") != -1){
                        timePosition = atoi(fileListTemp [counter1].substr(fileListTemp [counter1].find("STimage ")+8, 4).c_str())-1;
                        
                        if (fileList [timePosition*7+1] == "") fileList [timePosition*7+1] = fileListTemp [counter1];
                        else if (fileList [timePosition*7+2] == "") fileList [timePosition*7+2] = fileListTemp [counter1];
                        else if (fileList [timePosition*7+3] == "") fileList [timePosition*7+3] = fileListTemp [counter1];
                        else if (fileList [timePosition*7+4] == "") fileList [timePosition*7+4] = fileListTemp [counter1];
                        else if (fileList [timePosition*7+5] == "") fileList [timePosition*7+5] = fileListTemp [counter1];
                        else if (fileList [timePosition*7+6] == "") fileList [timePosition*7+6] = fileListTemp [counter1];
                    }
                }
                
                delete [] fileListTemp;
                
                fileNoBMPCount = 0;
                
                for (int counter1 = 1; counter1 <= maxImageNo; counter1++){
                    if (fileList [(counter1-1)*7+1] != ""){
                        if ((int)fileList [(counter1-1)*7+1].find("TIF") != -1 || (int)fileList [(counter1-1)*7+1].find("BMP") != -1) fileNoBMPCount++;
                        
                        if (fileList [(counter1-1)*7+2] != ""){
                            if ((int)fileList [(counter1-1)*7+2].find("TIF") != -1 || (int)fileList [(counter1-1)*7+2].find("BMP") != -1) fileNoBMPCount++;
                            
                            if (fileList [(counter1-1)*7+3] != ""){
                                if ((int)fileList [(counter1-1)*7+3].find("TIF") != -1 || (int)fileList [(counter1-1)*7+3].find("BMP") != -1) fileNoBMPCount++;
                                
                                if (fileList [(counter1-1)*7+4] != ""){
                                    if ((int)fileList [(counter1-1)*7+4].find("TIF") != -1 || (int)fileList [(counter1-1)*7+4].find("BMP") != -1) fileNoBMPCount++;
                                    
                                    if (fileList [(counter1-1)*7+5] != ""){
                                        if ((int)fileList [(counter1-1)*7+5].find("TIF") != -1 || (int)fileList [(counter1-1)*7+5].find("BMP") != -1) fileNoBMPCount++;
                                        
                                        if (fileList [(counter1-1)*7+6] != ""){
                                            if ((int)fileList [(counter1-1)*7+6].find("TIF") != -1 || (int)fileList [(counter1-1)*7+6].find("BMP") != -1) fileNoBMPCount++;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                delete [] fileNameListTemp;
                delete [] fileNameListTemp2;
                delete [] roundNoList;
                delete [] timePointList;
                
                selectedFile = "";
                fluorescentColorNoFluorescent = 0;
                xMovePositionHoldMain = 0;
                yMovePositionHoldMain = 0;
                referenceImageStatusFluorescent = 0;
                
                [tableViewTDList reloadData];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentAdjust object:self];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Need One IF Image"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"IF Image Loaded"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)mergeEntry:(id)sender{
    if (copyProgressFlag == 0){
        if (lastTIFRoundNo != 0 && imageLoadFlagFluorescent == 1){
            if ([mergeNoDisplay intValue] >= 1){
                int mergeNo = [mergeNoDisplay intValue];
                
                [mergeNoDisplay setStringValue:@""];
                
                string fileNameGet1 = "";
                string fileNameGet2 = "";
                string fileNameGet3 = "";
                string fileNameGet4 = "";
                string fileNameGet5 = "";
                string fileNameGet6 = "";
                string fileNameGet7 = "";
                string firstBMP = "";
                
                int timePointStart = 0;
                int bmpFindFlag = 0;
                
                for (int counter1 = 1; counter1 <= maxImageNo; counter1++){
                    if (fileList [(counter1-1)*7+1] != ""){
                        if ((int)fileList [(counter1-1)*7+1].find("TIF") != -1 || (int)fileList [(counter1-1)*7+1].find("BMP") != -1){
                            if (timePointStart == 0) timePointStart = atoi(fileList [(counter1-1)*7].substr(8, 4).c_str());
                            
                            if (bmpFindFlag == tableCurrentFluRowHold){
                                fileNameGet1 = fileList [(counter1-1)*7];
                                fileNameGet2 = fileList [(counter1-1)*7+1];
                                fileNameGet3 = fileList [(counter1-1)*7+2];
                                fileNameGet4 = fileList [(counter1-1)*7+3];
                                fileNameGet5 = fileList [(counter1-1)*7+4];
                                fileNameGet6 = fileList [(counter1-1)*7+5];
                                fileNameGet7 = fileList [(counter1-1)*7+6];
                                break;
                            }
                            else bmpFindFlag++;
                        }
                        
                        if (fileList [(counter1-1)*7+2] != ""){
                            if ((int)fileList [(counter1-1)*7+2].find("TIF") != -1 || (int)fileList [(counter1-1)*7+2].find("BMP") != -1){
                                if (bmpFindFlag == tableCurrentFluRowHold){
                                    fileNameGet1 = fileList [(counter1-1)*7];
                                    fileNameGet2 = fileList [(counter1-1)*7+1];
                                    fileNameGet3 = fileList [(counter1-1)*7+2];
                                    fileNameGet4 = fileList [(counter1-1)*7+3];
                                    fileNameGet5 = fileList [(counter1-1)*7+4];
                                    fileNameGet6 = fileList [(counter1-1)*7+5];
                                    fileNameGet7 = fileList [(counter1-1)*7+6];
                                    break;
                                }
                                else bmpFindFlag++;
                            }
                            
                            if (fileList [(counter1-1)*7+3] != ""){
                                if ((int)fileList [(counter1-1)*7+3].find("TIF") != -1 || (int)fileList [(counter1-1)*7+3].find("BMP") != -1){
                                    if (bmpFindFlag == tableCurrentFluRowHold){
                                        fileNameGet1 = fileList [(counter1-1)*7];
                                        fileNameGet2 = fileList [(counter1-1)*7+1];
                                        fileNameGet3 = fileList [(counter1-1)*7+2];
                                        fileNameGet4 = fileList [(counter1-1)*7+3];
                                        fileNameGet5 = fileList [(counter1-1)*7+4];
                                        fileNameGet6 = fileList [(counter1-1)*7+5];
                                        fileNameGet7 = fileList [(counter1-1)*7+6];
                                        break;
                                    }
                                    else bmpFindFlag++;
                                }
                                
                                if (fileList [(counter1-1)*7+4] != ""){
                                    if ((int)fileList [(counter1-1)*7+4].find("TIF") != -1 || (int)fileList [(counter1-1)*7+4].find("BMP") != -1){
                                        if (bmpFindFlag == tableCurrentFluRowHold){
                                            fileNameGet1 = fileList [(counter1-1)*7];
                                            fileNameGet2 = fileList [(counter1-1)*7+1];
                                            fileNameGet3 = fileList [(counter1-1)*7+2];
                                            fileNameGet4 = fileList [(counter1-1)*7+3];
                                            fileNameGet5 = fileList [(counter1-1)*7+4];
                                            fileNameGet6 = fileList [(counter1-1)*7+5];
                                            fileNameGet7 = fileList [(counter1-1)*7+6];
                                            break;
                                        }
                                        else bmpFindFlag++;
                                    }
                                    
                                    if (fileList [(counter1-1)*7+5] != ""){
                                        if ((int)fileList [(counter1-1)*7+5].find("TIF") != -1 || (int)fileList [(counter1-1)*7+5].find("BMP") != -1){
                                            if (bmpFindFlag == tableCurrentFluRowHold){
                                                fileNameGet1 = fileList [(counter1-1)*7];
                                                fileNameGet2 = fileList [(counter1-1)*7+1];
                                                fileNameGet3 = fileList [(counter1-1)*7+2];
                                                fileNameGet4 = fileList [(counter1-1)*7+3];
                                                fileNameGet5 = fileList [(counter1-1)*7+4];
                                                fileNameGet6 = fileList [(counter1-1)*7+5];
                                                fileNameGet7 = fileList [(counter1-1)*7+6];
                                                break;
                                            }
                                            else bmpFindFlag++;
                                        }
                                        
                                        if (fileList [(counter1-1)*7+6] != ""){
                                            if ((int)fileList [(counter1-1)*7+6].find("TIF") != -1 || (int)fileList [(counter1-1)*7+6].find("BMP") != -1){
                                                if (bmpFindFlag == tableCurrentFluRowHold){
                                                    fileNameGet1 = fileList [(counter1-1)*7];
                                                    fileNameGet2 = fileList [(counter1-1)*7+1];
                                                    fileNameGet3 = fileList [(counter1-1)*7+2];
                                                    fileNameGet4 = fileList [(counter1-1)*7+3];
                                                    fileNameGet5 = fileList [(counter1-1)*7+4];
                                                    fileNameGet6 = fileList [(counter1-1)*7+5];
                                                    fileNameGet7 = fileList [(counter1-1)*7+6];
                                                    break;
                                                }
                                                else bmpFindFlag++;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                //cout<<fileNameGet1<<" "<<fileNameGet2<<" "<<fileNameGet3 <<" "<<fileNameGet4 <<" Get"<<endl;
                
                if (fileNameGet1 != ""){
                    if (timePointStart <= mergeNo){
                        if (atoi(fileNameGet1.substr(8, 4).c_str()) != mergeNo){
                            string fileNameMerge1 = fileList [(mergeNo-1)*7];
                            string fileNameMerge2 = fileList [(mergeNo-1)*7+1];
                            string fileNameMerge3 = fileList [(mergeNo-1)*7+2];
                            string fileNameMerge4 = fileList [(mergeNo-1)*7+3];
                            string fileNameMerge5 = fileList [(mergeNo-1)*7+4];
                            string fileNameMerge6 = fileList [(mergeNo-1)*7+5];
                            string fileNameMerge7 = fileList [(mergeNo-1)*7+6];
                            
                            //cout<<fileNameMerge1<<" "<<fileNameMerge2<<" "<<fileNameMerge3 <<" "<<fileNameMerge4 <<" Merge"<<endl;
                            
                            int mergeCount = 1;
                            
                            if (fileNameMerge3 != "") mergeCount++;
                            if (fileNameMerge4 != "") mergeCount++;
                            if (fileNameMerge5 != "") mergeCount++;
                            if (fileNameMerge6 != "") mergeCount++;
                            if (fileNameMerge7 != "") mergeCount++;
                            
                            int getCount = 1;
                            
                            if (fileNameGet3 != "") getCount++;
                            if (fileNameGet4 != "") getCount++;
                            if (fileNameGet5 != "") getCount++;
                            if (fileNameGet6 != "") getCount++;
                            if (fileNameGet7 != "") getCount++;
                            
                            if (mergeCount+getCount <= 6){
                                int sameNameFind = 0;
                                
                                if (fileTypeTifBmp == 0){
                                    if (fileNameMerge2 != "" && fileNameGet2 != "" && fileNameMerge2.substr(12, fileNameMerge2.find(".TIF")-12) == fileNameGet2.substr(12, fileNameGet2.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge2 != "" && fileNameGet3 != "" && fileNameMerge2.substr(12, fileNameMerge2.find(".TIF")-12) == fileNameGet3.substr(12, fileNameGet3.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge2 != "" && fileNameGet4 != "" && fileNameMerge2.substr(12, fileNameMerge2.find(".TIF")-12) == fileNameGet4.substr(12, fileNameGet4.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge2 != "" && fileNameGet5 != "" && fileNameMerge2.substr(12, fileNameMerge2.find(".TIF")-12) == fileNameGet5.substr(12, fileNameGet5.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge2 != "" && fileNameGet6 != "" && fileNameMerge2.substr(12, fileNameMerge2.find(".TIF")-12) == fileNameGet6.substr(12, fileNameGet6.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge2 != "" && fileNameGet7 != "" && fileNameMerge2.substr(12, fileNameMerge2.find(".TIF")-12) == fileNameGet7.substr(12, fileNameGet7.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge3 != "" && fileNameGet2 != "" && fileNameMerge3.substr(12, fileNameMerge3.find(".TIF")-12) == fileNameGet2.substr(12, fileNameGet2.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge3 != "" && fileNameGet3 != "" && fileNameMerge3.substr(12, fileNameMerge3.find(".TIF")-12) == fileNameGet3.substr(12, fileNameGet3.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge3 != "" && fileNameGet4 != "" && fileNameMerge3.substr(12, fileNameMerge3.find(".TIF")-12) == fileNameGet4.substr(12, fileNameGet4.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge3 != "" && fileNameGet5 != "" && fileNameMerge3.substr(12, fileNameMerge3.find(".TIF")-12) == fileNameGet5.substr(12, fileNameGet5.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge3 != "" && fileNameGet6 != "" && fileNameMerge3.substr(12, fileNameMerge3.find(".TIF")-12) == fileNameGet6.substr(12, fileNameGet6.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge3 != "" && fileNameGet7 != "" && fileNameMerge3.substr(12, fileNameMerge3.find(".TIF")-12) == fileNameGet7.substr(12, fileNameGet7.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge4 != "" && fileNameGet2 != "" && fileNameMerge4.substr(12, fileNameMerge4.find(".TIF")-12) == fileNameGet2.substr(12, fileNameGet2.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge4 != "" && fileNameGet3 != "" && fileNameMerge4.substr(12, fileNameMerge4.find(".TIF")-12) == fileNameGet3.substr(12, fileNameGet3.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge4 != "" && fileNameGet4 != "" && fileNameMerge4.substr(12, fileNameMerge4.find(".TIF")-12) == fileNameGet4.substr(12, fileNameGet4.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge4 != "" && fileNameGet5 != "" && fileNameMerge4.substr(12, fileNameMerge4.find(".TIF")-12) == fileNameGet5.substr(12, fileNameGet5.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge4 != "" && fileNameGet6 != "" && fileNameMerge4.substr(12, fileNameMerge4.find(".TIF")-12) == fileNameGet6.substr(12, fileNameGet6.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge4 != "" && fileNameGet7 != "" && fileNameMerge4.substr(12, fileNameMerge4.find(".TIF")-12) == fileNameGet7.substr(12, fileNameGet7.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge5 != "" && fileNameGet2 != "" && fileNameMerge5.substr(12, fileNameMerge5.find(".TIF")-12) == fileNameGet2.substr(12, fileNameGet2.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge5 != "" && fileNameGet3 != "" && fileNameMerge5.substr(12, fileNameMerge5.find(".TIF")-12) == fileNameGet3.substr(12, fileNameGet3.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge5 != "" && fileNameGet4 != "" && fileNameMerge5.substr(12, fileNameMerge5.find(".TIF")-12) == fileNameGet4.substr(12, fileNameGet4.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge5 != "" && fileNameGet5 != "" && fileNameMerge5.substr(12, fileNameMerge5.find(".TIF")-12) == fileNameGet5.substr(12, fileNameGet5.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge5 != "" && fileNameGet6 != "" && fileNameMerge5.substr(12, fileNameMerge5.find(".TIF")-12) == fileNameGet6.substr(12, fileNameGet6.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge5 != "" && fileNameGet7 != "" && fileNameMerge5.substr(12, fileNameMerge5.find(".TIF")-12) == fileNameGet7.substr(12, fileNameGet7.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge6 != "" && fileNameGet2 != "" && fileNameMerge6.substr(12, fileNameMerge6.find(".TIF")-12) == fileNameGet2.substr(12, fileNameGet2.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge6 != "" && fileNameGet3 != "" && fileNameMerge6.substr(12, fileNameMerge6.find(".TIF")-12) == fileNameGet3.substr(12, fileNameGet3.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge6 != "" && fileNameGet4 != "" && fileNameMerge6.substr(12, fileNameMerge6.find(".TIF")-12) == fileNameGet4.substr(12, fileNameGet4.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge6 != "" && fileNameGet5 != "" && fileNameMerge6.substr(12, fileNameMerge6.find(".TIF")-12) == fileNameGet5.substr(12, fileNameGet5.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge6 != "" && fileNameGet6 != "" && fileNameMerge6.substr(12, fileNameMerge6.find(".TIF")-12) == fileNameGet6.substr(12, fileNameGet6.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge6 != "" && fileNameGet7 != "" && fileNameMerge6.substr(12, fileNameMerge6.find(".TIF")-12) == fileNameGet7.substr(12, fileNameGet7.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge7 != "" && fileNameGet2 != "" && fileNameMerge7.substr(12, fileNameMerge7.find(".TIF")-12) == fileNameGet2.substr(12, fileNameGet2.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge7 != "" && fileNameGet3 != "" && fileNameMerge7.substr(12, fileNameMerge7.find(".TIF")-12) == fileNameGet3.substr(12, fileNameGet3.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge7 != "" && fileNameGet4 != "" && fileNameMerge7.substr(12, fileNameMerge7.find(".TIF")-12) == fileNameGet4.substr(12, fileNameGet4.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge7 != "" && fileNameGet5 != "" && fileNameMerge7.substr(12, fileNameMerge7.find(".TIF")-12) == fileNameGet5.substr(12, fileNameGet5.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge7 != "" && fileNameGet6 != "" && fileNameMerge7.substr(12, fileNameMerge7.find(".TIF")-12) == fileNameGet6.substr(12, fileNameGet6.find(".TIF")-12)) sameNameFind = 1;
                                    if (fileNameMerge7 != "" && fileNameGet7 != "" && fileNameMerge7.substr(12, fileNameMerge7.find(".TIF")-12) == fileNameGet7.substr(12, fileNameGet7.find(".TIF")-12)) sameNameFind = 1;
                                }
                                else{
                                    
                                    if (fileNameMerge2 != "" && fileNameGet2 != "" && fileNameMerge2.substr(12, fileNameMerge2.find(".BMP")-12) == fileNameGet2.substr(12, fileNameGet2.find(".BMP")-12)) sameNameFind = 1;
                                    if (fileNameMerge2 != "" && fileNameGet3 != "" && fileNameMerge2.substr(12, fileNameMerge2.find(".BMP")-12) == fileNameGet3.substr(12, fileNameGet3.find(".BMP")-12)) sameNameFind = 1;
                                    if (fileNameMerge2 != "" && fileNameGet4 != "" && fileNameMerge2.substr(12, fileNameMerge2.find(".BMP")-12) == fileNameGet4.substr(12, fileNameGet4.find(".BMP")-12)) sameNameFind = 1;
                                    if (fileNameMerge3 != "" && fileNameGet2 != "" && fileNameMerge3.substr(12, fileNameMerge3.find(".BMP")-12) == fileNameGet2.substr(12, fileNameGet2.find(".BMP")-12)) sameNameFind = 1;
                                    if (fileNameMerge3 != "" && fileNameGet3 != "" && fileNameMerge3.substr(12, fileNameMerge3.find(".BMP")-12) == fileNameGet3.substr(12, fileNameGet3.find(".BMP")-12)) sameNameFind = 1;
                                    if (fileNameMerge3 != "" && fileNameGet4 != "" && fileNameMerge3.substr(12, fileNameMerge3.find(".BMP")-12) == fileNameGet4.substr(12, fileNameGet4.find(".BMP")-12)) sameNameFind = 1;
                                    if (fileNameMerge4 != "" && fileNameGet2 != "" && fileNameMerge4.substr(12, fileNameMerge4.find(".BMP")-12) == fileNameGet2.substr(12, fileNameGet2.find(".BMP")-12)) sameNameFind = 1;
                                    if (fileNameMerge4 != "" && fileNameGet3 != "" && fileNameMerge4.substr(12, fileNameMerge4.find(".BMP")-12) == fileNameGet3.substr(12, fileNameGet3.find(".BMP")-12)) sameNameFind = 1;
                                    if (fileNameMerge4 != "" && fileNameGet4 != "" && fileNameMerge4.substr(12, fileNameMerge4.find(".BMP")-12) == fileNameGet4.substr(12, fileNameGet4.find(".BMP")-12)) sameNameFind = 1;
                                }
                                
                                if (sameNameFind == 0){
                                    string sourceFileName;
                                    string destinationFileName;
                                    string mergeTimeNo = fileList [(mergeNo-1)*7].substr(8, 4);
                                    string mergeRoundNo;
                                    
                                    if (fileTypeTifBmp == 0) mergeRoundNo = fileList [(mergeNo-1)*7].substr(fileList [(mergeNo-1)*7].find("TIF")+3);
                                    else fileList [(mergeNo-1)*7].substr(fileList [(mergeNo-1)*7].find("BMP")+3);
                                    
                                    string colorName;
                                    
                                    int mergeTimeNoInt = atoi(mergeTimeNo.c_str());
                                    
                                    int maxNoTemp = 0;
                                    
                                    string *fileNameListTemp = new string [(fileNoBMPCount+1)*7+7];
                                    string *fileNameListTemp2 = new string [(fileNoBMPCount+1)*7+7];
                                    int *roundNoList = new int [fileNoBMPCount+2];
                                    int *timePointList = new int [maxImageNo+2];
                                    
                                    for (int counter1 = 0; counter1 < (fileNoBMPCount+1)*7+7; counter1++){
                                        fileNameListTemp [counter1] = "";
                                        fileNameListTemp2 [counter1] = "";
                                    }
                                    
                                    for (int counter1 = 0; counter1 < fileNoBMPCount+2; counter1++) roundNoList [counter1] = 0;
                                    
                                    for (int counter1 = 0; counter1 < maxImageNo+2; counter1++) timePointList [counter1] = 0;
                                    
                                    DIR *dir;
                                    struct dirent *dent;
                                    
                                    if (fileTypeTifBmp == 0){
                                        if (mergeCount == 1){
                                            colorName = fileNameGet2.substr(12, fileNameGet2.find(".TIF")-12);
                                            fileNameMerge3 = "STimage "+mergeTimeNo+colorName+".TIF"+mergeRoundNo;
                                            
                                            fileList [(mergeTimeNoInt-1)*7+2] = fileNameMerge3;
                                            
                                            sourceFileName = imageDisplayPath+"/"+fileNameGet2;
                                            destinationFileName = imageDisplayPath+"/"+fileNameMerge3;
                                            
                                            rename (sourceFileName.c_str(), destinationFileName.c_str());
                                            
                                            if (fileNameMerge4 == "" && fileNameGet3 != ""){
                                                colorName = fileNameGet3.substr(12, fileNameGet3.find(".TIF")-12);
                                                fileNameMerge4 = "STimage "+mergeTimeNo+colorName+".TIF"+mergeRoundNo;
                                                
                                                fileList [(mergeTimeNoInt-1)*7+3] = fileNameMerge4;
                                                
                                                sourceFileName = imageDisplayPath+"/"+fileNameGet3;
                                                destinationFileName = imageDisplayPath+"/"+fileNameMerge4;
                                                
                                                rename (sourceFileName.c_str(), destinationFileName.c_str());
                                            }
                                            
                                            if (fileNameMerge5 == "" && fileNameGet4 != ""){
                                                colorName = fileNameGet4.substr(12, fileNameGet4.find(".TIF")-12);
                                                fileNameMerge5 = "STimage "+mergeTimeNo+colorName+".TIF"+mergeRoundNo;
                                                
                                                fileList [(mergeTimeNoInt-1)*7+4] = fileNameMerge5;
                                                
                                                sourceFileName = imageDisplayPath+"/"+fileNameGet4;
                                                destinationFileName = imageDisplayPath+"/"+fileNameMerge5;
                                                
                                                rename (sourceFileName.c_str(), destinationFileName.c_str());
                                            }
                                            
                                            if (fileNameMerge6 == "" && fileNameGet5 != ""){
                                                colorName = fileNameGet5.substr(12, fileNameGet5.find(".TIF")-12);
                                                fileNameMerge6 = "STimage "+mergeTimeNo+colorName+".TIF"+mergeRoundNo;
                                                
                                                fileList [(mergeTimeNoInt-1)*7+5] = fileNameMerge6;
                                                
                                                sourceFileName = imageDisplayPath+"/"+fileNameGet5;
                                                destinationFileName = imageDisplayPath+"/"+fileNameMerge6;
                                                
                                                rename (sourceFileName.c_str(), destinationFileName.c_str());
                                            }
                                            
                                            if (fileNameMerge7 == "" && fileNameGet6 != ""){
                                                colorName = fileNameGet6.substr(12, fileNameGet6.find(".TIF")-12);
                                                fileNameMerge7 = "STimage "+mergeTimeNo+colorName+".TIF"+mergeRoundNo;
                                                
                                                fileList [(mergeTimeNoInt-1)*7+6] = fileNameMerge7;
                                                
                                                sourceFileName = imageDisplayPath+"/"+fileNameGet6;
                                                destinationFileName = imageDisplayPath+"/"+fileNameMerge7;
                                                
                                                rename (sourceFileName.c_str(), destinationFileName.c_str());
                                            }
                                        }
                                        else if (mergeCount == 2){
                                            colorName = fileNameGet2.substr(12, fileNameGet2.find(".TIF")-12);
                                            fileNameMerge4 = "STimage "+mergeTimeNo+colorName+".TIF"+mergeRoundNo;
                                            
                                            fileList [(mergeTimeNoInt-1)*7+3] = fileNameMerge4;
                                            
                                            sourceFileName = imageDisplayPath+"/"+fileNameGet2;
                                            destinationFileName = imageDisplayPath+"/"+fileNameMerge4;
                                            
                                            rename (sourceFileName.c_str(), destinationFileName.c_str());
                                            
                                            if (fileNameMerge5 == "" && fileNameGet3 != ""){
                                                colorName = fileNameGet3.substr(12, fileNameGet3.find(".TIF")-12);
                                                fileNameMerge5 = "STimage "+mergeTimeNo+colorName+".TIF"+mergeRoundNo;
                                                
                                                fileList [(mergeTimeNoInt-1)*7+4] = fileNameMerge5;
                                                
                                                sourceFileName = imageDisplayPath+"/"+fileNameGet3;
                                                destinationFileName = imageDisplayPath+"/"+fileNameMerge5;
                                                
                                                rename (sourceFileName.c_str(), destinationFileName.c_str());
                                            }
                                            
                                            if (fileNameMerge6 == "" && fileNameGet4 != ""){
                                                colorName = fileNameGet4.substr(12, fileNameGet4.find(".TIF")-12);
                                                fileNameMerge6 = "STimage "+mergeTimeNo+colorName+".TIF"+mergeRoundNo;
                                                
                                                fileList [(mergeTimeNoInt-1)*7+5] = fileNameMerge6;
                                                
                                                sourceFileName = imageDisplayPath+"/"+fileNameGet4;
                                                destinationFileName = imageDisplayPath+"/"+fileNameMerge6;
                                                
                                                rename (sourceFileName.c_str(), destinationFileName.c_str());
                                            }
                                            
                                            if (fileNameMerge7 == "" && fileNameGet5 != ""){
                                                colorName = fileNameGet5.substr(12, fileNameGet5.find(".TIF")-12);
                                                fileNameMerge7 = "STimage "+mergeTimeNo+colorName+".TIF"+mergeRoundNo;
                                                
                                                fileList [(mergeTimeNoInt-1)*7+6] = fileNameMerge7;
                                                
                                                sourceFileName = imageDisplayPath+"/"+fileNameGet5;
                                                destinationFileName = imageDisplayPath+"/"+fileNameMerge7;
                                                
                                                rename (sourceFileName.c_str(), destinationFileName.c_str());
                                            }
                                        }
                                        else if (mergeCount == 3){
                                            colorName = fileNameGet2.substr(12, fileNameGet2.find(".TIF")-12);
                                            fileNameMerge5 = "STimage "+mergeTimeNo+colorName+".TIF"+mergeRoundNo;
                                            
                                            fileList [(mergeTimeNoInt-1)*7+4] = fileNameMerge5;
                                            
                                            sourceFileName = imageDisplayPath+"/"+fileNameGet2;
                                            destinationFileName = imageDisplayPath+"/"+fileNameMerge5;
                                            
                                            rename (sourceFileName.c_str(), destinationFileName.c_str());
                                            
                                            if (fileNameMerge6 == "" && fileNameGet3 != ""){
                                                colorName = fileNameGet3.substr(12, fileNameGet3.find(".TIF")-12);
                                                fileNameMerge6 = "STimage "+mergeTimeNo+colorName+".TIF"+mergeRoundNo;
                                                
                                                fileList [(mergeTimeNoInt-1)*7+5] = fileNameMerge6;
                                                
                                                sourceFileName = imageDisplayPath+"/"+fileNameGet3;
                                                destinationFileName = imageDisplayPath+"/"+fileNameMerge6;
                                                
                                                rename (sourceFileName.c_str(), destinationFileName.c_str());
                                            }
                                            
                                            if (fileNameMerge7 == "" && fileNameGet4 != ""){
                                                colorName = fileNameGet4.substr(12, fileNameGet4.find(".TIF")-12);
                                                fileNameMerge7 = "STimage "+mergeTimeNo+colorName+".TIF"+mergeRoundNo;
                                                
                                                fileList [(mergeTimeNoInt-1)*7+6] = fileNameMerge7;
                                                
                                                sourceFileName = imageDisplayPath+"/"+fileNameGet4;
                                                destinationFileName = imageDisplayPath+"/"+fileNameMerge7;
                                                
                                                rename (sourceFileName.c_str(), destinationFileName.c_str());
                                            }
                                        }
                                        else if (mergeCount == 4){
                                            colorName = fileNameGet2.substr(12, fileNameGet2.find(".TIF")-12);
                                            fileNameMerge6 = "STimage "+mergeTimeNo+colorName+".TIF"+mergeRoundNo;
                                            
                                            fileList [(mergeTimeNoInt-1)*7+5] = fileNameMerge6;
                                            
                                            sourceFileName = imageDisplayPath+"/"+fileNameGet2;
                                            destinationFileName = imageDisplayPath+"/"+fileNameMerge6;
                                            
                                            rename (sourceFileName.c_str(), destinationFileName.c_str());
                                            
                                            if (fileNameMerge7 == "" && fileNameGet3 != ""){
                                                colorName = fileNameGet3.substr(12, fileNameGet3.find(".TIF")-12);
                                                fileNameMerge7 = "STimage "+mergeTimeNo+colorName+".TIF"+mergeRoundNo;
                                                
                                                fileList [(mergeTimeNoInt-1)*7+6] = fileNameMerge7;
                                                
                                                sourceFileName = imageDisplayPath+"/"+fileNameGet3;
                                                destinationFileName = imageDisplayPath+"/"+fileNameMerge7;
                                                
                                                rename (sourceFileName.c_str(), destinationFileName.c_str());
                                            }
                                        }
                                        else if (mergeCount == 5){
                                            colorName = fileNameGet2.substr(12, fileNameGet2.find(".TIF")-12);
                                            fileNameMerge7 = "STimage "+mergeTimeNo+colorName+".TIF"+mergeRoundNo;
                                            
                                            fileList [(mergeTimeNoInt-1)*7+6] = fileNameMerge7;
                                            
                                            sourceFileName = imageDisplayPath+"/"+fileNameGet2;
                                            destinationFileName = imageDisplayPath+"/"+fileNameMerge7;
                                            
                                            rename (sourceFileName.c_str(), destinationFileName.c_str());
                                        }
                                        
                                        sourceFileName = imageDisplayPath+"/"+fileNameGet1;
                                        remove (sourceFileName.c_str());
                                        
                                        int fileEntryCount = 0;
                                        
                                        for (int counter1 = 1; counter1 <= maxImageNo; counter1++){
                                            if ((int)fileList [(counter1-1)*7+1].find("TIF") != -1 && fileList [(counter1-1)*7] != fileNameGet1){
                                                fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7], fileEntryCount++;
                                                fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+1], fileEntryCount++;
                                                fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+2], fileEntryCount++;
                                                fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+3], fileEntryCount++;
                                                fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+4], fileEntryCount++;
                                                fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+5], fileEntryCount++;
                                                fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+6], fileEntryCount++;
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < fileEntryCount/4; counterA++){
                                        //    cout<<counterA<<" "<<fileNameListTemp [counterA*7]<<" "<<fileNameListTemp [counterA*7+1]<<" "<<fileNameListTemp [counterA*7+2]<<" "<<fileNameListTemp [counterA*7+3]<<" List"<<endl;
                                        //}
                                        
                                        for (int counter1 = 0; counter1 < fileNoBMPCount*7; counter1++){
                                            if (fileNameListTemp [counter1] != ""){
                                                roundNoList [atoi(fileNameListTemp [counter1].substr(fileNameListTemp [counter1].find("TIF")+4).c_str())]++;
                                                timePointList [atoi(fileNameListTemp [counter1].substr(8, 4).c_str())]++;
                                            }
                                        }
                                        
                                        int newRoundNo = 1;
                                        int newTimeNo = timePointStart;
                                        
                                        for (int counter1 = 0; counter1 < fileNoBMPCount+2; counter1++){
                                            if (roundNoList [counter1] != 0){
                                                roundNoList [counter1] = newRoundNo;
                                                newRoundNo++;
                                            }
                                        }
                                        
                                        for (int counter1 = 0; counter1 < maxImageNo+2; counter1++){
                                            if (timePointList [counter1] != 0){
                                                timePointList [counter1] = newTimeNo;
                                                newTimeNo++;
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < fileNoBMPCount+2; counterA++){
                                        //    cout<<counterA<<" "<<roundNoList [counterA]<<" roundNoList "<<endl;
                                        //}
                                        
                                        //for (int counterA = 0; counterA < maxImageNo+2; counterA++){
                                        //    cout<<counterA<<" "<<timePointList [counterA]<<" timePointList "<<endl;
                                        //}
                                        
                                        string timePointString;
                                        string roundString;
                                        int timePointSet = 0;
                                        int roundSet = 0;
                                        int fileEntryCount2 = 0;
                                        
                                        for (int counter1 = 0; counter1 < fileNoBMPCount*7; counter1++){
                                            if (fileNameListTemp [counter1] != "" && (int)fileNameListTemp [counter1].find ("TIF") == -1){
                                                timePointSet = atoi(fileNameListTemp [counter1].substr(8, 4).c_str());
                                                roundSet = atoi(fileNameListTemp [counter1].substr(fileNameListTemp [counter1].find("TIF")+3).c_str());
                                                
                                                timePointString = to_string(timePointList [timePointSet]);
                                                roundString = to_string(roundNoList [roundSet]);
                                                
                                                if (timePointString.length() == 1) timePointString = "000"+timePointString;
                                                else if (timePointString.length() == 2) timePointString = "00"+timePointString;
                                                else if (timePointString.length() == 3) timePointString = "0"+timePointString;
                                                
                                                if (roundString.length() == 1) roundString = "0"+roundString;
                                                
                                                sourceFileName = imageDisplayPath+"/"+fileNameListTemp [counter1];
                                                destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+".TIF"+roundString;
                                                
                                                fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+".TIF", fileEntryCount2++;
                                                
                                                rename (sourceFileName.c_str(), destinationFileName.c_str());
                                            }
                                            else if (fileNameListTemp [counter1] != "" && (int)fileNameListTemp [counter1].find ("TIF") != -1){
                                                timePointSet = atoi(fileNameListTemp [counter1].substr(8, 4).c_str());
                                                roundSet = atoi(fileNameListTemp [counter1].substr(fileNameListTemp [counter1].find("TIF")+3).c_str());
                                                colorName = fileNameListTemp [counter1].substr(12, fileNameListTemp [counter1].find(".TIF")-12);
                                                
                                                timePointString = to_string(timePointList [timePointSet]);
                                                roundString = to_string(roundNoList [roundSet]);
                                                
                                                if (timePointString.length() == 1) timePointString = "000"+timePointString;
                                                else if (timePointString.length() == 2) timePointString = "00"+timePointString;
                                                else if (timePointString.length() == 3) timePointString = "0"+timePointString;
                                                
                                                if (roundString.length() == 1) roundString = "0"+roundString;
                                                
                                                sourceFileName = imageDisplayPath+"/"+fileNameListTemp [counter1];
                                                destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+colorName+".TIF"+roundString;
                                                
                                                fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+colorName+".TIF"+roundString, fileEntryCount2++;
                                                
                                                rename (sourceFileName.c_str(), destinationFileName.c_str());
                                            }
                                        }
                                        
                                        for (int counter1 = 0; counter1 < fileEntryCount2; counter1++){
                                            sourceFileName = imageDisplayPath+"/"+fileNameListTemp2 [counter1];
                                            destinationFileName = imageDisplayPath+"/"+fileNameListTemp2 [counter1].substr(1);
                                            rename (sourceFileName.c_str(), destinationFileName.c_str());
                                        }
                                        
                                        string imageNoTemp;
                                        lastTIFRoundNo = 0;
                                        
                                        dir = opendir(imageDisplayPath.c_str());
                                        
                                        if (dir != NULL){
                                            string entry;
                                            
                                            while((dent = readdir(dir))){
                                                entry = dent -> d_name;
                                                
                                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                                    if ((int)entry.find("STimage") != -1){
                                                        imageNoTemp = entry.substr(8, 4);
                                                        
                                                        if (atoi(imageNoTemp.c_str()) > maxNoTemp) maxNoTemp = atoi(imageNoTemp.c_str());
                                                        if ((int)entry.find("TIF") != -1 && lastTIFRoundNo < atoi(entry.substr(entry.find("TIF")+3).c_str())){
                                                            lastTIFRoundNo = atoi(entry.substr(entry.find("TIF")+3).c_str());
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            closedir(dir);
                                        }
                                        
                                        maxImageNo = maxNoTemp;
                                    }
                                    else{
                                        
                                        if (mergeCount == 1){
                                            colorName = fileNameGet2.substr(12, fileNameGet2.find(".BMP")-12);
                                            fileNameMerge3 = "STimage "+mergeTimeNo+colorName+".BMP"+mergeRoundNo;
                                            
                                            fileList [(mergeTimeNoInt-1)*7+2] = fileNameMerge3;
                                            
                                            sourceFileName = imageDisplayPath+"/"+fileNameGet2;
                                            destinationFileName = imageDisplayPath+"/"+fileNameMerge3;
                                            
                                            rename (sourceFileName.c_str(), destinationFileName.c_str());
                                            
                                            if (fileNameMerge4 == "" && fileNameGet3 != ""){
                                                colorName = fileNameGet3.substr(12, fileNameGet3.find(".BMP")-12);
                                                fileNameMerge4 = "STimage "+mergeTimeNo+colorName+".BMP"+mergeRoundNo;
                                                
                                                fileList [(mergeTimeNoInt-1)*7+3] = fileNameMerge4;
                                                
                                                sourceFileName = imageDisplayPath+"/"+fileNameGet3;
                                                destinationFileName = imageDisplayPath+"/"+fileNameMerge4;
                                                
                                                rename (sourceFileName.c_str(), destinationFileName.c_str());
                                            }
                                        }
                                        else if (mergeCount == 2){
                                            colorName = fileNameGet2.substr(12, fileNameGet2.find(".BMP")-12);
                                            fileNameMerge4 = "STimage "+mergeTimeNo+colorName+".BMP"+mergeRoundNo;
                                            
                                            fileList [(mergeTimeNoInt-1)*7+3] = fileNameMerge4;
                                            
                                            sourceFileName = imageDisplayPath+"/"+fileNameGet2;
                                            destinationFileName = imageDisplayPath+"/"+fileNameMerge4;
                                            
                                            rename (sourceFileName.c_str(), destinationFileName.c_str());
                                        }
                                        
                                        sourceFileName = imageDisplayPath+"/"+fileNameGet1;
                                        remove (sourceFileName.c_str());
                                        
                                        int fileEntryCount = 0;
                                        
                                        for (int counter1 = 1; counter1 <= maxImageNo; counter1++){
                                            if ((int)fileList [(counter1-1)*7+1].find("BMP") != -1 && fileList [(counter1-1)*7] != fileNameGet1){
                                                fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7], fileEntryCount++;
                                                fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+1], fileEntryCount++;
                                                fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+2], fileEntryCount++;
                                                fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+3], fileEntryCount++;
                                                fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+4], fileEntryCount++;
                                                fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+5], fileEntryCount++;
                                                fileNameListTemp [fileEntryCount] = fileList [(counter1-1)*7+6], fileEntryCount++;
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < fileEntryCount/4; counterA++){
                                        //    cout<<counterA<<" "<<fileNameListTemp [counterA*7]<<" "<<fileNameListTemp [counterA*7+1]<<" "<<fileNameListTemp [counterA*7+2]<<" "<<fileNameListTemp [counterA*7+3]<<" List"<<endl;
                                        //}
                                        
                                        for (int counter1 = 0; counter1 < fileNoBMPCount*7; counter1++){
                                            if (fileNameListTemp [counter1] != ""){
                                                roundNoList [atoi(fileNameListTemp [counter1].substr(fileNameListTemp [counter1].find("BMP")+4).c_str())]++;
                                                timePointList [atoi(fileNameListTemp [counter1].substr(8, 4).c_str())]++;
                                            }
                                        }
                                        
                                        int newRoundNo = 1;
                                        int newTimeNo = timePointStart;
                                        
                                        for (int counter1 = 0; counter1 < fileNoBMPCount+2; counter1++){
                                            if (roundNoList [counter1] != 0){
                                                roundNoList [counter1] = newRoundNo;
                                                newRoundNo++;
                                            }
                                        }
                                        
                                        for (int counter1 = 0; counter1 < maxImageNo+2; counter1++){
                                            if (timePointList [counter1] != 0){
                                                timePointList [counter1] = newTimeNo;
                                                newTimeNo++;
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < fileNoBMPCount+2; counterA++){
                                        //    cout<<counterA<<" "<<roundNoList [counterA]<<" roundNoList "<<endl;
                                        //}
                                        
                                        //for (int counterA = 0; counterA < maxImageNo+2; counterA++){
                                        //    cout<<counterA<<" "<<timePointList [counterA]<<" timePointList "<<endl;
                                        //}
                                        
                                        string timePointString;
                                        string roundString;
                                        int timePointSet = 0;
                                        int roundSet = 0;
                                        int fileEntryCount2 = 0;
                                        
                                        for (int counter1 = 0; counter1 < fileNoBMPCount*7; counter1++){
                                            if (fileNameListTemp [counter1] != "" && (int)fileNameListTemp [counter1].find ("BMP") == -1){
                                                timePointSet = atoi(fileNameListTemp [counter1].substr(8, 4).c_str());
                                                roundSet = atoi(fileNameListTemp [counter1].substr(fileNameListTemp [counter1].find("BMP")+3).c_str());
                                                
                                                timePointString = to_string(timePointList [timePointSet]);
                                                roundString = to_string(roundNoList [roundSet]);
                                                
                                                if (timePointString.length() == 1) timePointString = "000"+timePointString;
                                                else if (timePointString.length() == 2) timePointString = "00"+timePointString;
                                                else if (timePointString.length() == 3) timePointString = "0"+timePointString;
                                                
                                                if (roundString.length() == 1) roundString = "0"+roundString;
                                                
                                                sourceFileName = imageDisplayPath+"/"+fileNameListTemp [counter1];
                                                destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+".BMP"+roundString;
                                                
                                                fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+".BMP", fileEntryCount2++;
                                                
                                                rename (sourceFileName.c_str(), destinationFileName.c_str());
                                            }
                                            else if (fileNameListTemp [counter1] != "" && (int)fileNameListTemp [counter1].find ("BMP") != -1){
                                                timePointSet = atoi(fileNameListTemp [counter1].substr(8, 4).c_str());
                                                roundSet = atoi(fileNameListTemp [counter1].substr(fileNameListTemp [counter1].find("BMP")+3).c_str());
                                                colorName = fileNameListTemp [counter1].substr(12, fileNameListTemp [counter1].find(".BMP")-12);
                                                
                                                timePointString = to_string(timePointList [timePointSet]);
                                                roundString = to_string(roundNoList [roundSet]);
                                                
                                                if (timePointString.length() == 1) timePointString = "000"+timePointString;
                                                else if (timePointString.length() == 2) timePointString = "00"+timePointString;
                                                else if (timePointString.length() == 3) timePointString = "0"+timePointString;
                                                
                                                if (roundString.length() == 1) roundString = "0"+roundString;
                                                
                                                sourceFileName = imageDisplayPath+"/"+fileNameListTemp [counter1];
                                                destinationFileName = imageDisplayPath+"/"+"*STimage "+timePointString+colorName+".BMP"+roundString;
                                                
                                                fileNameListTemp2 [fileEntryCount2] = "*STimage "+timePointString+colorName+".BMP"+roundString, fileEntryCount2++;
                                                
                                                rename (sourceFileName.c_str(), destinationFileName.c_str());
                                            }
                                        }
                                        
                                        for (int counter1 = 0; counter1 < fileEntryCount2; counter1++){
                                            sourceFileName = imageDisplayPath+"/"+fileNameListTemp2 [counter1];
                                            destinationFileName = imageDisplayPath+"/"+fileNameListTemp2 [counter1].substr(1);
                                            rename (sourceFileName.c_str(), destinationFileName.c_str());
                                        }
                                        
                                        string imageNoTemp;
                                        lastTIFRoundNo = 0;
                                        
                                        dir = opendir(imageDisplayPath.c_str());
                                        
                                        if (dir != NULL){
                                            string entry;
                                            
                                            while((dent = readdir(dir))){
                                                entry = dent -> d_name;
                                                
                                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                                    if ((int)entry.find("STimage") != -1){
                                                        imageNoTemp = entry.substr(8, 4);
                                                        
                                                        if (atoi(imageNoTemp.c_str()) > maxNoTemp) maxNoTemp = atoi(imageNoTemp.c_str());
                                                        if ((int)entry.find("BMP") != -1 && lastTIFRoundNo < atoi(entry.substr(entry.find("BMP")+3).c_str())){
                                                            lastTIFRoundNo = atoi(entry.substr(entry.find("BMP")+3).c_str());
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            closedir(dir);
                                        }
                                        
                                        maxImageNo = maxNoTemp;
                                    }
                                    
                                    delete [] fileList;
                                    
                                    fileList = new string [maxImageNo*7+4];
                                    fileListCount = 0;
                                    
                                    string *fileListTemp = new string [maxNoTemp*7+4];
                                    int fileListTempCount = 0;
                                    
                                    dir = opendir(imageDisplayPath.c_str());
                                    
                                    if (dir != NULL){
                                        string entry;
                                        
                                        while((dent = readdir(dir))){
                                            entry = dent -> d_name;
                                            
                                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                                if ((int)entry.find("STimage") != -1){
                                                    fileListTemp [fileListTempCount] = entry, fileListTempCount++;
                                                }
                                            }
                                        }
                                        
                                        closedir(dir);
                                    }
                                    
                                    //-----Directory Sort----
                                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                                    
                                    for (int counter1 = 0; counter1 < fileListTempCount; counter1++){
                                        [unsortedArray addObject:@(fileListTemp [counter1].c_str())];
                                    }
                                    
                                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                                    
                                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                                        fileListTemp [counter1] = [unsortedArray [counter1] UTF8String];
                                    }
                                    
                                    for (int counter1 = 0; counter1 < fileListTempCount; counter1++){
                                        if ((int)fileListTemp [counter1].find("_") == -1){
                                            fileList [fileListCount] = fileListTemp [counter1], fileListCount++;
                                            fileList [fileListCount] = "", fileListCount++;
                                            fileList [fileListCount] = "", fileListCount++;
                                            fileList [fileListCount] = "", fileListCount++;
                                            fileList [fileListCount] = "", fileListCount++;
                                            fileList [fileListCount] = "", fileListCount++;
                                            fileList [fileListCount] = "", fileListCount++;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < fileListCount/4; counterA++){
                                    //    cout<<counterA<<" "<<fileList [counterA*7]<<" "<<fileList [counterA*7+1]<<" "<<fileList [counterA*7+2]<<" "<<fileList [counterA*7+3]<<" List"<<endl;
                                    //}
                                    
                                    int timePosition = 0;
                                    
                                    for (int counter1 = 0; counter1 < fileListTempCount; counter1++){
                                        if ((int)fileListTemp [counter1].find("_1_") != -1 || (int)fileListTemp [counter1].find("_2_") != -1 || (int)fileListTemp [counter1].find("_3_") != -1 || (int)fileListTemp [counter1].find("_4_") != -1 || (int)fileListTemp [counter1].find("_5_") != -1 || (int)fileListTemp [counter1].find("_6_") != -1 || (int)fileListTemp [counter1].find("_7_") != -1 || (int)fileListTemp [counter1].find("_8_") != -1 || (int)fileListTemp [counter1].find("_9_") != -1){
                                            timePosition = atoi(fileListTemp [counter1].substr(fileListTemp [counter1].find("STimage ")+8, 4).c_str())-1;
                                            
                                            if (fileList [timePosition*7+1] == "") fileList [timePosition*7+1] = fileListTemp [counter1];
                                            else if (fileList [timePosition*7+2] == "") fileList [timePosition*7+2] = fileListTemp [counter1];
                                            else if (fileList [timePosition*7+3] == "") fileList [timePosition*7+3] = fileListTemp [counter1];
                                            else if (fileList [timePosition*7+4] == "") fileList [timePosition*7+4] = fileListTemp [counter1];
                                            else if (fileList [timePosition*7+5] == "") fileList [timePosition*7+5] = fileListTemp [counter1];
                                            else if (fileList [timePosition*7+6] == "") fileList [timePosition*7+6] = fileListTemp [counter1];
                                        }
                                    }
                                    
                                    delete [] fileListTemp;
                                    
                                    fileNoBMPCount = 0;
                                    
                                    for (int counter1 = 1; counter1 <= maxImageNo; counter1++){
                                        if (fileList [(counter1-1)*7+1] != ""){
                                            if ((int)fileList [(counter1-1)*7+1].find("TIF") != -1|| (int)fileList [(counter1-1)*7+1].find("BMP") != -1) fileNoBMPCount++;
                                            
                                            if (fileList [(counter1-1)*7+2] != ""){
                                                if ((int)fileList [(counter1-1)*7+2].find("TIF") != -1 || (int)fileList [(counter1-1)*7+2].find("BMP") != -1) fileNoBMPCount++;
                                                
                                                if (fileList [(counter1-1)*7+3] != ""){
                                                    if ((int)fileList [(counter1-1)*7+3].find("TIF") != -1 || (int)fileList [(counter1-1)*7+3].find("BMP") != -1) fileNoBMPCount++;
                                                    
                                                    if (fileList [(counter1-1)*7+4] != ""){
                                                        if ((int)fileList [(counter1-1)*7+4].find("TIF") != -1 || (int)fileList [(counter1-1)*7+4].find("BMP") != -1) fileNoBMPCount++;
                                                        
                                                        if (fileList [(counter1-1)*7+5] != ""){
                                                            if ((int)fileList [(counter1-1)*7+5].find("TIF") != -1 || (int)fileList [(counter1-1)*7+5].find("BMP") != -1) fileNoBMPCount++;
                                                            
                                                            if (fileList [(counter1-1)*7+6] != ""){
                                                                if ((int)fileList [(counter1-1)*7+6].find("TIF") != -1 || (int)fileList [(counter1-1)*7+6].find("BMP") != -1) fileNoBMPCount++;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    delete [] fileNameListTemp;
                                    delete [] fileNameListTemp2;
                                    delete [] roundNoList;
                                    delete [] timePointList;
                                    
                                    selectedFile = "";
                                    fluorescentColorNoFluorescent = 0;
                                    xMovePositionHoldMain = 0;
                                    yMovePositionHoldMain = 0;
                                    referenceImageStatusFluorescent = 0;
                                    
                                    [tableViewTDList reloadData];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                    
                                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentAdjust object:self];
                                }
                                else{
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"Duplicate File Name Detected"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                            }
                            else{
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Exceeded Channel Limit (Max 6)"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Select Different No."];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Select Different No."];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"File Not Found"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Value Out of Range"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"IF Image Loaded"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)closeWindow:(id)sender{
    [adjustWindow orderOut:self];
    positionAdjustOperationFluorescent = 2;
    adjustTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (positionAdjustOperationFluorescent == 3){
        [adjustWindow makeKeyAndOrderFront:self];
        positionAdjustOperationFluorescent = 1;
        [adjustTimer invalidate];
    }
}

-(void)dealloc{
    if (adjustTimer) [adjustTimer invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToFluorescentController object:nil];
}

@end
