//
//  LabelSet.h
//  CellMovie
//
//  Created by Masahiko Sato on 2022-02-01.
//

#ifndef LABELSET_H
#define LABELSET_H
#import "Controller.h"
#endif

@interface LabelSet : NSObject <NSTextFieldDelegate>{
    int progressTimingL; //Process timing
    int textChangeDisplayCall; //Call when text is changed
    
    IBOutlet NSTextField *labelDisplayTitle1;
    IBOutlet NSTextField *labelDisplayX1;
    IBOutlet NSTextField *labelDisplayY1;
    IBOutlet NSTextField *labelDisplayPrint1;
    IBOutlet NSTextField *labelDisplayFont1;
    IBOutlet NSTextField *labelDisplayColor1;
    
    IBOutlet NSTextField *labelDisplayTitle2;
    IBOutlet NSTextField *labelDisplayX2;
    IBOutlet NSTextField *labelDisplayY2;
    IBOutlet NSTextField *labelDisplayPrint2;
    IBOutlet NSTextField *labelDisplayFont2;
    IBOutlet NSTextField *labelDisplayColor2;
    
    IBOutlet NSTextField *incrementDisplayTitle;
    IBOutlet NSTextField *incrementDisplayX;
    IBOutlet NSTextField *incrementDisplayY;
    IBOutlet NSTextField *incrementDisplayInterval;
    IBOutlet NSTextField *incrementDisplayStart;
    IBOutlet NSTextField *incrementDisplayFont;
    IBOutlet NSTextField *incrementDisplayColor;
    
    IBOutlet NSTextField *scaleDisplayTitle;
    IBOutlet NSTextField *scaleDisplayX;
    IBOutlet NSTextField *scaleDisplayY;
    IBOutlet NSTextField *scaleDisplayLength;
    IBOutlet NSTextField *scaleDisplayWidth;
    IBOutlet NSTextField *scaleDisplayColor;
    
    IBOutlet NSTextField *setCropDisplay;
    IBOutlet NSTextField *imageSizeSetDisplay;
    
    IBOutlet NSWindow *labelSetWindow;
    
    NSTimer *labelSetTimer;
    NSTimer *labelSetTimer2;
    
    NSWindowController *labelSetWindController;
    
    id tiffFileRead;
    id singleTiffSave;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;
-(void)display;

-(IBAction)closeWindow:(id)sender;
-(IBAction)saveImage:(id)sender;
-(IBAction)imageLoad:(id)sender;
-(IBAction)labelActive1:(id)sender;
-(IBAction)labelFontSet1:(id)sender;
-(IBAction)labelColorSet1:(id)sender;
-(IBAction)labelClear1:(id)sender;
-(IBAction)labelActive2:(id)sender;
-(IBAction)labelFontSet2:(id)sender;
-(IBAction)labelColorSet2:(id)sender;
-(IBAction)labelClear2:(id)sender;
-(IBAction)incrementActive:(id)sender;
-(IBAction)incrementFontSet:(id)sender;
-(IBAction)incrementColorSet:(id)sender;
-(IBAction)incrementClear:(id)sender;
-(IBAction)scaleBarActive:(id)sender;
-(IBAction)scaleBarWidthSet:(id)sender;
-(IBAction)scaleBarColorSet:(id)sender;
-(IBAction)scaleBarClear:(id)sender;

-(IBAction)setCrop:(id)sender;
-(IBAction)printStopSet:(id)sender;
-(IBAction)imageSizeSet:(id)sender;

@end
