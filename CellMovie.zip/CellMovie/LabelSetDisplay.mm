//
//  LabelSetDisplay.m
//  CellMovie
//
//  Created by Masahiko Sato on 2022-02-01.
//

#import "LabelSetDisplay.h"

NSString *notificationToLabelSetDisplay = @"notificationExecuteLabelSetDisplay";

@implementation LabelSetDisplay

- (id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self) {
        labelSetImage = [[NSImage alloc] initWithContentsOfFile:@""];
        
        imageFirstLoadFlagDisplayLabel = 0;
        magnificationDisplayLabel = 10;
        mouseDragFlag = 0;
        mouseDownFlag = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToLabelSetDisplay object:nil];
    }
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    if (imageLoadFlagLabel == 1){
        int dicStitchDimension = 0;
        int counterIncrement = 0;
        
        if (imageXYLength <= 1000){
            dicStitchDimension = imageXYLength;
            counterIncrement = 1;
        }
        else if (imageXYLength <= 4000){
            dicStitchDimension = imageXYLength/2;
            counterIncrement = 2;
        }
        else{
            
            dicStitchDimension = imageXYLength/4;
            counterIncrement = 4;
        }
        
        if (grayColorStatus == 0){
            NSBitmapImageRep *bitmapReps = nil;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:dicStitchDimension pixelsHigh:dicStitchDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:dicStitchDimension*4 bitsPerPixel:32];
            
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            int readDataTemp = 0;
            
            for (int counterY = 0; counterY < imageXYLength; counterY = counterY+counterIncrement){
                for (int counterX = 0; counterX < imageXYLength; counterX = counterX+counterIncrement){
                    readDataTemp = arrayLabelImage [counterY][counterX];
                    
                    *bitmapData++ = (unsigned char)readDataTemp;
                    *bitmapData++ = (unsigned char)readDataTemp;
                    *bitmapData++ = (unsigned char)readDataTemp;
                    *bitmapData++ = 0;
                }
            }
            
            labelSetImage = [[NSImage alloc] initWithSize:NSMakeSize(imageXYLength, imageXYLength)];
            [labelSetImage addRepresentation:bitmapReps];
        }
        else if (grayColorStatus == 1){
            NSBitmapImageRep *bitmapReps = nil;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageXYLength pixelsHigh:imageXYLength bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageXYLength*4 bitsPerPixel:32];
            
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            int readDataTemp = 0;
            int readDataTemp2 = 0;
            int readDataTemp3 = 0;
            
            for (int counterY = 0; counterY < imageXYLength; counterY++){
                for (int counterX = 0; counterX < imageXYLength; counterX++){
                    readDataTemp = arrayLabelImage [counterY][counterX*3];
                    readDataTemp2 = arrayLabelImage [counterY][counterX*3+1];
                    readDataTemp3 = arrayLabelImage [counterY][counterX*3+2];
                    
                    *bitmapData++ = (unsigned char)readDataTemp;
                    *bitmapData++ = (unsigned char)readDataTemp2;
                    *bitmapData++ = (unsigned char)readDataTemp3;
                    *bitmapData++ = 0;
                }
            }
            
            labelSetImage = [[NSImage alloc] initWithSize:NSMakeSize(imageXYLength, imageXYLength)];
            [labelSetImage addRepresentation:bitmapReps];
        }
        
        if (imageFirstLoadFlagDisplayLabel == 0){
            xPositionDisplayLabel = 0;
            yPositionDisplayLabel = 0;
            xPositionAdjustDisplayLabel = 0;
            yPositionAdjustDisplayLabel = 0;
            magnificationDisplayLabel = 10;
            imageFirstLoadFlagDisplayLabel = 1;
        }
        
        //----Window size and Position re-adjust----
        int vertical = 500+78;
        int horizontal = 500;
        
        windowWidthDisplayLabel = imageXYLength/(double)horizontal;
        windowHeightDisplayLabel = imageXYLength/(double)(vertical-78);
        
        xPositionAdjustDisplayLabel = (imageXYLength-imageXYLength/(double)(magnificationDisplayLabel*0.1))/(double)2;
        yPositionAdjustDisplayLabel = (imageXYLength-imageXYLength/(double)(magnificationDisplayLabel*0.1))/(double)2;
    }
    
    [self setNeedsDisplay:YES];
}

-(void)mouseDown:(NSEvent *)event{
    if (imageLoadFlagLabel == 1){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        
        xMovePositionHold = 0;
        yMovePositionHold = 0;
        
        double xPositionAdj = xPositionAdjustDisplayLabel+xPositionDisplayLabel;
        double yPositionAdj = yPositionAdjustDisplayLabel+yPositionDisplayLabel;
        double xCalValue = 1/(double)windowWidthDisplayLabel*magnificationDisplayLabel*0.1;
        double yCalValue = 1/(double)windowHeightDisplayLabel*magnificationDisplayLabel*0.1;
        
        int xPointMarkTemp = (int)(clickPoint.x/(double)xCalValue+xPositionAdj);
        int yPointMarkTemp = (int)((clickPoint.y/(double)yCalValue+yPositionAdj-imageXYLength)*-1);
        
        xPositionExHold = xPointMarkTemp;
        yPositionExHold = yPointMarkTemp;
        
        if (currentActiveHold == 1){
            labelX1 = xPositionExHold;
            labelY1 = yPositionExHold;
        }
        else if (currentActiveHold == 2){
            labelX2 = xPositionExHold;
            labelY2 = yPositionExHold;
        }
        else if (currentActiveHold == 3){
            incrementX = xPositionExHold;
            incrementY = yPositionExHold;
        }
        else if (currentActiveHold == 4){
            scaleBarX = xPositionExHold;
            scaleBarY = yPositionExHold;
        }
        
        xyPositionLabelCall1 = 1;
        xyPositionLabelCall2 = 1;
        
        if (setCropStatus == 0){
            xPointDownDisplayLabel = clickPoint.x;
            yPointDownDisplayLabel = clickPoint.y;
        }
        else if (setCropStatus == 1){
            boxStartX = clickPoint.x;
            boxStartY = clickPoint.y;
            boxEndX = clickPoint.x;
            boxEndY = clickPoint.y;
            
            boxStartImageX = xPointMarkTemp;
            boxStartImageY = yPointMarkTemp;
            boxEndImageX = xPointMarkTemp;
            boxEndImageY = yPointMarkTemp;
        }
    }
}

-(void)mouseUp:(NSEvent *)event{
    if (imageLoadFlagLabel == 1){
        if (setCropStatus == 0){
            xPositionDisplayLabel = xPositionDisplayLabel+xPositionMoveDisplayLabel;
            yPositionDisplayLabel = yPositionDisplayLabel+yPositionMoveDisplayLabel;
            xPositionMoveDisplayLabel = 0;
            yPositionMoveDisplayLabel = 0;
            mouseDragFlag = 0;
            
            [self setNeedsDisplay:YES];
        }
        else if (setCropStatus == 1){
            NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
            boxEndX = clickPoint.x;
            boxEndY = clickPoint.y;
            
            double xPositionAdj = xPositionAdjustDisplayLabel+xPositionDisplayLabel;
            double yPositionAdj = yPositionAdjustDisplayLabel+yPositionDisplayLabel;
            double xCalValue = 1/(double)windowWidthDisplayLabel*magnificationDisplayLabel*0.1;
            double yCalValue = 1/(double)windowHeightDisplayLabel*magnificationDisplayLabel*0.1;
            
            int xPointMarkTemp = (int)(clickPoint.x/(double)xCalValue+xPositionAdj);
            int yPointMarkTemp = (int)((clickPoint.y/(double)yCalValue+yPositionAdj-imageXYLength)*-1);
            
            boxEndImageX = xPointMarkTemp;
            boxEndImageY = yPointMarkTemp;
            
            [self setNeedsDisplay:YES];
        }
    }
}

-(void)mouseDragged:(NSEvent *)event{
    if (imageLoadFlagLabel == 1){
        if (setCropStatus == 0){
            NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
            xPointDragDisplayLabel = clickPoint.x;
            yPointDragDisplayLabel = clickPoint.y;
            xPositionMoveDisplayLabel = (xPointDownDisplayLabel-xPointDragDisplayLabel)*windowWidthDisplayLabel/(double)(magnificationDisplayLabel*0.1);
            yPositionMoveDisplayLabel = (yPointDownDisplayLabel-yPointDragDisplayLabel)*windowHeightDisplayLabel/(double)(magnificationDisplayLabel*0.1);
            mouseDragFlag = 1;
            [self setNeedsDisplay:YES];
        }
        else if (setCropStatus == 1){
            NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
            boxEndX = clickPoint.x;
            boxEndY = clickPoint.y;
            
            double xPositionAdj = xPositionAdjustDisplayLabel+xPositionDisplayLabel;
            double yPositionAdj = yPositionAdjustDisplayLabel+yPositionDisplayLabel;
            double xCalValue = 1/(double)windowWidthDisplayLabel*magnificationDisplayLabel*0.1;
            double yCalValue = 1/(double)windowHeightDisplayLabel*magnificationDisplayLabel*0.1;
            
            int xPointMarkTemp = (int)(clickPoint.x/(double)xCalValue+xPositionAdj);
            int yPointMarkTemp = (int)((clickPoint.y/(double)yCalValue+yPositionAdj-imageXYLength)*-1);
            
            boxEndImageX = xPointMarkTemp;
            boxEndImageY = yPointMarkTemp;
            
            [self setNeedsDisplay:YES];
        }
    }
}

-(void)keyDown:(NSEvent *)event{
    int keyCode = [event keyCode];
    
    if (copyProgressFlag == 0){
        //----Magnification Magnify----
        if (keyCode == 125){
            if (magnificationDisplayLabel >= 10 && magnificationDisplayLabel <= 350){
                if (magnificationDisplayLabel-10 < 10) magnificationDisplayLabel = 10;
                else magnificationDisplayLabel = magnificationDisplayLabel-10;
                
                xPositionAdjustDisplayLabel = -1*(imageXYLength/(double)(magnificationDisplayLabel*0.1)-imageXYLength)/(double)2;
                yPositionAdjustDisplayLabel = -1*(imageXYLength/(double)(magnificationDisplayLabel*0.1)-imageXYLength)/(double)2;
                
                [self setNeedsDisplay:YES];
            }
        }
        
        //----Magnification Reduction----
        if (keyCode == 126){
            if (magnificationDisplayLabel >= 10 && magnificationDisplayLabel <= 498){
                if (magnificationDisplayLabel+10 > 498) magnificationDisplayLabel = 498;
                else magnificationDisplayLabel = magnificationDisplayLabel+10;
                
                xPositionAdjustDisplayLabel = (imageXYLength-imageXYLength/(double)(magnificationDisplayLabel*0.1))/(double)2;
                yPositionAdjustDisplayLabel = (imageXYLength-imageXYLength/(double)(magnificationDisplayLabel*0.1))/(double)2;
                
                [self setNeedsDisplay:YES];
            }
        }
    }
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect{
    [[NSColor blackColor] set];
    
    NSBezierPath *path;
    path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 500, 500)];
    [path fill];
    
    NSRect srcRect;
    
    srcRect.origin.x = xPositionDisplayLabel+xPositionAdjustDisplayLabel+xPositionMoveDisplayLabel;
    srcRect.origin.y = yPositionDisplayLabel+yPositionAdjustDisplayLabel+yPositionMoveDisplayLabel;
    srcRect.size.width = imageXYLength/(double)(magnificationDisplayLabel*0.1);
    srcRect.size.height = imageXYLength/(double)(magnificationDisplayLabel*0.1);
    
    [labelSetImage drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
    
    NSPoint pointA;
    NSAttributedString *attrStrA;
    NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
    
    if (imageFirstLoadFlagDisplayLabel == 1){
        double xPositionAdj = xPositionAdjustDisplayLabel+xPositionDisplayLabel;
        double yPositionAdj = yPositionAdjustDisplayLabel+yPositionDisplayLabel;
        double xCalValue = 1/(double)windowWidthDisplayLabel*magnificationDisplayLabel*0.1;
        double yCalValue = 1/(double)windowHeightDisplayLabel*magnificationDisplayLabel*0.1;
        double magnificationFont = magnificationDisplayLabel*0.1;
        
        int xPointMarkTemp = 0;
        int yPointMarkTemp = 0;
        int xPointMarkTemp2 = 0;
        
        if (labelX1 != -1 && labelY1 != -1 && exportFlag == 0){
            double labelFontSize1 = 0;
            
            if (labelFont1 == 1) labelFontSize1 = 12;
            else if (labelFont1 == 2) labelFontSize1 = 14;
            else if (labelFont1 == 3) labelFontSize1 = 16;
            else if (labelFont1 == 4) labelFontSize1 = 18;
            else if (labelFont1 == 5) labelFontSize1 = 20;
            else if (labelFont1 == 6) labelFontSize1 = 30;
            else if (labelFont1 == 7) labelFontSize1 = 40;
            else if (labelFont1 == 8) labelFontSize1 = 60;
            else if (labelFont1 == 9) labelFontSize1 = 80;
            else if (labelFont1 == 10) labelFontSize1 = 0;
            else if (labelFont1 == 11) labelFontSize1 = 4;
            else if (labelFont1 == 12) labelFontSize1 = 8;
            else if (labelFont1 == 13) labelFontSize1 = 10;
            
            if (labelFontSize1 != 0){
                NSString *labelFontNSString1 = @(labelPrint1.c_str());
                
                [attributesA setObject:[NSFont boldSystemFontOfSize:labelFontSize1*magnificationFont*xCalValue] forKey:NSFontAttributeName];
                
                xPointMarkTemp = (int)((labelX1-xPositionAdj)*(double)xCalValue);
                yPointMarkTemp = (int)(((imageXYLength-labelY1)-yPositionAdj)*(double)yCalValue);
                
                if (labelColor1 == 1) [attributesA setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                else if (labelColor1 == 2)  [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                else if (labelColor1 == 3)  [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                else if (labelColor1 == 4)  [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                else if (labelColor1 == 5)  [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                else if (labelColor1 == 6)  [attributesA setObject:[NSColor brownColor] forKey: NSForegroundColorAttributeName];
                else if (labelColor1 == 7)  [attributesA setObject:[NSColor cyanColor] forKey: NSForegroundColorAttributeName];
                else if (labelColor1 == 8)  [attributesA setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
                else if (labelColor1 == 9)  [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                else if (labelColor1 == 10)  [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA = [[NSAttributedString alloc] initWithString:labelFontNSString1 attributes:attributesA];
                pointA.x = xPointMarkTemp;
                pointA.y = yPointMarkTemp;
                [attrStrA drawAtPoint:pointA];
            }
        }
        
        if (labelX2 != -1 && labelY2 != -1 && exportFlag == 0){
            double labelFontSize2 = 0;
            
            if (labelFont2 == 1) labelFontSize2 = 12;
            else if (labelFont2 == 2) labelFontSize2 = 14;
            else if (labelFont2 == 3) labelFontSize2 = 16;
            else if (labelFont2 == 4) labelFontSize2 = 18;
            else if (labelFont2 == 5) labelFontSize2 = 20;
            else if (labelFont2 == 6) labelFontSize2 = 30;
            else if (labelFont2 == 7) labelFontSize2 = 40;
            else if (labelFont2 == 8) labelFontSize2 = 60;
            else if (labelFont2 == 9) labelFontSize2 = 80;
            else if (labelFont2 == 10) labelFontSize2 = 0;
            else if (labelFont2 == 11) labelFontSize2 = 4;
            else if (labelFont2 == 12) labelFontSize2 = 8;
            else if (labelFont2 == 13) labelFontSize2 = 10;
            
            if (labelFontSize2 != 0){
                NSString *labelFontNSString2 = @(labelPrint2.c_str());
                
                [attributesA setObject:[NSFont boldSystemFontOfSize:labelFontSize2*magnificationFont*xCalValue] forKey:NSFontAttributeName];
                
                xPointMarkTemp = (int)((labelX2-xPositionAdj)*(double)xCalValue);
                yPointMarkTemp = (int)(((imageXYLength-labelY2)-yPositionAdj)*(double)yCalValue);
                
                if (labelColor2 == 1) [attributesA setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                else if (labelColor2 == 2)  [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                else if (labelColor2 == 3)  [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                else if (labelColor2 == 4)  [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                else if (labelColor2 == 5)  [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                else if (labelColor2 == 6)  [attributesA setObject:[NSColor brownColor] forKey: NSForegroundColorAttributeName];
                else if (labelColor2 == 7)  [attributesA setObject:[NSColor cyanColor] forKey: NSForegroundColorAttributeName];
                else if (labelColor2 == 8)  [attributesA setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
                else if (labelColor2 == 9)  [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                else if (labelColor2 == 10)  [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA = [[NSAttributedString alloc] initWithString:labelFontNSString2 attributes:attributesA];
                pointA.x = xPointMarkTemp;
                pointA.y = yPointMarkTemp;
                [attrStrA drawAtPoint:pointA];
            }
        }
        
        if (incrementX != -1 && incrementY != -1 && exportFlag == 0){
            double incrementFontSize = 0;
            
            if (incrementFont == 1) incrementFontSize = 12;
            else if (incrementFont == 2) incrementFontSize = 14;
            else if (incrementFont == 3) incrementFontSize = 16;
            else if (incrementFont == 4) incrementFontSize = 18;
            else if (incrementFont == 5) incrementFontSize = 20;
            else if (incrementFont == 6) incrementFontSize = 30;
            else if (incrementFont == 7) incrementFontSize = 40;
            else if (incrementFont == 8) incrementFontSize = 60;
            else if (incrementFont == 9) incrementFontSize = 80;
            else if (incrementFont == 10) incrementFontSize = 0;
            else if (incrementFont == 11) incrementFontSize = 4;
            else if (incrementFont == 12) incrementFontSize = 8;
            else if (incrementFont == 13) incrementFontSize = 10;
            
            if (incrementFontSize != 0){
                NSString *incrementTestFont = @"00000";
                
                [attributesA setObject:[NSFont boldSystemFontOfSize:incrementFontSize*magnificationFont*xCalValue] forKey:NSFontAttributeName];
                
                xPointMarkTemp = (int)((incrementX-xPositionAdj)*(double)xCalValue);
                yPointMarkTemp = (int)(((imageXYLength-incrementY)-yPositionAdj)*(double)yCalValue);
                
                if (incrementColor == 1) [attributesA setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                else if (incrementColor == 2)  [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                else if (incrementColor == 3)  [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                else if (incrementColor == 4)  [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                else if (incrementColor == 5)  [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                else if (incrementColor == 6)  [attributesA setObject:[NSColor brownColor] forKey: NSForegroundColorAttributeName];
                else if (incrementColor == 7)  [attributesA setObject:[NSColor cyanColor] forKey: NSForegroundColorAttributeName];
                else if (incrementColor == 8)  [attributesA setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
                else if (incrementColor == 9)  [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                else if (incrementColor == 10)  [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA = [[NSAttributedString alloc] initWithString:incrementTestFont attributes:attributesA];
                pointA.x = xPointMarkTemp;
                pointA.y = yPointMarkTemp;
                [attrStrA drawAtPoint:pointA];
            }
        }
        
        if (scaleBarX != -1 && scaleBarY != -1 && exportFlag == 0){
            NSPoint positionAA;
            NSPoint positionBB;
            
            xPointMarkTemp = (int)((scaleBarX-xPositionAdj)*(double)xCalValue);
            yPointMarkTemp = (int)(((imageXYLength-scaleBarY)-yPositionAdj)*(double)yCalValue);
            xPointMarkTemp2 = (int)(((scaleBarX+scaleBarLength)-xPositionAdj)*(double)xCalValue);
            
            if (scaleBarWidth == 1) [NSBezierPath setDefaultLineWidth:3*magnificationFont*xCalValue];
            else if (scaleBarWidth == 2)  [NSBezierPath setDefaultLineWidth:4*magnificationFont*xCalValue];
            else if (scaleBarWidth == 3)  [NSBezierPath setDefaultLineWidth:5*magnificationFont*xCalValue];
            else if (scaleBarWidth == 4)  [NSBezierPath setDefaultLineWidth:6*magnificationFont*xCalValue];
            else if (scaleBarWidth == 5)  [NSBezierPath setDefaultLineWidth:7*magnificationFont*xCalValue];
            else if (scaleBarWidth == 6)  [NSBezierPath setDefaultLineWidth:8*magnificationFont*xCalValue];
            else if (scaleBarWidth == 7)  [NSBezierPath setDefaultLineWidth:0.5*magnificationFont*xCalValue];
            else if (scaleBarWidth == 8)  [NSBezierPath setDefaultLineWidth:1*magnificationFont*xCalValue];
            else if (scaleBarWidth == 9)  [NSBezierPath setDefaultLineWidth:2*magnificationFont*xCalValue];
            
            if (scaleBarColor == 1) [[NSColor whiteColor] set];
            else if (scaleBarColor == 2)  [[NSColor blackColor] set];
            else if (scaleBarColor == 3)  [[NSColor yellowColor] set];
            else if (scaleBarColor == 4)  [[NSColor greenColor] set];
            else if (scaleBarColor == 5)  [[NSColor redColor] set];
            else if (scaleBarColor == 6)  [[NSColor brownColor] set];
            else if (scaleBarColor == 7)  [[NSColor cyanColor] set];
            else if (scaleBarColor == 8)  [[NSColor magentaColor] set];
            else if (scaleBarColor == 9)  [[NSColor orangeColor] set];
            else if (scaleBarColor == 10)  [[NSColor blueColor] set];
            
            positionAA.x = xPointMarkTemp;
            positionAA.y = yPointMarkTemp;
            positionBB.x = xPointMarkTemp2;
            positionBB.y = yPointMarkTemp;
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
        }
        
        //----Info writing----
        if (setCropStatus == 1 && exportFlag == 0){
            [attributesA setObject:[NSFont boldSystemFontOfSize:12] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
            
            string ifString = "Window Lock";
            
            [NSBezierPath setDefaultLineWidth:1*magnificationFont*xCalValue];
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 10;
            pointA.y = 480;
            [attrStrA drawAtPoint:pointA];
        }
        
        if (setCropStatus == 1){
            NSBezierPath *path2;
            path2 = [NSBezierPath bezierPathWithRect: NSMakeRect(boxStartX, boxStartY, boxEndX-boxStartX, boxEndY-boxStartY)];
            [path2 stroke];
        }
        
        if (exportFlag == 1){
            [attributesA setObject:[NSFont boldSystemFontOfSize:12] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
            
            string ifString = labelImageSavePath2.substr(labelImageSavePath2.find("ST"));
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 10;
            pointA.y = 480;
            [attrStrA drawAtPoint:pointA];
        }
        
        //=========Graphic export=========
        if (exportFlag == 1){
            int xImageStart = -1;
            int yImageStart = -1;
            int xImageEnd = -1;
            int yImageEnd = -1;
            int xImageSizeEX = 0;
            int yImageSizeEX = 0;
            
            int **imageLabelExport = new int *[imageXYLength+1];
            
            for (int counterY = 0; counterY < imageXYLength+1; counterY++){
                imageLabelExport [counterY] = new int [imageXYLength*3+1];
            }
            
            int imageSizeUpdate = imageXYLength+1;
            int imageExpansionMode = 0;
            
            if (imageSizeIncreaseHold == 1 && imageXYLength < 300){
                int entryCountL = 0;
                int entryCountX = 0;
                imageExpansionMode = 1;
                
                for (int counterY = 0; counterY < imageXYLength+1; counterY++){
                    delete [] imageLabelExport [counterY];
                }
                
                delete [] imageLabelExport;
                
                if (grayColorStatus == 0){
                    imageLabelExport = new int *[imageXYLength*2+1];
                    
                    for (int counterY = 0; counterY < imageXYLength*2+1; counterY++){
                        imageLabelExport [counterY] = new int [imageXYLength*2+1];
                    }
                    
                    imageSizeUpdate = imageXYLength*2+1;
                    
                    for (int counterY = 0; counterY < imageXYLength; counterY++){
                        for (int counterX = 0; counterX < imageXYLength; counterX++){
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                        }
                        
                        entryCountL++;
                        entryCountX = 0;
                        
                        for (int counterX = 0; counterX < imageXYLength; counterX++){
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                        }
                        
                        entryCountL++;
                        entryCountX = 0;
                    }
                }
                else{
                    
                    imageLabelExport = new int *[imageXYLength*2+1];
                    
                    for (int counterY = 0; counterY < imageXYLength*2+1; counterY++){
                        imageLabelExport [counterY] = new int [imageXYLength*2*3+1];
                    }
                    
                    imageSizeUpdate = imageXYLength*2+1;
                    
                    for (int counterY = 0; counterY < imageXYLength; counterY++){
                        for (int counterX = 0; counterX < imageXYLength*3; counterX = counterX+3){
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+1], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+2], entryCountX++;
                            
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+1], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+2], entryCountX++;
                        }
                        
                        entryCountL++;
                        entryCountX = 0;
                        
                        for (int counterX = 0; counterX < imageXYLength*3; counterX = counterX+3){
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+1], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+2], entryCountX++;
                            
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+1], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+2], entryCountX++;
                        }
                        
                        entryCountL++;
                        entryCountX = 0;
                    }
                }
            }
            else if (imageSizeIncreaseHold == 2 && imageXYLength < 200){
                int entryCountL = 0;
                int entryCountX = 0;
                imageExpansionMode = 2;
                
                for (int counterY = 0; counterY < imageXYLength+1; counterY++){
                    delete [] imageLabelExport [counterY];
                }
                
                delete [] imageLabelExport;
                
                if (grayColorStatus == 0){
                    imageLabelExport = new int *[imageXYLength*4+1];
                    
                    for (int counterY = 0; counterY < imageXYLength*4+1; counterY++){
                        imageLabelExport [counterY] = new int [imageXYLength*4+1];
                    }
                    
                    imageSizeUpdate = imageXYLength*4+1;
                    
                    for (int counterY = 0; counterY < imageXYLength; counterY++){
                        for (int counterX = 0; counterX < imageXYLength; counterX++){
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                        }
                        
                        entryCountL++;
                        entryCountX = 0;
                        
                        for (int counterX = 0; counterX < imageXYLength; counterX++){
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                        }
                        
                        entryCountL++;
                        entryCountX = 0;
                        
                        for (int counterX = 0; counterX < imageXYLength; counterX++){
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                        }
                        
                        entryCountL++;
                        entryCountX = 0;
                        
                        for (int counterX = 0; counterX < imageXYLength; counterX++){
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                        }
                        
                        entryCountL++;
                        entryCountX = 0;
                    }
                }
                else{
                    
                    imageLabelExport = new int *[imageXYLength*4+1];
                    
                    for (int counterY = 0; counterY < imageXYLength*4+1; counterY++){
                        imageLabelExport [counterY] = new int [imageXYLength*4*3+1];
                    }
                    
                    imageSizeUpdate = imageXYLength*4+1;
                    
                    for (int counterY = 0; counterY < imageXYLength; counterY++){
                        for (int counterX = 0; counterX < imageXYLength*3; counterX = counterX+3){
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+1], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+2], entryCountX++;
                            
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+1], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+2], entryCountX++;
                            
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+1], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+2], entryCountX++;
                            
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+1], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+2], entryCountX++;
                        }
                        
                        entryCountL++;
                        entryCountX = 0;
                        
                        for (int counterX = 0; counterX < imageXYLength*3; counterX = counterX+3){
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+1], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+2], entryCountX++;
                            
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+1], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+2], entryCountX++;
                            
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+1], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+2], entryCountX++;
                            
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+1], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+2], entryCountX++;
                        }
                        
                        entryCountL++;
                        entryCountX = 0;
                        
                        for (int counterX = 0; counterX < imageXYLength*3; counterX = counterX+3){
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+1], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+2], entryCountX++;
                            
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+1], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+2], entryCountX++;
                            
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+1], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+2], entryCountX++;
                            
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+1], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+2], entryCountX++;
                        }
                        
                        entryCountL++;
                        entryCountX = 0;
                        
                        for (int counterX = 0; counterX < imageXYLength*3; counterX = counterX+3){
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+1], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+2], entryCountX++;
                            
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+1], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+2], entryCountX++;
                            
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+1], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+2], entryCountX++;
                            
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+1], entryCountX++;
                            imageLabelExport [entryCountL][entryCountX] = arrayLabelImage [counterY][counterX+2], entryCountX++;
                        }
                        
                        entryCountL++;
                        entryCountX = 0;
                    }
                }
            }
            else{
                
                if (grayColorStatus == 0){
                    for (int counterY = 0; counterY < imageXYLength; counterY++){
                        for (int counterX = 0; counterX < imageXYLength; counterX++){
                            imageLabelExport [counterY][counterX] = arrayLabelImage [counterY][counterX];
                        }
                    }
                }
                else{
                    
                    for (int counterY = 0; counterY < imageXYLength; counterY++){
                        for (int counterX = 0; counterX < imageXYLength*3; counterX = counterX+3){
                            imageLabelExport [counterY][counterX] = arrayLabelImage [counterY][counterX];
                            imageLabelExport [counterY][counterX+1] = arrayLabelImage [counterY][counterX+1];
                            imageLabelExport [counterY][counterX+2] = arrayLabelImage [counterY][counterX+2];
                        }
                    }
                }
            }
            
            if (setCropStatus == 1){
                if (boxStartImageX < 0) boxStartImageX = 0;
                if (boxStartImageX > imageXYLength) boxStartImageX = imageXYLength;
                if (boxEndImageX < 0) boxEndImageX = 0;
                if (boxEndImageX > imageXYLength) boxEndImageX = imageXYLength;
                if (boxStartImageY < 0) boxStartImageY = 0;
                if (boxStartImageY > imageXYLength) boxStartImageY = imageXYLength;
                if (boxEndImageY < 0) boxEndImageY = 0;
                if (boxEndImageY > imageXYLength) boxEndImageY = imageXYLength;
                
                if (boxStartImageX > boxEndImageX && boxStartImageX-boxEndImageX > 50){
                    xImageStart = (int)boxEndImageX;
                    xImageEnd = (int)boxStartImageX;
                    xImageSizeEX = (int)(boxStartImageX-boxEndImageX);
                }
                else if (boxStartImageX <= boxEndImageX && boxEndImageX-boxStartImageX > 50){
                    xImageStart = (int)boxStartImageX;
                    xImageEnd = (int)boxEndImageX;
                    xImageSizeEX = (int)(boxEndImageX-boxStartImageX);
                }
                
                if (boxStartImageY > boxEndImageY && boxStartImageY-boxEndImageY > 50){
                    yImageStart = (int)(boxEndImageY);
                    yImageEnd = (int)(boxStartImageY);
                    yImageSizeEX = (int)(boxStartImageY-boxEndImageY);
                }
                else if (boxStartImageY <= boxEndImageY && boxEndImageY-boxStartImageY > 50){
                    yImageStart = (int)(boxStartImageY);
                    yImageEnd = (int)(boxEndImageY);
                    yImageSizeEX = (int)(boxEndImageY-boxStartImageY);
                }
            }
            
            if (saveExport == 1){
                if (yImageSizeEX > xImageSizeEX){
                    int sizeDifference = yImageSizeEX-xImageSizeEX;
                    
                    if (xImageSizeEX+sizeDifference < imageXYLength){
                        xImageEnd = xImageEnd+sizeDifference;
                        xImageSizeEX = xImageSizeEX+sizeDifference;
                    }
                    else{
                        
                        yImageEnd = yImageEnd-sizeDifference;
                        yImageSizeEX = yImageSizeEX-sizeDifference;
                    }
                }
            }
            
            if (xImageStart == -1 || yImageStart == -1 || xImageEnd == -1 || yImageEnd == -1){
                xImageStart = 0;
                yImageStart = 0;
                xImageEnd = imageXYLength;
                yImageEnd = imageXYLength;
                xImageSizeEX = imageXYLength;
                yImageSizeEX = imageXYLength;
            }
            
            if (imageExpansionMode == 1){
                xImageStart = xImageStart*2;
                yImageStart = yImageStart*2;
                xImageEnd = xImageEnd*2;
                yImageEnd = yImageEnd*2;
                xImageSizeEX = xImageSizeEX*2;
                yImageSizeEX = yImageSizeEX*2;
            }
            else if (imageExpansionMode == 2){
                xImageStart = xImageStart*4;
                yImageStart = yImageStart*4;
                xImageEnd = xImageEnd*4;
                yImageEnd = yImageEnd*4;
                xImageSizeEX = xImageSizeEX*4;
                yImageSizeEX = yImageSizeEX*4;
            }
            
            NSBitmapImageRep *bitmapReps = nil;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:xImageSizeEX pixelsHigh:yImageSizeEX bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:xImageSizeEX*4 bitsPerPixel:32];
            
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            if (grayColorStatus == 0){
                int readDataTemp = 0;
                
                for (int counterY = yImageStart; counterY < yImageEnd; counterY++){
                    for (int counterX = xImageStart; counterX < xImageEnd; counterX++){
                        readDataTemp = imageLabelExport [counterY][counterX];
                        
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = 0;
                    }
                }
            }
            else if (grayColorStatus == 1){
                int readDataTemp = 0;
                int readDataTemp2 = 0;
                int readDataTemp3 = 0;
                
                for (int counterY = yImageStart; counterY < yImageEnd; counterY++){
                    for (int counterX = xImageStart*3; counterX < xImageEnd*3; counterX = counterX+3){
                        readDataTemp = imageLabelExport [counterY][counterX];
                        readDataTemp2 = imageLabelExport [counterY][counterX+1];
                        readDataTemp3 = imageLabelExport [counterY][counterX+2];
                        
                        *bitmapData++ = (unsigned char)readDataTemp;
                        *bitmapData++ = (unsigned char)readDataTemp2;
                        *bitmapData++ = (unsigned char)readDataTemp3;
                        *bitmapData++ = 0;
                    }
                }
            }
            
            for (int counterY = 0; counterY < imageSizeUpdate; counterY++){
                delete [] imageLabelExport [counterY];
            }
            
            delete [] imageLabelExport;
            
            [NSGraphicsContext saveGraphicsState];
            [NSGraphicsContext setCurrentContext:[NSGraphicsContext graphicsContextWithBitmapImageRep:bitmapReps]];
            
            if (labelX1 != -1 && labelY1 != -1){
                double labelFontSize1 = 0;
                
                if (labelFont1 == 1) labelFontSize1 = 12;
                else if (labelFont1 == 2) labelFontSize1 = 14;
                else if (labelFont1 == 3) labelFontSize1 = 16;
                else if (labelFont1 == 4) labelFontSize1 = 18;
                else if (labelFont1 == 5) labelFontSize1 = 20;
                else if (labelFont1 == 6) labelFontSize1 = 30;
                else if (labelFont1 == 7) labelFontSize1 = 40;
                else if (labelFont1 == 8) labelFontSize1 = 60;
                else if (labelFont1 == 9) labelFontSize1 = 80;
                else if (labelFont1 == 10) labelFontSize1 = 0;
                else if (labelFont1 == 11) labelFontSize1 = 4;
                else if (labelFont1 == 12) labelFontSize1 = 8;
                else if (labelFont1 == 13) labelFontSize1 = 10;
                
                if (labelFontSize1 != 0){
                    NSString *labelFontNSString1 = @(labelPrint1.c_str());
                    
                    [attributesA setObject:[NSFont boldSystemFontOfSize:labelFontSize1] forKey:NSFontAttributeName];
                    
                    if (imageExpansionMode == 0){
                        xPointMarkTemp = labelX1-xImageStart;
                        yPointMarkTemp = (imageXYLength-labelY1)-(imageXYLength-yImageEnd);
                    }
                    else if (imageExpansionMode == 1){
                        xPointMarkTemp = labelX1*2-xImageStart;
                        yPointMarkTemp = (imageXYLength*2-labelY1*2)-(imageXYLength*2-yImageEnd);
                    }
                    else if (imageExpansionMode == 2){
                        xPointMarkTemp = labelX1*4-xImageStart;
                        yPointMarkTemp = (imageXYLength*4-labelY1*4)-(imageXYLength*4-yImageEnd);
                    }
                    
                    if (labelColor1 == 1) [attributesA setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                    else if (labelColor1 == 2)  [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    else if (labelColor1 == 3)  [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                    else if (labelColor1 == 4)  [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                    else if (labelColor1 == 5)  [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                    else if (labelColor1 == 6)  [attributesA setObject:[NSColor brownColor] forKey: NSForegroundColorAttributeName];
                    else if (labelColor1 == 7)  [attributesA setObject:[NSColor cyanColor] forKey: NSForegroundColorAttributeName];
                    else if (labelColor1 == 8)  [attributesA setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
                    else if (labelColor1 == 9)  [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                    else if (labelColor1 == 10)  [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:labelFontNSString1 attributes:attributesA];
                    pointA.x = xPointMarkTemp;
                    pointA.y = yPointMarkTemp;
                    [attrStrA drawAtPoint:pointA];
                }
            }
            
            if (labelX2 != -1 && labelY2 != -1){
                double labelFontSize2 = 0;
                
                if (labelFont2 == 1) labelFontSize2 = 12;
                else if (labelFont2 == 2) labelFontSize2 = 14;
                else if (labelFont2 == 3) labelFontSize2 = 16;
                else if (labelFont2 == 4) labelFontSize2 = 18;
                else if (labelFont2 == 5) labelFontSize2 = 20;
                else if (labelFont2 == 6) labelFontSize2 = 30;
                else if (labelFont2 == 7) labelFontSize2 = 40;
                else if (labelFont2 == 8) labelFontSize2 = 60;
                else if (labelFont2 == 9) labelFontSize2 = 80;
                else if (labelFont2 == 10) labelFontSize2 = 0;
                else if (labelFont2 == 11) labelFontSize2 = 4;
                else if (labelFont2 == 12) labelFontSize2 = 8;
                else if (labelFont2 == 12) labelFontSize2 = 10;
                
                if (labelFontSize2 != 0){
                    NSString *labelFontNSString2 = @(labelPrint2.c_str());
                    
                    [attributesA setObject:[NSFont boldSystemFontOfSize:labelFontSize2] forKey:NSFontAttributeName];
                    
                    if (imageExpansionMode == 0){
                        xPointMarkTemp = labelX2-xImageStart;
                        yPointMarkTemp = (imageXYLength-labelY2)-(imageXYLength-yImageEnd);
                    }
                    else if (imageExpansionMode == 1){
                        xPointMarkTemp = labelX2*2-xImageStart;
                        yPointMarkTemp = (imageXYLength*2-labelY2*2)-(imageXYLength*2-yImageEnd);
                    }
                    else if (imageExpansionMode == 2){
                        xPointMarkTemp = labelX2*4-xImageStart;
                        yPointMarkTemp = (imageXYLength*4-labelY2*4)-(imageXYLength*4-yImageEnd);
                    }
                    
                    if (labelColor2 == 1) [attributesA setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                    else if (labelColor2 == 2)  [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    else if (labelColor2 == 3)  [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                    else if (labelColor2 == 4)  [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                    else if (labelColor2 == 5)  [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                    else if (labelColor2 == 6)  [attributesA setObject:[NSColor brownColor] forKey: NSForegroundColorAttributeName];
                    else if (labelColor2 == 7)  [attributesA setObject:[NSColor cyanColor] forKey: NSForegroundColorAttributeName];
                    else if (labelColor2 == 8)  [attributesA setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
                    else if (labelColor2 == 9)  [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                    else if (labelColor2 == 10)  [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:labelFontNSString2 attributes:attributesA];
                    pointA.x = xPointMarkTemp;
                    pointA.y = yPointMarkTemp;
                    [attrStrA drawAtPoint:pointA];
                }
            }
            
            if (incrementX != -1 && incrementY != -1){
                double incrementFontSize = 0;
                
                if (incrementFont == 1) incrementFontSize = 12;
                else if (incrementFont == 2) incrementFontSize = 14;
                else if (incrementFont == 3) incrementFontSize = 16;
                else if (incrementFont == 4) incrementFontSize = 18;
                else if (incrementFont == 5) incrementFontSize = 20;
                else if (incrementFont == 6) incrementFontSize = 30;
                else if (incrementFont == 7) incrementFontSize = 40;
                else if (incrementFont == 8) incrementFontSize = 60;
                else if (incrementFont == 9) incrementFontSize = 80;
                else if (incrementFont == 10) incrementFontSize = 0;
                else if (incrementFont == 11) incrementFontSize = 4;
                else if (incrementFont == 12) incrementFontSize = 8;
                else if (incrementFont == 13) incrementFontSize = 10;
                
                if (incrementFontSize != 0){
                    string incrementString = to_string(incrementAccumulate);
                    string incrementStringNew = incrementString;
                    
                    if (incrementString.length () >= 4 && incrementString.length () < 7){
                        if (incrementString.length() == 4) incrementStringNew = incrementString.substr(0, 1)+","+incrementString.substr(1);
                        else if (incrementString.length() == 5) incrementStringNew = incrementString.substr(0, 2)+","+incrementString.substr(2);
                        else if (incrementString.length() == 6) incrementStringNew = incrementString.substr(0, 3)+","+incrementString.substr(3);
                    }
                    else if (incrementString.length () >= 7 && incrementString.length () < 10){
                        if (incrementString.length() == 7) incrementStringNew = incrementString.substr(0, 1)+","+incrementString.substr(1, 3)+","+incrementString.substr(4);
                        else if (incrementString.length() == 8) incrementStringNew = incrementString.substr(0, 2)+","+incrementString.substr(2, 3)+","+incrementString.substr(5);
                        else if (incrementString.length() == 9) incrementStringNew = incrementString.substr(0, 3)+","+incrementString.substr(3, 3)+","+incrementString.substr(6);
                    }
                    else if (incrementString.length () >= 10 && incrementString.length () < 13){
                        if (incrementString.length() == 10) incrementStringNew = incrementString.substr(0, 1)+","+incrementString.substr(1, 3)+","+incrementString.substr(4, 3)+","+incrementString.substr(7);
                        else if (incrementString.length() == 11) incrementStringNew = incrementString.substr(0, 2)+","+incrementString.substr(2, 3)+","+incrementString.substr(5, 3)+","+incrementString.substr(8);
                        else if (incrementString.length() == 12) incrementStringNew = incrementString.substr(0, 3)+","+incrementString.substr(3, 3)+","+incrementString.substr(6, 3)+","+incrementString.substr(9);
                    }
                    
                    incrementStringNew = incrementStringNew+" min";
                    
                    NSString *incrementTestFont = @(incrementStringNew.c_str());
                    
                    [attributesA setObject:[NSFont boldSystemFontOfSize:incrementFontSize] forKey:NSFontAttributeName];
                    
                    if (imageExpansionMode == 0){
                        xPointMarkTemp = incrementX-xImageStart;
                        yPointMarkTemp = (imageXYLength-incrementY)-(imageXYLength-yImageEnd);
                    }
                    else if (imageExpansionMode == 1){
                        xPointMarkTemp = incrementX*2-xImageStart;
                        yPointMarkTemp = (imageXYLength*2-incrementY*2)-(imageXYLength*2-yImageEnd);
                    }
                    else if (imageExpansionMode == 2){
                        xPointMarkTemp = incrementX*4-xImageStart;
                        yPointMarkTemp = (imageXYLength*4-incrementY*4)-(imageXYLength*4-yImageEnd);
                    }
                    
                    if (incrementColor == 1) [attributesA setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                    else if (incrementColor == 2)  [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    else if (incrementColor == 3)  [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                    else if (incrementColor == 4)  [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                    else if (incrementColor == 5)  [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                    else if (incrementColor == 6)  [attributesA setObject:[NSColor brownColor] forKey: NSForegroundColorAttributeName];
                    else if (incrementColor == 7)  [attributesA setObject:[NSColor cyanColor] forKey: NSForegroundColorAttributeName];
                    else if (incrementColor == 8)  [attributesA setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
                    else if (incrementColor == 9)  [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                    else if (incrementColor == 10)  [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:incrementTestFont attributes:attributesA];
                    pointA.x = xPointMarkTemp;
                    pointA.y = yPointMarkTemp;
                    [attrStrA drawAtPoint:pointA];
                }
            }
            
            if (scaleBarX != -1 && scaleBarY != -1){
                NSPoint positionAA;
                NSPoint positionBB;
                
                if (imageExpansionMode == 0){
                    xPointMarkTemp = scaleBarX-xImageStart;
                    yPointMarkTemp = (imageXYLength-scaleBarY)-(imageXYLength-yImageEnd);
                    xPointMarkTemp2 = scaleBarX+scaleBarLength-xImageStart;
                }
                else if (imageExpansionMode == 1){
                    xPointMarkTemp = scaleBarX*2-xImageStart;
                    yPointMarkTemp = (imageXYLength*2-scaleBarY*2)-(imageXYLength*2-yImageEnd);
                    xPointMarkTemp2 = scaleBarX*2+scaleBarLength*2-xImageStart;
                }
                else if (imageExpansionMode == 2){
                    xPointMarkTemp = scaleBarX*4-xImageStart;
                    yPointMarkTemp = (imageXYLength*4-scaleBarY*4)-(imageXYLength*4-yImageEnd);
                    xPointMarkTemp2 = scaleBarX*4+scaleBarLength*4-xImageStart;
                }
                
                if (scaleBarWidth == 1) [NSBezierPath setDefaultLineWidth:3];
                else if (scaleBarWidth == 2)  [NSBezierPath setDefaultLineWidth:4];
                else if (scaleBarWidth == 3)  [NSBezierPath setDefaultLineWidth:5];
                else if (scaleBarWidth == 4)  [NSBezierPath setDefaultLineWidth:6];
                else if (scaleBarWidth == 5)  [NSBezierPath setDefaultLineWidth:7];
                else if (scaleBarWidth == 6)  [NSBezierPath setDefaultLineWidth:8];
                else if (scaleBarWidth == 7)  [NSBezierPath setDefaultLineWidth:0.5];
                else if (scaleBarWidth == 8)  [NSBezierPath setDefaultLineWidth:1];
                else if (scaleBarWidth == 9)  [NSBezierPath setDefaultLineWidth:2];
                
                if (scaleBarColor == 1) [[NSColor whiteColor] set];
                else if (scaleBarColor == 2)  [[NSColor blackColor] set];
                else if (scaleBarColor == 3)  [[NSColor yellowColor] set];
                else if (scaleBarColor == 4)  [[NSColor greenColor] set];
                else if (scaleBarColor == 5)  [[NSColor redColor] set];
                else if (scaleBarColor == 6)  [[NSColor brownColor] set];
                else if (scaleBarColor == 7)  [[NSColor cyanColor] set];
                else if (scaleBarColor == 8)  [[NSColor magentaColor] set];
                else if (scaleBarColor == 9)  [[NSColor orangeColor] set];
                else if (scaleBarColor == 10)  [[NSColor blueColor] set];
                
                positionAA.x = xPointMarkTemp;
                positionAA.y = yPointMarkTemp;
                positionBB.x = xPointMarkTemp2;
                positionBB.y = yPointMarkTemp;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            }
            
            [NSGraphicsContext restoreGraphicsState];
            
            NSData *imageExportData;
            imageExportData = [bitmapReps TIFFRepresentation];
            
            [imageExportData writeToFile:@(labelImageSavePath2.c_str()) atomically:YES];
        }
        
        if (exportTiming == 112) exportTiming = 113;
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToLabelSetDisplay object:nil];
}

@end
