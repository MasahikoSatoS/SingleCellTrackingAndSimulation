//
//  DICAdjust.h
//  CellMovie
//
//  Created by Masahiko Sato on 11/22/16.
//
//

#ifndef DICADJUST_H
#define DICADJUST_H
#import "Controller.h"
#endif

@interface DICAdjust : NSView{
    int imageFirstLoadFlagDisplayDIC; //DIC image first load
    
    int magnificationDisplayDIC; //Window control
    int mouseDragFlag; //Window control
    int mouseDownFlag; //Window control
    int xMovePositionHold; //Window control
    int yMovePositionHold; //Window control
    
    double xPointDownDisplayDIC; //Window control
    double yPointDownDisplayDIC; //Window control
    double xPositionMoveDisplayDIC; //Window control
    double yPositionMoveDisplayDIC; //Window control
    double xPointDragDisplayDIC; //Window control
    double yPointDragDisplayDIC; //Window control
    double xPositionDisplayDIC; //Window control
    double yPositionDisplayDIC; //Window control
    double xPositionAdjustDisplayDIC; //Window control
    double yPositionAdjustDisplayDIC; //Window control
    double windowWidthDisplayDIC; //Window control
    double windowHeightDisplayDIC; //Window control
    
    int dragHoldFlag; //Window control
    int dragControl; //Window control
    
    IBOutlet NSImage *dicAdjustImage;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDragged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
