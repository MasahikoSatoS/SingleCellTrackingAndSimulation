//
//  FluorescentController.h
//  CellMovie
//
//  Created by Masahiko Sato on 10/7/16.
//
//

#ifndef FluorescentController_H
#define FluorescentController_H
#import "Controller.h" 
#endif

@interface FluorescentController : NSObject <NSTableViewDataSource>{
    int fileNoBMPCount; //TIF BMP file count
    int fileTypeTifBmp; //TIF BMP type
    
    double sliderFluorescentMax; //Slider
    double sliderFluorescentMin; //Slider
    double sliderFluorescentDiff; //Slider
    double sliderBaseMax; //Slider
    double sliderBaseMin; //Slider
    double sliderBaseDiff; //Slider
    
    IBOutlet NSTextField *moveStatusDiaplay;
    IBOutlet NSTextField *baseCutValueDisplay;
    IBOutlet NSTextField *fluorescentValueDisplay;
    IBOutlet NSTextField *mergeNoDisplay;
    
    IBOutlet NSTableView *tableViewTDList;
    IBOutlet NSWindow *adjustWindow;
    
    IBOutlet NSSlider *sliderFluorescent;
    IBOutlet NSSlider *sliderBase;
    IBOutlet NSSlider *sliderFluorescentCircle;
    IBOutlet NSSlider *sliderBaseCircle;
    
    NSTimer *adjustTimer;
    
    NSWindowController *adjustWindController;
    
    id tiffFileRead;
    id singleTiffSave;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

-(IBAction)closeWindow:(id)sender;
-(IBAction)savePosition:(id)sender;
-(IBAction)imageLoad:(id)sender;
-(IBAction)sliderAction:(id)sender;
-(IBAction)sliderActionBase:(id)sender;
-(IBAction)sliderActionCircle:(id)sender;
-(IBAction)sliderActionBaseCircle:(id)sender;
-(IBAction)clearFluorescent:(id)sender;
-(IBAction)moveStatusSet:(id)sender;
-(IBAction)changeOrder:(id)sender;
-(IBAction)deleteEntry:(id)sender;
-(IBAction)mergeEntry:(id)sender;

@end
