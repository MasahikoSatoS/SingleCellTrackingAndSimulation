//
//  DICAdjust.m
//  CellMovie
//
//  Created by Masahiko Sato on 11/22/16.
//
//

#import "DICAdjust.h"

NSString *notificationToDICAdjust = @"notificationExecuteDICAdjust";

@implementation DICAdjust

- (id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self) {
        dicAdjustImage = [[NSImage alloc] initWithContentsOfFile:@""];
        
        imageFirstLoadFlagDisplayDIC = 0;
        
        magnificationDisplayDIC = 10;
        mouseDragFlag = 0;
        mouseDownFlag = 0;
        dragControl = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToDICAdjust object:nil];
    }
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    if (imageLoadFlagDICPos == 1){
        int dicStitchDimension = 0;
        int counterIncrement = 0;
        
        if (imageSizeDICPos <= 1000){
            dicStitchDimension = imageSizeDICPos;
            counterIncrement = 1;
        }
        else if (imageSizeDICPos <= 4000){
            dicStitchDimension = imageSizeDICPos/2;
            counterIncrement = 2;
        }
        else{
            
            dicStitchDimension = imageSizeDICPos/4;
            counterIncrement = 4;
        }
        
        if (dicImageStatusPos == 1 && referenceImageStatusPos == 0){
            NSBitmapImageRep *bitmapReps = nil;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:dicStitchDimension pixelsHigh:dicStitchDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:dicStitchDimension*4 bitsPerPixel:32];
            
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            int readDataTemp = 0;
            
            for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                    readDataTemp = arrayDICImageForPos [counterY][counterX];
                    
                    if (readDataTemp >= 0 && readDataTemp < baseDICSourceCutPos){
                        readDataTemp = readDataTemp-(int)((baseDICSourceCutPos-readDataTemp)*dicSourceEnhancePos);
                        
                        if (readDataTemp < 0) readDataTemp = 0;
                    }
                    else{
                        
                        readDataTemp = readDataTemp+(int)((readDataTemp-baseDICSourceCutPos)*dicSourceEnhancePos);
                        
                        if (readDataTemp > 255) readDataTemp = 255;
                    }
                    
                    *bitmapData++ = (unsigned char)readDataTemp;
                    *bitmapData++ = (unsigned char)readDataTemp;
                    *bitmapData++ = (unsigned char)readDataTemp;
                    *bitmapData++ = 0;
                }
            }
            
            dicAdjustImage = [[NSImage alloc] initWithSize:NSMakeSize(imageSizeDICPos, imageSizeDICPos)];
            [dicAdjustImage addRepresentation:bitmapReps];
        }
        else if (dicImageStatusPos == 1 && referenceImageStatusPos == 1){
            NSBitmapImageRep *bitmapReps = nil;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:dicStitchDimension pixelsHigh:dicStitchDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:dicStitchDimension*4 bitsPerPixel:32];
            
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            int readDataTemp = 0;
            int readDataTemp2 = 0;
            
            if (fluorescentColorNoPos == 1){
                for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForPos [counterY][counterX];
                        
                        if (counterY-yMovePositionHoldMainDIC >= 0 && counterY-yMovePositionHoldMainDIC < imageSizeDICPos && counterX+xMovePositionHoldMainDIC >= 0 && counterX+xMovePositionHoldMainDIC < imageSizeDICPos){
                            readDataTemp2 = arrayReferenceImagePos [counterY-yMovePositionHoldMainDIC][counterX+xMovePositionHoldMainDIC];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        else readDataTemp2 = 0;
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoPos == 2){
                for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForPos [counterY][counterX];
                        
                        if (counterY-yMovePositionHoldMainDIC >= 0 && counterY-yMovePositionHoldMainDIC < imageSizeDICPos && counterX+xMovePositionHoldMainDIC >= 0 && counterX+xMovePositionHoldMainDIC < imageSizeDICPos){
                            readDataTemp2 = arrayReferenceImagePos [counterY-yMovePositionHoldMainDIC][counterX+xMovePositionHoldMainDIC];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        else readDataTemp2 = 0;
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = 0;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoPos == 3){
                for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForPos [counterY][counterX];
                        
                        if (counterY-yMovePositionHoldMainDIC >= 0 && counterY-yMovePositionHoldMainDIC < imageSizeDICPos && counterX+xMovePositionHoldMainDIC >= 0 && counterX+xMovePositionHoldMainDIC < imageSizeDICPos){
                            readDataTemp2 = arrayReferenceImagePos [counterY-yMovePositionHoldMainDIC][counterX+xMovePositionHoldMainDIC];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        else readDataTemp2 = 0;
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoPos == 4){
                for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForPos [counterY][counterX];
                        
                        if (counterY-yMovePositionHoldMainDIC >= 0 && counterY-yMovePositionHoldMainDIC < imageSizeDICPos && counterX+xMovePositionHoldMainDIC >= 0 && counterX+xMovePositionHoldMainDIC < imageSizeDICPos){
                            readDataTemp2 = arrayReferenceImagePos [counterY-yMovePositionHoldMainDIC][counterX+xMovePositionHoldMainDIC];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        else readDataTemp2 = 0;
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoPos == 5){
                for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForPos [counterY][counterX];
                        
                        if (counterY-yMovePositionHoldMainDIC >= 0 && counterY-yMovePositionHoldMainDIC < imageSizeDICPos && counterX+xMovePositionHoldMainDIC >= 0 && counterX+xMovePositionHoldMainDIC < imageSizeDICPos){
                            readDataTemp2 = arrayReferenceImagePos [counterY-yMovePositionHoldMainDIC][counterX+xMovePositionHoldMainDIC];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        else readDataTemp2 = 0;
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoPos == 6){
                for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForPos [counterY][counterX];
                        
                        if (counterY-yMovePositionHoldMainDIC >= 0 && counterY-yMovePositionHoldMainDIC < imageSizeDICPos && counterX+xMovePositionHoldMainDIC >= 0 && counterX+xMovePositionHoldMainDIC < imageSizeDICPos){
                            readDataTemp2 = arrayReferenceImagePos [counterY-yMovePositionHoldMainDIC][counterX+xMovePositionHoldMainDIC];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        else readDataTemp2 = 0;
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = 0;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoPos == 7){
                for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForPos [counterY][counterX];
                        
                        if (counterY-yMovePositionHoldMainDIC >= 0 && counterY-yMovePositionHoldMainDIC < imageSizeDICPos && counterX+xMovePositionHoldMainDIC >= 0 && counterX+xMovePositionHoldMainDIC < imageSizeDICPos){
                            readDataTemp2 = arrayReferenceImagePos [counterY-yMovePositionHoldMainDIC][counterX+xMovePositionHoldMainDIC];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        else readDataTemp2 = 0;
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.674));
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoPos == 8){
                for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForPos [counterY][counterX];
                        
                        if (counterY-yMovePositionHoldMainDIC >= 0 && counterY-yMovePositionHoldMainDIC < imageSizeDICPos && counterX+xMovePositionHoldMainDIC >= 0 && counterX+xMovePositionHoldMainDIC < imageSizeDICPos){
                            readDataTemp2 = arrayReferenceImagePos [counterY-yMovePositionHoldMainDIC][counterX+xMovePositionHoldMainDIC];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        else readDataTemp2 = 0;
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.627));
                            *bitmapData++ = (unsigned char)(unsigned char)((int)(readDataTemp2*(double)0.125));
                            *bitmapData++ = (unsigned char)(unsigned char)((int)(readDataTemp2*(double)0.941));
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoPos == 9){
                for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForPos [counterY][counterX];
                        
                        if (counterY-yMovePositionHoldMainDIC >= 0 && counterY-yMovePositionHoldMainDIC < imageSizeDICPos && counterX+xMovePositionHoldMainDIC >= 0 && counterX+xMovePositionHoldMainDIC < imageSizeDICPos){
                            readDataTemp2 = arrayReferenceImagePos [counterY-yMovePositionHoldMainDIC][counterX+xMovePositionHoldMainDIC];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        else readDataTemp2 = 0;
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.529));
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.808));
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.922));
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            
            dicAdjustImage = [[NSImage alloc] initWithSize:NSMakeSize(imageSizeDICPos, imageSizeDICPos)];
            [dicAdjustImage addRepresentation:bitmapReps];
        }
        
        if (imageFirstLoadFlagDisplayDIC == 0){
            xPositionDisplayDIC = 0;
            yPositionDisplayDIC = 0;
            xPositionAdjustDisplayDIC = 0;
            yPositionAdjustDisplayDIC = 0;
            magnificationDisplayDIC = 10;
            imageFirstLoadFlagDisplayDIC = 1;
        }
        
        //----Window size and Position re-adjust----
        int vertical = 500+78;
        int horizontal = 500;
        
        windowWidthDisplayDIC = imageSizeDICPos/(double)horizontal;
        windowHeightDisplayDIC = imageSizeDICPos/(double)(vertical-78);
        
        xPositionAdjustDisplayDIC = (imageSizeDICPos-imageSizeDICPos/(double)(magnificationDisplayDIC*0.1))/(double)2;
        yPositionAdjustDisplayDIC = (imageSizeDICPos-imageSizeDICPos/(double)(magnificationDisplayDIC*0.1))/(double)2;
    }
    
    [self setNeedsDisplay:YES];
}

-(void)mouseDown:(NSEvent *)event{
    if (imageLoadFlagDICPos == 1){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDownDisplayDIC = clickPoint.x;
        yPointDownDisplayDIC = clickPoint.y;
        
        xMovePositionHold = 0;
        yMovePositionHold = 0;
        dragHoldFlag = 0;
    }
}

-(void)mouseUp:(NSEvent *)event{
    if (imageLoadFlagDICPos == 1){
        xPositionDisplayDIC = xPositionDisplayDIC+xPositionMoveDisplayDIC;
        yPositionDisplayDIC = yPositionDisplayDIC+yPositionMoveDisplayDIC;
        
        xPositionMoveDisplayDIC = 0;
        yPositionMoveDisplayDIC = 0;
        mouseDragFlag = 0;
        mouseDownFlag = 0;
        
        if (dragHoldFlag == 1){
            xMovePositionHoldMainDIC = xMovePositionHold;
            yMovePositionHoldMainDIC = yMovePositionHold;
        }
        
        [self setNeedsDisplay:YES];
    }
}

-(void)mouseDragged:(NSEvent *)event{
    if (imageLoadFlagDICPos == 1){
        NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDragDisplayDIC = clickPoint.x;
        yPointDragDisplayDIC = clickPoint.y;
        
        if (imageMoveStatusPos == 0){
            xPositionMoveDisplayDIC = (xPointDownDisplayDIC-xPointDragDisplayDIC)*windowWidthDisplayDIC/(double)(magnificationDisplayDIC*0.1);
            yPositionMoveDisplayDIC = (yPointDownDisplayDIC-yPointDragDisplayDIC)*windowHeightDisplayDIC/(double)(magnificationDisplayDIC*0.1);
        }
        else if (imageMoveStatusPos == 1 && dragControl == 0){
            dragControl = 1;
            dragHoldFlag = 1;
            
            int xMovePosition = xMovePositionHoldMainDIC+(int)((xPointDownDisplayDIC-xPointDragDisplayDIC)*windowWidthDisplayDIC/(double)(magnificationDisplayDIC*0.1));
            int yMovePosition = yMovePositionHoldMainDIC+(int)((yPointDownDisplayDIC-yPointDragDisplayDIC)*windowHeightDisplayDIC/(double)(magnificationDisplayDIC*0.1));
            
            xMovePositionHold = xMovePosition;
            yMovePositionHold = yMovePosition;
            
            int dicStitchDimension = 0;
            int counterIncrement = 0;
            
            if (imageSizeDICPos <= 1000){
                dicStitchDimension = imageSizeDICPos;
                counterIncrement = 1;
            }
            else if (imageSizeDICPos <= 4000){
                dicStitchDimension = imageSizeDICPos/2;
                counterIncrement = 2;
            }
            else{
                
                dicStitchDimension = imageSizeDICPos/4;
                counterIncrement = 4;
            }
            
            NSBitmapImageRep *bitmapReps = nil;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:dicStitchDimension pixelsHigh:dicStitchDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:dicStitchDimension*4 bitsPerPixel:32];
            
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            int readDataTemp = 0;
            int readDataTemp2 = 0;
            
            if (fluorescentColorNoPos == 1){
                for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForPos [counterY][counterX];
                        readDataTemp2 = -1;
                        
                        if (counterY-yMovePosition >= 0 && counterY-yMovePosition < imageSizeDICPos && counterX+xMovePosition >= 0 && counterX+xMovePosition < imageSizeDICPos){
                            readDataTemp2 = arrayReferenceImagePos [counterY-yMovePosition][counterX+xMovePosition];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoPos == 2){
                for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForPos [counterY][counterX];
                        readDataTemp2 = -1;
                        
                        if (counterY-yMovePosition >= 0 && counterY-yMovePosition < imageSizeDICPos && counterX+xMovePosition >= 0 && counterX+xMovePosition < imageSizeDICPos){
                            readDataTemp2 = arrayReferenceImagePos [counterY-yMovePosition][counterX+xMovePosition];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = 0;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoPos == 3){
                for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForPos [counterY][counterX];
                        readDataTemp2 = -1;
                        
                        if (counterY-yMovePosition >= 0 && counterY-yMovePosition < imageSizeDICPos && counterX+xMovePosition >= 0 && counterX+xMovePosition < imageSizeDICPos){
                            readDataTemp2 = arrayReferenceImagePos [counterY-yMovePosition][counterX+xMovePosition];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoPos == 4){
                for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForPos [counterY][counterX];
                        readDataTemp2 = -1;
                        
                        if (counterY-yMovePosition >= 0 && counterY-yMovePosition < imageSizeDICPos && counterX+xMovePosition >= 0 && counterX+xMovePosition < imageSizeDICPos){
                            readDataTemp2 = arrayReferenceImagePos [counterY-yMovePosition][counterX+xMovePosition];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoPos == 5){
                for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForPos [counterY][counterX];
                        readDataTemp2 = -1;
                        
                        if (counterY-yMovePosition >= 0 && counterY-yMovePosition < imageSizeDICPos && counterX+xMovePosition >= 0 && counterX+xMovePosition < imageSizeDICPos){
                            readDataTemp2 = arrayReferenceImagePos [counterY-yMovePosition][counterX+xMovePosition];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoPos == 6){
                for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForPos [counterY][counterX];
                        readDataTemp2 = -1;
                        
                        if (counterY-yMovePosition >= 0 && counterY-yMovePosition < imageSizeDICPos && counterX+xMovePosition >= 0 && counterX+xMovePosition < imageSizeDICPos){
                            readDataTemp2 = arrayReferenceImagePos [counterY-yMovePosition][counterX+xMovePosition];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = 0;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoPos == 7){
                for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForPos [counterY][counterX];
                        readDataTemp2 = -1;
                        
                        if (counterY-yMovePosition >= 0 && counterY-yMovePosition < imageSizeDICPos && counterX+xMovePosition >= 0 && counterX+xMovePosition < imageSizeDICPos){
                            readDataTemp2 = arrayReferenceImagePos [counterY-yMovePosition][counterX+xMovePosition];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.674));
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoPos == 8){
                for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForPos [counterY][counterX];
                        readDataTemp2 = -1;
                        
                        if (counterY-yMovePosition >= 0 && counterY-yMovePosition < imageSizeDICPos && counterX+xMovePosition >= 0 && counterX+xMovePosition < imageSizeDICPos){
                            readDataTemp2 = arrayReferenceImagePos [counterY-yMovePosition][counterX+xMovePosition];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.627));
                            *bitmapData++ = (unsigned char)(unsigned char)((int)(readDataTemp2*(double)0.125));
                            *bitmapData++ = (unsigned char)(unsigned char)((int)(readDataTemp2*(double)0.941));
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoPos == 9){
                for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForPos [counterY][counterX];
                        readDataTemp2 = -1;
                        
                        if (counterY-yMovePosition >= 0 && counterY-yMovePosition < imageSizeDICPos && counterX+xMovePosition >= 0 && counterX+xMovePosition < imageSizeDICPos){
                            readDataTemp2 = arrayReferenceImagePos [counterY-yMovePosition][counterX+xMovePosition];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.529));
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.808));
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.922));
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            
            dicAdjustImage = [[NSImage alloc] initWithSize:NSMakeSize(imageSizeDICPos, imageSizeDICPos)];
            [dicAdjustImage addRepresentation:bitmapReps];
        }
        
        mouseDragFlag = 1;
        
        [self setNeedsDisplay:YES];
    }
}

-(void)keyDown:(NSEvent *)event{
    int keyCode = [event keyCode];
    
    if (imageLoadFlagDICPos == 1){
        //----Magnification Magnify----
        if (keyCode == 125){
            if (magnificationDisplayDIC >= 10 && magnificationDisplayDIC <= 490){
                if (magnificationDisplayDIC-10 < 10) magnificationDisplayDIC = 10;
                else magnificationDisplayDIC = magnificationDisplayDIC-10;
                
                xPositionAdjustDisplayDIC = -1*(imageSizeDICPos/(double)(magnificationDisplayDIC*0.1)-imageSizeDICPos)/(double)2;
                yPositionAdjustDisplayDIC = -1*(imageSizeDICPos/(double)(magnificationDisplayDIC*0.1)-imageSizeDICPos)/(double)2;
            }
            else if (magnificationDisplayDIC < 10) magnificationDisplayDIC = 10;
        }
        
        //----Magnification Reduction----
        if (keyCode == 126){
            if (magnificationDisplayDIC >= 10 && magnificationDisplayDIC <= 490){
                if (magnificationDisplayDIC+10 > 490) magnificationDisplayDIC = 490;
                else magnificationDisplayDIC = magnificationDisplayDIC+10;
                
                xPositionAdjustDisplayDIC = (imageSizeDICPos-imageSizeDICPos/(double)(magnificationDisplayDIC*0.1))/(double)2;
                yPositionAdjustDisplayDIC = (imageSizeDICPos-imageSizeDICPos/(double)(magnificationDisplayDIC*0.1))/(double)2;
            }
            else if (magnificationDisplayDIC > 490) magnificationDisplayDIC = 490;
        }
        
        if (keyCode == 6){
            xPositionDisplayDIC = 0;
            yPositionDisplayDIC = 0;
            xPositionAdjustDisplayDIC = 0;
            yPositionAdjustDisplayDIC = 0;
            magnificationDisplayDIC = 10;
            
            xPositionAdjustDisplayDIC = (imageSizeDICPos-imageSizeDICPos/(double)(magnificationDisplayDIC*0.1))/(double)2;
            yPositionAdjustDisplayDIC = (imageSizeDICPos-imageSizeDICPos/(double)(magnificationDisplayDIC*0.1))/(double)2;
            
            xMovePositionHoldMainDIC = 0;
            yMovePositionHoldMainDIC = 0;
            
            if (dicImageStatusPos == 1 && referenceImageStatusPos == 1){
                int dicStitchDimension = 0;
                int counterIncrement = 0;
                
                if (imageSizeDICPos <= 1000){
                    dicStitchDimension = imageSizeDICPos;
                    counterIncrement = 1;
                }
                else if (imageSizeDICPos <= 4000){
                    dicStitchDimension = imageSizeDICPos/2;
                    counterIncrement = 2;
                }
                else{
                    
                    dicStitchDimension = imageSizeDICPos/4;
                    counterIncrement = 4;
                }
                
                NSBitmapImageRep *bitmapReps = nil;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:dicStitchDimension pixelsHigh:dicStitchDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:dicStitchDimension*4 bitsPerPixel:32];
                
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                int readDataTemp = 0;
                int readDataTemp2 = 0;
                
                if (fluorescentColorNoPos == 1){
                    for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                        for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                            readDataTemp = arrayDICImageForPos [counterY][counterX];
                            readDataTemp2 = -1;
                            
                            if (counterY-yMovePositionHoldMainDIC >= 0 && counterY-yMovePositionHoldMainDIC < imageSizeDICPos && counterX+xMovePositionHoldMainDIC >= 0 && counterX+xMovePositionHoldMainDIC < imageSizeDICPos){
                                readDataTemp2 = arrayReferenceImagePos [counterY-yMovePositionHoldMainDIC][counterX+xMovePositionHoldMainDIC];
                                
                                if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                                else{
                                    
                                    readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                    
                                    if (readDataTemp2 > 255) readDataTemp2 = 255;
                                }
                            }
                            
                            if (readDataTemp2 <= 0){
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                *bitmapData++ = 0;
                                *bitmapData++ = 0;
                                *bitmapData++ = (unsigned char)readDataTemp2;
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
                else if (fluorescentColorNoPos == 2){
                    for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                        for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                            readDataTemp = arrayDICImageForPos [counterY][counterX];
                            readDataTemp2 = -1;
                            
                            if (counterY-yMovePositionHoldMainDIC >= 0 && counterY-yMovePositionHoldMainDIC < imageSizeDICPos && counterX+xMovePositionHoldMainDIC >= 0 && counterX+xMovePositionHoldMainDIC < imageSizeDICPos){
                                readDataTemp2 = arrayReferenceImagePos [counterY-yMovePositionHoldMainDIC][counterX+xMovePositionHoldMainDIC];
                                
                                if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                                else{
                                    
                                    readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                    
                                    if (readDataTemp2 > 255) readDataTemp2 = 255;
                                }
                            }
                            
                            if (readDataTemp2 <= 0){
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                *bitmapData++ = 0;
                                *bitmapData++ = (unsigned char)readDataTemp2;
                                *bitmapData++ = 0;
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
                else if (fluorescentColorNoPos == 3){
                    for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                        for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                            readDataTemp = arrayDICImageForPos [counterY][counterX];
                            readDataTemp2 = -1;
                            
                            if (counterY-yMovePositionHoldMainDIC >= 0 && counterY-yMovePositionHoldMainDIC < imageSizeDICPos && counterX+xMovePositionHoldMainDIC >= 0 && counterX+xMovePositionHoldMainDIC < imageSizeDICPos){
                                readDataTemp2 = arrayReferenceImagePos [counterY-yMovePositionHoldMainDIC][counterX+xMovePositionHoldMainDIC];
                                
                                if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                                else{
                                    
                                    readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                    
                                    if (readDataTemp2 > 255) readDataTemp2 = 255;
                                }
                            }
                            
                            if (readDataTemp2 <= 0){
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                *bitmapData++ = (unsigned char)readDataTemp2;
                                *bitmapData++ = (unsigned char)readDataTemp2;
                                *bitmapData++ = 0;
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
                else if (fluorescentColorNoPos == 4){
                    for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                        for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                            readDataTemp = arrayDICImageForPos [counterY][counterX];
                            readDataTemp2 = -1;
                            
                            if (counterY-yMovePositionHoldMainDIC >= 0 && counterY-yMovePositionHoldMainDIC < imageSizeDICPos && counterX+xMovePositionHoldMainDIC >= 0 && counterX+xMovePositionHoldMainDIC < imageSizeDICPos){
                                readDataTemp2 = arrayReferenceImagePos [counterY-yMovePositionHoldMainDIC][counterX+xMovePositionHoldMainDIC];
                                
                                if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                                else{
                                    
                                    readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                    
                                    if (readDataTemp2 > 255) readDataTemp2 = 255;
                                }
                            }
                            
                            if (readDataTemp2 <= 0){
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                *bitmapData++ = (unsigned char)readDataTemp2;
                                *bitmapData++ = 0;
                                *bitmapData++ = 0;
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
                else if (fluorescentColorNoPos == 5){
                    for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                        for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                            readDataTemp = arrayDICImageForPos [counterY][counterX];
                            readDataTemp2 = -1;
                            
                            if (counterY-yMovePositionHoldMainDIC >= 0 && counterY-yMovePositionHoldMainDIC < imageSizeDICPos && counterX+xMovePositionHoldMainDIC >= 0 && counterX+xMovePositionHoldMainDIC < imageSizeDICPos){
                                readDataTemp2 = arrayReferenceImagePos [counterY-yMovePositionHoldMainDIC][counterX+xMovePositionHoldMainDIC];
                                
                                if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                                else{
                                    
                                    readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                    
                                    if (readDataTemp2 > 255) readDataTemp2 = 255;
                                }
                            }
                            
                            if (readDataTemp2 <= 0){
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                *bitmapData++ = (unsigned char)readDataTemp2;
                                *bitmapData++ = 0;
                                *bitmapData++ = (unsigned char)readDataTemp2;
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
                else if (fluorescentColorNoPos == 6){
                    for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                        for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                            readDataTemp = arrayDICImageForPos [counterY][counterX];
                            readDataTemp2 = -1;
                            
                            if (counterY-yMovePositionHoldMainDIC >= 0 && counterY-yMovePositionHoldMainDIC < imageSizeDICPos && counterX+xMovePositionHoldMainDIC >= 0 && counterX+xMovePositionHoldMainDIC < imageSizeDICPos){
                                readDataTemp2 = arrayReferenceImagePos [counterY-yMovePositionHoldMainDIC][counterX+xMovePositionHoldMainDIC];
                                
                                if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                                else{
                                    
                                    readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                    
                                    if (readDataTemp2 > 255) readDataTemp2 = 255;
                                }
                            }
                            
                            if (readDataTemp2 <= 0){
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                *bitmapData++ = 0;
                                *bitmapData++ = (unsigned char)readDataTemp2;
                                *bitmapData++ = (unsigned char)readDataTemp2;
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
                else if (fluorescentColorNoPos == 7){
                    for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                        for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                            readDataTemp = arrayDICImageForPos [counterY][counterX];
                            readDataTemp2 = -1;
                            
                            if (counterY-yMovePositionHoldMainDIC >= 0 && counterY-yMovePositionHoldMainDIC < imageSizeDICPos && counterX+xMovePositionHoldMainDIC >= 0 && counterX+xMovePositionHoldMainDIC < imageSizeDICPos){
                                readDataTemp2 = arrayReferenceImagePos [counterY-yMovePositionHoldMainDIC][counterX+xMovePositionHoldMainDIC];
                                
                                if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                                else{
                                    
                                    readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                    
                                    if (readDataTemp2 > 255) readDataTemp2 = 255;
                                }
                            }
                            
                            if (readDataTemp2 <= 0){
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                *bitmapData++ = (unsigned char)readDataTemp2;
                                *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.674));
                                *bitmapData++ = 0;
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
                else if (fluorescentColorNoPos == 8){
                    for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                        for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                            readDataTemp = arrayDICImageForPos [counterY][counterX];
                            readDataTemp2 = -1;
                            
                            if (counterY-yMovePositionHoldMainDIC >= 0 && counterY-yMovePositionHoldMainDIC < imageSizeDICPos && counterX+xMovePositionHoldMainDIC >= 0 && counterX+xMovePositionHoldMainDIC < imageSizeDICPos){
                                readDataTemp2 = arrayReferenceImagePos [counterY-yMovePositionHoldMainDIC][counterX+xMovePositionHoldMainDIC];
                                
                                if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                                else{
                                    
                                    readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                    
                                    if (readDataTemp2 > 255) readDataTemp2 = 255;
                                }
                            }
                            
                            if (readDataTemp2 <= 0){
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.627));
                                *bitmapData++ = (unsigned char)(unsigned char)((int)(readDataTemp2*(double)0.125));
                                *bitmapData++ = (unsigned char)(unsigned char)((int)(readDataTemp2*(double)0.941));
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
                else if (fluorescentColorNoPos == 9){
                    for (int counterY = 0; counterY < imageSizeDICPos; counterY = counterY+counterIncrement){
                        for (int counterX = 0; counterX < imageSizeDICPos; counterX = counterX+counterIncrement){
                            readDataTemp = arrayDICImageForPos [counterY][counterX];
                            readDataTemp2 = -1;
                            
                            if (counterY-yMovePositionHoldMainDIC >= 0 && counterY-yMovePositionHoldMainDIC < imageSizeDICPos && counterX+xMovePositionHoldMainDIC >= 0 && counterX+xMovePositionHoldMainDIC < imageSizeDICPos){
                                readDataTemp2 = arrayReferenceImagePos [counterY-yMovePositionHoldMainDIC][counterX+xMovePositionHoldMainDIC];
                                
                                if (readDataTemp2 >= 0 && readDataTemp2 < baseDICCutDICPos) readDataTemp2 = 0;
                                else{
                                    
                                    readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseDICCutDICPos)*dicEnhancePos);
                                    
                                    if (readDataTemp2 > 255) readDataTemp2 = 255;
                                }
                            }
                            
                            if (readDataTemp2 <= 0){
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.529));
                                *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.808));
                                *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.922));
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
                
                dicAdjustImage = [[NSImage alloc] initWithSize:NSMakeSize(imageSizeDICPos, imageSizeDICPos)];
                [dicAdjustImage addRepresentation:bitmapReps];
            }
        }
        
        [self setNeedsDisplay:YES];
    }
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect{
    NSRect srcRect;
    srcRect.origin.x = xPositionDisplayDIC+xPositionAdjustDisplayDIC+xPositionMoveDisplayDIC;
    srcRect.origin.y = yPositionDisplayDIC+yPositionAdjustDisplayDIC+yPositionMoveDisplayDIC;
    srcRect.size.width = imageSizeDICPos/(double)(magnificationDisplayDIC*0.1);
    srcRect.size.height = imageSizeDICPos/(double)(magnificationDisplayDIC*0.1);
    
    [dicAdjustImage drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
    
    dragControl = 0;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToDICAdjust object:nil];
}

@end
