//
//  FluorescentAdjust.h
//  CellMovie
//
//  Created by Masahiko Sato on 10/7/16.
//
//

#ifndef FluorescentAdjust_H
#define FluorescentAdjust_H
#import "Controller.h"
#endif

@interface FluorescentAdjust : NSView{
    int mouseDragFlag; //Window control
    int mouseDownFlag; //Window control
    int xMovePositionHold; //Window control
    int yMovePositionHold; //Window control
    
    double xPointDownDisplayFluorescent; //Window control
    double yPointDownDisplayFluorescent; //Window control
    double xPositionMoveDisplayFluorescent; //Window control
    double yPositionMoveDisplayFluorescent; //Window control
    double xPointDragDisplayFluorescent; //Window control
    double yPointDragDisplayFluorescent; //Window control
    double xPositionDisplayFluorescent; //Window control
    double yPositionDisplayFluorescent; //Window control
    double xPositionAdjustDisplayFluorescent; //Window control
    double yPositionAdjustDisplayFluorescent; //Window control
    double windowWidthDisplayFluorescent; //Window control
    double windowHeightDisplayFluorescent; //Window control
    
    int dragHoldFlag; //Window control
    int dragControl; //Window control
    
    IBOutlet NSImage *adjustImage;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDragged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
