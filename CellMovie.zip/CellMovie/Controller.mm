//
//  Controller.m
//  CellMovie
//
//  Created by Masahiko Sato on 2014-09-29.
//
//

#import "Controller.h"

//----Basic info----
string pathNameString;
string analysisNameHold;
string treatNameHold;
string imageDataPath;
string imageDisplayPath;

//-----Arrays-----
string *fileList;
int fileListCount;
int fileListStatus;
uint8_t *fileReadArray;

//----Basic operation----
int maxImageNo;
int timePointHold;
int movieRunningFlag;
int filePosition;
int timePointDisplayCall;
int movieTiming;
int imageXYLength;
int imageBmpTifFlag;
int grayColorStatus;

uint8_t *uploadTemp;
int uploadTempStatus;
uint8_t *uploadTempCl1;
int uploadTempStatusCl1;
uint8_t *uploadTempCl2;
int uploadTempStatusCl2;
uint8_t *uploadTempCl3;
int uploadTempStatusCl3;
uint8_t *uploadTempCl4;
int uploadTempStatusCl4;
uint8_t *uploadTempCl5;
int uploadTempStatusCl5;
uint8_t *uploadTempCl6;
int uploadTempStatusCl6;
long uploadTempFileSize; 
int colorFlag1;
int colorFlag2;
int colorFlag3;
int colorFlag4;
int colorFlag5;
int colorFlag6;
string colorNo1;
string colorNo2;
string colorNo3;
string colorNo4;
string colorNo5;
string colorNo6;
string colorName1;
string colorName2;
string colorName3;
string colorName4;
string colorName5;
string colorName6;
double levelHold1;
double levelHold2;
double levelHold3;
double levelHold4;
double levelHold5;
double levelHold6;
double levelHoldDIC;
double levelHoldR;
double levelHoldG;
double levelHoldB;
double cutHold1;
double cutHold2;
double cutHold3;
double cutHold4;
double cutHold5;
double cutHold6;
double cutHoldDIC;
int statusHold1;
int statusHold2;
int statusHold3;
int statusHold4;
int statusHold5;
int statusHold6;
int statusHoldDIC;
int lastDICImageTime;
int lastTIFRoundNo;
int colorInfoDisplayCall;

//========Fluorescent Image Overlay========
int positionAdjustOperationFluorescent;
int imageMoveStatusFluorescent;
int imageFirstLoadFlagDisplayFluorescent;
int magnificationDisplayFluorescent;
int xMovePositionHoldMain;
int yMovePositionHoldMain;
int baseCutFluorescent;
double fluorescentEnhanceFluorescent;
int **arrayDICImageForFluorescent;
int dicImageStatusFluorescent;
int **arrayReferenceImageFluorescent;
int referenceImageStatusFluorescent;
int imageSizeFluorescent;
int imageLoadFlagFluorescent;
int fluorescentColorNoFluorescent;
int tableCallFluorescentCount;
int tableCurrentFluRowHold;
int rowIndexFluorescentHold;
string selectedFile;
string fileSavePathHold;
int **arrayImageFileSave;
string ascIIstring;

//=======Image Position adjust=======
int positionDICAdjustOperation;
int baseDICCutDICPos;
double dicEnhancePos;
int imageLoadFlagDICPos;
int baseDICSourceCutPos;
double dicSourceEnhancePos;
int imageSizeDICPos;
int xMovePositionHoldMainDIC;
int yMovePositionHoldMainDIC;
string holdCopyFolderName;
string holdDeleteFolderName;
string liveFluorescentName1;
string liveFluorescentName2;
string liveFluorescentName3;
string liveFluorescentName4;
string liveFluorescentName5;
string liveFluorescentName6;
int copyProgressFlag;
int **arrayDICImageForPos;
int dicImageStatusPos;
int **arrayReferenceImagePos;
int referenceImageStatusPos;
int fluorescentColorNoPos;
int imageMoveStatusPos;

//=======Label Set=======
int labelSetOperation;
int labelX1;
int labelY1;
string labelPrint1;
int labelFont1;
int labelColor1;
int labelX2;
int labelY2;
string labelPrint2;
int labelFont2;
int labelColor2;
int incrementX;
int incrementY;
int incrementValue;
int incrementStart;
int incrementFont;
int incrementColor;
int scaleBarX;
int scaleBarY;
int scaleBarLength;
int scaleBarWidth;
int scaleBarColor;
int setCropStatus;
int currentActiveHold;
int imageLoadingFlag;
int **arrayLabelImage;
int labelImageStatus;
string labelImageSavePath;
string labelImageSavePath2;
int imageLoadFlagLabel;
int xPositionExHold;
int yPositionExHold;
int xyPositionLabelCall1;
int xyPositionLabelCall2;
int exportFlag;
int exportTiming;
int incrementAccumulate;
int nextLoadImageCount;
int labeledSaveImageCount; 
int fluorescentLevelCount;
int printStop;
int imageSizeLabelHold;
int saveExport;
int imageSizeIncreaseHold;

@implementation Controller

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSString *currentDirectoryPathNSString = [[NSBundle mainBundle] bundlePath];
        string userPathNameString = [currentDirectoryPathNSString cStringUsingEncoding:NSUTF8StringEncoding];
        
        if (userPathNameString.length() == 0) exit (0);
        else if ((int)userPathNameString.find("/Users/") == -1) exit (0);
        else{
            
            string pathName2 = userPathNameString.substr((unsigned long)userPathNameString.find("/Users/")+7);
            pathNameString = pathName2.substr(0, (unsigned long)pathName2.find("/"));
        }
        
        analysisNameHold = "";
        treatNameHold = "";
        
        fileListStatus = 0;
        
        maxImageNo = 0;
        timePointHold = 0;
        movieRunningFlag = 0;
        timePointDisplayCall = 0;
        movieTiming = 0;
        imageXYLength = 0;
        imageBmpTifFlag = 0;
        grayColorStatus = 0;
        
        uploadTempStatus = 0;
        uploadTempStatusCl1 = 0;
        uploadTempStatusCl2 = 0;
        uploadTempStatusCl3 = 0;
        uploadTempStatusCl4 = 0;
        uploadTempStatusCl5 = 0;
        uploadTempStatusCl6 = 0;
        colorFlag1 = 0;
        colorFlag2 = 0;
        colorFlag3 = 0;
        colorFlag4 = 0;
        colorFlag5 = 0;
        colorFlag6 = 0;
        levelHold1 = 1;
        levelHold2 = 1;
        levelHold3 = 1;
        levelHold4 = 1;
        levelHold5 = 1;
        levelHold6 = 1;
        levelHoldDIC = 0;
        levelHoldR = 1;
        levelHoldG = 1;
        levelHoldB = 1;
        cutHold1 = 50;
        cutHold2 = 50;
        cutHold3 = 50;
        cutHold4 = 50;
        cutHold5 = 50;
        cutHold6 = 50;
        cutHoldDIC = 0;
        statusHold1 = 0;
        statusHold2 = 0;
        statusHold3 = 0;
        statusHold4 = 0;
        statusHold5 = 0;
        statusHold6 = 0;
        statusHoldDIC = 0;
        colorInfoDisplayCall = 0;
        
        //======Fluorescent Image Overlay=====
        positionAdjustOperationFluorescent = 0;
        imageMoveStatusFluorescent = 0;
        imageFirstLoadFlagDisplayFluorescent = 0;
        magnificationDisplayFluorescent = 10;
        baseCutFluorescent = 50;
        fluorescentEnhanceFluorescent = 1;
        dicImageStatusFluorescent = 0;
        referenceImageStatusFluorescent = 0;
        imageLoadFlagFluorescent = 0;
        tableCallFluorescentCount = 0;
        tableCurrentFluRowHold = 0;
        rowIndexFluorescentHold = 0;
        
        //=======Image Position adjust=======
        positionDICAdjustOperation = 0;
        baseDICCutDICPos = 50;
        dicEnhancePos = 1;
        baseDICSourceCutPos = 0;
        dicSourceEnhancePos = 0.01;
        imageLoadFlagDICPos = 0;
        holdCopyFolderName = "";
        holdDeleteFolderName = "";
        copyProgressFlag = 0;
        dicImageStatusPos = 0;
        referenceImageStatusPos = 0;
        imageMoveStatusPos = 0;
        
        //=======Label Set=======
        labelSetOperation = 0;
        labelX1 = -1;
        labelY1 = -1;
        labelPrint1 = "";
        labelFont1 = 1;
        labelColor1 = 1;
        labelX2 = -1;
        labelY2 = -1;
        labelPrint2 = "";
        labelFont2 = 1;
        labelColor2 = 1;
        incrementX = -1;
        incrementY = -1;
        incrementValue = 0;
        incrementFont = 1;
        incrementColor = 1;
        scaleBarX = -1;
        scaleBarY = -1;
        scaleBarLength = 0;
        scaleBarWidth = 1;
        scaleBarColor = 1;
        setCropStatus = 0;
        currentActiveHold = 0;
        imageLoadingFlag = 0;
        labelImageStatus = 0;
        imageLoadFlagLabel = 0;
        xyPositionLabelCall1 = 0;
        xyPositionLabelCall2 = 0;
        exportFlag = 0;
        exportTiming = 0;
        printStop = 0;
        saveExport = 0;
        imageSizeIncreaseHold = 0;
        
        //-----Controller static-----
        currentImageNo = 0;
        speedHold = 10;
        orientationHold = 0;
        
        sliderFluorescentCHMax1 = 20;
        sliderFluorescentCHMin1 = 0.01;
        sliderFluorescentCHDiff1 = 19.99;
        sliderCutCHMax1 = 255;
        sliderCutCHMin1 = 0;
        sliderCutCHDiff1 = 255;
        
        sliderFluorescentCHMax2 = 20;
        sliderFluorescentCHMin2 = 0.01;
        sliderFluorescentCHDiff2 = 19.99;
        sliderCutCHMax2 = 255;
        sliderCutCHMin2 = 0;
        sliderCutCHDiff2 = 255;
        
        sliderFluorescentCHMax3 = 20;
        sliderFluorescentCHMin3 = 0.01;
        sliderFluorescentCHDiff3 = 19.99;
        sliderCutCHMax3 = 255;
        sliderCutCHMin3 = 0;
        sliderCutCHDiff3 = 255;
        
        sliderFluorescentCHMax4 = 20;
        sliderFluorescentCHMin4 = 0.01;
        sliderFluorescentCHDiff4 = 19.99;
        sliderCutCHMax4 = 255;
        sliderCutCHMin4 = 0;
        sliderCutCHDiff4 = 255;
        
        sliderFluorescentCHMax5 = 20;
        sliderFluorescentCHMin5 = 0.01;
        sliderFluorescentCHDiff5 = 19.99;
        sliderCutCHMax5 = 255;
        sliderCutCHMin5 = 0;
        sliderCutCHDiff5 = 255;
        
        sliderFluorescentCHMax6 = 20;
        sliderFluorescentCHMin6 = 0.01;
        sliderFluorescentCHDiff6 = 19.99;
        sliderCutCHMax6 = 255;
        sliderCutCHMin6 = 0;
        sliderCutCHDiff6 = 255;
        
        sliderDICMax = 20;
        sliderDICMin = 0.01;
        sliderDICDiff = 19.99;
        sliderCutDICMax = 255;
        sliderCutDICMin = 0;
        sliderCutDICDiff = 255;
        
        sliderRMax = 20;
        sliderRMin = 0.01;
        sliderRDiff = 19.99;
        
        sliderGMax = 20;
        sliderGMin = 0.01;
        sliderGDiff = 19.99;
        
        sliderBMax = 20;
        sliderBMin = 0.01;
        sliderBDiff = 19.99;
        
        sliderStart = 0;
        sliderEnd = 0;
    }
    
    return self;
}

-(void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat xLength = screenRect.size.width;
    CGFloat yLength = screenRect.size.height;
    
    int mainControllerX = 800;
    
    NSRect windowSize = [controllerWindow frame];
    CGFloat windowWidth = windowSize.size.width;
    CGFloat windowHeight = windowSize.size.height;
    
    int displayPositionType = 0;
    
    if (80+mainControllerX+5+windowWidth+5+80 > xLength) displayPositionType = 1;
    
    CGFloat displayX;
    
    if (displayPositionType == 1) displayX = 550;
    else displayX = 80+mainControllerX+5;
    
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [controllerWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    imageDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images";
    
    [speed setDelegate:self];
    
    [listBrowser setTarget:self];
    [listBrowser setDoubleAction:@selector(browserDoubleClick:)];
}

-(void)applicationDidFinishLaunching:(NSNotification*)notification{
    string movieSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CMBasic";
    
    string getString;
    
    ifstream fin;
    fin.open(movieSettingPath.c_str(),ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), speedHold = atoi(getString.c_str());
        getline(fin, getString), orientationHold = atoi(getString.c_str());
        fin.close();
    }
    else{
        
        ofstream oin;
        oin.open(movieSettingPath.c_str(),ios::out);
        oin<<speedHold<<endl;
        oin<<orientationHold<<endl;
        oin.close();
    }
    
    [speed setIntegerValue:speedHold];
    [stepper setIntValue:speedHold];
    [stepper setMinValue:10];
    [stepper setMaxValue:1000];
    
    if (orientationHold == 0) [direction setStringValue:@"FW"];
    else [direction setStringValue:@"RW"];
    
    [timePoint setStringValue:@"nil"];
    [analysisName setStringValue:@"nil"];
    [treatment setStringValue:@"nil"];
    
    [movieStatus setStringValue:@"Off"];
    [movieText setStringValue:@"Movie"];
    
    [chLabel1 setStringValue:@"CH1"];
    [chLabel2 setStringValue:@"CH2"];
    [chLabel3 setStringValue:@"CH3"];
    [chLabel4 setStringValue:@"CH4"];
    [chLabel5 setStringValue:@"CH5"];
    [chLabel6 setStringValue:@"CH6"];
    [chName1 setStringValue:@"nil"];
    [chName2 setStringValue:@"nil"];
    [chName3 setStringValue:@"nil"];
    [chName4 setStringValue:@"nil"];
    [chName5 setStringValue:@"nil"];
    [chName6 setStringValue:@"nil"];
    [chLevel1 setStringValue:@"nil"];
    [chLevel2 setStringValue:@"nil"];
    [chLevel3 setStringValue:@"nil"];
    [chLevel4 setStringValue:@"nil"];
    [chLevel5 setStringValue:@"nil"];
    [chLevel6 setStringValue:@"nil"];
    [chCut1 setStringValue:@"nil"];
    [chCut2 setStringValue:@"nil"];
    [chCut3 setStringValue:@"nil"];
    [chCut4 setStringValue:@"nil"];
    [chCut5 setStringValue:@"nil"];
    [chCut6 setStringValue:@"nil"];
    [chCutDIC setStringValue:@"nil"];
    [chStatus1 setStringValue:@"Off"];
    [chStatus2 setStringValue:@"Off"];
    [chStatus3 setStringValue:@"Off"];
    [chStatus4 setStringValue:@"Off"];
    [chStatus5 setStringValue:@"Off"];
    [chStatus6 setStringValue:@"Off"];
    [chLevelDIC setStringValue:@"nil"];
    [chDICImage setStringValue:@"IF Image"];
    
    arrayDirectoryInfo = new string [100];
    directoryInfoCount = 0;
    directoryInfoLimit = 100;
    
    [listBrowser reloadColumn:0];
    
    timerCD = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    if (timePointDisplayCall == 1){
        [timePoint setIntegerValue:timePointHold];
        
        NSString *treatNSString = [timePoint stringValue];
        
        if (treatNSString != NULL){
            string treatString = [treatNSString UTF8String];
            
            if (to_string(timePointHold) == treatString) timePointDisplayCall = 0;
        }
    }
    
    if (movieRunningFlag == 1){
        if (orientationHold == 0 && movieTiming == 0){
            movieTiming = 1;
            filePosition++;
            
            if (maxImageNo < filePosition){
                filePosition--;
                movieRunningFlag = 0;
                
                [movieStatus setTextColor:[NSColor blackColor]];
                [movieStatus setStringValue:@"Off"];
                [movieText setTextColor:[NSColor blackColor]];
                [movieText setStringValue:@"Movie"];
            }
            else{
                
                [self dataSetAndDisplay];
                
                string timeDisplayTemp = fileList [(filePosition-1)*7];
                timeDisplayTemp = timeDisplayTemp.substr(8, 4);
                
                timePointHold = atoi(timeDisplayTemp.c_str());
                [timePoint setIntegerValue:timePointHold];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
            }
        }
        else if (orientationHold == 1 && movieTiming == 0){
            movieTiming = 1;
            filePosition--;
            
            if (filePosition <= 0){
                filePosition = 1;
                movieRunningFlag = 0;
                
                [movieStatus setTextColor:[NSColor blackColor]];
                [movieStatus setStringValue:@"Off"];
                [movieText setTextColor:[NSColor blackColor]];
                [movieText setStringValue:@"Movie"];
            }
            else{
                
                [self dataSetAndDisplay];
                
                string timeDisplayTemp = fileList [(filePosition-1)*7];
                timeDisplayTemp = timeDisplayTemp.substr(8, 4);
                
                timePointHold = atoi(timeDisplayTemp.c_str());
                [timePoint setIntegerValue:timePointHold];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
            }
        }
    }
    
    if (colorInfoDisplayCall == 1){
        colorInfoDisplayCall = 2;
        
        int mode = 1;
        
        if (colorFlag1 == 1){
            [self setCH1:mode];
            
            if (colorFlag2 == 1){
                [self setCH2:mode];
                
                if (colorFlag3 == 1){
                    [self setCH3:mode];
                    
                    if (colorFlag4 == 1){
                        [self setCH4:mode];
                        
                        if (colorFlag5 == 1){
                            [self setCH5:mode];
                            
                            if (colorFlag6 == 1) [self setCH6:mode];
                            else [self resetSubCH6];
                        }
                        else [self resetSubCH5];
                    }
                    else [self resetSubCH4];
                }
                else [self resetSubCH3];
            }
            else [self resetSubCH2];
        }
        else{
            
            if (colorFlag1 == 0) [self resetSubCH1];
        }
        
        colorInfoDisplayCall = 0;
    }
    
    if (tableCallFluorescentCount == 1){
        tableCallFluorescentCount = 0;
        rowIndexFluorescentHold = tableCurrentFluRowHold;
    }
    
    if (tableCallFluorescentCount > 1) tableCallFluorescentCount = 0;
    
    if (sliderStart == 1 && sliderEnd == 0){
        sliderEnd = 1;
        sliderStart = 0;
    }
    
    if (sliderEnd == 1){
        if (sliderStart == 1) sliderStart = 0;
        else{
            
            sliderStart = 0;
            sliderEnd = 0;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
    }
}

-(int)browser:(NSBrowser *)sender numberOfRowsInColumn:(int)column{
    directoryInfoCount = 0;
    
    DIR *dir;
    struct dirent *dent;
    
    if (column == 0 && copyProgressFlag == 0 && directoryInfoLimit >= 100){
        dir = opendir(imageDataPath.c_str());
        
        if (dir != NULL){
            string entry;
            
            while((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if ((int)entry.find("_Image") != -1){
                        if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                        
                        entry = entry.substr(0, entry.find("_Image"));
                        arrayDirectoryInfo [directoryInfoCount] = entry, directoryInfoCount++;
                    }
                }
            }
            
            closedir(dir);
            
            //-----Directory Sort----
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
            }
        }
    }
    
    if (column == 1 && copyProgressFlag == 0){
        NSString *path;
        path = [sender path];
        
        string imageFolderPath = imageDataPath+[path UTF8String]+"_Image";
        string imageFolderPath2 = "";
        string imageNameTemp = [path UTF8String];
        
        if (imageNameTemp != ""){
            imageNameTemp = imageNameTemp.substr(1);
            
            dir = opendir(imageFolderPath.c_str());
            
            if (dir != NULL){
                string entry;
                
                while((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if ((int)entry.find("_Stitch") != -1){
                            if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                            
                            entry = entry.substr(0, entry.find("_Stitch"));
                            
                            arrayDirectoryInfo [directoryInfoCount] = entry, directoryInfoCount++;
                        }
                    }
                }
                
                closedir(dir);
                
                //-----Directory Sort----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                    [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
        }
    }
    
    return directoryInfoCount;
}

-(void)browser:(NSBrowser *)sender willDisplayCell:(id)cell atRow:(int)row column:(int)column{
    if (column == 0){
        string folderName = arrayDirectoryInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLoaded:YES];
    }
    
    if (column == 1){
        string folderName = arrayDirectoryInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLeaf:YES];
    }
}

-(IBAction)browserDoubleClick:(id)browser{
    NSString *nodePath = [browser path];
    string nodePathString = [nodePath UTF8String];
    
    if (nodePathString != "" && movieRunningFlag == 0 && copyProgressFlag == 0){
        nodePathString = nodePathString.substr(1);
        
        if ((int)nodePathString.find("/") != -1){
            analysisNameHold = nodePathString.substr(0, nodePathString.find("/"));
            treatNameHold = nodePathString.substr(nodePathString.find("/")+1);
            
            imageDisplayPath = imageDataPath+"/"+analysisNameHold+"_Image/"+treatNameHold+"_Stitch";
            
            string imageNo;
            string imageNoTemp;
            string firstImageName = "";
            int maxNoTemp = 0;
            
            lastDICImageTime = 0;
            lastTIFRoundNo = 0;
            
            DIR *dir;
            struct dirent *dent;
            
            dir = opendir(imageDisplayPath.c_str());
            
            if (dir != NULL){
                string entry;
                
                while((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if ((int)entry.find("STimage") != -1){
                            imageNoTemp = entry.substr(8, 4);
                            
                            if (atoi(imageNoTemp.c_str()) > maxNoTemp) maxNoTemp = atoi(imageNoTemp.c_str());
                            
                            if ((int)entry.find("tif") != -1 || (int)entry.find("TIF") != -1){
                                if ((int)entry.find("TIF") == -1 && lastDICImageTime < atoi(imageNoTemp.c_str())){
                                    lastDICImageTime = atoi(imageNoTemp.c_str());
                                }
                                if ((int)entry.find("TIF") != -1 && lastTIFRoundNo < atoi(entry.substr(entry.find("TIF")+3).c_str())){
                                    lastTIFRoundNo = atoi(entry.substr(entry.find("TIF")+3).c_str());
                                }
                            }
                            else if ((int)entry.find("bmp") != -1 || (int)entry.find("BMP") != -1){
                                if ((int)entry.find("BMP") == -1 && lastDICImageTime < atoi(imageNoTemp.c_str())){
                                    lastDICImageTime = atoi(imageNoTemp.c_str());
                                }
                                if ((int)entry.find("BMP") != -1 && lastTIFRoundNo < atoi(entry.substr(entry.find("BMP")+3).c_str())){
                                    lastTIFRoundNo = atoi(entry.substr(entry.find("BMP")+3).c_str());
                                }
                            }
                            
                            if (firstImageName == "") firstImageName = entry;
                        }
                    }
                }
                
                closedir(dir);
            }
            
            if (maxNoTemp > 0 && lastDICImageTime != 0){
                maxImageNo = maxNoTemp;
                currentImageNo = 1;
                
                string movieSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CMBasic";
                
                ofstream oin;
                oin.open(movieSettingPath.c_str(),ios::in);
                oin<<speedHold<<endl;
                oin<<orientationHold<<endl;
                oin.close();
                
                if (fileListStatus == 1){
                    delete [] fileList;
                }
                
                fileList = new string [maxNoTemp*7+4];
                fileListCount = 0;
                
                string *fileListTemp = new string [maxNoTemp*7+4];
                int fileListTempCount = 0;
                
                dir = opendir(imageDisplayPath.c_str());
                
                if (dir != NULL){
                    string entry;
                    
                    while((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("STimage") != -1){
                                fileListTemp [fileListTempCount] = entry, fileListTempCount++;
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                //-----Directory Sort----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < fileListTempCount; counter1++){
                    [unsortedArray addObject:@(fileListTemp [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    fileListTemp [counter1] = [unsortedArray [counter1] UTF8String];
                }
                
                for (int counter1 = 0; counter1 < fileListTempCount; counter1++){
                    if ((int)fileListTemp [counter1].find("_") == -1){
                        fileList [fileListCount] = fileListTemp [counter1], fileListCount++;
                        fileList [fileListCount] = "", fileListCount++;
                        fileList [fileListCount] = "", fileListCount++;
                        fileList [fileListCount] = "", fileListCount++;
                        fileList [fileListCount] = "", fileListCount++;
                        fileList [fileListCount] = "", fileListCount++;
                        fileList [fileListCount] = "", fileListCount++;
                    }
                }
                
                int  timePosition = 0;
                
                for (int counter1 = 0; counter1 < fileListTempCount; counter1++){
                    if ((int)fileListTemp [counter1].find("_1_") != -1 || (int)fileListTemp [counter1].find("_2_") != -1 || (int)fileListTemp [counter1].find("_3_") != -1 || (int)fileListTemp [counter1].find("_4_") != -1 || (int)fileListTemp [counter1].find("_5_") != -1 || (int)fileListTemp [counter1].find("_6_") != -1 || (int)fileListTemp [counter1].find("_7_") != -1 || (int)fileListTemp [counter1].find("_8_") != -1 || (int)fileListTemp [counter1].find("_9_") != -1){
                        timePosition = atoi(fileListTemp [counter1].substr(fileListTemp [counter1].find("STimage ")+8, 4).c_str())-1;
                        
                        if (fileList [timePosition*7+1] == "") fileList [timePosition*7+1] = fileListTemp [counter1];
                        else if (fileList [timePosition*7+2] == "") fileList [timePosition*7+2] = fileListTemp [counter1];
                        else if (fileList [timePosition*7+3] == "") fileList [timePosition*7+3] = fileListTemp [counter1];
                        else if (fileList [timePosition*7+4] == "") fileList [timePosition*7+4] = fileListTemp [counter1];
                        else if (fileList [timePosition*7+5] == "") fileList [timePosition*7+5] = fileListTemp [counter1];
                        else if (fileList [timePosition*7+6] == "") fileList [timePosition*7+6] = fileListTemp [counter1];
                    }
                }
                
                delete [] fileListTemp;
                
                firstImageName = fileList [0];
                
                string firstImagePath = imageDisplayPath+"/"+firstImageName;
                
                imageXYLength = 0;
                
                ifstream fin;
                
                if ((int)firstImageName.find("tif") != -1 || (int)firstImageName.find("TIF") != -1){
                    imageBmpTifFlag = 0;
                    
                    //----Tiff reading----
                    unsigned long stripFirstAddress = 0;
                    unsigned long stripByteCountAddress = 0;
                    unsigned long nextAddress = 0;
                    unsigned long headPosition = 0;
                    unsigned long stripEntry = 0;
                    long sizeForCopy = 0;
                    
                    double xPosition = 0;
                    double yPosition = 0;
                    
                    int imageWidth = 0;
                    int imageHeight = 0;
                    int imageBit = 0; // Check 8, 16
                    int imageCompression = 0; // Check 1
                    int photoMetric = 0; //check 0, 1, 2
                    int imageDimensionTif = 0;
                    int endianType = 0;
                    int samplePerPix = 0;
                    int dataConversion [4];
                    int processTypeTif = 1;
                    int numberOfLayers = 0;
                    struct stat sizeOfFile;
                    
                    if (stat(firstImagePath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        fileReadArray = new uint8_t [sizeForCopy+4];
                        fin.open(firstImagePath.c_str(), ios::in | ios::binary);
                        
                        fin.read((char*)fileReadArray, sizeForCopy+4);
                        fin.close();
                        
                        dataConversion [0] = fileReadArray [0];
                        dataConversion [1] = fileReadArray [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        int *arrayExtractedImage3 = new int [100];
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = fileReadArray [7];
                            dataConversion [1] = fileReadArray [6];
                            dataConversion [2] = fileReadArray [5];
                            dataConversion [3] = fileReadArray [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = fileReadArray [4];
                            dataConversion [1] = fileReadArray [5];
                            dataConversion [2] = fileReadArray [6];
                            dataConversion [3] = fileReadArray [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        if (endianType == 1){
                            tiffFileRead = [[TiffFileRead alloc] init];
                            [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            
                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                else imageDimensionTif = imageHeight;
                                
                                tiffFileRead = [[TiffFileRead alloc] init];
                                delete [] arrayExtractedImage3;
                                
                                arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                            }
                        }
                        else if (endianType == 0){
                            tiffFileRead = [[TiffFileRead alloc] init];
                            [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            
                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                else imageDimensionTif = imageHeight;
                                
                                tiffFileRead = [[TiffFileRead alloc] init];
                                delete [] arrayExtractedImage3;
                                
                                arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                            }
                        }
                        
                        if (photoMetric <= 1){
                            grayColorStatus = 0;
                            [chColor setTextColor:[NSColor whiteColor]];
                            [chColor setStringValue:@"Color"];
                        }
                        else if (photoMetric == 2){
                            grayColorStatus = 1;
                            [chColor setTextColor:[NSColor redColor]];
                            [chColor setStringValue:@"Color"];
                        }
                        
                        imageXYLength = imageDimensionTif;
                        
                        delete [] fileReadArray;
                        delete [] arrayExtractedImage3;
                    }
                }
                else if ((int)firstImageName.find("bmp") != -1 || (int)firstImageName.find("BMP") != -1){
                    imageBmpTifFlag = 1;
                    
                    int bitPosition = 0;
                    int bitData = 0;
                    int verticalBit [4];
                    
                    fin.open(firstImagePath.c_str(),ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        while((bitData = fin.get()) != EOF){
                            if (bitPosition == 22) verticalBit [0] = bitData;
                            if (bitPosition == 23) verticalBit [1] = bitData;
                            if (bitPosition == 24) verticalBit [2] = bitData;
                            if (bitPosition == 25){
                                verticalBit [3] = bitData;
                                imageXYLength = verticalBit [3]*16777216+verticalBit [2]*65536+verticalBit [1]*256+verticalBit [0];
                                break;
                            }
                            
                            bitPosition++;
                        }
                        
                        fin.close();
                    }
                    
                    grayColorStatus = 0;
                    [chColor setTextColor:[NSColor whiteColor]];
                    [chColor setStringValue:@"Color"];
                }
                
                if (imageXYLength != 0){
                    fileListStatus = 1;
                    
                    filePosition = 1;
                    imageLoadFlagFluorescent = 0;
                    imageLoadFlagDICPos = 0;
                    imageLoadFlagLabel = 0;
                    uploadTempFileSize = 0;
                    
                    struct stat sizeOfFile;
                    
                    if (stat(firstImagePath.c_str(), &sizeOfFile) == 0){
                        uploadTempFileSize = sizeOfFile.st_size;
                    }
                    
                    if (uploadTempStatus == 1) delete [] uploadTemp;
                    
                    uploadTemp = new uint8_t [uploadTempFileSize*3+50];
                    
                    uploadTempStatus = 1;
                    
                    fin.open(firstImagePath.c_str(), ios::in | ios::binary);
                    
                    fin.read((char*)uploadTemp, (long)uploadTempFileSize+1);
                    fin.close();
                    
                    int mode = 0;
                    
                    if (fileList [(filePosition-1)*7+1] != ""){
                        [self setCH1:mode];
                        
                        if (fileList [(filePosition-1)*7+2] != ""){
                            [self setCH2:mode];
                            
                            if (fileList [(filePosition-1)*7+3] != ""){
                                [self  setCH3:mode];
                                
                                if (fileList [(filePosition-1)*7+4] != ""){
                                    [self setCH4:mode];
                                    
                                    if (fileList [(filePosition-1)*7+5] != ""){
                                        [self setCH5:mode];
                                        
                                        if (fileList [(filePosition-1)*7+6] != "") [self setCH6:mode];
                                        else{
                                            
                                            if (uploadTempStatusCl6 == 1){
                                                delete [] uploadTempCl6;
                                                uploadTempStatusCl6 = 0;
                                            }
                                        }
                                    }
                                    else{
                                        
                                        if (uploadTempStatusCl5 == 1){
                                            delete [] uploadTempCl5;
                                            uploadTempStatusCl5 = 0;
                                        }
                                        
                                        if (uploadTempStatusCl6 == 1){
                                            delete [] uploadTempCl6;
                                            uploadTempStatusCl6 = 0;
                                        }
                                    }
                                }
                                else{
                                    
                                    if (uploadTempStatusCl4 == 1){
                                        delete [] uploadTempCl4;
                                        uploadTempStatusCl4 = 0;
                                    }
                                    
                                    if (uploadTempStatusCl5 == 1){
                                        delete [] uploadTempCl5;
                                        uploadTempStatusCl5 = 0;
                                    }
                                    
                                    if (uploadTempStatusCl6 == 1){
                                        delete [] uploadTempCl6;
                                        uploadTempStatusCl6 = 0;
                                    }
                                }
                            }
                            else{
                                
                                if (uploadTempStatusCl3 == 1){
                                    delete [] uploadTempCl3;
                                    uploadTempStatusCl3 = 0;
                                }
                                
                                if (uploadTempStatusCl4 == 1){
                                    delete [] uploadTempCl4;
                                    uploadTempStatusCl4 = 0;
                                }
                                
                                if (uploadTempStatusCl5 == 1){
                                    delete [] uploadTempCl5;
                                    uploadTempStatusCl5 = 0;
                                }
                                
                                if (uploadTempStatusCl6 == 1){
                                    delete [] uploadTempCl6;
                                    uploadTempStatusCl6 = 0;
                                }
                            }
                        }
                        else{
                            
                            if (uploadTempStatusCl2 == 1){
                                delete [] uploadTempCl2;
                                uploadTempStatusCl2 = 0;
                            }
                            
                            if (uploadTempStatusCl3 == 1){
                                delete [] uploadTempCl3;
                                uploadTempStatusCl3 = 0;
                            }
                            
                            if (uploadTempStatusCl4 == 1){
                                delete [] uploadTempCl4;
                                uploadTempStatusCl4 = 0;
                            }
                            
                            if (uploadTempStatusCl5 == 1){
                                delete [] uploadTempCl5;
                                uploadTempStatusCl5 = 0;
                            }
                            
                            if (uploadTempStatusCl6 == 1){
                                delete [] uploadTempCl6;
                                uploadTempStatusCl6 = 0;
                            }
                        }
                    }
                    else{
                        
                        if (uploadTempStatusCl1 == 1){
                            delete [] uploadTempCl1;
                            uploadTempStatusCl1 = 0;
                        }
                        
                        if (uploadTempStatusCl2 == 1){
                            delete [] uploadTempCl2;
                            uploadTempStatusCl2 = 0;
                        }
                        
                        if (uploadTempStatusCl3 == 1){
                            delete [] uploadTempCl3;
                            uploadTempStatusCl3 = 0;
                        }
                        
                        if (uploadTempStatusCl4 == 1){
                            delete [] uploadTempCl4;
                            uploadTempStatusCl4 = 0;
                        }
                        
                        if (uploadTempStatusCl5 == 1){
                            delete [] uploadTempCl5;
                            uploadTempStatusCl5 = 0;
                        }
                        
                        if (uploadTempStatusCl6 == 1){
                            delete [] uploadTempCl6;
                            uploadTempStatusCl6 = 0;
                        }
                        
                        if (colorFlag1 != 0){
                            [self resetSubCH1];
                        }
                    }
                    
                    [analysisName setStringValue:@(analysisNameHold.c_str())];
                    [treatment setStringValue:@(treatNameHold.c_str())];
                    [timePoint setIntegerValue:currentImageNo];
                    
                    holdCopyFolderName = "";
                    holdDeleteFolderName = "";
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Image Size Retrieval Failed"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Image Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Image Folder Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)quitProcess:(id)sender{
    if (copyProgressFlag == 0){
        delete [] arrayDirectoryInfo;
        
        if (fileListStatus == 1){
            delete [] fileList;
        }
        
        if (uploadTempStatus == 1) delete [] uploadTemp;
        if (uploadTempStatusCl1 == 1) delete [] uploadTempCl1;
        if (uploadTempStatusCl2 == 1) delete [] uploadTempCl2;
        if (uploadTempStatusCl3 == 1) delete [] uploadTempCl3;
        if (uploadTempStatusCl4 == 1) delete [] uploadTempCl4;
        if (uploadTempStatusCl5 == 1) delete [] uploadTempCl5;
        if (uploadTempStatusCl6 == 1) delete [] uploadTempCl6;
        
        if (referenceImageStatusFluorescent == 1){
            for (int counter1 = 0; counter1 < imageSizeFluorescent+5; counter1++){
                delete [] arrayReferenceImageFluorescent [counter1];
            }
            
            delete [] arrayReferenceImageFluorescent;
        }
        
        if (dicImageStatusFluorescent == 1){
            for (int counter1 = 0; counter1 < imageSizeFluorescent+5; counter1++){
                delete [] arrayDICImageForFluorescent [counter1];
            }
            
            delete [] arrayDICImageForFluorescent;
        }
        
        if (referenceImageStatusPos == 1){
            for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
                delete [] arrayReferenceImagePos [counter1];
            }
            
            delete [] arrayReferenceImagePos;
        }
        
        if (dicImageStatusPos == 1){
            for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
                delete [] arrayDICImageForPos [counter1];
            }
            
            delete [] arrayDICImageForPos;
        }
        
        if (labelImageStatus == 1){
            for (int counter1 = 0; counter1 < imageSizeLabelHold+5; counter1++){
                delete [] arrayLabelImage [counter1];
            }
            
            delete [] arrayLabelImage;
        }
        
        exit (0);
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)startProcess:(id)sender{
    if (imageXYLength != 0 && copyProgressFlag == 0){
        if (movieRunningFlag == 0){
            movieRunningFlag = 1;
            movieTiming = 0;
            
            [movieStatus setTextColor:[NSColor redColor]];
            [movieStatus setStringValue:@"On"];
            [movieText setTextColor:[NSColor redColor]];
            [movieText setStringValue:@"Movie"];
        }
        else if (movieRunningFlag == 1){
            movieRunningFlag = 0;
            
            [movieStatus setTextColor:[NSColor blackColor]];
            [movieStatus setStringValue:@"Off"];
            [movieText setTextColor:[NSColor blackColor]];
            [movieText setStringValue:@"Movie"];
        }
    }
}

-(IBAction)directionSet:(id)sender{
    if (orientationHold == 0 && movieRunningFlag == 0){
        orientationHold = 1;
        
        string movieSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CMBasic";
        
        ofstream oin;
        oin.open(movieSettingPath.c_str(),ios::out);
        oin<<speedHold<<endl;
        oin<<orientationHold<<endl;
        oin.close();
        [direction setStringValue:@"RW"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else if (orientationHold == 1 && movieRunningFlag == 0){
        orientationHold = 0;
        
        string movieSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CMBasic";
        
        ofstream oin;
        oin.open(movieSettingPath.c_str(),ios::out);
        oin<<speedHold<<endl;
        oin<<orientationHold<<endl;
        oin.close();
        
        [direction setStringValue:@"FW"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(void)controlTextDidChange:(NSNotification *)aNotification {
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]) {
        if ([aNotification object] == speed && movieRunningFlag == 0){
            if ([speed intValue] >= 10 && [speed intValue] <= 1000){
                [stepper setIntValue:[speed intValue]];
                speedHold = [speed intValue];
                
                string movieSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CMBasic";
                
                ofstream oin;
                oin.open(movieSettingPath.c_str(),ios::in);
                oin<<speedHold<<endl;
                oin<<orientationHold<<endl;
                oin.close();
            }
        }
    }
}

-(IBAction)stepperAction:(id)sender{
    if (movieRunningFlag == 0){
        if ([stepper intValue] >= 10 && [stepper intValue] <= 1000){
            [speed setIntValue:[stepper intValue]];
            speedHold = [stepper intValue];
            
            string movieSettingPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/CMBasic";
            
            ofstream oin;
            oin.open(movieSettingPath.c_str(),ios::in);
            oin<<speedHold<<endl;
            oin<<orientationHold<<endl;
            oin.close();
        }
        else{
            
            [speed setStringValue:@""];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)tableReload:(id)sender{
    if (copyProgressFlag == 0){
        [listBrowser reloadColumn:0];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)tenFW:(id)sender{
    if (copyProgressFlag == 0){
        if (imageXYLength != 0 && movieRunningFlag == 0){
            filePosition = filePosition+10;
            
            if (maxImageNo < filePosition) filePosition = maxImageNo;
            
            [self dataSetAndDisplay];
            
            string timeDisplayTemp = fileList [(filePosition-1)*7];
            timeDisplayTemp = timeDisplayTemp.substr(8, 4);
            
            timePointHold = atoi(timeDisplayTemp.c_str());
            timePointDisplayCall = 1;
            imageLoadFlagDICPos = 0;
            imageLoadFlagLabel = 0;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Copy In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)tenBW:(id)sender{
    if (copyProgressFlag == 0){
        if (imageXYLength != 0 && movieRunningFlag == 0){
            filePosition = filePosition-10;
            
            if (filePosition <= 0) filePosition = 1;
            
            [self dataSetAndDisplay];
            
            string timeDisplayTemp = fileList [(filePosition-1)*7];
            timeDisplayTemp = timeDisplayTemp.substr(8, 4);
            
            timePointHold = atoi(timeDisplayTemp.c_str());
            timePointDisplayCall = 1;
            imageLoadFlagDICPos = 0;
            imageLoadFlagLabel = 0;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)hundredFW:(id)sender{
    if (copyProgressFlag == 0){
        if (imageXYLength != 0 && movieRunningFlag == 0){
            filePosition = filePosition+100;
            
            if (maxImageNo < filePosition) filePosition = maxImageNo;
            
            [self dataSetAndDisplay];
            
            string timeDisplayTemp = fileList [(filePosition-1)*7];
            timeDisplayTemp = timeDisplayTemp.substr(8, 4);
            
            timePointHold = atoi(timeDisplayTemp.c_str());
            timePointDisplayCall = 1;
            imageLoadFlagDICPos = 0;
            imageLoadFlagLabel = 0;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)hundredBW:(id)sender{
    if (copyProgressFlag == 0){
        if (imageXYLength != 0 && movieRunningFlag == 0){
            filePosition = filePosition-100;
            
            if (filePosition <= 0) filePosition = 1;
            
            [self dataSetAndDisplay];
            
            string timeDisplayTemp = fileList [(filePosition-1)*7];
            timeDisplayTemp = timeDisplayTemp.substr(8, 4);
            
            timePointHold = atoi(timeDisplayTemp.c_str());
            timePointDisplayCall = 1;
            imageLoadFlagDICPos = 0;
            imageLoadFlagLabel = 0;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)positionAdjustStart:(id)sender{
    if (copyProgressFlag == 0){
        if (imageXYLength != 0 && movieRunningFlag == 0){
            if (positionAdjustOperationFluorescent == 0){
                positionAdjustOperationFluorescent = 1;
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentController object:self];
            }
            
            if (positionAdjustOperationFluorescent == 2) positionAdjustOperationFluorescent = 3;
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)positionDICAdjustStart:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        if (positionDICAdjustOperation == 0){
            positionDICAdjustOperation = 1;
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDICController object:self];
        }
        
        if (positionDICAdjustOperation == 2) positionDICAdjustOperation = 3;
    }
}

-(IBAction)labelSetStart:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        if (labelSetOperation == 0){
            labelSetOperation = 1;
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLabelSet object:self];
        }
        
        if (labelSetOperation == 2) labelSetOperation = 3;
    }
}

-(void)dataSetAndDisplay{
    string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7];
    
    if (statusHoldDIC == 1){
        if (filePosition > lastDICImageTime) imageMoviePath = imageDisplayPath+"/"+fileList [(lastDICImageTime-1)*7];
    }
    
    ifstream fin;
    fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
    
    fin.read((char*)uploadTemp, (long)uploadTempFileSize+1);
    fin.close();
    
    int mode = 0;
    
    if (fileList [(filePosition-1)*7+1] != ""){
        [self setCH1:mode];
        
        if (fileList [(filePosition-1)*7+2] != ""){
            [self setCH2:mode];
            
            if (fileList [(filePosition-1)*7+3] != ""){
                [self setCH3:mode];
                
                if (fileList [(filePosition-1)*7+4] != ""){
                    [self setCH4:mode];
                    
                    if (fileList [(filePosition-1)*7+5] != ""){
                        [self setCH5:mode];
                        
                        if (fileList [(filePosition-1)*7+6] != "") [self setCH6:mode];
                        else [self resetSubCH6];
                    }
                    else [self resetSubCH5];
                }
                else [self resetSubCH4];
            }
            else [self resetSubCH3];
        }
        else [self resetSubCH2];
    }
    else{
        
        if (colorFlag1 != 0) [self resetSubCH1];
    }
}

-(void)resetSubCH1{
    colorFlag1 = 0;
    colorFlag2 = 0;
    colorFlag3 = 0;
    colorFlag4 = 0;
    colorFlag5 = 0;
    colorFlag6 = 0;
    
    [chLabel1 setTextColor:[NSColor whiteColor]];
    [chLabel1 setStringValue:@"CH1:"];
    [chName1 setTextColor:[NSColor whiteColor]];
    [chName1 setStringValue:@"nil"];
    
    [chLabel2 setTextColor:[NSColor whiteColor]];
    [chLabel2 setStringValue:@"CH2:"];
    [chName2 setTextColor:[NSColor whiteColor]];
    [chName2 setStringValue:@"nil"];
    
    [chLabel3 setTextColor:[NSColor whiteColor]];
    [chLabel3 setStringValue:@"CH3:"];
    [chName3 setTextColor:[NSColor whiteColor]];
    [chName3 setStringValue:@"nil"];
    
    [chLabel4 setTextColor:[NSColor whiteColor]];
    [chLabel4 setStringValue:@"CH4:"];
    [chName4 setTextColor:[NSColor whiteColor]];
    [chName4 setStringValue:@"nil"];
    
    [chLabel5 setTextColor:[NSColor whiteColor]];
    [chLabel5 setStringValue:@"CH5:"];
    [chName5 setTextColor:[NSColor whiteColor]];
    [chName5 setStringValue:@"nil"];
    
    [chLabel6 setTextColor:[NSColor whiteColor]];
    [chLabel6 setStringValue:@"CH6:"];
    [chName6 setTextColor:[NSColor whiteColor]];
    [chName6 setStringValue:@"nil"];
    
    [chLevel1 setStringValue:@"nil"];
    [chLevel2 setStringValue:@"nil"];
    [chLevel3 setStringValue:@"nil"];
    [chLevel4 setStringValue:@"nil"];
    [chLevel5 setStringValue:@"nil"];
    [chLevel6 setStringValue:@"nil"];
    [chCut1 setStringValue:@"nil"];
    [chCut2 setStringValue:@"nil"];
    [chCut3 setStringValue:@"nil"];
    [chCut4 setStringValue:@"nil"];
    [chCut5 setStringValue:@"nil"];
    [chCut6 setStringValue:@"nil"];
    [chStatus1 setStringValue:@"Off"];
    [chStatus2 setStringValue:@"Off"];
    [chStatus3 setStringValue:@"Off"];
    [chStatus4 setStringValue:@"Off"];
    [chStatus5 setStringValue:@"Off"];
    [chStatus6 setStringValue:@"Off"];
    
    [sliderKnobLevel1 setIntegerValue:1];
    [sliderKnobCut1 setIntegerValue:50];
    [sliderKnobLevel2 setIntegerValue:1];
    [sliderKnobCut2 setIntegerValue:50];
    [sliderKnobLevel3 setIntegerValue:1];
    [sliderKnobCut3 setIntegerValue:50];
    [sliderKnobLevel4 setIntegerValue:1];
    [sliderKnobCut4 setIntegerValue:50];
    [sliderKnobLevel5 setIntegerValue:1];
    [sliderKnobCut5 setIntegerValue:50];
    [sliderKnobLevel6 setIntegerValue:1];
    [sliderKnobCut6 setIntegerValue:50];
}

-(void)resetSubCH2{
    colorFlag2 = 0;
    colorFlag3 = 0;
    colorFlag4 = 0;
    colorFlag5 = 0;
    colorFlag6 = 0;
    
    [chLabel2 setTextColor:[NSColor whiteColor]];
    [chLabel2 setStringValue:@"CH2:"];
    [chName2 setTextColor:[NSColor whiteColor]];
    [chName2 setStringValue:@"nil"];
    
    [chLabel3 setTextColor:[NSColor whiteColor]];
    [chLabel3 setStringValue:@"CH3:"];
    [chName3 setTextColor:[NSColor whiteColor]];
    [chName3 setStringValue:@"nil"];
    
    [chLabel4 setTextColor:[NSColor whiteColor]];
    [chLabel4 setStringValue:@"CH4:"];
    [chName4 setTextColor:[NSColor whiteColor]];
    [chName4 setStringValue:@"nil"];
    
    [chLabel5 setTextColor:[NSColor whiteColor]];
    [chLabel5 setStringValue:@"CH5:"];
    [chName5 setTextColor:[NSColor whiteColor]];
    [chName5 setStringValue:@"nil"];
    
    [chLabel6 setTextColor:[NSColor whiteColor]];
    [chLabel6 setStringValue:@"CH6:"];
    [chName6 setTextColor:[NSColor whiteColor]];
    [chName6 setStringValue:@"nil"];
    
    [chLevel2 setStringValue:@"nil"];
    [chLevel3 setStringValue:@"nil"];
    [chLevel4 setStringValue:@"nil"];
    [chLevel5 setStringValue:@"nil"];
    [chLevel6 setStringValue:@"nil"];
    [chCut2 setStringValue:@"nil"];
    [chCut3 setStringValue:@"nil"];
    [chCut4 setStringValue:@"nil"];
    [chCut5 setStringValue:@"nil"];
    [chCut6 setStringValue:@"nil"];
    [chStatus2 setStringValue:@"Off"];
    [chStatus3 setStringValue:@"Off"];
    [chStatus4 setStringValue:@"Off"];
    [chStatus5 setStringValue:@"Off"];
    [chStatus6 setStringValue:@"Off"];
    
    [sliderKnobLevel2 setIntegerValue:1];
    [sliderKnobCut2 setIntegerValue:50];
    [sliderKnobLevel3 setIntegerValue:1];
    [sliderKnobCut3 setIntegerValue:50];
    [sliderKnobLevel4 setIntegerValue:1];
    [sliderKnobCut4 setIntegerValue:50];
    [sliderKnobLevel5 setIntegerValue:1];
    [sliderKnobCut5 setIntegerValue:50];
    [sliderKnobLevel6 setIntegerValue:1];
    [sliderKnobCut6 setIntegerValue:50];
}

-(void)resetSubCH3{
    colorFlag3 = 0;
    colorFlag4 = 0;
    colorFlag5 = 0;
    colorFlag6 = 0;
    
    [chLabel3 setTextColor:[NSColor whiteColor]];
    [chLabel3 setStringValue:@"CH3:"];
    [chName3 setTextColor:[NSColor whiteColor]];
    [chName3 setStringValue:@"nil"];
    
    [chLabel4 setTextColor:[NSColor whiteColor]];
    [chLabel4 setStringValue:@"CH4:"];
    [chName4 setTextColor:[NSColor whiteColor]];
    [chName4 setStringValue:@"nil"];
    
    [chLabel5 setTextColor:[NSColor whiteColor]];
    [chLabel5 setStringValue:@"CH5:"];
    [chName5 setTextColor:[NSColor whiteColor]];
    [chName5 setStringValue:@"nil"];
    
    [chLabel6 setTextColor:[NSColor whiteColor]];
    [chLabel6 setStringValue:@"CH6:"];
    [chName6 setTextColor:[NSColor whiteColor]];
    [chName6 setStringValue:@"nil"];
    
    [chLevel3 setStringValue:@"nil"];
    [chLevel4 setStringValue:@"nil"];
    [chLevel5 setStringValue:@"nil"];
    [chLevel6 setStringValue:@"nil"];
    [chCut3 setStringValue:@"nil"];
    [chCut4 setStringValue:@"nil"];
    [chCut5 setStringValue:@"nil"];
    [chCut6 setStringValue:@"nil"];
    [chStatus3 setStringValue:@"Off"];
    [chStatus4 setStringValue:@"Off"];
    [chStatus5 setStringValue:@"Off"];
    [chStatus6 setStringValue:@"Off"];
    
    [sliderKnobLevel3 setIntegerValue:1];
    [sliderKnobCut3 setIntegerValue:50];
    [sliderKnobLevel4 setIntegerValue:1];
    [sliderKnobCut4 setIntegerValue:50];
    [sliderKnobLevel5 setIntegerValue:1];
    [sliderKnobCut5 setIntegerValue:50];
    [sliderKnobLevel6 setIntegerValue:1];
    [sliderKnobCut6 setIntegerValue:50];
}

-(void)resetSubCH4{
    colorFlag4 = 0;
    colorFlag5 = 0;
    colorFlag6 = 0;
    
    [chLabel4 setTextColor:[NSColor whiteColor]];
    [chLabel4 setStringValue:@"CH4:"];
    [chName4 setTextColor:[NSColor whiteColor]];
    [chName4 setStringValue:@"nil"];
    
    [chLabel5 setTextColor:[NSColor whiteColor]];
    [chLabel5 setStringValue:@"CH5:"];
    [chName5 setTextColor:[NSColor whiteColor]];
    [chName5 setStringValue:@"nil"];
    
    [chLabel6 setTextColor:[NSColor whiteColor]];
    [chLabel6 setStringValue:@"CH6:"];
    [chName6 setTextColor:[NSColor whiteColor]];
    [chName6 setStringValue:@"nil"];
    
    [chLevel4 setStringValue:@"nil"];
    [chLevel5 setStringValue:@"nil"];
    [chLevel6 setStringValue:@"nil"];
    [chCut4 setStringValue:@"nil"];
    [chCut5 setStringValue:@"nil"];
    [chCut6 setStringValue:@"nil"];
    [chStatus4 setStringValue:@"Off"];
    [chStatus5 setStringValue:@"Off"];
    [chStatus6 setStringValue:@"Off"];
    
    [sliderKnobLevel4 setIntegerValue:1];
    [sliderKnobCut4 setIntegerValue:50];
    [sliderKnobLevel5 setIntegerValue:1];
    [sliderKnobCut5 setIntegerValue:50];
    [sliderKnobLevel6 setIntegerValue:1];
    [sliderKnobCut6 setIntegerValue:50];
}

-(void)resetSubCH5{
    colorFlag5 = 0;
    colorFlag6 = 0;
    
    [chLabel5 setTextColor:[NSColor whiteColor]];
    [chLabel5 setStringValue:@"CH5:"];
    [chName5 setTextColor:[NSColor whiteColor]];
    [chName5 setStringValue:@"nil"];
    
    [chLabel6 setTextColor:[NSColor whiteColor]];
    [chLabel6 setStringValue:@"CH6:"];
    [chName6 setTextColor:[NSColor whiteColor]];
    [chName6 setStringValue:@"nil"];
    
    [chLevel5 setStringValue:@"nil"];
    [chLevel6 setStringValue:@"nil"];
    [chCut5 setStringValue:@"nil"];
    [chCut6 setStringValue:@"nil"];
    [chStatus5 setStringValue:@"Off"];
    [chStatus6 setStringValue:@"Off"];
    
    [sliderKnobLevel5 setIntegerValue:1];
    [sliderKnobCut5 setIntegerValue:50];
    [sliderKnobLevel6 setIntegerValue:1];
    [sliderKnobCut6 setIntegerValue:50];
}

-(void)resetSubCH6{
    colorFlag6 = 0;
    
    [chName5 setTextColor:[NSColor whiteColor]];
    [chName5 setStringValue:@"nil"];
    
    [chName6 setTextColor:[NSColor whiteColor]];
    [chName6 setStringValue:@"nil"];
    
    [chLevel6 setStringValue:@"nil"];
    [chCut6 setStringValue:@"nil"];
    [chStatus6 setStringValue:@"Off"];
    
    [sliderKnobLevel6 setIntegerValue:1];
    [sliderKnobCut6 setIntegerValue:50];
}

-(void)setCH1:(int)mode{
    if (mode == 0){
        colorFlag1 = 1;
        
        unsigned long findString = fileList [(filePosition-1)*7+1].find("tif");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+1].find("TIF");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+1].find("bmp");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+1].find("BMP");
        
        colorNo1 = fileList [(filePosition-1)*7+1].substr(13, 1);
        colorName1 = fileList [(filePosition-1)*7+1].substr(15, findString-16);
        
        string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+1];
        
        if (uploadTempStatusCl1 == 1) delete [] uploadTempCl1;
        
        uploadTempCl1 = new uint8_t [uploadTempFileSize+50];
        uploadTempStatusCl1 = 1;
        
        ifstream fin;
        
        fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
        
        fin.read((char*)uploadTempCl1, (long)uploadTempFileSize+1);
        fin.close();
    }
    
    if (colorNo1 == "1"){
        [chLabel1 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chLabel1 setStringValue:@"CH1:"];
        [chName1 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chName1 setStringValue:@(colorName1.c_str())];
    }
    else if (colorNo1 == "2"){
        [chLabel1 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chLabel1 setStringValue:@"CH1:"];
        [chName1 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chName1 setStringValue:@(colorName1.c_str())];
    }
    else if (colorNo1 == "3"){
        [chLabel1 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chLabel1 setStringValue:@"CH1:"];
        [chName1 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chName1 setStringValue:@(colorName1.c_str())];
    }
    else if (colorNo1 == "4"){
        [chLabel1 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chLabel1 setStringValue:@"CH1:"];
        [chName1 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chName1 setStringValue:@(colorName1.c_str())];
    }
    else if (colorNo1 == "5"){
        [chLabel1 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chLabel1 setStringValue:@"CH1:"];
        [chName1 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chName1 setStringValue:@(colorName1.c_str())];
    }
    else if (colorNo1 == "6"){
        [chLabel1 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chLabel1 setStringValue:@"CH1:"];
        [chName1 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chName1 setStringValue:@(colorName1.c_str())];
    }
    else if (colorNo1 == "7"){
        [chLabel1 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chLabel1 setStringValue:@"CH1:"];
        [chName1 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chName1 setStringValue:@(colorName1.c_str())];
    }
    else if (colorNo1 == "8"){
        [chLabel1 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chLabel1 setStringValue:@"CH1:"];
        [chName1 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chName1 setStringValue:@(colorName1.c_str())];
    }
    else if (colorNo1 == "9"){
        [chLabel1 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chLabel1 setStringValue:@"CH1:"];
        [chName1 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chName1 setStringValue:@(colorName1.c_str())];
    }
    
    int holdTemp = (int)(levelHold1*1000);
    double holdTempDouble = holdTemp/(double)1000;
    
    [chLevel1 setDoubleValue:holdTempDouble];
    
    holdTemp = (int)(cutHold1*1000);
    holdTempDouble = holdTemp/(double)1000;
    
    [chCut1 setDoubleValue:holdTempDouble];
    
    if (statusHold1 == 0){
        [chStatus1 setStringValue:@"Off"];
    }
    else [chStatus1 setStringValue:@"On"];
    
    [sliderKnobLevel1 setIntegerValue:(long)levelHold1];
    [sliderKnobCut1 setDoubleValue:cutHold1];
}

-(void)setCH2:(int)mode{
    if (mode == 0){
        colorFlag2 = 1;
        
        unsigned long findString = fileList [(filePosition-1)*7+2].find("tif");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+2].find("TIF");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+2].find("bmp");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+2].find("BMP");
        
        colorNo2 = fileList [(filePosition-1)*7+2].substr(13, 1);
        colorName2 = fileList [(filePosition-1)*7+2].substr(15, findString-16);
        
        string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+2];
        
        if (uploadTempStatusCl2 == 1) delete [] uploadTempCl2;
        
        uploadTempCl2 = new uint8_t [uploadTempFileSize+50];
        uploadTempStatusCl2 = 1;
        
        ifstream fin;
        
        fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
        
        fin.read((char*)uploadTempCl2, (long)uploadTempFileSize+1);
        fin.close();
    }
    
    if (colorNo2 == "1"){
        [chLabel2 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chLabel2 setStringValue:@"CH2:"];
        [chName2 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chName2 setStringValue:@(colorName2.c_str())];
    }
    else if (colorNo2 == "2"){
        [chLabel2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chLabel2 setStringValue:@"CH2:jj"];
        [chName2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chName2 setStringValue:@(colorName2.c_str())];
    }
    else if (colorNo2 == "3"){
        [chLabel2 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chLabel2 setStringValue:@"CH2:"];
        [chName2 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chName2 setStringValue:@(colorName2.c_str())];
    }
    else if (colorNo2 == "4"){
        [chLabel2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chLabel2 setStringValue:@"CH2:"];
        [chName2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chName2 setStringValue:@(colorName2.c_str())];
    }
    else if (colorNo2 == "5"){
        [chLabel2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chLabel2 setStringValue:@"CH2:"];
        [chName2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chName2 setStringValue:@(colorName2.c_str())];
    }
    else if (colorNo2 == "6"){
        [chLabel2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chLabel2 setStringValue:@"CH2:"];
        [chName2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chName2 setStringValue:@(colorName2.c_str())];
    }
    else if (colorNo2 == "7"){
        [chLabel2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chLabel2 setStringValue:@"CH2:"];
        [chName2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chName2 setStringValue:@(colorName2.c_str())];
    }
    else if (colorNo2 == "8"){
        [chLabel2 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chLabel2 setStringValue:@"CH2:"];
        [chName2 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chName2 setStringValue:@(colorName2.c_str())];
    }
    else if (colorNo2 == "9"){
        [chLabel2 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chLabel2 setStringValue:@"CH2:"];
        [chName2 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chName2 setStringValue:@(colorName2.c_str())];
    }
    
    int holdTemp = (int)(levelHold2*1000);
    double holdTempDouble = holdTemp/(double)1000;
    
    [chLevel2 setDoubleValue:holdTempDouble];
    
    holdTemp = (int)(cutHold2*1000);
    holdTempDouble = holdTemp/(double)1000;
    
    [chCut2 setDoubleValue:holdTempDouble];
    
    if (statusHold2 == 0){
        [chStatus2 setStringValue:@"Off"];
    }
    else [chStatus2 setStringValue:@"On"];
    
    [sliderKnobLevel2 setIntegerValue:(long)levelHold2];
    [sliderKnobCut2 setDoubleValue:cutHold2];
}

-(void)setCH3:(int)mode{
    if (mode == 0){
        colorFlag3 = 1;
        
        unsigned long findString = fileList [(filePosition-1)*7+3].find("tif");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+3].find("TIF");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+3].find("bmp");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+3].find("BMP");
        
        colorNo3 = fileList [(filePosition-1)*7+3].substr(13, 1);
        colorName3 = fileList [(filePosition-1)*7+3].substr(15, findString-16);
        
        string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+3];
        
        if (uploadTempStatusCl3 == 1) delete [] uploadTempCl3;
        
        uploadTempCl3 = new uint8_t [uploadTempFileSize+50];
        uploadTempStatusCl3 = 1;
        
        ifstream fin;
        
        fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
        
        fin.read((char*)uploadTempCl3, (long)uploadTempFileSize+1);
        fin.close();
    }
    
    if (colorNo3 == "1"){
        [chLabel3 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chLabel3 setStringValue:@"CH3:"];
        [chName3 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chName3 setStringValue:@(colorName3.c_str())];
    }
    else if (colorNo3 == "2"){
        [chLabel3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chLabel3 setStringValue:@"CH3:"];
        [chName3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chName3 setStringValue:@(colorName3.c_str())];
    }
    else if (colorNo3 == "3"){
        [chLabel3 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chLabel3 setStringValue:@"CH3:"];
        [chName3 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chName3 setStringValue:@(colorName3.c_str())];
    }
    else if (colorNo3 == "4"){
        [chLabel3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chLabel3 setStringValue:@"CH3:"];
        [chName3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chName3 setStringValue:@(colorName3.c_str())];
    }
    else if (colorNo3 == "5"){
        [chLabel3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chLabel3 setStringValue:@"CH3:"];
        [chName3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chName3 setStringValue:@(colorName3.c_str())];
    }
    else if (colorNo3 == "6"){
        [chLabel3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chLabel3 setStringValue:@"CH3:"];
        [chName3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chName3 setStringValue:@(colorName3.c_str())];
    }
    else if (colorNo3 == "7"){
        [chLabel3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chLabel3 setStringValue:@"CH3:"];
        [chName3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chName3 setStringValue:@(colorName3.c_str())];
    }
    else if (colorNo3 == "8"){
        [chLabel3 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chLabel3 setStringValue:@"CH3:"];
        [chName3 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chName3 setStringValue:@(colorName3.c_str())];
    }
    else if (colorNo3 == "9"){
        [chLabel3 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chLabel3 setStringValue:@"CH3:"];
        [chName3 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chName3 setStringValue:@(colorName3.c_str())];
    }
    
    int holdTemp = (int)(levelHold3*1000);
    double holdTempDouble = holdTemp/(double)1000;
    
    [chLevel3 setDoubleValue:holdTempDouble];
    
    holdTemp = (int)(cutHold3*1000);
    holdTempDouble = holdTemp/(double)1000;
    
    [chCut3 setDoubleValue:holdTempDouble];
    
    if (statusHold3 == 0){
        [chStatus3 setStringValue:@"Off"];
    }
    else [chStatus3 setStringValue:@"On"];
    
    [sliderKnobLevel3 setIntegerValue:(long)levelHold3];
    [sliderKnobCut3 setDoubleValue:cutHold3];
}

-(void)setCH4:(int)mode{
    if (mode == 0){
        colorFlag4 = 1;
        
        unsigned long findString = fileList [(filePosition-1)*7+4].find("tif");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+4].find("TIF");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+4].find("bmp");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+4].find("BMP");
        
        colorNo4 = fileList [(filePosition-1)*7+4].substr(13, 1);
        colorName4 = fileList [(filePosition-1)*7+4].substr(15, findString-16);
        
        string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+4];
        
        if (uploadTempStatusCl4 == 1) delete [] uploadTempCl4;
        
        uploadTempCl4 = new uint8_t [uploadTempFileSize+50];
        uploadTempStatusCl4 = 1;
        
        ifstream fin;
        
        fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
        
        fin.read((char*)uploadTempCl4, (long)uploadTempFileSize+1);
        fin.close();
    }
    
    if (colorNo4 == "1"){
        [chLabel4 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chLabel4 setStringValue:@"CH4:"];
        [chName4 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chName4 setStringValue:@(colorName4.c_str())];
    }
    else if (colorNo4 == "2"){
        [chLabel4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chLabel4 setStringValue:@"CH4:"];
        [chName4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chName4 setStringValue:@(colorName4.c_str())];
    }
    else if (colorNo4 == "3"){
        [chLabel4 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chLabel4 setStringValue:@"CH4:"];
        [chName4 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chName4 setStringValue:@(colorName4.c_str())];
    }
    else if (colorNo4 == "4"){
        [chLabel4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chLabel4 setStringValue:@"CH4:"];
        [chName4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chName4 setStringValue:@(colorName4.c_str())];
    }
    else if (colorNo4 == "5"){
        [chLabel4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chLabel4 setStringValue:@"CH4:"];
        [chName4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chName4 setStringValue:@(colorName4.c_str())];
    }
    else if (colorNo4 == "6"){
        [chLabel4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chLabel4 setStringValue:@"CH4:"];
        [chName4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chName4 setStringValue:@(colorName4.c_str())];
    }
    else if (colorNo4 == "7"){
        [chLabel4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chLabel4 setStringValue:@"CH4:"];
        [chName4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chName4 setStringValue:@(colorName4.c_str())];
    }
    else if (colorNo4 == "8"){
        [chLabel4 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chLabel4 setStringValue:@"CH4:"];
        [chName4 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chName4 setStringValue:@(colorName4.c_str())];
    }
    else if (colorNo4 == "9"){
        [chLabel4 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chLabel4 setStringValue:@"CH4:"];
        [chName4 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chName4 setStringValue:@(colorName4.c_str())];
    }
    
    int holdTemp = (int)(levelHold4*1000);
    double holdTempDouble = holdTemp/(double)1000;
    
    [chLevel4 setDoubleValue:holdTempDouble];
    
    holdTemp = (int)(cutHold4*1000);
    holdTempDouble = holdTemp/(double)1000;
    
    [chCut4 setDoubleValue:holdTempDouble];
    
    if (statusHold4 == 0){
        [chStatus4 setStringValue:@"Off"];
    }
    else [chStatus4 setStringValue:@"On"];
    
    [sliderKnobLevel4 setIntegerValue:(long)levelHold4];
    [sliderKnobCut4 setDoubleValue:cutHold4];
}

-(void)setCH5:(int)mode{
    if (mode == 0){
        colorFlag5 = 1;
        
        unsigned long findString = fileList [(filePosition-1)*7+5].find("tif");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+5].find("TIF");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+5].find("bmp");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+5].find("BMP");
        
        colorNo5 = fileList [(filePosition-1)*7+5].substr(13, 1);
        colorName5 = fileList [(filePosition-1)*7+5].substr(15, findString-16);
        
        string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+5];
        
        if (uploadTempStatusCl5 == 1) delete [] uploadTempCl5;
        
        uploadTempCl5 = new uint8_t [uploadTempFileSize+50];
        uploadTempStatusCl5 = 1;
        
        ifstream fin;
        
        fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
        
        fin.read((char*)uploadTempCl5, (long)uploadTempFileSize+1);
        fin.close();
    }
    
    if (colorNo5 == "1"){
        [chLabel5 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chLabel5 setStringValue:@"CH5:"];
        [chName5 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chName5 setStringValue:@(colorName5.c_str())];
    }
    else if (colorNo5 == "2"){
        [chLabel5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chLabel5 setStringValue:@"CH5:"];
        [chName5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chName5 setStringValue:@(colorName5.c_str())];
    }
    else if (colorNo5 == "3"){
        [chLabel5 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chLabel5 setStringValue:@"CH5:"];
        [chName5 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chName5 setStringValue:@(colorName5.c_str())];
    }
    else if (colorNo5 == "4"){
        [chLabel5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chLabel5 setStringValue:@"CH5:"];
        [chName5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chName5 setStringValue:@(colorName5.c_str())];
    }
    else if (colorNo5 == "5"){
        [chLabel5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chLabel5 setStringValue:@"CH5:"];
        [chName5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chName5 setStringValue:@(colorName5.c_str())];
    }
    else if (colorNo5 == "6"){
        [chLabel5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chLabel5 setStringValue:@"CH5:"];
        [chName5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chName5 setStringValue:@(colorName5.c_str())];
    }
    else if (colorNo5 == "7"){
        [chLabel5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chLabel5 setStringValue:@"CH5:"];
        [chName5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chName5 setStringValue:@(colorName5.c_str())];
    }
    else if (colorNo5 == "8"){
        [chLabel5 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chLabel5 setStringValue:@"CH5:"];
        [chName5 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chName5 setStringValue:@(colorName5.c_str())];
    }
    else if (colorNo5 == "9"){
        [chLabel5 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chLabel5 setStringValue:@"CH5:"];
        [chName5 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chName5 setStringValue:@(colorName5.c_str())];
    }
    
    int holdTemp = (int)(levelHold5*1000);
    double holdTempDouble = holdTemp/(double)1000;
    
    [chLevel5 setDoubleValue:holdTempDouble];
    
    holdTemp = (int)(cutHold5*1000);
    holdTempDouble = holdTemp/(double)1000;
    
    [chCut5 setDoubleValue:holdTempDouble];
    
    if (statusHold5 == 0){
        [chStatus5 setStringValue:@"Off"];
    }
    else [chStatus5 setStringValue:@"On"];
    
    [sliderKnobLevel5 setIntegerValue:(long)levelHold5];
    [sliderKnobCut5 setDoubleValue:cutHold5];
}

-(void)setCH6:(int)mode{
    if (mode == 0){
        colorFlag6 = 1;
        
        unsigned long findString = fileList [(filePosition-1)*7+6].find("tif");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+6].find("TIF");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+6].find("bmp");
        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+6].find("BMP");
        
        colorNo6 = fileList [(filePosition-1)*7+6].substr(13, 1);
        colorName6 = fileList [(filePosition-1)*7+6].substr(15, findString-16);
        
        string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+6];
        
        if (uploadTempStatusCl6 == 1) delete [] uploadTempCl6;
        
        uploadTempCl6 = new uint8_t [uploadTempFileSize+50];
        uploadTempStatusCl6 = 1;
        
        ifstream fin;
        
        fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
        
        fin.read((char*)uploadTempCl6, (long)uploadTempFileSize+1);
        fin.close();
    }
    
    if (colorNo6 == "1"){
        [chLabel6 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chLabel6 setStringValue:@"CH6:"];
        [chName6 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
        [chName6 setStringValue:@(colorName6.c_str())];
    }
    else if (colorNo6 == "2"){
        [chLabel6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chLabel6 setStringValue:@"CH6:"];
        [chName6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
        [chName6 setStringValue:@(colorName6.c_str())];
    }
    else if (colorNo6 == "3"){
        [chLabel6 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chLabel6 setStringValue:@"CH6:"];
        [chName6 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
        [chName6 setStringValue:@(colorName6.c_str())];
    }
    else if (colorNo6 == "4"){
        [chLabel6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chLabel6 setStringValue:@"CH6:"];
        [chName6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
        [chName6 setStringValue:@(colorName6.c_str())];
    }
    else if (colorNo6 == "5"){
        [chLabel6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chLabel6 setStringValue:@"CH6:"];
        [chName6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
        [chName6 setStringValue:@(colorName6.c_str())];
    }
    else if (colorNo6 == "6"){
        [chLabel6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chLabel6 setStringValue:@"CH6:"];
        [chName6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
        [chName6 setStringValue:@(colorName6.c_str())];
    }
    else if (colorNo6 == "7"){
        [chLabel6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chLabel6 setStringValue:@"CH6:"];
        [chName6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
        [chName6 setStringValue:@(colorName6.c_str())];
    }
    else if (colorNo6 == "8"){
        [chLabel6 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chLabel6 setStringValue:@"CH6:"];
        [chName6 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
        [chName6 setStringValue:@(colorName6.c_str())];
    }
    else if (colorNo6 == "9"){
        [chLabel6 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chLabel6 setStringValue:@"CH6:"];
        [chName6 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
        [chName6 setStringValue:@(colorName6.c_str())];
    }
    
    int holdTemp = (int)(levelHold6*1000);
    double holdTempDouble = holdTemp/(double)1000;
    
    [chLevel6 setDoubleValue:holdTempDouble];
    
    holdTemp = (int)(cutHold6*1000);
    holdTempDouble = holdTemp/(double)1000;
    
    [chCut6 setDoubleValue:holdTempDouble];
    
    if (statusHold6 == 0){
        [chStatus6 setStringValue:@"Off"];
    }
    else [chStatus6 setStringValue:@"On"];
    
    [sliderKnobLevel6 setIntegerValue:(long)levelHold6];
    [sliderKnobCut6 setDoubleValue:cutHold6];
}

-(IBAction)chSet1:(id)sender{
    if (colorFlag1 == 1){
        if (statusHold1 == 0){
            statusHold1 = 1;
            [chStatus1 setStringValue:@"On"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        else if (statusHold1 == 1){
            statusHold1 = 0;
            [chStatus1 setStringValue:@"Off"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)chSet2:(id)sender{
    if (colorFlag2 == 1){
        if (statusHold2 == 0){
            statusHold2 = 1;
            [chStatus2 setStringValue:@"On"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        else if (statusHold2 == 1){
            statusHold2 = 0;
            [chStatus2 setStringValue:@"Off"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)chSet3:(id)sender{
    if (colorFlag3 == 1){
        if (statusHold3 == 0){
            statusHold3 = 1;
            [chStatus3 setStringValue:@"On"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        else if (statusHold3 == 1){
            statusHold3 = 0;
            [chStatus3 setStringValue:@"Off"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)chSet4:(id)sender{
    if (colorFlag4 == 1){
        if (statusHold4 == 0){
            statusHold4 = 1;
            [chStatus4 setStringValue:@"On"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        else if (statusHold4 == 1){
            statusHold4 = 0;
            [chStatus4 setStringValue:@"Off"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)chSet5:(id)sender{
    if (colorFlag5 == 1){
        if (statusHold5 == 0){
            statusHold5 = 1;
            [chStatus5 setStringValue:@"On"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        else if (statusHold5 == 1){
            statusHold5 = 0;
            [chStatus5 setStringValue:@"Off"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)chSet6:(id)sender{
    if (colorFlag6 == 1){
        if (statusHold6 == 0){
            statusHold6 = 1;
            [chStatus6 setStringValue:@"On"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        else if (statusHold6 == 1){
            statusHold6 = 0;
            [chStatus6 setStringValue:@"Off"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderLevelCH1:(id)sender{
    if (colorFlag1 == 1){
        levelHold1 = [sliderLevel1 doubleValue];
        
        int holdTemp = (int)(levelHold1*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chLevel1 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderLevelCH2:(id)sender{
    if (colorFlag2 == 1){
        levelHold2 = [sliderLevel2 doubleValue];
        
        int holdTemp = (int)(levelHold2*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chLevel2 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderLevelCH3:(id)sender{
    if (colorFlag3 == 1){
        levelHold3 = [sliderLevel3 doubleValue];
        
        int holdTemp = (int)(levelHold3*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chLevel3 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderLevelCH4:(id)sender{
    if (colorFlag4 == 1){
        levelHold4 = [sliderLevel4 doubleValue];
        
        int holdTemp = (int)(levelHold4*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chLevel4 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderLevelCH5:(id)sender{
    if (colorFlag5 == 1){
        levelHold5 = [sliderLevel5 doubleValue];
        
        int holdTemp = (int)(levelHold5*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chLevel5 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderLevelCH6:(id)sender{
    if (colorFlag6 == 1){
        levelHold6 = [sliderLevel6 doubleValue];
        
        int holdTemp = (int)(levelHold6*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chLevel6 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderCutCH1:(id)sender{
    if (colorFlag1 == 1){
        cutHold1 = [sliderCut1 doubleValue];
        
        int holdTemp = (int)(cutHold1*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chCut1 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderCutCH2:(id)sender{
    if (colorFlag2 == 1){
        cutHold2 = [sliderCut2 doubleValue];
        
        int holdTemp = (int)(cutHold2*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chCut2 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderCutCH3:(id)sender{
    if (colorFlag3 == 1){
        cutHold3 = [sliderCut3 doubleValue];
        
        int holdTemp = (int)(cutHold3*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chCut3 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderCutCH4:(id)sender{
    if (colorFlag4 == 1){
        cutHold4 = [sliderCut4 doubleValue];
        
        int holdTemp = (int)(cutHold4*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chCut4 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderCutCH5:(id)sender{
    if (colorFlag5 == 1){
        cutHold5 = [sliderCut5 doubleValue];
        
        int holdTemp = (int)(cutHold5*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chCut5 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderCutCH6:(id)sender{
    if (colorFlag6 == 1){
        cutHold6 = [sliderCut6 doubleValue];
        
        int holdTemp = (int)(cutHold6*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chCut6 setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderLevelDIC:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        levelHoldDIC = [sliderLevelDIC doubleValue];
        
        int holdTemp = (int)(levelHoldDIC*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chLevelDIC setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderCutDIC:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        cutHoldDIC = [sliderCutDIC doubleValue];
        
        int holdTemp = (int)(cutHoldDIC*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chCutDIC setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderLevelR:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        levelHoldR = [sliderLevelR doubleValue];
        
        int holdTemp = (int)(levelHoldR*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chLevelR setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderLevelG:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        levelHoldG = [sliderLevelG doubleValue];
        
        int holdTemp = (int)(levelHoldG*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chLevelG setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderLevelB:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        levelHoldB = [sliderLevelB doubleValue];
        
        int holdTemp = (int)(levelHoldB*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [chLevelB setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)dicImageSelect:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        if (statusHoldDIC == 0){
            statusHoldDIC = 1;
            
            string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7];
            
            if (statusHoldDIC == 1){
                if (filePosition > lastDICImageTime) imageMoviePath = imageDisplayPath+"/"+fileList [(lastDICImageTime-1)*7];
            }
            
            ifstream fin;
            fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
            
            fin.read((char*)uploadTemp, (long)uploadTempFileSize+1);
            fin.close();
            
            [chDICImage setStringValue:@"Last Live"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        else if (statusHoldDIC == 1){
            statusHoldDIC = 0;
            
            string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7];
            
            if (statusHoldDIC == 1){
                if (filePosition > lastDICImageTime) imageMoviePath = imageDisplayPath+"/"+fileList [(lastDICImageTime-1)*7];
            }
            
            ifstream fin;
            fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
            
            fin.read((char*)uploadTemp, (long)uploadTempFileSize+1);
            fin.close();
            
            [chDICImage setStringValue:@"IF Image"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)sliderLevelCHCircle1:(id)sender{
    if (colorFlag1 == 1){
        double sliderCircleValue = sliderFluorescentCHMax1*[sliderLevelCircle1 doubleValue];
        double sliderCircleValue2 = sliderFluorescentCHMin1/[sliderLevelCircle1 doubleValue];
        double sliderValue = [sliderLevel1 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderFluorescentCHDiff1;
        
        sliderCircleValue = sliderValue+(sliderFluorescentCHMax1-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderFluorescentCHMin1)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderLevel1 setMaxValue:sliderCircleValue];
        [sliderLevel1 setMinValue:sliderCircleValue2];
        
        int fluorescentEnhanceInt = (int)([sliderLevel1 doubleValue]*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chLevel1 setDoubleValue:fluorescentEnhanceDouble];
    }
}

-(IBAction)sliderLevelCHCircle2:(id)sender{
    if (colorFlag2 == 1){
        double sliderCircleValue = sliderFluorescentCHMax2*[sliderLevelCircle2 doubleValue];
        double sliderCircleValue2 = sliderFluorescentCHMin2/[sliderLevelCircle2 doubleValue];
        double sliderValue = [sliderLevel2 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderFluorescentCHDiff2;
        
        sliderCircleValue = sliderValue+(sliderFluorescentCHMax2-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderFluorescentCHMin2)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderLevel2 setMaxValue:sliderCircleValue];
        [sliderLevel2 setMinValue:sliderCircleValue2];
        
        int fluorescentEnhanceInt = (int)([sliderLevel2 doubleValue]*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chLevel2 setDoubleValue:fluorescentEnhanceDouble];
    }
}

-(IBAction)sliderLevelCHCircle3:(id)sender{
    if (colorFlag3 == 1){
        double sliderCircleValue = sliderFluorescentCHMax3*[sliderLevelCircle3 doubleValue];
        double sliderCircleValue2 = sliderFluorescentCHMin3/[sliderLevelCircle3 doubleValue];
        double sliderValue = [sliderLevel3 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderFluorescentCHDiff3;
        
        sliderCircleValue = sliderValue+(sliderFluorescentCHMax3-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderFluorescentCHMin3)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderLevel3 setMaxValue:sliderCircleValue];
        [sliderLevel3 setMinValue:sliderCircleValue2];
        
        int fluorescentEnhanceInt = (int)([sliderLevel3 doubleValue]*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chLevel3 setDoubleValue:fluorescentEnhanceDouble];
    }
}

-(IBAction)sliderLevelCHCircle4:(id)sender{
    if (colorFlag4 == 1){
        double sliderCircleValue = sliderFluorescentCHMax4*[sliderLevelCircle4 doubleValue];
        double sliderCircleValue2 = sliderFluorescentCHMin4/[sliderLevelCircle4 doubleValue];
        double sliderValue = [sliderLevel4 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderFluorescentCHDiff4;
        
        sliderCircleValue = sliderValue+(sliderFluorescentCHMax4-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderFluorescentCHMin4)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderLevel4 setMaxValue:sliderCircleValue];
        [sliderLevel4 setMinValue:sliderCircleValue2];
        
        int fluorescentEnhanceInt = (int)([sliderLevel4 doubleValue]*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chLevel4 setDoubleValue:fluorescentEnhanceDouble];
    }
}

-(IBAction)sliderLevelCHCircle5:(id)sender{
    if (colorFlag5 == 1){
        double sliderCircleValue = sliderFluorescentCHMax5*[sliderLevelCircle5 doubleValue];
        double sliderCircleValue2 = sliderFluorescentCHMin5/[sliderLevelCircle5 doubleValue];
        double sliderValue = [sliderLevel5 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderFluorescentCHDiff5;
        
        sliderCircleValue = sliderValue+(sliderFluorescentCHMax5-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderFluorescentCHMin5)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderLevel5 setMaxValue:sliderCircleValue];
        [sliderLevel5 setMinValue:sliderCircleValue2];
        
        int fluorescentEnhanceInt = (int)([sliderLevel5 doubleValue]*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chLevel5 setDoubleValue:fluorescentEnhanceDouble];
    }
}

-(IBAction)sliderLevelCHCircle6:(id)sender{
    if (colorFlag6 == 1){
        double sliderCircleValue = sliderFluorescentCHMax6*[sliderLevelCircle6 doubleValue];
        double sliderCircleValue2 = sliderFluorescentCHMin6/[sliderLevelCircle6 doubleValue];
        double sliderValue = [sliderLevel6 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderFluorescentCHDiff6;
        
        sliderCircleValue = sliderValue+(sliderFluorescentCHMax6-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderFluorescentCHMin6)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderLevel6 setMaxValue:sliderCircleValue];
        [sliderLevel6 setMinValue:sliderCircleValue2];
        
        int fluorescentEnhanceInt = (int)([sliderLevel6 doubleValue]*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chLevel6 setDoubleValue:fluorescentEnhanceDouble];
    }
}

-(IBAction)sliderCutCHCircle1:(id)sender{
    if (colorFlag1 == 1){
        double sliderCircleValue = sliderCutCHMax1*[sliderCutCircle1 doubleValue];
        double sliderCircleValue2 = sliderCutCHMin1/[sliderCutCircle1 doubleValue];
        double sliderValue = [sliderCut1 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderCutCHDiff1;
        
        sliderCircleValue = sliderValue+(sliderCutCHMax1-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderCutCHMin1)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderCut1 setMaxValue:sliderCircleValue];
        [sliderCut1 setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderCut1 doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chCut1 setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderCutCHCircle2:(id)sender{
    if (colorFlag2 == 1){
        double sliderCircleValue = sliderCutCHMax2*[sliderCutCircle2 doubleValue];
        double sliderCircleValue2 = sliderCutCHMin2/[sliderCutCircle2 doubleValue];
        double sliderValue = [sliderCut2 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderCutCHDiff2;
        
        sliderCircleValue = sliderValue+(sliderCutCHMax2-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderCutCHMin2)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderCut2 setMaxValue:sliderCircleValue];
        [sliderCut2 setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderCut2 doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chCut2 setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderCutCHCircle3:(id)sender{
    if (colorFlag3 == 1){
        double sliderCircleValue = sliderCutCHMax3*[sliderCutCircle3 doubleValue];
        double sliderCircleValue2 = sliderCutCHMin3/[sliderCutCircle3 doubleValue];
        double sliderValue = [sliderCut3 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderCutCHDiff3;
        
        sliderCircleValue = sliderValue+(sliderCutCHMax3-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderCutCHMin3)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderCut3 setMaxValue:sliderCircleValue];
        [sliderCut3 setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderCut3 doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chCut3 setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderCutCHCircle4:(id)sender{
    if (colorFlag4 == 1){
        double sliderCircleValue = sliderCutCHMax4*[sliderCutCircle4 doubleValue];
        double sliderCircleValue2 = sliderCutCHMin4/[sliderCutCircle4 doubleValue];
        double sliderValue = [sliderCut4 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderCutCHDiff4;
        
        sliderCircleValue = sliderValue+(sliderCutCHMax4-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderCutCHMin4)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderCut4 setMaxValue:sliderCircleValue];
        [sliderCut4 setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderCut4 doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chCut4 setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderCutCHCircle5:(id)sender{
    if (colorFlag5 == 1){
        double sliderCircleValue = sliderCutCHMax5*[sliderCutCircle5 doubleValue];
        double sliderCircleValue2 = sliderCutCHMin5/[sliderCutCircle5 doubleValue];
        double sliderValue = [sliderCut5 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderCutCHDiff5;
        
        sliderCircleValue = sliderValue+(sliderCutCHMax5-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderCutCHMin5)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderCut5 setMaxValue:sliderCircleValue];
        [sliderCut5 setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderCut5 doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chCut5 setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderCutCHCircle6:(id)sender{
    if (colorFlag6 == 1){
        double sliderCircleValue = sliderCutCHMax6*[sliderCutCircle6 doubleValue];
        double sliderCircleValue2 = sliderCutCHMin6/[sliderCutCircle6 doubleValue];
        double sliderValue = [sliderCut6 doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderCutCHDiff6;
        
        sliderCircleValue = sliderValue+(sliderCutCHMax6-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderCutCHMin6)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderCut6 setMaxValue:sliderCircleValue];
        [sliderCut6 setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderCut6 doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chCut6 setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderLevelDICCircle:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        double sliderCircleValue = sliderDICMax*[sliderLevelCircleDIC doubleValue];
        double sliderCircleValue2 = sliderDICMin/[sliderLevelCircleDIC doubleValue];
        double sliderValue = [sliderLevelDIC doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderDICDiff;
        
        sliderCircleValue = sliderValue+(sliderDICMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderDICMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderLevelDIC setMaxValue:sliderCircleValue];
        [sliderLevelDIC setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderLevelDIC doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chLevelDIC setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderCutDICCircle:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        double sliderCircleValue = sliderCutDICMax*[sliderCutCircleDIC doubleValue];
        double sliderCircleValue2 = sliderCutDICMin/[sliderCutCircleDIC doubleValue];
        double sliderValue = [sliderCutDIC doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderCutDICDiff;
        
        sliderCircleValue = sliderValue+(sliderCutDICMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderCutDICMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderCutDIC setMaxValue:sliderCircleValue];
        [sliderCutDIC setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderCutDIC doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chCutDIC setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderLevelRCircle:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        double sliderCircleValue = sliderRMax*[sliderLevelCircleR doubleValue];
        double sliderCircleValue2 = sliderRMin/[sliderLevelCircleR doubleValue];
        double sliderValue = [sliderLevelR doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderRDiff;
        
        sliderCircleValue = sliderValue+(sliderRMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderRMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderLevelR setMaxValue:sliderCircleValue];
        [sliderLevelR setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderLevelR doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chLevelR setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderLevelGCircle:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        double sliderCircleValue = sliderGMax*[sliderLevelCircleG doubleValue];
        double sliderCircleValue2 = sliderGMin/[sliderLevelCircleG doubleValue];
        double sliderValue = [sliderLevelG doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderGDiff;
        
        sliderCircleValue = sliderValue+(sliderGMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderGMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderLevelG setMaxValue:sliderCircleValue];
        [sliderLevelG setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderLevelG doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chLevelG setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)sliderLevelBCircle:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        double sliderCircleValue = sliderBMax*[sliderLevelCircleB doubleValue];
        double sliderCircleValue2 = sliderBMin/[sliderLevelCircleB doubleValue];
        double sliderValue = [sliderLevelB doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderBDiff;
        
        sliderCircleValue = sliderValue+(sliderBMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderBMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderLevelB setMaxValue:sliderCircleValue];
        [sliderLevelB setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderLevelB doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [chLevelB setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)resetCH1:(id)sender{
    if (colorFlag1 == 1){
        cutHold1 = 50;
        levelHold1 = 1;
        
        int baseCutInt = (int)(cutHold1*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        int fluorescentEnhanceInt = (int)(levelHold1*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chCut1 setDoubleValue:baseCutDouble];
        [chLevel1 setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderLevel1 setDoubleValue:1];
        [sliderCut1 setDoubleValue:50];
        [sliderLevelCircle1 setDoubleValue:1];
        [sliderCutCircle1 setDoubleValue:1];
        
        [sliderLevel1 setMaxValue:sliderFluorescentCHMax1];
        [sliderLevel1 setMinValue:sliderFluorescentCHMin1];
        
        [sliderCut1 setMaxValue:sliderCutCHMax1];
        [sliderCut1 setMinValue:sliderCutCHMin1];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetCH2:(id)sender{
    if (colorFlag2 == 1){
        cutHold2 = 50;
        levelHold2 = 1;
        
        int baseCutInt = (int)(cutHold2*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        int fluorescentEnhanceInt = (int)(levelHold2*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chCut2 setDoubleValue:baseCutDouble];
        [chLevel2 setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderLevel2 setDoubleValue:1];
        [sliderCut2 setDoubleValue:50];
        [sliderLevelCircle2 setDoubleValue:1];
        [sliderCutCircle2 setDoubleValue:1];
        
        [sliderLevel2 setMaxValue:sliderFluorescentCHMax2];
        [sliderLevel2 setMinValue:sliderFluorescentCHMin2];
        
        [sliderCut2 setMaxValue:sliderCutCHMax2];
        [sliderCut2 setMinValue:sliderCutCHMin2];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetCH3:(id)sender{
    if (colorFlag3 == 1){
        cutHold3 = 50;
        levelHold3 = 1;
        
        int baseCutInt = (int)(cutHold3*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        int fluorescentEnhanceInt = (int)(levelHold3*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chCut3 setDoubleValue:baseCutDouble];
        [chLevel3 setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderLevel3 setDoubleValue:1];
        [sliderCut3 setDoubleValue:50];
        [sliderLevelCircle3 setDoubleValue:1];
        [sliderCutCircle3 setDoubleValue:1];
        
        [sliderLevel3 setMaxValue:sliderFluorescentCHMax3];
        [sliderLevel3 setMinValue:sliderFluorescentCHMin3];
        
        [sliderCut3 setMaxValue:sliderCutCHMax3];
        [sliderCut3 setMinValue:sliderCutCHMin3];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetCH4:(id)sender{
    if (colorFlag4 == 1){
        cutHold4 = 50;
        levelHold4 = 1;
        
        int baseCutInt = (int)(cutHold4*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        int fluorescentEnhanceInt = (int)(levelHold4*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chCut4 setDoubleValue:baseCutDouble];
        [chLevel4 setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderLevel4 setDoubleValue:1];
        [sliderCut4 setDoubleValue:50];
        [sliderLevelCircle4 setDoubleValue:1];
        [sliderCutCircle4 setDoubleValue:1];
        
        [sliderLevel4 setMaxValue:sliderFluorescentCHMax4];
        [sliderLevel4 setMinValue:sliderFluorescentCHMin4];
        
        [sliderCut4 setMaxValue:sliderCutCHMax4];
        [sliderCut4 setMinValue:sliderCutCHMin4];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetCH5:(id)sender{
    if (colorFlag5 == 1){
        cutHold5 = 50;
        levelHold5 = 1;
        
        int baseCutInt = (int)(cutHold5*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        int fluorescentEnhanceInt = (int)(levelHold5*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chCut5 setDoubleValue:baseCutDouble];
        [chLevel5 setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderLevel5 setDoubleValue:1];
        [sliderCut5 setDoubleValue:50];
        [sliderLevelCircle5 setDoubleValue:1];
        [sliderCutCircle5 setDoubleValue:1];
        
        [sliderLevel5 setMaxValue:sliderFluorescentCHMax5];
        [sliderLevel5 setMinValue:sliderFluorescentCHMin5];
        
        [sliderCut5 setMaxValue:sliderCutCHMax5];
        [sliderCut5 setMinValue:sliderCutCHMin5];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetCH6:(id)sender{
    if (colorFlag6 == 1){
        cutHold6 = 50;
        levelHold6 = 1;
        
        int baseCutInt = (int)(cutHold6*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        int fluorescentEnhanceInt = (int)(levelHold6*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chCut6 setDoubleValue:baseCutDouble];
        [chLevel6 setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderLevel6 setDoubleValue:1];
        [sliderCut6 setDoubleValue:50];
        [sliderLevelCircle6 setDoubleValue:1];
        [sliderCutCircle6 setDoubleValue:1];
        
        [sliderLevel6 setMaxValue:sliderFluorescentCHMax6];
        [sliderLevel6 setMinValue:sliderFluorescentCHMin6];
        
        [sliderCut6 setMaxValue:sliderCutCHMax6];
        [sliderCut6 setMinValue:sliderCutCHMin6];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetDIC:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        cutHoldDIC = 0;
        levelHoldDIC = 1;
        
        int baseCutInt = (int)(cutHoldDIC*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        int fluorescentEnhanceInt = (int)(levelHoldDIC*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chCutDIC setDoubleValue:baseCutDouble];
        [chLevelDIC setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderLevelDIC setDoubleValue:1];
        [sliderCutDIC setDoubleValue:50];
        [sliderLevelCircleDIC setDoubleValue:1];
        [sliderCutCircleDIC setDoubleValue:1];
        
        [sliderLevelDIC setMaxValue:sliderDICMax];
        [sliderLevelDIC setMinValue:sliderDICMin];
        
        [sliderCutDIC setMaxValue:sliderCutDICMax];
        [sliderCutDIC setMinValue:sliderCutDICMin];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetR:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        levelHoldR = 1;
        
        int fluorescentEnhanceInt = (int)(levelHoldR*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chLevelR setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderLevelR setDoubleValue:1];
        [sliderLevelCircleR setDoubleValue:1];
        
        [sliderLevelR setMaxValue:sliderRMax];
        [sliderLevelR setMinValue:sliderRMin];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetG:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        levelHoldG = 1;
        
        int fluorescentEnhanceInt = (int)(levelHoldG*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chLevelG setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderLevelG setDoubleValue:1];
        [sliderLevelCircleG setDoubleValue:1];
        
        [sliderLevelG setMaxValue:sliderGMax];
        [sliderLevelG setMinValue:sliderGMin];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetB:(id)sender{
    if (imageXYLength != 0 && movieRunningFlag == 0){
        levelHoldB = 1;
        
        int fluorescentEnhanceInt = (int)(levelHoldB*1000);
        double fluorescentEnhanceDouble = fluorescentEnhanceInt/(double)1000;
        
        [chLevelB setDoubleValue:fluorescentEnhanceDouble];
        
        [sliderLevelB setDoubleValue:1];
        [sliderLevelCircleB setDoubleValue:1];
        
        [sliderLevelB setMaxValue:sliderBMax];
        [sliderLevelB setMinValue:sliderBMin];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)imageLoadStart:(id)sender{
    if (copyProgressFlag == 0){
        if (movieRunningFlag == 0){
            NSOpenPanel *openDlg = [NSOpenPanel openPanel];
            [openDlg setCanChooseFiles:NO];
            [openDlg setCanChooseDirectories:YES];
            [openDlg setCanCreateDirectories:YES];
            
            if ([openDlg runModal] == NSModalResponseOK){
                NSArray *files = [openDlg URLs];
                NSString *fileName = [[files objectAtIndex:0] absoluteString];
                
                string directoryPathExtract = [fileName UTF8String];
                string fileLoadPath = "nil";
                
                int folderSet = 0;
                
                if ((int)directoryPathExtract.find("/Volumes/") != -1){
                    unsigned long directoryLength = directoryPathExtract.length();
                    string extreactedID = directoryPathExtract.substr(directoryPathExtract.find("/Volumes/"), directoryLength-directoryPathExtract.find("/Volumes/")-1);
                    string extreactedID2;
                    
                    int terminationFlag = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        if ((int)extreactedID.find("%20") != -1){
                            extreactedID2 = extreactedID.substr(0, extreactedID.find("%20"));
                            extreactedID = extreactedID.substr(extreactedID.find("%20")+3);
                            extreactedID = extreactedID2+" "+extreactedID;
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    fileLoadPath = extreactedID;
                    folderSet = 1;
                }
                else if ((int)directoryPathExtract.find("/Users/") != -1){
                    unsigned long directoryLength = directoryPathExtract.length();
                    string extreactedID = directoryPathExtract.substr(directoryPathExtract.find("/Users/"), directoryLength-directoryPathExtract.find("/Users/")-1);
                    string extreactedID2;
                    
                    int terminationFlag = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        if ((int)extreactedID.find("%20") != -1){
                            extreactedID2 = extreactedID.substr(0, extreactedID.find("%20"));
                            extreactedID = extreactedID.substr(extreactedID.find("%20")+3);
                            extreactedID = extreactedID2+" "+extreactedID;
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    fileLoadPath = extreactedID;
                    folderSet = 1;
                }
                
                if (folderSet == 1){
                    DIR *dir;
                    struct dirent *dent;
                    
                    dir = opendir(fileLoadPath.c_str());
                    
                    unsigned long totalFileSize = 0;
                    int fileReadNoCount = 0;
                    struct stat sizeOfFile;
                    
                    if (dir != NULL){
                        string entry;
                        string pathName2;
                        
                        long sizeForCopy = 0;
                        
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            pathName2 = fileLoadPath+"/"+entry;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store" && ((int)entry.find(".TIFF") != -1 || (int)entry.find(".Tiff") != -1 || (int)entry.find(".tiff") != -1 || (int)entry.find(".TIF") != -1 || (int)entry.find(".Tif") != -1 || (int)entry.find(".tif") != -1)){
                                fileReadNoCount++;
                                
                                if (stat(pathName2.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                                }
                            }
                        }
                        
                        closedir(dir);
                        
                        NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(pathName2.c_str()) error:nil];
                        unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
                        unsigned long refSize = (unsigned long)totalFileSize+1048576000; //----1Gb-----
                        
                        if (totalFileSize != 0 && freeSize > refSize){
                            int startNo = [imageLoadDisplayStart intValue];
                            
                            if (startNo <= 0){
                                startNo = 1;
                                [imageLoadDisplayStart setStringValue:@"1"];
                            }
                            
                            copyProgressFlag = 1;
                            
                            string inputdata = [[imageLoadDisplayID stringValue] UTF8String];
                            
                            string *fileNameList  = new string [fileReadNoCount+10];
                            string extension;
                            
                            fileReadNoCount = 0;
                            
                            dir = opendir(fileLoadPath.c_str());
                            
                            if (dir != NULL){
                                while((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    pathName2 = fileLoadPath+"/"+entry;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store" && ((int)entry.find(".TIFF") != -1 || (int)entry.find(".Tiff") != -1 || (int)entry.find(".tiff") != -1 || (int)entry.find(".TIF") != -1 || (int)entry.find(".Tif") != -1 || (int)entry.find(".tif") != -1)){
                                        if ((int)entry.find(".TIFF") != -1) extension = ".TIFF";
                                        else if ((int)entry.find(".tiff") != -1) extension = ".tiff";
                                        else if ((int)entry.find(".TIF") != -1) extension = ".TIF";
                                        else if ((int)entry.find(".Tif") != -1) extension = ".Tif";
                                        else if ((int)entry.find(".tif") != -1) extension = ".tif";
                                        
                                        if ((int)entry.find(inputdata) != -1){
                                            if (atoi(entry.substr(entry.find(inputdata)+inputdata.length(), entry.find(extension)-(entry.find(inputdata)+inputdata.length())+1).c_str()) >= startNo){
                                                fileNameList [fileReadNoCount] = entry, fileReadNoCount++;
                                            }
                                        }
                                    }
                                }
                                
                                closedir(dir);
                                
                                if (fileReadNoCount != 0){
                                    string extractString;
                                    int maxEntryNo = 0;
                                    
                                    dir = opendir(imageDataPath.c_str());
                                    
                                    if (dir != NULL){
                                        while ((dent = readdir(dir))){
                                            entry = dent -> d_name;
                                            
                                            if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("ImportImage") != -1){
                                                if (entry.substr(11, 1) == "_"){
                                                    if (maxEntryNo == 0) maxEntryNo = 1;
                                                }
                                                else extractString = entry.substr(11, entry.find("_Image")-11);
                                                
                                                if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                                            }
                                        }
                                        
                                        closedir(dir);
                                    }
                                    
                                    maxEntryNo++;
                                    
                                    string resultSavePath;
                                    
                                    if (maxEntryNo == 1){
                                        resultSavePath = imageDataPath+"/ImportImage_Image";
                                        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                    }
                                    else{
                                        
                                        resultSavePath = imageDataPath+"/ImportImage"+to_string(maxEntryNo)+"_Image";
                                        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                    }
                                    
                                    string resultSavePath2 = resultSavePath+"/ImportImage_Stitch";
                                    mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                    
                                    unsigned long stripFirstAddress = 0;
                                    unsigned long stripByteCountAddress = 0;
                                    unsigned long nextAddress = 0;
                                    unsigned long headPosition = 0;
                                    unsigned long stripEntry = 0;
                                    
                                    double xPosition = 0;
                                    double yPosition = 0;
                                    
                                    int imageWidth = 0;
                                    int imageHeight = 0;
                                    int imageBit = 0; // Check 8, 16
                                    int imageCompression = 0; // Check 1
                                    int photoMetric = 0; //check 0, 1, 2
                                    int imageDimension = 0;
                                    int dimensionAddition = 0;
                                    int verticalBmp = 0;
                                    int horizontalBmp = 0;
                                    int horizontalBmpEntry = 0;
                                    int newImageDimension = 0;
                                    int endianType = 0;
                                    int samplePerPix = 0;
                                    int dataConversion [4];
                                    int mode = 0;
                                    int processType = 1;
                                    int numberOfLayers = 0;
                                    
                                    string sourceFileName;
                                    string newFilePath;
                                    string tiffExtensionHold;
                                    string sliceString;
                                    string extension2;
                                    string processFileName;
                                    
                                    ifstream fin2;
                                    
                                    int fileNumberCount = startNo;
                                    int createFileCount = 1;
                                    
                                    for (int counter1 = 0; counter1 < fileReadNoCount; counter1++){
                                        processFileName = "nil";
                                        
                                        for (int counter2 = 0; counter2 < fileReadNoCount; counter2++){
                                            if ((int)fileNameList [counter2].find(".TIFF") != -1) extension = ".TIFF";
                                            else if ((int)fileNameList [counter2].find(".tiff") != -1) extension = ".tiff";
                                            else if ((int)fileNameList [counter2].find(".TIF") != -1) extension = ".TIF";
                                            else if ((int)fileNameList [counter2].find(".Tif") != -1) extension = ".Tif";
                                            else if ((int)fileNameList [counter2].find(".tif") != -1) extension = ".tif";
                                            
                                            if (atoi(fileNameList [counter2].substr(fileNameList [counter2].find(inputdata)+inputdata.length(), fileNameList [counter2].find(extension)-(fileNameList [counter2].find(inputdata)+inputdata.length())+1).c_str()) == fileNumberCount){
                                                
                                                processFileName = fileNameList [counter2];
                                                
                                                break;
                                            }
                                        }
                                        
                                        if (processFileName != "nil"){
                                            extension2 = to_string (createFileCount);
                                            
                                            if (extension2.length() == 1) extension2 = "000"+extension2;
                                            else if (extension2.length() == 2) extension2 = "00"+extension2;
                                            else if (extension2.length() == 3) extension2 = "0"+extension2;
                                            
                                            sourceFileName = fileLoadPath+"/"+processFileName;
                                            fileSavePathHold = resultSavePath2+"/"+"STimage "+extension2+".tif";
                                            
                                            //------File Read------
                                            if (stat(sourceFileName.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                                
                                                fileReadArray = new uint8_t [sizeForCopy+4];
                                                fin2.open(sourceFileName.c_str(), ios::in | ios::binary);
                                                
                                                fin2.read((char*)fileReadArray, sizeForCopy+4);
                                                fin2.close();
                                                
                                                dataConversion [0] = fileReadArray [0];
                                                dataConversion [1] = fileReadArray [1];
                                                
                                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                                else endianType = 0;
                                                
                                                int *arrayExtractedImage3 = new int [100];
                                                
                                                headPosition = 0;
                                                
                                                if (endianType == 1){
                                                    dataConversion [0] = fileReadArray [7];
                                                    dataConversion [1] = fileReadArray [6];
                                                    dataConversion [2] = fileReadArray [5];
                                                    dataConversion [3] = fileReadArray [4];
                                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                                }
                                                else if (endianType == 0){
                                                    dataConversion [0] = fileReadArray [4];
                                                    dataConversion [1] = fileReadArray [5];
                                                    dataConversion [2] = fileReadArray [6];
                                                    dataConversion [3] = fileReadArray [7];
                                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                                }
                                                
                                                imageDimension = 0;
                                                
                                                if (endianType == 1){
                                                    tiffFileRead = [[TiffFileRead alloc] init];
                                                    [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                                    
                                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3 && numberOfLayers == 1){
                                                        if (imageWidth > imageHeight) imageDimension = imageWidth;
                                                        else imageDimension = imageHeight;
                                                        
                                                        tiffFileRead = [[TiffFileRead alloc] init];
                                                        delete [] arrayExtractedImage3;
                                                        
                                                        arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                                    }
                                                }
                                                else if (endianType == 0){
                                                    tiffFileRead = [[TiffFileRead alloc] init];
                                                    [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                                    
                                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3 && numberOfLayers == 1){
                                                        if (imageWidth > imageHeight) imageDimension = imageWidth;
                                                        else imageDimension = imageHeight;
                                                        
                                                        tiffFileRead = [[TiffFileRead alloc] init];
                                                        delete [] arrayExtractedImage3;
                                                        
                                                        arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                                    }
                                                }
                                                
                                                if (imageDimension != 0){
                                                    dimensionAddition = imageDimension%4;
                                                    
                                                    if (dimensionAddition == 1) dimensionAddition = 3;
                                                    else if (dimensionAddition == 2) dimensionAddition = 2;
                                                    else if (dimensionAddition == 3) dimensionAddition = 1;
                                                    
                                                    newImageDimension = imageDimension+dimensionAddition;
                                                    
                                                    //-----Saved image-----
                                                    arrayImageFileSave = new int *[newImageDimension+1];
                                                    
                                                    for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                                                        arrayImageFileSave [counter3] = new int [newImageDimension*3+1];
                                                    }
                                                    
                                                    for (int counter3 = 0; counter3 < newImageDimension; counter3++){
                                                        for (int counter4 = 0; counter4 < newImageDimension*3; counter4++){
                                                            arrayImageFileSave [counter3][counter4] = 0;
                                                        }
                                                    }
                                                    
                                                    horizontalBmp = 0;
                                                    horizontalBmpEntry = 0;
                                                    verticalBmp = 0;
                                                    
                                                    for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                                        if (photoMetric == 1){
                                                            if (horizontalBmp < imageWidth){
                                                                arrayImageFileSave [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3], horizontalBmpEntry++;
                                                                horizontalBmp++;
                                                            }
                                                            
                                                            if (horizontalBmp == imageWidth){
                                                                if (imageWidth< newImageDimension){
                                                                    for (int counter4 = 0; counter4 < newImageDimension-imageWidth; counter4++){
                                                                        arrayImageFileSave [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                    }
                                                                }
                                                                
                                                                horizontalBmp = 0;
                                                                horizontalBmpEntry = 0;
                                                                verticalBmp++;
                                                            }
                                                        }
                                                        else if (photoMetric == 2){
                                                            if (horizontalBmp < imageWidth){
                                                                arrayImageFileSave [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3], horizontalBmpEntry++;
                                                                arrayImageFileSave [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3+1], horizontalBmpEntry++;
                                                                arrayImageFileSave [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3+2], horizontalBmpEntry++;
                                                                
                                                                horizontalBmp++;
                                                            }
                                                            
                                                            if (horizontalBmp == imageWidth){
                                                                if (imageWidth < newImageDimension){
                                                                    for (int counter4 = 0; counter4 < newImageDimension-imageWidth; counter4++){
                                                                        arrayImageFileSave [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                        arrayImageFileSave [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                        arrayImageFileSave [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                    }
                                                                }
                                                                
                                                                horizontalBmp = 0;
                                                                horizontalBmpEntry = 0;
                                                                verticalBmp++;
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (photoMetric == 1){
                                                        if (imageHeight < newImageDimension){
                                                            for (int counter3 = imageHeight; counter3 < newImageDimension; counter3++){
                                                                horizontalBmpEntry = 0;
                                                                
                                                                for (int counter4 = 0; counter4 < imageWidth; counter4++){
                                                                    arrayImageFileSave [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                }
                                                                
                                                                verticalBmp++;
                                                            }
                                                        }
                                                    }
                                                    else if (photoMetric == 2){
                                                        if (imageHeight < newImageDimension){
                                                            for (int counter3 = imageHeight; counter3 < newImageDimension; counter3++){
                                                                horizontalBmpEntry = 0;
                                                                
                                                                for (int counter4 = 0; counter4 < imageWidth; counter4++){
                                                                    arrayImageFileSave [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                    arrayImageFileSave [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                    arrayImageFileSave [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                }
                                                                
                                                                verticalBmp++;
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                if (xPosition == -1) xPosition = 100;
                                                if (yPosition == -1) yPosition = 100;
                                                
                                                singleTiffSave = [[SingleTiffSave alloc] init];
                                                [singleTiffSave singleTiffLayerSave:newImageDimension:newImageDimension:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:(unsigned long)mode];
                                                
                                                for (int counter3 = 0; counter3 < newImageDimension+1; counter3++){
                                                    delete [] arrayImageFileSave [counter3];
                                                }
                                                
                                                delete [] arrayImageFileSave;
                                                
                                                delete [] arrayExtractedImage3;
                                                
                                                createFileCount++;
                                                fileNumberCount++;
                                            }
                                            
                                            delete [] fileReadArray;
                                        }
                                    }
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                }
                                else{
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"ID-Matched Files Absent"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                            }
                            else{
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Directory Not Found"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                            
                            delete [] fileNameList;
                            
                            copyProgressFlag = 0;
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Disk Space Low"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Directory Not Found"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Directory Not Found"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Movie On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)directoryInfoUpDate{
    string *arrayUpDate = new string [directoryInfoCount+10];
    
    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++) arrayUpDate [counter1] = arrayDirectoryInfo [counter1];
    
    delete [] arrayDirectoryInfo;
    arrayDirectoryInfo = new string [directoryInfoLimit+500];
    directoryInfoLimit = directoryInfoLimit+500;
    
    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++) arrayDirectoryInfo [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    if (timerCD) [timerCD invalidate];
}

@end
