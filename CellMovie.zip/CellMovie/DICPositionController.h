//
//  DICPositionController.h
//  CellMovie
//
//  Created by Masahiko Sato on 11/22/16.
//
//

#ifndef DICPOSITIONCONTROLLER_H
#define DICPOSITIONCONTROLLER_H
#import "Controller.h"
#endif

@interface DICPositionController : NSObject <NSTextFieldDelegate>{
    int dicLiveStatus; //Hold DIC/Live selection
    int liveChSelect; //Fold Live Ch no
    int liveNoOfCh; //Fold Live No of Ch
    int nextImageLoad; //Flag for next image load
    int fileTypeTifBmp; //TIF BMP type
    int fileNumberCount; //Number of image file
    int dicContrastTo; //DIC contrast
    
    int liveFluorescentCH1; //Hold live CH no
    int liveFluorescentCH2; //Hold live CH no
    int liveFluorescentCH3; //Hold live CH no
    int liveFluorescentCH4; //Hold live CH no
    int liveFluorescentCH5; //Hold live CH no
    int liveFluorescentCH6; //Hold live CH no
    
    int progressTiming; //Process timing
    int progressTimingB; //Process timing
    int progressValue; //Value hold for progress bar
    
    double sliderDICMax; //Slider
    double sliderDICMin; //Slider
    double sliderDICDiff; //Slider
    double sliderDICBaseMax; //Slider
    double sliderDICBaseMin; //Slider
    double sliderDICBaseDiff; //Slider
    
    double sliderDICSourceMax; //Slider
    double sliderDICSourceMin; //Slider
    double sliderDICSourceDiff; //Slider
    double sliderDICBaseSourceMax; //Slider
    double sliderDICBaseSourceMin; //Slider
    double sliderDICBaseSourceDiff; //Slider
    
    IBOutlet NSTextField *moveStatusDiaplay;
    IBOutlet NSTextField *baseCutValueDisplay;
    IBOutlet NSTextField *dicValueDisplay;
    IBOutlet NSTextField *baseCutValueSourceDisplay;
    IBOutlet NSTextField *dicValueSourceDisplay;
    IBOutlet NSTextField *currentImageNoDiaplay;
    IBOutlet NSTextField *nextImageNoDisplay;
    IBOutlet NSTextField *chNameDisplay1;
    IBOutlet NSTextField *chNameDisplay2;
    IBOutlet NSTextField *chNameDisplay3;
    IBOutlet NSTextField *chNameDisplay4;
    IBOutlet NSTextField *chNameDisplay5;
    IBOutlet NSTextField *chNameDisplay6;
    IBOutlet NSTextField *chStatusDisplay1;
    IBOutlet NSTextField *chStatusDisplay2;
    IBOutlet NSTextField *chStatusDisplay3;
    IBOutlet NSTextField *chStatusDisplay4;
    IBOutlet NSTextField *chStatusDisplay5;
    IBOutlet NSTextField *chStatusDisplay6;
    IBOutlet NSTextField *dicLiveStatusDisplay;
    IBOutlet NSTextField *copyFolderNameDisplay;
    IBOutlet NSTextField *rangeToDisplay;
    
    IBOutlet NSWindow *dicAdjustWindow;
    
    IBOutlet NSSlider *sliderDIC;
    IBOutlet NSSlider *sliderDICBase;
    IBOutlet NSSlider *sliderDICCircle;
    IBOutlet NSSlider *sliderDICBaseCircle;
    
    IBOutlet NSSlider *sliderDICSource;
    IBOutlet NSSlider *sliderDICBaseSource;
    IBOutlet NSSlider *sliderDICCircleSource;
    IBOutlet NSSlider *sliderDICBaseCircleSource;
    
    NSTimer *dicAdjustTimer;
    NSTimer *dicAdjustTimer2;
    
    NSWindowController *dicAdjustWindController;
    
    IBOutlet NSProgressIndicator *backSave;
    IBOutlet NSProgressIndicator *progressIndicator;
    
    id tiffFileRead;
    id singleTiffSave;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;
-(void)copyProcessing:(int)lastCopyNo;
-(void)display;
-(void)contrastSaveProcessing;
-(void)savePositionProcessing;

-(IBAction)closeWindow:(id)sender;
-(IBAction)savePosition:(id)sender;
-(IBAction)saveSourceContrast:(id)sender;
-(IBAction)imageLoad:(id)sender;
-(IBAction)sliderAction:(id)sender;
-(IBAction)sliderActionBase:(id)sender;
-(IBAction)sliderActionCircle:(id)sender;
-(IBAction)sliderActionBaseCircle:(id)sender;
-(IBAction)clearDIC:(id)sender;
-(IBAction)sliderActionSource:(id)sender;
-(IBAction)sliderActionBaseSource:(id)sender;
-(IBAction)sliderActionCircleSource:(id)sender;
-(IBAction)sliderActionBaseCircleSource:(id)sender;
-(IBAction)clearDICSource:(id)sender;
-(IBAction)moveStatusSet:(id)sender;
-(IBAction)chActivate1:(id)sender;
-(IBAction)chActivate2:(id)sender;
-(IBAction)chActivate3:(id)sender;
-(IBAction)chActivate4:(id)sender;
-(IBAction)chActivate5:(id)sender;
-(IBAction)chActivate6:(id)sender;
-(IBAction)dicLiveSwitch:(id)sender;
-(IBAction)deleteCurrentImage:(id)sender;
-(IBAction)createACopy:(id)sender;
-(IBAction)selectFolder:(id)sender;
-(IBAction)nextImageLoadSet:(id)sender;
-(IBAction)currentSettingClear:(id)sender;
-(IBAction)selectDeleteFolder:(id)sender;

@end
