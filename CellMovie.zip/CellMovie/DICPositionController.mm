//
//  DICPositionController.m
//  CellMovie
//
//  Created by Masahiko Sato on 11/22/16.
//
//

#import "DICPositionController.h"

NSString *notificationToDICController = @"notificationExecuteDICController";

@implementation DICPositionController

-(id)init{
    self = [super init];
    
    if (self != nil){
        dicLiveStatus = 0;
        liveChSelect = 0;
        liveNoOfCh = 0;
        nextImageLoad = 0;
        fileTypeTifBmp = 0;
        
        progressTiming = 0;
        progressTimingB = 0;
        progressValue = 0;
        
        sliderDICMax = 20;
        sliderDICMin = 0.01;
        sliderDICDiff = 19.99;
        sliderDICBaseMax = 255;
        sliderDICBaseMin = 0;
        sliderDICBaseDiff = 255;
        
        sliderDICSourceMax = 20;
        sliderDICSourceMin = 0.01;
        sliderDICSourceDiff = 19.99;
        sliderDICBaseSourceMax = 255;
        sliderDICBaseSourceMin = 0;
        sliderDICBaseSourceDiff = 255;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToDICController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    dicAdjustWindController = [[NSWindowController alloc] initWithWindowNibName:@"DICWindow"];
    [dicAdjustWindController showWindow:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDICAdjust object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [dicAdjustWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [dicAdjustWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    int baseCutInt = (int)(baseDICCutDICPos*1000);
    double baseCutDouble = baseCutInt/(double)1000;
    int dicEnhancePosInt = (int)(dicEnhancePos*1000);
    double dicEnhancePosDouble = dicEnhancePosInt/(double)1000;
    
    [baseCutValueDisplay setDoubleValue:baseCutDouble];
    [dicValueDisplay setDoubleValue:dicEnhancePosDouble];
    [sliderDICCircle setDoubleValue:1];
    [sliderDICBaseCircle setDoubleValue:1];
    
    baseCutInt = (int)(baseDICSourceCutPos*1000);
    baseCutDouble = baseCutInt/(double)1000;
    dicEnhancePosInt = (int)(dicSourceEnhancePos*1000);
    dicEnhancePosDouble = dicEnhancePosInt/(double)1000;
    
    [baseCutValueSourceDisplay setDoubleValue:baseCutDouble];
    [dicValueSourceDisplay setDoubleValue:dicEnhancePosDouble];
    [sliderDICCircleSource setDoubleValue:1];
    [sliderDICBaseCircleSource setDoubleValue:1];
    
    [rangeToDisplay setDelegate:self];
    [rangeToDisplay setIntegerValue:dicContrastTo];
    
    dicAdjustTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.3 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    if (progressTiming == 1){
        [progressIndicator setMinValue:0];
        [progressIndicator setMaxValue:progressValue];
        [progressIndicator startAnimation:self];
        [progressIndicator setHidden:NO];
        
        double bValue = [progressIndicator maxValue];
        
        if (progressIndicator){
            if (bValue == progressValue) progressTiming = 2;
        }
    }
    else if (progressTiming == 3){
        [progressIndicator setDoubleValue:progressValue];
        [progressIndicator displayIfNeeded];
        
        double bValue = [progressIndicator doubleValue];
        
        if (bValue == progressValue) progressTiming = 4;
    }
    else if (progressTiming == 5){
        [progressIndicator setDoubleValue:progressValue];
        [progressIndicator displayIfNeeded];
        
        double bValue = [progressIndicator doubleValue];
        
        if (bValue == progressValue) progressTiming = 6;
    }
    else if (progressTiming == 7){
        [progressIndicator stopAnimation:self];
        
        if (!progressIndicator) progressTiming = 0;
    }
    
    if (progressTiming == 0 && [progressIndicator doubleValue] != 0){
        [progressIndicator startAnimation:self];
        [progressIndicator setDoubleValue:0];
        [progressIndicator displayIfNeeded];
        [progressIndicator stopAnimation:self];
    }
    
    if (progressTimingB == 6){
        [backSave startAnimation:self];
        
        if (backSave) progressTimingB = 7;
    }
    else if (progressTimingB == 8){
        [backSave stopAnimation:self];
        
        if (backSave) progressTimingB = 0;
    }
    
    if (progressTimingB == 0){
        if (backSave) [backSave stopAnimation:self];
    }
}

-(void)controlTextDidChange:(NSNotification *)aNotification{
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == rangeToDisplay){
            if ([rangeToDisplay intValue] > filePosition && [rangeToDisplay intValue] <= lastDICImageTime){
                dicContrastTo = [rangeToDisplay intValue];
            }
        }
    }
}

-(IBAction)savePosition:(id)sender{
    if (copyProgressFlag == 0){
        if (imageLoadFlagDICPos == 1){
            if (imageSizeDICPos != 0 && movieRunningFlag == 0){
                if (dicImageStatusPos == 1 && referenceImageStatusPos == 1){
                    if (holdCopyFolderName != ""){
                        if ((dicLiveStatus == 0 && nextImageLoad == 1) || (dicLiveStatus == 1 && fluorescentColorNoPos != 0 && liveChSelect != 0)){
                            [self savePositionProcessing];
                            
                            [chStatusDisplay1 setStringValue:@"Off"];
                            [chStatusDisplay2 setStringValue:@"Off"];
                            [chStatusDisplay3 setStringValue:@"Off"];
                            [chStatusDisplay4 setStringValue:@"Off"];
                            [chStatusDisplay5 setStringValue:@"Off"];
                            [chStatusDisplay6 setStringValue:@"Off"];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Reference Image Unselected"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Missing Copy Directory"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Fluorescent Image Not Loaded"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Image Selected or Movie On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Fluorescent Image Not Loaded or Loaded Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)savePositionProcessing{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        copyProgressFlag = 1;
        self->progressTimingB = 6;
        
        do usleep(10);
        while (self->progressTimingB == 6);
        
        if (self->dicLiveStatus == 0){
            if (self->nextImageLoad == 1){
                string timePointNo;
                
                ifstream fin;
                
                if (self->fileTypeTifBmp == 0){
                    //----Tiff reading----
                    unsigned long stripFirstAddress = 0;
                    unsigned long stripByteCountAddress = 0;
                    unsigned long nextAddress = 0;
                    unsigned long headPosition = 0;
                    unsigned long stripEntry = 0;
                    long sizeForCopy = 0;
                    
                    double xPosition = 100;
                    double yPosition = 100;
                    
                    int imageWidth = 0;
                    int imageHeight = 0;
                    int imageBit = 8; // Check 8, 16
                    int imageCompression = 0; // Check 1
                    int photoMetric = 1; //check 0, 1, 2
                    int imageDimensionTif = 0;
                    int verticalBmp = 0;
                    int horizontalBmp = 0;
                    int horizontalBmpEntry = 0;
                    int endianType = 0;
                    int samplePerPix = 1;
                    int dataConversion [4];
                    int processTypeTif = 1;
                    int numberOfLayers = 0;
                    int mode = 0;
                    
                    struct stat sizeOfFile;
                    
                    for (int counter1 = filePosition+1; counter1 <= lastDICImageTime; counter1++){
                        timePointNo = to_string(counter1);
                        
                        if (timePointNo.length() == 1) timePointNo = "000"+timePointNo;
                        else if (timePointNo.length() == 2) timePointNo = "00"+timePointNo;
                        else if (timePointNo.length() == 3) timePointNo = "0"+timePointNo;
                        
                        fileSavePathHold = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+".tif";
                        
                        if (stat(fileSavePathHold.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            fileReadArray = new uint8_t [sizeForCopy+4];
                            fin.open(fileSavePathHold.c_str(), ios::in | ios::binary);
                            
                            fin.read((char*)fileReadArray, sizeForCopy+4);
                            fin.close();
                            
                            dataConversion [0] = fileReadArray [0];
                            dataConversion [1] = fileReadArray [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            int *arrayExtractedImage3 = new int [100];
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = fileReadArray [7];
                                dataConversion [1] = fileReadArray [6];
                                dataConversion [2] = fileReadArray [5];
                                dataConversion [3] = fileReadArray [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = fileReadArray [4];
                                dataConversion [1] = fileReadArray [5];
                                dataConversion [2] = fileReadArray [6];
                                dataConversion [3] = fileReadArray [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (endianType == 1){
                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                    else imageDimensionTif = imageHeight;
                                    
                                    self->tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [self->tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                }
                            }
                            else if (endianType == 0){
                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                    else imageDimensionTif = imageHeight;
                                    
                                    self->tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [self->tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                }
                            }
                            
                            verticalBmp = 0;
                            horizontalBmp = 0;
                            horizontalBmpEntry = 0;
                            
                            for (int counter5 = 0; counter5 < imageWidth*imageHeight; counter5++){
                                if (verticalBmp < imageHeight){
                                    if (horizontalBmp < imageWidth){
                                        arrayReferenceImagePos [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter5]), horizontalBmpEntry++;
                                        horizontalBmp++;
                                    }
                                    
                                    if (horizontalBmp == imageWidth){
                                        horizontalBmp = 0;
                                        horizontalBmpEntry = 0;
                                        verticalBmp++;
                                    }
                                }
                            }
                            
                            delete [] fileReadArray;
                            
                            arrayImageFileSave = new int *[imageSizeDICPos+1];
                            
                            for (int counter3 = 0; counter3 < imageSizeDICPos+1; counter3++){
                                arrayImageFileSave [counter3] = new int [imageSizeDICPos+1];
                            }
                            
                            for (int counter2 = 0; counter2 < imageSizeDICPos; counter2++){
                                for (int counter3 = 0; counter3 < imageSizeDICPos; counter3++){
                                    if (counter2-yMovePositionHoldMainDIC >= 0 && counter2-yMovePositionHoldMainDIC < imageSizeDICPos && counter3+xMovePositionHoldMainDIC >= 0 && counter3+xMovePositionHoldMainDIC < imageSizeDICPos){
                                        arrayImageFileSave [counter2][counter3] = arrayReferenceImagePos  [counter2-yMovePositionHoldMainDIC][counter3+xMovePositionHoldMainDIC];
                                    }
                                    else arrayImageFileSave [counter2][counter3] = 100;
                                }
                            }
                            
                            self->singleTiffSave = [[SingleTiffSave alloc] init];
                            [self->singleTiffSave singleTiffLayerSave:imageSizeDICPos:imageSizeDICPos:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:(unsigned long)mode];
                            
                            
                            for (int counter3 = 0; counter3 < imageSizeDICPos+1; counter3++){
                                delete [] arrayImageFileSave [counter3];
                            }
                            
                            delete [] arrayImageFileSave;
                            
                            delete [] arrayExtractedImage3;
                        }
                    }
                }
                else{
                    
                    string imageMovePath;
                    int totalDataLength = imageSizeDICPos*imageSizeDICPos+1500;
                    int totalEntryCount = 0;
                    int value1 = 0;
                    int valueTemp = 0;
                    int value2 = 0;
                    int value3 = 0;
                    int value4 = 0;
                    int imageDimensionReadCount = 0;
                    
                    long sizeForCopy = 0;
                    struct stat sizeOfFile;
                    
                    char *mainDataEntry = new char [totalDataLength];
                    
                    for (int counter1 = filePosition+1; counter1 <= lastDICImageTime; counter1++){
                        timePointNo = to_string(counter1);
                        
                        if (timePointNo.length() == 1) timePointNo = "000"+timePointNo;
                        else if (timePointNo.length() == 2) timePointNo = "00"+timePointNo;
                        else if (timePointNo.length() == 3) timePointNo = "0"+timePointNo;
                        
                        imageMovePath = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+".bmp";
                        
                        if (stat(imageMovePath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                            fin.open(imageMovePath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTempA, sizeForCopy+1);
                                fin.close();
                                
                                imageDimensionReadCount = 0;
                                
                                for (int counter2 = imageSizeDICPos-1; counter2 >= 0; counter2--){
                                    for (int counter3 = 0; counter3 < imageSizeDICPos; counter3++){
                                        arrayReferenceImagePos [imageDimensionReadCount][counter3] = uploadTempA [1078+counter2*imageSizeDICPos+counter3];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            
                            delete [] uploadTempA;
                            
                            totalEntryCount = 0;
                            
                            mainDataEntry [totalEntryCount] = 66, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 77, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 54, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 4, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 40, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            value1 = imageSizeDICPos/16777216;
                            valueTemp = imageSizeDICPos%16777216;
                            value2 = valueTemp/65536;
                            valueTemp = valueTemp%65536;
                            value3 = valueTemp/256;
                            valueTemp = valueTemp%256;
                            value4 = valueTemp;
                            
                            mainDataEntry [totalEntryCount] = (char)value4, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)value3, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)value2, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)value1, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = (char)value4, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)value3, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)value2, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)value1, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 1, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 8, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            value1 = imageSizeDICPos*imageSizeDICPos/16777216;
                            valueTemp = imageSizeDICPos*imageSizeDICPos%16777216;
                            value2 = valueTemp/65536;
                            valueTemp = valueTemp%65536;
                            value3 = valueTemp/256;
                            valueTemp = valueTemp%256;
                            value4 = valueTemp;
                            
                            mainDataEntry [totalEntryCount] = (char)value4, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)value3, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)value2, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)value1, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            for (int counter2 = 0; counter2 <= 255; counter2++){
                                mainDataEntry [totalEntryCount] = (char)counter2, totalEntryCount++;
                                mainDataEntry [totalEntryCount] = (char)counter2, totalEntryCount++;
                                mainDataEntry [totalEntryCount] = (char)counter2, totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            }
                            
                            for (int counter2 = imageSizeDICPos-1; counter2 >= 0; counter2--){
                                for (int counter3 = 0; counter3 < imageSizeDICPos; counter3++){
                                    if (counter2-yMovePositionHoldMainDIC >= 0 && counter2-yMovePositionHoldMainDIC < imageSizeDICPos && counter3+xMovePositionHoldMainDIC >= 0 && counter3+xMovePositionHoldMainDIC < imageSizeDICPos){
                                        mainDataEntry [totalEntryCount] = (char)arrayReferenceImagePos  [counter2-yMovePositionHoldMainDIC][counter3+xMovePositionHoldMainDIC], totalEntryCount++;
                                    }
                                    else mainDataEntry [totalEntryCount] = 100, totalEntryCount++;
                                }
                            }
                            
                            mainDataEntry [totalEntryCount] = 88, totalEntryCount++;
                            
                            ofstream outfile3 (imageMovePath.c_str(), ofstream::binary);
                            
                            if (outfile3.is_open()){
                                outfile3.write (mainDataEntry, totalEntryCount);
                                outfile3.close();
                            }
                        }
                    }
                    
                    delete [] mainDataEntry;
                }
                
                for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
                    delete [] arrayReferenceImagePos [counter1];
                }
                
                delete [] arrayReferenceImagePos;
                
                referenceImageStatusPos = 0;
                
                xMovePositionHoldMainDIC = 0;
                yMovePositionHoldMainDIC = 0;
                
                fluorescentColorNoPos = 0;
                self->liveChSelect = 0;
                self->nextImageLoad = 0;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDICAdjust object:self];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else if (self->dicLiveStatus == 1){
            if (fluorescentColorNoPos != 0 && self->liveChSelect != 0){
                string timePointNo;
                
                ifstream fin;
                
                if (self->fileTypeTifBmp == 0){
                    unsigned long stripFirstAddress = 0;
                    unsigned long stripByteCountAddress = 0;
                    unsigned long nextAddress = 0;
                    unsigned long headPosition = 0;
                    unsigned long stripEntry = 0;
                    long sizeForCopy = 0;
                    
                    double xPosition = 100;
                    double yPosition = 100;
                    
                    int imageWidth = 0;
                    int imageHeight = 0;
                    int imageBit = 8; // Check 8, 16
                    int imageCompression = 0; // Check 1
                    int photoMetric = 1; //check 0, 1, 2
                    int imageDimensionTif = 0;
                    int verticalBmp = 0;
                    int horizontalBmp = 0;
                    int horizontalBmpEntry = 0;
                    int endianType = 0;
                    int samplePerPix = 1;
                    int dataConversion [4];
                    int processTypeTif = 1;
                    int numberOfLayers = 0;
                    int mode = 0;
                    
                    struct stat sizeOfFile;
                    
                    for (int counter1 = filePosition; counter1 <= lastDICImageTime; counter1++){
                        timePointNo = to_string(counter1);
                        
                        if (timePointNo.length() == 1) timePointNo = "000"+timePointNo;
                        else if (timePointNo.length() == 2) timePointNo = "00"+timePointNo;
                        else if (timePointNo.length() == 3) timePointNo = "0"+timePointNo;
                        
                        if (self->liveChSelect == 1){
                            fileSavePathHold = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+"_"+to_string(self->liveFluorescentCH1)+"_"+liveFluorescentName1+".tif";
                        }
                        else if (self->liveChSelect == 2){
                            fileSavePathHold = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+"_"+to_string(self->liveFluorescentCH2)+"_"+liveFluorescentName2+".tif";
                        }
                        else if (self->liveChSelect == 3){
                            fileSavePathHold = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+"_"+to_string(self->liveFluorescentCH3)+"_"+liveFluorescentName3+".tif";
                        }
                        else if (self->liveChSelect == 4){
                            fileSavePathHold = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+"_"+to_string(self->liveFluorescentCH4)+"_"+liveFluorescentName4+".tif";
                        }
                        else if (self->liveChSelect == 5){
                            fileSavePathHold = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+"_"+to_string(self->liveFluorescentCH5)+"_"+liveFluorescentName5+".tif";
                        }
                        else if (self->liveChSelect == 6){
                            fileSavePathHold = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+"_"+to_string(self->liveFluorescentCH6)+"_"+liveFluorescentName6+".tif";
                        }
                        
                        if (stat(fileSavePathHold.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            fileReadArray = new uint8_t [sizeForCopy+4];
                            fin.open(fileSavePathHold.c_str(), ios::in | ios::binary);
                            
                            fin.read((char*)fileReadArray, sizeForCopy+4);
                            fin.close();
                            
                            dataConversion [0] = fileReadArray [0];
                            dataConversion [1] = fileReadArray [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            int *arrayExtractedImage3 = new int [100];
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = fileReadArray [7];
                                dataConversion [1] = fileReadArray [6];
                                dataConversion [2] = fileReadArray [5];
                                dataConversion [3] = fileReadArray [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = fileReadArray [4];
                                dataConversion [1] = fileReadArray [5];
                                dataConversion [2] = fileReadArray [6];
                                dataConversion [3] = fileReadArray [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (endianType == 1){
                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                    else imageDimensionTif = imageHeight;
                                    
                                    self->tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [self->tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                }
                            }
                            else if (endianType == 0){
                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                    else imageDimensionTif = imageHeight;
                                    
                                    self->tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [self->tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                }
                            }
                            
                            verticalBmp = 0;
                            horizontalBmp = 0;
                            horizontalBmpEntry = 0;
                            
                            for (int counter5 = 0; counter5 < imageWidth*imageHeight; counter5++){
                                if (verticalBmp < imageHeight){
                                    if (horizontalBmp < imageWidth){
                                        arrayReferenceImagePos [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter5]), horizontalBmpEntry++;
                                        horizontalBmp++;
                                    }
                                    
                                    if (horizontalBmp == imageWidth){
                                        horizontalBmp = 0;
                                        horizontalBmpEntry = 0;
                                        verticalBmp++;
                                    }
                                }
                            }
                            
                            delete [] fileReadArray;
                            
                            arrayImageFileSave = new int *[imageSizeDICPos+1];
                            
                            for (int counter3 = 0; counter3 < imageSizeDICPos+1; counter3++){
                                arrayImageFileSave [counter3] = new int [imageSizeDICPos+1];
                            }
                            
                            for (int counter2 = 0; counter2 < imageSizeDICPos; counter2++){
                                for (int counter3 = 0; counter3 < imageSizeDICPos; counter3++){
                                    if (counter2-yMovePositionHoldMainDIC >= 0 && counter2-yMovePositionHoldMainDIC < imageSizeDICPos && counter3+xMovePositionHoldMainDIC >= 0 && counter3+xMovePositionHoldMainDIC < imageSizeDICPos){
                                        arrayImageFileSave [counter2][counter3] = arrayReferenceImagePos  [counter2-yMovePositionHoldMainDIC][counter3+xMovePositionHoldMainDIC];
                                    }
                                    else arrayImageFileSave [counter2][counter3] = 0;
                                }
                            }
                            
                            self->singleTiffSave = [[SingleTiffSave alloc] init];
                            [self->singleTiffSave singleTiffLayerSave:imageSizeDICPos:imageSizeDICPos:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:(unsigned long)mode];
                            
                            
                            for (int counter3 = 0; counter3 < imageSizeDICPos+1; counter3++){
                                delete [] arrayImageFileSave [counter3];
                            }
                            
                            delete [] arrayImageFileSave;
                            
                            delete [] arrayExtractedImage3;
                        }
                    }
                }
                else{
                    
                    string imageMovePath;
                    int totalDataLength = imageSizeDICPos*imageSizeDICPos+1500;
                    int totalEntryCount = 0;
                    int value1 = 0;
                    int valueTemp = 0;
                    int value2 = 0;
                    int value3 = 0;
                    int value4 = 0;
                    int imageDimensionReadCount = 0;
                    
                    long sizeForCopy = 0;
                    struct stat sizeOfFile;
                    
                    char *mainDataEntry = new char [totalDataLength];
                    
                    for (int counter1 = filePosition; counter1 <= lastDICImageTime; counter1++){
                        timePointNo = to_string(counter1);
                        
                        if (timePointNo.length() == 1) timePointNo = "000"+timePointNo;
                        else if (timePointNo.length() == 2) timePointNo = "00"+timePointNo;
                        else if (timePointNo.length() == 3) timePointNo = "0"+timePointNo;
                        
                        if (self->liveChSelect == 1){
                            imageMovePath = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+"_"+to_string(self->liveFluorescentCH1)+"_"+liveFluorescentName1+".bmp";
                        }
                        else if (self->liveChSelect == 2){
                            imageMovePath = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+"_"+to_string(self->liveFluorescentCH2)+"_"+liveFluorescentName2+".bmp";
                        }
                        else if (self->liveChSelect == 3){
                            imageMovePath = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+"_"+to_string(self->liveFluorescentCH3)+"_"+liveFluorescentName3+".bmp";
                        }
                        
                        if (stat(imageMovePath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                            fin.open(imageMovePath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTempA, sizeForCopy+1);
                                fin.close();
                                
                                imageDimensionReadCount = 0;
                                
                                for (int counter2 = imageSizeDICPos-1; counter2 >= 0; counter2--){
                                    for (int counter3 = 0; counter3 < imageSizeDICPos; counter3++){
                                        arrayReferenceImagePos  [imageDimensionReadCount][counter3] = uploadTempA [1078+counter2*imageSizeDICPos+counter3];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            
                            delete [] uploadTempA;
                            
                            totalEntryCount = 0;
                            
                            mainDataEntry [totalEntryCount] = 66, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 77, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 54, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 4, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 40, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            value1 = imageSizeDICPos/16777216;
                            valueTemp = imageSizeDICPos%16777216;
                            value2 = valueTemp/65536;
                            valueTemp = valueTemp%65536;
                            value3 = valueTemp/256;
                            valueTemp = valueTemp%256;
                            value4 = valueTemp;
                            
                            mainDataEntry [totalEntryCount] = (char)value4, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)value3, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)value2, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)value1, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = (char)value4, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)value3, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)value2, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)value1, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 1, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 8, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            value1 = imageSizeDICPos*imageSizeDICPos/16777216;
                            valueTemp = imageSizeDICPos*imageSizeDICPos%16777216;
                            value2 = valueTemp/65536;
                            valueTemp = valueTemp%65536;
                            value3 = valueTemp/256;
                            valueTemp = valueTemp%256;
                            value4 = valueTemp;
                            
                            mainDataEntry [totalEntryCount] = (char)value4, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)value3, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)value2, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = (char)value1, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            
                            for (int counter2 = 0; counter2 <= 255; counter2++){
                                mainDataEntry [totalEntryCount] = (char)counter2, totalEntryCount++;
                                mainDataEntry [totalEntryCount] = (char)counter2, totalEntryCount++;
                                mainDataEntry [totalEntryCount] = (char)counter2, totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                            }
                            
                            for (int counter2 = imageSizeDICPos-1; counter2 >= 0; counter2--){
                                for (int counter3 = 0; counter3 < imageSizeDICPos; counter3++){
                                    if (counter2-yMovePositionHoldMainDIC >= 0 && counter2-yMovePositionHoldMainDIC < imageSizeDICPos && counter3+xMovePositionHoldMainDIC >= 0 && counter3+xMovePositionHoldMainDIC < imageSizeDICPos){
                                        mainDataEntry [totalEntryCount] = (char)arrayReferenceImagePos  [counter2-yMovePositionHoldMainDIC][counter3+xMovePositionHoldMainDIC], totalEntryCount++;
                                    }
                                    else mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                                }
                            }
                            
                            mainDataEntry [totalEntryCount] = 88, totalEntryCount++;
                            
                            ofstream outfile3 (imageMovePath.c_str(), ofstream::binary);
                            
                            if (outfile3.is_open()){
                                outfile3.write (mainDataEntry, totalEntryCount);
                                outfile3.close();
                            }
                        }
                    }
                    
                    delete [] mainDataEntry;
                }
                
                for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
                    delete [] arrayReferenceImagePos [counter1];
                }
                
                delete [] arrayReferenceImagePos ;
                
                referenceImageStatusPos = 0;
                
                xMovePositionHoldMainDIC = 0;
                yMovePositionHoldMainDIC = 0;
                
                fluorescentColorNoPos = 0;
                self->liveChSelect = 0;
                self->nextImageLoad = 0;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDICAdjust object:self];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        
        self->progressTimingB = 8;
        copyProgressFlag = 0;
    });
}

-(IBAction)saveSourceContrast:(id)sender{
    if (copyProgressFlag == 0){
        if (imageLoadFlagDICPos == 1){
            if (imageSizeDICPos != 0 && movieRunningFlag == 0){
                if (dicImageStatusPos == 1){
                    if (holdCopyFolderName != ""){
                        if (dicLiveStatus == 0){
                            [self contrastSaveProcessing];
                            
                            [chStatusDisplay1 setStringValue:@"Off"];
                            [chStatusDisplay2 setStringValue:@"Off"];
                            [chStatusDisplay3 setStringValue:@"Off"];
                            [chStatusDisplay4 setStringValue:@"Off"];
                            [chStatusDisplay5 setStringValue:@"Off"];
                            [chStatusDisplay6 setStringValue:@"Off"];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Missing Copy Directory"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"No fluorescent Image Loaded"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Image Selected or Movie On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Fluorescent Image Not Loaded or Loaded Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)contrastSaveProcessing{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        copyProgressFlag = 1;
        self->progressTimingB = 6;
        
        do usleep(10);
        while (self->progressTimingB == 6);
        
        string timePointNo;
        
        int processRange = 0;
        
        if (self->dicContrastTo > filePosition && self->dicContrastTo <= lastDICImageTime) processRange = self->dicContrastTo;
        else processRange = lastDICImageTime;
        
        int **arraySaveImage = new int *[imageSizeDICPos+5];
        
        for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
            arraySaveImage [counter1] = new int [imageSizeDICPos+5];
        }
        
        ifstream fin;
        
        if (self->fileTypeTifBmp == 0){
            unsigned long stripFirstAddress = 0;
            unsigned long stripByteCountAddress = 0;
            unsigned long nextAddress = 0;
            unsigned long headPosition = 0;
            unsigned long stripEntry = 0;
            long sizeForCopy = 0;
            
            double xPosition = 0;
            double yPosition = 0;
            
            int imageWidth = 0;
            int imageHeight = 0;
            int imageBit = 8; // Check 8, 16
            int imageCompression = 0; // Check 1
            int photoMetric = 1; //check 0, 1, 2
            int imageDimensionTif = 0;
            int verticalBmp = 0;
            int horizontalBmp = 0;
            int horizontalBmpEntry = 0;
            int endianType = 0;
            int samplePerPix = 1;
            int dataConversion [4];
            int processTypeTif = 1;
            int numberOfLayers = 0;
            int mode = 0;
            
            struct stat sizeOfFile;
            
            for (int counter1 = filePosition; counter1 <= processRange; counter1++){
                timePointNo = to_string(counter1);
                
                if (timePointNo.length() == 1) timePointNo = "000"+timePointNo;
                else if (timePointNo.length() == 2) timePointNo = "00"+timePointNo;
                else if (timePointNo.length() == 3) timePointNo = "0"+timePointNo;
                
                fileSavePathHold = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+".tif";
                
                if (stat(fileSavePathHold.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    fileReadArray = new uint8_t [sizeForCopy+4];
                    fin.open(fileSavePathHold.c_str(), ios::in | ios::binary);
                    
                    fin.read((char*)fileReadArray, sizeForCopy+4);
                    fin.close();
                    
                    dataConversion [0] = fileReadArray [0];
                    dataConversion [1] = fileReadArray [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    int *arrayExtractedImage3 = new int [100];
                    
                    headPosition = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = fileReadArray [7];
                        dataConversion [1] = fileReadArray [6];
                        dataConversion [2] = fileReadArray [5];
                        dataConversion [3] = fileReadArray [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = fileReadArray [4];
                        dataConversion [1] = fileReadArray [5];
                        dataConversion [2] = fileReadArray [6];
                        dataConversion [3] = fileReadArray [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    if (endianType == 1){
                        self->tiffFileRead = [[TiffFileRead alloc] init];
                        [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                        
                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                            if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                            else imageDimensionTif = imageHeight;
                            
                            self->tiffFileRead = [[TiffFileRead alloc] init];
                            delete [] arrayExtractedImage3;
                            
                            arrayExtractedImage3 = [self->tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                        }
                    }
                    else if (endianType == 0){
                        self->tiffFileRead = [[TiffFileRead alloc] init];
                        [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                        
                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                            if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                            else imageDimensionTif = imageHeight;
                            
                            self->tiffFileRead = [[TiffFileRead alloc] init];
                            delete [] arrayExtractedImage3;
                            
                            arrayExtractedImage3 = [self->tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                        }
                    }
                    
                    verticalBmp = 0;
                    horizontalBmp = 0;
                    horizontalBmpEntry = 0;
                    
                    for (int counter5 = 0; counter5 < imageWidth*imageHeight; counter5++){
                        if (verticalBmp < imageHeight){
                            if (horizontalBmp < imageWidth){
                                arraySaveImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter5]), horizontalBmpEntry++;
                                horizontalBmp++;
                            }
                            
                            if (horizontalBmp == imageWidth){
                                horizontalBmp = 0;
                                horizontalBmpEntry = 0;
                                verticalBmp++;
                            }
                        }
                    }
                    
                    delete [] fileReadArray;
                    
                    arrayImageFileSave = new int *[imageSizeDICPos+1];
                    
                    for (int counter3 = 0; counter3 < imageSizeDICPos+1; counter3++){
                        arrayImageFileSave [counter3] = new int [imageSizeDICPos+1];
                    }
                    
                    for (int counter2 = 0; counter2 < imageSizeDICPos; counter2++){
                        for (int counter3 = 0; counter3 < imageSizeDICPos; counter3++){
                            if (arraySaveImage [counter2][counter3] != 100){
                                if (arraySaveImage [counter2][counter3] >= 0 && arraySaveImage [counter2][counter3] < baseDICSourceCutPos){
                                    if (arraySaveImage [counter2][counter3]-(int)((baseDICSourceCutPos-arraySaveImage [counter2][counter3])*dicSourceEnhancePos) < 0){
                                        arrayImageFileSave [counter2][counter3] = 0;
                                    }
                                    else arrayImageFileSave [counter2][counter3] = arraySaveImage [counter2][counter3]-(int)((baseDICSourceCutPos-arraySaveImage [counter2][counter3])*dicSourceEnhancePos);
                                }
                                else{
                                    
                                    if (arraySaveImage [counter2][counter3]+(int)((arraySaveImage [counter2][counter3]-baseDICSourceCutPos)*dicSourceEnhancePos) > 255){
                                        arrayImageFileSave [counter2][counter3] = 255;
                                    }
                                    else arrayImageFileSave [counter2][counter3] = arraySaveImage [counter2][counter3]+(int)((arraySaveImage [counter2][counter3]-baseDICSourceCutPos)*dicSourceEnhancePos);
                                }
                            }
                            else arrayImageFileSave [counter2][counter3] = 100;
                        }
                    }
                    
                    self->singleTiffSave = [[SingleTiffSave alloc] init];
                    [self->singleTiffSave singleTiffLayerSave:imageSizeDICPos:imageSizeDICPos:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:(unsigned long)mode];
                    
                    for (int counter3 = 0; counter3 < imageSizeDICPos+1; counter3++){
                        delete [] arrayImageFileSave [counter3];
                    }
                    
                    delete [] arrayImageFileSave;
                    
                    delete [] arrayExtractedImage3;
                }
            }
        }
        else{
            
            string imageMovePath;
            int totalDataLength = imageSizeDICPos*imageSizeDICPos+1500;
            int totalEntryCount = 0;
            int value1 = 0;
            int valueTemp = 0;
            int value2 = 0;
            int value3 = 0;
            int value4 = 0;
            int imageDimensionReadCount = 0;
            int readDataTemp = 0;
            
            long sizeForCopy = 0;
            struct stat sizeOfFile;
            
            char *mainDataEntry = new char [totalDataLength];
            
            for (int counter1 = filePosition; counter1 <= processRange; counter1++){
                timePointNo = to_string(counter1);
                
                if (timePointNo.length() == 1) timePointNo = "000"+timePointNo;
                else if (timePointNo.length() == 2) timePointNo = "00"+timePointNo;
                else if (timePointNo.length() == 3) timePointNo = "0"+timePointNo;
                
                imageMovePath = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+".bmp";
                
                if (stat(imageMovePath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                    fin.open(imageMovePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTempA, sizeForCopy+1);
                        fin.close();
                        
                        imageDimensionReadCount = 0;
                        
                        for (int counter2 = imageSizeDICPos-1; counter2 >= 0; counter2--){
                            for (int counter3 = 0; counter3 < imageSizeDICPos; counter3++){
                                arraySaveImage [imageDimensionReadCount][counter3] = uploadTempA [1078+counter2*imageSizeDICPos+counter3];
                            }
                            
                            imageDimensionReadCount++;
                        }
                    }
                    
                    delete [] uploadTempA;
                    
                    totalEntryCount = 0;
                    
                    mainDataEntry [totalEntryCount] = 66, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 77, totalEntryCount++;
                    
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    
                    mainDataEntry [totalEntryCount] = 54, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 4, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    
                    mainDataEntry [totalEntryCount] = 40, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    
                    value1 = imageSizeDICPos/16777216;
                    valueTemp = imageSizeDICPos%16777216;
                    value2 = valueTemp/65536;
                    valueTemp = valueTemp%65536;
                    value3 = valueTemp/256;
                    valueTemp = valueTemp%256;
                    value4 = valueTemp;
                    
                    mainDataEntry [totalEntryCount] = (char)value4, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = (char)value3, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = (char)value2, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = (char)value1, totalEntryCount++;
                    
                    mainDataEntry [totalEntryCount] = (char)value4, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = (char)value3, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = (char)value2, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = (char)value1, totalEntryCount++;
                    
                    mainDataEntry [totalEntryCount] = 1, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    
                    mainDataEntry [totalEntryCount] = 8, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    
                    value1 = imageSizeDICPos*imageSizeDICPos/16777216;
                    valueTemp = imageSizeDICPos*imageSizeDICPos%16777216;
                    value2 = valueTemp/65536;
                    valueTemp = valueTemp%65536;
                    value3 = valueTemp/256;
                    valueTemp = valueTemp%256;
                    value4 = valueTemp;
                    
                    mainDataEntry [totalEntryCount] = (char)value4, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = (char)value3, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = (char)value2, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = (char)value1, totalEntryCount++;
                    
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    
                    for (int counter2 = 0; counter2 <= 255; counter2++){
                        mainDataEntry [totalEntryCount] = (char)counter2, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = (char)counter2, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = (char)counter2, totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0, totalEntryCount++;
                    }
                    
                    for (int counter2 = imageSizeDICPos-1; counter2 >= 0; counter2--){
                        for (int counter3 = 0; counter3 < imageSizeDICPos; counter3++){
                            readDataTemp = arraySaveImage [counter2][counter3];
                            
                            if (readDataTemp != 100){
                                if (readDataTemp >= 0 && readDataTemp < baseDICSourceCutPos){
                                    readDataTemp = readDataTemp-(int)((baseDICSourceCutPos-readDataTemp)*dicSourceEnhancePos);
                                    
                                    if (readDataTemp < 0) readDataTemp = 0;
                                }
                                else{
                                    
                                    readDataTemp = readDataTemp+(int)((readDataTemp-baseDICSourceCutPos)*dicSourceEnhancePos);
                                    
                                    if (readDataTemp > 255) readDataTemp = 255;
                                }
                            }
                            
                            mainDataEntry [totalEntryCount] = (char)readDataTemp, totalEntryCount++;
                        }
                    }
                    
                    mainDataEntry [totalEntryCount] = 88, totalEntryCount++;
                    
                    ofstream outfile3 (imageMovePath.c_str(), ofstream::binary);
                    
                    if (outfile3.is_open()){
                        outfile3.write (mainDataEntry, totalEntryCount);
                        outfile3.close();
                    }
                }
            }
            
            delete [] mainDataEntry;
        }
        
        for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
            delete [] arraySaveImage [counter1];
        }
        
        delete [] arraySaveImage;
        
        if (referenceImageStatusPos  == 1){
            for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
                delete [] arrayReferenceImagePos [counter1];
            }
            
            delete [] arrayReferenceImagePos ;
            
            referenceImageStatusPos = 0;
        }
        
        xMovePositionHoldMainDIC = 0;
        yMovePositionHoldMainDIC = 0;
        
        fluorescentColorNoPos = 0;
        self->liveChSelect = 0;
        self->nextImageLoad = 0;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        self->progressTimingB = 8;
        copyProgressFlag = 0;
    });
}

-(IBAction)imageLoad:(id)sender{
    if (copyProgressFlag == 0){
        if (imageLoadFlagDICPos == 0){
            if (imageXYLength != 0 && movieRunningFlag == 0){
                int ifImageCheck = 0;
                int liveImageCheck = 0;
                
                if (fileList [(filePosition-1)*7+1] != ""){
                    if ((int)fileList [(filePosition-1)*7+1].find("TIF") != -1 || (int)fileList [(filePosition-1)*7+1].find("BMP") != -1) ifImageCheck++;
                    
                    if ((int)fileList [(filePosition-1)*7+1].find("_1_") != -1) liveImageCheck++;
                    else if ((int)fileList [(filePosition-1)*7+1].find("_2_") != -1) liveImageCheck++;
                    else if ((int)fileList [(filePosition-1)*7+1].find("_3_") != -1) liveImageCheck++;
                    else if ((int)fileList [(filePosition-1)*7+1].find("_4_") != -1) liveImageCheck++;
                    else if ((int)fileList [(filePosition-1)*7+1].find("_5_") != -1) liveImageCheck++;
                    else if ((int)fileList [(filePosition-1)*7+1].find("_6_") != -1) liveImageCheck++;
                    else if ((int)fileList [(filePosition-1)*7+1].find("_7_") != -1) liveImageCheck++;
                    else if ((int)fileList [(filePosition-1)*7+1].find("_8_") != -1) liveImageCheck++;
                    else if ((int)fileList [(filePosition-1)*7+1].find("_9_") != -1) liveImageCheck++;
                    
                    if (fileList [(filePosition-1)*7+2] != ""){
                        if ((int)fileList [(filePosition-1)*7+2].find("_1_") != -1) liveImageCheck++;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_2_") != -1) liveImageCheck++;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_3_") != -1) liveImageCheck++;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_4_") != -1) liveImageCheck++;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_5_") != -1) liveImageCheck++;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_6_") != -1) liveImageCheck++;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_7_") != -1) liveImageCheck++;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_8_") != -1) liveImageCheck++;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_9_") != -1) liveImageCheck++;
                        
                        if (fileList [(filePosition-1)*7+3] != ""){
                            if ((int)fileList [(filePosition-1)*7+3].find("_1_") != -1) liveImageCheck++;
                            else if ((int)fileList [(filePosition-1)*7+3].find("_2_") != -1) liveImageCheck++;
                            else if ((int)fileList [(filePosition-1)*7+3].find("_3_") != -1) liveImageCheck++;
                            else if ((int)fileList [(filePosition-1)*7+3].find("_4_") != -1) liveImageCheck++;
                            else if ((int)fileList [(filePosition-1)*7+3].find("_5_") != -1) liveImageCheck++;
                            else if ((int)fileList [(filePosition-1)*7+3].find("_6_") != -1) liveImageCheck++;
                            else if ((int)fileList [(filePosition-1)*7+3].find("_7_") != -1) liveImageCheck++;
                            else if ((int)fileList [(filePosition-1)*7+3].find("_8_") != -1) liveImageCheck++;
                            else if ((int)fileList [(filePosition-1)*7+3].find("_9_") != -1) liveImageCheck++;
                            
                            if (fileList [(filePosition-1)*7+4] != ""){
                                if ((int)fileList [(filePosition-1)*7+4].find("_1_") != -1) liveImageCheck++;
                                else if ((int)fileList [(filePosition-1)*7+4].find("_2_") != -1) liveImageCheck++;
                                else if ((int)fileList [(filePosition-1)*7+4].find("_3_") != -1) liveImageCheck++;
                                else if ((int)fileList [(filePosition-1)*7+4].find("_4_") != -1) liveImageCheck++;
                                else if ((int)fileList [(filePosition-1)*7+4].find("_5_") != -1) liveImageCheck++;
                                else if ((int)fileList [(filePosition-1)*7+4].find("_6_") != -1) liveImageCheck++;
                                else if ((int)fileList [(filePosition-1)*7+4].find("_7_") != -1) liveImageCheck++;
                                else if ((int)fileList [(filePosition-1)*7+4].find("_8_") != -1) liveImageCheck++;
                                else if ((int)fileList [(filePosition-1)*7+4].find("_9_") != -1) liveImageCheck++;
                                
                                if (fileList [(filePosition-1)*7+5] != ""){
                                    if ((int)fileList [(filePosition-1)*7+5].find("_1_") != -1) liveImageCheck++;
                                    else if ((int)fileList [(filePosition-1)*7+5].find("_2_") != -1) liveImageCheck++;
                                    else if ((int)fileList [(filePosition-1)*7+5].find("_3_") != -1) liveImageCheck++;
                                    else if ((int)fileList [(filePosition-1)*7+5].find("_4_") != -1) liveImageCheck++;
                                    else if ((int)fileList [(filePosition-1)*7+5].find("_5_") != -1) liveImageCheck++;
                                    else if ((int)fileList [(filePosition-1)*7+5].find("_6_") != -1) liveImageCheck++;
                                    else if ((int)fileList [(filePosition-1)*7+5].find("_7_") != -1) liveImageCheck++;
                                    else if ((int)fileList [(filePosition-1)*7+5].find("_8_") != -1) liveImageCheck++;
                                    else if ((int)fileList [(filePosition-1)*7+5].find("_9_") != -1) liveImageCheck++;
                                    
                                    if (fileList [(filePosition-1)*7+6] != ""){
                                        if ((int)fileList [(filePosition-1)*7+6].find("_1_") != -1) liveImageCheck++;
                                        else if ((int)fileList [(filePosition-1)*7+6].find("_2_") != -1) liveImageCheck++;
                                        else if ((int)fileList [(filePosition-1)*7+6].find("_3_") != -1) liveImageCheck++;
                                        else if ((int)fileList [(filePosition-1)*7+6].find("_4_") != -1) liveImageCheck++;
                                        else if ((int)fileList [(filePosition-1)*7+6].find("_5_") != -1) liveImageCheck++;
                                        else if ((int)fileList [(filePosition-1)*7+6].find("_6_") != -1) liveImageCheck++;
                                        else if ((int)fileList [(filePosition-1)*7+6].find("_7_") != -1) liveImageCheck++;
                                        else if ((int)fileList [(filePosition-1)*7+6].find("_8_") != -1) liveImageCheck++;
                                        else if ((int)fileList [(filePosition-1)*7+6].find("_9_") != -1) liveImageCheck++;
                                    }
                                }
                            }
                        }
                    }
                }
                
                if (dicLiveStatus == 1 && liveImageCheck == 0){
                    dicLiveStatus = 0;
                    
                    if (referenceImageStatusPos  == 1){
                        for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
                            delete [] arrayReferenceImagePos [counter1];
                        }
                        
                        delete [] arrayReferenceImagePos;
                    }
                    
                    referenceImageStatusPos = 0;
                    
                    xMovePositionHoldMainDIC = 0;
                    yMovePositionHoldMainDIC = 0;
                    
                    [chStatusDisplay1 setStringValue:@"Off"];
                    [chStatusDisplay2 setStringValue:@"Off"];
                    [chStatusDisplay3 setStringValue:@"Off"];
                    [chStatusDisplay4 setStringValue:@"Off"];
                    [chStatusDisplay5 setStringValue:@"Off"];
                    [chStatusDisplay6 setStringValue:@"Off"];
                    
                    fluorescentColorNoPos = 0;
                    liveChSelect = 0;
                    nextImageLoad = 0;
                    
                    [dicLiveStatusDisplay setStringValue:@"DIC"];
                }
                
                if (((dicLiveStatus == 1 && liveImageCheck != 0) || (dicLiveStatus == 0 && filePosition != lastDICImageTime)) && ifImageCheck == 0 ){
                    if (dicImageStatusPos == 1){
                        for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
                            delete [] arrayDICImageForPos [counter1];
                        }
                        
                        delete [] arrayDICImageForPos;
                    }
                    
                    if (referenceImageStatusPos  == 1){
                        for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
                            delete [] arrayReferenceImagePos [counter1];
                        }
                        
                        delete [] arrayReferenceImagePos ;
                        
                        referenceImageStatusPos = 0;
                    }
                    
                    imageSizeDICPos = imageXYLength;
                    
                    arrayDICImageForPos = new int *[imageSizeDICPos+5];
                    
                    for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
                        arrayDICImageForPos [counter1] = new int [imageSizeDICPos+5];
                    }
                    
                    dicImageStatusPos = 1;
                    
                    string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7];
                    
                    
                    if ((int)fileList [(filePosition-1)*7].find("tif") != -1) fileTypeTifBmp = 0;
                    else if ((int)fileList [(filePosition-1)*7].find("bmp") != -1) fileTypeTifBmp = 1;
                    
                    ifstream fin;
                    
                    if (fileTypeTifBmp == 0){
                        unsigned long stripFirstAddress = 0;
                        unsigned long stripByteCountAddress = 0;
                        unsigned long nextAddress = 0;
                        unsigned long headPosition = 0;
                        unsigned long stripEntry = 0;
                        long sizeForCopy = 0;
                        
                        double xPosition = 0;
                        double yPosition = 0;
                        
                        int imageWidth = 0;
                        int imageHeight = 0;
                        int imageBit = 0; // Check 8, 16
                        int imageCompression = 0; // Check 1
                        int photoMetric = 0; //check 0, 1, 2
                        int imageDimensionTif = 0;
                        int verticalBmp = 0;
                        int horizontalBmp = 0;
                        int horizontalBmpEntry = 0;
                        int endianType = 0;
                        int samplePerPix = 0;
                        int dataConversion [4];
                        int processTypeTif = 1;
                        int numberOfLayers = 0;
                        
                        struct stat sizeOfFile;
                        
                        if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            fileReadArray = new uint8_t [sizeForCopy+4];
                            fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                            
                            fin.read((char*)fileReadArray, sizeForCopy+4);
                            fin.close();
                            
                            dataConversion [0] = fileReadArray [0];
                            dataConversion [1] = fileReadArray [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            int *arrayExtractedImage3 = new int [100];
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = fileReadArray [7];
                                dataConversion [1] = fileReadArray [6];
                                dataConversion [2] = fileReadArray [5];
                                dataConversion [3] = fileReadArray [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = fileReadArray [4];
                                dataConversion [1] = fileReadArray [5];
                                dataConversion [2] = fileReadArray [6];
                                dataConversion [3] = fileReadArray [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (endianType == 1){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                    else imageDimensionTif = imageHeight;
                                    
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                }
                            }
                            else if (endianType == 0){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                    else imageDimensionTif = imageHeight;
                                    
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                }
                            }
                            
                            verticalBmp = 0;
                            horizontalBmp = 0;
                            horizontalBmpEntry = 0;
                            
                            for (int counter5 = 0; counter5 < imageWidth*imageHeight; counter5++){
                                if (verticalBmp < imageHeight){
                                    if (horizontalBmp < imageWidth){
                                        arrayDICImageForPos [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter5]), horizontalBmpEntry++;
                                        
                                        horizontalBmp++;
                                    }
                                    
                                    if (horizontalBmp == imageWidth){
                                        horizontalBmp = 0;
                                        horizontalBmpEntry = 0;
                                        verticalBmp++;
                                    }
                                }
                            }
                            
                            delete [] fileReadArray;
                            
                            delete [] arrayExtractedImage3;
                        }
                    }
                    else{
                        
                        long sizeForCopy = 0;
                        
                        struct stat sizeOfFile;
                        
                        if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                            fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTempA, sizeForCopy+1);
                                fin.close();
                                
                                int imageDimensionReadCount = 0;
                                
                                for (int counter1 = imageSizeDICPos-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageSizeDICPos; counter2++){
                                        arrayDICImageForPos [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageSizeDICPos+counter2];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            
                            delete [] uploadTempA;
                        }
                    }
                    
                    fluorescentColorNoPos = 0;
                    imageLoadFlagDICPos = 1;
                    xMovePositionHoldMainDIC = 0;
                    yMovePositionHoldMainDIC = 0;
                    liveNoOfCh = 0;
                    liveChSelect = 0;
                    nextImageLoad = 0;
                    
                    dicContrastTo = 0;
                    
                    [currentImageNoDiaplay setIntegerValue:filePosition];
                    
                    if (dicLiveStatus == 0){
                        [nextImageNoDisplay setIntegerValue:filePosition+1];
                    }
                    
                    [chStatusDisplay1 setStringValue:@"Off"];
                    [chStatusDisplay2 setStringValue:@"Off"];
                    [chStatusDisplay3 setStringValue:@"Off"];
                    [chStatusDisplay4 setStringValue:@"Off"];
                    [chStatusDisplay5 setStringValue:@"Off"];
                    [chStatusDisplay6 setStringValue:@"Off"];
                    
                    [chNameDisplay1 setStringValue:@"nil"];
                    [chNameDisplay2 setStringValue:@"nil"];
                    [chNameDisplay3 setStringValue:@"nil"];
                    [chNameDisplay4 setStringValue:@"nil"];
                    [chNameDisplay5 setStringValue:@"nil"];
                    [chNameDisplay6 setStringValue:@"nil"];
                    
                    liveFluorescentName1 = "";
                    liveFluorescentName2 = "";
                    liveFluorescentName3 = "";
                    liveFluorescentName4 = "";
                    liveFluorescentName5 = "";
                    liveFluorescentName6 = "";
                    
                    liveFluorescentCH1 = 0;
                    liveFluorescentCH2 = 0;
                    liveFluorescentCH3 = 0;
                    liveFluorescentCH4 = 0;
                    liveFluorescentCH5 = 0;
                    liveFluorescentCH6 = 0;
                    
                    if (liveImageCheck >= 1){
                        string fluorescentName;
                        
                        if (fileTypeTifBmp == 0) fluorescentName = fileList [(filePosition-1)*7+1].substr(15, fileList [(filePosition-1)*7+1].find(".tif")-15);
                        else fluorescentName = fileList [(filePosition-1)*7+1].substr(15, fileList [(filePosition-1)*7+1].find(".bmp")-15);
                        
                        [chNameDisplay1 setStringValue:@(fluorescentName.c_str())];
                        [chNameDisplay2 setStringValue:@"nil"];
                        [chNameDisplay3 setStringValue:@"nil"];
                        [chNameDisplay4 setStringValue:@"nil"];
                        [chNameDisplay5 setStringValue:@"nil"];
                        [chNameDisplay6 setStringValue:@"nil"];
                        
                        liveFluorescentName1 = fluorescentName;
                        
                        if ((int)fileList [(filePosition-1)*7+1].find("_1_") != -1) liveFluorescentCH1 = 1;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_2_") != -1) liveFluorescentCH1 = 2;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_3_") != -1) liveFluorescentCH1 = 3;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_4_") != -1) liveFluorescentCH1 = 4;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_5_") != -1) liveFluorescentCH1 = 5;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_6_") != -1) liveFluorescentCH1 = 6;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_7_") != -1) liveFluorescentCH1 = 7;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_8_") != -1) liveFluorescentCH1 = 8;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_9_") != -1) liveFluorescentCH1 = 9;
                    }
                    
                    if (liveImageCheck >= 2){
                        string fluorescentName;
                        string fluorescentName2;
                        
                        if (fileTypeTifBmp == 0) fluorescentName = fileList [(filePosition-1)*7+1].substr(15, fileList [(filePosition-1)*7+1].find(".tif")-15);
                        else fluorescentName = fileList [(filePosition-1)*7+1].substr(15, fileList [(filePosition-1)*7+1].find(".bmp")-15);
                        
                        if (fileTypeTifBmp == 0) fluorescentName2 = fileList [(filePosition-1)*7+2].substr(15, fileList [(filePosition-1)*7+2].find(".tif")-15);
                        else fluorescentName2 = fileList [(filePosition-1)*7+2].substr(15, fileList [(filePosition-1)*7+2].find(".bmp")-15);
                        
                        [chNameDisplay1 setStringValue:@(fluorescentName.c_str())];
                        [chNameDisplay2 setStringValue:@(fluorescentName2.c_str())];
                        [chNameDisplay3 setStringValue:@"nil"];
                        [chNameDisplay4 setStringValue:@"nil"];
                        [chNameDisplay5 setStringValue:@"nil"];
                        [chNameDisplay6 setStringValue:@"nil"];
                        
                        liveFluorescentName1 = fluorescentName;
                        liveFluorescentName2 = fluorescentName2;
                        
                        if ((int)fileList [(filePosition-1)*7+1].find("_1_") != -1) liveFluorescentCH1 = 1;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_2_") != -1) liveFluorescentCH1 = 2;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_3_") != -1) liveFluorescentCH1 = 3;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_4_") != -1) liveFluorescentCH1 = 4;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_5_") != -1) liveFluorescentCH1 = 5;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_6_") != -1) liveFluorescentCH1 = 6;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_7_") != -1) liveFluorescentCH1 = 7;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_8_") != -1) liveFluorescentCH1 = 8;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_9_") != -1) liveFluorescentCH1 = 9;
                        
                        if ((int)fileList [(filePosition-1)*7+2].find("_1_") != -1) liveFluorescentCH2 = 1;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_2_") != -1) liveFluorescentCH2 = 2;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_3_") != -1) liveFluorescentCH2 = 3;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_4_") != -1) liveFluorescentCH2 = 4;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_5_") != -1) liveFluorescentCH2 = 5;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_6_") != -1) liveFluorescentCH2 = 6;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_7_") != -1) liveFluorescentCH2 = 7;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_8_") != -1) liveFluorescentCH2 = 8;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_9_") != -1) liveFluorescentCH2 = 9;
                    }
                    
                    if (liveImageCheck >= 3){
                        string fluorescentName;
                        string fluorescentName2;
                        string fluorescentName3;
                        
                        if (fileTypeTifBmp == 0) fluorescentName = fileList [(filePosition-1)*7+1].substr(15, fileList [(filePosition-1)*7+1].find(".tif")-15);
                        else fluorescentName = fileList [(filePosition-1)*7+1].substr(15, fileList [(filePosition-1)*7+1].find(".bmp")-15);
                        
                        if (fileTypeTifBmp == 0) fluorescentName2 = fileList [(filePosition-1)*7+2].substr(15, fileList [(filePosition-1)*7+2].find(".tif")-15);
                        else fluorescentName2 = fileList [(filePosition-1)*7+2].substr(15, fileList [(filePosition-1)*7+2].find(".bmp")-15);
                        
                        if (fileTypeTifBmp == 0) fluorescentName3 = fileList [(filePosition-1)*7+3].substr(15, fileList [(filePosition-1)*7+3].find(".tif")-15);
                        else fluorescentName3 = fileList [(filePosition-1)*7+3].substr(15, fileList [(filePosition-1)*7+3].find(".bmp")-15);
                        
                        [chNameDisplay1 setStringValue:@(fluorescentName.c_str())];
                        [chNameDisplay2 setStringValue:@(fluorescentName2.c_str())];
                        [chNameDisplay3 setStringValue:@(fluorescentName3.c_str())];
                        [chNameDisplay4 setStringValue:@"nil"];
                        [chNameDisplay5 setStringValue:@"nil"];
                        [chNameDisplay6 setStringValue:@"nil"];
                        
                        liveFluorescentName1 = fluorescentName;
                        liveFluorescentName2 = fluorescentName2;
                        liveFluorescentName3 = fluorescentName3;
                        
                        if ((int)fileList [(filePosition-1)*7+1].find("_1_") != -1) liveFluorescentCH1 = 1;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_2_") != -1) liveFluorescentCH1 = 2;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_3_") != -1) liveFluorescentCH1 = 3;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_4_") != -1) liveFluorescentCH1 = 4;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_5_") != -1) liveFluorescentCH1 = 5;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_6_") != -1) liveFluorescentCH1 = 6;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_7_") != -1) liveFluorescentCH1 = 7;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_8_") != -1) liveFluorescentCH1 = 8;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_9_") != -1) liveFluorescentCH1 = 9;
                        
                        if ((int)fileList [(filePosition-1)*7+2].find("_1_") != -1) liveFluorescentCH2 = 1;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_2_") != -1) liveFluorescentCH2 = 2;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_3_") != -1) liveFluorescentCH2 = 3;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_4_") != -1) liveFluorescentCH2 = 4;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_5_") != -1) liveFluorescentCH2 = 5;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_6_") != -1) liveFluorescentCH2 = 6;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_7_") != -1) liveFluorescentCH2 = 7;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_8_") != -1) liveFluorescentCH2 = 8;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_9_") != -1) liveFluorescentCH2 = 9;
                        
                        if ((int)fileList [(filePosition-1)*7+3].find("_1_") != -1) liveFluorescentCH3 = 1;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_2_") != -1) liveFluorescentCH3 = 2;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_3_") != -1) liveFluorescentCH3 = 3;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_4_") != -1) liveFluorescentCH3 = 4;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_5_") != -1) liveFluorescentCH3 = 5;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_6_") != -1) liveFluorescentCH3 = 6;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_7_") != -1) liveFluorescentCH3 = 7;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_8_") != -1) liveFluorescentCH3 = 8;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_9_") != -1) liveFluorescentCH3 = 9;
                    }
                    
                    if (liveImageCheck >= 4){
                        string fluorescentName;
                        string fluorescentName2;
                        string fluorescentName3;
                        string fluorescentName4;
                        
                        if (fileTypeTifBmp == 0) fluorescentName = fileList [(filePosition-1)*7+1].substr(15, fileList [(filePosition-1)*7+1].find(".tif")-15);
                        else fluorescentName = fileList [(filePosition-1)*7+1].substr(15, fileList [(filePosition-1)*7+1].find(".bmp")-15);
                        
                        if (fileTypeTifBmp == 0) fluorescentName2 = fileList [(filePosition-1)*7+2].substr(15, fileList [(filePosition-1)*7+2].find(".tif")-15);
                        else fluorescentName2 = fileList [(filePosition-1)*7+2].substr(15, fileList [(filePosition-1)*7+2].find(".bmp")-15);
                        
                        if (fileTypeTifBmp == 0) fluorescentName3 = fileList [(filePosition-1)*7+3].substr(15, fileList [(filePosition-1)*7+3].find(".tif")-15);
                        else fluorescentName3 = fileList [(filePosition-1)*7+3].substr(15, fileList [(filePosition-1)*7+3].find(".bmp")-15);
                        
                        if (fileTypeTifBmp == 0) fluorescentName4 = fileList [(filePosition-1)*7+4].substr(15, fileList [(filePosition-1)*7+4].find(".tif")-15);
                        else fluorescentName4 = fileList [(filePosition-1)*7+4].substr(15, fileList [(filePosition-1)*7+4].find(".bmp")-15);
                        
                        [chNameDisplay1 setStringValue:@(fluorescentName.c_str())];
                        [chNameDisplay2 setStringValue:@(fluorescentName2.c_str())];
                        [chNameDisplay3 setStringValue:@(fluorescentName3.c_str())];
                        [chNameDisplay4 setStringValue:@(fluorescentName4.c_str())];
                        [chNameDisplay5 setStringValue:@"nil"];
                        [chNameDisplay6 setStringValue:@"nil"];
                        
                        liveFluorescentName1 = fluorescentName;
                        liveFluorescentName2 = fluorescentName2;
                        liveFluorescentName3 = fluorescentName3;
                        liveFluorescentName4 = fluorescentName4;
                        
                        if ((int)fileList [(filePosition-1)*7+1].find("_1_") != -1) liveFluorescentCH1 = 1;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_2_") != -1) liveFluorescentCH1 = 2;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_3_") != -1) liveFluorescentCH1 = 3;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_4_") != -1) liveFluorescentCH1 = 4;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_5_") != -1) liveFluorescentCH1 = 5;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_6_") != -1) liveFluorescentCH1 = 6;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_7_") != -1) liveFluorescentCH1 = 7;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_8_") != -1) liveFluorescentCH1 = 8;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_9_") != -1) liveFluorescentCH1 = 9;
                        
                        if ((int)fileList [(filePosition-1)*7+2].find("_1_") != -1) liveFluorescentCH2 = 1;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_2_") != -1) liveFluorescentCH2 = 2;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_3_") != -1) liveFluorescentCH2 = 3;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_4_") != -1) liveFluorescentCH2 = 4;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_5_") != -1) liveFluorescentCH2 = 5;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_6_") != -1) liveFluorescentCH2 = 6;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_7_") != -1) liveFluorescentCH2 = 7;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_8_") != -1) liveFluorescentCH2 = 8;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_9_") != -1) liveFluorescentCH2 = 9;
                        
                        if ((int)fileList [(filePosition-1)*7+3].find("_1_") != -1) liveFluorescentCH3 = 1;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_2_") != -1) liveFluorescentCH3 = 2;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_3_") != -1) liveFluorescentCH3 = 3;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_4_") != -1) liveFluorescentCH3 = 4;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_5_") != -1) liveFluorescentCH3 = 5;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_6_") != -1) liveFluorescentCH3 = 6;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_7_") != -1) liveFluorescentCH3 = 7;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_8_") != -1) liveFluorescentCH3 = 8;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_9_") != -1) liveFluorescentCH3 = 9;
                        
                        if ((int)fileList [(filePosition-1)*7+4].find("_1_") != -1) liveFluorescentCH4 = 1;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_2_") != -1) liveFluorescentCH4 = 2;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_3_") != -1) liveFluorescentCH4 = 3;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_4_") != -1) liveFluorescentCH4 = 4;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_5_") != -1) liveFluorescentCH4 = 5;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_6_") != -1) liveFluorescentCH4 = 6;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_7_") != -1) liveFluorescentCH4 = 7;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_8_") != -1) liveFluorescentCH4 = 8;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_9_") != -1) liveFluorescentCH4 = 9;
                    }
                    
                    if (liveImageCheck >= 5){
                        string fluorescentName;
                        string fluorescentName2;
                        string fluorescentName3;
                        string fluorescentName4;
                        string fluorescentName5;
                        
                        if (fileTypeTifBmp == 0) fluorescentName = fileList [(filePosition-1)*7+1].substr(15, fileList [(filePosition-1)*7+1].find(".tif")-15);
                        else fluorescentName = fileList [(filePosition-1)*7+1].substr(15, fileList [(filePosition-1)*7+1].find(".bmp")-15);
                        
                        if (fileTypeTifBmp == 0) fluorescentName2 = fileList [(filePosition-1)*7+2].substr(15, fileList [(filePosition-1)*7+2].find(".tif")-15);
                        else fluorescentName2 = fileList [(filePosition-1)*7+2].substr(15, fileList [(filePosition-1)*7+2].find(".bmp")-15);
                        
                        if (fileTypeTifBmp == 0) fluorescentName3 = fileList [(filePosition-1)*7+3].substr(15, fileList [(filePosition-1)*7+3].find(".tif")-15);
                        else fluorescentName3 = fileList [(filePosition-1)*7+3].substr(15, fileList [(filePosition-1)*7+3].find(".bmp")-15);
                        
                        if (fileTypeTifBmp == 0) fluorescentName4 = fileList [(filePosition-1)*7+4].substr(15, fileList [(filePosition-1)*7+4].find(".tif")-15);
                        else fluorescentName4 = fileList [(filePosition-1)*7+4].substr(15, fileList [(filePosition-1)*7+4].find(".bmp")-15);
                        
                        if (fileTypeTifBmp == 0) fluorescentName5 = fileList [(filePosition-1)*7+5].substr(15, fileList [(filePosition-1)*7+5].find(".tif")-15);
                        else fluorescentName5 = fileList [(filePosition-1)*7+5].substr(15, fileList [(filePosition-1)*7+5].find(".bmp")-15);
                        
                        [chNameDisplay1 setStringValue:@(fluorescentName.c_str())];
                        [chNameDisplay2 setStringValue:@(fluorescentName2.c_str())];
                        [chNameDisplay3 setStringValue:@(fluorescentName3.c_str())];
                        [chNameDisplay4 setStringValue:@(fluorescentName4.c_str())];
                        [chNameDisplay5 setStringValue:@(fluorescentName5.c_str())];
                        [chNameDisplay6 setStringValue:@"nil"];
                        
                        liveFluorescentName1 = fluorescentName;
                        liveFluorescentName2 = fluorescentName2;
                        liveFluorescentName3 = fluorescentName3;
                        liveFluorescentName4 = fluorescentName4;
                        liveFluorescentName5 = fluorescentName5;
                        
                        if ((int)fileList [(filePosition-1)*7+1].find("_1_") != -1) liveFluorescentCH1 = 1;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_2_") != -1) liveFluorescentCH1 = 2;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_3_") != -1) liveFluorescentCH1 = 3;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_4_") != -1) liveFluorescentCH1 = 4;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_5_") != -1) liveFluorescentCH1 = 5;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_6_") != -1) liveFluorescentCH1 = 6;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_7_") != -1) liveFluorescentCH1 = 7;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_8_") != -1) liveFluorescentCH1 = 8;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_9_") != -1) liveFluorescentCH1 = 9;
                        
                        if ((int)fileList [(filePosition-1)*7+2].find("_1_") != -1) liveFluorescentCH2 = 1;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_2_") != -1) liveFluorescentCH2 = 2;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_3_") != -1) liveFluorescentCH2 = 3;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_4_") != -1) liveFluorescentCH2 = 4;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_5_") != -1) liveFluorescentCH2 = 5;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_6_") != -1) liveFluorescentCH2 = 6;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_7_") != -1) liveFluorescentCH2 = 7;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_8_") != -1) liveFluorescentCH2 = 8;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_9_") != -1) liveFluorescentCH2 = 9;
                        
                        if ((int)fileList [(filePosition-1)*7+3].find("_1_") != -1) liveFluorescentCH3 = 1;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_2_") != -1) liveFluorescentCH3 = 2;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_3_") != -1) liveFluorescentCH3 = 3;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_4_") != -1) liveFluorescentCH3 = 4;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_5_") != -1) liveFluorescentCH3 = 5;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_6_") != -1) liveFluorescentCH3 = 6;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_7_") != -1) liveFluorescentCH3 = 7;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_8_") != -1) liveFluorescentCH3 = 8;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_9_") != -1) liveFluorescentCH3 = 9;
                        
                        if ((int)fileList [(filePosition-1)*7+4].find("_1_") != -1) liveFluorescentCH4 = 1;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_2_") != -1) liveFluorescentCH4 = 2;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_3_") != -1) liveFluorescentCH4 = 3;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_4_") != -1) liveFluorescentCH4 = 4;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_5_") != -1) liveFluorescentCH4 = 5;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_6_") != -1) liveFluorescentCH4 = 6;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_7_") != -1) liveFluorescentCH4 = 7;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_8_") != -1) liveFluorescentCH4 = 8;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_9_") != -1) liveFluorescentCH4 = 9;
                        
                        if ((int)fileList [(filePosition-1)*7+5].find("_1_") != -1) liveFluorescentCH5 = 1;
                        else if ((int)fileList [(filePosition-1)*7+5].find("_2_") != -1) liveFluorescentCH5 = 2;
                        else if ((int)fileList [(filePosition-1)*7+5].find("_3_") != -1) liveFluorescentCH5 = 3;
                        else if ((int)fileList [(filePosition-1)*7+5].find("_4_") != -1) liveFluorescentCH5 = 4;
                        else if ((int)fileList [(filePosition-1)*7+5].find("_5_") != -1) liveFluorescentCH5 = 5;
                        else if ((int)fileList [(filePosition-1)*7+5].find("_6_") != -1) liveFluorescentCH5 = 6;
                        else if ((int)fileList [(filePosition-1)*7+5].find("_7_") != -1) liveFluorescentCH5 = 7;
                        else if ((int)fileList [(filePosition-1)*7+5].find("_8_") != -1) liveFluorescentCH5 = 8;
                        else if ((int)fileList [(filePosition-1)*7+5].find("_9_") != -1) liveFluorescentCH5 = 9;
                    }
                    
                    if (liveImageCheck == 6){
                        string fluorescentName;
                        string fluorescentName2;
                        string fluorescentName3;
                        string fluorescentName4;
                        string fluorescentName5;
                        string fluorescentName6;
                        
                        if (fileTypeTifBmp == 0) fluorescentName = fileList [(filePosition-1)*7+1].substr(15, fileList [(filePosition-1)*7+1].find(".tif")-15);
                        else fluorescentName = fileList [(filePosition-1)*7+1].substr(15, fileList [(filePosition-1)*7+1].find(".bmp")-15);
                        
                        if (fileTypeTifBmp == 0) fluorescentName2 = fileList [(filePosition-1)*7+2].substr(15, fileList [(filePosition-1)*7+2].find(".tif")-15);
                        else fluorescentName2 = fileList [(filePosition-1)*7+2].substr(15, fileList [(filePosition-1)*7+2].find(".bmp")-15);
                        
                        if (fileTypeTifBmp == 0) fluorescentName3 = fileList [(filePosition-1)*7+3].substr(15, fileList [(filePosition-1)*7+3].find(".tif")-15);
                        else fluorescentName3 = fileList [(filePosition-1)*7+3].substr(15, fileList [(filePosition-1)*7+3].find(".bmp")-15);
                        
                        if (fileTypeTifBmp == 0) fluorescentName4 = fileList [(filePosition-1)*7+4].substr(15, fileList [(filePosition-1)*7+4].find(".tif")-15);
                        else fluorescentName4 = fileList [(filePosition-1)*7+4].substr(15, fileList [(filePosition-1)*7+4].find(".bmp")-15);
                        
                        if (fileTypeTifBmp == 0) fluorescentName5 = fileList [(filePosition-1)*7+5].substr(15, fileList [(filePosition-1)*7+5].find(".tif")-15);
                        else fluorescentName5 = fileList [(filePosition-1)*7+5].substr(15, fileList [(filePosition-1)*7+5].find(".bmp")-15);
                        
                        if (fileTypeTifBmp == 0) fluorescentName6 = fileList [(filePosition-1)*7+6].substr(15, fileList [(filePosition-1)*7+6].find(".tif")-15);
                        else fluorescentName6 = fileList [(filePosition-1)*7+6].substr(15, fileList [(filePosition-1)*7+6].find(".bmp")-15);
                        
                        [chNameDisplay1 setStringValue:@(fluorescentName.c_str())];
                        [chNameDisplay2 setStringValue:@(fluorescentName2.c_str())];
                        [chNameDisplay3 setStringValue:@(fluorescentName3.c_str())];
                        [chNameDisplay4 setStringValue:@(fluorescentName4.c_str())];
                        [chNameDisplay5 setStringValue:@(fluorescentName5.c_str())];
                        [chNameDisplay6 setStringValue:@(fluorescentName6.c_str())];
                        
                        liveFluorescentName1 = fluorescentName;
                        liveFluorescentName2 = fluorescentName2;
                        liveFluorescentName3 = fluorescentName3;
                        liveFluorescentName4 = fluorescentName4;
                        liveFluorescentName5 = fluorescentName5;
                        liveFluorescentName6 = fluorescentName6;
                        
                        if ((int)fileList [(filePosition-1)*7+1].find("_1_") != -1) liveFluorescentCH1 = 1;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_2_") != -1) liveFluorescentCH1 = 2;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_3_") != -1) liveFluorescentCH1 = 3;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_4_") != -1) liveFluorescentCH1 = 4;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_5_") != -1) liveFluorescentCH1 = 5;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_6_") != -1) liveFluorescentCH1 = 6;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_7_") != -1) liveFluorescentCH1 = 7;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_8_") != -1) liveFluorescentCH1 = 8;
                        else if ((int)fileList [(filePosition-1)*7+1].find("_9_") != -1) liveFluorescentCH1 = 9;
                        
                        if ((int)fileList [(filePosition-1)*7+2].find("_1_") != -1) liveFluorescentCH2 = 1;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_2_") != -1) liveFluorescentCH2 = 2;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_3_") != -1) liveFluorescentCH2 = 3;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_4_") != -1) liveFluorescentCH2 = 4;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_5_") != -1) liveFluorescentCH2 = 5;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_6_") != -1) liveFluorescentCH2 = 6;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_7_") != -1) liveFluorescentCH2 = 7;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_8_") != -1) liveFluorescentCH2 = 8;
                        else if ((int)fileList [(filePosition-1)*7+2].find("_9_") != -1) liveFluorescentCH2 = 9;
                        
                        if ((int)fileList [(filePosition-1)*7+3].find("_1_") != -1) liveFluorescentCH3 = 1;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_2_") != -1) liveFluorescentCH3 = 2;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_3_") != -1) liveFluorescentCH3 = 3;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_4_") != -1) liveFluorescentCH3 = 4;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_5_") != -1) liveFluorescentCH3 = 5;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_6_") != -1) liveFluorescentCH3 = 6;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_7_") != -1) liveFluorescentCH3 = 7;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_8_") != -1) liveFluorescentCH3 = 8;
                        else if ((int)fileList [(filePosition-1)*7+3].find("_9_") != -1) liveFluorescentCH3 = 9;
                        
                        if ((int)fileList [(filePosition-1)*7+4].find("_1_") != -1) liveFluorescentCH4 = 1;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_2_") != -1) liveFluorescentCH4 = 2;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_3_") != -1) liveFluorescentCH4 = 3;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_4_") != -1) liveFluorescentCH4 = 4;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_5_") != -1) liveFluorescentCH4 = 5;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_6_") != -1) liveFluorescentCH4 = 6;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_7_") != -1) liveFluorescentCH4 = 7;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_8_") != -1) liveFluorescentCH4 = 8;
                        else if ((int)fileList [(filePosition-1)*7+4].find("_9_") != -1) liveFluorescentCH4 = 9;
                        
                        if ((int)fileList [(filePosition-1)*7+5].find("_1_") != -1) liveFluorescentCH5 = 1;
                        else if ((int)fileList [(filePosition-1)*7+5].find("_2_") != -1) liveFluorescentCH5 = 2;
                        else if ((int)fileList [(filePosition-1)*7+5].find("_3_") != -1) liveFluorescentCH5 = 3;
                        else if ((int)fileList [(filePosition-1)*7+5].find("_4_") != -1) liveFluorescentCH5 = 4;
                        else if ((int)fileList [(filePosition-1)*7+5].find("_5_") != -1) liveFluorescentCH5 = 5;
                        else if ((int)fileList [(filePosition-1)*7+5].find("_6_") != -1) liveFluorescentCH5 = 6;
                        else if ((int)fileList [(filePosition-1)*7+5].find("_7_") != -1) liveFluorescentCH5 = 7;
                        else if ((int)fileList [(filePosition-1)*7+5].find("_8_") != -1) liveFluorescentCH5 = 8;
                        else if ((int)fileList [(filePosition-1)*7+5].find("_9_") != -1) liveFluorescentCH5 = 9;
                        
                        if ((int)fileList [(filePosition-1)*7+6].find("_1_") != -1) liveFluorescentCH6 = 1;
                        else if ((int)fileList [(filePosition-1)*7+6].find("_2_") != -1) liveFluorescentCH6 = 2;
                        else if ((int)fileList [(filePosition-1)*7+6].find("_3_") != -1) liveFluorescentCH6 = 3;
                        else if ((int)fileList [(filePosition-1)*7+6].find("_4_") != -1) liveFluorescentCH6 = 4;
                        else if ((int)fileList [(filePosition-1)*7+6].find("_5_") != -1) liveFluorescentCH6 = 5;
                        else if ((int)fileList [(filePosition-1)*7+6].find("_6_") != -1) liveFluorescentCH6 = 6;
                        else if ((int)fileList [(filePosition-1)*7+6].find("_7_") != -1) liveFluorescentCH6 = 7;
                        else if ((int)fileList [(filePosition-1)*7+6].find("_8_") != -1) liveFluorescentCH6 = 8;
                        else if ((int)fileList [(filePosition-1)*7+6].find("_9_") != -1) liveFluorescentCH6 = 9;
                    }
                    
                    liveNoOfCh = liveImageCheck;
                    
                    if (holdCopyFolderName != "") [copyFolderNameDisplay setStringValue:@(holdCopyFolderName.c_str())];
                    else [copyFolderNameDisplay setStringValue:@"nil"];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDICAdjust object:self];
                }
                else{
                    
                    if (dicLiveStatus == 1 && liveImageCheck == 0){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"No Matching Live Fluorescent Image"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else if (dicLiveStatus == 0 && filePosition == lastDICImageTime){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Modifying Last DIC Image Forbidden"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else if (ifImageCheck == 0){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Found IF image; Set Fluorescent Position"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Image Selected or Movie On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Image Loaded"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderAction:(id)sender{
    if (imageLoadFlagDICPos == 1){
        dicEnhancePos = [sliderDIC doubleValue];
        
        int dicEnhancePosInt = (int)(dicEnhancePos*1000);
        double dicEnhancePosDouble = dicEnhancePosInt/(double)1000;
        
        [dicValueDisplay setDoubleValue:dicEnhancePosDouble];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDICAdjust object:self];
    }
}

-(IBAction)sliderActionBase:(id)sender{
    if (imageLoadFlagDICPos == 1){
        baseDICCutDICPos = (int)[sliderDICBase doubleValue];
        
        int baseCutInt = (int)(baseDICCutDICPos*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        
        [baseCutValueDisplay setDoubleValue:baseCutDouble];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDICAdjust object:self];
    }
}

-(IBAction)sliderActionCircle:(id)sender{
    if (imageLoadFlagDICPos == 1){
        double sliderCircleValue = sliderDICMax*[sliderDICCircle doubleValue];
        double sliderCircleValue2 = sliderDICMin/[sliderDICCircle doubleValue];
        double sliderValue = [sliderDIC doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderDICDiff;
        
        sliderCircleValue = sliderValue+(sliderDICMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderDICMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderDIC setMaxValue:sliderCircleValue];
        [sliderDIC setMinValue:sliderCircleValue2];
        
        int dicEnhancePosInt = (int)([sliderDIC doubleValue]*1000);
        double dicEnhancePosDouble = dicEnhancePosInt/(double)1000;
        
        [dicValueDisplay setDoubleValue:dicEnhancePosDouble];
    }
}

-(IBAction)sliderActionBaseCircle:(id)sender{
    if (imageLoadFlagDICPos == 1){
        double sliderCircleValue = sliderDICBaseMax*[sliderDICBaseCircle doubleValue];
        double sliderCircleValue2 = sliderDICBaseMin/[sliderDICBaseCircle doubleValue];
        double sliderValue = [sliderDICBase doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderDICBaseDiff;
        
        sliderCircleValue = sliderValue+(sliderDICBaseMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderDICBaseMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderDICBase setMaxValue:sliderCircleValue];
        [sliderDICBase setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderDICBase doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [baseCutValueDisplay setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)clearDIC:(id)sender{
    if (imageLoadFlagDICPos == 1){
        baseDICCutDICPos = 50;
        dicEnhancePos = 1;
        
        int baseCutInt = (int)(baseDICCutDICPos*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        int dicEnhancePosInt = (int)(dicEnhancePos*1000);
        double dicEnhancePosDouble = dicEnhancePosInt/(double)1000;
        
        [baseCutValueDisplay setDoubleValue:baseCutDouble];
        [dicValueDisplay setDoubleValue:dicEnhancePosDouble];
        
        [sliderDIC setDoubleValue:1];
        [sliderDICBase setDoubleValue:50];
        [sliderDICCircle setDoubleValue:1];
        [sliderDICBaseCircle setDoubleValue:1];
        
        [sliderDIC setMaxValue:sliderDICMax];
        [sliderDIC setMinValue:sliderDICMin];
        
        [sliderDICBase setMaxValue:sliderDICBaseMax];
        [sliderDICBase setMinValue:sliderDICBaseMin];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDICAdjust object:self];
    }
}

-(IBAction)sliderActionSource:(id)sender{
    if (imageLoadFlagDICPos == 1){
        dicSourceEnhancePos = [sliderDICSource doubleValue];
        
        int dicEnhancePosInt = (int)(dicSourceEnhancePos*1000);
        double dicEnhancePosDouble = dicEnhancePosInt/(double)1000;
        
        [dicValueSourceDisplay setDoubleValue:dicEnhancePosDouble];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDICAdjust object:self];
    }
}

-(IBAction)sliderActionBaseSource:(id)sender{
    if (imageLoadFlagDICPos == 1){
        baseDICSourceCutPos = (int)[sliderDICBaseSource doubleValue];
        
        int baseCutInt = (int)(baseDICSourceCutPos*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        
        [baseCutValueSourceDisplay setDoubleValue:baseCutDouble];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDICAdjust object:self];
    }
}

-(IBAction)sliderActionCircleSource:(id)sender{
    if (imageLoadFlagDICPos == 1){
        double sliderCircleValue = sliderDICSourceMax*[sliderDICCircleSource doubleValue];
        double sliderCircleValue2 = sliderDICSourceMin/[sliderDICCircleSource doubleValue];
        double sliderValue = [sliderDICSource doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderDICSourceDiff;
        
        sliderCircleValue = sliderValue+(sliderDICSourceMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderDICSourceMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderDICSource setMaxValue:sliderCircleValue];
        [sliderDICSource setMinValue:sliderCircleValue2];
        
        int dicEnhancePosInt = (int)([sliderDICSource doubleValue]*1000);
        double dicEnhancePosDouble = dicEnhancePosInt/(double)1000;
        
        [dicValueSourceDisplay setDoubleValue:dicEnhancePosDouble];
    }
}

-(IBAction)sliderActionBaseCircleSource:(id)sender{
    if (imageLoadFlagDICPos == 1){
        double sliderCircleValue = sliderDICBaseSourceMax*[sliderDICBaseCircleSource doubleValue];
        double sliderCircleValue2 = sliderDICBaseSourceMin/[sliderDICBaseCircleSource doubleValue];
        double sliderValue = [sliderDICBaseSource doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderDICBaseSourceDiff;
        
        sliderCircleValue = sliderValue+(sliderDICBaseSourceMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderDICBaseSourceMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderDICBaseSource setMaxValue:sliderCircleValue];
        [sliderDICBaseSource setMinValue:sliderCircleValue2];
        
        int baseEnhanceInt = (int)([sliderDICBaseSource doubleValue]*1000);
        double baseEnhanceDouble = baseEnhanceInt/(double)1000;
        
        [baseCutValueSourceDisplay setDoubleValue:baseEnhanceDouble];
    }
}

-(IBAction)clearDICSource:(id)sender{
    if (imageLoadFlagDICPos == 1){
        baseDICSourceCutPos = 0;
        dicSourceEnhancePos = 0.01;
        
        int baseCutInt = (int)(baseDICSourceCutPos*1000);
        double baseCutDouble = baseCutInt/(double)1000;
        int dicEnhancePosInt = (int)(dicSourceEnhancePos*1000);
        double dicEnhancePosDouble = dicEnhancePosInt/(double)1000;
        
        [baseCutValueSourceDisplay setDoubleValue:baseCutDouble];
        [dicValueSourceDisplay setDoubleValue:dicEnhancePosDouble];
        
        [sliderDICSource setDoubleValue:0.01];
        [sliderDICBaseSource setDoubleValue:0];
        [sliderDICCircleSource setDoubleValue:1];
        [sliderDICBaseCircleSource setDoubleValue:1];
        
        [sliderDICSource setMaxValue:sliderDICSourceMax];
        [sliderDICSource setMinValue:sliderDICSourceMin];
        
        [sliderDICBaseSource setMaxValue:sliderDICBaseSourceMax];
        [sliderDICBaseSource setMinValue:sliderDICBaseSourceMin];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDICAdjust object:self];
    }
}

-(IBAction)moveStatusSet:(id)sender{
    if (imageLoadFlagDICPos == 1){
        if (dicImageStatusPos == 1 && referenceImageStatusPos == 1){
            if (imageMoveStatusPos == 1){
                imageMoveStatusPos = 0;
                [moveStatusDiaplay setStringValue:@"Both"];
            }
            else if (imageMoveStatusPos == 0){
                imageMoveStatusPos = 1;
                [moveStatusDiaplay setStringValue:@"Fluo"];
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Fluorescent Image Not Loaded"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Loaded Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)chActivate1:(id)sender{
    if (copyProgressFlag == 0){
        if (imageLoadFlagDICPos == 1){
            if (dicImageStatusPos == 1 && referenceImageStatusPos == 0){
                if (dicLiveStatus == 1){
                    if (referenceImageStatusPos == 0){
                        arrayReferenceImagePos  = new int *[imageSizeDICPos+5];
                        
                        for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
                            arrayReferenceImagePos  [counter1] = new int [imageSizeDICPos+5];
                        }
                        
                        referenceImageStatusPos = 1;
                    }
                    
                    int fileFindCheck = -1;
                    
                    string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+1];
                    
                    if ((int)fileList [(filePosition-1)*7+1].find("tif") != -1) fileFindCheck = 0;
                    else if ((int)fileList [(filePosition-1)*7+1].find("bmp") != -1) fileFindCheck = 1;
                    
                    if (fileFindCheck != -1){
                        ifstream fin;
                        
                        if (fileTypeTifBmp == 0){
                            unsigned long stripFirstAddress = 0;
                            unsigned long stripByteCountAddress = 0;
                            unsigned long nextAddress = 0;
                            unsigned long headPosition = 0;
                            unsigned long stripEntry = 0;
                            long sizeForCopy = 0;
                            
                            double xPosition = 0;
                            double yPosition = 0;
                            
                            int imageWidth = 0;
                            int imageHeight = 0;
                            int imageBit = 0; // Check 8, 16
                            int imageCompression = 0; // Check 1
                            int photoMetric = 0; //check 0, 1, 2
                            int imageDimensionTif = 0;
                            int verticalBmp = 0;
                            int horizontalBmp = 0;
                            int horizontalBmpEntry = 0;
                            int endianType = 0;
                            int samplePerPix = 0;
                            int dataConversion [4];
                            int processTypeTif = 1;
                            int numberOfLayers = 0;
                            
                            struct stat sizeOfFile;
                            
                            if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                fileReadArray = new uint8_t [sizeForCopy+4];
                                fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                                
                                fin.read((char*)fileReadArray, sizeForCopy+4);
                                fin.close();
                                
                                dataConversion [0] = fileReadArray [0];
                                dataConversion [1] = fileReadArray [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                int *arrayExtractedImage3 = new int [100];
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = fileReadArray [7];
                                    dataConversion [1] = fileReadArray [6];
                                    dataConversion [2] = fileReadArray [5];
                                    dataConversion [3] = fileReadArray [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = fileReadArray [4];
                                    dataConversion [1] = fileReadArray [5];
                                    dataConversion [2] = fileReadArray [6];
                                    dataConversion [3] = fileReadArray [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                if (endianType == 1){
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                    
                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                        if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                        else imageDimensionTif = imageHeight;
                                        
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                    }
                                }
                                else if (endianType == 0){
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                    
                                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                        if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                        else imageDimensionTif = imageHeight;
                                        
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                    }
                                }
                                
                                verticalBmp = 0;
                                horizontalBmp = 0;
                                horizontalBmpEntry = 0;
                                
                                for (int counter5 = 0; counter5 < imageWidth*imageHeight; counter5++){
                                    if (verticalBmp < imageHeight){
                                        if (horizontalBmp < imageWidth){
                                            arrayReferenceImagePos [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter5]), horizontalBmpEntry++;
                                            horizontalBmp++;
                                        }
                                        
                                        if (horizontalBmp == imageWidth){
                                            horizontalBmp = 0;
                                            horizontalBmpEntry = 0;
                                            verticalBmp++;
                                        }
                                    }
                                }
                                
                                delete [] fileReadArray;
                                
                                delete [] arrayExtractedImage3;
                            }
                        }
                        else{
                            
                            long sizeForCopy = 0;
                            
                            struct stat sizeOfFile;
                            
                            if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.read((char*)uploadTempA, sizeForCopy+1);
                                    fin.close();
                                    
                                    int imageDimensionReadCount = 0;
                                    
                                    for (int counter1 = imageSizeDICPos-1; counter1 >= 0; counter1--){
                                        for (int counter2 = 0; counter2 < imageSizeDICPos; counter2++){
                                            arrayReferenceImagePos  [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageSizeDICPos+counter2];
                                        }
                                        
                                        imageDimensionReadCount++;
                                    }
                                }
                                
                                delete [] uploadTempA;
                            }
                        }
                        
                        xMovePositionHoldMainDIC = 0;
                        yMovePositionHoldMainDIC = 0;
                        
                        fluorescentColorNoPos = atoi(fileList [(filePosition-1)*7+1].substr(13, 1).c_str());
                        
                        [chStatusDisplay1 setStringValue:@"On"];
                        [chStatusDisplay2 setStringValue:@"Off"];
                        [chStatusDisplay3 setStringValue:@"Off"];
                        [chStatusDisplay4 setStringValue:@"Off"];
                        [chStatusDisplay5 setStringValue:@"Off"];
                        [chStatusDisplay6 setStringValue:@"Off"];
                        
                        liveChSelect = 1;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDICAdjust object:self];
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Live Fluorescent File Missing"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Live Fluorescent Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"IF Image Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Loaded Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)chActivate2:(id)sender{
    if (copyProgressFlag == 0){
        if (imageLoadFlagDICPos == 1){
            if (dicImageStatusPos == 1 && referenceImageStatusPos == 0){
                if (dicLiveStatus == 1){
                    if (liveNoOfCh >= 2){
                        if (referenceImageStatusPos == 0){
                            arrayReferenceImagePos  = new int *[imageSizeDICPos+5];
                            
                            for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
                                arrayReferenceImagePos  [counter1] = new int [imageSizeDICPos+5];
                            }
                            
                            referenceImageStatusPos = 1;
                        }
                        
                        int fileFindCheck = -1;
                        
                        string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+2];
                        
                        if ((int)fileList [(filePosition-1)*7+2].find("tif") != -1) fileFindCheck = 0;
                        else if ((int)fileList [(filePosition-1)*7+2].find("bmp") != -1) fileFindCheck = 1;
                        
                        if (fileFindCheck != -1){
                            ifstream fin;
                            
                            if (fileTypeTifBmp == 0){
                                unsigned long stripFirstAddress = 0;
                                unsigned long stripByteCountAddress = 0;
                                unsigned long nextAddress = 0;
                                unsigned long headPosition = 0;
                                unsigned long stripEntry = 0;
                                long sizeForCopy = 0;
                                
                                double xPosition = 0;
                                double yPosition = 0;
                                
                                int imageWidth = 0;
                                int imageHeight = 0;
                                int imageBit = 0; // Check 8, 16
                                int imageCompression = 0; // Check 1
                                int photoMetric = 0; //check 0, 1, 2
                                int imageDimensionTif = 0;
                                int verticalBmp = 0;
                                int horizontalBmp = 0;
                                int horizontalBmpEntry = 0;
                                int endianType = 0;
                                int samplePerPix = 0;
                                int dataConversion [4];
                                int processTypeTif = 1;
                                int numberOfLayers = 0;
                                
                                struct stat sizeOfFile;
                                
                                if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    fileReadArray = new uint8_t [sizeForCopy+4];
                                    fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                                    
                                    fin.read((char*)fileReadArray, sizeForCopy+4);
                                    fin.close();
                                    
                                    dataConversion [0] = fileReadArray [0];
                                    dataConversion [1] = fileReadArray [1];
                                    
                                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                    else endianType = 0;
                                    
                                    int *arrayExtractedImage3 = new int [100];
                                    
                                    headPosition = 0;
                                    
                                    if (endianType == 1){
                                        dataConversion [0] = fileReadArray [7];
                                        dataConversion [1] = fileReadArray [6];
                                        dataConversion [2] = fileReadArray [5];
                                        dataConversion [3] = fileReadArray [4];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    else if (endianType == 0){
                                        dataConversion [0] = fileReadArray [4];
                                        dataConversion [1] = fileReadArray [5];
                                        dataConversion [2] = fileReadArray [6];
                                        dataConversion [3] = fileReadArray [7];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    
                                    if (endianType == 1){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                            if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                            else imageDimensionTif = imageHeight;
                                            
                                            tiffFileRead = [[TiffFileRead alloc] init];
                                            delete [] arrayExtractedImage3;
                                            
                                            arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                        }
                                    }
                                    else if (endianType == 0){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                            if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                            else imageDimensionTif = imageHeight;
                                            
                                            tiffFileRead = [[TiffFileRead alloc] init];
                                            delete [] arrayExtractedImage3;
                                            
                                            arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                        }
                                    }
                                    
                                    verticalBmp = 0;
                                    horizontalBmp = 0;
                                    horizontalBmpEntry = 0;
                                    
                                    for (int counter5 = 0; counter5 < imageWidth*imageHeight; counter5++){
                                        if (verticalBmp < imageHeight){
                                            if (horizontalBmp < imageWidth){
                                                arrayReferenceImagePos [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter5]), horizontalBmpEntry++;
                                                horizontalBmp++;
                                            }
                                            
                                            if (horizontalBmp == imageWidth){
                                                horizontalBmp = 0;
                                                horizontalBmpEntry = 0;
                                                verticalBmp++;
                                            }
                                        }
                                    }
                                    
                                    delete [] fileReadArray;
                                    
                                    delete [] arrayExtractedImage3;
                                }
                            }
                            else{
                                
                                long sizeForCopy = 0;
                                
                                struct stat sizeOfFile;
                                
                                if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                    fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)uploadTempA, sizeForCopy+1);
                                        fin.close();
                                        
                                        int imageDimensionReadCount = 0;
                                        
                                        for (int counter1 = imageSizeDICPos-1; counter1 >= 0; counter1--){
                                            for (int counter2 = 0; counter2 < imageSizeDICPos; counter2++){
                                                arrayReferenceImagePos  [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageSizeDICPos+counter2];
                                            }
                                            
                                            imageDimensionReadCount++;
                                        }
                                    }
                                    
                                    delete [] uploadTempA;
                                }
                            }
                            
                            xMovePositionHoldMainDIC = 0;
                            yMovePositionHoldMainDIC = 0;
                            
                            fluorescentColorNoPos = atoi(fileList [(filePosition-1)*7+2].substr(13, 1).c_str());
                            
                            [chStatusDisplay1 setStringValue:@"Off"];
                            [chStatusDisplay2 setStringValue:@"On"];
                            [chStatusDisplay3 setStringValue:@"Off"];
                            [chStatusDisplay4 setStringValue:@"Off"];
                            [chStatusDisplay5 setStringValue:@"Off"];
                            [chStatusDisplay6 setStringValue:@"Off"];
                            
                            liveChSelect = 2;
                            
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDICAdjust object:self];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Live Fluorescent File Missing"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"CH2 Image Missing"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Live Fluorescent Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Fluorescent Image Not Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Loaded Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)chActivate3:(id)sender{
    if (copyProgressFlag == 0){
        if (imageLoadFlagDICPos == 1){
            if (dicImageStatusPos == 1 && referenceImageStatusPos == 0){
                if (dicLiveStatus == 1){
                    if (liveNoOfCh >= 3){
                        if (referenceImageStatusPos == 0){
                            arrayReferenceImagePos  = new int *[imageSizeDICPos+5];
                            
                            for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
                                arrayReferenceImagePos  [counter1] = new int [imageSizeDICPos+5];
                            }
                            
                            referenceImageStatusPos = 1;
                        }
                        
                        int fileFindCheck = -1;
                        
                        string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+3];
                        
                        if ((int)fileList [(filePosition-1)*7+3].find("tif") != -1) fileFindCheck = 0;
                        else if ((int)fileList [(filePosition-1)*7+3].find("bmp") != -1) fileFindCheck = 1;
                        
                        if (fileFindCheck != -1){
                            ifstream fin;
                            
                            if (fileTypeTifBmp == 0){
                                unsigned long stripFirstAddress = 0;
                                unsigned long stripByteCountAddress = 0;
                                unsigned long nextAddress = 0;
                                unsigned long headPosition = 0;
                                unsigned long stripEntry = 0;
                                long sizeForCopy = 0;
                                
                                double xPosition = 0;
                                double yPosition = 0;
                                
                                int imageWidth = 0;
                                int imageHeight = 0;
                                int imageBit = 0; // Check 8, 16
                                int imageCompression = 0; // Check 1
                                int photoMetric = 0; //check 0, 1, 2
                                int imageDimensionTif = 0;
                                int verticalBmp = 0;
                                int horizontalBmp = 0;
                                int horizontalBmpEntry = 0;
                                int endianType = 0;
                                int samplePerPix = 0;
                                int dataConversion [4];
                                int processTypeTif = 1;
                                int numberOfLayers = 0;
                                
                                struct stat sizeOfFile;
                                
                                if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    fileReadArray = new uint8_t [sizeForCopy+4];
                                    fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                                    
                                    fin.read((char*)fileReadArray, sizeForCopy+4);
                                    fin.close();
                                    
                                    dataConversion [0] = fileReadArray [0];
                                    dataConversion [1] = fileReadArray [1];
                                    
                                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                    else endianType = 0;
                                    
                                    int *arrayExtractedImage3 = new int [100];
                                    
                                    headPosition = 0;
                                    
                                    if (endianType == 1){
                                        dataConversion [0] = fileReadArray [7];
                                        dataConversion [1] = fileReadArray [6];
                                        dataConversion [2] = fileReadArray [5];
                                        dataConversion [3] = fileReadArray [4];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    else if (endianType == 0){
                                        dataConversion [0] = fileReadArray [4];
                                        dataConversion [1] = fileReadArray [5];
                                        dataConversion [2] = fileReadArray [6];
                                        dataConversion [3] = fileReadArray [7];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    
                                    if (endianType == 1){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                            if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                            else imageDimensionTif = imageHeight;
                                            
                                            tiffFileRead = [[TiffFileRead alloc] init];
                                            delete [] arrayExtractedImage3;
                                            
                                            arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                        }
                                    }
                                    else if (endianType == 0){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                            if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                            else imageDimensionTif = imageHeight;
                                            
                                            tiffFileRead = [[TiffFileRead alloc] init];
                                            delete [] arrayExtractedImage3;
                                            
                                            arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                        }
                                    }
                                    
                                    verticalBmp = 0;
                                    horizontalBmp = 0;
                                    horizontalBmpEntry = 0;
                                    
                                    for (int counter5 = 0; counter5 < imageWidth*imageHeight; counter5++){
                                        if (verticalBmp < imageHeight){
                                            if (horizontalBmp < imageWidth){
                                                arrayReferenceImagePos [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter5]), horizontalBmpEntry++;
                                                horizontalBmp++;
                                            }
                                            
                                            if (horizontalBmp == imageWidth){
                                                horizontalBmp = 0;
                                                horizontalBmpEntry = 0;
                                                verticalBmp++;
                                            }
                                        }
                                    }
                                    
                                    delete [] fileReadArray;
                                    
                                    delete [] arrayExtractedImage3;
                                }
                            }
                            else{
                                
                                long sizeForCopy = 0;
                                
                                struct stat sizeOfFile;
                                
                                if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                    fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)uploadTempA, sizeForCopy+1);
                                        fin.close();
                                        
                                        int imageDimensionReadCount = 0;
                                        
                                        for (int counter1 = imageSizeDICPos-1; counter1 >= 0; counter1--){
                                            for (int counter2 = 0; counter2 < imageSizeDICPos; counter2++){
                                                arrayReferenceImagePos  [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageSizeDICPos+counter2];
                                            }
                                            
                                            imageDimensionReadCount++;
                                        }
                                    }
                                    
                                    delete [] uploadTempA;
                                }
                            }
                            
                            xMovePositionHoldMainDIC = 0;
                            yMovePositionHoldMainDIC = 0;
                            
                            fluorescentColorNoPos = atoi(fileList [(filePosition-1)*7+3].substr(13, 1).c_str());
                            
                            [chStatusDisplay1 setStringValue:@"Off"];
                            [chStatusDisplay2 setStringValue:@"Off"];
                            [chStatusDisplay3 setStringValue:@"On"];
                            [chStatusDisplay4 setStringValue:@"Off"];
                            [chStatusDisplay5 setStringValue:@"Off"];
                            [chStatusDisplay6 setStringValue:@"Off"];
                            
                            liveChSelect = 3;
                            
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDICAdjust object:self];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Live Fluorescent File Missing"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"CH3 Image Missing"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Live Fluorescent Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Fluorescent Image Not Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Loaded Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)chActivate4:(id)sender{
    if (copyProgressFlag == 0){
        if (imageLoadFlagDICPos == 1){
            if (dicImageStatusPos == 1 && referenceImageStatusPos == 0){
                if (dicLiveStatus == 1){
                    if (liveNoOfCh >= 4){
                        if (referenceImageStatusPos == 0){
                            arrayReferenceImagePos  = new int *[imageSizeDICPos+5];
                            
                            for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
                                arrayReferenceImagePos  [counter1] = new int [imageSizeDICPos+5];
                            }
                            
                            referenceImageStatusPos = 1;
                        }
                        
                        int fileFindCheck = -1;
                        
                        string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+4];
                        
                        if ((int)fileList [(filePosition-1)*7+4].find("tif") != -1) fileFindCheck = 0;
                        else if ((int)fileList [(filePosition-1)*7+4].find("bmp") != -1) fileFindCheck = 1;
                        
                        if (fileFindCheck != -1){
                            ifstream fin;
                            
                            if (fileTypeTifBmp == 0){
                                unsigned long stripFirstAddress = 0;
                                unsigned long stripByteCountAddress = 0;
                                unsigned long nextAddress = 0;
                                unsigned long headPosition = 0;
                                unsigned long stripEntry = 0;
                                long sizeForCopy = 0;
                                
                                double xPosition = 0;
                                double yPosition = 0;
                                
                                int imageWidth = 0;
                                int imageHeight = 0;
                                int imageBit = 0; // Check 8, 16
                                int imageCompression = 0; // Check 1
                                int photoMetric = 0; //check 0, 1, 2
                                int imageDimensionTif = 0;
                                int verticalBmp = 0;
                                int horizontalBmp = 0;
                                int horizontalBmpEntry = 0;
                                int endianType = 0;
                                int samplePerPix = 0;
                                int dataConversion [4];
                                int processTypeTif = 1;
                                int numberOfLayers = 0;
                                
                                struct stat sizeOfFile;
                                
                                if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    fileReadArray = new uint8_t [sizeForCopy+4];
                                    fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                                    
                                    fin.read((char*)fileReadArray, sizeForCopy+4);
                                    fin.close();
                                    
                                    dataConversion [0] = fileReadArray [0];
                                    dataConversion [1] = fileReadArray [1];
                                    
                                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                    else endianType = 0;
                                    
                                    int *arrayExtractedImage3 = new int [100];
                                    
                                    headPosition = 0;
                                    
                                    if (endianType == 1){
                                        dataConversion [0] = fileReadArray [7];
                                        dataConversion [1] = fileReadArray [6];
                                        dataConversion [2] = fileReadArray [5];
                                        dataConversion [3] = fileReadArray [4];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    else if (endianType == 0){
                                        dataConversion [0] = fileReadArray [4];
                                        dataConversion [1] = fileReadArray [5];
                                        dataConversion [2] = fileReadArray [6];
                                        dataConversion [3] = fileReadArray [7];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    
                                    if (endianType == 1){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                            if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                            else imageDimensionTif = imageHeight;
                                            
                                            tiffFileRead = [[TiffFileRead alloc] init];
                                            delete [] arrayExtractedImage3;
                                            
                                            arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                        }
                                    }
                                    else if (endianType == 0){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                            if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                            else imageDimensionTif = imageHeight;
                                            
                                            tiffFileRead = [[TiffFileRead alloc] init];
                                            delete [] arrayExtractedImage3;
                                            
                                            arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                        }
                                    }
                                    
                                    verticalBmp = 0;
                                    horizontalBmp = 0;
                                    horizontalBmpEntry = 0;
                                    
                                    for (int counter5 = 0; counter5 < imageWidth*imageHeight; counter5++){
                                        if (verticalBmp < imageHeight){
                                            if (horizontalBmp < imageWidth){
                                                arrayReferenceImagePos [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter5]), horizontalBmpEntry++;
                                                horizontalBmp++;
                                            }
                                            
                                            if (horizontalBmp == imageWidth){
                                                horizontalBmp = 0;
                                                horizontalBmpEntry = 0;
                                                verticalBmp++;
                                            }
                                        }
                                    }
                                    
                                    delete [] fileReadArray;
                                    
                                    delete [] arrayExtractedImage3;
                                }
                            }
                            else{
                                
                                long sizeForCopy = 0;
                                
                                struct stat sizeOfFile;
                                
                                if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                    fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)uploadTempA, sizeForCopy+1);
                                        fin.close();
                                        
                                        int imageDimensionReadCount = 0;
                                        
                                        for (int counter1 = imageSizeDICPos-1; counter1 >= 0; counter1--){
                                            for (int counter2 = 0; counter2 < imageSizeDICPos; counter2++){
                                                arrayReferenceImagePos  [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageSizeDICPos+counter2];
                                            }
                                            
                                            imageDimensionReadCount++;
                                        }
                                    }
                                    
                                    delete [] uploadTempA;
                                }
                            }
                            
                            xMovePositionHoldMainDIC = 0;
                            yMovePositionHoldMainDIC = 0;
                            
                            fluorescentColorNoPos = atoi(fileList [(filePosition-1)*7+4].substr(13, 1).c_str());
                            
                            [chStatusDisplay1 setStringValue:@"Off"];
                            [chStatusDisplay2 setStringValue:@"Off"];
                            [chStatusDisplay3 setStringValue:@"Off"];
                            [chStatusDisplay4 setStringValue:@"On"];
                            [chStatusDisplay5 setStringValue:@"Off"];
                            [chStatusDisplay6 setStringValue:@"Off"];
                            
                            liveChSelect = 4;
                            
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDICAdjust object:self];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Live Fluorescent File Missing"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"CH4 Image Missing"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Live Fluorescent Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Fluorescent Image Not Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Loaded Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)chActivate5:(id)sender{
    if (copyProgressFlag == 0){
        if (imageLoadFlagDICPos == 1){
            if (dicImageStatusPos == 1 && referenceImageStatusPos == 0){
                if (dicLiveStatus == 1){
                    if (liveNoOfCh >= 5){
                        if (referenceImageStatusPos == 0){
                            arrayReferenceImagePos  = new int *[imageSizeDICPos+5];
                            
                            for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
                                arrayReferenceImagePos  [counter1] = new int [imageSizeDICPos+5];
                            }
                            
                            referenceImageStatusPos = 1;
                        }
                        
                        int fileFindCheck = -1;
                        
                        string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+5];
                        
                        if ((int)fileList [(filePosition-1)*7+5].find("tif") != -1) fileFindCheck = 0;
                        else if ((int)fileList [(filePosition-1)*7+5].find("bmp") != -1) fileFindCheck = 1;
                        
                        if (fileFindCheck != -1){
                            ifstream fin;
                            
                            if (fileTypeTifBmp == 0){
                                unsigned long stripFirstAddress = 0;
                                unsigned long stripByteCountAddress = 0;
                                unsigned long nextAddress = 0;
                                unsigned long headPosition = 0;
                                unsigned long stripEntry = 0;
                                long sizeForCopy = 0;
                                
                                double xPosition = 0;
                                double yPosition = 0;
                                
                                int imageWidth = 0;
                                int imageHeight = 0;
                                int imageBit = 0; // Check 8, 16
                                int imageCompression = 0; // Check 1
                                int photoMetric = 0; //check 0, 1, 2
                                int imageDimensionTif = 0;
                                int verticalBmp = 0;
                                int horizontalBmp = 0;
                                int horizontalBmpEntry = 0;
                                int endianType = 0;
                                int samplePerPix = 0;
                                int dataConversion [4];
                                int processTypeTif = 1;
                                int numberOfLayers = 0;
                                
                                struct stat sizeOfFile;
                                
                                if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    fileReadArray = new uint8_t [sizeForCopy+4];
                                    fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                                    
                                    fin.read((char*)fileReadArray, sizeForCopy+4);
                                    fin.close();
                                    
                                    dataConversion [0] = fileReadArray [0];
                                    dataConversion [1] = fileReadArray [1];
                                    
                                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                    else endianType = 0;
                                    
                                    int *arrayExtractedImage3 = new int [100];
                                    
                                    headPosition = 0;
                                    
                                    if (endianType == 1){
                                        dataConversion [0] = fileReadArray [7];
                                        dataConversion [1] = fileReadArray [6];
                                        dataConversion [2] = fileReadArray [5];
                                        dataConversion [3] = fileReadArray [4];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    else if (endianType == 0){
                                        dataConversion [0] = fileReadArray [4];
                                        dataConversion [1] = fileReadArray [5];
                                        dataConversion [2] = fileReadArray [6];
                                        dataConversion [3] = fileReadArray [7];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    
                                    if (endianType == 1){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                            if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                            else imageDimensionTif = imageHeight;
                                            
                                            tiffFileRead = [[TiffFileRead alloc] init];
                                            delete [] arrayExtractedImage3;
                                            
                                            arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                        }
                                    }
                                    else if (endianType == 0){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                            if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                            else imageDimensionTif = imageHeight;
                                            
                                            tiffFileRead = [[TiffFileRead alloc] init];
                                            delete [] arrayExtractedImage3;
                                            
                                            arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                        }
                                    }
                                    
                                    verticalBmp = 0;
                                    horizontalBmp = 0;
                                    horizontalBmpEntry = 0;
                                    
                                    for (int counter5 = 0; counter5 < imageWidth*imageHeight; counter5++){
                                        if (verticalBmp < imageHeight){
                                            if (horizontalBmp < imageWidth){
                                                arrayReferenceImagePos [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter5]), horizontalBmpEntry++;
                                                horizontalBmp++;
                                            }
                                            
                                            if (horizontalBmp == imageWidth){
                                                horizontalBmp = 0;
                                                horizontalBmpEntry = 0;
                                                verticalBmp++;
                                            }
                                        }
                                    }
                                    
                                    delete [] fileReadArray;
                                    
                                    delete [] arrayExtractedImage3;
                                }
                            }
                            else{
                                
                                long sizeForCopy = 0;
                                
                                struct stat sizeOfFile;
                                
                                if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                    fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)uploadTempA, sizeForCopy+1);
                                        fin.close();
                                        
                                        int imageDimensionReadCount = 0;
                                        
                                        for (int counter1 = imageSizeDICPos-1; counter1 >= 0; counter1--){
                                            for (int counter2 = 0; counter2 < imageSizeDICPos; counter2++){
                                                arrayReferenceImagePos  [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageSizeDICPos+counter2];
                                            }
                                            
                                            imageDimensionReadCount++;
                                        }
                                    }
                                    
                                    delete [] uploadTempA;
                                }
                            }
                            
                            xMovePositionHoldMainDIC = 0;
                            yMovePositionHoldMainDIC = 0;
                            
                            fluorescentColorNoPos = atoi(fileList [(filePosition-1)*7+5].substr(13, 1).c_str());
                            
                            [chStatusDisplay1 setStringValue:@"Off"];
                            [chStatusDisplay2 setStringValue:@"Off"];
                            [chStatusDisplay3 setStringValue:@"Off"];
                            [chStatusDisplay4 setStringValue:@"Off"];
                            [chStatusDisplay5 setStringValue:@"On"];
                            [chStatusDisplay6 setStringValue:@"Off"];
                            
                            liveChSelect = 5;
                            
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDICAdjust object:self];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Live Fluorescent File Missing"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"CH5 Image Missing"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Live Fluorescent Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Fluorescent Image Not Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Loaded Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)chActivate6:(id)sender{
    if (copyProgressFlag == 0){
        if (imageLoadFlagDICPos == 1){
            if (dicImageStatusPos == 1 && referenceImageStatusPos == 0){
                if (dicLiveStatus == 1){
                    if (liveNoOfCh == 6){
                        if (referenceImageStatusPos == 0){
                            arrayReferenceImagePos  = new int *[imageSizeDICPos+5];
                            
                            for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
                                arrayReferenceImagePos  [counter1] = new int [imageSizeDICPos+5];
                            }
                            
                            referenceImageStatusPos = 1;
                        }
                        
                        int fileFindCheck = -1;
                        
                        string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+6];
                        
                        if ((int)fileList [(filePosition-1)*7+6].find("tif") != -1) fileFindCheck = 0;
                        else if ((int)fileList [(filePosition-1)*7+6].find("bmp") != -1) fileFindCheck = 1;
                        
                        if (fileFindCheck != -1){
                            ifstream fin;
                            
                            if (fileTypeTifBmp == 0){
                                unsigned long stripFirstAddress = 0;
                                unsigned long stripByteCountAddress = 0;
                                unsigned long nextAddress = 0;
                                unsigned long headPosition = 0;
                                unsigned long stripEntry = 0;
                                long sizeForCopy = 0;
                                
                                double xPosition = 0;
                                double yPosition = 0;
                                
                                int imageWidth = 0;
                                int imageHeight = 0;
                                int imageBit = 0; // Check 8, 16
                                int imageCompression = 0; // Check 1
                                int photoMetric = 0; //check 0, 1, 2
                                int imageDimensionTif = 0;
                                int verticalBmp = 0;
                                int horizontalBmp = 0;
                                int horizontalBmpEntry = 0;
                                int endianType = 0;
                                int samplePerPix = 0;
                                int dataConversion [4];
                                int processTypeTif = 1;
                                int numberOfLayers = 0;
                                
                                struct stat sizeOfFile;
                                
                                if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    fileReadArray = new uint8_t [sizeForCopy+4];
                                    fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                                    
                                    fin.read((char*)fileReadArray, sizeForCopy+4);
                                    fin.close();
                                    
                                    dataConversion [0] = fileReadArray [0];
                                    dataConversion [1] = fileReadArray [1];
                                    
                                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                    else endianType = 0;
                                    
                                    int *arrayExtractedImage3 = new int [100];
                                    
                                    headPosition = 0;
                                    
                                    if (endianType == 1){
                                        dataConversion [0] = fileReadArray [7];
                                        dataConversion [1] = fileReadArray [6];
                                        dataConversion [2] = fileReadArray [5];
                                        dataConversion [3] = fileReadArray [4];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    else if (endianType == 0){
                                        dataConversion [0] = fileReadArray [4];
                                        dataConversion [1] = fileReadArray [5];
                                        dataConversion [2] = fileReadArray [6];
                                        dataConversion [3] = fileReadArray [7];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    
                                    if (endianType == 1){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                            if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                            else imageDimensionTif = imageHeight;
                                            
                                            tiffFileRead = [[TiffFileRead alloc] init];
                                            delete [] arrayExtractedImage3;
                                            
                                            arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                        }
                                    }
                                    else if (endianType == 0){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                            if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                            else imageDimensionTif = imageHeight;
                                            
                                            tiffFileRead = [[TiffFileRead alloc] init];
                                            delete [] arrayExtractedImage3;
                                            
                                            arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                        }
                                    }
                                    
                                    verticalBmp = 0;
                                    horizontalBmp = 0;
                                    horizontalBmpEntry = 0;
                                    
                                    for (int counter5 = 0; counter5 < imageWidth*imageHeight; counter5++){
                                        if (verticalBmp < imageHeight){
                                            if (horizontalBmp < imageWidth){
                                                arrayReferenceImagePos [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter5]), horizontalBmpEntry++;
                                                horizontalBmp++;
                                            }
                                            
                                            if (horizontalBmp == imageWidth){
                                                horizontalBmp = 0;
                                                horizontalBmpEntry = 0;
                                                verticalBmp++;
                                            }
                                        }
                                    }
                                    
                                    delete [] fileReadArray;
                                    
                                    delete [] arrayExtractedImage3;
                                }
                            }
                            else{
                                
                                long sizeForCopy = 0;
                                
                                struct stat sizeOfFile;
                                
                                if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                    fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)uploadTempA, sizeForCopy+1);
                                        fin.close();
                                        
                                        int imageDimensionReadCount = 0;
                                        
                                        for (int counter1 = imageSizeDICPos-1; counter1 >= 0; counter1--){
                                            for (int counter2 = 0; counter2 < imageSizeDICPos; counter2++){
                                                arrayReferenceImagePos  [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageSizeDICPos+counter2];
                                            }
                                            
                                            imageDimensionReadCount++;
                                        }
                                    }
                                    
                                    delete [] uploadTempA;
                                }
                            }
                            
                            xMovePositionHoldMainDIC = 0;
                            yMovePositionHoldMainDIC = 0;
                            
                            fluorescentColorNoPos = atoi(fileList [(filePosition-1)*7+6].substr(13, 1).c_str());
                            
                            [chStatusDisplay1 setStringValue:@"Off"];
                            [chStatusDisplay2 setStringValue:@"Off"];
                            [chStatusDisplay3 setStringValue:@"Off"];
                            [chStatusDisplay4 setStringValue:@"Off"];
                            [chStatusDisplay5 setStringValue:@"Off"];
                            [chStatusDisplay6 setStringValue:@"On"];
                            
                            liveChSelect = 6;
                            
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDICAdjust object:self];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Live Fluorescent File Missing"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"CH6 Image Missing"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Live Fluorescent Mode Off"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Fluorescent Image Not Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Loaded Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dicLiveSwitch:(id)sender{
    if (copyProgressFlag == 0){
        if (imageLoadFlagDICPos == 1){
            if (imageSizeDICPos != 0 && movieRunningFlag == 0){
                if (dicLiveStatus == 1){
                    dicLiveStatus = 0;
                    
                    if (referenceImageStatusPos  == 1){
                        for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
                            delete [] arrayReferenceImagePos [counter1];
                        }
                        
                        delete [] arrayReferenceImagePos;
                    }
                    
                    referenceImageStatusPos = 0;
                    
                    xMovePositionHoldMainDIC = 0;
                    yMovePositionHoldMainDIC = 0;
                    
                    [chStatusDisplay1 setStringValue:@"Off"];
                    [chStatusDisplay2 setStringValue:@"Off"];
                    [chStatusDisplay3 setStringValue:@"Off"];
                    [chStatusDisplay4 setStringValue:@"Off"];
                    [chStatusDisplay5 setStringValue:@"Off"];
                    [chStatusDisplay6 setStringValue:@"Off"];
                    
                    fluorescentColorNoPos = 0;
                    liveChSelect = 0;
                    nextImageLoad = 0;
                    
                    [dicLiveStatusDisplay setStringValue:@"DIC"];
                }
                else if (dicLiveStatus == 0){
                    dicLiveStatus = 1;
                    [dicLiveStatusDisplay setStringValue:@"LIVE"];
                }
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDICAdjust object:self];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Image Selected or Movie On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Fluorescent Image Not Loaded or Loaded Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)deleteCurrentImage:(id)sender{
    if (copyProgressFlag == 0){
        if (imageLoadFlagDICPos == 1){
            if (imageSizeDICPos != 0 && movieRunningFlag == 0){
                if (dicImageStatusPos == 1){
                    if (holdCopyFolderName != ""){
                        string imageMovePath;
                        string timePointNo = to_string(filePosition);
                        
                        if (timePointNo.length() == 1) timePointNo = "000"+timePointNo;
                        else if (timePointNo.length() == 2) timePointNo = "00"+timePointNo;
                        else if (timePointNo.length() == 3) timePointNo = "0"+timePointNo;
                        
                        if (fileTypeTifBmp == 0){
                            imageMovePath = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+".tif";
                            remove (imageMovePath.c_str());
                            
                            imageMovePath = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+"_"+to_string(liveFluorescentCH1)+"_"+liveFluorescentName1+".tif";
                            remove (imageMovePath.c_str());
                            
                            imageMovePath = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+"_"+to_string(liveFluorescentCH2)+"_"+liveFluorescentName2+".tif";
                            remove (imageMovePath.c_str());
                            
                            imageMovePath = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+"_"+to_string(liveFluorescentCH3)+"_"+liveFluorescentName3+".tif";
                            remove (imageMovePath.c_str());
                            
                            imageMovePath = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+"_"+to_string(liveFluorescentCH4)+"_"+liveFluorescentName3+".tif";
                            remove (imageMovePath.c_str());
                            
                            imageMovePath = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+"_"+to_string(liveFluorescentCH5)+"_"+liveFluorescentName3+".tif";
                            remove (imageMovePath.c_str());
                            
                            imageMovePath = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+"_"+to_string(liveFluorescentCH6)+"_"+liveFluorescentName3+".tif";
                            remove (imageMovePath.c_str());
                            
                            imageMovePath = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch";
                        }
                        else{
                            
                            imageMovePath = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+".bmp";
                            remove (imageMovePath.c_str());
                            
                            imageMovePath = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+"_"+to_string(liveFluorescentCH1)+"_"+liveFluorescentName1+".bmp";
                            remove (imageMovePath.c_str());
                            
                            imageMovePath = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+"_"+to_string(liveFluorescentCH2)+"_"+liveFluorescentName2+".bmp";
                            remove (imageMovePath.c_str());
                            
                            imageMovePath = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+"_"+to_string(liveFluorescentCH3)+"_"+liveFluorescentName3+".bmp";
                            remove (imageMovePath.c_str());
                            
                            imageMovePath = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch";
                        }
                        
                        int fineNoCount = 0;
                        
                        DIR *dir;
                        struct dirent *dent;
                        
                        dir = opendir(imageMovePath.c_str());
                        
                        if (dir != NULL){
                            string entry;
                            
                            while((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    fineNoCount++;
                                }
                            }
                            
                            closedir(dir);
                        }
                        
                        string *fileNameHold = new string [fineNoCount+10];
                        int fileNameHoldCount = 0;
                        string imageNoTemp;
                        
                        dir = opendir(imageMovePath.c_str());
                        
                        if (dir != NULL){
                            string entry;
                            
                            while((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    if ((int)entry.find("STimage") != -1){
                                        imageNoTemp = entry.substr(8, 4);
                                        
                                        if (atoi(imageNoTemp.c_str()) > filePosition) fileNameHold [fileNameHoldCount] = entry, fileNameHoldCount++;
                                    }
                                }
                            }
                            
                            closedir(dir);
                        }
                        
                        string newNamePath;
                        string nameRemaining;
                        int reviseCountNo = 0;
                        
                        for (int counter1 = 0; counter1 < fileNameHoldCount; counter1++){
                            nameRemaining = fileNameHold [counter1].substr(8, 4);
                            reviseCountNo = atoi(nameRemaining.c_str())-1;
                            
                            timePointNo = to_string(reviseCountNo);
                            
                            if (timePointNo.length() == 1) timePointNo = "000"+timePointNo;
                            else if (timePointNo.length() == 2) timePointNo = "00"+timePointNo;
                            else if (timePointNo.length() == 3) timePointNo = "0"+timePointNo;
                            
                            imageMovePath = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+fileNameHold [counter1];
                            
                            nameRemaining = fileNameHold [counter1].substr(12);
                            newNamePath = imageDataPath+"/"+holdCopyFolderName+"_Image/"+treatNameHold+"_Stitch/"+"STimage "+timePointNo+nameRemaining;
                            
                            rename(imageMovePath.c_str(), newNamePath.c_str());
                        }
                        
                        imageMovePath = imageDataPath+"/"+holdCopyFolderName+"_Image";
                        newNamePath = imageDataPath+"/"+holdDeleteFolderName+"_Image";
                        
                        holdCopyFolderName = "";
                        [copyFolderNameDisplay setStringValue:@"nil"];
                        
                        rename(imageMovePath.c_str(), newNamePath.c_str());
                        
                        delete [] fileNameHold;
                        
                        if (referenceImageStatusPos == 1){
                            for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
                                delete [] arrayReferenceImagePos [counter1];
                            }
                            
                            delete [] arrayReferenceImagePos;
                        }
                        
                        referenceImageStatusPos = 0;
                        imageLoadFlagDICPos = 0;
                        
                        xMovePositionHoldMainDIC = 0;
                        yMovePositionHoldMainDIC = 0;
                        
                        [chStatusDisplay1 setStringValue:@"Off"];
                        [chStatusDisplay2 setStringValue:@"Off"];
                        [chStatusDisplay3 setStringValue:@"Off"];
                        [chStatusDisplay4 setStringValue:@"Off"];
                        [chStatusDisplay5 setStringValue:@"Off"];
                        [chStatusDisplay6 setStringValue:@"Off"];
                        
                        fluorescentColorNoPos = 0;
                        liveChSelect = 0;
                        nextImageLoad = 0;
                        imageLoadFlagDICPos = 0;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Missing Copy Directory"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"No IF Mode/Ready for Next Image"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Image Selected or Movie On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Fluorescent Image Not Loaded or Loaded Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)createACopy:(id)sender{
    if (copyProgressFlag == 0){
        if (imageLoadFlagDICPos == 1){
            int proceedingFlag = 0;
            if (holdCopyFolderName != ""){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert addButtonWithTitle:@"Cancel"];
                [alert setMessageText:@"Copied Folder Missing"];
                [alert setInformativeText:@"Re-Create a Copied Folder?"];
                [alert setAlertStyle:NSAlertStyleWarning];
                
                if ([alert runModal] == NSAlertFirstButtonReturn){
                    proceedingFlag = 1;
                }
            }
            
            if ((holdCopyFolderName != "" && proceedingFlag == 1) || (holdCopyFolderName == "" && proceedingFlag == 0)){
                int lastCopyNo = 0;
                string nameTemp = "";
                
                DIR *dir;
                struct dirent *dent;
                
                dir = opendir(imageDataPath.c_str());
                
                if (dir != NULL){
                    string entry;
                    
                    while((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find(analysisNameHold+"%") != -1){
                                nameTemp = analysisNameHold+"%";
                                
                                if (lastCopyNo < atoi(entry.substr(nameTemp.length(), entry.find("_Image")-nameTemp.length()).c_str())){
                                    lastCopyNo = atoi(entry.substr(nameTemp.length(), entry.find("_Image")-nameTemp.length()).c_str());
                                }
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                lastCopyNo++;
                
                if (analysisNameHold.length() < 20){
                    string imageSourcePath = imageDataPath+"/"+analysisNameHold+"_Image";
                    string imageDestinationPath = imageDataPath+"/"+analysisNameHold+"%"+to_string(lastCopyNo)+"_Image";
                    string sizeCheckPath = "/";
                    
                    NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(sizeCheckPath.c_str()) error:nil];
                    unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
                    unsigned long totalFileSize = 0;
                    
                    long sizeForCopy = 0;
                    fileNumberCount = 0;
                    
                    DIR *dir2;
                    struct dirent *dent2;
                    
                    dir = opendir(imageSourcePath.c_str());
                    
                    if (dir != NULL){
                        string entry;
                        string entry2;
                        string pathName2;
                        string pathName3;
                        
                        struct stat sizeOfFile;
                        
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Stitch") != -1){
                                pathName2 = imageSourcePath+"/"+entry;
                                
                                dir2 = opendir(pathName2.c_str());
                                
                                if (dir2 != NULL){
                                    while((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                            pathName3 = pathName2+"/"+entry2;
                                            
                                            if (stat(pathName3.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                                
                                                totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                                                fileNumberCount++;
                                            }
                                        }
                                    }
                                    
                                    closedir(dir2);
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    unsigned long refSize = totalFileSize+2097152000;
                    
                    if (freeSize > refSize){
                        mkdir(imageDestinationPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                        
                        [self copyProcessing:lastCopyNo];
                        
                        holdCopyFolderName = analysisNameHold+"%"+to_string(lastCopyNo);
                        holdDeleteFolderName = analysisNameHold+"$"+to_string(lastCopyNo);
                        [copyFolderNameDisplay setStringValue:@(holdCopyFolderName.c_str())];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Disk Space Low"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Analysis Name Too Long: Rename Analysis Name"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Loaded Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)copyProcessing:(int)lastCopyNo{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        copyProgressFlag = 1;
        
        self->progressValue = self->fileNumberCount;
        self->progressTiming = 1;
        
        do usleep(10);
        while (self->progressTiming == 1);
        
        string imageSourcePath = imageDataPath+"/"+analysisNameHold+"_Image";
        string imageDestinationPath = imageDataPath+"/"+analysisNameHold+"%"+to_string(lastCopyNo)+"_Image";
        
        string *sourcePathHold = new string [10000];
        string *destinationPathHold = new string [10000];
        
        int pathEntryCount = 0;
        int pathEntryLimit = 10000;
        
        long sizeForCopy = 0;
        
        DIR *dir;
        struct dirent *dent;
        DIR *dir2;
        struct dirent *dent2;
        
        dir = opendir(imageSourcePath.c_str());
        
        if (dir != NULL){
            string entry;
            string entry2;
            string pathName2;
            string pathNameB2;
            
            while((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Stitch") != -1){
                    pathName2 = imageSourcePath+"/"+entry;
                    pathNameB2 = imageDestinationPath+"/"+entry;
                    
                    dir2 = opendir(pathName2.c_str());
                    
                    if (dir2 != NULL){
                        mkdir(pathNameB2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                        
                        while((dent2 = readdir(dir2))){
                            entry2 = dent2 -> d_name;
                            
                            if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                if (pathEntryCount+2 > pathEntryLimit){
                                    string *arrayUpDate0 = new string [pathEntryCount+10];
                                    string *arrayUpDate2 = new string [pathEntryCount+10];
                                    
                                    for (int counter1 = 0; counter1 < pathEntryCount; counter1++){
                                        arrayUpDate0 [counter1] = sourcePathHold [counter1];
                                        arrayUpDate2 [counter1] = destinationPathHold [counter1];
                                    }
                                    
                                    delete [] sourcePathHold;
                                    delete [] destinationPathHold;
                                    sourcePathHold = new string [pathEntryLimit+5000];
                                    destinationPathHold = new string [pathEntryLimit+5000];
                                    
                                    pathEntryLimit = pathEntryLimit+5000;
                                    
                                    for (int counter1 = 0; counter1 < pathEntryCount; counter1++){
                                        sourcePathHold [counter1] = arrayUpDate0 [counter1];
                                        destinationPathHold [counter1] = arrayUpDate2 [counter1];
                                    }
                                    
                                    delete [] arrayUpDate0;
                                    delete [] arrayUpDate2;
                                }
                                
                                sourcePathHold [pathEntryCount] = pathName2+"/"+entry2;
                                destinationPathHold [pathEntryCount] = pathNameB2+"/"+entry2, pathEntryCount++;
                            }
                        }
                        
                        closedir(dir2);
                    }
                }
            }
            
            closedir(dir);
        }
        
        struct stat sizeOfFile;
        
        for (int counter1 = 0; counter1 < pathEntryCount; counter1++){
            self->progressValue = counter1;
            self->progressTiming = 3;
            usleep(1000);
            
            if (stat(sourcePathHold [counter1].c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                ifstream infile (sourcePathHold [counter1].c_str(), ifstream::binary);
                ofstream outfile (destinationPathHold [counter1].c_str(), ofstream::binary);
                
                char* buffer = new char[sizeForCopy];
                infile.read (buffer, sizeForCopy);
                outfile.write (buffer, sizeForCopy);
                delete[] buffer;
                
                outfile.close();
                infile.close();
                
                do{
                } while (stat(destinationPathHold [counter1].c_str(), &sizeOfFile) == 0);
            }
        }
        
        delete [] sourcePathHold;
        delete [] destinationPathHold;
        
        self->progressValue = 0;
        self->progressTiming = 5;
        
        do{
            usleep(10);
        } while (self->progressTiming == 5);
        
        self->progressTiming = 7;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        copyProgressFlag = 0;
    });
}

-(IBAction)selectDeleteFolder:(id)sender{
    if (copyProgressFlag == 0){
        if (imageLoadFlagDICPos == 1){
            int lastCopyNo = 0;
            string nameTemp = "";
            
            DIR *dir;
            struct dirent *dent;
            
            dir = opendir(imageDataPath.c_str());
            
            if (dir != NULL){
                string entry;
                
                while((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if ((int)entry.find(analysisNameHold+"$") != -1){
                            nameTemp = analysisNameHold+"$";
                            
                            if (lastCopyNo < atoi(entry.substr(nameTemp.length(), entry.find("_Image")-nameTemp.length()).c_str())){
                                lastCopyNo = atoi(entry.substr(nameTemp.length(), entry.find("_Image")-nameTemp.length()).c_str());
                            }
                        }
                    }
                }
                
                closedir(dir);
            }
            
            if (lastCopyNo != 0){
                holdCopyFolderName = "";
                holdDeleteFolderName = analysisNameHold+"$"+to_string(lastCopyNo);
                [copyFolderNameDisplay setStringValue:@(holdDeleteFolderName.c_str())];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Copy Folder (Not Created or Deleted)"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Loaded Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)selectFolder:(id)sender{
    if (copyProgressFlag == 0){
        if (imageLoadFlagDICPos == 1){
            int lastCopyNo = 0;
            string nameTemp = "";
            
            DIR *dir;
            struct dirent *dent;
            
            dir = opendir(imageDataPath.c_str());
            
            if (dir != NULL){
                string entry;
                
                while((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if ((int)entry.find(analysisNameHold+"%") != -1){
                            nameTemp = analysisNameHold+"%";
                            
                            if (lastCopyNo < atoi(entry.substr(nameTemp.length(), entry.find("_Image")-nameTemp.length()).c_str())){
                                lastCopyNo = atoi(entry.substr(nameTemp.length(), entry.find("_Image")-nameTemp.length()).c_str());
                            }
                        }
                    }
                }
                
                closedir(dir);
            }
            
            if (lastCopyNo != 0){
                holdCopyFolderName = analysisNameHold+"%"+to_string(lastCopyNo);
                [copyFolderNameDisplay setStringValue:@(holdCopyFolderName.c_str())];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Copy Folder (Not Created or Deleted)"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Loaded Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)nextImageLoadSet:(id)sender{
    if (copyProgressFlag == 0){
        if (imageLoadFlagDICPos == 1){
            if (dicImageStatusPos == 1 && referenceImageStatusPos == 0){
                if (dicLiveStatus == 0){
                    if (referenceImageStatusPos == 0){
                        arrayReferenceImagePos  = new int *[imageSizeDICPos+5];
                        
                        for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
                            arrayReferenceImagePos  [counter1] = new int [imageSizeDICPos+5];
                        }
                        
                        referenceImageStatusPos = 1;
                    }
                    
                    string imageMoviePath = imageDisplayPath+"/"+fileList [filePosition*7];
                    
                    if ((int)fileList [(filePosition)*7].find("tif") != -1) fileTypeTifBmp = 0;
                    else if ((int)fileList [(filePosition)*7].find("bmp") != -1) fileTypeTifBmp = 1;
                    
                    ifstream fin;
                    
                    if (fileTypeTifBmp == 0){
                        unsigned long stripFirstAddress = 0;
                        unsigned long stripByteCountAddress = 0;
                        unsigned long nextAddress = 0;
                        unsigned long headPosition = 0;
                        unsigned long stripEntry = 0;
                        long sizeForCopy = 0;
                        
                        double xPosition = 0;
                        double yPosition = 0;
                        
                        int imageWidth = 0;
                        int imageHeight = 0;
                        int imageBit = 0; // Check 8, 16
                        int imageCompression = 0; // Check 1
                        int photoMetric = 0; //check 0, 1, 2
                        int imageDimensionTif = 0;
                        int verticalBmp = 0;
                        int horizontalBmp = 0;
                        int horizontalBmpEntry = 0;
                        int endianType = 0;
                        int samplePerPix = 0;
                        int dataConversion [4];
                        int processTypeTif = 1;
                        int numberOfLayers = 0;
                        
                        struct stat sizeOfFile;
                        
                        if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            fileReadArray = new uint8_t [sizeForCopy+4];
                            fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                            
                            fin.read((char*)fileReadArray, sizeForCopy+4);
                            fin.close();
                            
                            dataConversion [0] = fileReadArray [0];
                            dataConversion [1] = fileReadArray [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            int *arrayExtractedImage3 = new int [100];
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = fileReadArray [7];
                                dataConversion [1] = fileReadArray [6];
                                dataConversion [2] = fileReadArray [5];
                                dataConversion [3] = fileReadArray [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = fileReadArray [4];
                                dataConversion [1] = fileReadArray [5];
                                dataConversion [2] = fileReadArray [6];
                                dataConversion [3] = fileReadArray [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (endianType == 1){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                    else imageDimensionTif = imageHeight;
                                    
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                }
                            }
                            else if (endianType == 0){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                    if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                    else imageDimensionTif = imageHeight;
                                    
                                    tiffFileRead = [[TiffFileRead alloc] init];
                                    delete [] arrayExtractedImage3;
                                    
                                    arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                                }
                            }
                            
                            verticalBmp = 0;
                            horizontalBmp = 0;
                            horizontalBmpEntry = 0;
                            
                            for (int counter5 = 0; counter5 < imageWidth*imageHeight; counter5++){
                                if (verticalBmp < imageHeight){
                                    if (horizontalBmp < imageWidth){
                                        arrayReferenceImagePos [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter5]), horizontalBmpEntry++;
                                        horizontalBmp++;
                                    }
                                    
                                    if (horizontalBmp == imageWidth){
                                        horizontalBmp = 0;
                                        horizontalBmpEntry = 0;
                                        verticalBmp++;
                                    }
                                }
                            }
                            
                            delete [] fileReadArray;
                            
                            delete [] arrayExtractedImage3;
                        }
                    }
                    else{
                        
                        long sizeForCopy = 0;
                        
                        struct stat sizeOfFile;
                        
                        if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                            fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTempA, sizeForCopy+1);
                                fin.close();
                                
                                int imageDimensionReadCount = 0;
                                
                                for (int counter1 = imageSizeDICPos-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageSizeDICPos; counter2++){
                                        arrayReferenceImagePos  [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageSizeDICPos+counter2];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            
                            delete [] uploadTempA;
                        }
                    }
                    
                    xMovePositionHoldMainDIC = 0;
                    yMovePositionHoldMainDIC = 0;
                    
                    nextImageLoad = 1;
                    fluorescentColorNoPos = 2;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDICAdjust object:self];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"No DIC Mode"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Loaded Next Image"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Loaded Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)currentSettingClear:(id)sender{
    if (copyProgressFlag == 0){
        if (imageLoadFlagDICPos == 1){
            if (dicImageStatusPos == 1 && referenceImageStatusPos == 1){
                if (referenceImageStatusPos  == 1){
                    for (int counter1 = 0; counter1 < imageSizeDICPos+5; counter1++){
                        delete [] arrayReferenceImagePos [counter1];
                    }
                    
                    delete [] arrayReferenceImagePos ;
                    
                    referenceImageStatusPos = 0;
                    
                    xMovePositionHoldMainDIC = 0;
                    yMovePositionHoldMainDIC = 0;
                    
                    [chStatusDisplay1 setStringValue:@"Off"];
                    [chStatusDisplay2 setStringValue:@"Off"];
                    [chStatusDisplay3 setStringValue:@"Off"];
                    [chStatusDisplay4 setStringValue:@"Off"];
                    [chStatusDisplay5 setStringValue:@"Off"];
                    [chStatusDisplay6 setStringValue:@"Off"];
                    
                    fluorescentColorNoPos = 0;
                    liveChSelect = 0;
                    nextImageLoad = 0;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDICAdjust object:self];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Image Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Loaded Image Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)closeWindow:(id)sender{
    [dicAdjustWindow orderOut:self];
    positionDICAdjustOperation = 2;
    dicAdjustTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
    [dicAdjustTimer2 invalidate];
}

-(void)reDisplayWindow{
    if (positionDICAdjustOperation == 3){
        [dicAdjustWindow makeKeyAndOrderFront:self];
        positionDICAdjustOperation = 1;
        [dicAdjustTimer invalidate];
        dicAdjustTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
    }
}

-(void)dealloc{
    if (dicAdjustTimer) [dicAdjustTimer invalidate];
    if (dicAdjustTimer2) [dicAdjustTimer2 invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToDICController object:nil];
}

@end
