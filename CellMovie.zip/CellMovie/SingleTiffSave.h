//
//  TiffSave.h
//  CellMovie
//
//  Created by Masahiko Sato on 2021-06-16.
//  Copyright Masahiko Sato 2021 All rights reserved.
//

#ifndef SINGLETIFFSAVE_H
#define SINGLETIFFSAVE_H
#import "Controller.h"
#endif

@interface SingleTiffSave : NSObject{
    id ascIIconversion;
}

-(unsigned long)singleTiffLayerSave:(int)imageDimensionX :(int)imageDimensionY :(int)imageBitPerPix :(int)photometric :(int)samplePerPix :(double)xPositionImage :(double)yPositionImage :(int)mode :(unsigned long)ifPrevious;

@end
