//
//  LabelSetDisplay.h
//  CellMovie
//
//  Created by Masahiko Sato on 2022-02-01.
//

#ifndef LABELSETDISPLAY_H
#define LABELSETDISPLAY_H
#import "Controller.h"
#endif

@interface LabelSetDisplay : NSView {
    int imageFirstLoadFlagDisplayLabel; //DIC image first load
    
    int magnificationDisplayLabel; //Window control
    int mouseDragFlag; //Window control
    int mouseDownFlag; //Window control
    int xMovePositionHold; //Window control
    int yMovePositionHold; //Window control
    double boxStartX; //Box position for display
    double boxStartY; //Box position for display
    double boxEndX; //Box position for display
    double boxEndY; //Box position for display
    double boxStartImageX; //Box position for print
    double boxStartImageY; //Box position for print
    double boxEndImageX; //Box position for print
    double boxEndImageY; //Box position for print
    
    double xPointDownDisplayLabel; //Window control
    double yPointDownDisplayLabel; //Window control
    double xPositionMoveDisplayLabel; //Window control
    double yPositionMoveDisplayLabel; //Window control
    double xPointDragDisplayLabel; //Window control
    double yPointDragDisplayLabel; //Window control
    double xPositionDisplayLabel; //Window control
    double yPositionDisplayLabel; //Window control
    double xPositionAdjustDisplayLabel; //Window control
    double yPositionAdjustDisplayLabel; //Window control
    double windowWidthDisplayLabel; //Window control
    double windowHeightDisplayLabel; //Window control
    
    IBOutlet NSImage *labelSetImage;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDragged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
