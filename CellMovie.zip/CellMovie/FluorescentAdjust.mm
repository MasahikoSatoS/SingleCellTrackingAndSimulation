//
//  FluorescentAdjust.m
//  CellMovie
//
//  Created by Masahiko Sato on 10/7/16.
//
//

#import "FluorescentAdjust.h"

NSString *notificationToFluorescentAdjust = @"notificationExecuteFluorescentAdjust";

@implementation FluorescentAdjust

- (id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self) {
        adjustImage = [[NSImage alloc] initWithContentsOfFile:@""];
        
        mouseDragFlag = 0;
        mouseDownFlag = 0;
        dragControl = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToFluorescentAdjust object:nil];
    }
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    if (imageLoadFlagFluorescent == 1){
        int newImageSize = 0;
        int counterIncrement = 0;
        
        if (imageSizeFluorescent <= 1000){
            newImageSize = imageSizeFluorescent;
            counterIncrement = 1;
        }
        else if (imageSizeFluorescent <= 4000){
            newImageSize = imageSizeFluorescent/2;
            counterIncrement = 2;
        }
        else{
            
            newImageSize = imageSizeFluorescent/4;
            counterIncrement = 4;
        }
        
        if (dicImageStatusFluorescent == 1 && referenceImageStatusFluorescent == 0){
            NSBitmapImageRep *bitmapReps = nil;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:newImageSize pixelsHigh:newImageSize bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:newImageSize*4 bitsPerPixel:32];
            
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            int readDataTemp = 0;
            
            for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                    readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                    
                    *bitmapData++ = (unsigned char)readDataTemp;
                    *bitmapData++ = (unsigned char)readDataTemp;
                    *bitmapData++ = (unsigned char)readDataTemp;
                    *bitmapData++ = 0;
                }
            }
            
            adjustImage = [[NSImage alloc] initWithSize:NSMakeSize(imageSizeFluorescent, imageSizeFluorescent)];
            [adjustImage addRepresentation:bitmapReps];
        }
        else if (dicImageStatusFluorescent == 1 && referenceImageStatusFluorescent == 1){
            NSBitmapImageRep *bitmapReps = nil;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:newImageSize pixelsHigh:newImageSize bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:newImageSize*4 bitsPerPixel:32];
            
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            int readDataTemp = 0;
            int readDataTemp2 = 0;
            
            if (fluorescentColorNoFluorescent == 1){
                for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                        
                        if (counterY-yMovePositionHoldMain >= 0 && counterY-yMovePositionHoldMain < imageSizeFluorescent && counterX+xMovePositionHoldMain >= 0 && counterX+xMovePositionHoldMain < imageSizeFluorescent){
                            readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePositionHoldMain][counterX+xMovePositionHoldMain];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 < 0) readDataTemp2 = 0;
                            }
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        else readDataTemp2 = 0;
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoFluorescent == 2){
                for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                        
                        if (counterY-yMovePositionHoldMain >= 0 && counterY-yMovePositionHoldMain < imageSizeFluorescent && counterX+xMovePositionHoldMain >= 0 && counterX+xMovePositionHoldMain < imageSizeFluorescent){
                            readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePositionHoldMain][counterX+xMovePositionHoldMain];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 < 0) readDataTemp2 = 0;
                            }
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        else readDataTemp2 = 0;
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = 0;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoFluorescent == 3){
                for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                        
                        if (counterY-yMovePositionHoldMain >= 0 && counterY-yMovePositionHoldMain < imageSizeFluorescent && counterX+xMovePositionHoldMain >= 0 && counterX+xMovePositionHoldMain < imageSizeFluorescent){
                            readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePositionHoldMain][counterX+xMovePositionHoldMain];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 < 0) readDataTemp2 = 0;
                            }
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        else readDataTemp2 = 0;
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoFluorescent == 4){
                for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                        
                        if (counterY-yMovePositionHoldMain >= 0 && counterY-yMovePositionHoldMain < imageSizeFluorescent && counterX+xMovePositionHoldMain >= 0 && counterX+xMovePositionHoldMain < imageSizeFluorescent){
                            readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePositionHoldMain][counterX+xMovePositionHoldMain];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 < 0) readDataTemp2 = 0;
                            }
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        else readDataTemp2 = 0;
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoFluorescent == 5){
                for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                        
                        if (counterY-yMovePositionHoldMain >= 0 && counterY-yMovePositionHoldMain < imageSizeFluorescent && counterX+xMovePositionHoldMain >= 0 && counterX+xMovePositionHoldMain < imageSizeFluorescent){
                            readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePositionHoldMain][counterX+xMovePositionHoldMain];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 < 0) readDataTemp2 = 0;
                            }
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        else readDataTemp2 = 0;
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoFluorescent == 6){
                for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                        
                        if (counterY-yMovePositionHoldMain >= 0 && counterY-yMovePositionHoldMain < imageSizeFluorescent && counterX+xMovePositionHoldMain >= 0 && counterX+xMovePositionHoldMain < imageSizeFluorescent){
                            readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePositionHoldMain][counterX+xMovePositionHoldMain];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 < 0) readDataTemp2 = 0;
                            }
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        else readDataTemp2 = 0;
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = 0;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoFluorescent == 7){
                for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                        
                        if (counterY-yMovePositionHoldMain >= 0 && counterY-yMovePositionHoldMain < imageSizeFluorescent && counterX+xMovePositionHoldMain >= 0 && counterX+xMovePositionHoldMain < imageSizeFluorescent){
                            readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePositionHoldMain][counterX+xMovePositionHoldMain];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 < 0) readDataTemp2 = 0;
                            }
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        else readDataTemp2 = 0;
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.674));
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoFluorescent == 8){
                for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                        
                        if (counterY-yMovePositionHoldMain >= 0 && counterY-yMovePositionHoldMain < imageSizeFluorescent && counterX+xMovePositionHoldMain >= 0 && counterX+xMovePositionHoldMain < imageSizeFluorescent){
                            readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePositionHoldMain][counterX+xMovePositionHoldMain];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 < 0) readDataTemp2 = 0;
                            }
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        else readDataTemp2 = 0;
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.627));
                            *bitmapData++ = (unsigned char)(unsigned char)((int)(readDataTemp2*(double)0.125));
                            *bitmapData++ = (unsigned char)(unsigned char)((int)(readDataTemp2*(double)0.941));
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoFluorescent == 9){
                for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                        
                        if (counterY-yMovePositionHoldMain >= 0 && counterY-yMovePositionHoldMain < imageSizeFluorescent && counterX+xMovePositionHoldMain >= 0 && counterX+xMovePositionHoldMain < imageSizeFluorescent){
                            readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePositionHoldMain][counterX+xMovePositionHoldMain];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 < 0) readDataTemp2 = 0;
                            }
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        else readDataTemp2 = 0;
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.529));
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.808));
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.922));
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            
            adjustImage = [[NSImage alloc] initWithSize:NSMakeSize(imageSizeFluorescent, imageSizeFluorescent)];
            [adjustImage addRepresentation:bitmapReps];
        }
        
        if (imageFirstLoadFlagDisplayFluorescent == 0){
            xPositionDisplayFluorescent = 0;
            yPositionDisplayFluorescent = 0;
            xPositionAdjustDisplayFluorescent = 0;
            yPositionAdjustDisplayFluorescent = 0;
            magnificationDisplayFluorescent = 10;
            imageFirstLoadFlagDisplayFluorescent = 1;
        }
        
        //----Window size and Position re-adjust----
        int vertical = 500+78;
        int horizontal = 500;
        
        windowWidthDisplayFluorescent = imageSizeFluorescent/(double)horizontal;
        windowHeightDisplayFluorescent = imageSizeFluorescent/(double)(vertical-78);
        
        xPositionAdjustDisplayFluorescent = (imageSizeFluorescent-imageSizeFluorescent/(double)(magnificationDisplayFluorescent*0.1))/(double)2;
        yPositionAdjustDisplayFluorescent = (imageSizeFluorescent-imageSizeFluorescent/(double)(magnificationDisplayFluorescent*0.1))/(double)2;
    }
    
    [self setNeedsDisplay:YES];
}

-(void)mouseDown:(NSEvent *)event{
    if (lastTIFRoundNo != 0 && imageLoadFlagFluorescent == 1){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDownDisplayFluorescent = clickPoint.x;
        yPointDownDisplayFluorescent = clickPoint.y;
        
        xMovePositionHold = 0;
        yMovePositionHold = 0;
        dragHoldFlag = 0;
    }
}

-(void)mouseUp:(NSEvent *)event{
    if (lastTIFRoundNo != 0 && imageLoadFlagFluorescent == 1){
        xPositionDisplayFluorescent = xPositionDisplayFluorescent+xPositionMoveDisplayFluorescent;
        yPositionDisplayFluorescent = yPositionDisplayFluorescent+yPositionMoveDisplayFluorescent;
        
        xPositionMoveDisplayFluorescent = 0;
        yPositionMoveDisplayFluorescent = 0;
        mouseDragFlag = 0;
        mouseDownFlag = 0;
        
        if (dragHoldFlag == 1){
            xMovePositionHoldMain = xMovePositionHold;
            yMovePositionHoldMain = yMovePositionHold;
        }
        
        [self setNeedsDisplay:YES];
    }
}

-(void)mouseDragged:(NSEvent *)event{
    if (lastTIFRoundNo != 0 && imageLoadFlagFluorescent == 1){
        NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDragDisplayFluorescent = clickPoint.x;
        yPointDragDisplayFluorescent = clickPoint.y;
        
        if (imageMoveStatusFluorescent == 0){
            xPositionMoveDisplayFluorescent = (xPointDownDisplayFluorescent-xPointDragDisplayFluorescent)*windowWidthDisplayFluorescent/(double)(magnificationDisplayFluorescent*0.1);
            yPositionMoveDisplayFluorescent = (yPointDownDisplayFluorescent-yPointDragDisplayFluorescent)*windowHeightDisplayFluorescent/(double)(magnificationDisplayFluorescent*0.1);
        }
        else if (imageMoveStatusFluorescent == 1 && dragControl == 0){
            dragControl = 1;
            dragHoldFlag = 1;
            
            int xMovePosition = xMovePositionHoldMain+(int)((xPointDownDisplayFluorescent-xPointDragDisplayFluorescent)*windowWidthDisplayFluorescent/(double)(magnificationDisplayFluorescent*0.1));
            int yMovePosition = yMovePositionHoldMain+(int)((yPointDownDisplayFluorescent-yPointDragDisplayFluorescent)*windowHeightDisplayFluorescent/(double)(magnificationDisplayFluorescent*0.1));
            
            xMovePositionHold = xMovePosition;
            yMovePositionHold = yMovePosition;
            
            int newImageSize = 0;
            int counterIncrement = 0;
            
            if (imageSizeFluorescent <= 1000){
                newImageSize = imageSizeFluorescent;
                counterIncrement = 1;
            }
            else if (imageSizeFluorescent <= 4000){
                newImageSize = imageSizeFluorescent/2;
                counterIncrement = 2;
            }
            else{
                
                newImageSize = imageSizeFluorescent/4;
                counterIncrement = 4;
            }
            
            NSBitmapImageRep *bitmapReps = nil;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:newImageSize pixelsHigh:newImageSize bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:newImageSize*4 bitsPerPixel:32];
            
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            int readDataTemp = 0;
            int readDataTemp2 = 0;
            
            if (fluorescentColorNoFluorescent == 1){
                for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                        readDataTemp2 = -1;
                        
                        if (counterY-yMovePosition >= 0 && counterY-yMovePosition < imageSizeFluorescent && counterX+xMovePosition >= 0 && counterX+xMovePosition < imageSizeFluorescent){
                            readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePosition][counterX+xMovePosition];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 < 0) readDataTemp2 = 0;
                            }
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoFluorescent == 2){
                for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                        readDataTemp2 = -1;
                        
                        if (counterY-yMovePosition >= 0 && counterY-yMovePosition < imageSizeFluorescent && counterX+xMovePosition >= 0 && counterX+xMovePosition < imageSizeFluorescent){
                            readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePosition][counterX+xMovePosition];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 < 0) readDataTemp2 = 0;
                            }
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = 0;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoFluorescent == 3){
                for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                        readDataTemp2 = -1;
                        
                        if (counterY-yMovePosition >= 0 && counterY-yMovePosition < imageSizeFluorescent && counterX+xMovePosition >= 0 && counterX+xMovePosition < imageSizeFluorescent){
                            readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePosition][counterX+xMovePosition];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 < 0) readDataTemp2 = 0;
                            }
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoFluorescent == 4){
                for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                        readDataTemp2 = -1;
                        
                        if (counterY-yMovePosition >= 0 && counterY-yMovePosition < imageSizeFluorescent && counterX+xMovePosition >= 0 && counterX+xMovePosition < imageSizeFluorescent){
                            readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePosition][counterX+xMovePosition];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 < 0) readDataTemp2 = 0;
                            }
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoFluorescent == 5){
                for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                        readDataTemp2 = -1;
                        
                        if (counterY-yMovePosition >= 0 && counterY-yMovePosition < imageSizeFluorescent && counterX+xMovePosition >= 0 && counterX+xMovePosition < imageSizeFluorescent){
                            readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePosition][counterX+xMovePosition];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 < 0) readDataTemp2 = 0;
                            }
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoFluorescent == 6){
                for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                        readDataTemp2 = -1;
                        
                        if (counterY-yMovePosition >= 0 && counterY-yMovePosition < imageSizeFluorescent && counterX+xMovePosition >= 0 && counterX+xMovePosition < imageSizeFluorescent){
                            readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePosition][counterX+xMovePosition];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 < 0) readDataTemp2 = 0;
                            }
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = 0;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoFluorescent == 7){
                for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                        readDataTemp2 = -1;
                        
                        if (counterY-yMovePosition >= 0 && counterY-yMovePosition < imageSizeFluorescent && counterX+xMovePosition >= 0 && counterX+xMovePosition < imageSizeFluorescent){
                            readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePosition][counterX+xMovePosition];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 < 0) readDataTemp2 = 0;
                            }
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)readDataTemp2;
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.674));
                            *bitmapData++ = 0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoFluorescent == 8){
                for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                        readDataTemp2 = -1;
                        
                        if (counterY-yMovePosition >= 0 && counterY-yMovePosition < imageSizeFluorescent && counterX+xMovePosition >= 0 && counterX+xMovePosition < imageSizeFluorescent){
                            readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePosition][counterX+xMovePosition];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 < 0) readDataTemp2 = 0;
                            }
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.627));
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.125));
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.941));
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            else if (fluorescentColorNoFluorescent == 9){
                for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                    for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                        readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                        readDataTemp2 = -1;
                        
                        if (counterY-yMovePosition >= 0 && counterY-yMovePosition < imageSizeFluorescent && counterX+xMovePosition >= 0 && counterX+xMovePosition < imageSizeFluorescent){
                            readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePosition][counterX+xMovePosition];
                            
                            if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 < 0) readDataTemp2 = 0;
                            }
                            else{
                                
                                readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                
                                if (readDataTemp2 > 255) readDataTemp2 = 255;
                            }
                        }
                        
                        if (readDataTemp2 <= 0){
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = (unsigned char)readDataTemp;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.529));
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.808));
                            *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.922));
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
            
            adjustImage = [[NSImage alloc] initWithSize:NSMakeSize(imageSizeFluorescent, imageSizeFluorescent)];
            [adjustImage addRepresentation:bitmapReps];
        }
        
        mouseDragFlag = 1;
        
        [self setNeedsDisplay:YES];
    }
}

-(void)keyDown:(NSEvent *)event{
    int keyCode = [event keyCode];
    
    if (lastTIFRoundNo != 0 && imageLoadFlagFluorescent == 1){
        //----Magnification Magnify----
        if (keyCode == 125){
            if (magnificationDisplayFluorescent >= 10 && magnificationDisplayFluorescent <= 490){
                if (magnificationDisplayFluorescent-10 < 10) magnificationDisplayFluorescent = 10;
                else magnificationDisplayFluorescent = magnificationDisplayFluorescent-10;
                
                xPositionAdjustDisplayFluorescent = -1*(imageSizeFluorescent/(double)(magnificationDisplayFluorescent*0.1)-imageSizeFluorescent)/(double)2;
                yPositionAdjustDisplayFluorescent = -1*(imageSizeFluorescent/(double)(magnificationDisplayFluorescent*0.1)-imageSizeFluorescent)/(double)2;
            }
            else if (magnificationDisplayFluorescent < 10) magnificationDisplayFluorescent = 10;
        }
        
        //----Magnification Reduction----
        if (keyCode == 126){
            if (magnificationDisplayFluorescent >= 10 && magnificationDisplayFluorescent <= 490){
                if (magnificationDisplayFluorescent+10 > 490) magnificationDisplayFluorescent = 490;
                else magnificationDisplayFluorescent = magnificationDisplayFluorescent+10;
                
                xPositionAdjustDisplayFluorescent = (imageSizeFluorescent-imageSizeFluorescent/(double)(magnificationDisplayFluorescent*0.1))/(double)2;
                yPositionAdjustDisplayFluorescent = (imageSizeFluorescent-imageSizeFluorescent/(double)(magnificationDisplayFluorescent*0.1))/(double)2;
            }
            else if (magnificationDisplayFluorescent > 490) magnificationDisplayFluorescent = 490;
        }
        
        if (keyCode == 6){
            xPositionDisplayFluorescent = 0;
            yPositionDisplayFluorescent = 0;
            xPositionAdjustDisplayFluorescent = 0;
            yPositionAdjustDisplayFluorescent = 0;
            magnificationDisplayFluorescent = 10;
            
            xPositionAdjustDisplayFluorescent = (imageSizeFluorescent-imageSizeFluorescent/(double)(magnificationDisplayFluorescent*0.1))/(double)2;
            yPositionAdjustDisplayFluorescent = (imageSizeFluorescent-imageSizeFluorescent/(double)(magnificationDisplayFluorescent*0.1))/(double)2;
            
            xMovePositionHoldMain = 0;
            yMovePositionHoldMain = 0;
            
            if (dicImageStatusFluorescent == 1 && referenceImageStatusFluorescent == 1){int newImageSize = 0;
                int counterIncrement = 0;
                
                if (imageSizeFluorescent <= 1000){
                    newImageSize = imageSizeFluorescent;
                    counterIncrement = 1;
                }
                else if (imageSizeFluorescent <= 4000){
                    newImageSize = imageSizeFluorescent/2;
                    counterIncrement = 2;
                }
                else{
                    
                    newImageSize = imageSizeFluorescent/4;
                    counterIncrement = 4;
                }
                
                NSBitmapImageRep *bitmapReps = nil;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:newImageSize pixelsHigh:newImageSize bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:newImageSize*4 bitsPerPixel:32];
                
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                int readDataTemp = 0;
                int readDataTemp2 = 0;
                
                if (fluorescentColorNoFluorescent == 1){
                    for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                        for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                            readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                            readDataTemp2 = -1;
                            
                            if (counterY-yMovePositionHoldMain >= 0 && counterY-yMovePositionHoldMain < imageSizeFluorescent && counterX+xMovePositionHoldMain >= 0 && counterX+xMovePositionHoldMain < imageSizeFluorescent){
                                readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePositionHoldMain][counterX+xMovePositionHoldMain];
                                
                                if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                    readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                    
                                    if (readDataTemp2 < 0) readDataTemp2 = 0;
                                }
                                else{
                                    
                                    readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                    
                                    if (readDataTemp2 > 255) readDataTemp2 = 255;
                                }
                            }
                            
                            if (readDataTemp2 <= 0){
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                *bitmapData++ = 0;
                                *bitmapData++ = 0;
                                *bitmapData++ = (unsigned char)readDataTemp2;
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
                else if (fluorescentColorNoFluorescent == 2){
                    for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                        for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                            readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                            readDataTemp2 = -1;
                            
                            if (counterY-yMovePositionHoldMain >= 0 && counterY-yMovePositionHoldMain < imageSizeFluorescent && counterX+xMovePositionHoldMain >= 0 && counterX+xMovePositionHoldMain < imageSizeFluorescent){
                                readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePositionHoldMain][counterX+xMovePositionHoldMain];
                                
                                if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                    readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                    
                                    if (readDataTemp2 < 0) readDataTemp2 = 0;
                                }
                                else{
                                    
                                    readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                    
                                    if (readDataTemp2 > 255) readDataTemp2 = 255;
                                }
                            }
                            
                            if (readDataTemp2 <= 0){
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                *bitmapData++ = 0;
                                *bitmapData++ = (unsigned char)readDataTemp2;
                                *bitmapData++ = 0;
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
                else if (fluorescentColorNoFluorescent == 3){
                    for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                        for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                            readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                            readDataTemp2 = -1;
                            
                            if (counterY-yMovePositionHoldMain >= 0 && counterY-yMovePositionHoldMain < imageSizeFluorescent && counterX+xMovePositionHoldMain >= 0 && counterX+xMovePositionHoldMain < imageSizeFluorescent){
                                readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePositionHoldMain][counterX+xMovePositionHoldMain];
                                
                                if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                    readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                    
                                    if (readDataTemp2 < 0) readDataTemp2 = 0;
                                }
                                else{
                                    
                                    readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                    
                                    if (readDataTemp2 > 255) readDataTemp2 = 255;
                                }
                            }
                            
                            if (readDataTemp2 <= 0){
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                *bitmapData++ = (unsigned char)readDataTemp2;
                                *bitmapData++ = (unsigned char)readDataTemp2;
                                *bitmapData++ = 0;
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
                else if (fluorescentColorNoFluorescent == 4){
                    for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                        for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                            readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                            readDataTemp2 = -1;
                            
                            if (counterY-yMovePositionHoldMain >= 0 && counterY-yMovePositionHoldMain < imageSizeFluorescent && counterX+xMovePositionHoldMain >= 0 && counterX+xMovePositionHoldMain < imageSizeFluorescent){
                                readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePositionHoldMain][counterX+xMovePositionHoldMain];
                                
                                if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                    readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                    
                                    if (readDataTemp2 < 0) readDataTemp2 = 0;
                                }
                                else{
                                    
                                    readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                    
                                    if (readDataTemp2 > 255) readDataTemp2 = 255;
                                }
                            }
                            
                            if (readDataTemp2 <= 0){
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                *bitmapData++ = (unsigned char)readDataTemp2;
                                *bitmapData++ = 0;
                                *bitmapData++ = 0;
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
                else if (fluorescentColorNoFluorescent == 5){
                    for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                        for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                            readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                            readDataTemp2 = -1;
                            
                            if (counterY-yMovePositionHoldMain >= 0 && counterY-yMovePositionHoldMain < imageSizeFluorescent && counterX+xMovePositionHoldMain >= 0 && counterX+xMovePositionHoldMain < imageSizeFluorescent){
                                readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePositionHoldMain][counterX+xMovePositionHoldMain];
                                
                                if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                    readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                    
                                    if (readDataTemp2 < 0) readDataTemp2 = 0;
                                }
                                else{
                                    
                                    readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                    
                                    if (readDataTemp2 > 255) readDataTemp2 = 255;
                                }
                            }
                            
                            if (readDataTemp2 <= 0){
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                *bitmapData++ = (unsigned char)readDataTemp2;
                                *bitmapData++ = 0;
                                *bitmapData++ = (unsigned char)readDataTemp2;
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
                else if (fluorescentColorNoFluorescent == 6){
                    for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                        for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                            readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                            readDataTemp2 = -1;
                            
                            if (counterY-yMovePositionHoldMain >= 0 && counterY-yMovePositionHoldMain < imageSizeFluorescent && counterX+xMovePositionHoldMain >= 0 && counterX+xMovePositionHoldMain < imageSizeFluorescent){
                                readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePositionHoldMain][counterX+xMovePositionHoldMain];
                                
                                if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                    readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                    
                                    if (readDataTemp2 < 0) readDataTemp2 = 0;
                                }
                                else{
                                    
                                    readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                    
                                    if (readDataTemp2 > 255) readDataTemp2 = 255;
                                }
                            }
                            
                            if (readDataTemp2 <= 0){
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                *bitmapData++ = 0;
                                *bitmapData++ = (unsigned char)readDataTemp2;
                                *bitmapData++ = (unsigned char)readDataTemp2;
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
                else if (fluorescentColorNoFluorescent == 7){
                    for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                        for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                            readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                            readDataTemp2 = -1;
                            
                            if (counterY-yMovePositionHoldMain >= 0 && counterY-yMovePositionHoldMain < imageSizeFluorescent && counterX+xMovePositionHoldMain >= 0 && counterX+xMovePositionHoldMain < imageSizeFluorescent){
                                readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePositionHoldMain][counterX+xMovePositionHoldMain];
                                
                                if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                    readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                    
                                    if (readDataTemp2 < 0) readDataTemp2 = 0;
                                }
                                else{
                                    
                                    readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                    
                                    if (readDataTemp2 > 255) readDataTemp2 = 255;
                                }
                            }
                            
                            if (readDataTemp2 <= 0){
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                *bitmapData++ = (unsigned char)readDataTemp2;
                                *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.674));
                                *bitmapData++ = 0;
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
                else if (fluorescentColorNoFluorescent == 8){
                    for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                        for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                            readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                            readDataTemp2 = -1;
                            
                            if (counterY-yMovePositionHoldMain >= 0 && counterY-yMovePositionHoldMain < imageSizeFluorescent && counterX+xMovePositionHoldMain >= 0 && counterX+xMovePositionHoldMain < imageSizeFluorescent){
                                readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePositionHoldMain][counterX+xMovePositionHoldMain];
                                
                                if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                    readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                    
                                    if (readDataTemp2 < 0) readDataTemp2 = 0;
                                }
                                else{
                                    
                                    readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                    
                                    if (readDataTemp2 > 255) readDataTemp2 = 255;
                                }
                            }
                            
                            if (readDataTemp2 <= 0){
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.627));
                                *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.125));
                                *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.941));
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
                else if (fluorescentColorNoFluorescent == 9){
                    for (int counterY = 0; counterY < imageSizeFluorescent; counterY = counterY+counterIncrement){
                        for (int counterX = 0; counterX < imageSizeFluorescent; counterX = counterX+counterIncrement){
                            readDataTemp = arrayDICImageForFluorescent [counterY][counterX];
                            readDataTemp2 = -1;
                            
                            if (counterY-yMovePositionHoldMain >= 0 && counterY-yMovePositionHoldMain < imageSizeFluorescent && counterX+xMovePositionHoldMain >= 0 && counterX+xMovePositionHoldMain < imageSizeFluorescent){
                                readDataTemp2 = arrayReferenceImageFluorescent [counterY-yMovePositionHoldMain][counterX+xMovePositionHoldMain];
                                
                                if (readDataTemp2 >= 0 && readDataTemp2 < baseCutFluorescent){
                                    readDataTemp2 = readDataTemp2-(int)((baseCutFluorescent-readDataTemp2)*fluorescentEnhanceFluorescent);
                                    
                                    if (readDataTemp2 < 0) readDataTemp2 = 0;
                                }
                                else{
                                    
                                    readDataTemp2 = readDataTemp2+(int)((readDataTemp2-baseCutFluorescent)*fluorescentEnhanceFluorescent);
                                    
                                    if (readDataTemp2 > 255) readDataTemp2 = 255;
                                }
                            }
                            
                            if (readDataTemp2 <= 0){
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = (unsigned char)readDataTemp;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.529));
                                *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.808));
                                *bitmapData++ = (unsigned char)((int)(readDataTemp2*(double)0.922));
                                *bitmapData++ = 0;
                            }
                        }
                    }
                }
                
                adjustImage = [[NSImage alloc] initWithSize:NSMakeSize(imageSizeFluorescent, imageSizeFluorescent)];
                [adjustImage addRepresentation:bitmapReps];
            }
        }
        
        [self setNeedsDisplay:YES];
    }
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect{
    if (imageFirstLoadFlagDisplayFluorescent == 1){
        NSRect srcRect;
        srcRect.origin.x = xPositionDisplayFluorescent+xPositionAdjustDisplayFluorescent+xPositionMoveDisplayFluorescent;
        srcRect.origin.y = yPositionDisplayFluorescent+yPositionAdjustDisplayFluorescent+yPositionMoveDisplayFluorescent;
        srcRect.size.width = imageSizeFluorescent/(double)(magnificationDisplayFluorescent*0.1);
        srcRect.size.height = imageSizeFluorescent/(double)(magnificationDisplayFluorescent*0.1);
        
        [adjustImage drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
        
        dragControl = 0;
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToFluorescentAdjust object:nil];
}

@end
