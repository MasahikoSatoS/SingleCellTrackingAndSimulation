//
//  LabelSet.mm
//  CellMovie
//
//  Created by Masahiko Sato on 2022-02-01.
//

#import "LabelSet.h"

NSString *notificationToLabelSet = @"notificationExecuteLabelSet";

@implementation LabelSet

-(id)init{
    self = [super init];
    
    if (self != nil){
        progressTimingL = 0;
        textChangeDisplayCall = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToLabelSet object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    labelSetWindController = [[NSWindowController alloc] initWithWindowNibName:@"AddLabel"];
    [labelSetWindController showWindow:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLabelSetDisplay object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [labelSetWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [labelSetWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [labelDisplayX1 setDelegate:self];
    [labelDisplayY1 setDelegate:self];
    [labelDisplayPrint1 setDelegate:self];
    
    [labelDisplayX2 setDelegate:self];
    [labelDisplayY2 setDelegate:self];
    [labelDisplayPrint2 setDelegate:self];
    
    [incrementDisplayX setDelegate:self];
    [incrementDisplayY setDelegate:self];
    [incrementDisplayInterval setDelegate:self];
    [incrementDisplayStart setDelegate:self];
    
    [scaleDisplayX setDelegate:self];
    [scaleDisplayY setDelegate:self];
    [scaleDisplayLength setDelegate:self];
    
    labelSetTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.3 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    //-----XY position display----
    if (xyPositionLabelCall1 == 1){
        if (currentActiveHold == 1){
            [labelDisplayX1 setIntegerValue:xPositionExHold];
            
            NSString *treatNSString = [labelDisplayX1 stringValue];
            
            if (treatNSString != NULL){
                int valueTemp = [labelDisplayX1 intValue];
                
                if (xPositionExHold == valueTemp) xyPositionLabelCall1 = 0;
            }
        }
        else if (currentActiveHold == 2){
            [labelDisplayX2 setIntegerValue:xPositionExHold];
            
            NSString *treatNSString = [labelDisplayX2 stringValue];
            
            if (treatNSString != NULL){
                int valueTemp = [labelDisplayX2 intValue];
                
                if (xPositionExHold == valueTemp) xyPositionLabelCall1 = 0;
            }
        }
        else if (currentActiveHold == 3){
            [incrementDisplayX setIntegerValue:xPositionExHold];
            
            NSString *treatNSString = [incrementDisplayX stringValue];
            
            if (treatNSString != NULL){
                int valueTemp = [incrementDisplayX intValue];
                
                if (xPositionExHold == valueTemp) xyPositionLabelCall1 = 0;
            }
        }
        else if (currentActiveHold == 4){
            [scaleDisplayX setIntegerValue:xPositionExHold];
            
            NSString *treatNSString = [scaleDisplayX stringValue];
            
            if (treatNSString != NULL){
                int valueTemp = [scaleDisplayX intValue];
                
                if (xPositionExHold == valueTemp) xyPositionLabelCall1 = 0;
            }
        }
    }
    
    if (xyPositionLabelCall2 == 1){
        if (currentActiveHold == 1){
            [labelDisplayY1 setIntegerValue:yPositionExHold];
            
            NSString *treatNSString = [labelDisplayY1 stringValue];
            
            if (treatNSString != NULL){
                int valueTemp = [labelDisplayY1 intValue];
                
                if (yPositionExHold == valueTemp) xyPositionLabelCall2 = 0;
            }
        }
        else if (currentActiveHold == 2){
            [labelDisplayY2 setIntegerValue:yPositionExHold];
            
            NSString *treatNSString = [labelDisplayY2 stringValue];
            
            if (treatNSString != NULL){
                int valueTemp = [labelDisplayY2 intValue];
                
                if (yPositionExHold == valueTemp) xyPositionLabelCall2 = 0;
            }
        }
        else if (currentActiveHold == 3){
            [incrementDisplayY setIntegerValue:yPositionExHold];
            
            NSString *treatNSString = [incrementDisplayY stringValue];
            
            if (treatNSString != NULL){
                int valueTemp = [incrementDisplayY intValue];
                
                if (yPositionExHold == valueTemp) xyPositionLabelCall2 = 0;
            }
        }
        else if (currentActiveHold == 4){
            [scaleDisplayY setIntegerValue:yPositionExHold];
            
            NSString *treatNSString = [scaleDisplayY stringValue];
            
            if (treatNSString != NULL){
                int valueTemp = [scaleDisplayY intValue];
                
                if (yPositionExHold == valueTemp) xyPositionLabelCall2 = 0;
            }
        }
    }
    
    //-----Display call for text change-----
    if (textChangeDisplayCall == 1){
        textChangeDisplayCall  = 0;
        
        if (imageLoadFlagLabel == 1 && imageLoadingFlag == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLabelSetDisplay object:self];
        }
    }
    
    //-----Create image files----
    if (exportTiming == 101){
        exportTiming = 102;
        copyProgressFlag = 1;
        
        labeledSaveImageCount = 1;
        nextLoadImageCount = filePosition;
        fluorescentLevelCount = 0;
        incrementAccumulate = 0;
        
        if (labelImageStatus == 1){
            for (int counter1 = 0; counter1 < imageSizeLabelHold+5; counter1++){
                delete [] arrayLabelImage [counter1];
            }
            
            delete [] arrayLabelImage;
        }
        
        imageSizeLabelHold = imageXYLength;
        
        arrayLabelImage = new int *[imageXYLength+5];
        labelImageStatus = 1;
        
        for (int counter1 = 0; counter1 < imageXYLength+5; counter1++){
            if (grayColorStatus == 0) arrayLabelImage [counter1] = new int [imageXYLength+5];
            else if (grayColorStatus == 1) arrayLabelImage [counter1] = new int [imageXYLength*3+5];
        }
        
        exportTiming = 103;
    }
    else if (exportTiming >= 103 && exportTiming < 110){
        exportTiming++;
    }
    else if (exportTiming == 110){
        exportTiming = 111;
        exportFlag = 1;
        
        if (grayColorStatus == 0){
            for (int counter1 = 0; counter1 < imageXYLength+5; counter1++){
                for (int counter2 = 0; counter2 < imageXYLength+5; counter2++){
                    arrayLabelImage [counter1][counter2] = 0;
                }
            }
        }
        else if (grayColorStatus == 1){
            for (int counter1 = 0; counter1 < imageXYLength+5; counter1++){
                for (int counter2 = 0; counter2 < imageXYLength*3+5; counter2++){
                    arrayLabelImage [counter1][counter2] = 0;
                }
            }
        }
        
        int fileTypeTifBmp = 0;
        
        if ((int)fileList [(filePosition-1)*7].find("tif") != -1) fileTypeTifBmp = 0;
        else if ((int)fileList [(filePosition-1)*7].find("bmp") != -1) fileTypeTifBmp = 1;
        
        string imageMoviePath = imageDisplayPath+"/"+fileList [(nextLoadImageCount-1)*7+fluorescentLevelCount];
        
        ifstream fin;
        
        if (fileTypeTifBmp == 0){
            unsigned long stripFirstAddress = 0;
            unsigned long stripByteCountAddress = 0;
            unsigned long nextAddress = 0;
            unsigned long headPosition = 0;
            unsigned long stripEntry = 0;
            long sizeForCopy = 0;
            
            double xPosition = 0;
            double yPosition = 0;
            
            int imageWidth = 0;
            int imageHeight = 0;
            int imageBit = 0; // Check 8, 16
            int imageCompression = 0; // Check 1
            int photoMetric = 0; //check 0, 1, 2
            int imageDimensionTif = 0;
            int verticalBmp = 0;
            int horizontalBmp = 0;
            int horizontalBmpEntry = 0;
            int endianType = 0;
            int samplePerPix = 0;
            int dataConversion [4];
            int processTypeTif = 1;
            int numberOfLayers = 0;
            
            struct stat sizeOfFile;
            
            if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                fileReadArray = new uint8_t [sizeForCopy+4];
                fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                
                fin.read((char*)fileReadArray, sizeForCopy+4);
                fin.close();
                
                dataConversion [0] = fileReadArray [0];
                dataConversion [1] = fileReadArray [1];
                
                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                else endianType = 0;
                
                int *arrayExtractedImage3 = new int [100];
                
                headPosition = 0;
                
                if (endianType == 1){
                    dataConversion [0] = fileReadArray [7];
                    dataConversion [1] = fileReadArray [6];
                    dataConversion [2] = fileReadArray [5];
                    dataConversion [3] = fileReadArray [4];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                else if (endianType == 0){
                    dataConversion [0] = fileReadArray [4];
                    dataConversion [1] = fileReadArray [5];
                    dataConversion [2] = fileReadArray [6];
                    dataConversion [3] = fileReadArray [7];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                
                if (endianType == 1){
                    tiffFileRead = [[TiffFileRead alloc] init];
                    [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                    
                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                        if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                        else imageDimensionTif = imageHeight;
                        
                        tiffFileRead = [[TiffFileRead alloc] init];
                        delete [] arrayExtractedImage3;
                        
                        arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                    }
                }
                else if (endianType == 0){
                    tiffFileRead = [[TiffFileRead alloc] init];
                    [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                    
                    if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                        if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                        else imageDimensionTif = imageHeight;
                        
                        tiffFileRead = [[TiffFileRead alloc] init];
                        delete [] arrayExtractedImage3;
                        
                        arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                    }
                }
                
                if (imageDimensionTif != 0){
                    horizontalBmp = 0;
                    horizontalBmpEntry = 0;
                    
                    for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                        if (photoMetric == 1){
                            if (horizontalBmp < imageWidth){
                                arrayLabelImage [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3], horizontalBmpEntry++;
                                horizontalBmp++;
                            }
                            
                            if (horizontalBmp == imageWidth){
                                horizontalBmp = 0;
                                horizontalBmpEntry = 0;
                                verticalBmp++;
                            }
                        }
                        else if (photoMetric == 2){
                            if (horizontalBmp < imageWidth){
                                arrayLabelImage [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3], horizontalBmpEntry++;
                                arrayLabelImage [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3+1], horizontalBmpEntry++;
                                arrayLabelImage [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3+2], horizontalBmpEntry++;
                                horizontalBmp++;
                            }
                            
                            if (horizontalBmp == imageWidth){
                                horizontalBmp = 0;
                                horizontalBmpEntry = 0;
                                verticalBmp++;
                            }
                        }
                    }
                }
                
                delete [] fileReadArray;
                delete [] arrayExtractedImage3;
            }
        }
        else{
            
            long sizeForCopy = 0;
            
            struct stat sizeOfFile;
            
            if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    fin.read((char*)uploadTempA, sizeForCopy+1);
                    fin.close();
                    
                    int imageDimensionReadCount = 0;
                    
                    for (int counter1 = imageXYLength-1; counter1 >= 0; counter1--){
                        for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                            arrayLabelImage [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageXYLength+counter2];
                        }
                        
                        imageDimensionReadCount++;
                    }
                }
                
                delete [] uploadTempA;
            }
        }
        
        string nameExtension;
        
        if (fluorescentLevelCount > 0){
            nameExtension = fileList [(nextLoadImageCount-1)*7+fluorescentLevelCount].substr(13);
            nameExtension = nameExtension.substr(0, nameExtension.length()-4);
        }
        
        string extension2 = to_string (labeledSaveImageCount);
        
        if (extension2.length() == 1) extension2 = "000"+extension2;
        else if (extension2.length() == 2) extension2 = "00"+extension2;
        else if (extension2.length() == 3) extension2 = "0"+extension2;
        
        if (fluorescentLevelCount == 0) labelImageSavePath2 = labelImageSavePath+"/"+"STimage "+extension2+".tif";
        else labelImageSavePath2 = labelImageSavePath+"/"+"STimage "+extension2+"_"+nameExtension+".tif";
        
        exportTiming = 112;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLabelSetDisplay object:self];
    }
    else if (exportTiming >= 113 && exportTiming < 120){
        exportTiming++;
    }
    else if (exportTiming == 120){
        exportTiming = 121;
    }
    else if (exportTiming == 121){
        fluorescentLevelCount++;
        
        if (fileList [(nextLoadImageCount-1)*7+fluorescentLevelCount] == "") fluorescentLevelCount = 0;
        if (fluorescentLevelCount == 7) fluorescentLevelCount = 0;
        
        if (fluorescentLevelCount == 0){
            nextLoadImageCount++;
            labeledSaveImageCount++;
            incrementAccumulate = incrementAccumulate+incrementValue;
        }
        
        if (nextLoadImageCount > maxImageNo || printStop == 1) exportTiming = 150;
        else exportTiming = 110;
    }
    else if (exportTiming == 150){
        exportTiming = 0;
        exportFlag = 0;
        printStop = 0;
        copyProgressFlag = 0;
        imageLoadFlagLabel = 0;
        saveExport = 0;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(void)controlTextDidChange:(NSNotification *)aNotification{
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == labelDisplayX1){
            if ([labelDisplayX1 intValue] > 0 && [labelDisplayX1 intValue] <= imageXYLength){
                labelX1 = [labelDisplayX1 intValue];
                textChangeDisplayCall = 1;
            }
            else [labelDisplayX1 setIntegerValue:labelX1];
        }
    }
    
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == labelDisplayY1){
            if ([labelDisplayY1 intValue] > 0 && [labelDisplayY1 intValue] <= imageXYLength){
                labelY1 = [labelDisplayY1 intValue];
                textChangeDisplayCall = 1;
            }
            else [labelDisplayY1 setIntegerValue:labelY1];
        }
    }
    
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == labelDisplayPrint1){
            NSString *labelDisplayPrint = [labelDisplayPrint1 stringValue];
            string labelPrintString = [labelDisplayPrint UTF8String];
            
            if (labelPrintString.length() <= 100){
                labelPrint1 = labelPrintString;
                textChangeDisplayCall = 1;
            }
            else [labelDisplayPrint1 setStringValue:@(labelPrint1.c_str())];
        }
    }
    
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == labelDisplayX2){
            if ([labelDisplayX2 intValue] > 0 && [labelDisplayX2 intValue] <= imageXYLength){
                labelX2 = [labelDisplayX2 intValue];
                textChangeDisplayCall = 1;
            }
            else [labelDisplayX2 setIntegerValue:labelX2];
        }
    }
    
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == labelDisplayY2){
            if ([labelDisplayY2 intValue] > 0 && [labelDisplayY2 intValue] <= imageXYLength){
                labelY2 = [labelDisplayY2 intValue];
                textChangeDisplayCall = 1;
            }
            else [labelDisplayY2 setIntegerValue:labelY2];
        }
    }
    
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == labelDisplayPrint2){
            NSString *labelDisplayPrint = [labelDisplayPrint2 stringValue];
            string labelPrintString = [labelDisplayPrint UTF8String];
            
            if (labelPrintString.length() <= 100){
                labelPrint2 = labelPrintString;
                textChangeDisplayCall = 1;
            }
            else [labelDisplayPrint2 setStringValue:@(labelPrint2.c_str())];
        }
    }
    
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == incrementDisplayX){
            if ([incrementDisplayX intValue] > 0 && [incrementDisplayX intValue] <= imageXYLength){
                incrementX = [incrementDisplayX intValue];
                textChangeDisplayCall = 1;
            }
            else [incrementDisplayX setIntegerValue:incrementX];
        }
    }
    
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == incrementDisplayY){
            if ([incrementDisplayY intValue] > 0 && [incrementDisplayY intValue] <= imageXYLength){
                incrementY = [incrementDisplayY intValue];
                textChangeDisplayCall = 1;
            }
            else [incrementDisplayY setIntegerValue:incrementY];
        }
    }
    
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == incrementDisplayInterval){
            if ([incrementDisplayInterval intValue] >= 0 && [incrementDisplayInterval intValue] <= 1000){
                incrementValue = [incrementDisplayInterval intValue];
            }
            else [incrementDisplayInterval setIntegerValue:incrementValue];
        }
    }
    
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == incrementDisplayStart){
            if ([incrementDisplayStart intValue] >= 1 && [incrementDisplayStart intValue] <= maxImageNo){
                incrementStart = [incrementDisplayStart intValue];
            }
            else [incrementDisplayStart setIntegerValue:incrementStart];
        }
    }
    
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == scaleDisplayX){
            if ([scaleDisplayX intValue] >= 1 && [scaleDisplayX intValue] <= imageXYLength){
                scaleBarX = [scaleDisplayX intValue];
                textChangeDisplayCall = 1;
            }
            else [scaleDisplayX setIntegerValue:scaleBarX];
        }
    }
    
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == scaleDisplayY){
            if ([scaleDisplayY intValue] >= 1 && [scaleDisplayY intValue] <= imageXYLength){
                scaleBarY = [scaleDisplayY intValue];
                textChangeDisplayCall = 1;
            }
            else [scaleDisplayY setIntegerValue:scaleBarY];
        }
    }
    
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == scaleDisplayLength){
            if ([scaleDisplayLength intValue] >= 1 && [scaleDisplayLength intValue] <= imageXYLength){
                scaleBarLength = [scaleDisplayLength intValue];
                textChangeDisplayCall = 1;
            }
            else [scaleDisplayLength setIntegerValue:scaleBarLength];
        }
    }
}

-(IBAction)saveImage:(id)sender{
    if (copyProgressFlag == 0 && imageLoadingFlag == 0){
        if (imageXYLength != 0 && movieRunningFlag == 0){
            if (imageLoadFlagLabel == 1){
                if (exportFlag == 0){
                    string entry;
                    string extractString;
                    int maxEntryNo = 0;
                    
                    DIR *dir;
                    struct dirent *dent;
                    
                    dir = opendir(imageDataPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("LabeledImage") != -1){
                                if (entry.substr(12, 1) == "_"){
                                    if (maxEntryNo == 0) maxEntryNo = 1;
                                }
                                else extractString = entry.substr(12, entry.find("_Image")-12);
                                
                                if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    saveExport = 1;
                    
                    maxEntryNo++;
                    
                    string resultSavePath;
                    
                    if (maxEntryNo == 1){
                        resultSavePath = imageDataPath+"/LabeledImage_Image";
                        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    }
                    else{
                        
                        resultSavePath = imageDataPath+"/LabeledImage"+to_string(maxEntryNo)+"_Image";
                        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    }
                    
                    labelImageSavePath = resultSavePath+"/LabeledImage_Stitch";
                    mkdir(labelImageSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    exportTiming = 101;
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Image Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Movie On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy/Image Loading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)exportImage:(id)sender{
    if (copyProgressFlag == 0 && imageLoadingFlag == 0){
        if (imageXYLength != 0 && movieRunningFlag == 0){
            if (imageLoadFlagLabel == 1){
                if (exportFlag == 0){
                    string entry;
                    string extractString;
                    int maxEntryNo = 0;
                    
                    string imageDesktopPath = "/Users/"+pathNameString+"/Desktop";
                    
                    DIR *dir;
                    struct dirent *dent;
                    
                    dir = opendir(imageDesktopPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("LabeledImage") != -1){
                                if (entry.substr(12, 1) == "_"){
                                    if (maxEntryNo == 0) maxEntryNo = 1;
                                }
                                else extractString = entry.substr(12, entry.find("_Image")-12);
                                
                                if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    saveExport = 2;
                    
                    maxEntryNo++;
                    
                    string resultSavePath;
                    
                    if (maxEntryNo == 1){
                        resultSavePath = imageDesktopPath+"/LabeledImage_Image";
                        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    }
                    else{
                        
                        resultSavePath = imageDesktopPath+"/LabeledImage"+to_string(maxEntryNo)+"_Image";
                        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    }
                    
                    labelImageSavePath = resultSavePath+"/LabeledImage_Stitch";
                    mkdir(labelImageSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    exportTiming = 101;
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Image Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Movie On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy/Image Loading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageLoad:(id)sender{
    if (copyProgressFlag == 0 && imageLoadingFlag == 0){
        if (imageXYLength != 0 && movieRunningFlag == 0){
            if (imageLoadFlagLabel == 0){
                if (labelImageStatus == 1){
                    for (int counter1 = 0; counter1 < imageSizeLabelHold+5; counter1++){
                        delete [] arrayLabelImage [counter1];
                    }
                    
                    delete [] arrayLabelImage;
                }
                
                imageSizeLabelHold = imageXYLength;
                
                arrayLabelImage = new int *[imageXYLength+5];
                labelImageStatus = 1;
                
                for (int counter1 = 0; counter1 < imageXYLength+5; counter1++){
                    if (grayColorStatus == 0) arrayLabelImage [counter1] = new int [imageXYLength+5];
                    else if (grayColorStatus == 1) arrayLabelImage [counter1] = new int [imageXYLength*3+5];
                }
                
                if (grayColorStatus == 0){
                    for (int counter1 = 0; counter1 < imageXYLength+5; counter1++){
                        for (int counter2 = 0; counter2 < imageXYLength+5; counter2++){
                            arrayLabelImage [counter1][counter2] = 0;
                        }
                    }
                }
                else if (grayColorStatus == 1){
                    for (int counter1 = 0; counter1 < imageXYLength+5; counter1++){
                        for (int counter2 = 0; counter2 < imageXYLength*3+5; counter2++){
                            arrayLabelImage [counter1][counter2] = 0;
                        }
                    }
                }
                
                int fileTypeTifBmp = 0;
                
                if ((int)fileList [(filePosition-1)*7].find("tif") != -1) fileTypeTifBmp = 0;
                else if ((int)fileList [(filePosition-1)*7].find("bmp") != -1) fileTypeTifBmp = 1;
                
                string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7];
                
                ifstream fin;
                
                if (fileTypeTifBmp == 0){
                    unsigned long stripFirstAddress = 0;
                    unsigned long stripByteCountAddress = 0;
                    unsigned long nextAddress = 0;
                    unsigned long headPosition = 0;
                    unsigned long stripEntry = 0;
                    long sizeForCopy = 0;
                    
                    double xPosition = 0;
                    double yPosition = 0;
                    
                    int imageWidth = 0;
                    int imageHeight = 0;
                    int imageBit = 0; // Check 8, 16
                    int imageCompression = 0; // Check 1
                    int photoMetric = 0; //check 0, 1, 2
                    int imageDimensionTif = 0;
                    int verticalBmp = 0;
                    int horizontalBmp = 0;
                    int horizontalBmpEntry = 0;
                    int endianType = 0;
                    int samplePerPix = 0;
                    int dataConversion [4];
                    int processTypeTif = 1;
                    int numberOfLayers = 0;
                    
                    struct stat sizeOfFile;
                    
                    if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        fileReadArray = new uint8_t [sizeForCopy+4];
                        fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                        
                        fin.read((char*)fileReadArray, sizeForCopy+4);
                        fin.close();
                        
                        dataConversion [0] = fileReadArray [0];
                        dataConversion [1] = fileReadArray [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        int *arrayExtractedImage3 = new int [100];
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = fileReadArray [7];
                            dataConversion [1] = fileReadArray [6];
                            dataConversion [2] = fileReadArray [5];
                            dataConversion [3] = fileReadArray [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = fileReadArray [4];
                            dataConversion [1] = fileReadArray [5];
                            dataConversion [2] = fileReadArray [6];
                            dataConversion [3] = fileReadArray [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        if (endianType == 1){
                            tiffFileRead = [[TiffFileRead alloc] init];
                            [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            
                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                else imageDimensionTif = imageHeight;
                                
                                tiffFileRead = [[TiffFileRead alloc] init];
                                delete [] arrayExtractedImage3;
                                
                                arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                            }
                        }
                        else if (endianType == 0){
                            tiffFileRead = [[TiffFileRead alloc] init];
                            [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            
                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                if (imageWidth > imageHeight) imageDimensionTif = imageWidth;
                                else imageDimensionTif = imageHeight;
                                
                                tiffFileRead = [[TiffFileRead alloc] init];
                                delete [] arrayExtractedImage3;
                                
                                arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimensionTif:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processTypeTif];
                            }
                        }
                        
                        if (imageDimensionTif != 0){
                            horizontalBmp = 0;
                            horizontalBmpEntry = 0;
                            verticalBmp = 0;
                            
                            for (int counter3 = 0; counter3 < imageWidth*imageHeight; counter3++){
                                if (photoMetric == 1){
                                    if (horizontalBmp < imageWidth){
                                        arrayLabelImage [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3], horizontalBmpEntry++;
                                        horizontalBmp++;
                                    }
                                    
                                    if (horizontalBmp == imageWidth){
                                        horizontalBmp = 0;
                                        horizontalBmpEntry = 0;
                                        verticalBmp++;
                                    }
                                }
                                else if (photoMetric == 2){
                                    if (horizontalBmp < imageWidth){
                                        arrayLabelImage [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3], horizontalBmpEntry++;
                                        arrayLabelImage [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3+1], horizontalBmpEntry++;
                                        arrayLabelImage [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3+2], horizontalBmpEntry++;
                                        
                                        horizontalBmp++;
                                    }
                                    
                                    if (horizontalBmp == imageWidth){
                                        horizontalBmp = 0;
                                        horizontalBmpEntry = 0;
                                        verticalBmp++;
                                    }
                                }
                            }
                        }
                        
                        delete [] fileReadArray;
                        delete [] arrayExtractedImage3;
                    }
                }
                else{
                    
                    long sizeForCopy = 0;
                    
                    struct stat sizeOfFile;
                    
                    if (stat(imageMoviePath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                        fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTempA, sizeForCopy+1);
                            fin.close();
                            
                            int imageDimensionReadCount = 0;
                            
                            for (int counter1 = imageXYLength-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                                    arrayLabelImage [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageXYLength+counter2];
                                }
                                
                                imageDimensionReadCount++;
                            }
                        }
                        
                        delete [] uploadTempA;
                    }
                }
                
                imageLoadFlagLabel = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLabelSetDisplay object:self];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Image Loaded"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Movie On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Copy/Image Loading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)labelActive1:(id)sender{
    if (currentActiveHold != 1){
        currentActiveHold = 1;
        
        [labelDisplayTitle1 setTextColor:[NSColor redColor]];
        [labelDisplayTitle1 setStringValue:@"Label 1"];
        
        [labelDisplayTitle2 setTextColor:[NSColor blackColor]];
        [labelDisplayTitle2 setStringValue:@"Label 2"];
        
        [incrementDisplayTitle setTextColor:[NSColor blackColor]];
        [incrementDisplayTitle setStringValue:@"Increment"];
        
        [scaleDisplayTitle setTextColor:[NSColor blackColor]];
        [scaleDisplayTitle setStringValue:@"Scale Bar"];
        
        if (labelX1 != -1 && labelY1 != -1){
            [labelDisplayX1 setIntegerValue:labelX1];
            [labelDisplayY1 setIntegerValue:labelY1];
        }
        else{
            
            [labelDisplayX1 setStringValue:@""];
            [labelDisplayY1 setStringValue:@""];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        textChangeDisplayCall = 1;
    }
    
    else if (currentActiveHold == 1){
        
        currentActiveHold = 0;
        
        [labelDisplayTitle1 setTextColor:[NSColor blackColor]];
        [labelDisplayTitle1 setStringValue:@"Label 1"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)labelFontSet1:(id)sender{
    if (labelFont1 == 1){
        labelFont1 = 2;
        [labelDisplayFont1 setStringValue:@"14 F"];
    }
    else if (labelFont1 == 2){
        labelFont1 = 3;
        [labelDisplayFont1 setStringValue:@"16 F"];
    }
    else if (labelFont1 == 3){
        labelFont1 = 4;
        [labelDisplayFont1 setStringValue:@"18 F"];
    }
    else if (labelFont1 == 4){
        labelFont1 = 5;
        [labelDisplayFont1 setStringValue:@"20 F"];
    }
    else if (labelFont1 == 5){
        labelFont1 = 6;
        [labelDisplayFont1 setStringValue:@"30 F"];
    }
    else if (labelFont1 == 6){
        labelFont1 = 7;
        [labelDisplayFont1 setStringValue:@"40 F"];
    }
    else if (labelFont1 == 7){
        labelFont1 = 8;
        [labelDisplayFont1 setStringValue:@"60 F"];
    }
    else if (labelFont1 == 8){
        labelFont1 = 9;
        [labelDisplayFont1 setStringValue:@"80 F"];
    }
    else if (labelFont1 == 9){
        labelFont1 = 10;
        [labelDisplayFont1 setStringValue:@"0 F"];
    }
    else if (labelFont1 == 10){
        labelFont1 = 11;
        [labelDisplayFont1 setStringValue:@"4 F"];
    }
    else if (labelFont1 == 11){
        labelFont1 = 12;
        [labelDisplayFont1 setStringValue:@"8 F"];
    }
    else if (labelFont1 == 12){
        labelFont1 = 13;
        [labelDisplayFont1 setStringValue:@"10 F"];
    }
    else if (labelFont1 == 13){
        labelFont1 = 1;
        [labelDisplayFont1 setStringValue:@"12 F"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
    
    textChangeDisplayCall = 1;
}

-(IBAction)labelColorSet1:(id)sender{
    if (labelColor1 == 1){
        labelColor1 = 2;
        [labelDisplayColor1 setStringValue:@"Black"];
    }
    else if (labelColor1 == 2){
        labelColor1 = 3;
        [labelDisplayColor1 setStringValue:@"Yellow"];
    }
    else if (labelColor1 == 3){
        labelColor1 = 4;
        [labelDisplayColor1 setStringValue:@"Green"];
    }
    else if (labelColor1 == 4){
        labelColor1 = 5;
        [labelDisplayColor1 setStringValue:@"Red"];
    }
    else if (labelColor1 == 5){
        labelColor1 = 6;
        [labelDisplayColor1 setStringValue:@"Brown"];
    }
    else if (labelColor1 == 6){
        labelColor1 = 7;
        [labelDisplayColor1 setStringValue:@"Cyan"];
    }
    else if (labelColor1 == 7){
        labelColor1 = 8;
        [labelDisplayColor1 setStringValue:@"Magenta"];
    }
    else if (labelColor1 == 8){
        labelColor1 = 9;
        [labelDisplayColor1 setStringValue:@"Orange"];
    }
    else if (labelColor1 == 9){
        labelColor1 = 10;
        [labelDisplayColor1 setStringValue:@"Blue"];
    }
    else if (labelColor1 == 10){
        labelColor1 = 1;
        [labelDisplayColor1 setStringValue:@"White"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
    
    textChangeDisplayCall = 1;
}

-(IBAction)labelClear1:(id)sender{
    currentActiveHold = 0;
    xyPositionLabelCall1 = 0;
    xyPositionLabelCall2 = 0;
    
    [labelDisplayTitle1 setTextColor:[NSColor blackColor]];
    [labelDisplayTitle1 setStringValue:@"Label 1"];
    
    labelFont1 = 1;
    [labelDisplayFont1 setStringValue:@"12 F"];
    
    labelColor1 = 1;
    [labelDisplayColor1 setStringValue:@"White"];
    
    labelX1 = -1;
    labelY1 = -1;
    labelPrint1 = "";
    
    [labelDisplayX1 setStringValue:@""];
    [labelDisplayY1 setStringValue:@""];
    [labelDisplayPrint1 setStringValue:@""];
    
    if (labelX2 != -1 && labelY2 != -1){
        [labelDisplayX2 setIntegerValue:labelX2];
        [labelDisplayY2 setIntegerValue:labelY2];
    }
    else{
        
        [labelDisplayX2 setStringValue:@""];
        [labelDisplayY2 setStringValue:@""];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
    
    textChangeDisplayCall = 1;
}

-(IBAction)labelActive2:(id)sender{
    if (currentActiveHold != 2){
        currentActiveHold = 2;
        
        [labelDisplayTitle1 setTextColor:[NSColor blackColor]];
        [labelDisplayTitle1 setStringValue:@"Label 1"];
        
        [labelDisplayTitle2 setTextColor:[NSColor redColor]];
        [labelDisplayTitle2 setStringValue:@"Label 2"];
        
        [incrementDisplayTitle setTextColor:[NSColor blackColor]];
        [incrementDisplayTitle setStringValue:@"Increment"];
        
        [scaleDisplayTitle setTextColor:[NSColor blackColor]];
        [scaleDisplayTitle setStringValue:@"Scale Bar"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        textChangeDisplayCall = 1;
    }
    else if (currentActiveHold == 2){
        
        currentActiveHold = 0;
        
        [labelDisplayTitle2 setTextColor:[NSColor blackColor]];
        [labelDisplayTitle2 setStringValue:@"Label 2"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)labelFontSet2:(id)sender{
    if (labelFont2 == 1){
        labelFont2 = 2;
        [labelDisplayFont2 setStringValue:@"14 F"];
    }
    else if (labelFont2 == 2){
        labelFont2 = 3;
        [labelDisplayFont2 setStringValue:@"16 F"];
    }
    else if (labelFont2 == 3){
        labelFont2 = 4;
        [labelDisplayFont2 setStringValue:@"18 F"];
    }
    else if (labelFont2 == 4){
        labelFont2 = 5;
        [labelDisplayFont2 setStringValue:@"20 F"];
    }
    else if (labelFont2 == 5){
        labelFont2 = 6;
        [labelDisplayFont2 setStringValue:@"30 F"];
    }
    else if (labelFont2 == 6){
        labelFont2 = 7;
        [labelDisplayFont2 setStringValue:@"40 F"];
    }
    else if (labelFont2 == 7){
        labelFont2 = 8;
        [labelDisplayFont2 setStringValue:@"60 F"];
    }
    else if (labelFont2 == 8){
        labelFont2 = 9;
        [labelDisplayFont2 setStringValue:@"80 F"];
    }
    else if (labelFont2 == 9){
        labelFont2 = 10;
        [labelDisplayFont2 setStringValue:@"0 F"];
    }
    else if (labelFont2 == 10){
        labelFont2 = 11;
        [labelDisplayFont2 setStringValue:@"4 F"];
    }
    else if (labelFont2 == 11){
        labelFont2 = 12;
        [labelDisplayFont2 setStringValue:@"8 F"];
    }
    else if (labelFont2 == 12){
        labelFont2 = 13;
        [labelDisplayFont2 setStringValue:@"10 F"];
    }
    else if (labelFont2 == 13){
        labelFont2 = 1;
        [labelDisplayFont2 setStringValue:@"12 F"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
    
    textChangeDisplayCall = 1;
}

-(IBAction)labelColorSet2:(id)sender{
    if (labelColor2 == 1){
        labelColor2 = 2;
        [labelDisplayColor2 setStringValue:@"Black"];
    }
    else if (labelColor2 == 2){
        labelColor2 = 3;
        [labelDisplayColor2 setStringValue:@"Yellow"];
    }
    else if (labelColor2 == 3){
        labelColor2 = 4;
        [labelDisplayColor2 setStringValue:@"Green"];
    }
    else if (labelColor2 == 4){
        labelColor2 = 5;
        [labelDisplayColor2 setStringValue:@"Red"];
    }
    else if (labelColor2 == 5){
        labelColor2 = 6;
        [labelDisplayColor2 setStringValue:@"Brown"];
    }
    else if (labelColor2 == 6){
        labelColor2 = 7;
        [labelDisplayColor2 setStringValue:@"Cyan"];
    }
    else if (labelColor2 == 7){
        labelColor2 = 8;
        [labelDisplayColor2 setStringValue:@"Magenta"];
    }
    else if (labelColor2 == 8){
        labelColor2 = 9;
        [labelDisplayColor2 setStringValue:@"Orange"];
    }
    else if (labelColor2 == 9){
        labelColor2 = 10;
        [labelDisplayColor2 setStringValue:@"Blue"];
    }
    else if (labelColor2 == 10){
        labelColor2 = 1;
        [labelDisplayColor2 setStringValue:@"White"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
    
    textChangeDisplayCall = 1;
}

-(IBAction)labelClear2:(id)sender{
    currentActiveHold = 0;
    xyPositionLabelCall1 = 0;
    xyPositionLabelCall2 = 0;
    
    [labelDisplayTitle2 setTextColor:[NSColor blackColor]];
    [labelDisplayTitle2 setStringValue:@"Label 2"];
    
    labelFont2 = 1;
    [labelDisplayFont2 setStringValue:@"12 F"];
    
    labelColor2 = 1;
    [labelDisplayColor2 setStringValue:@"White"];
    
    labelX2 = -1;
    labelY2 = -1;
    labelPrint2 = "";
    
    [labelDisplayX2 setStringValue:@""];
    [labelDisplayY2 setStringValue:@""];
    [labelDisplayPrint2 setStringValue:@""];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
    
    textChangeDisplayCall = 1;
}

-(IBAction)incrementActive:(id)sender{
    if (currentActiveHold != 3){
        currentActiveHold = 3;
        
        [labelDisplayTitle1 setTextColor:[NSColor blackColor]];
        [labelDisplayTitle1 setStringValue:@"Label 1"];
        
        [labelDisplayTitle2 setTextColor:[NSColor blackColor]];
        [labelDisplayTitle2 setStringValue:@"Label 2"];
        
        [incrementDisplayTitle setTextColor:[NSColor redColor]];
        [incrementDisplayTitle setStringValue:@"Increment"];
        
        [scaleDisplayTitle setTextColor:[NSColor blackColor]];
        [scaleDisplayTitle setStringValue:@"Scale Bar"];
        
        if (incrementX != -1 && incrementY != -1){
            [incrementDisplayX setIntegerValue:incrementX];
            [incrementDisplayY setIntegerValue:incrementY];
        }
        else{
            
            [incrementDisplayX setStringValue:@""];
            [incrementDisplayY setStringValue:@""];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        textChangeDisplayCall = 1;
    }
    else if (currentActiveHold == 3){
        
        currentActiveHold = 0;
        
        [incrementDisplayTitle setTextColor:[NSColor blackColor]];
        [incrementDisplayTitle setStringValue:@"Increment"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)incrementFontSet:(id)sender{
    if (incrementFont == 1){
        incrementFont = 2;
        [incrementDisplayFont setStringValue:@"14 F"];
    }
    else if (incrementFont == 2){
        incrementFont = 3;
        [incrementDisplayFont setStringValue:@"16 F"];
    }
    else if (incrementFont == 3){
        incrementFont = 4;
        [incrementDisplayFont setStringValue:@"18 F"];
    }
    else if (incrementFont == 4){
        incrementFont = 5;
        [incrementDisplayFont setStringValue:@"20 F"];
    }
    else if (incrementFont == 5){
        incrementFont = 6;
        [incrementDisplayFont setStringValue:@"30 F"];
    }
    else if (incrementFont == 6){
        incrementFont = 7;
        [incrementDisplayFont setStringValue:@"40 F"];
    }
    else if (incrementFont == 7){
        incrementFont = 8;
        [incrementDisplayFont setStringValue:@"60 F"];
    }
    else if (incrementFont == 8){
        incrementFont = 9;
        [incrementDisplayFont setStringValue:@"80 F"];
    }
    else if (incrementFont == 9){
        incrementFont = 10;
        [incrementDisplayFont setStringValue:@"0 F"];
    }
    else if (incrementFont == 10){
        incrementFont = 11;
        [incrementDisplayFont setStringValue:@"4 F"];
    }
    else if (incrementFont == 11){
        incrementFont = 12;
        [incrementDisplayFont setStringValue:@"8 F"];
    }
    else if (incrementFont == 12){
        incrementFont = 13;
        [incrementDisplayFont setStringValue:@"10 F"];
    }
    else if (incrementFont == 13){
        incrementFont = 1;
        [incrementDisplayFont setStringValue:@"12 F"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
    
    textChangeDisplayCall = 1;
}

-(IBAction)incrementColorSet:(id)sender{
    if (incrementColor == 1){
        incrementColor = 2;
        [incrementDisplayColor setStringValue:@"Black"];
    }
    else if (incrementColor == 2){
        incrementColor = 3;
        [incrementDisplayColor setStringValue:@"Yellow"];
    }
    else if (incrementColor == 3){
        incrementColor = 4;
        [incrementDisplayColor setStringValue:@"Green"];
    }
    else if (incrementColor == 4){
        incrementColor = 5;
        [incrementDisplayColor setStringValue:@"Red"];
    }
    else if (incrementColor == 5){
        incrementColor = 6;
        [incrementDisplayColor setStringValue:@"Brown"];
    }
    else if (incrementColor == 6){
        incrementColor = 7;
        [incrementDisplayColor setStringValue:@"Cyan"];
    }
    else if (incrementColor == 7){
        incrementColor = 8;
        [incrementDisplayColor setStringValue:@"Magenta"];
    }
    else if (incrementColor == 8){
        incrementColor = 9;
        [incrementDisplayColor setStringValue:@"Orange"];
    }
    else if (incrementColor == 9){
        incrementColor = 10;
        [incrementDisplayColor setStringValue:@"Blue"];
    }
    else if (incrementColor == 10){
        incrementColor = 1;
        [incrementDisplayColor setStringValue:@"White"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
    
    textChangeDisplayCall = 1;
}

-(IBAction)incrementClear:(id)sender{
    currentActiveHold = 0;
    
    [incrementDisplayTitle setTextColor:[NSColor blackColor]];
    [incrementDisplayTitle setStringValue:@"Increment"];
    
    incrementFont = 1;
    [incrementDisplayFont setStringValue:@"12 F"];
    
    incrementColor = 1;
    [incrementDisplayColor setStringValue:@"White"];
    
    incrementX = -1;
    incrementY = -1;
    incrementValue = 0;
    incrementStart = 0;
    
    [incrementDisplayX setStringValue:@""];
    [incrementDisplayY setStringValue:@""];
    [incrementDisplayInterval setStringValue:@""];
    [incrementDisplayStart setStringValue:@""];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
    
    textChangeDisplayCall = 1;
}

-(IBAction)scaleBarActive:(id)sender{
    if (currentActiveHold != 4){
        currentActiveHold = 4;
        
        [labelDisplayTitle1 setTextColor:[NSColor blackColor]];
        [labelDisplayTitle1 setStringValue:@"Label 1"];
        
        [labelDisplayTitle2 setTextColor:[NSColor blackColor]];
        [labelDisplayTitle2 setStringValue:@"Label 2"];
        
        [incrementDisplayTitle setTextColor:[NSColor blackColor]];
        [incrementDisplayTitle setStringValue:@"Increment"];
        
        [scaleDisplayTitle setTextColor:[NSColor redColor]];
        [scaleDisplayTitle setStringValue:@"Scale Bar"];
        
        if (scaleBarX != -1 && scaleBarY != -1){
            [scaleDisplayX setIntegerValue:scaleBarX];
            [scaleDisplayY setIntegerValue:scaleBarY];
        }
        else{
            
            [scaleDisplayX setStringValue:@""];
            [scaleDisplayY setStringValue:@""];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        textChangeDisplayCall = 1;
    }
    else if (currentActiveHold == 4){
        
        currentActiveHold = 0;
        
        [scaleDisplayTitle setTextColor:[NSColor blackColor]];
        [scaleDisplayTitle setStringValue:@"Scale Bar"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)scaleBarWidthSet:(id)sender{
    if (scaleBarWidth == 1){
        scaleBarWidth = 2;
        [scaleDisplayWidth setStringValue:@"4 pix"];
    }
    else if (scaleBarWidth == 2){
        scaleBarWidth = 3;
        [scaleDisplayWidth setStringValue:@"5 pix"];
    }
    else if (scaleBarWidth == 3){
        scaleBarWidth = 4;
        [scaleDisplayWidth setStringValue:@"6 pix"];
    }
    else if (scaleBarWidth == 4){
        scaleBarWidth = 5;
        [scaleDisplayWidth setStringValue:@"7 pix"];
    }
    else if (scaleBarWidth == 5){
        scaleBarWidth = 6;
        [scaleDisplayWidth setStringValue:@"8 pix"];
    }
    else if (scaleBarWidth == 6){
        scaleBarWidth = 7;
        [scaleDisplayWidth setStringValue:@"0.5 pix"];
    }
    else if (scaleBarWidth == 7){
        scaleBarWidth = 8;
        [scaleDisplayWidth setStringValue:@"1 pix"];
    }
    else if (scaleBarWidth == 8){
        scaleBarWidth = 9;
        [scaleDisplayWidth setStringValue:@"2 pix"];
    }
    else if (scaleBarWidth == 9){
        scaleBarWidth = 1;
        [scaleDisplayWidth setStringValue:@"3 pix"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
    
    textChangeDisplayCall = 1;
}

-(IBAction)scaleBarColorSet:(id)sender{
    if (scaleBarColor == 1){
        scaleBarColor = 2;
        [scaleDisplayColor setStringValue:@"Black"];
    }
    else if (scaleBarColor == 2){
        scaleBarColor = 3;
        [scaleDisplayColor setStringValue:@"Yellow"];
    }
    else if (scaleBarColor == 3){
        scaleBarColor = 4;
        [scaleDisplayColor setStringValue:@"Green"];
    }
    else if (scaleBarColor == 4){
        scaleBarColor = 5;
        [scaleDisplayColor setStringValue:@"Red"];
    }
    else if (scaleBarColor == 5){
        scaleBarColor = 6;
        [scaleDisplayColor setStringValue:@"Brown"];
    }
    else if (scaleBarColor == 6){
        scaleBarColor = 7;
        [scaleDisplayColor setStringValue:@"Cyan"];
    }
    else if (scaleBarColor == 7){
        scaleBarColor = 8;
        [scaleDisplayColor setStringValue:@"Magenta"];
    }
    else if (scaleBarColor == 8){
        scaleBarColor = 9;
        [scaleDisplayColor setStringValue:@"Orange"];
    }
    else if (scaleBarColor == 9){
        scaleBarColor = 10;
        [scaleDisplayColor setStringValue:@"Blue"];
    }
    else if (scaleBarColor == 10){
        scaleBarColor = 1;
        [scaleDisplayColor setStringValue:@"White"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
    
    textChangeDisplayCall = 1;
}

-(IBAction)scaleBarClear:(id)sender{
    currentActiveHold = 0;
    
    [scaleDisplayTitle setTextColor:[NSColor blackColor]];
    [scaleDisplayTitle setStringValue:@"Scale Bar"];
    
    scaleBarWidth = 1;
    [scaleDisplayWidth setStringValue:@"3 Pix"];
    
    scaleBarColor = 1;
    [scaleDisplayColor setStringValue:@"White"];
    
    scaleBarX = -1;
    scaleBarY = -1;
    scaleBarLength = 0;
    
    [scaleDisplayX setStringValue:@""];
    [scaleDisplayY setStringValue:@""];
    [scaleDisplayLength setStringValue:@""];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
    
    textChangeDisplayCall = 1;
}

-(IBAction)setCrop:(id)sender{
    if (setCropStatus == 0){
        setCropStatus = 1;
        [setCropDisplay setStringValue:@"On"];
    }
    else if (setCropStatus == 1){
        setCropStatus = 0;
        [setCropDisplay setStringValue:@"Off"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
    
    textChangeDisplayCall = 1;
}

-(IBAction)printStopSet:(id)sender{
    if (exportFlag == 1){
        printStop = 1;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)imageSizeSet:(id)sender{
    if (exportFlag == 0){
        if (imageSizeIncreaseHold == 0){
            imageSizeIncreaseHold = 1;
            [imageSizeSetDisplay setStringValue:@"x2"];
            
        }
        else if (imageSizeIncreaseHold == 1){
            imageSizeIncreaseHold = 2;
            [imageSizeSetDisplay setStringValue:@"x4"];
        }
        else if (imageSizeIncreaseHold == 2){
            imageSizeIncreaseHold = 0;
            [imageSizeSetDisplay setStringValue:@"x1"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)closeWindow:(id)sender{
    [labelSetWindow orderOut:self];
    labelSetOperation = 2;
    labelSetTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
    [labelSetTimer2 invalidate];
}

-(void)reDisplayWindow{
    if (labelSetOperation == 3){
        [labelSetWindow makeKeyAndOrderFront:self];
        labelSetOperation = 1;
        [labelSetTimer invalidate];
        labelSetTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
    }
}

-(void)dealloc{
    if (labelSetTimer) [labelSetTimer invalidate];
    if (labelSetTimer2) [labelSetTimer2 invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToLabelSet object:nil];
}

@end
