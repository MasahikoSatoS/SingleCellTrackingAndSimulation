//
//  DataRepair1.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-05-28.
//

#import "DataRepair1.h"

@implementation DataRepair1

-(IBAction)dataRepair1:(id)sender{
    //-----PR reconstruct/GC Lineage data reconstruct-----
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Map Integrity Needed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            int processType = 1;
            [self reconstruct:processType];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dataRepair2:(id)sender{
    //-----PR reconstruct/GC Lineage data reconstruct-----
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Map Integrity Needed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            int processType = 2;
            [self reconstruct:processType];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dataRepair5:(id)sender{
    //-----PR reconstruct/GC Lineage data reconstruct-----
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Map Integrity Needed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            int processType = 5;
            [self reconstruct:processType];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dataRepair6:(id)sender{
    //-----ST reconstruct-----
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Need Intact RL Data"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            int processType = 6;
            [self reconstruct:processType];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dataRepair7:(id)sender{
    //-----RL reconstruct-----
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Need Intact PR Data"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            int processType = 7;
            [self reconstruct:processType];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dataRepair8:(id)sender{
    //-----GC reconstruct-----
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Map Integrity Needed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            int processType = 8;
            [self reconstruct:processType];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dataRepair8B:(id)sender{
    //-----GC reconstruct-----
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Need Intact PR Data"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            int processType = 12;
            [self reconstruct:processType];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dataRepair9:(id)sender{
    //-----AD reconstruct-----
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"GC Data Integrity Required"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            int processType = 9;
            [self reconstruct:processType];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dataRepair10:(id)sender{
    //-----Map reconstruct-----
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Need Intact PR Data"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            int processType = 10;
            [self reconstruct:processType];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dataRepair11:(id)sender{
    //-----Fluorescent reconstruct-----
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Need Intact PR Data: Modified Area Data will be Cleared or Redraw Areas"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            int processType = 11;
            [self reconstruct:processType];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)reconstruct:(int)processType{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        cleaningProgress = 1;
        progressControl = 1;
        
        if (checkListCount == 0 && treatmentNameHold != "") nameStringRep = treatmentNameHold;
        else nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
        
        int *timePointProcessList = new int [imageEndHold+50];
        
        for (int counter2 = 0; counter2 < imageEndHold+50; counter2++) timePointProcessList [counter2] = 0;
        
        if (errorTimeModeHold == 1){
            for (int counter2 = 0; counter2 < checkListCount/8; counter2++){
                if (checkList [repairOperationTableCurrentRow*8+1] == checkList [counter2*8+1]){
                    if (processType == 1 || processType == 2){
                        if (checkList [counter2*8+5] == 46 || checkList [counter2*8+5] == 45){
                            if (timePointProcessList [checkList [counter2*8]] != -1) timePointProcessList [checkList [counter2*8]] = 1;
                        }
                        
                        if (checkOverrideFlag == 0 && (checkList [counter2*8+5] == 33)){
                            timePointProcessList [checkList [counter2*8]] = -1;
                        }
                    }
                    else if (processType == 5){
                        if (checkList [counter2*8+5] == 7 || checkList [counter2*8+5] == 10 || checkList [counter2*8+5] == 11 || checkList [counter2*8+5] == 13){
                            if (timePointProcessList [checkList [counter2*8]] != -1) timePointProcessList [checkList [counter2*8]] = 1;
                        }
                        
                        if (checkOverrideFlag == 0 && (checkList [counter2*8+5] == 33)){
                            timePointProcessList [checkList [counter2*8]] = -1;
                        }
                    }
                    else if (processType == 6){
                        if (checkList [counter2*8+5] == 14 || checkList [counter2*8+5] == 15 || checkList [counter2*8+5] == 16 || checkList [counter2*8+5] == 17 || checkList [counter2*8+5] == 19 || checkList [counter2*8+5] == 20 || checkList [counter2*8+5] == 21 || checkList [counter2*8+5] == 22){
                            if (timePointProcessList [checkList [counter2*8]] != -1) timePointProcessList [checkList [counter2*8]] = 1;
                        }
                        
                        if (checkOverrideFlag == 0 && (checkList [counter2*8+5] == 31 || checkList [counter2*8+5] == 32)){
                            timePointProcessList [checkList [counter2*8]] = -1;
                        }
                    }
                    else if (processType == 7){
                        if (checkList [counter2*8+5] == 31 || checkList [counter2*8+5] == 32){
                            if (timePointProcessList [checkList [counter2*8]] != -1) timePointProcessList [checkList [counter2*8]] = 1;
                        }
                        
                        if (checkOverrideFlag == 0 && (checkList [counter2*8+5] == 7 || checkList [counter2*8+5] == 10 || checkList [counter2*8+5] == 11 || checkList [counter2*8+5] == 12)){
                            timePointProcessList [checkList [counter2*8]] = -1;
                        }
                    }
                    else if (processType == 8){
                        if (checkList [counter2*8+5] == 24 || checkList [counter2*8+5] == 25 || checkList [counter2*8+5] == 26){
                            if (timePointProcessList [checkList [counter2*8]] != -1) timePointProcessList [checkList [counter2*8]] = 1;
                        }
                        
                        if (checkOverrideFlag == 0 && (checkList [counter2*8+5] == 33)){
                            timePointProcessList [checkList [counter2*8]] = -1;
                        }
                    }
                    else if (processType == 9){
                        if (checkList [counter2*8+5] == 27 || checkList [counter2*8+5] == 28 || checkList [counter2*8+5] == 29 || checkList [counter2*8+5] == 30){
                            if (timePointProcessList [checkList [counter2*8]] != -1) timePointProcessList [checkList [counter2*8]] = 1;
                        }
                        
                        if (checkOverrideFlag == 0 && (checkList [counter2*8+5] == 23 || checkList [counter2*8+5] == 24 || checkList [counter2*8+5] == 25 || checkList [counter2*8+5] == 26)){
                            timePointProcessList [checkList [counter2*8]] = -1;
                        }
                    }
                    else if (processType == 11){
                        if (checkList [counter2*8+5] == 34 || checkList [counter2*8+5] == 35 || checkList [counter2*8+5] == 36 || checkList [counter2*8+5] == 37 || checkList [counter2*8+5] == 41 || checkList [counter2*8+5] == 42 || checkList [counter2*8+5] == 43){
                            if (timePointProcessList [checkList [counter2*8]] != -1) timePointProcessList [checkList [counter2*8]] = 1;
                        }
                        
                        if (checkOverrideFlag == 0 && (checkList [counter2*8+5] == 7 || checkList [counter2*8+5] == 10 || checkList [counter2*8+5] == 11 || checkList [counter2*8+5] == 12)){
                            timePointProcessList [checkList [counter2*8]] = -1;
                        }
                    }
                }
            }
        }
        else if (errorTimeModeHold == 0){
            timePointProcessList [checkList [repairOperationTableCurrentRow*8]] = 1;
            
            if (checkOverrideFlag == 0){
                for (int counter2 = 0; counter2 < checkListCount/8; counter2++){
                    if (checkList [repairOperationTableCurrentRow*8+1] == checkList [counter2*8+1] && checkList [repairOperationTableCurrentRow*8] == checkList [counter2*8]){
                        if (processType == 1 || processType == 2){
                            if (checkList [counter2*8+5] == 33){
                                timePointProcessList [checkList [counter2*8]] = -1;
                            }
                        }
                        else if (processType == 5){
                            if (checkList [counter2*8+5] == 33){
                                timePointProcessList [checkList [counter2*8]] = -1;
                            }
                        }
                        else if (processType == 6){
                            if (checkList [counter2*8+5] == 31 || checkList [counter2*8+5] == 32){
                                timePointProcessList [checkList [counter2*8]] = -1;
                            }
                        }
                        else if (processType == 7){
                            if (checkList [counter2*8+5] == 7 || checkList [counter2*8+5] == 10 || checkList [counter2*8+5] == 11 || checkList [counter2*8+5] == 12){
                                timePointProcessList [checkList [counter2*8]] = -1;
                            }
                        }
                        else if (processType == 8){
                            if (checkList [counter2*8+5] == 33){
                                timePointProcessList [checkList [counter2*8]] = -1;
                            }
                        }
                        else if (processType == 9){
                            if (checkList [counter2*8+5] == 23 || checkList [counter2*8+5] == 24 || checkList [counter2*8+5] == 25 || checkList [counter2*8+5] == 26){
                                timePointProcessList [checkList [counter2*8]] = -1;
                            }
                        }
                        else if (processType == 10){
                            if (checkList [counter2*8+5] == 7 || checkList [counter2*8+5] == 10 || checkList [counter2*8+5] == 11 || checkList [counter2*8+5] == 12){
                                timePointProcessList [checkList [counter2*8]] = -1;
                            }
                        }
                        else if (processType == 11){
                            if (checkList [counter2*8+5] == 7 || checkList [counter2*8+5] == 10 || checkList [counter2*8+5] == 11 || checkList [counter2*8+5] == 12){
                                timePointProcessList [checkList [counter2*8]] = -1;
                            }
                        }
                    }
                }
            }
        }
        else if (errorTimeModeHold == 2){
            for (int counter2 = 0; counter2 < checkListCount/8; counter2++){
                if (checkList [counter2*8+5] == errorNumberHold){
                    if (timePointProcessList [checkList [counter2*8]] != -1) timePointProcessList [checkList [counter2*8]] = 1;
                }
            }
        }
        
        lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+ analysisID+"_"+nameStringRep+"_LineageData";
        
        struct stat sizeOfFile;
        long sizeForCopy = 0;
        long size1 = 0;
        long size2 = 0;
        int checkFlag = 0;
        
        for (int counter4 = 0; counter4 < 6; counter4++){
            sizeForCopy = 0;
            
            if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (sizeForCopy != 0){
                if (counter4 == 0) size1 = sizeForCopy;
                else if (counter4 == 1) size2 = sizeForCopy;
                else if (counter4 == 2){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                        break;
                    }
                    else{
                        
                        size1 = 0;
                        size2 = 0;
                        usleep (50000);
                    }
                }
                else if (counter4 == 3) size1 = sizeForCopy;
                else if (counter4 == 4) size2 = sizeForCopy;
                else if (counter4 == 5){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                    }
                }
            }
        }
        
        //-----Lineage data upload-----
        arrayLineageRepairData = new int [sizeForCopy+50];
        lineageDataRepairCount = 0;
        
        int returnValue2 = 0;
        
        if (checkFlag == 1){
            int processType2 = -1;
            
            self->dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
            returnValue2 = [self->dataRepairReadWrite lineageDataSetList:sizeForCopy:processType2];
        }
        
        if (returnValue2 == 0){
            int processTime = 0;
            int imageSize = 0;
            int stepCount = 0;
            int readBit [4];
            int readBit2 [4];
            int finData [25];
            int pixData = 0;
            int totalSize = 0;
            int yDimensionCount = 0;
            int xDimensionCount = 0;
            int maxConnectNoMap = 0;
            int maxMapConnect = 0;
            int timeSelectedVerCount = 0;
            int connectLineageRelVerCount = 0;
            int valueTemp = 0;
            int dataTemp = 0;
            int statusDataReconstructCount = 0;
            int positionRevReconstructCount = 0;
            int connectNumberTemp = 0;
            int rlDataReconstructCount2 = 0;
            int maxPointDimX = 0;
            int maxPointDimY = 0;
            int minPointDimX = 0;
            int minPointDimY = 0;
            int horizontalLength = 0;
            int verticalLength = 0;
            int dimension = 0;
            int horizontalStart = 0;
            int verticalStart = 0;
            int mapGravityCenterCalculationIntX = 0;
            int mapGravityCenterCalculationIntY = 0;
            int mapGRPoint = 0;
            int totalIntensityInt = 0;
            int positionRevListCount = 0;
            int positionRevListLimit = 0;
            int connectivityNumber = 0;
            int connectAnalysisCount = 0;
            int terminationFlag = 0;
            int connectAnalysisTempCount = 0;
            int xSource = 0;
            int ySource = 0;
            int largestConnect = 0;
            int largestConnectNo = 0;
            int xPositionTempStart = 0;
            int yPositionTempStart = 0;
            int lineSize = 0;
            int constructedLineCount = 0;
            int findFlag = 0;
            int maxConnectPR = 0;
            int dataTemp2 = 0;
            int entryCount = 0;
            int nextLoad = 0;
            int fluorescentEntryCountVer = 0;
            int fluorescentCutOffVer1 = 0;
            int fluorescentCutOffVer2 = 0;
            int fluorescentCutOffVer3 = 0;
            int fluorescentCutOffVer4 = 0;
            int fluorescentCutOffVer5 = 0;
            int fluorescentCutOffVer6 = 0;
            int connectListCount = 0;
            int fluorescentNoVer1 = 0;
            int fluorescentNoVer2 = 0;
            int fluorescentNoVer3 = 0;
            int fluorescentNoVer4 = 0;
            int fluorescentNoVer5 = 0;
            int fluorescentNoVer6 = 0;
            int pixelValueTemp = 0;
            int pixelAreaTemp = 0;
            int connectNoVer = 0;
            int expandFluLineTempCount = 0;
            int expandFluLineTempLimit = 0;
            int expandFluAreaTempCount = 0;
            int expandFluAreaTempLimit = 0;
            int processingCheckFlag = 0;
            int lingCheckPosition = 0;
            int gravityCenterRevVerTemp = 0;
            int overlapFind = 0;
            int overlapNumber = 0;
            int areaCount = 0;
            int numberOfSlash = 0;
            int firstConnectNo = 0;
            int areaSizeCheck = 0;
            int areaSizeHold = 0;
            int processOrderSortCount = 0;
            int processConnectNo = 0;
            int lineageExtractTempPRCount = 0;
            int matchCount = 0;
            int matchPoint = 0;
            int overflowCheck = 0;
            int cellNumberTemp = 0;
            int lingNumberTemp = 0;
            int xPositionLing = 0;
            int yPositionLing = 0;
            int xPositionGC = 0;
            int yPositionGC = 0;
            int lingCheck = 0;
            int gravityCenterCheck = 0;
            int changeFlag = 0;
            int lineagePositionError = 0;
            int connectFind = 0;
            int dataConversion [4];
            int endianType = 0;
            int imageWidthEntry = 0;
            int value0 = 0;
            int value1 = 0;
            int value2 = 0;
            int imageDimensionReadCount = 0;
            int processType2 = 0;
            int dataType = 0;
            int masterDataReadingError = 0;
            int missingFind = 0;
            int listOrderPositionHold = 0;
            int listOrderConnect = 0;
            
            double averageArea = 0;
            double mapGravityCenterCalculationX = 0;
            double mapGravityCenterCalculationY = 0;
            long totalIntensity = 0;
            
            unsigned long readPosition = 0;
            unsigned long totalMapSizeTemp = 0;
            unsigned long indexCount = 0;
            unsigned long headPosition = 0;
            
            string revisedMapPath;
            string sourceImagePath;
            string connectStatusDataPath;
            string connectRelationPath;
            string extension;
            string fluorescentProcessPath1;
            string fluorescentProcessPath2;
            string fluorescentProcessPath3;
            string fluorescentProcessPath4;
            string fluorescentProcessPath5;
            string fluorescentProcessPath6;
            string fluorescentRoundNoVer;
            string fluorescentNameVer1;
            string fluorescentNameVer2;
            string fluorescentNameVer3;
            string fluorescentNameVer4;
            string fluorescentNameVer5;
            string fluorescentNameVer6;
            string extractString;
            string extractString2;
            
            ifstream fin;
            
            for (int counter1 = 1; counter1 <= imageEndHold; counter1++){
                if (timePointProcessList [counter1] == 1){
                    processTime = counter1;
                    imageSize = 0;
                    
                    for (int counter2 = 0; counter2 < imageSizeListCount/2; counter2++){
                        if (arrayImageSizeList [counter2*2] == nameStringRep){
                            imageSize = atoi(arrayImageSizeList [counter2*2+1].c_str());
                            break;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageDataRepairCount/8; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageRepairData [counterA*8+counterB];
                    //    cout<<" arrayLineageRepairData "<<counterA<<endl;
                    //}
                    
                    int **revisedMapVer = new int *[imageSize+1];
                    int **sourceMapVer = new int *[imageSize+1];
                    int **revisedMapVerTemp = new int *[imageSize+1];
                    
                    for (int counter2 = 0; counter2 < imageSize+1; counter2++){
                        revisedMapVer [counter2] = new int [imageSize+1];
                        sourceMapVer [counter2] = new int [imageSize+1];
                        revisedMapVerTemp [counter2] = new int [imageSize+1];
                    }
                    
                    for (int counter3 = 0; counter3 < imageSize; counter3++){
                        for (int counter4 = 0; counter4 < imageSize; counter4++){
                            revisedMapVer [counter3][counter4] = 0;
                            sourceMapVer [counter3][counter4] = 0;
                            revisedMapVerTemp [counter3][counter4] = 0;
                        }
                    }
                    
                    extension = to_string(processTime);
                    
                    if (extension.length() == 1) extension = "000"+extension;
                    else if (extension.length() == 2) extension = "00"+extension;
                    else if (extension.length() == 3) extension = "0"+extension;
                    
                    revisedMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_RevisedMap";
                    
                    totalSize = imageSize*imageSize*4;
                    
                    fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        uint8_t *upload2 = new uint8_t [totalSize+50];
                        fin.read((char*)upload2, totalSize+1);
                        fin.close();
                        
                        yDimensionCount = 0;
                        xDimensionCount = 0;
                        
                        for (int counter3 = 0; counter3 < totalSize; counter3 = counter3+4){
                            readBit [0] = upload2[counter3];
                            readBit [1] = upload2[counter3+1];
                            readBit [2] = upload2[counter3+2];
                            readBit [3] = upload2[counter3+3];
                            
                            pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                            
                            for (int counter4 = 0; counter4 < readBit [3]; counter4++){
                                revisedMapVer [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                            }
                            
                            if (xDimensionCount == imageSize){
                                xDimensionCount = 0;
                                yDimensionCount++;
                                
                                if (yDimensionCount == imageSize){
                                    break;
                                }
                            }
                        }
                        
                        delete [] upload2;
                    }
                    
                    maxConnectNoMap = 0;
                    
                    for (int counter3 = 0; counter3 < imageSize; counter3++){
                        for (int counter4 = 0; counter4 < imageSize; counter4++){
                            if (revisedMapVer [counter3][counter4] > maxConnectNoMap) maxConnectNoMap = revisedMapVer [counter3][counter4];
                        }
                    }
                    
                    sourceImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+nameStringRep+"_Stitch/"+"STimage "+extension+exType;
                    
                    //-----Source upload-----
                    if (stat(sourceImagePath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        if (exType == ".tif" || exTypeIF == ".TIF"){
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                imageDimensionReadCount = 0;
                                imageWidthEntry = 0;
                                
                                if (tifImageColorGray == 0){
                                    for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                        sourceMapVer [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                                else if (tifImageColorGray == 1){
                                    for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                        value0 = uploadTemp [counter3];
                                        value1 = uploadTemp [counter3+1];
                                        value2 = uploadTemp [counter3+2];
                                        
                                        sourceMapVer [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                        
                                        if (imageWidthEntry == imageDimension){
                                            imageWidthEntry = 0;
                                            imageDimensionReadCount++;
                                        }
                                    }
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                        else if (exType == ".bmp" || exTypeIF == ".BMP"){
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                imageDimensionReadCount = 0;
                                
                                for (int counter3 = imageDimension-1; counter3 >= 0; counter3--){
                                    for (int counter4 = 0; counter4 < imageDimension; counter4++){
                                        sourceMapVer [imageDimensionReadCount][counter4] = uploadTemp [1078+counter3*imageDimension+counter4];
                                    }
                                    
                                    imageDimensionReadCount++;
                                }
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    
                    double *mapGravityCenterCalculation = new double [maxConnectNoMap*2+20];
                    int *mapGRPointNo = new int [maxConnectNoMap+10];
                    
                    double *totalIntensityList = new double [maxConnectNoMap*2+20];
                    
                    for (int counter3 = 0; counter3 <= maxConnectNoMap; counter3++){
                        mapGravityCenterCalculation [counter3*2] = 0;
                        mapGravityCenterCalculation [counter3*2+1] = 0;
                        mapGRPointNo [counter3] = 0;
                        totalIntensityList [counter3] = 0;
                    }
                    
                    for (int counter3 = 0; counter3 < imageSize; counter3++){
                        for (int counter4 = 0; counter4 < imageSize; counter4++){
                            if (revisedMapVer [counter3][counter4] > 0){
                                mapGravityCenterCalculation [revisedMapVer [counter3][counter4]*2] = mapGravityCenterCalculation [revisedMapVer [counter3][counter4]*2]+counter4;
                                mapGravityCenterCalculation [revisedMapVer [counter3][counter4]*2+1] = mapGravityCenterCalculation [revisedMapVer [counter3][counter4]*2+1]+counter3;
                                mapGRPointNo [revisedMapVer [counter3][counter4]]++;
                                
                                totalIntensityList [revisedMapVer [counter3][counter4]] = totalIntensityList [revisedMapVer [counter3][counter4]] + sourceMapVer [counter3][counter4];
                            }
                        }
                    }
                    
                    maxMapConnect = 0;
                    
                    for (int counter3 = 0; counter3 < imageSize; counter3++){
                        for (int counter4 = 0; counter4 < imageSize; counter4++){
                            if (maxMapConnect < revisedMapVer [counter3][counter4]){
                                maxMapConnect = revisedMapVer [counter3][counter4];
                            }
                        }
                    }
                    
                    //**********arrayTimeSelected**********
                    //1. Status:[0: Non-Track, 1: Track, 3: Non-Track-Deleted (Delete "0", Used to recover from Cut, when cut line is removed. It will be removed by Cleaning),
                    //4: Track-Deleted (Delete "1 or 7", Used to recover from Cut, when cut line is removed. It will be removed by Cleaning), 7: Cell-Confirmed, 2: Noise, 5: Only for Time One (Area) Non-Track-Deleted, 6: Only for Time One (Area) Track-Deleted]
                    //2. Previous Connect No: When Cut line is set, Hold cut line no that created the connect; When data is saved this information is cleared;
                    //3. Starting position of MasterData
                    //4. Cut Line number hold: when cut line is set, the line number is entered; When data is saved this information is cleared;
                    //5. OPEN;
                    //6. OPEN;
                    //7. OPEN;
                    //8. OPEN;
                    //9. Connect no.
                    //10. Lineage no.
                    
                    //-----Master data UpLoad-----
                    masterDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_MasterDataRevise";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter4 = 0; counter4 < 6; counter4++){
                        sizeForCopy = 0;
                        
                        if (stat(masterDataRevPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter4 == 0) size1 = sizeForCopy;
                            else if (counter4 == 1) size2 = sizeForCopy;
                            else if (counter4 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter4 == 3) size1 = sizeForCopy;
                            else if (counter4 == 4) size2 = sizeForCopy;
                            else if (counter4 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    arrayPositionReviseVer = new int [sizeForCopy+50];
                    positionReviseVerCount = 0;
                    
                    arrayGravityCenterVerRev = new int [sizeForCopy+50];
                    gravityCenterRevVerCount = 0;
                    
                    arrayRepairDataHoldVerRev = new int [sizeForCopy+50];
                    repairDataHoldVerCount = 0;
                    
                    masterDataReadingError = 0;
                    returnValue2 = 0;
                    
                    if (checkFlag == 1){
                        processType2 = -1;
                        dataType = -1;
                        
                        self->dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                        returnValue2 = [self->dataRepairReadWrite masterDataSetList:sizeForCopy:processType2:dataType];
                    }
                    
                    if (returnValue2 == -1) masterDataReadingError = 1;
                    
                    //for (int counterA = 0; counterA < gravityCenterRevVerCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterVerRev [counterA*6+counterB];
                    //    cout<<" arrayGravityCenterVerRev "<<counterA<<endl;
                    //}
                    
                    //-----Status Data UpLoad-----
                    connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_Status";
                    
                    sizeForCopy = 0;
                    
                    if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    int *arrayTimeSelectedVer = new int [sizeForCopy+50];
                    timeSelectedVerCount = 0;
                    
                    if (sizeForCopy != 0){
                        fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            readPosition = 0;
                            stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                                    finData [1] = uploadTemp [readPosition], readPosition++;
                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                                    finData [4] = uploadTemp [readPosition], readPosition++;
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                                    finData [7] = uploadTemp [readPosition], readPosition++;
                                    finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                                    finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                                    finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                                    finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                                    finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                                    finData [13] = uploadTemp [readPosition], readPosition++;
                                    finData [14] = uploadTemp [readPosition], readPosition++;
                                    finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                                    finData [16] = uploadTemp [readPosition], readPosition++;
                                    finData [17] = uploadTemp [readPosition], readPosition++;
                                    finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                                    
                                    finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                                    finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                    finData [8] = finData [7]*256+finData [8];
                                    finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                                    finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                                    
                                    if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                                    else{
                                        
                                        arrayTimeSelectedVer [timeSelectedVerCount] = finData [0], timeSelectedVerCount++; //-----Selected, removed, eliminated status-----
                                        arrayTimeSelectedVer [timeSelectedVerCount] = finData [3], timeSelectedVerCount++; //-----When new line is created, enter line number which creates-----
                                        arrayTimeSelectedVer [timeSelectedVerCount] = finData [6], timeSelectedVerCount++; //-----PositionRevise Start-----
                                        arrayTimeSelectedVer [timeSelectedVerCount] = finData [8], timeSelectedVerCount++; //-----Cut line number-----
                                        arrayTimeSelectedVer [timeSelectedVerCount] = finData [9], timeSelectedVerCount++; //-----X Start-----
                                        arrayTimeSelectedVer [timeSelectedVerCount] = finData [10], timeSelectedVerCount++; //-----X End-----
                                        arrayTimeSelectedVer [timeSelectedVerCount] = finData [11], timeSelectedVerCount++; //-----Y Start-----
                                        arrayTimeSelectedVer [timeSelectedVerCount] = finData [12], timeSelectedVerCount++; //-----Y End-----
                                        arrayTimeSelectedVer [timeSelectedVerCount] = finData [15], timeSelectedVerCount++; //-----Connect-----
                                        arrayTimeSelectedVer [timeSelectedVerCount] = finData [18], timeSelectedVerCount++; //-----Lineage-----
                                    }
                                }
                                
                            } while (stepCount != 3);
                            
                            delete [] uploadTemp;
                        }
                    }
                    
                    //-----connect RL UpLoad-----
                    connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_ConnectLineageRel";
                    
                    sizeForCopy = 0;
                    
                    if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    int *arrayConnectLineageRelVer = new int [sizeForCopy+50];
                    connectLineageRelVerCount = 0;
                    
                    if (sizeForCopy != 0){
                        fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            readPosition = 0;
                            stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++;
                                    finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                                    finData [3] = uploadTemp [readPosition], readPosition++;
                                    finData [4] = uploadTemp [readPosition], readPosition++;
                                    finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                                    finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                                    finData [9] = uploadTemp [readPosition], readPosition++;
                                    finData [10] = uploadTemp [readPosition], readPosition++;
                                    finData [11] = uploadTemp [readPosition], readPosition++;
                                    finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                                    finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                                    finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                                    
                                    finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                    finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                                    finData [7] = finData [6]*256+finData [7];
                                    
                                    if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                    else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                    
                                    if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                    else{
                                        
                                        arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [2], connectLineageRelVerCount++;
                                        arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [5], connectLineageRelVerCount++;
                                        arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [7], connectLineageRelVerCount++;
                                        arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [12], connectLineageRelVerCount++;
                                        arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [13], connectLineageRelVerCount++;
                                        arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [14], connectLineageRelVerCount++;
                                    }
                                }
                                
                            } while (stepCount != 3);
                            
                            delete [] uploadTemp;
                        }
                    }
                    
                    if (maxConnectNoMap > 0 &&  masterDataReadingError == 0){
                        //**********ConnectLineageRel**********
                        //1. Lineage No;
                        //2. Connect No;
                        //3. Image number;
                        //4. Cell no;
                        //5. Target (0: non-target, 1: target);
                        //6. Reserve;
                        
                        //**********Position Revise (main line data array)**********
                        //1. X position;
                        //2. Y position;
                        //3. Average:
                        //4. Connect No;
                        //5. Cell No;
                        //6. Status (0. Non-Track (+Noise), 1. Track (+Cell Confirm), 2. Non-Track Deleted, 3. Track-Deleted)
                        //7. Lineage no;
                        
                        if (processType == 1 || processType == 2 || processType == 5){
                            int *positionRevList = new int [maxMapConnect*7*50+100];
                            positionRevListCount = 0;
                            positionRevListLimit = maxMapConnect*7*50+100;
                            
                            for (int counter3 = 0; counter3 < maxMapConnect*7*50+100; counter3++) positionRevList [counter3] = 0;
                            
                            int *connectLimit = new int [(maxMapConnect+1)*4+100];
                            
                            for (int counter3 = 0; counter3 <= maxMapConnect; counter3++){
                                connectLimit [counter3*4] = 0;
                                connectLimit [counter3*4+1] = 1000000;
                                connectLimit [counter3*4+2] = 0;
                                connectLimit [counter3*4+3] = 1000000;
                            }
                            
                            for (int counter3 = 0; counter3 < imageSize; counter3++){
                                for (int counter4 = 0; counter4 < imageSize; counter4++){
                                    if (revisedMapVer [counter3][counter4] != 0){
                                        if (connectLimit [revisedMapVer [counter3][counter4]*4] < counter3) connectLimit [revisedMapVer [counter3][counter4]*4] = counter3;
                                        if (connectLimit [revisedMapVer [counter3][counter4]*4+1] > counter3) connectLimit [revisedMapVer [counter3][counter4]*4+1] = counter3;
                                        if (connectLimit [revisedMapVer [counter3][counter4]*4+2] < counter4) connectLimit [revisedMapVer [counter3][counter4]*4+2] = counter4;
                                        if (connectLimit [revisedMapVer [counter3][counter4]*4+3] > counter4) connectLimit [revisedMapVer [counter3][counter4]*4+3] = counter4;
                                    }
                                }
                            }
                            
                            string *processOrder = new string [maxMapConnect+10];
                            
                            for (int counter2 = 1; counter2 <= maxMapConnect; counter2++) processOrder [counter2] = "nil";
                            
                            for (int counter2 = 1; counter2 <= maxMapConnect; counter2++){
                                maxPointDimX = 0;
                                maxPointDimY = 0;
                                minPointDimX = 1000000;
                                minPointDimY = 1000000;
                                
                                for (int counter3 = connectLimit [counter2*4+1]; counter3 <= connectLimit [counter2*4]; counter3++){
                                    for (int counter4 = connectLimit [counter2*4+3]; counter4 <= connectLimit [counter2*4+2]; counter4++){
                                        if (counter2 == revisedMapVer [counter3][counter4]){
                                            if (maxPointDimX < counter4) maxPointDimX = counter4;
                                            if (minPointDimX > counter4) minPointDimX = counter4;
                                            if (maxPointDimY < counter3) maxPointDimY = counter3;
                                            if (minPointDimY > counter3) minPointDimY = counter3;
                                        }
                                    }
                                }
                                
                                if (minPointDimX != 1000000){
                                    //-----Determine the dimension of cell-----
                                    horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                                    verticalLength = (maxPointDimY-minPointDimY)/2*2;
                                    dimension = 0;
                                    
                                    if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
                                    if (horizontalLength < verticalLength) dimension = verticalLength+30;
                                    
                                    dimension = (dimension/2)*2;
                                    
                                    horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
                                    verticalStart = minPointDimY-(dimension-verticalLength)/2;
                                    
                                    int **connectivityMapVerMap = new int *[dimension+1];
                                    
                                    for (int counter3 = 0; counter3 < dimension+1; counter3++){
                                        connectivityMapVerMap [counter3] = new int [dimension+1];
                                    }
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            connectivityMapVerMap [counterY][counterX] = 0;
                                        }
                                    }
                                    
                                    for (int counter3 = connectLimit [counter2*4+1]; counter3 <= connectLimit [counter2*4]; counter3++){
                                        for (int counter4 = connectLimit [counter2*4+3]; counter4 <= connectLimit [counter2*4+2]; counter4++){
                                            if (counter2 == revisedMapVer [counter3][counter4]){
                                                if (counter3-verticalStart >= 0 && counter3-verticalStart < dimension && counter4-horizontalStart >= 0 && counter4-horizontalStart < dimension){
                                                    connectivityMapVerMap [counter3-verticalStart][counter4-horizontalStart] = 1;
                                                }
                                            }
                                        }
                                    }
                                    
                                    //-----Fill inside-----
                                    int *connectAnalysisX = new int [dimension*4];
                                    int *connectAnalysisY = new int [dimension*4];
                                    int *connectAnalysisTempX = new int [dimension*4];
                                    int *connectAnalysisTempY = new int [dimension*4];
                                    
                                    connectivityNumber = -3;
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (connectivityMapVerMap [counterY][counterX] == 0){
                                                connectivityNumber = connectivityNumber+2;
                                                connectAnalysisCount = 0;
                                                
                                                if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMapVerMap [counterY][counterX] = connectivityNumber;
                                                
                                                if (counterY-1 >= 0 && connectivityMapVerMap [counterY-1][counterX] == 0){
                                                    connectivityMapVerMap [counterY-1][counterX] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                }
                                                if (counterX+1 < dimension && connectivityMapVerMap [counterY][counterX+1] == 0){
                                                    connectivityMapVerMap [counterY][counterX+1] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                }
                                                if (counterY+1 < dimension && connectivityMapVerMap [counterY+1][counterX] == 0){
                                                    connectivityMapVerMap [counterY+1][counterX] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                }
                                                if (counterX-1 >= 0 && connectivityMapVerMap [counterY][counterX-1] == 0){
                                                    connectivityMapVerMap [counterY][counterX-1] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                }
                                                
                                                if (connectAnalysisCount != 0){
                                                    do{
                                                        
                                                        terminationFlag = 1;
                                                        connectAnalysisTempCount = 0;
                                                        
                                                        for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                            xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                            
                                                            if (ySource-1 >= 0 && connectivityMapVerMap [ySource-1][xSource] == 0){
                                                                connectivityMapVerMap [ySource-1][xSource] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                            }
                                                            if (xSource+1 < dimension && connectivityMapVerMap [ySource][xSource+1] == 0){
                                                                connectivityMapVerMap [ySource][xSource+1] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                            }
                                                            if (ySource+1 < dimension && connectivityMapVerMap [ySource+1][xSource] == 0){
                                                                connectivityMapVerMap [ySource+1][xSource] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                            }
                                                            if (xSource-1 >= 0 && connectivityMapVerMap [ySource][xSource-1] == 0){
                                                                connectivityMapVerMap [ySource][xSource-1] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                            }
                                                        }
                                                        
                                                        for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                            connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                        }
                                                        
                                                        connectAnalysisCount = connectAnalysisTempCount;
                                                        
                                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                                        
                                                    } while (terminationFlag == 1);
                                                }
                                            }
                                        }
                                    }
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (connectivityMapVerMap [counterY][counterX] == -1) connectivityMapVerMap [counterY][counterX] = 0;
                                            else connectivityMapVerMap [counterY][counterX] = 1;
                                        }
                                    }
                                    
                                    //-----Connectivity analysis, For Zero-----
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (connectivityMapVerMap [counterY][counterX] != 0){
                                                if (counterX+1 < dimension && connectivityMapVerMap [counterY][counterX+1] == 0) connectivityMapVerMap [counterY][counterX] = -1;
                                                else if (counterY+1 < dimension && connectivityMapVerMap [counterY+1][counterX] == 0) connectivityMapVerMap [counterY][counterX] = -1;
                                                else if (counterX-1 >= 0 && connectivityMapVerMap [counterY][counterX-1] == 0) connectivityMapVerMap [counterY][counterX] = -1;
                                                else if (counterY-1 >= 0 && connectivityMapVerMap [counterY-1][counterX] == 0) connectivityMapVerMap [counterY][counterX] = -1;
                                            }
                                        }
                                    }
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (connectivityMapVerMap [counterY][counterX] > 0) connectivityMapVerMap [counterY][counterX] = 0;
                                            if (connectivityMapVerMap [counterY][counterX] < 0) connectivityMapVerMap [counterY][counterX] = 1;
                                        }
                                    }
                                    
                                    delete [] connectAnalysisX;
                                    delete [] connectAnalysisY;
                                    delete [] connectAnalysisTempX;
                                    delete [] connectAnalysisTempY;
                                    
                                    connectivityNumber = 0;
                                    
                                    connectAnalysisX = new int [dimension*4];
                                    connectAnalysisY = new int [dimension*4];
                                    connectAnalysisTempX = new int [dimension*4];
                                    connectAnalysisTempY = new int [dimension*4];
                                    
                                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                            if (connectivityMapVerMap [counterY2][counterX2] == 0){
                                                connectivityNumber--;
                                                connectAnalysisCount = 0;
                                                
                                                connectivityMapVerMap [counterY2][counterX2] = connectivityNumber;
                                                
                                                if (counterY2-1 >= 0 && connectivityMapVerMap [counterY2-1][counterX2] == 0){
                                                    connectivityMapVerMap [counterY2-1][counterX2] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                                }
                                                if (counterX2+1 < dimension && connectivityMapVerMap [counterY2][counterX2+1] == 0){
                                                    connectivityMapVerMap [counterY2][counterX2+1] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                                }
                                                if (counterY2+1 < dimension && connectivityMapVerMap [counterY2+1][counterX2] == 0){
                                                    connectivityMapVerMap [counterY2+1][counterX2] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                                }
                                                if (counterX2-1 >= 0 && connectivityMapVerMap [counterY2][counterX2-1] == 0){
                                                    connectivityMapVerMap [counterY2][counterX2-1] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                                }
                                                
                                                if (connectAnalysisCount != 0){
                                                    do{
                                                        
                                                        terminationFlag = 1;
                                                        connectAnalysisTempCount = 0;
                                                        
                                                        for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                            xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                            
                                                            if (ySource-1 >= 0 && connectivityMapVerMap [ySource-1][xSource] == 0){
                                                                connectivityMapVerMap [ySource-1][xSource] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                            }
                                                            if (xSource+1 < dimension && connectivityMapVerMap [ySource][xSource+1] == 0){
                                                                connectivityMapVerMap [ySource][xSource+1] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                            }
                                                            if (ySource+1 < dimension && connectivityMapVerMap [ySource+1][xSource] == 0){
                                                                connectivityMapVerMap [ySource+1][xSource] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                            }
                                                            if (xSource-1 >= 0 && connectivityMapVerMap [ySource][xSource-1] == 0){
                                                                connectivityMapVerMap [ySource][xSource-1] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                            }
                                                        }
                                                        
                                                        for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                            connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                        }
                                                        
                                                        connectAnalysisCount = connectAnalysisTempCount;
                                                        
                                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                                        
                                                    } while (terminationFlag == 1);
                                                }
                                            }
                                        }
                                    }
                                    
                                    delete [] connectAnalysisX;
                                    delete [] connectAnalysisY;
                                    delete [] connectAnalysisTempX;
                                    delete [] connectAnalysisTempY;
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (connectivityMapVerMap [counterY][counterX] == 1 || connectivityMapVerMap [counterY][counterX] == -2){
                                                connectivityMapVerMap [counterY][counterX] = 1;
                                            }
                                            else connectivityMapVerMap [counterY][counterX] = 0;
                                        }
                                    }
                                    
                                    overlapFind = 0;
                                    overlapNumber = 0;
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (connectivityMapVerMap [counterY][counterX] != 0 && revisedMapVerTemp [counterY+verticalStart][counterX+horizontalStart] != 0){
                                                overlapFind = 1;
                                                overlapNumber = revisedMapVerTemp [counterY+verticalStart][counterX+horizontalStart];
                                            }
                                        }
                                    }
                                    
                                    areaCount = 0;
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (connectivityMapVerMap [counterY][counterX] == 1) areaCount++;
                                        }
                                    }
                                    
                                    if (overlapFind == 0){
                                        processOrder [counter2] = to_string(counter2)+"~"+to_string(areaCount)+"/!";
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                if (connectivityMapVerMap [counterY][counterX] != 0 && counterY+verticalStart >= 0 && counterY+verticalStart < imageSize && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageSize){
                                                    revisedMapVerTemp [counterY+verticalStart][counterX+horizontalStart] = counter2;
                                                }
                                            }
                                        }
                                    }
                                    else{
                                        
                                        for (int counter3 = 1; counter3 <= maxMapConnect; counter3++){
                                            if (atoi(processOrder [counter3].substr(0, processOrder [counter3].find("~")).c_str()) == overlapNumber){
                                                numberOfSlash = 0;
                                                extractString = processOrder [counter3];
                                                
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    
                                                    if ((int)extractString.find("/!") != -1){
                                                        numberOfSlash++;
                                                        extractString = extractString.substr(extractString.find("/!")+2);
                                                    }
                                                    else terminationFlag = 0;
                                                    
                                                } while(terminationFlag == 1);
                                                
                                                int *listOfConnectNo = new int [numberOfSlash*2+10];
                                                
                                                extractString = processOrder [counter3];
                                                numberOfSlash = 0;
                                                firstConnectNo = 0;
                                                
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    
                                                    if ((int)extractString.find("/!") != -1){
                                                        extractString2 = extractString.substr(0, extractString.find("/!"));
                                                        
                                                        listOfConnectNo [numberOfSlash*2] = atoi(extractString.substr(0, extractString2.find("~")).c_str());
                                                        listOfConnectNo [numberOfSlash*2+1] = atoi(extractString.substr(extractString2.find("~")+1).c_str());
                                                        
                                                        extractString = extractString.substr(extractString.find("/!")+2);
                                                        
                                                        if (numberOfSlash == 0) firstConnectNo = listOfConnectNo [numberOfSlash*2];
                                                        
                                                        numberOfSlash++;
                                                    }
                                                    else terminationFlag = 0;
                                                    
                                                } while(terminationFlag == 1);
                                                
                                                areaSizeHold = 0;
                                                
                                                for (int counter4 = 0; counter4 < numberOfSlash; counter4++){
                                                    if (listOfConnectNo [counter4*2+1] > areaSizeHold){
                                                        areaSizeHold = listOfConnectNo [counter4*2+1];
                                                    }
                                                }
                                                
                                                if (areaSizeHold < areaCount){
                                                    for (int counterY = 0; counterY < dimension; counterY++){
                                                        for (int counterX = 0; counterX < dimension; counterX++){
                                                            if (connectivityMapVerMap [counterY][counterX] != 0 && counterY+verticalStart >= 0 && counterY+verticalStart < imageSize && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageSize){
                                                                revisedMapVerTemp [counterY+verticalStart][counterX+horizontalStart] = firstConnectNo;
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                processOrder [counter3] = processOrder [counter3]+to_string(counter2)+"~"+to_string(areaCount)+"/!";
                                                
                                                delete [] listOfConnectNo;
                                                
                                                break;
                                            }
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < dimension+1; counter3++){
                                        delete [] connectivityMapVerMap [counter3];
                                    }
                                    
                                    delete [] connectivityMapVerMap;
                                }
                            }
                            
                            int *processOrderSort = new int [maxMapConnect*2+10];
                            processOrderSortCount = 0;
                            
                            for (int counter2 = 0; counter2 < maxMapConnect*2+10; counter2++) processOrderSort [counter2] = 0;
                            
                            for (int counter2 = 1; counter2 <= maxMapConnect; counter2++){
                                if (processOrder [counter2] != "nil"){
                                    numberOfSlash = 0;
                                    extractString = processOrder [counter2];
                                    
                                    do{
                                        
                                        terminationFlag = 1;
                                        
                                        if ((int)extractString.find("/!") != -1){
                                            numberOfSlash++;
                                            extractString = extractString.substr(extractString.find("/!")+2);
                                        }
                                        else terminationFlag = 0;
                                        
                                    } while(terminationFlag == 1);
                                    
                                    if (numberOfSlash == 1){
                                        processOrderSort [processOrderSortCount] = atoi(processOrder [counter2].substr(0, processOrder [counter2].find("~")).c_str()), processOrderSortCount++;
                                        processOrderSort [processOrderSortCount] = atoi(processOrder [counter2].substr(processOrder [counter2].find("~")+1, processOrder [counter2].find("/")-processOrder [counter2].find("~")-1).c_str()), processOrderSortCount++;
                                    }
                                    else{
                                        
                                        int *listOfConnectNo = new int [numberOfSlash*2+10];
                                        
                                        extractString = processOrder [counter2];
                                        numberOfSlash = 0;
                                        
                                        do{
                                            
                                            terminationFlag = 1;
                                            
                                            if ((int)extractString.find("/!") != -1){
                                                extractString2 = extractString.substr(0, extractString.find("/!"));
                                                
                                                listOfConnectNo [numberOfSlash*2] = atoi(extractString.substr(0, extractString2.find("~")).c_str());
                                                listOfConnectNo [numberOfSlash*2+1] = atoi(extractString.substr(extractString2.find("~")+1).c_str());
                                                
                                                extractString = extractString.substr(extractString.find("/!")+2);
                                                
                                                numberOfSlash++;
                                            }
                                            else terminationFlag = 0;
                                            
                                        } while(terminationFlag == 1);
                                        
                                        do{
                                            
                                            terminationFlag = 1;
                                            areaSizeCheck = -1;
                                            areaSizeHold = 0;
                                            
                                            for (int counter4 = 0; counter4 < numberOfSlash; counter4++){
                                                if (listOfConnectNo [counter4*2+1] > areaSizeHold){
                                                    areaSizeCheck = counter4;
                                                    areaSizeHold = listOfConnectNo [counter4*2+1];
                                                }
                                            }
                                            
                                            if (areaSizeHold != 0 && areaSizeCheck != -1){
                                                processOrderSort [processOrderSortCount] = listOfConnectNo [areaSizeCheck*2], processOrderSortCount++;
                                                processOrderSort [processOrderSortCount] = listOfConnectNo [areaSizeCheck*2+1], processOrderSortCount++;
                                                listOfConnectNo [areaSizeCheck*2] = -2;
                                                listOfConnectNo [areaSizeCheck*2+1] = -2;
                                            }
                                            else  terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                        
                                        delete [] listOfConnectNo;
                                    }
                                }
                            }
                            
                            int *gravityCenterList = new int [maxMapConnect*3+10];
                            
                            for (int counter2 = 0; counter2 < maxMapConnect*3+10; counter2++) gravityCenterList [counter2] = 0;
                            
                            for (int counter2 = 0; counter2 < processOrderSortCount/2; counter2++){
                                processConnectNo = processOrderSort [counter2*2];
                                
                                maxPointDimX = 0;
                                maxPointDimY = 0;
                                minPointDimX = 1000000;
                                minPointDimY = 1000000;
                                
                                for (int counter3 = connectLimit [processConnectNo*4+1]; counter3 <= connectLimit [processConnectNo*4]; counter3++){
                                    for (int counter4 = connectLimit [processConnectNo*4+3]; counter4 <= connectLimit [processConnectNo*4+2]; counter4++){
                                        if (processConnectNo == revisedMapVer [counter3][counter4]){
                                            if (maxPointDimX < counter4) maxPointDimX = counter4;
                                            if (minPointDimX > counter4) minPointDimX = counter4;
                                            if (maxPointDimY < counter3) maxPointDimY = counter3;
                                            if (minPointDimY > counter3) minPointDimY = counter3;
                                        }
                                    }
                                }
                                
                                if (minPointDimX != 1000000){
                                    //-----Determine the dimension of cell-----
                                    horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                                    verticalLength = (maxPointDimY-minPointDimY)/2*2;
                                    dimension = 0;
                                    
                                    if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
                                    if (horizontalLength < verticalLength) dimension = verticalLength+30;
                                    
                                    dimension = (dimension/2)*2;
                                    
                                    horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
                                    verticalStart = minPointDimY-(dimension-verticalLength)/2;
                                    
                                    int **connectivityMapVerMap = new int *[dimension+1];
                                    
                                    for (int counter3 = 0; counter3 < dimension+1; counter3++){
                                        connectivityMapVerMap [counter3] = new int [dimension+1];
                                    }
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            connectivityMapVerMap [counterY][counterX] = 0;
                                        }
                                    }
                                    
                                    for (int counter3 = connectLimit [processConnectNo*4+1]; counter3 <= connectLimit [processConnectNo*4]; counter3++){
                                        for (int counter4 = connectLimit [processConnectNo*4+3]; counter4 <= connectLimit [processConnectNo*4+2]; counter4++){
                                            if (processConnectNo == revisedMapVer [counter3][counter4]){
                                                if (counter3-verticalStart >= 0 && counter3-verticalStart < dimension && counter4-horizontalStart >= 0 && counter4-horizontalStart < dimension){
                                                    connectivityMapVerMap [counter3-verticalStart][counter4-horizontalStart] = 1;
                                                }
                                            }
                                        }
                                    }
                                    
                                    mapGravityCenterCalculationX = 0;
                                    mapGravityCenterCalculationY = 0;
                                    mapGRPoint = 0;
                                    totalIntensity = 0;
                                    totalIntensityInt = 0;
                                    
                                    for (int counter3 = 0; counter3 < dimension; counter3++){
                                        for (int counter4 = 0; counter4 < dimension; counter4++){
                                            if (connectivityMapVerMap [counter3][counter4] == 1){
                                                mapGravityCenterCalculationX = mapGravityCenterCalculationX+counter4;
                                                mapGravityCenterCalculationY = mapGravityCenterCalculationY+counter3;
                                                mapGRPoint++;
                                                
                                                if (counter3+verticalStart >= 0 && counter3-verticalStart < imageSize && counter4+horizontalStart >= 0 && counter4+horizontalStart < imageSize){
                                                    totalIntensity = totalIntensity+sourceMapVer [counter3+verticalStart][counter4+horizontalStart];
                                                }
                                            }
                                        }
                                    }
                                    
                                    if (mapGRPoint != 0) totalIntensityInt = (int)(totalIntensity/(double)mapGRPoint);
                                    
                                    mapGravityCenterCalculationIntX = (int)(mapGravityCenterCalculation [processConnectNo*2]/(double)mapGRPointNo [processConnectNo]);
                                    mapGravityCenterCalculationIntY = (int)(mapGravityCenterCalculation [processConnectNo*2+1]/(double)mapGRPointNo [processConnectNo]);
                                    
                                    gravityCenterList [processConnectNo*3] = mapGravityCenterCalculationIntX;
                                    gravityCenterList [processConnectNo*3+1] = mapGravityCenterCalculationIntY;
                                    
                                    //-----Fill inside-----
                                    int *connectAnalysisX = new int [dimension*4];
                                    int *connectAnalysisY = new int [dimension*4];
                                    int *connectAnalysisTempX = new int [dimension*4];
                                    int *connectAnalysisTempY = new int [dimension*4];
                                    
                                    connectivityNumber = -3;
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (connectivityMapVerMap [counterY][counterX] == 0){
                                                connectivityNumber = connectivityNumber+2;
                                                connectAnalysisCount = 0;
                                                
                                                if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMapVerMap [counterY][counterX] = connectivityNumber;
                                                
                                                if (counterY-1 >= 0 && connectivityMapVerMap [counterY-1][counterX] == 0){
                                                    connectivityMapVerMap [counterY-1][counterX] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                }
                                                if (counterX+1 < dimension && connectivityMapVerMap [counterY][counterX+1] == 0){
                                                    connectivityMapVerMap [counterY][counterX+1] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                }
                                                if (counterY+1 < dimension && connectivityMapVerMap [counterY+1][counterX] == 0){
                                                    connectivityMapVerMap [counterY+1][counterX] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                }
                                                if (counterX-1 >= 0 && connectivityMapVerMap [counterY][counterX-1] == 0){
                                                    connectivityMapVerMap [counterY][counterX-1] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                }
                                                
                                                if (connectAnalysisCount != 0){
                                                    do{
                                                        
                                                        terminationFlag = 1;
                                                        connectAnalysisTempCount = 0;
                                                        
                                                        for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                            xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                            
                                                            if (ySource-1 >= 0 && connectivityMapVerMap [ySource-1][xSource] == 0){
                                                                connectivityMapVerMap [ySource-1][xSource] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                            }
                                                            if (xSource+1 < dimension && connectivityMapVerMap [ySource][xSource+1] == 0){
                                                                connectivityMapVerMap [ySource][xSource+1] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                            }
                                                            if (ySource+1 < dimension && connectivityMapVerMap [ySource+1][xSource] == 0){
                                                                connectivityMapVerMap [ySource+1][xSource] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                            }
                                                            if (xSource-1 >= 0 && connectivityMapVerMap [ySource][xSource-1] == 0){
                                                                connectivityMapVerMap [ySource][xSource-1] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                            }
                                                        }
                                                        
                                                        for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                            connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                        }
                                                        
                                                        connectAnalysisCount = connectAnalysisTempCount;
                                                        
                                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                                        
                                                    } while (terminationFlag == 1);
                                                }
                                            }
                                        }
                                    }
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (connectivityMapVerMap [counterY][counterX] == -1) connectivityMapVerMap [counterY][counterX] = 0;
                                            else connectivityMapVerMap [counterY][counterX] = 1;
                                        }
                                    }
                                    
                                    //-----Connectivity analysis, For Zero-----
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (connectivityMapVerMap [counterY][counterX] != 0){
                                                if (counterX+1 < dimension && connectivityMapVerMap [counterY][counterX+1] == 0) connectivityMapVerMap [counterY][counterX] = -1;
                                                else if (counterY+1 < dimension && connectivityMapVerMap [counterY+1][counterX] == 0) connectivityMapVerMap [counterY][counterX] = -1;
                                                else if (counterX-1 >= 0 && connectivityMapVerMap [counterY][counterX-1] == 0) connectivityMapVerMap [counterY][counterX] = -1;
                                                else if (counterY-1 >= 0 && connectivityMapVerMap [counterY-1][counterX] == 0) connectivityMapVerMap [counterY][counterX] = -1;
                                            }
                                        }
                                    }
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (connectivityMapVerMap [counterY][counterX] > 0) connectivityMapVerMap [counterY][counterX] = 0;
                                            if (connectivityMapVerMap [counterY][counterX] < 0) connectivityMapVerMap [counterY][counterX] = 1;
                                        }
                                    }
                                    
                                    connectivityNumber = 0;
                                    
                                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                            if (connectivityMapVerMap [counterY2][counterX2] == 0){
                                                connectivityNumber--;
                                                connectAnalysisCount = 0;
                                                
                                                connectivityMapVerMap [counterY2][counterX2] = connectivityNumber;
                                                
                                                if (counterY2-1 >= 0 && connectivityMapVerMap [counterY2-1][counterX2] == 0){
                                                    connectivityMapVerMap [counterY2-1][counterX2] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                                }
                                                if (counterX2+1 < dimension && connectivityMapVerMap [counterY2][counterX2+1] == 0){
                                                    connectivityMapVerMap [counterY2][counterX2+1] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                                }
                                                if (counterY2+1 < dimension && connectivityMapVerMap [counterY2+1][counterX2] == 0){
                                                    connectivityMapVerMap [counterY2+1][counterX2] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                                }
                                                if (counterX2-1 >= 0 && connectivityMapVerMap [counterY2][counterX2-1] == 0){
                                                    connectivityMapVerMap [counterY2][counterX2-1] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                                }
                                                
                                                if (connectAnalysisCount != 0){
                                                    do{
                                                        
                                                        terminationFlag = 1;
                                                        connectAnalysisTempCount = 0;
                                                        
                                                        for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                            xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                            
                                                            if (ySource-1 >= 0 && connectivityMapVerMap [ySource-1][xSource] == 0){
                                                                connectivityMapVerMap [ySource-1][xSource] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                            }
                                                            if (xSource+1 < dimension && connectivityMapVerMap [ySource][xSource+1] == 0){
                                                                connectivityMapVerMap [ySource][xSource+1] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                            }
                                                            if (ySource+1 < dimension && connectivityMapVerMap [ySource+1][xSource] == 0){
                                                                connectivityMapVerMap [ySource+1][xSource] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                            }
                                                            if (xSource-1 >= 0 && connectivityMapVerMap [ySource][xSource-1] == 0){
                                                                connectivityMapVerMap [ySource][xSource-1] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                            }
                                                        }
                                                        
                                                        for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                            connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                        }
                                                        
                                                        connectAnalysisCount = connectAnalysisTempCount;
                                                        
                                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                                        
                                                    } while (terminationFlag == 1);
                                                }
                                            }
                                        }
                                    }
                                    
                                    delete [] connectAnalysisX;
                                    delete [] connectAnalysisY;
                                    delete [] connectAnalysisTempX;
                                    delete [] connectAnalysisTempY;
                                    
                                    //-----Determine number of pixels-----
                                    connectivityNumber = connectivityNumber*-1;
                                    
                                    int *connectedPix = new int [connectivityNumber+50];
                                    for (int counter3 = 0; counter3 <= connectivityNumber; counter3++) connectedPix [counter3] = 0;
                                    
                                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                            if (connectivityMapVerMap [counterY2][counterX2] < -1 && connectivityMapVerMap [counterY2][counterX2] != 0){
                                                connectedPix [connectivityMapVerMap [counterY2][counterX2]*-1]++;
                                            }
                                        }
                                    }
                                    
                                    largestConnect = 0;
                                    largestConnectNo = 0;
                                    
                                    for (int counter3 = 2; counter3 <= connectivityNumber; counter3++){
                                        if (connectedPix [counter3] > largestConnect){
                                            largestConnect = connectedPix [counter3];
                                            largestConnectNo = counter3;
                                        }
                                    }
                                    
                                    delete [] connectedPix;
                                    
                                    int **newConnectivityMapTemp = new int *[dimension+4];
                                    for (int counter3 = 0; counter3 < dimension+4; counter3++) newConnectivityMapTemp [counter3] = new int [dimension+4];
                                    
                                    for (int counterY = 0; counterY < dimension+4; counterY++){
                                        for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
                                    }
                                    
                                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                            if (connectivityMapVerMap [counterY2][counterX2] == largestConnectNo*-1){
                                                if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityMapVerMap [counterY2-1][counterX2-1] == 1){
                                                    newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                                                    connectivityMapVerMap [counterY2-1][counterX2-1] = 0;
                                                }
                                                if (counterY2-1 >= 0 && connectivityMapVerMap [counterY2-1][counterX2] == 1){
                                                    newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                                                    connectivityMapVerMap [counterY2-1][counterX2] = 0;
                                                }
                                                if (counterY2-1 >= 0 && counterX2+1 < dimension && connectivityMapVerMap [counterY2-1][counterX2+1] == 1){
                                                    newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                                                    connectivityMapVerMap [counterY2-1][counterX2+1] = 0;
                                                }
                                                if (counterX2+1 < dimension && connectivityMapVerMap [counterY2][counterX2+1] == 1){
                                                    newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                                                    connectivityMapVerMap [counterY2][counterX2+1] = 0;
                                                }
                                                if (counterY2+1 < dimension && counterX2+1 < dimension && connectivityMapVerMap [counterY2+1][counterX2+1] == 1){
                                                    newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                                                    connectivityMapVerMap [counterY2+1][counterX2+1] = 0;
                                                }
                                                if (counterY2+1 < dimension && connectivityMapVerMap [counterY2+1][counterX2] == 1){
                                                    newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                                                    connectivityMapVerMap [counterY2+1][counterX2] = 0;
                                                }
                                                if (counterY2+1 < dimension && counterX2-1 >= 0 && connectivityMapVerMap [counterY2+1][counterX2-1] == 1){
                                                    newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                                                    connectivityMapVerMap [counterY2+1][counterX2-1] = 0;
                                                }
                                                if (counterX2-1 >= 0 && connectivityMapVerMap [counterY2][counterX2-1] == 1){
                                                    newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                                                    connectivityMapVerMap [counterY2][counterX2-1] = 0;
                                                }
                                            }
                                        }
                                    }
                                    
                                    xPositionTempStart = 0;
                                    yPositionTempStart = 0;
                                    lineSize = 0;
                                    
                                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                            if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                                                connectivityMapVerMap [counterY2][counterX2] = 1;
                                                
                                                xPositionTempStart = counterX2;
                                                yPositionTempStart = counterY2;
                                                lineSize++;
                                            }
                                            else connectivityMapVerMap [counterY2][counterX2] = 0;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < dimension+4; counter3++) delete [] newConnectivityMapTemp [counter3];
                                    delete [] newConnectivityMapTemp;
                                    
                                    constructedLineCount = 0;
                                    
                                    int *arrayNewLines = new int [lineSize*2+50];
                                    
                                    connectivityMapVerMap [yPositionTempStart][xPositionTempStart] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                                    
                                    do{
                                        
                                        findFlag = 0;
                                        terminationFlag = 0;
                                        
                                        if (xPositionTempStart+1 < dimension){
                                            if (connectivityMapVerMap [yPositionTempStart][xPositionTempStart+1] == 1){
                                                connectivityMapVerMap [yPositionTempStart][xPositionTempStart+1] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                                                xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                            }
                                        }
                                        if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                                            if (connectivityMapVerMap [yPositionTempStart+1][xPositionTempStart+1] == 1){
                                                connectivityMapVerMap [yPositionTempStart+1][xPositionTempStart+1] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                                                xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                            }
                                        }
                                        if (yPositionTempStart+1 < dimension && findFlag == 0){
                                            if (connectivityMapVerMap [yPositionTempStart+1][xPositionTempStart] == 1){
                                                connectivityMapVerMap [yPositionTempStart+1][xPositionTempStart] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                                                yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                            }
                                        }
                                        if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                                            if (connectivityMapVerMap [yPositionTempStart+1][xPositionTempStart-1] == 1){
                                                connectivityMapVerMap [yPositionTempStart+1][xPositionTempStart-1] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                                                xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                                            }
                                        }
                                        if (xPositionTempStart-1 >= 0 && findFlag == 0){
                                            if (connectivityMapVerMap [yPositionTempStart][xPositionTempStart-1] == 1){
                                                connectivityMapVerMap [yPositionTempStart][xPositionTempStart-1] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                                                xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                            }
                                        }
                                        if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                                            if (connectivityMapVerMap [yPositionTempStart-1][xPositionTempStart-1] == 1){
                                                connectivityMapVerMap [yPositionTempStart-1][xPositionTempStart-1] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                                                xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                            }
                                        }
                                        if (yPositionTempStart-1 >= 0 && findFlag == 0){
                                            if (connectivityMapVerMap [yPositionTempStart-1][xPositionTempStart] == 1){
                                                connectivityMapVerMap [yPositionTempStart-1][xPositionTempStart] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                                                yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                                            }
                                        }
                                        if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                                            if (connectivityMapVerMap [yPositionTempStart-1][xPositionTempStart+1] == 1){
                                                connectivityMapVerMap [yPositionTempStart-1][xPositionTempStart+1] = -1;
                                                arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                                                arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                                                xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                                            }
                                        }
                                        
                                    } while (terminationFlag == 1);
                                    
                                    for (int counter3 = 0; counter3 < constructedLineCount/2; counter3++){
                                        if (positionRevListLimit < positionRevListCount+10){
                                            int *arrayUpDate = new int [positionRevListCount+10];
                                            
                                            for (int counter4 = 0; counter4 < positionRevListCount; counter4++) arrayUpDate [counter4] = positionRevList [counter4];
                                            
                                            delete [] positionRevList;
                                            positionRevList = new int [positionRevListLimit+5000];
                                            positionRevListLimit = positionRevListLimit+5000;
                                            
                                            for (int counter4 = 0; counter4 < positionRevListCount; counter4++) positionRevList [counter4] = arrayUpDate [counter4];
                                            delete [] arrayUpDate;
                                        }
                                        
                                        positionRevList [positionRevListCount] = arrayNewLines [counter3*2], positionRevListCount++;
                                        positionRevList [positionRevListCount] = arrayNewLines [counter3*2+1], positionRevListCount++;
                                        positionRevList [positionRevListCount] = totalIntensityInt, positionRevListCount++;
                                        positionRevList [positionRevListCount] = processConnectNo, positionRevListCount++;
                                        positionRevList [positionRevListCount] = 0, positionRevListCount++;
                                        positionRevList [positionRevListCount] = 0, positionRevListCount++;
                                        positionRevList [positionRevListCount] = 0, positionRevListCount++;
                                    }
                                    
                                    delete [] arrayNewLines;
                                    
                                    for (int counter3 = 0; counter3 < dimension+1; counter3++){
                                        delete [] connectivityMapVerMap [counter3];
                                    }
                                    
                                    delete [] connectivityMapVerMap;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < positionRevListCount/7; counterA++){
                            //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<positionRevList [counterA*7+counterB];
                            //    cout<<" positionRevList "<<counterA<<endl;
                            //}
                            
                            int *lineageExtractTempPR = new int [lineageDataRepairCount+10];
                            lineageExtractTempPRCount = 0;
                            
                            for (int counter2 = 0; counter2 < lineageDataRepairCount/8; counter2++){
                                if (arrayLineageRepairData [counter2*8+3] != 91 && arrayLineageRepairData [counter2*8+3] != 13){
                                    if (arrayLineageRepairData [counter2*8+2] == processTime){
                                        lineageExtractTempPR [lineageExtractTempPRCount] = arrayLineageRepairData [counter2*8+6], lineageExtractTempPRCount++;
                                        lineageExtractTempPR [lineageExtractTempPRCount] = arrayLineageRepairData [counter2*8+5], lineageExtractTempPRCount++;
                                        lineageExtractTempPR [lineageExtractTempPRCount] = arrayLineageRepairData [counter2*8], lineageExtractTempPRCount++;
                                        lineageExtractTempPR [lineageExtractTempPRCount] = arrayLineageRepairData [counter2*8+1], lineageExtractTempPRCount++;
                                        lineageExtractTempPR [lineageExtractTempPRCount] = 0, lineageExtractTempPRCount++;
                                        lineageExtractTempPR [lineageExtractTempPRCount] = 0, lineageExtractTempPRCount++;
                                        lineageExtractTempPR [lineageExtractTempPRCount] = 0, lineageExtractTempPRCount++;
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < lineageExtractTempPRCount/7; counterA++){
                            //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<lineageExtractTempPR [counterA*7+counterB];
                            //    cout<<" lineageExtractTempPR "<<counterA<<endl;
                            //}
                            
                            for (int counter2 = 0; counter2 < lineageExtractTempPRCount/7; counter2++){
                                matchCount = 0;
                                matchPoint = 0;
                                
                                for (int counter3 = 1; counter3 <= maxMapConnect; counter3++){
                                    if (gravityCenterList [counter3*3] == lineageExtractTempPR [counter2*7+2] && gravityCenterList [counter3*3+1] == lineageExtractTempPR [counter2*7+3]){
                                        matchCount++;
                                        matchPoint = counter3;
                                    }
                                }
                                
                                if (matchCount == 1){
                                    lineageExtractTempPR [counter2*7+4] = matchPoint;
                                    lineageExtractTempPR [counter2*7+5] = gravityCenterList [matchPoint*3];
                                    lineageExtractTempPR [counter2*7+6] = gravityCenterList [matchPoint*3+1];
                                    gravityCenterList [matchPoint*3+2] = 1;
                                }
                                else{
                                    
                                    if (matchCount == 0){
                                        matchCount = 0;
                                        matchPoint = 0;
                                        
                                        for (int counter3 = 1; counter3 <= maxMapConnect; counter3++){
                                            if (gravityCenterList [counter3*3+2] == 0){
                                                lingCheckPosition = 0;
                                                
                                                if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3]-1 && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]) lingCheckPosition = 2;
                                                else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3]-1 && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]-1) lingCheckPosition = 2;
                                                else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3] && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]-1) lingCheckPosition = 2;
                                                else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3]+1 && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]-1) lingCheckPosition = 2;
                                                else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3]+1 && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]) lingCheckPosition = 2;
                                                else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3]+1 && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]+1) lingCheckPosition = 2;
                                                else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3] && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]+1) lingCheckPosition = 2;
                                                else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3]+1 && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]+1) lingCheckPosition = 2;
                                                
                                                if (lingCheckPosition == 2){
                                                    matchCount++;
                                                    matchPoint = counter3;
                                                }
                                            }
                                        }
                                        
                                        if (matchCount == 1){
                                            lineageExtractTempPR [counter2*7+4] = matchPoint;
                                            lineageExtractTempPR [counter2*7+5] = gravityCenterList [matchPoint*3];
                                            lineageExtractTempPR [counter2*7+6] = gravityCenterList [matchPoint*3+1];
                                            gravityCenterList [matchPoint*3+2] = 1;
                                        }
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < lineageExtractTempPRCount/7; counterA++){
                            //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<lineageExtractTempPR [counterA*7+counterB];
                            //    cout<<" lineageExtractTempPR "<<counterA<<endl;
                            //}
                            
                            missingFind = 0;
                            
                            for (int counter2 = 0; counter2 < lineageExtractTempPRCount/7; counter2++){
                                if (lineageExtractTempPR [counter2*7+4] == 0){
                                    missingFind = 1;
                                    break;
                                }
                            }
                            
                            if (missingFind == 1){
                                for (int counter2 = 0; counter2 < lineageExtractTempPRCount/7; counter2++){
                                    if (lineageExtractTempPR [counter2*7+4] == 0){
                                        matchCount = 0;
                                        matchPoint = 0;
                                        
                                        for (int counter3 = 1; counter3 <= maxMapConnect; counter3++){
                                            if (gravityCenterList [counter3*3+2] == 0 && gravityCenterList [counter3*3] == lineageExtractTempPR [counter2*7+2] && gravityCenterList [counter3*3+1] == lineageExtractTempPR [counter2*7+3]){
                                                matchCount++;
                                                matchPoint = counter3;
                                            }
                                        }
                                        
                                        if (matchCount == 1){
                                            lineageExtractTempPR [counter2*7+4] = matchPoint;
                                            lineageExtractTempPR [counter2*7+5] = gravityCenterList [matchPoint*3];
                                            lineageExtractTempPR [counter2*7+6] = gravityCenterList [matchPoint*3+1];
                                            gravityCenterList [matchPoint*3+2] = 1;
                                        }
                                        else if (matchCount > 1){
                                            listOrderPositionHold = -1;
                                            listOrderConnect = 0;
                                            
                                            for (int counter3 = 1; counter3 <= maxMapConnect; counter3++){
                                                if (gravityCenterList [counter3*3+2] == 0 && gravityCenterList [counter3*3] == lineageExtractTempPR [counter2*7+2] && gravityCenterList [counter3*3+1] == lineageExtractTempPR [counter2*7+3]){
                                                    for (int counter4 = 0; counter4 < processOrderSortCount/2; counter4++){
                                                        if (processOrderSort [counter4*2] == counter3){
                                                            if (listOrderPositionHold < counter4){
                                                                listOrderPositionHold = counter4;
                                                                listOrderConnect = counter3;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            if (listOrderPositionHold != -1){
                                                lineageExtractTempPR [counter2*7+4] = listOrderConnect;
                                                lineageExtractTempPR [counter2*7+5] = gravityCenterList [listOrderConnect*3];
                                                lineageExtractTempPR [counter2*7+6] = gravityCenterList [listOrderConnect*3+1];
                                                gravityCenterList [listOrderConnect*3+2] = 1;
                                            }
                                        }
                                        else if (matchCount == 0){
                                            matchCount = 0;
                                            matchPoint = 0;
                                            
                                            for (int counter3 = 1; counter3 <= maxMapConnect; counter3++){
                                                if (gravityCenterList [counter3*3+2] == 0){
                                                    lingCheckPosition = 0;
                                                    
                                                    if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3]-1 && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]) lingCheckPosition = 2;
                                                    else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3]-1 && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]-1) lingCheckPosition = 2;
                                                    else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3] && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]-1) lingCheckPosition = 2;
                                                    else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3]+1 && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]-1) lingCheckPosition = 2;
                                                    else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3]+1 && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]) lingCheckPosition = 2;
                                                    else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3]+1 && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]+1) lingCheckPosition = 2;
                                                    else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3] && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]+1) lingCheckPosition = 2;
                                                    else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3]+1 && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]+1) lingCheckPosition = 2;
                                                    
                                                    if (lingCheckPosition == 2){
                                                        matchCount++;
                                                        matchPoint = counter3;
                                                    }
                                                }
                                            }
                                            
                                            if (matchCount == 1){
                                                lineageExtractTempPR [counter2*7+4] = matchPoint;
                                                lineageExtractTempPR [counter2*7+5] = gravityCenterList [matchPoint*3];
                                                lineageExtractTempPR [counter2*7+6] = gravityCenterList [matchPoint*3+1];
                                                gravityCenterList [matchPoint*3+2] = 1;
                                            }
                                            else if (matchCount > 1){
                                                listOrderPositionHold = -1;
                                                listOrderConnect = 0;
                                                
                                                for (int counter3 = 1; counter3 <= maxMapConnect; counter3++){
                                                    if (gravityCenterList [counter3*3+2] == 0){
                                                        lingCheckPosition = 0;
                                                        
                                                        if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3]-1 && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]) lingCheckPosition = 2;
                                                        else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3]-1 && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]-1) lingCheckPosition = 2;
                                                        else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3] && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]-1) lingCheckPosition = 2;
                                                        else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3]+1 && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]-1) lingCheckPosition = 2;
                                                        else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3]+1 && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]) lingCheckPosition = 2;
                                                        else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3]+1 && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]+1) lingCheckPosition = 2;
                                                        else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3] && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]+1) lingCheckPosition = 2;
                                                        else if (lineageExtractTempPR [counter2*7+2] == gravityCenterList [counter3*3]+1 && lineageExtractTempPR [counter2*7+3] == gravityCenterList [counter3*3+1]+1) lingCheckPosition = 2;
                                                        
                                                        if (lingCheckPosition == 2){
                                                            for (int counter4 = 0; counter4 < processOrderSortCount/2; counter4++){
                                                                if (processOrderSort [counter4*2] == counter3){
                                                                    if (listOrderPositionHold < counter4){
                                                                        listOrderPositionHold = counter4;
                                                                        listOrderConnect = counter3;
                                                                        break;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                if (listOrderPositionHold != -1){
                                                    lineageExtractTempPR [counter2*7+4] = listOrderConnect;
                                                    lineageExtractTempPR [counter2*7+5] = gravityCenterList [listOrderConnect*3];
                                                    lineageExtractTempPR [counter2*7+6] = gravityCenterList [listOrderConnect*3+1];
                                                    gravityCenterList [listOrderConnect*3+2] = 1;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < lineageExtractTempPRCount/7; counterA++){
                            //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<lineageExtractTempPR [counterA*7+counterB];
                            //    cout<<" lineageExtractTempPR "<<counterA<<endl;
                            //}
                            
                            //**********Position Revise (main line data array)**********
                            //1. X position;
                            //2. Y position;
                            //3. Average:
                            //4. Connect No;
                            //5. Cell No;
                            //6. Status (0. Non-Track (+Noise), 1. Track (+Cell Confirm), 2. Non-Track Deleted, 3. Track-Deleted)
                            //7. Lineage no;
                            
                            for (int counter2 = 0; counter2 < positionRevListCount/7; counter2++){
                                for (int counter3 = 0; counter3 < lineageExtractTempPRCount/7; counter3++){
                                    if (positionRevList [counter2*7+3] == lineageExtractTempPR [counter3*7+4]){
                                        positionRevList [counter2*7+4] = lineageExtractTempPR [counter3*7+1];
                                        positionRevList [counter2*7+5] = 1;
                                        positionRevList [counter2*7+6] = lineageExtractTempPR [counter3*7];
                                        break;
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < positionRevListCount/7; counterA++){
                            //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<positionRevList [counterA*7+counterB];
                            //    cout<<" positionRevList "<<counterA<<endl;
                            //}
                            
                            for (int counter2 = 0; counter2 < lineageExtractTempPRCount/7; counter2++){
                                if (lineageExtractTempPR [counter2*7+5] != 0 && lineageExtractTempPR [counter2*7+6] != 0 && (lineageExtractTempPR [counter2*7+2] != lineageExtractTempPR [counter2*7+5] || lineageExtractTempPR [counter2*7+3] != lineageExtractTempPR [counter2*7+6])){
                                    for (int counter3 = 0; counter3 < lineageDataRepairCount/8; counter3++){
                                        if (arrayLineageRepairData [counter3*8+2] == processTime && arrayLineageRepairData [counter3*8+5] == lineageExtractTempPR [counter2*7+1] && arrayLineageRepairData [counter3*8+6] == lineageExtractTempPR [counter2*7]){
                                            arrayLineageRepairData [counter3*8] = lineageExtractTempPR [counter2*7+5];
                                            arrayLineageRepairData [counter3*8+1] = lineageExtractTempPR [counter2*7+6];
                                            
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < lineageDataRepairCount/8; counterA++){
                            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageRepairData [counterA*8+counterB];
                            //    cout<<" arrayLineageRepairData "<<counterA<<endl;
                            //}
                            
                            delete [] arrayPositionReviseVer;
                            arrayPositionReviseVer = new int [positionRevListCount];
                            
                            positionReviseVerCount = 0;
                            
                            for (int counter2 = 0; counter2 < positionRevListCount; counter2++) arrayPositionReviseVer [positionReviseVerCount] = positionRevList [counter2], positionReviseVerCount++;
                            
                            self->dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                            [self->dataRepairReadWrite lineageDataSave];
                            
                            delete [] connectLimit;
                            delete [] positionRevList;
                            
                            delete [] processOrder;
                            delete [] processOrderSort;
                            delete [] lineageExtractTempPR;
                            delete [] gravityCenterList;
                            
                            if (processType != 1){
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                            }
                        }
                        
                        //for (int counterA = 0; counterA < positionReviseVerCount/7; counterA++){
                        //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionReviseVer [counterA*7+counterB];
                        //    cout<<" arrayPositionReviseVer "<<counterA<<endl;
                        //}
                        
                        if (processType == 1 || processType == 2 || processType == 7){
                            //**********ConnectLineageRel**********
                            //1. Lineage No;
                            //2. Connect No;
                            //3. Image number;
                            //4. Cell no;
                            //5. Target (0: non-target, 1: target);
                            //6. Reserve;
                            
                            //**********Position Revise (main line data array)**********
                            //1. X position;
                            //2. Y position;
                            //3. Average:
                            //4. Connect No;
                            //5. Cell No;
                            //6. Status (0. Non-Track (+Noise), 1. Track (+Cell Confirm), 2. Non-Track Deleted, 3. Track-Deleted)
                            //7. Lineage no;
                            
                            //-----RL data reconstruct-----
                            int *rlDataReconstruct = new int [(maxConnectNoMap+1)*6+50];
                            int *rlDataReconstruct2 = new int [(maxConnectNoMap+1)*6+50];
                            rlDataReconstructCount2 = 0;
                            
                            for (int counter3 = 0; counter3 < (maxConnectNoMap+1)*6+50; counter3++){
                                rlDataReconstruct [counter3] = 0;
                                rlDataReconstruct2 [counter3] = 0;
                            }
                            
                            for (int counter2 = 0; counter2 < positionReviseVerCount/7; counter2++){
                                if (arrayPositionReviseVer [counter2*7+5] == 0 || arrayPositionReviseVer [counter2*7+5] == 1){
                                    rlDataReconstruct [arrayPositionReviseVer [counter2*7+3]*6] = arrayPositionReviseVer [counter2*7+6];
                                    rlDataReconstruct [arrayPositionReviseVer [counter2*7+3]*6+1] = arrayPositionReviseVer [counter2*7+3];
                                    rlDataReconstruct [arrayPositionReviseVer [counter2*7+3]*6+2] = processTime;
                                    rlDataReconstruct [arrayPositionReviseVer [counter2*7+3]*6+3] = arrayPositionReviseVer [counter2*7+4];
                                    rlDataReconstruct [arrayPositionReviseVer [counter2*7+3]*6+4] = 0;
                                    rlDataReconstruct [arrayPositionReviseVer [counter2*7+3]*6+5] = arrayPositionReviseVer [counter2*7+5]; //-----Status-----
                                }
                            }
                            
                            //for (int counterA = 1; counterA <= maxConnectNoMap; counterA++){
                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<rlDataReconstruct [counterA*6+counterB];
                            //    cout<<" rlDataReconstruct "<<counterA<<endl;
                            //}
                            
                            for (int counter3 = 1; counter3 <= maxConnectNoMap; counter3++){
                                if (rlDataReconstruct [counter3*6+5] != 0){
                                    rlDataReconstruct2 [rlDataReconstructCount2] = rlDataReconstruct [counter3*6], rlDataReconstructCount2++;
                                    rlDataReconstruct2 [rlDataReconstructCount2] = rlDataReconstruct [counter3*6+1], rlDataReconstructCount2++;
                                    rlDataReconstruct2 [rlDataReconstructCount2] = rlDataReconstruct [counter3*6+2], rlDataReconstructCount2++;
                                    rlDataReconstruct2 [rlDataReconstructCount2] = rlDataReconstruct [counter3*6+3], rlDataReconstructCount2++;
                                    rlDataReconstruct2 [rlDataReconstructCount2] = rlDataReconstruct [counter3*6+4], rlDataReconstructCount2++;
                                    rlDataReconstruct2 [rlDataReconstructCount2] = 0, rlDataReconstructCount2++;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < rlDataReconstructCount2/6; counterA++){
                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<rlDataReconstruct2 [counterA*6+counterB];
                            //    cout<<" rlDataReconstruct2 "<<counterA<<endl;
                            //}
                            
                            delete [] arrayConnectLineageRelVer;
                            arrayConnectLineageRelVer = new int [rlDataReconstructCount2+50];
                            connectLineageRelVerCount = 0;
                            
                            for (int counter3 = 0; counter3 < rlDataReconstructCount2; counter3++) arrayConnectLineageRelVer [connectLineageRelVerCount] = rlDataReconstruct2 [counter3], connectLineageRelVerCount++;
                            
                            char *writingArray = new char [rlDataReconstructCount2/6*16+16];
                            
                            indexCount = 0;
                            
                            for (int counter2 = 0; counter2 < rlDataReconstructCount2/6; counter2++){
                                dataTemp = rlDataReconstruct2 [counter2*6];
                                readBit [0] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [1] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [2] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                
                                dataTemp = rlDataReconstruct2 [counter2*6+1];
                                readBit [0] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [1] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [2] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                
                                dataTemp = rlDataReconstruct2 [counter2*6+2];
                                readBit [0] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [1] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                
                                if (rlDataReconstruct2 [counter2*6+3] < 0){
                                    writingArray [indexCount] = 1, indexCount++;
                                    dataTemp = rlDataReconstruct2 [counter2*6+3]*-1;
                                }
                                else{
                                    
                                    writingArray [indexCount] = 0, indexCount++;
                                    dataTemp = rlDataReconstruct2 [counter2*6+3];
                                }
                                
                                readBit [0] = dataTemp/16777216;
                                dataTemp = dataTemp%16777216;
                                readBit [1] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [2] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [3] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                writingArray [indexCount] = (char)readBit [3], indexCount++;
                                
                                writingArray [indexCount] = 0, indexCount++;
                                
                                writingArray [indexCount] = (char)rlDataReconstruct2 [counter2*6+5], indexCount++;
                            }
                            
                            for (int counter2 = 0; counter2 < 15; counter2++) writingArray [indexCount] = 0, indexCount++;
                            
                            ofstream outfile2 (connectRelationPath.c_str(), ofstream::binary);
                            outfile2.write ((char*) writingArray, indexCount);
                            outfile2.close();
                            
                            delete [] writingArray;
                            delete [] rlDataReconstruct;
                            delete [] rlDataReconstruct2;
                            
                            if (processType != 1){
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                            }
                        }
                        
                        if (processType == 1 || processType == 2 || processType == 6){
                            if (processType == 6){
                                int *positionRevReconstruct = new int [positionReviseVerCount+50];
                                positionRevReconstructCount = 0;
                                
                                for (int counter2 = 0; counter2 < positionReviseVerCount/7; counter2++){
                                    if (arrayPositionReviseVer [counter2*7+5] == 0 || arrayPositionReviseVer [counter2*7+5] == 1){
                                        positionRevReconstruct [positionRevReconstructCount] = arrayPositionReviseVer [counter2*7], positionRevReconstructCount++;
                                        positionRevReconstruct [positionRevReconstructCount] = arrayPositionReviseVer [counter2*7+1], positionRevReconstructCount++;
                                        positionRevReconstruct [positionRevReconstructCount] = arrayPositionReviseVer [counter2*7+2], positionRevReconstructCount++;
                                        positionRevReconstruct [positionRevReconstructCount] = arrayPositionReviseVer [counter2*7+3], positionRevReconstructCount++;
                                        positionRevReconstruct [positionRevReconstructCount] = arrayPositionReviseVer [counter2*7+4], positionRevReconstructCount++;
                                        positionRevReconstruct [positionRevReconstructCount] = arrayPositionReviseVer [counter2*7+5], positionRevReconstructCount++;
                                        positionRevReconstruct [positionRevReconstructCount] = arrayPositionReviseVer [counter2*7+6], positionRevReconstructCount++;
                                    }
                                }
                                
                                positionReviseVerCount = 0;
                                
                                for (int counter2 = 0; counter2 < positionRevReconstructCount; counter2++) arrayPositionReviseVer [positionReviseVerCount] = positionRevReconstruct [counter2], positionReviseVerCount++;
                                
                                delete [] positionRevReconstruct;
                                
                                self->dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                                [self->dataRepairReadWrite masterDataSave];
                            }
                            
                            //for (int counterA = 0; counterA < positionReviseVerCount/7; counterA++){
                            //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionReviseVer [counterA*7+counterB];
                            //    cout<<" arrayPositionReviseVer "<<counterA<<endl;
                            //}
                            
                            //-----Status data reconstruct-----
                            int *statusDataReconstruct = new int [(maxConnectNoMap+1)*10+50];
                            statusDataReconstructCount = maxConnectNoMap*10;
                            
                            for (int counter3 = 0; counter3 < (maxConnectNoMap+1)*10+50; counter3++) statusDataReconstruct [counter3] = 0;
                            
                            for (int counter3 = 0; counter3 < statusDataReconstructCount/10; counter3++){
                                statusDataReconstruct [counter3*10+8] = counter3+1; //-----Selected, removed, eliminated status-----
                            }
                            
                            //for (int counterA = 0; counterA < statusDataReconstructCount/10; counterA++){
                            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<statusDataReconstruct [counterA*10+counterB];
                            //    cout<<" statusDataReconstructCount "<<counterA<<endl;
                            //}
                            
                            valueTemp = 0;
                            overflowCheck = 0;
                            
                            for (int counter2 = 0; counter2 < positionReviseVerCount/7; counter2++){
                                if (arrayPositionReviseVer [counter2*7+3] != valueTemp){
                                    valueTemp = arrayPositionReviseVer [counter2*7+3];
                                    
                                    if (maxConnectNoMap >= valueTemp) statusDataReconstruct [(valueTemp-1)*10+2] = counter2;
                                    else overflowCheck = 1;
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < statusDataReconstructCount/10; counter3++){
                                if (statusDataReconstruct [counter3*10+2] == 0) statusDataReconstruct [counter3*10] = 3;
                            }
                            
                            //for (int counterA = 0; counterA < statusDataReconstructCount/10; counterA++){
                            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<statusDataReconstruct [counterA*10+counterB];
                            //    cout<<" statusDataReconstruct "<<counterA<<endl;
                            //}
                            
                            for (int counter2 = 0; counter2 < connectLineageRelVerCount/6; counter2++){
                                for (int counter3 = 0; counter3 < statusDataReconstructCount/10; counter3++){
                                    if (arrayConnectLineageRelVer [counter2*6+1] == statusDataReconstruct [counter3*10+8]){
                                        statusDataReconstruct [counter3*10] = 7;
                                        statusDataReconstruct [counter3*10+9] = arrayConnectLineageRelVer [counter2*6];
                                        break;
                                    }
                                }
                            }
                            
                            if (overflowCheck == 0){
                                delete [] arrayTimeSelectedVer;
                                arrayTimeSelectedVer = new int [statusDataReconstructCount+50];
                                timeSelectedVerCount = 0;
                                
                                for (int counter2 = 0; counter2 < statusDataReconstructCount; counter2++) arrayTimeSelectedVer [timeSelectedVerCount] = statusDataReconstruct [counter2], timeSelectedVerCount++;
                                
                                char *writingArray = new char [statusDataReconstructCount/10*19+20];
                                
                                indexCount = 0;
                                
                                for (int counter3 = 0; counter3 < statusDataReconstructCount/10; counter3++){
                                    writingArray [indexCount] = (char)statusDataReconstruct [counter3*10], indexCount++;
                                    writingArray [indexCount] = 0, indexCount++;
                                    writingArray [indexCount] = 0, indexCount++;
                                    writingArray [indexCount] = 0, indexCount++;
                                    
                                    dataTemp = statusDataReconstruct [counter3*10+2];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = 0, indexCount++;
                                    writingArray [indexCount] = 0, indexCount++;
                                    
                                    writingArray [indexCount] = (char)statusDataReconstruct [counter3*10+4], indexCount++;
                                    writingArray [indexCount] = (char)statusDataReconstruct [counter3*10+5], indexCount++;
                                    writingArray [indexCount] = (char)statusDataReconstruct [counter3*10+6], indexCount++;
                                    writingArray [indexCount] = (char)statusDataReconstruct [counter3*10+7], indexCount++;
                                    
                                    dataTemp = statusDataReconstruct [counter3*10+8];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    if (statusDataReconstruct [counter3*10] == 3 || statusDataReconstruct [counter3*10] == 4) connectNumberTemp = 0;
                                    else connectNumberTemp = statusDataReconstruct [counter3*10+9];
                                    
                                    dataTemp = connectNumberTemp;
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                }
                                
                                for (int counter3 = 0; counter3 < 19; counter3++) writingArray [indexCount] = 0, indexCount++;
                                
                                ofstream outfile2 (connectStatusDataPath.c_str(), ofstream::binary);
                                outfile2.write ((char*) writingArray, indexCount);
                                outfile2.close();
                                
                                delete [] writingArray;
                                delete [] statusDataReconstruct;
                                
                                if (processType != 1){
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                }
                            }
                            else if (processType != 1){
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                        
                        if (processType == 1 || processType == 2 || processType == 8){
                            //*********arrayGravityCenterRev (GR Center)**********
                            //1. X Position;
                            //2. Y Position;
                            //3. Total Area;
                            //4. Average;
                            //5. Connect No.
                            //6. Target Hit;
                            
                            delete [] arrayGravityCenterVerRev;
                            arrayGravityCenterVerRev = new int [maxConnectNoMap*6+10];
                            
                            gravityCenterRevVerCount = 0;
                            
                            for (int counter2 = 1; counter2 <= maxConnectNoMap; counter2++){
                                if (mapGravityCenterCalculation [counter2*2] != 0){
                                    gravityCenterRevVerTemp = (int)(mapGravityCenterCalculation [counter2*2]/(double)mapGRPointNo [counter2]);
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = gravityCenterRevVerTemp, gravityCenterRevVerCount++;
                                    gravityCenterRevVerTemp = (int)(mapGravityCenterCalculation [counter2*2+1]/(double)mapGRPointNo [counter2]);
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = gravityCenterRevVerTemp, gravityCenterRevVerCount++;
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = mapGRPointNo [counter2], gravityCenterRevVerCount++;
                                    gravityCenterRevVerTemp = (int)(totalIntensityList [counter2]/(double)mapGRPointNo [counter2]);
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = gravityCenterRevVerTemp, gravityCenterRevVerCount++;
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = counter2, gravityCenterRevVerCount++;
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = 0, gravityCenterRevVerCount++;
                                }
                                else{
                                    
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = 0, gravityCenterRevVerCount++;
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = 0, gravityCenterRevVerCount++;
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = 0, gravityCenterRevVerCount++;
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = 0, gravityCenterRevVerCount++;
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = counter2, gravityCenterRevVerCount++;
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = 0, gravityCenterRevVerCount++;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < gravityCenterRevVerCount/6; counterA++){
                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterVerRev [counterA*6+counterB];
                            //    cout<<" arrayGravityCenterVerRev "<<counterA<<endl;
                            //}
                            
                            self->dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                            [self->dataRepairReadWrite masterDataSave];
                            
                            if (processType != 1){
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                            }
                        }
                        
                        if (processType == 1 || processType == 2 || processType == 9){
                            //*********arrayAssociateData (not used)--Cell Carving is using this assay, so keep it**********
                            //1. Connect No;
                            //2. Process type;
                            //3. Cut type;
                            //4. Pair no;
                            //5. Cell dimension
                            //6. Reserve;
                            
                            delete [] arrayRepairDataHoldVerRev;
                            arrayRepairDataHoldVerRev = new int [maxConnectNoMap*6+10];
                            
                            repairDataHoldVerCount = 0;
                            
                            for (int counter2 = 1; counter2 <= maxConnectNoMap; counter2++){
                                arrayRepairDataHoldVerRev [repairDataHoldVerCount] = counter2, repairDataHoldVerCount++;
                                arrayRepairDataHoldVerRev [repairDataHoldVerCount] = 0, repairDataHoldVerCount++;
                                arrayRepairDataHoldVerRev [repairDataHoldVerCount] = 0, repairDataHoldVerCount++;
                                arrayRepairDataHoldVerRev [repairDataHoldVerCount] = 0, repairDataHoldVerCount++;
                                arrayRepairDataHoldVerRev [repairDataHoldVerCount] = 0, repairDataHoldVerCount++;
                                arrayRepairDataHoldVerRev [repairDataHoldVerCount] = 0, repairDataHoldVerCount++;
                            }
                            
                            self->dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                            [self->dataRepairReadWrite masterDataSave];
                            
                            if (processType != 1){
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                            }
                        }
                        
                        if (processType == 11){
                            fluorescentProcessPath1 = "nil";
                            fluorescentProcessPath2 = "nil";
                            fluorescentProcessPath3 = "nil";
                            fluorescentProcessPath4 = "nil";
                            fluorescentProcessPath5 = "nil";
                            fluorescentProcessPath6 = "nil";
                            
                            if (ifStartHold == 0 || processTime < ifStartHold){
                                fluorescentProcessPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+nameStringRep+"_Stitch/"+"STimage "+extension+"_"+to_string(fluorescentNo1)+"_"+fluorescentName1+exType;
                                fluorescentProcessPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+nameStringRep+"_Stitch/"+"STimage "+extension+"_"+to_string(fluorescentNo2)+"_"+fluorescentName2+exType;
                                fluorescentProcessPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+nameStringRep+"_Stitch/"+"STimage "+extension+"_"+to_string(fluorescentNo3)+"_"+fluorescentName3+exType;
                                fluorescentProcessPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+nameStringRep+"_Stitch/"+"STimage "+extension+"_"+to_string(fluorescentNo4)+"_"+fluorescentName4+exType;
                                fluorescentProcessPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+nameStringRep+"_Stitch/"+"STimage "+extension+"_"+to_string(fluorescentNo5)+"_"+fluorescentName5+exType;
                                fluorescentProcessPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+nameStringRep+"_Stitch/"+"STimage "+extension+"_"+to_string(fluorescentNo6)+"_"+fluorescentName6+exType;
                                
                                fluorescentEntryCountVer = fluorescentEntryCount;
                            }
                            else{
                                
                                nextLoad = 0;
                                
                                for (int counter2 = 0; counter2 < 450; counter2 = counter2+15){
                                    
                                    if (atoi(arrayIFDataHold [counter2].c_str()) != 0 && atoi(arrayIFDataHold [counter2+14].c_str()) == processTime){
                                        nextLoad = counter2/15;
                                    }
                                    else if (atoi(arrayIFDataHold [counter2].c_str()) == 0){
                                        break;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < 450/15; counterA++){
                                //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayIFDataHold [counterA*15+counterB];
                                //    cout<<" arrayIFDataHold "<<counterA<<endl;
                                //}
                                
                                fluorescentEntryCountVer = atoi(arrayIFDataHold [nextLoad*15+13].c_str());
                                fluorescentRoundNoVer = arrayIFDataHold [nextLoad*15];
                                
                                if (fluorescentEntryCountVer >= 1){
                                    fluorescentNoVer1 = atoi(arrayIFDataHold [nextLoad*15+7].c_str());
                                    fluorescentNameVer1 = arrayIFDataHold [nextLoad*15+1];
                                    
                                    fluorescentProcessPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+nameStringRep+"_Stitch/"+"STimage "+extension+"_"+to_string(fluorescentNoVer1)+"_"+fluorescentNameVer1+exTypeIF+fluorescentRoundNoVer;
                                }
                                if (fluorescentEntryCountVer >= 2){
                                    fluorescentNoVer2 = atoi(arrayIFDataHold [nextLoad*15+8].c_str());
                                    fluorescentNameVer2 = arrayIFDataHold [nextLoad*15+2];
                                    
                                    fluorescentProcessPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+nameStringRep+"_Stitch/"+"STimage "+extension+"_"+to_string(fluorescentNoVer2)+"_"+fluorescentNameVer2+exTypeIF+fluorescentRoundNoVer;
                                }
                                if (fluorescentEntryCountVer >= 3){
                                    fluorescentNoVer3 = atoi(arrayIFDataHold [nextLoad*15+9].c_str());
                                    fluorescentNameVer3 = arrayIFDataHold [nextLoad*15+3];
                                    
                                    fluorescentProcessPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+nameStringRep+"_Stitch/"+"STimage "+extension+"_"+to_string(fluorescentNoVer3)+"_"+fluorescentNameVer3+exTypeIF+fluorescentRoundNoVer;
                                }
                                if (fluorescentEntryCountVer >= 4){
                                    fluorescentNoVer4 = atoi(arrayIFDataHold [nextLoad*15+10].c_str());
                                    fluorescentNameVer4 = arrayIFDataHold [nextLoad*15+4];
                                    
                                    fluorescentProcessPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+nameStringRep+"_Stitch/"+"STimage "+extension+"_"+to_string(fluorescentNoVer4)+"_"+fluorescentNameVer4+exTypeIF+fluorescentRoundNoVer;
                                }
                                if (fluorescentEntryCountVer >= 5){
                                    fluorescentNoVer5 = atoi(arrayIFDataHold [nextLoad*15+11].c_str());
                                    fluorescentNameVer5 = arrayIFDataHold [nextLoad*15+5];
                                    
                                    fluorescentProcessPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+nameStringRep+"_Stitch/"+"STimage "+extension+"_"+to_string(fluorescentNoVer5)+"_"+fluorescentNameVer5+exTypeIF+fluorescentRoundNoVer;
                                }
                                if (fluorescentEntryCountVer >= 6){
                                    fluorescentNoVer6 = atoi(arrayIFDataHold [nextLoad*15+12].c_str());
                                    fluorescentNameVer6 = arrayIFDataHold [nextLoad*15+6];
                                    
                                    fluorescentProcessPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+nameStringRep+"_Stitch/"+"STimage "+extension+"_"+to_string(fluorescentNoVer6)+"_"+fluorescentNameVer6+exTypeIF+fluorescentRoundNoVer;
                                }
                            }
                            
                            //*********arrayTreatmentStatus*********
                            //1. TreatName
                            //2. Lineage Data check (0: not fined, 1: find)
                            //3. Status Data check (0: not fined, 1: find)
                            //4. Other Map Data check (0: not fined, 1: find)
                            //5. Time One
                            //6. Time End
                            //7. Time Max
                            //8. IF Start
                            //9. Image End
                            
                            //*********arrayIFDataHold*********
                            //1. IF No
                            //2. IF fluorescent name1
                            //3. IF fluorescent name2
                            //4. IF fluorescent name3
                            //5. IF fluorescent No1
                            //6. IF fluorescent No2
                            //7. IF fluorescent No3
                            //8. IF fluorescent Count
                            //9. Image no
                            
                            int **fluorescentMapVer1 = new int *[imageSize+1];
                            for (int counter2 = 0; counter2 < imageSize+1; counter2++) fluorescentMapVer1 [counter2] = new int [imageSize+1];
                            
                            int **fluorescentMapVer2 = new int *[imageSize+1];
                            for (int counter2 = 0; counter2 < imageSize+1; counter2++) fluorescentMapVer2 [counter2] = new int [imageSize+1];
                            
                            int **fluorescentMapVer3 = new int *[imageSize+1];
                            for (int counter2 = 0; counter2 < imageSize+1; counter2++) fluorescentMapVer3 [counter2] = new int [imageSize+1];
                            
                            int **fluorescentMapVer4 = new int *[imageSize+1];
                            for (int counter2 = 0; counter2 < imageSize+1; counter2++) fluorescentMapVer4 [counter2] = new int [imageSize+1];
                            
                            int **fluorescentMapVer5 = new int *[imageSize+1];
                            for (int counter2 = 0; counter2 < imageSize+1; counter2++) fluorescentMapVer5 [counter2] = new int [imageSize+1];
                            
                            int **fluorescentMapVer6 = new int *[imageSize+1];
                            for (int counter2 = 0; counter2 < imageSize+1; counter2++) fluorescentMapVer6 [counter2] = new int [imageSize+1];
                            
                            if (fluorescentEntryCountVer >= 1){
                                if (stat(fluorescentProcessPath1.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    if (exType == ".tif" || exTypeIF == ".TIF"){
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath1.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            dataConversion [0] = uploadTemp [0];
                                            dataConversion [1] = uploadTemp [1];
                                            
                                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                            else endianType = 0;
                                            
                                            headPosition = 0;
                                            
                                            if (endianType == 1){
                                                dataConversion [0] = uploadTemp [7];
                                                dataConversion [1] = uploadTemp [6];
                                                dataConversion [2] = uploadTemp [5];
                                                dataConversion [3] = uploadTemp [4];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            else if (endianType == 0){
                                                dataConversion [0] = uploadTemp [4];
                                                dataConversion [1] = uploadTemp [5];
                                                dataConversion [2] = uploadTemp [6];
                                                dataConversion [3] = uploadTemp [7];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            
                                            imageDimensionReadCount = 0;
                                            imageWidthEntry = 0;
                                            
                                            if (tifImageColorGray == 0){
                                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                    fluorescentMapVer1 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                            else if (tifImageColorGray == 1){
                                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                    value0 = uploadTemp [counter3];
                                                    value1 = uploadTemp [counter3+1];
                                                    value2 = uploadTemp [counter3+2];
                                                    
                                                    fluorescentMapVer1 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        delete [] uploadTemp;
                                    }
                                    else if (exType == ".bmp" || exTypeIF == ".BMP"){
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath1.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            imageDimensionReadCount = 0;
                                            
                                            for (int counter2 = imageSize-1; counter2 >= 0; counter2--){
                                                for (int counter3 = 0; counter3 < imageSize; counter3++){
                                                    fluorescentMapVer1 [imageDimensionReadCount][counter3] = uploadTemp [1078+counter2*imageSize+counter3];
                                                }
                                                
                                                imageDimensionReadCount++;
                                            }
                                        }
                                        
                                        delete [] uploadTemp;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCountVer >= 2){
                                if (stat(fluorescentProcessPath2.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    if (exType == ".tif" || exTypeIF == ".TIF"){
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            dataConversion [0] = uploadTemp [0];
                                            dataConversion [1] = uploadTemp [1];
                                            
                                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                            else endianType = 0;
                                            
                                            headPosition = 0;
                                            
                                            if (endianType == 1){
                                                dataConversion [0] = uploadTemp [7];
                                                dataConversion [1] = uploadTemp [6];
                                                dataConversion [2] = uploadTemp [5];
                                                dataConversion [3] = uploadTemp [4];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            else if (endianType == 0){
                                                dataConversion [0] = uploadTemp [4];
                                                dataConversion [1] = uploadTemp [5];
                                                dataConversion [2] = uploadTemp [6];
                                                dataConversion [3] = uploadTemp [7];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            
                                            imageDimensionReadCount = 0;
                                            imageWidthEntry = 0;
                                            
                                            if (tifImageColorGray == 0){
                                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                    fluorescentMapVer2 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                            else if (tifImageColorGray == 1){
                                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                    value0 = uploadTemp [counter3];
                                                    value1 = uploadTemp [counter3+1];
                                                    value2 = uploadTemp [counter3+2];
                                                    
                                                    fluorescentMapVer2 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        delete [] uploadTemp;
                                    }
                                    else if (exType == ".bmp" || exTypeIF == ".BMP"){
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            imageDimensionReadCount = 0;
                                            
                                            for (int counter2 = imageSize-1; counter2 >= 0; counter2--){
                                                for (int counter3 = 0; counter3 < imageSize; counter3++){
                                                    fluorescentMapVer2 [imageDimensionReadCount][counter3] = uploadTemp [1078+counter2*imageSize+counter3];
                                                }
                                                
                                                imageDimensionReadCount++;
                                            }
                                        }
                                        
                                        delete [] uploadTemp;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCountVer >= 3){
                                if (stat(fluorescentProcessPath3.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    if (exType == ".tif" || exTypeIF == ".TIF"){
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath3.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            dataConversion [0] = uploadTemp [0];
                                            dataConversion [1] = uploadTemp [1];
                                            
                                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                            else endianType = 0;
                                            
                                            headPosition = 0;
                                            
                                            if (endianType == 1){
                                                dataConversion [0] = uploadTemp [7];
                                                dataConversion [1] = uploadTemp [6];
                                                dataConversion [2] = uploadTemp [5];
                                                dataConversion [3] = uploadTemp [4];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            else if (endianType == 0){
                                                dataConversion [0] = uploadTemp [4];
                                                dataConversion [1] = uploadTemp [5];
                                                dataConversion [2] = uploadTemp [6];
                                                dataConversion [3] = uploadTemp [7];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            
                                            imageDimensionReadCount = 0;
                                            imageWidthEntry = 0;
                                            
                                            if (tifImageColorGray == 0){
                                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                    fluorescentMapVer3 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                            else if (tifImageColorGray == 1){
                                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                    value0 = uploadTemp [counter3];
                                                    value1 = uploadTemp [counter3+1];
                                                    value2 = uploadTemp [counter3+2];
                                                    
                                                    fluorescentMapVer3 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        delete [] uploadTemp;
                                    }
                                    else if (exType == ".bmp" || exTypeIF == ".BMP"){
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath3.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            imageDimensionReadCount = 0;
                                            
                                            for (int counter2 = imageSize-1; counter2 >= 0; counter2--){
                                                for (int counter3 = 0; counter3 < imageSize; counter3++){
                                                    fluorescentMapVer3 [imageDimensionReadCount][counter3] = uploadTemp [1078+counter2*imageSize+counter3];
                                                }
                                                
                                                imageDimensionReadCount++;
                                            }
                                        }
                                        
                                        delete [] uploadTemp;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCountVer >= 4){
                                if (stat(fluorescentProcessPath4.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    if (exType == ".tif" || exTypeIF == ".TIF"){
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath4.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            dataConversion [0] = uploadTemp [0];
                                            dataConversion [1] = uploadTemp [1];
                                            
                                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                            else endianType = 0;
                                            
                                            headPosition = 0;
                                            
                                            if (endianType == 1){
                                                dataConversion [0] = uploadTemp [7];
                                                dataConversion [1] = uploadTemp [6];
                                                dataConversion [2] = uploadTemp [5];
                                                dataConversion [3] = uploadTemp [4];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            else if (endianType == 0){
                                                dataConversion [0] = uploadTemp [4];
                                                dataConversion [1] = uploadTemp [5];
                                                dataConversion [2] = uploadTemp [6];
                                                dataConversion [3] = uploadTemp [7];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            
                                            imageDimensionReadCount = 0;
                                            imageWidthEntry = 0;
                                            
                                            if (tifImageColorGray == 0){
                                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                    fluorescentMapVer4 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                            else if (tifImageColorGray == 1){
                                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                    value0 = uploadTemp [counter3];
                                                    value1 = uploadTemp [counter3+1];
                                                    value2 = uploadTemp [counter3+2];
                                                    
                                                    fluorescentMapVer4 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        delete [] uploadTemp;
                                    }
                                    else if (exType == ".bmp" || exTypeIF == ".BMP"){
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath4.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            imageDimensionReadCount = 0;
                                            
                                            for (int counter2 = imageSize-1; counter2 >= 0; counter2--){
                                                for (int counter3 = 0; counter3 < imageSize; counter3++){
                                                    fluorescentMapVer4 [imageDimensionReadCount][counter3] = uploadTemp [1078+counter2*imageSize+counter3];
                                                }
                                                
                                                imageDimensionReadCount++;
                                            }
                                        }
                                        
                                        delete [] uploadTemp;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCountVer >= 5){
                                if (stat(fluorescentProcessPath5.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    if (exType == ".tif" || exTypeIF == ".TIF"){
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath5.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            dataConversion [0] = uploadTemp [0];
                                            dataConversion [1] = uploadTemp [1];
                                            
                                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                            else endianType = 0;
                                            
                                            headPosition = 0;
                                            
                                            if (endianType == 1){
                                                dataConversion [0] = uploadTemp [7];
                                                dataConversion [1] = uploadTemp [6];
                                                dataConversion [2] = uploadTemp [5];
                                                dataConversion [3] = uploadTemp [4];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            else if (endianType == 0){
                                                dataConversion [0] = uploadTemp [4];
                                                dataConversion [1] = uploadTemp [5];
                                                dataConversion [2] = uploadTemp [6];
                                                dataConversion [3] = uploadTemp [7];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            
                                            imageDimensionReadCount = 0;
                                            imageWidthEntry = 0;
                                            
                                            if (tifImageColorGray == 0){
                                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                    fluorescentMapVer5 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                            else if (tifImageColorGray == 1){
                                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                    value0 = uploadTemp [counter3];
                                                    value1 = uploadTemp [counter3+1];
                                                    value2 = uploadTemp [counter3+2];
                                                    
                                                    fluorescentMapVer5 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        delete [] uploadTemp;
                                    }
                                    else if (exType == ".bmp" || exTypeIF == ".BMP"){
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath5.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            imageDimensionReadCount = 0;
                                            
                                            for (int counter2 = imageSize-1; counter2 >= 0; counter2--){
                                                for (int counter3 = 0; counter3 < imageSize; counter3++){
                                                    fluorescentMapVer5 [imageDimensionReadCount][counter3] = uploadTemp [1078+counter2*imageSize+counter3];
                                                }
                                                
                                                imageDimensionReadCount++;
                                            }
                                        }
                                        
                                        delete [] uploadTemp;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCountVer >= 6){
                                if (stat(fluorescentProcessPath6.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    if (exType == ".tif" || exTypeIF == ".TIF"){
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath6.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            dataConversion [0] = uploadTemp [0];
                                            dataConversion [1] = uploadTemp [1];
                                            
                                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                            else endianType = 0;
                                            
                                            headPosition = 0;
                                            
                                            if (endianType == 1){
                                                dataConversion [0] = uploadTemp [7];
                                                dataConversion [1] = uploadTemp [6];
                                                dataConversion [2] = uploadTemp [5];
                                                dataConversion [3] = uploadTemp [4];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            else if (endianType == 0){
                                                dataConversion [0] = uploadTemp [4];
                                                dataConversion [1] = uploadTemp [5];
                                                dataConversion [2] = uploadTemp [6];
                                                dataConversion [3] = uploadTemp [7];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            
                                            imageDimensionReadCount = 0;
                                            imageWidthEntry = 0;
                                            
                                            if (tifImageColorGray == 0){
                                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                    fluorescentMapVer6 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                            else if (tifImageColorGray == 1){
                                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                    value0 = uploadTemp [counter3];
                                                    value1 = uploadTemp [counter3+1];
                                                    value2 = uploadTemp [counter3+2];
                                                    
                                                    fluorescentMapVer6 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        delete [] uploadTemp;
                                    }
                                    else if (exType == ".bmp" || exTypeIF == ".BMP"){
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath6.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            imageDimensionReadCount = 0;
                                            
                                            for (int counter2 = imageSize-1; counter2 >= 0; counter2--){
                                                for (int counter3 = 0; counter3 < imageSize; counter3++){
                                                    fluorescentMapVer6 [imageDimensionReadCount][counter3] = uploadTemp [1078+counter2*imageSize+counter3];
                                                }
                                                
                                                imageDimensionReadCount++;
                                            }
                                        }
                                        
                                        delete [] uploadTemp;
                                    }
                                }
                            }
                            
                            int *connectList = new int [(maxConnectNoMap+1)*3];
                            connectListCount = 0;
                            
                            for (int counter2 = 0; counter2 < lineageDataRepairCount/8; counter2++){
                                if (arrayLineageRepairData [counter2*8+2] == processTime){
                                    connectList [connectListCount] = arrayLineageRepairData [counter2*8+6], connectListCount++;
                                    connectList [connectListCount] = arrayLineageRepairData [counter2*8+5], connectListCount++;
                                    connectList [connectListCount] = 0, connectListCount++;
                                }
                            }
                            
                            for (int counter2 = 0; counter2 < connectListCount/3; counter2++){
                                for (int counter3 = 0; counter3 < connectLineageRelVerCount/6; counter3++){
                                    if (arrayConnectLineageRelVer [counter3*6] == connectList [counter2*3] && arrayConnectLineageRelVer [counter3*6+3] == connectList [counter2*3+1]){
                                        connectList [counter2*3+2] = arrayConnectLineageRelVer [counter3*6+1];
                                        break;
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < connectListCount/3; counterA++){
                            //    cout<< connectList [counterA*3]<<" "<< connectList [counterA*3+1]<<" "<< connectList [counterA*3+2]<<" List"<<endl;
                            //}
                            
                            int *arrayExpandFluorescentLineTemp = new int [10000];
                            expandFluLineTempCount = 0;
                            expandFluLineTempLimit = 10000;
                            
                            int *arrayExpandFluorescentAreaTemp = new int [10000];
                            expandFluAreaTempCount = 0;
                            expandFluAreaTempLimit = 10000;
                            
                            fluorescentCutOffVer1 = 150;
                            fluorescentCutOffVer2 = 150;
                            fluorescentCutOffVer3 = 150;
                            fluorescentCutOffVer4 = 150;
                            fluorescentCutOffVer5 = 150;
                            fluorescentCutOffVer6 = 150;
                            
                            for (int counter2 = 0; counter2 < fluorescentCutOffCount/7; counter2++){
                                if (arrayFluorescentCutOff [counter2*7] == processTime){
                                    fluorescentCutOffVer1 = arrayFluorescentCutOff [counter2*7+1];
                                    fluorescentCutOffVer2 = arrayFluorescentCutOff [counter2*7+2];
                                    fluorescentCutOffVer3 = arrayFluorescentCutOff [counter2*7+3];
                                    fluorescentCutOffVer4 = arrayFluorescentCutOff [counter2*7+4];
                                    fluorescentCutOffVer5 = arrayFluorescentCutOff [counter2*7+5];
                                    fluorescentCutOffVer6 = arrayFluorescentCutOff [counter2*7+6];
                                    break;
                                }
                            }
                            
                            for (int counter2 = 0; counter2 < connectListCount/3; counter2++){
                                connectNoVer = connectList [counter2*3+2];
                                maxPointDimX = 0;
                                maxPointDimY = 0;
                                minPointDimX = 1000000;
                                minPointDimY = 1000000;
                                
                                for (int counter3 = 0; counter3 < positionReviseVerCount/7; counter3++){
                                    if (arrayPositionReviseVer [counter3*7+3] == connectNoVer){
                                        if (maxPointDimX < arrayPositionReviseVer [counter3*7]) maxPointDimX = arrayPositionReviseVer [counter3*7];
                                        if (minPointDimX > arrayPositionReviseVer [counter3*7]) minPointDimX = arrayPositionReviseVer [counter3*7];
                                        if (maxPointDimY < arrayPositionReviseVer [counter3*7+1]) maxPointDimY = arrayPositionReviseVer [counter3*7+1];
                                        if (minPointDimY > arrayPositionReviseVer [counter3*7+1]) minPointDimY = arrayPositionReviseVer [counter3*7+1];
                                    }
                                }
                                
                                //-----Determine the dimension of cell-----
                                horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                                verticalLength = (maxPointDimY-minPointDimY)/2*2;
                                dimension = 0;
                                
                                if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
                                if (horizontalLength < verticalLength) dimension = verticalLength+30;
                                
                                dimension = (dimension/2)*2;
                                
                                horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
                                verticalStart = minPointDimY-(dimension-verticalLength)/2;
                                
                                if (dimension > 0){
                                    int **connectivityMapVerRE = new int *[dimension+1];
                                    
                                    for (int counter3 = 0; counter3 < dimension+1; counter3++){
                                        connectivityMapVerRE [counter3] = new int [dimension+1];
                                    }
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            connectivityMapVerRE [counterY][counterX] = 0;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < positionReviseVerCount/7; counter3++){
                                        if (arrayPositionReviseVer [counter3*7+3] == connectNoVer){
                                            connectivityMapVerRE [arrayPositionReviseVer [counter3*7+1]-verticalStart][arrayPositionReviseVer [counter3*7]-horizontalStart] = 1;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < dimension; counterA++){
                                    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
                                    //    cout<<" connectivityMap"<<counterA<<endl;
                                    //}
                                    
                                    //-----Fill inside-----
                                    int *connectAnalysisX = new int [dimension*4];
                                    int *connectAnalysisY = new int [dimension*4];
                                    int *connectAnalysisTempX = new int [dimension*4];
                                    int *connectAnalysisTempY = new int [dimension*4];
                                    
                                    connectivityNumber = -3;
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (connectivityMapVerRE [counterY][counterX] == 0){
                                                connectivityNumber = connectivityNumber+2;
                                                connectAnalysisCount = 0;
                                                
                                                if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMapVerRE [counterY][counterX] = connectivityNumber;
                                                
                                                if (counterY-1 >= 0 && connectivityMapVerRE [counterY-1][counterX] == 0){
                                                    connectivityMapVerRE [counterY-1][counterX] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                }
                                                if (counterX+1 < dimension && connectivityMapVerRE [counterY][counterX+1] == 0){
                                                    connectivityMapVerRE [counterY][counterX+1] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                }
                                                if (counterY+1 < dimension && connectivityMapVerRE [counterY+1][counterX] == 0){
                                                    connectivityMapVerRE [counterY+1][counterX] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                }
                                                if (counterX-1 >= 0 && connectivityMapVerRE [counterY][counterX-1] == 0){
                                                    connectivityMapVerRE [counterY][counterX-1] = connectivityNumber;
                                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                }
                                                
                                                if (connectAnalysisCount != 0){
                                                    do{
                                                        
                                                        terminationFlag = 1;
                                                        connectAnalysisTempCount = 0;
                                                        
                                                        for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                            xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                            
                                                            if (ySource-1 >= 0 && connectivityMapVerRE [ySource-1][xSource] == 0){
                                                                connectivityMapVerRE [ySource-1][xSource] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                            }
                                                            if (xSource+1 < dimension && connectivityMapVerRE [ySource][xSource+1] == 0){
                                                                connectivityMapVerRE [ySource][xSource+1] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                            }
                                                            if (ySource+1 < dimension && connectivityMapVerRE [ySource+1][xSource] == 0){
                                                                connectivityMapVerRE [ySource+1][xSource] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                            }
                                                            if (xSource-1 >= 0 && connectivityMapVerRE [ySource][xSource-1] == 0){
                                                                connectivityMapVerRE [ySource][xSource-1] = connectivityNumber;
                                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                            }
                                                        }
                                                        
                                                        for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                            connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                        }
                                                        
                                                        connectAnalysisCount = connectAnalysisTempCount;
                                                        
                                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                                        
                                                    } while (terminationFlag == 1);
                                                }
                                            }
                                        }
                                    }
                                    
                                    for (int counterY = 0; counterY < dimension; counterY++){
                                        for (int counterX = 0; counterX < dimension; counterX++){
                                            if (connectivityMapVerRE [counterY][counterX] == -1) connectivityMapVerRE [counterY][counterX] = 0;
                                            else connectivityMapVerRE [counterY][counterX] = 1;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < dimension; counterA++){
                                    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapVerRE [counterA][counterB];
                                    //    cout<<" connectivityMapVerRE "<<counterA<<endl;
                                    //}
                                    
                                    delete [] connectAnalysisX;
                                    delete [] connectAnalysisY;
                                    delete [] connectAnalysisTempX;
                                    delete [] connectAnalysisTempY;
                                    
                                    if (fluorescentEntryCountVer >= 1){
                                        for (int counter3 = 0; counter3 < positionReviseVerCount/7; counter3++){
                                            if (arrayPositionReviseVer [counter3*7+3] == connectNoVer){
                                                if (expandFluLineTempCount+20 > expandFluLineTempLimit){
                                                    int *arrayUpDate = new int [expandFluLineTempCount+10];
                                                    
                                                    for (int counter4 = 0; counter4 < expandFluLineTempCount; counter4++) arrayUpDate [counter4] = arrayExpandFluorescentLineTemp [counter4];
                                                    
                                                    delete [] arrayExpandFluorescentLineTemp;
                                                    arrayExpandFluorescentLineTemp = new int [expandFluLineTempLimit+10000];
                                                    expandFluLineTempLimit = expandFluLineTempLimit+10000;
                                                    
                                                    for (int counter4 = 0; counter4 < expandFluLineTempCount; counter4++) arrayExpandFluorescentLineTemp [counter4] = arrayUpDate [counter4];
                                                    delete [] arrayUpDate;
                                                }
                                                
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = arrayPositionReviseVer [counter3*7], expandFluLineTempCount++;
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = arrayPositionReviseVer [counter3*7+1], expandFluLineTempCount++;
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = arrayPositionReviseVer [counter3*7+3], expandFluLineTempCount++;
                                                
                                                if (processTime < ifStartHold) arrayExpandFluorescentLineTemp [expandFluLineTempCount] = 1, expandFluLineTempCount++;
                                                else arrayExpandFluorescentLineTemp [expandFluLineTempCount] = 7, expandFluLineTempCount++;
                                            }
                                        }
                                        
                                        pixelValueTemp = 0;
                                        pixelAreaTemp = 0;
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                if (connectivityMapVerRE [counterY][counterX] != 0){
                                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageSize && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageSize){
                                                        
                                                        if (fluorescentCutOffVer1 <= fluorescentMapVer1 [counterY+verticalStart][counterX+horizontalStart] && revisedMapVer [counterY+verticalStart][counterX+horizontalStart] == connectNoVer){
                                                            pixelValueTemp = pixelValueTemp+fluorescentMapVer1 [counterY+verticalStart][counterX+horizontalStart];
                                                        }
                                                        
                                                        pixelAreaTemp++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        averageArea = pixelValueTemp/(double)pixelAreaTemp;
                                        
                                        if (expandFluAreaTempCount+20 > expandFluAreaTempLimit){
                                            if (expandFluAreaTempCount+20 > expandFluAreaTempLimit){
                                                int *arrayUpDate = new int [expandFluAreaTempCount+10];
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount; counter4++) arrayUpDate [counter4] = arrayExpandFluorescentAreaTemp [counter4];
                                                
                                                delete [] arrayExpandFluorescentAreaTemp;
                                                arrayExpandFluorescentAreaTemp = new int [expandFluAreaTempLimit+10000];
                                                expandFluAreaTempLimit = expandFluAreaTempLimit+10000;
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount; counter4++) arrayExpandFluorescentAreaTemp [counter4] = arrayUpDate [counter4];
                                                delete [] arrayUpDate;
                                            }
                                        }
                                        
                                        arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = connectNoVer, expandFluAreaTempCount++;
                                        
                                        if (processTime < ifStartHold) arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = 1, expandFluAreaTempCount++;
                                        else arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = 7, expandFluAreaTempCount++;
                                        
                                        arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = (int)averageArea, expandFluAreaTempCount++;
                                        arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = pixelAreaTemp, expandFluAreaTempCount++;
                                    }
                                    
                                    //*********Fluorescent Line**********
                                    //1. X Position
                                    //2. Y position
                                    //3. Connect No
                                    //4. Channel No (1, 2, 3 Live, 4, 5, 6 IF)
                                    
                                    //**********Position Revise (main line data array)**********
                                    //1. X position;
                                    //2. Y position;
                                    //3. Average:
                                    //4. Connect No;
                                    //5. Cell No;
                                    //6. Status (0. Non-Track (+Noise), 1. Track (+Cell Confirm), 2. Non-Track Deleted, 3. Track-Deleted)
                                    //7. Lineage no;
                                    
                                    if (fluorescentEntryCountVer >= 2){
                                        for (int counter3 = 0; counter3 < positionReviseVerCount/7; counter3++){
                                            if (arrayPositionReviseVer [counter3*7+3] == connectNoVer){
                                                if (expandFluLineTempCount+20 > expandFluLineTempLimit){
                                                    int *arrayUpDate = new int [expandFluLineTempCount+10];
                                                    
                                                    for (int counter4 = 0; counter4 < expandFluLineTempCount; counter4++) arrayUpDate [counter4] = arrayExpandFluorescentLineTemp [counter4];
                                                    
                                                    delete [] arrayExpandFluorescentLineTemp;
                                                    arrayExpandFluorescentLineTemp = new int [expandFluLineTempLimit+10000];
                                                    expandFluLineTempLimit = expandFluLineTempLimit+10000;
                                                    
                                                    for (int counter4 = 0; counter4 < expandFluLineTempCount; counter4++) arrayExpandFluorescentLineTemp [counter4] = arrayUpDate [counter4];
                                                    delete [] arrayUpDate;
                                                }
                                                
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = arrayPositionReviseVer [counter3*7], expandFluLineTempCount++;
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = arrayPositionReviseVer [counter3*7+1], expandFluLineTempCount++;
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = arrayPositionReviseVer [counter3*7+3], expandFluLineTempCount++;
                                                
                                                if (processTime < ifStartHold) arrayExpandFluorescentLineTemp [expandFluLineTempCount] = 2, expandFluLineTempCount++;
                                                else arrayExpandFluorescentLineTemp [expandFluLineTempCount] = 8, expandFluLineTempCount++;
                                            }
                                        }
                                        
                                        pixelValueTemp = 0;
                                        pixelAreaTemp = 0;
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                if (connectivityMapVerRE [counterY][counterX] != 0){
                                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageSize && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageSize){
                                                        if (fluorescentCutOffVer2 <= fluorescentMapVer2 [counterY+verticalStart][counterX+horizontalStart] && revisedMapVer [counterY+verticalStart][counterX+horizontalStart] == connectNoVer){
                                                            pixelValueTemp = pixelValueTemp+fluorescentMapVer2 [counterY+verticalStart][counterX+horizontalStart];
                                                        }
                                                        
                                                        pixelAreaTemp++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        averageArea = pixelValueTemp/(double)pixelAreaTemp;
                                        
                                        if (expandFluAreaTempCount+20 > expandFluAreaTempLimit){
                                            if (expandFluAreaTempCount+20 > expandFluAreaTempLimit){
                                                int *arrayUpDate = new int [expandFluAreaTempCount+10];
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount; counter4++) arrayUpDate [counter4] = arrayExpandFluorescentAreaTemp [counter4];
                                                
                                                delete [] arrayExpandFluorescentAreaTemp;
                                                arrayExpandFluorescentAreaTemp = new int [expandFluAreaTempLimit+10000];
                                                expandFluAreaTempLimit = expandFluAreaTempLimit+10000;
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount; counter4++) arrayExpandFluorescentAreaTemp [counter4] = arrayUpDate [counter4];
                                                delete [] arrayUpDate;
                                            }
                                        }
                                        
                                        arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = connectNoVer, expandFluAreaTempCount++;
                                        
                                        if (processTime < ifStartHold) arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = 2, expandFluAreaTempCount++;
                                        else arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = 8, expandFluAreaTempCount++;
                                        
                                        arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = (int)averageArea, expandFluAreaTempCount++;
                                        arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = pixelAreaTemp, expandFluAreaTempCount++;
                                    }
                                    
                                    if (fluorescentEntryCountVer >= 3){
                                        for (int counter3 = 0; counter3 < positionReviseVerCount/7; counter3++){
                                            if (arrayPositionReviseVer [counter3*7+3] == connectNoVer){
                                                if (expandFluLineTempCount+20 > expandFluLineTempLimit){
                                                    int *arrayUpDate = new int [expandFluLineTempCount+10];
                                                    
                                                    for (int counter4 = 0; counter4 < expandFluLineTempCount; counter4++) arrayUpDate [counter4] = arrayExpandFluorescentLineTemp [counter4];
                                                    
                                                    delete [] arrayExpandFluorescentLineTemp;
                                                    arrayExpandFluorescentLineTemp = new int [expandFluLineTempLimit+10000];
                                                    expandFluLineTempLimit = expandFluLineTempLimit+10000;
                                                    
                                                    for (int counter4 = 0; counter4 < expandFluLineTempCount; counter4++) arrayExpandFluorescentLineTemp [counter4] = arrayUpDate [counter4];
                                                    delete [] arrayUpDate;
                                                }
                                                
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = arrayPositionReviseVer [counter3*7], expandFluLineTempCount++;
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = arrayPositionReviseVer [counter3*7+1], expandFluLineTempCount++;
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = arrayPositionReviseVer [counter3*7+3], expandFluLineTempCount++;
                                                
                                                if (processTime < ifStartHold) arrayExpandFluorescentLineTemp [expandFluLineTempCount] = 3, expandFluLineTempCount++;
                                                else arrayExpandFluorescentLineTemp [expandFluLineTempCount] = 9, expandFluLineTempCount++;
                                            }
                                        }
                                        
                                        pixelValueTemp = 0;
                                        pixelAreaTemp = 0;
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                if (connectivityMapVerRE [counterY][counterX] != 0){
                                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageSize && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageSize){
                                                        if (fluorescentCutOffVer3 <= fluorescentMapVer3 [counterY+verticalStart][counterX+horizontalStart] && revisedMapVer [counterY+verticalStart][counterX+horizontalStart] == connectNoVer){
                                                            pixelValueTemp = pixelValueTemp+fluorescentMapVer3 [counterY+verticalStart][counterX+horizontalStart];
                                                        }
                                                        
                                                        pixelAreaTemp++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        averageArea = pixelValueTemp/(double)pixelAreaTemp;
                                        
                                        if (expandFluAreaTempCount+20 > expandFluAreaTempLimit){
                                            if (expandFluAreaTempCount+20 > expandFluAreaTempLimit){
                                                int *arrayUpDate = new int [expandFluAreaTempCount+10];
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount; counter4++) arrayUpDate [counter4] = arrayExpandFluorescentAreaTemp [counter4];
                                                
                                                delete [] arrayExpandFluorescentAreaTemp;
                                                arrayExpandFluorescentAreaTemp = new int [expandFluAreaTempLimit+10000];
                                                expandFluAreaTempLimit = expandFluAreaTempLimit+10000;
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount; counter4++) arrayExpandFluorescentAreaTemp [counter4] = arrayUpDate [counter4];
                                                delete [] arrayUpDate;
                                            }
                                        }
                                        
                                        arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = connectNoVer, expandFluAreaTempCount++;
                                        
                                        if (processTime < ifStartHold) arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = 3, expandFluAreaTempCount++;
                                        else arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = 9, expandFluAreaTempCount++;
                                        
                                        arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = (int)averageArea, expandFluAreaTempCount++;
                                        arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = pixelAreaTemp, expandFluAreaTempCount++;
                                    }
                                    
                                    if (fluorescentEntryCountVer >= 4){
                                        for (int counter3 = 0; counter3 < positionReviseVerCount/7; counter3++){
                                            if (arrayPositionReviseVer [counter3*7+3] == connectNoVer){
                                                if (expandFluLineTempCount+20 > expandFluLineTempLimit){
                                                    int *arrayUpDate = new int [expandFluLineTempCount+10];
                                                    
                                                    for (int counter4 = 0; counter4 < expandFluLineTempCount; counter4++) arrayUpDate [counter4] = arrayExpandFluorescentLineTemp [counter4];
                                                    
                                                    delete [] arrayExpandFluorescentLineTemp;
                                                    arrayExpandFluorescentLineTemp = new int [expandFluLineTempLimit+10000];
                                                    expandFluLineTempLimit = expandFluLineTempLimit+10000;
                                                    
                                                    for (int counter4 = 0; counter4 < expandFluLineTempCount; counter4++) arrayExpandFluorescentLineTemp [counter4] = arrayUpDate [counter4];
                                                    delete [] arrayUpDate;
                                                }
                                                
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = arrayPositionReviseVer [counter3*7], expandFluLineTempCount++;
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = arrayPositionReviseVer [counter3*7+1], expandFluLineTempCount++;
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = arrayPositionReviseVer [counter3*7+3], expandFluLineTempCount++;
                                                
                                                if (processTime < ifStartHold) arrayExpandFluorescentLineTemp [expandFluLineTempCount] = 4, expandFluLineTempCount++;
                                                else arrayExpandFluorescentLineTemp [expandFluLineTempCount] = 10, expandFluLineTempCount++;
                                            }
                                        }
                                        
                                        pixelValueTemp = 0;
                                        pixelAreaTemp = 0;
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                if (connectivityMapVerRE [counterY][counterX] != 0){
                                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageSize && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageSize){
                                                        if (fluorescentCutOffVer4 <= fluorescentMapVer4 [counterY+verticalStart][counterX+horizontalStart] && revisedMapVer [counterY+verticalStart][counterX+horizontalStart] == connectNoVer){
                                                            pixelValueTemp = pixelValueTemp+fluorescentMapVer4 [counterY+verticalStart][counterX+horizontalStart];
                                                        }
                                                        
                                                        pixelAreaTemp++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        averageArea = pixelValueTemp/(double)pixelAreaTemp;
                                        
                                        if (expandFluAreaTempCount+20 > expandFluAreaTempLimit){
                                            if (expandFluAreaTempCount+20 > expandFluAreaTempLimit){
                                                int *arrayUpDate = new int [expandFluAreaTempCount+10];
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount; counter4++) arrayUpDate [counter4] = arrayExpandFluorescentAreaTemp [counter4];
                                                
                                                delete [] arrayExpandFluorescentAreaTemp;
                                                arrayExpandFluorescentAreaTemp = new int [expandFluAreaTempLimit+10000];
                                                expandFluAreaTempLimit = expandFluAreaTempLimit+10000;
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount; counter4++) arrayExpandFluorescentAreaTemp [counter4] = arrayUpDate [counter4];
                                                delete [] arrayUpDate;
                                            }
                                        }
                                        
                                        arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = connectNoVer, expandFluAreaTempCount++;
                                        
                                        if (processTime < ifStartHold) arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = 4, expandFluAreaTempCount++;
                                        else arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = 10, expandFluAreaTempCount++;
                                        
                                        arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = (int)averageArea, expandFluAreaTempCount++;
                                        arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = pixelAreaTemp, expandFluAreaTempCount++;
                                    }
                                    
                                    if (fluorescentEntryCountVer >= 5){
                                        for (int counter3 = 0; counter3 < positionReviseVerCount/7; counter3++){
                                            if (arrayPositionReviseVer [counter3*7+3] == connectNoVer){
                                                if (expandFluLineTempCount+20 > expandFluLineTempLimit){
                                                    int *arrayUpDate = new int [expandFluLineTempCount+10];
                                                    
                                                    for (int counter4 = 0; counter4 < expandFluLineTempCount; counter4++) arrayUpDate [counter4] = arrayExpandFluorescentLineTemp [counter4];
                                                    
                                                    delete [] arrayExpandFluorescentLineTemp;
                                                    arrayExpandFluorescentLineTemp = new int [expandFluLineTempLimit+10000];
                                                    expandFluLineTempLimit = expandFluLineTempLimit+10000;
                                                    
                                                    for (int counter4 = 0; counter4 < expandFluLineTempCount; counter4++) arrayExpandFluorescentLineTemp [counter4] = arrayUpDate [counter4];
                                                    delete [] arrayUpDate;
                                                }
                                                
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = arrayPositionReviseVer [counter3*7], expandFluLineTempCount++;
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = arrayPositionReviseVer [counter3*7+1], expandFluLineTempCount++;
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = arrayPositionReviseVer [counter3*7+3], expandFluLineTempCount++;
                                                
                                                if (processTime < ifStartHold) arrayExpandFluorescentLineTemp [expandFluLineTempCount] = 5, expandFluLineTempCount++;
                                                else arrayExpandFluorescentLineTemp [expandFluLineTempCount] = 11, expandFluLineTempCount++;
                                            }
                                        }
                                        
                                        pixelValueTemp = 0;
                                        pixelAreaTemp = 0;
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                if (connectivityMapVerRE [counterY][counterX] != 0){
                                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageSize && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageSize){
                                                        if (fluorescentCutOffVer5 <= fluorescentMapVer5 [counterY+verticalStart][counterX+horizontalStart] && revisedMapVer [counterY+verticalStart][counterX+horizontalStart] == connectNoVer){
                                                            pixelValueTemp = pixelValueTemp+fluorescentMapVer5 [counterY+verticalStart][counterX+horizontalStart];
                                                        }
                                                        
                                                        pixelAreaTemp++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        averageArea = pixelValueTemp/(double)pixelAreaTemp;
                                        
                                        if (expandFluAreaTempCount+20 > expandFluAreaTempLimit){
                                            if (expandFluAreaTempCount+20 > expandFluAreaTempLimit){
                                                int *arrayUpDate = new int [expandFluAreaTempCount+10];
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount; counter4++) arrayUpDate [counter4] = arrayExpandFluorescentAreaTemp [counter4];
                                                
                                                delete [] arrayExpandFluorescentAreaTemp;
                                                arrayExpandFluorescentAreaTemp = new int [expandFluAreaTempLimit+10000];
                                                expandFluAreaTempLimit = expandFluAreaTempLimit+10000;
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount; counter4++) arrayExpandFluorescentAreaTemp [counter4] = arrayUpDate [counter4];
                                                delete [] arrayUpDate;
                                            }
                                        }
                                        
                                        arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = connectNoVer, expandFluAreaTempCount++;
                                        
                                        if (processTime < ifStartHold) arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = 5, expandFluAreaTempCount++;
                                        else arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = 11, expandFluAreaTempCount++;
                                        
                                        arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = (int)averageArea, expandFluAreaTempCount++;
                                        arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = pixelAreaTemp, expandFluAreaTempCount++;
                                    }
                                    
                                    if (fluorescentEntryCountVer >= 6){
                                        for (int counter3 = 0; counter3 < positionReviseVerCount/7; counter3++){
                                            if (arrayPositionReviseVer [counter3*7+3] == connectNoVer){
                                                if (expandFluLineTempCount+20 > expandFluLineTempLimit){
                                                    int *arrayUpDate = new int [expandFluLineTempCount+10];
                                                    
                                                    for (int counter4 = 0; counter4 < expandFluLineTempCount; counter4++) arrayUpDate [counter4] = arrayExpandFluorescentLineTemp [counter4];
                                                    
                                                    delete [] arrayExpandFluorescentLineTemp;
                                                    arrayExpandFluorescentLineTemp = new int [expandFluLineTempLimit+10000];
                                                    expandFluLineTempLimit = expandFluLineTempLimit+10000;
                                                    
                                                    for (int counter4 = 0; counter4 < expandFluLineTempCount; counter4++) arrayExpandFluorescentLineTemp [counter4] = arrayUpDate [counter4];
                                                    delete [] arrayUpDate;
                                                }
                                                
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = arrayPositionReviseVer [counter3*7], expandFluLineTempCount++;
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = arrayPositionReviseVer [counter3*7+1], expandFluLineTempCount++;
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = arrayPositionReviseVer [counter3*7+3], expandFluLineTempCount++;
                                                
                                                if (processTime < ifStartHold) arrayExpandFluorescentLineTemp [expandFluLineTempCount] = 6, expandFluLineTempCount++;
                                                else arrayExpandFluorescentLineTemp [expandFluLineTempCount] = 12, expandFluLineTempCount++;
                                            }
                                        }
                                        
                                        pixelValueTemp = 0;
                                        pixelAreaTemp = 0;
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                if (connectivityMapVerRE [counterY][counterX] != 0){
                                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageSize && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageSize){
                                                        if (fluorescentCutOffVer6 <= fluorescentMapVer6 [counterY+verticalStart][counterX+horizontalStart] && revisedMapVer [counterY+verticalStart][counterX+horizontalStart] == connectNoVer){
                                                            pixelValueTemp = pixelValueTemp+fluorescentMapVer6 [counterY+verticalStart][counterX+horizontalStart];
                                                        }
                                                        
                                                        pixelAreaTemp++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        averageArea = pixelValueTemp/(double)pixelAreaTemp;
                                        
                                        if (expandFluAreaTempCount+20 > expandFluAreaTempLimit){
                                            if (expandFluAreaTempCount+20 > expandFluAreaTempLimit){
                                                int *arrayUpDate = new int [expandFluAreaTempCount+10];
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount; counter4++) arrayUpDate [counter4] = arrayExpandFluorescentAreaTemp [counter4];
                                                
                                                delete [] arrayExpandFluorescentAreaTemp;
                                                arrayExpandFluorescentAreaTemp = new int [expandFluAreaTempLimit+10000];
                                                expandFluAreaTempLimit = expandFluAreaTempLimit+10000;
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount; counter4++) arrayExpandFluorescentAreaTemp [counter4] = arrayUpDate [counter4];
                                                delete [] arrayUpDate;
                                            }
                                        }
                                        
                                        arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = connectNoVer, expandFluAreaTempCount++;
                                        
                                        if (processTime < ifStartHold) arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = 6, expandFluAreaTempCount++;
                                        else arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = 12, expandFluAreaTempCount++;
                                        
                                        arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = (int)averageArea, expandFluAreaTempCount++;
                                        arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = pixelAreaTemp, expandFluAreaTempCount++;
                                    }
                                    
                                    for (int counter3 = 0; counter3 < dimension+1; counter3++){
                                        delete [] connectivityMapVerRE [counter3];
                                    }
                                    
                                    delete [] connectivityMapVerRE;
                                }
                            }
                            
                            connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_ExtendLineData";
                            
                            //for (int counterA = 0; counterA < expandFluLineTempCount/4; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayExpandFluorescentLineTemp [counterA*4+counterB];
                            //    cout<<" arrayExpandFluorescentLineTemp "<<counterA<<endl;
                            //}
                            
                            if (expandFluLineTempCount != 0){
                                indexCount = 0;
                                
                                //for (int counterA = 0; counterA < expandFluLineTempCount/4; counterA++){
                                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayExpandFluorescentLineTemp [counterA*4+counterB];
                                //    cout<<" arrayExpandFluorescentLineTemp "<<counterA<<endl;
                                //}
                                
                                char *writingArray = new char [expandFluLineTempCount*2+200];
                                
                                for (int counter2 = 0; counter2 < expandFluLineTempCount/4; counter2++){
                                    dataTemp = arrayExpandFluorescentLineTemp [counter2*4];
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    dataTemp = arrayExpandFluorescentLineTemp [counter2*4+1];
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    dataTemp = arrayExpandFluorescentLineTemp [counter2*4+2];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)arrayExpandFluorescentLineTemp [counter2*4+3], indexCount++;
                                }
                                
                                for (int counter2 = 0; counter2 < 8; counter2++) writingArray [indexCount] = 0, indexCount++;
                                
                                ofstream outfile3 (connectRelationPath.c_str(), ofstream::binary);
                                outfile3.write ((char*)writingArray, indexCount);
                                outfile3.close();
                                
                                delete [] writingArray;
                            }
                            else remove(connectRelationPath.c_str());
                            
                            connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_ExtendAreaData";
                            
                            if (expandFluAreaTempCount != 0){
                                indexCount = 0;
                                
                                //for (int counterA = 0; counterA < expandFluAreaTempCount/4; counterA++){
                                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayExpandFluorescentAreaTemp [counterA*4+counterB];
                                //    cout<<" arrayExpandFluorescentAreaTemp "<<counterA<<endl;
                                //}
                                
                                char *writingArray = new char [expandFluAreaTempCount*2+20];
                                
                                for (int counter2 = 0; counter2 < expandFluAreaTempCount/4; counter2++){
                                    dataTemp = arrayExpandFluorescentAreaTemp [counter2*4];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)arrayExpandFluorescentAreaTemp [counter2*4+1], indexCount++;
                                    writingArray [indexCount] = (char)arrayExpandFluorescentAreaTemp [counter2*4+2], indexCount++;
                                    
                                    dataTemp = arrayExpandFluorescentAreaTemp [counter2*4+3];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                }
                                
                                for (int counter2 = 0; counter2 < 8; counter2++) writingArray [indexCount] = 0, indexCount++;
                                
                                ofstream outfile3 (connectRelationPath.c_str(), ofstream::binary);
                                outfile3.write ((char*)writingArray, indexCount);
                                outfile3.close();
                                
                                delete [] writingArray;
                            }
                            else remove(connectRelationPath.c_str());
                            
                            delete [] arrayExpandFluorescentLineTemp;
                            delete [] arrayExpandFluorescentAreaTemp;
                            
                            for (int counter2 = 0; counter2 < imageSize+1; counter2++){
                                delete [] fluorescentMapVer1 [counter2];
                                delete [] fluorescentMapVer2 [counter2];
                                delete [] fluorescentMapVer3 [counter2];
                                delete [] fluorescentMapVer4 [counter2];
                                delete [] fluorescentMapVer5 [counter2];
                                delete [] fluorescentMapVer6 [counter2];
                            }
                            
                            delete [] fluorescentMapVer1;
                            delete [] fluorescentMapVer2;
                            delete [] fluorescentMapVer3;
                            delete [] fluorescentMapVer4;
                            delete [] fluorescentMapVer5;
                            delete [] fluorescentMapVer6;
                            
                            delete [] connectList;
                        }
                        
                        if (processType == 10){
                            int **newMapData = new int *[imageSize+1];
                            
                            for (int counter2 = 0; counter2 < imageSize+1; counter2++) newMapData [counter2] = new int [imageSize+1];
                            
                            for (int counterY = 0; counterY < imageSize+1; counterY++){
                                for (int counterX = 0; counterX < imageSize+1; counterX++){
                                    newMapData [counterY][counterX] = 0;
                                }
                            }
                            
                            maxConnectPR = 0;
                            
                            for (int counter2 = 0; counter2 < positionReviseVerCount/7; counter2++){
                                if ((arrayPositionReviseVer [counter2*7+5] == 0 || arrayPositionReviseVer [counter2*7+5] == 1) && arrayPositionReviseVer [counter2*7+3] > maxConnectPR){
                                    maxConnectPR = arrayPositionReviseVer [counter2*7+3];
                                }
                            }
                            
                            if (maxConnectPR != 0){
                                string *processOrder = new string [maxMapConnect+10];
                                
                                for (int counter2 = 1; counter2 <= maxMapConnect; counter2++) processOrder [counter2] = "nil";
                                
                                for (int counter2 = 1; counter2 <= maxMapConnect; counter2++){
                                    maxPointDimX = 0;
                                    maxPointDimY = 0;
                                    minPointDimX = 1000000;
                                    minPointDimY = 1000000;
                                    
                                    for (int counter3 = 0; counter3 < positionReviseVerCount/7; counter3++){
                                        if ((arrayPositionReviseVer [counter3*7+5] == 0 || arrayPositionReviseVer [counter3*7+5] == 1) && arrayPositionReviseVer [counter3*7+3] == counter2){
                                            if (maxPointDimX < arrayPositionReviseVer [counter3*7]) maxPointDimX = arrayPositionReviseVer [counter3*7];
                                            if (minPointDimX > arrayPositionReviseVer [counter3*7]) minPointDimX = arrayPositionReviseVer [counter3*7];
                                            if (maxPointDimY < arrayPositionReviseVer [counter3*7+1]) maxPointDimY = arrayPositionReviseVer [counter3*7+1];
                                            if (minPointDimY > arrayPositionReviseVer [counter3*7+1]) minPointDimY = arrayPositionReviseVer [counter3*7+1];
                                        }
                                    }
                                    
                                    if (minPointDimX != 1000000){
                                        //-----Determine the dimension of cell-----
                                        horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                                        verticalLength = (maxPointDimY-minPointDimY)/2*2;
                                        dimension = 0;
                                        
                                        if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
                                        if (horizontalLength < verticalLength) dimension = verticalLength+30;
                                        
                                        dimension = (dimension/2)*2;
                                        
                                        horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
                                        verticalStart = minPointDimY-(dimension-verticalLength)/2;
                                        
                                        int **connectivityMapVerMap = new int *[dimension+1];
                                        
                                        for (int counter3 = 0; counter3 < dimension+1; counter3++){
                                            connectivityMapVerMap [counter3] = new int [dimension+1];
                                        }
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                connectivityMapVerMap [counterY][counterX] = 0;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < positionReviseVerCount/7; counter3++){
                                            if ((arrayPositionReviseVer [counter3*7+5] == 0 || arrayPositionReviseVer [counter3*7+5] == 1) && arrayPositionReviseVer [counter3*7+3] == counter2){
                                                connectivityMapVerMap [arrayPositionReviseVer [counter3*7+1]-verticalStart][arrayPositionReviseVer [counter3*7]-horizontalStart] = 1;
                                            }
                                        }
                                        
                                        //-----Fill inside-----
                                        int *connectAnalysisX = new int [dimension*4];
                                        int *connectAnalysisY = new int [dimension*4];
                                        int *connectAnalysisTempX = new int [dimension*4];
                                        int *connectAnalysisTempY = new int [dimension*4];
                                        
                                        connectivityNumber = -3;
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                if (connectivityMapVerMap [counterY][counterX] == 0){
                                                    connectivityNumber = connectivityNumber+2;
                                                    connectAnalysisCount = 0;
                                                    
                                                    if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMapVerMap [counterY][counterX] = connectivityNumber;
                                                    
                                                    if (counterY-1 >= 0 && connectivityMapVerMap [counterY-1][counterX] == 0){
                                                        connectivityMapVerMap [counterY-1][counterX] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                    }
                                                    if (counterX+1 < dimension && connectivityMapVerMap [counterY][counterX+1] == 0){
                                                        connectivityMapVerMap [counterY][counterX+1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                    }
                                                    if (counterY+1 < dimension && connectivityMapVerMap [counterY+1][counterX] == 0){
                                                        connectivityMapVerMap [counterY+1][counterX] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                    }
                                                    if (counterX-1 >= 0 && connectivityMapVerMap [counterY][counterX-1] == 0){
                                                        connectivityMapVerMap [counterY][counterX-1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                    }
                                                    
                                                    if (connectAnalysisCount != 0){
                                                        do{
                                                            
                                                            terminationFlag = 1;
                                                            connectAnalysisTempCount = 0;
                                                            
                                                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                                xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                                
                                                                if (ySource-1 >= 0 && connectivityMapVerMap [ySource-1][xSource] == 0){
                                                                    connectivityMapVerMap [ySource-1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource+1 < dimension && connectivityMapVerMap [ySource][xSource+1] == 0){
                                                                    connectivityMapVerMap [ySource][xSource+1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                                if (ySource+1 < dimension && connectivityMapVerMap [ySource+1][xSource] == 0){
                                                                    connectivityMapVerMap [ySource+1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource-1 >= 0 && connectivityMapVerMap [ySource][xSource-1] == 0){
                                                                    connectivityMapVerMap [ySource][xSource-1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                            }
                                                            
                                                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                                connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                            }
                                                            
                                                            connectAnalysisCount = connectAnalysisTempCount;
                                                            
                                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                                            
                                                        } while (terminationFlag == 1);
                                                    }
                                                }
                                            }
                                        }
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                if (connectivityMapVerMap [counterY][counterX] == -1) connectivityMapVerMap [counterY][counterX] = 0;
                                                else connectivityMapVerMap [counterY][counterX] = 1;
                                            }
                                        }
                                        
                                        //-----Connectivity analysis, For Zero-----
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                if (connectivityMapVerMap [counterY][counterX] != 0){
                                                    if (counterX+1 < dimension && connectivityMapVerMap [counterY][counterX+1] == 0) connectivityMapVerMap [counterY][counterX] = -1;
                                                    else if (counterY+1 < dimension && connectivityMapVerMap [counterY+1][counterX] == 0) connectivityMapVerMap [counterY][counterX] = -1;
                                                    else if (counterX-1 >= 0 && connectivityMapVerMap [counterY][counterX-1] == 0) connectivityMapVerMap [counterY][counterX] = -1;
                                                    else if (counterY-1 >= 0 && connectivityMapVerMap [counterY-1][counterX] == 0) connectivityMapVerMap [counterY][counterX] = -1;
                                                }
                                            }
                                        }
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                if (connectivityMapVerMap [counterY][counterX] > 0) connectivityMapVerMap [counterY][counterX] = 0;
                                                if (connectivityMapVerMap [counterY][counterX] < 0) connectivityMapVerMap [counterY][counterX] = 1;
                                            }
                                        }
                                        
                                        connectivityNumber = 0;
                                        
                                        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                                            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                                if (connectivityMapVerMap [counterY2][counterX2] == 0){
                                                    connectivityNumber--;
                                                    connectAnalysisCount = 0;
                                                    
                                                    connectivityMapVerMap [counterY2][counterX2] = connectivityNumber;
                                                    
                                                    if (counterY2-1 >= 0 && connectivityMapVerMap [counterY2-1][counterX2] == 0){
                                                        connectivityMapVerMap [counterY2-1][counterX2] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                                    }
                                                    if (counterX2+1 < dimension && connectivityMapVerMap [counterY2][counterX2+1] == 0){
                                                        connectivityMapVerMap [counterY2][counterX2+1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                                    }
                                                    if (counterY2+1 < dimension && connectivityMapVerMap [counterY2+1][counterX2] == 0){
                                                        connectivityMapVerMap [counterY2+1][counterX2] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                                    }
                                                    if (counterX2-1 >= 0 && connectivityMapVerMap [counterY2][counterX2-1] == 0){
                                                        connectivityMapVerMap [counterY2][counterX2-1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                                    }
                                                    
                                                    if (connectAnalysisCount != 0){
                                                        do{
                                                            
                                                            terminationFlag = 1;
                                                            connectAnalysisTempCount = 0;
                                                            
                                                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                                xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                                
                                                                if (ySource-1 >= 0 && connectivityMapVerMap [ySource-1][xSource] == 0){
                                                                    connectivityMapVerMap [ySource-1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource+1 < dimension && connectivityMapVerMap [ySource][xSource+1] == 0){
                                                                    connectivityMapVerMap [ySource][xSource+1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                                if (ySource+1 < dimension && connectivityMapVerMap [ySource+1][xSource] == 0){
                                                                    connectivityMapVerMap [ySource+1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource-1 >= 0 && connectivityMapVerMap [ySource][xSource-1] == 0){
                                                                    connectivityMapVerMap [ySource][xSource-1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                            }
                                                            
                                                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                                connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                            }
                                                            
                                                            connectAnalysisCount = connectAnalysisTempCount;
                                                            
                                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                                            
                                                        } while (terminationFlag == 1);
                                                    }
                                                }
                                            }
                                        }
                                        
                                        delete [] connectAnalysisX;
                                        delete [] connectAnalysisY;
                                        delete [] connectAnalysisTempX;
                                        delete [] connectAnalysisTempY;
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                if (connectivityMapVerMap [counterY][counterX] == 1 || connectivityMapVerMap [counterY][counterX] == -2){
                                                    connectivityMapVerMap [counterY][counterX] = 1;
                                                }
                                                else connectivityMapVerMap [counterY][counterX] = 0;
                                            }
                                        }
                                        
                                        overlapFind = 0;
                                        overlapNumber = 0;
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageSize && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageSize){
                                                    if (connectivityMapVerMap [counterY][counterX] != 0 && revisedMapVerTemp [counterY+verticalStart][counterX+horizontalStart] != 0){
                                                        overlapFind = 1;
                                                        overlapNumber = revisedMapVerTemp [counterY+verticalStart][counterX+horizontalStart];
                                                    }
                                                }
                                            }
                                        }
                                        
                                        areaCount = 0;
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                if (connectivityMapVerMap [counterY][counterX] == 1) areaCount++;
                                            }
                                        }
                                        
                                        if (overlapFind == 0){
                                            processOrder [counter2] = to_string(counter2)+"~"+to_string(areaCount)+"/!";
                                            
                                            for (int counterY = 0; counterY < dimension; counterY++){
                                                for (int counterX = 0; counterX < dimension; counterX++){
                                                    if (connectivityMapVerMap [counterY][counterX] != 0 && counterY+verticalStart >= 0 && counterY+verticalStart < imageSize && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageSize){
                                                        revisedMapVerTemp [counterY+verticalStart][counterX+horizontalStart] = counter2;
                                                    }
                                                }
                                            }
                                        }
                                        else{
                                            
                                            for (int counter3 = 1; counter3 <= maxMapConnect; counter3++){
                                                if (atoi(processOrder [counter3].substr(0, processOrder [counter3].find("~")).c_str()) == overlapNumber){
                                                    numberOfSlash = 0;
                                                    extractString = processOrder [counter3];
                                                    
                                                    do{
                                                        
                                                        terminationFlag = 1;
                                                        
                                                        if ((int)extractString.find("/!") != -1){
                                                            numberOfSlash++;
                                                            extractString = extractString.substr(extractString.find("/!")+2);
                                                        }
                                                        else terminationFlag = 0;
                                                        
                                                    } while(terminationFlag == 1);
                                                    
                                                    int *listOfConnectNo = new int [numberOfSlash*2+10];
                                                    
                                                    extractString = processOrder [counter3];
                                                    numberOfSlash = 0;
                                                    firstConnectNo = 0;
                                                    
                                                    do{
                                                        
                                                        terminationFlag = 1;
                                                        
                                                        if ((int)extractString.find("/!") != -1){
                                                            extractString2 = extractString.substr(0, extractString.find("/!"));
                                                            
                                                            listOfConnectNo [numberOfSlash*2] = atoi(extractString.substr(0, extractString2.find("~")).c_str());
                                                            listOfConnectNo [numberOfSlash*2+1] = atoi(extractString.substr(extractString2.find("~")+1).c_str());
                                                            
                                                            extractString = extractString.substr(extractString.find("/!")+2);
                                                            
                                                            if (numberOfSlash == 0) firstConnectNo = listOfConnectNo [numberOfSlash*2];
                                                            
                                                            numberOfSlash++;
                                                        }
                                                        else terminationFlag = 0;
                                                        
                                                    } while(terminationFlag == 1);
                                                    
                                                    areaSizeHold = 0;
                                                    
                                                    for (int counter4 = 0; counter4 < numberOfSlash; counter4++){
                                                        if (listOfConnectNo [counter4*2+1] > areaSizeHold){
                                                            areaSizeHold = listOfConnectNo [counter4*2+1];
                                                        }
                                                    }
                                                    
                                                    if (areaSizeHold < areaCount){
                                                        for (int counterY = 0; counterY < dimension; counterY++){
                                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                                if (connectivityMapVerMap [counterY][counterX] != 0 && counterY+verticalStart >= 0 && counterY+verticalStart < imageSize && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageSize){
                                                                    revisedMapVerTemp [counterY+verticalStart][counterX+horizontalStart] = firstConnectNo;
                                                                }
                                                            }
                                                        }
                                                    }
                                                    
                                                    processOrder [counter3] = processOrder [counter3]+to_string(counter2)+"~"+to_string(areaCount)+"/!";
                                                    
                                                    delete [] listOfConnectNo;
                                                    
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < dimension+1; counter3++){
                                            delete [] connectivityMapVerMap [counter3];
                                        }
                                        
                                        delete [] connectivityMapVerMap;
                                    }
                                }
                                
                                int *processOrderSort = new int [maxMapConnect*2+10];
                                processOrderSortCount = 0;
                                
                                for (int counter2 = 0; counter2 < maxMapConnect*2+10; counter2++) processOrderSort [counter2] = 0;
                                
                                for (int counter2 = 1; counter2 <= maxMapConnect; counter2++){
                                    if (processOrder [counter2] != "nil"){
                                        numberOfSlash = 0;
                                        extractString = processOrder [counter2];
                                        
                                        do{
                                            
                                            terminationFlag = 1;
                                            
                                            if ((int)extractString.find("/!") != -1){
                                                numberOfSlash++;
                                                extractString = extractString.substr(extractString.find("/!")+2);
                                            }
                                            else terminationFlag = 0;
                                            
                                        } while(terminationFlag == 1);
                                        
                                        if (numberOfSlash == 1){
                                            processOrderSort [processOrderSortCount] = atoi(processOrder [counter2].substr(0, processOrder [counter2].find("~")).c_str()), processOrderSortCount++;
                                            processOrderSort [processOrderSortCount] = atoi(processOrder [counter2].substr(processOrder [counter2].find("~")+1, processOrder [counter2].find("/")-processOrder [counter2].find("~")-1).c_str()), processOrderSortCount++;
                                        }
                                        else{
                                            
                                            int *listOfConnectNo = new int [numberOfSlash*2+10];
                                            
                                            extractString = processOrder [counter2];
                                            numberOfSlash = 0;
                                            
                                            do{
                                                
                                                terminationFlag = 1;
                                                
                                                if ((int)extractString.find("/!") != -1){
                                                    extractString2 = extractString.substr(0, extractString.find("/!"));
                                                    
                                                    listOfConnectNo [numberOfSlash*2] = atoi(extractString.substr(0, extractString2.find("~")).c_str());
                                                    listOfConnectNo [numberOfSlash*2+1] = atoi(extractString.substr(extractString2.find("~")+1).c_str());
                                                    
                                                    extractString = extractString.substr(extractString.find("/!")+2);
                                                    
                                                    numberOfSlash++;
                                                }
                                                else terminationFlag = 0;
                                                
                                            } while(terminationFlag == 1);
                                            
                                            do{
                                                
                                                terminationFlag = 1;
                                                areaSizeCheck = -1;
                                                areaSizeHold = 0;
                                                
                                                for (int counter4 = 0; counter4 < numberOfSlash; counter4++){
                                                    if (listOfConnectNo [counter4*2+1] > areaSizeHold){
                                                        areaSizeCheck = counter4;
                                                        areaSizeHold = listOfConnectNo [counter4*2+1];
                                                    }
                                                }
                                                
                                                if (areaSizeHold != 0 && areaSizeCheck != -1){
                                                    processOrderSort [processOrderSortCount] = listOfConnectNo [areaSizeCheck*2], processOrderSortCount++;
                                                    processOrderSort [processOrderSortCount] = listOfConnectNo [areaSizeCheck*2+1], processOrderSortCount++;
                                                    listOfConnectNo [areaSizeCheck*2] = -2;
                                                    listOfConnectNo [areaSizeCheck*2+1] = -2;
                                                }
                                                else  terminationFlag = 0;
                                                
                                            } while (terminationFlag == 1);
                                            
                                            delete [] listOfConnectNo;
                                        }
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < processOrderSortCount/2; counter2++){
                                    processConnectNo = processOrderSort [counter2*2];
                                    
                                    maxPointDimX = 0;
                                    maxPointDimY = 0;
                                    minPointDimX = 1000000;
                                    minPointDimY = 1000000;
                                    
                                    for (int counter3 = 0; counter3 < positionReviseVerCount/7; counter3++){
                                        if ((arrayPositionReviseVer [counter3*7+5] == 0 || arrayPositionReviseVer [counter3*7+5] == 1) && arrayPositionReviseVer [counter3*7+3] == processConnectNo){
                                            if (maxPointDimX < arrayPositionReviseVer [counter3*7]) maxPointDimX = arrayPositionReviseVer [counter3*7];
                                            if (minPointDimX > arrayPositionReviseVer [counter3*7]) minPointDimX = arrayPositionReviseVer [counter3*7];
                                            if (maxPointDimY < arrayPositionReviseVer [counter3*7+1]) maxPointDimY = arrayPositionReviseVer [counter3*7+1];
                                            if (minPointDimY > arrayPositionReviseVer [counter3*7+1]) minPointDimY = arrayPositionReviseVer [counter3*7+1];
                                        }
                                    }
                                    
                                    //-----Determine the dimension of cell-----
                                    horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                                    verticalLength = (maxPointDimY-minPointDimY)/2*2;
                                    dimension = 0;
                                    
                                    if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
                                    if (horizontalLength < verticalLength) dimension = verticalLength+30;
                                    
                                    dimension = (dimension/2)*2;
                                    
                                    horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
                                    verticalStart = minPointDimY-(dimension-verticalLength)/2;
                                    
                                    if (dimension > 0){
                                        int **connectivityMapVerRE = new int *[dimension+1];
                                        
                                        for (int counter3 = 0; counter3 < dimension+1; counter3++){
                                            connectivityMapVerRE [counter3] = new int [dimension+1];
                                        }
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                connectivityMapVerRE [counterY][counterX] = 0;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < positionReviseVerCount/7; counter3++){
                                            if (arrayPositionReviseVer [counter3*7+3] == processConnectNo && (arrayPositionReviseVer [counter3*7+5] == 0 || arrayPositionReviseVer [counter3*7+5] == 1)){
                                                connectivityMapVerRE [arrayPositionReviseVer [counter3*7+1]-verticalStart][arrayPositionReviseVer [counter3*7]-horizontalStart] = 1;
                                            }
                                        }
                                        
                                        //-----Fill inside-----
                                        int *connectAnalysisX = new int [dimension*4];
                                        int *connectAnalysisY = new int [dimension*4];
                                        int *connectAnalysisTempX = new int [dimension*4];
                                        int *connectAnalysisTempY = new int [dimension*4];
                                        
                                        connectivityNumber = -3;
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                if (connectivityMapVerRE [counterY][counterX] == 0){
                                                    connectivityNumber = connectivityNumber+2;
                                                    connectAnalysisCount = 0;
                                                    
                                                    if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMapVerRE [counterY][counterX] = connectivityNumber;
                                                    
                                                    if (counterY-1 >= 0 && connectivityMapVerRE [counterY-1][counterX] == 0){
                                                        connectivityMapVerRE [counterY-1][counterX] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                    }
                                                    if (counterX+1 < dimension && connectivityMapVerRE [counterY][counterX+1] == 0){
                                                        connectivityMapVerRE [counterY][counterX+1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                    }
                                                    if (counterY+1 < dimension && connectivityMapVerRE [counterY+1][counterX] == 0){
                                                        connectivityMapVerRE [counterY+1][counterX] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                    }
                                                    if (counterX-1 >= 0 && connectivityMapVerRE [counterY][counterX-1] == 0){
                                                        connectivityMapVerRE [counterY][counterX-1] = connectivityNumber;
                                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                    }
                                                    
                                                    if (connectAnalysisCount != 0){
                                                        do{
                                                            
                                                            terminationFlag = 1;
                                                            connectAnalysisTempCount = 0;
                                                            
                                                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                                xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                                
                                                                if (ySource-1 >= 0 && connectivityMapVerRE [ySource-1][xSource] == 0){
                                                                    connectivityMapVerRE [ySource-1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource+1 < dimension && connectivityMapVerRE [ySource][xSource+1] == 0){
                                                                    connectivityMapVerRE [ySource][xSource+1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                                if (ySource+1 < dimension && connectivityMapVerRE [ySource+1][xSource] == 0){
                                                                    connectivityMapVerRE [ySource+1][xSource] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                }
                                                                if (xSource-1 >= 0 && connectivityMapVerRE [ySource][xSource-1] == 0){
                                                                    connectivityMapVerRE [ySource][xSource-1] = connectivityNumber;
                                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                }
                                                            }
                                                            
                                                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                                connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                            }
                                                            
                                                            connectAnalysisCount = connectAnalysisTempCount;
                                                            
                                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                                            
                                                        } while (terminationFlag == 1);
                                                    }
                                                }
                                            }
                                        }
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                if (connectivityMapVerRE [counterY][counterX] == -1) connectivityMapVerRE [counterY][counterX] = 0;
                                                else connectivityMapVerRE [counterY][counterX] = processConnectNo;
                                            }
                                        }
                                        
                                        for (int counterY = 0; counterY < dimension; counterY++){
                                            for (int counterX = 0; counterX < dimension; counterX++){
                                                if (connectivityMapVerRE [counterY][counterX] != 0 && counterY+verticalStart >= 0 && counterY+verticalStart < imageSize && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageSize){
                                                    newMapData [counterY+verticalStart][counterX+horizontalStart] = connectivityMapVerRE [counterY][counterX];
                                                }
                                            }
                                        }
                                        
                                        //    for (int counterA = 0; counterA < dimension; counterA++){
                                        //        for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapVerMap [counterA][counterB];
                                        //        cout<<" connectivityMapVerMap "<<counterA<<endl;
                                        //    }
                                        
                                        delete [] connectAnalysisX;
                                        delete [] connectAnalysisY;
                                        delete [] connectAnalysisTempX;
                                        delete [] connectAnalysisTempY;
                                        
                                        for (int counter3 = 0; counter3 < dimension+1; counter3++){
                                            delete [] connectivityMapVerRE [counter3];
                                        }
                                        
                                        delete [] connectivityMapVerRE;
                                    }
                                }
                                
                                //-----Save Revised Map-----
                                revisedMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_RevisedMap";
                                
                                totalMapSizeTemp = imageSize*imageSize*4+1;
                                indexCount = 0;
                                dataTemp2 = 0;
                                entryCount = 0;
                                
                                char *dataHold = new char [totalMapSizeTemp];
                                
                                for (int counterX = 0; counterX < imageSize; counterX++){
                                    for (int counterY = 0; counterY < imageSize; counterY++){
                                        dataTemp = newMapData [counterX][counterY];
                                        
                                        if (counterY == 0) dataTemp2 = dataTemp, entryCount++;
                                        else if (dataTemp != dataTemp2 || entryCount == 254 || counterY == imageSize-1){
                                            readBit2 [0] = dataTemp2/65536;
                                            dataTemp2 = dataTemp2%65536;
                                            readBit2 [1] = dataTemp2/256;
                                            dataTemp2 = dataTemp2%256;
                                            readBit2 [2] = dataTemp2;
                                            
                                            if (counterY == imageSize-1){
                                                if (dataTemp != dataTemp2){
                                                    dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                                                    dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                                                    dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                                                    dataHold [indexCount] = (char)entryCount, indexCount++;
                                                    
                                                    readBit2 [0] = dataTemp/65536;
                                                    dataTemp = dataTemp%65536;
                                                    readBit2 [1] = dataTemp/256;
                                                    dataTemp = dataTemp%256;
                                                    readBit2 [2] = dataTemp;
                                                    
                                                    entryCount = 1;
                                                    
                                                    dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                                                    dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                                                    dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                                                    dataHold [indexCount] = (char)entryCount, indexCount++;
                                                }
                                                else{
                                                    
                                                    entryCount++;
                                                    
                                                    dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                                                    dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                                                    dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                                                    dataHold [indexCount] = (char)entryCount, indexCount++;
                                                }
                                            }
                                            else{
                                                
                                                dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                                                dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                                                dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                                                dataHold [indexCount] = (char)entryCount, indexCount++;
                                            }
                                            
                                            if (counterY == imageSize-1) entryCount = 0;
                                            else entryCount = 1, dataTemp2 = dataTemp;
                                        }
                                        else entryCount++;
                                    }
                                }
                                
                                ofstream outfile5 (revisedMapPath.c_str(), ofstream::binary);
                                outfile5.write(dataHold, indexCount);
                                outfile5.close();
                                
                                delete [] dataHold;
                                delete [] processOrder;
                                delete [] processOrderSort;
                            }
                            else{
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                            
                            for (int counter2 = 0; counter2 < imageSize+1; counter2++) delete [] newMapData [counter2];
                            delete [] newMapData;
                        }
                        
                        if (processType == 12){
                            int *connectLimit = new int [(maxMapConnect+1)*4+100];
                            
                            for (int counter3 = 0; counter3 <= maxMapConnect; counter3++){
                                connectLimit [counter3*4] = 0;
                                connectLimit [counter3*4+1] = 1000000;
                                connectLimit [counter3*4+2] = 0;
                                connectLimit [counter3*4+3] = 1000000;
                            }
                            
                            for (int counter3 = 0; counter3 < imageSize; counter3++){
                                for (int counter4 = 0; counter4 < imageSize; counter4++){
                                    if (revisedMapVer [counter3][counter4] != 0){
                                        if (connectLimit [revisedMapVer [counter3][counter4]*4] < counter3) connectLimit [revisedMapVer [counter3][counter4]*4] = counter3;
                                        if (connectLimit [revisedMapVer [counter3][counter4]*4+1] > counter3) connectLimit [revisedMapVer [counter3][counter4]*4+1] = counter3;
                                        if (connectLimit [revisedMapVer [counter3][counter4]*4+2] < counter4) connectLimit [revisedMapVer [counter3][counter4]*4+2] = counter4;
                                        if (connectLimit [revisedMapVer [counter3][counter4]*4+3] > counter4) connectLimit [revisedMapVer [counter3][counter4]*4+3] = counter4;
                                    }
                                }
                            }
                            
                            changeFlag = 0;
                            
                            for (int counter2 = 1; counter2 <= maxMapConnect; counter2++){
                                mapGravityCenterCalculationX = 0;
                                mapGravityCenterCalculationY = 0;
                                mapGRPoint = 0;
                                
                                for (int counter3 = connectLimit [counter2*4+1]; counter3 <= connectLimit [counter2*4]; counter3++){
                                    for (int counter4 = connectLimit [counter2*4+3]; counter4 <= connectLimit [counter2*4+2]; counter4++){
                                        if (counter2 == revisedMapVer [counter3][counter4]){
                                            mapGravityCenterCalculationX = mapGravityCenterCalculationX+counter4;
                                            mapGravityCenterCalculationY = mapGravityCenterCalculationY+counter3;
                                            mapGRPoint++;
                                        }
                                    }
                                }
                                
                                if (mapGRPoint != 0){
                                    mapGravityCenterCalculationIntX = (int)(mapGravityCenterCalculationX/(double)mapGRPoint);
                                    mapGravityCenterCalculationIntY = (int)(mapGravityCenterCalculationY/(double)mapGRPoint);
                                    
                                    //**********ConnectLineageRel**********
                                    //1. Lineage No;
                                    //2. Connect No;
                                    //3. Image number;
                                    //4. Cell no;
                                    //5. Target (0: non-target, 1: target);
                                    //6. Reserve;
                                    
                                    cellNumberTemp = 0;
                                    lingNumberTemp = 0;
                                    
                                    for (int counter3 = 0; counter3 < connectLineageRelVerCount/6; counter3++){
                                        if (arrayConnectLineageRelVer [counter3*6+1] == counter2){
                                            cellNumberTemp = arrayConnectLineageRelVer [counter3*6+3];
                                            lingNumberTemp = arrayConnectLineageRelVer [counter3*6];
                                            break;
                                        }
                                    }
                                    
                                    xPositionLing = 0;
                                    yPositionLing = 0;
                                    xPositionGC = 0;
                                    yPositionGC = 0;
                                    
                                    for (int counter3 = 0; counter3 < lineageDataRepairCount/7; counter3++){
                                        if (arrayLineageRepairData [counter3*8+2] == counter1 && arrayLineageRepairData [counter3*8+5] == cellNumberTemp && arrayLineageRepairData [counter3*8+6] == lingNumberTemp){
                                            xPositionLing = arrayLineageRepairData [counter3*8];
                                            yPositionLing = arrayLineageRepairData [counter3*8+1];
                                            break;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < gravityCenterRevVerCount/6; counter3++){
                                        if (arrayGravityCenterVerRev [counter3*6+4] == counter2){
                                            xPositionGC = arrayGravityCenterVerRev [counter3*6];
                                            yPositionGC = arrayGravityCenterVerRev [counter3*6+1];
                                            break;
                                        }
                                    }
                                    
                                    lingCheck = 0;
                                    gravityCenterCheck = 0;
                                    
                                    if (mapGravityCenterCalculationIntX != xPositionLing || mapGravityCenterCalculationIntY != yPositionLing){
                                        if (mapGravityCenterCalculationIntX == xPositionLing-1 && mapGravityCenterCalculationIntY == yPositionLing) lingCheck = 1;
                                        else if (mapGravityCenterCalculationIntX == xPositionLing-1 && mapGravityCenterCalculationIntY == yPositionLing-1) lingCheck = 1;
                                        else if (mapGravityCenterCalculationIntX == xPositionLing && mapGravityCenterCalculationIntY == yPositionLing-1) lingCheck = 1;
                                        else if (mapGravityCenterCalculationIntX == xPositionLing+1 && mapGravityCenterCalculationIntY == yPositionLing-1) lingCheck = 1;
                                        else if (mapGravityCenterCalculationIntX == xPositionLing+1 && mapGravityCenterCalculationIntY == yPositionLing) lingCheck = 1;
                                        else if (mapGravityCenterCalculationIntX == xPositionLing+1 && mapGravityCenterCalculationIntY == yPositionLing+1) lingCheck = 1;
                                        else if (mapGravityCenterCalculationIntX == xPositionLing && mapGravityCenterCalculationIntY == yPositionLing+1) lingCheck = 1;
                                        else if (mapGravityCenterCalculationIntX == xPositionLing+1 && mapGravityCenterCalculationIntY == yPositionLing+1) lingCheck = 1;
                                    }
                                    
                                    if (mapGravityCenterCalculationIntX != xPositionGC || mapGravityCenterCalculationIntY != yPositionGC){
                                        if (mapGravityCenterCalculationIntX == xPositionGC-1 && mapGravityCenterCalculationIntY == yPositionGC) gravityCenterCheck = 1;
                                        else if (mapGravityCenterCalculationIntX == xPositionGC-1 && mapGravityCenterCalculationIntY == yPositionGC-1) gravityCenterCheck = 1;
                                        else if (mapGravityCenterCalculationIntX == xPositionGC && mapGravityCenterCalculationIntY == yPositionGC-1) gravityCenterCheck = 1;
                                        else if (mapGravityCenterCalculationIntX == xPositionGC+1 && mapGravityCenterCalculationIntY == yPositionGC-1) gravityCenterCheck = 1;
                                        else if (mapGravityCenterCalculationIntX == xPositionGC+1 && mapGravityCenterCalculationIntY == yPositionGC) gravityCenterCheck = 1;
                                        else if (mapGravityCenterCalculationIntX == xPositionGC+1 && mapGravityCenterCalculationIntY == yPositionGC+1) gravityCenterCheck = 1;
                                        else if (mapGravityCenterCalculationIntX == xPositionGC && mapGravityCenterCalculationIntY == yPositionGC+1) gravityCenterCheck = 1;
                                        else if (mapGravityCenterCalculationIntX == xPositionGC+1 && mapGravityCenterCalculationIntY == yPositionGC+1) gravityCenterCheck = 1;
                                    }
                                    
                                    if (gravityCenterCheck == 1 || lingCheck == 1){
                                        if (lingCheck == 1){
                                            for (int counter3 = 0; counter3 < lineageDataRepairCount/7; counter3++){
                                                if (arrayLineageRepairData [counter3*8+2] == counter1 && arrayLineageRepairData [counter3*8+5] == cellNumberTemp && arrayLineageRepairData [counter3*8+6] == lingNumberTemp){
                                                    arrayLineageRepairData [counter3*8] = mapGravityCenterCalculationIntX;
                                                    arrayLineageRepairData [counter3*8+1] = mapGravityCenterCalculationIntY;
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        if (gravityCenterCheck == 1){
                                            for (int counter3 = 0; counter3 < gravityCenterRevVerCount/6; counter3++){
                                                if (arrayGravityCenterVerRev [counter3*6+4] == counter2){
                                                    arrayGravityCenterVerRev [counter3*6] = mapGravityCenterCalculationIntX;
                                                    arrayGravityCenterVerRev [counter3*6+1] = mapGravityCenterCalculationIntY;
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        changeFlag = 1;
                                    }
                                }
                            }
                            
                            if (changeFlag == 1){
                                self->dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                                [self->dataRepairReadWrite lineageDataSave];
                                
                                self->dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                                [self->dataRepairReadWrite masterDataSave];
                            }
                            
                            delete [] connectLimit;
                        }
                        
                        if (processType == 1){
                            for (int counter3 = 0; counter3 < lineageDataRepairCount/8; counter3++){
                                if (arrayLineageRepairData [counter3*8+2] == counter1 && arrayLineageRepairData [counter3*8+3] != 13){
                                    if (revisedMapVer [arrayLineageRepairData [counter3*8+1]][arrayLineageRepairData [counter3*8]] != 0){
                                        lineagePositionError = 0;
                                        
                                        for (int counter4 = 0; counter4 < positionReviseVerCount/7; counter4++){
                                            if (arrayPositionReviseVer [counter4*7+3] == revisedMapVer [arrayLineageRepairData [counter3*8+1]][arrayLineageRepairData [counter3*8]] && arrayPositionReviseVer [counter4*7+4] == arrayLineageRepairData [counter3*8+5] && arrayPositionReviseVer [counter4*7+6] == arrayLineageRepairData [counter3*8+6]){
                                                lineagePositionError = 1;
                                                break;
                                            }
                                        }
                                        
                                        if (lineagePositionError == 0){
                                            connectFind = 0;
                                            
                                            for (int counter4 = 0; counter4 < positionReviseVerCount/7; counter4++){
                                                if (arrayPositionReviseVer [counter4*7+3] == revisedMapVer [arrayLineageRepairData [counter3*8+1]][arrayLineageRepairData [counter3*8]] && connectFind == 0){
                                                    arrayPositionReviseVer [counter4*7+4] = arrayLineageRepairData [counter3*8+5];
                                                    arrayPositionReviseVer [counter4*7+5] = 1;
                                                    arrayPositionReviseVer [counter4*7+6] = arrayLineageRepairData [counter3*8+6];
                                                    connectFind = 1;
                                                }
                                                else if (arrayPositionReviseVer [counter4*7+3] == revisedMapVer [arrayLineageRepairData [counter3*8+1]][arrayLineageRepairData [counter3*8]] && connectFind == 1){
                                                    arrayPositionReviseVer [counter4*7+4] = arrayLineageRepairData [counter3*8+5];
                                                    arrayPositionReviseVer [counter4*7+5] = 1;
                                                    arrayPositionReviseVer [counter4*7+6] = arrayLineageRepairData [counter3*8+6];
                                                }
                                                else if (arrayPositionReviseVer [counter4*7+3] != revisedMapVer [arrayLineageRepairData [counter3*8+1]][arrayLineageRepairData [counter3*8]] && connectFind == 1){
                                                    break;
                                                }
                                            }
                                            
                                            self->dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                                            [self->dataRepairReadWrite masterDataSave];
                                            
                                            //**********ConnectLineageRel**********
                                            //1. Lineage No;
                                            //2. Connect No;
                                            //3. Image number;
                                            //4. Cell no;
                                            //5. Target (0: non-target, 1: target);
                                            //6. Reserve;
                                            
                                            int *rlDataReconstruct2 = new int [connectLineageRelVerCount+50];
                                            rlDataReconstructCount2 = 0;
                                            
                                            for (int counter4 = 0; counter4 < connectLineageRelVerCount; counter4++) rlDataReconstruct2 [rlDataReconstructCount2] = arrayConnectLineageRelVer [counter4], rlDataReconstructCount2++;
                                            
                                            rlDataReconstruct2 [rlDataReconstructCount2] = arrayLineageRepairData [counter3*8+6], rlDataReconstructCount2++;
                                            rlDataReconstruct2 [rlDataReconstructCount2] = revisedMapVer [arrayLineageRepairData [counter3*8+1]][arrayLineageRepairData [counter3*8]], rlDataReconstructCount2++;
                                            rlDataReconstruct2 [rlDataReconstructCount2] = arrayLineageRepairData [counter3*8+2], rlDataReconstructCount2++;
                                            rlDataReconstruct2 [rlDataReconstructCount2] = arrayLineageRepairData [counter3*8+5], rlDataReconstructCount2++;
                                            rlDataReconstruct2 [rlDataReconstructCount2] = 0, rlDataReconstructCount2++;
                                            rlDataReconstruct2 [rlDataReconstructCount2] = 0, rlDataReconstructCount2++;
                                            
                                            //for (int counterA = 0; counterA < rlDataReconstructCount2/6; counterA++){
                                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<rlDataReconstruct2 [counterA*6+counterB];
                                            //    cout<<" rlDataReconstruct2 "<<counterA<<endl;
                                            //}
                                            
                                            delete [] arrayConnectLineageRelVer;
                                            arrayConnectLineageRelVer = new int [rlDataReconstructCount2+50];
                                            connectLineageRelVerCount = 0;
                                            
                                            for (int counter4 = 0; counter4 < rlDataReconstructCount2; counter4++) arrayConnectLineageRelVer [connectLineageRelVerCount] = rlDataReconstruct2 [counter4], connectLineageRelVerCount++;
                                            
                                            char *writingArray = new char [rlDataReconstructCount2/6*16+16];
                                            
                                            indexCount = 0;
                                            
                                            for (int counter4 = 0; counter4 < rlDataReconstructCount2/6; counter4++){
                                                dataTemp = rlDataReconstruct2 [counter4*6];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                
                                                dataTemp = rlDataReconstruct2 [counter4*6+1];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                
                                                dataTemp = rlDataReconstruct2 [counter4*6+2];
                                                readBit [0] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [1] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                
                                                if (rlDataReconstruct2 [counter4*6+3] < 0){
                                                    writingArray [indexCount] = 1, indexCount++;
                                                    dataTemp = rlDataReconstruct2 [counter4*6+3]*-1;
                                                }
                                                else{
                                                    
                                                    writingArray [indexCount] = 0, indexCount++;
                                                    dataTemp = rlDataReconstruct2 [counter4*6+3];
                                                }
                                                
                                                readBit [0] = dataTemp/16777216;
                                                dataTemp = dataTemp%16777216;
                                                readBit [1] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [2] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [3] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                writingArray [indexCount] = (char)readBit [3], indexCount++;
                                                
                                                writingArray [indexCount] = 0, indexCount++;
                                                
                                                writingArray [indexCount] = (char)rlDataReconstruct2 [counter4*6+5], indexCount++;
                                            }
                                            
                                            for (int counter4 = 0; counter4 < 15; counter4++) writingArray [indexCount] = 0, indexCount++;
                                            
                                            ofstream outfile2 (connectRelationPath.c_str(), ofstream::binary);
                                            outfile2.write ((char*) writingArray, indexCount);
                                            outfile2.close();
                                            
                                            delete [] writingArray;
                                            delete [] rlDataReconstruct2;
                                            
                                            //**********arrayTimeSelected**********
                                            //1. Status:[0: Non-Track, 1: Track, 3: Non-Track-Deleted (Delete "0", Used to recover from Cut, when cut line is removed. It will be removed by Cleaning),
                                            //4: Track-Deleted (Delete "1 or 7", Used to recover from Cut, when cut line is removed. It will be removed by Cleaning), 7: Cell-Confirmed, 2: Noise, 5: Only for Time One (Area) Non-Track-Deleted, 6: Only for Time One (Area) Track-Deleted]
                                            //2. Previous Connect No: When Cut line is set, Hold cut line no that created the connect; When data is saved this information is cleared;
                                            //3. Starting position of MasterData
                                            //4. Cut Line number hold: when cut line is set, the line number is entered; When data is saved this information is cleared;
                                            //5. OPEN;
                                            //6. OPEN;
                                            //7. OPEN;
                                            //8. OPEN;
                                            //9. Connect no.
                                            //10. Lineage no.
                                            
                                            for (int counter4 = 0; counter4 < timeSelectedVerCount/10; counter4++){
                                                if (arrayTimeSelectedVer [counter4*10+8] == revisedMapVer [arrayLineageRepairData [counter3*8+1]][arrayLineageRepairData [counter3*8]]){
                                                    arrayTimeSelectedVer [counter4*10] = 7;
                                                    arrayTimeSelectedVer [counter4*10+9] = arrayLineageRepairData [counter3*8+6];
                                                    break;
                                                }
                                            }
                                            
                                            writingArray = new char [timeSelectedVerCount/10*19+20];
                                            
                                            indexCount = 0;
                                            
                                            for (int counter4 = 0; counter4 < timeSelectedVerCount/10; counter4++){
                                                writingArray [indexCount] = (char)arrayTimeSelectedVer [counter4*10], indexCount++;
                                                writingArray [indexCount] = 0, indexCount++;
                                                writingArray [indexCount] = 0, indexCount++;
                                                writingArray [indexCount] = 0, indexCount++;
                                                
                                                dataTemp = arrayTimeSelectedVer [counter4*10+2];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                
                                                writingArray [indexCount] = 0, indexCount++;
                                                writingArray [indexCount] = 0, indexCount++;
                                                
                                                writingArray [indexCount] = (char)arrayTimeSelectedVer [counter4*10+4], indexCount++;
                                                writingArray [indexCount] = (char)arrayTimeSelectedVer [counter4*10+5], indexCount++;
                                                writingArray [indexCount] = (char)arrayTimeSelectedVer [counter4*10+6], indexCount++;
                                                writingArray [indexCount] = (char)arrayTimeSelectedVer [counter4*10+7], indexCount++;
                                                
                                                dataTemp = arrayTimeSelectedVer [counter4*10+8];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                
                                                if (arrayTimeSelectedVer [counter4*10] == 3 || arrayTimeSelectedVer [counter4*10] == 4) connectNumberTemp = 0;
                                                else connectNumberTemp = arrayTimeSelectedVer [counter4*10+9];
                                                
                                                dataTemp = connectNumberTemp;
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                            }
                                            
                                            for (int counter4 = 0; counter4 < 19; counter4++) writingArray [indexCount] = 0, indexCount++;
                                            
                                            ofstream outfile3 (connectStatusDataPath.c_str(), ofstream::binary);
                                            outfile3.write ((char*) writingArray, indexCount);
                                            outfile3.close();
                                            
                                            delete [] writingArray;
                                            
                                            //1. X Position;
                                            //2. Y Position;
                                            //3. Total Area;
                                            //4. Average;
                                            //5. Connect No.
                                            //6. Target Hit;
                                            
                                            for (int counter4 = 0; counter4 < gravityCenterRevVerCount/6; counter4++){
                                                if (arrayGravityCenterVerRev [counter4*6+4] == revisedMapVer [arrayLineageRepairData [counter3*8+1]][arrayLineageRepairData [counter3*8]]){
                                                    arrayLineageRepairData [counter3*8+1] = arrayGravityCenterVerRev [counter4*6+1];
                                                    arrayLineageRepairData [counter3*8] = arrayGravityCenterVerRev [counter4*6];
                                                    break;
                                                }
                                            }
                                            
                                            self->dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                                            [self->dataRepairReadWrite lineageDataSave];
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < gravityCenterRevVerCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterVerRev [counterA*6+counterB];
                    //    cout<<" arrayGravityCenterVerRev "<<counterA<<endl;
                    //}
                    
                    delete [] arrayTimeSelectedVer;
                    delete [] arrayConnectLineageRelVer;
                    delete [] arrayPositionReviseVer;
                    delete [] arrayGravityCenterVerRev;
                    delete [] arrayRepairDataHoldVerRev;
                    
                    for (int counter2 = 0; counter2 < imageSize+1; counter2++){
                        delete [] revisedMapVer [counter2];
                        delete [] revisedMapVerTemp [counter2];
                        delete [] sourceMapVer [counter2];
                    }
                    
                    delete [] revisedMapVer;
                    delete [] sourceMapVer;
                    delete [] revisedMapVerTemp;
                    
                    delete [] mapGravityCenterCalculation;
                    delete [] mapGRPointNo;
                    
                    delete [] totalIntensityList;
                    
                    processingCheckFlag = 1;
                }
                
                if (masterDataReadingError == 1){
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                    
                    break;
                }
            }
            
            self->dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
            [self->dataRepairReadWrite lineageRelDataSet];
            
            if (processingCheckFlag == 0){
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        
        delete [] timePointProcessList;
        delete [] arrayLineageRepairData;
        
        cleaningProgress = 0;
        progressControl = 2;
    });
}

@end
