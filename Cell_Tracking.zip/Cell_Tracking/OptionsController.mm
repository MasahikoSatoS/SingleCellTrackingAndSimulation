//
//  OptionsController.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2015-12-03.
//
//

#import "OptionsController.h"

NSString *notificationToOptionController = @"notificationExecuteOptionController";

@implementation OptionsController

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToOptionController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    optionWindowController = [[NSWindowController alloc] initWithWindowNibName:@"InitialProcess"];
    [optionWindowController showWindow:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToOptionOperations object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [optionWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [optionWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
}

-(IBAction)closeWindow:(id)sender{
    [optionWindow orderOut:self];
    optionWindowOperation = 2;
    optionTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (optionWindowOperation == 3){
        [optionWindow makeKeyAndOrderFront:self];
        
        optionWindowOperation = 1;
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToOptionOperations object:self];
        [optionTimer invalidate];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToOptionController object:nil];
}

@end
