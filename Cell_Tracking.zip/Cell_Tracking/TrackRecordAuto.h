//
// TrackRecordAuto.h
// Cell_Tracking
//
// Created by Masahiko Sato on 22/11/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef TRACKRECORDAUTO_H
#define TRACKRECORDAUTO_H
#import "Communication.h"
#endif

@interface TrackRecordAuto : NSObject {
    id fileUpdate;
}

-(int)trackDataAutoMain;

@end
