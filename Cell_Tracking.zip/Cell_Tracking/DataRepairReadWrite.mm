//
//  DataRepairReadWrite.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-05-28.
//

#import "DataRepairReadWrite.h"

@implementation DataRepairReadWrite

-(int)lineageDataSetList:(long)size :(int)processType{
    int returnValue = 0;
    
    ifstream fin;
    
    int finData [29];
    
    fin.open(lineageDataPath.c_str(), ios::in | ios::binary);
    
    int errorFind = 0;
    
    uint8_t *uploadTemp = new uint8_t [size+50];
    fin.read((char*)uploadTemp, size+50);
    
    if ((finData [0] = uploadTemp [size-1]) != 0 || (finData [0] = uploadTemp [size-2]) != 0 || (finData [0] = uploadTemp [size-3]) != 0 || (finData [0] = uploadTemp [size-4]) != 0 || (finData [0] = uploadTemp [size-5]) != 0 || (finData [0] = uploadTemp [size-6]) != 0 || (finData [0] = uploadTemp [size-7]) != 0 || (finData [0] = uploadTemp [size-8]) != 0 || (finData [0] = uploadTemp [size-9]) != 0 || (finData [0] = uploadTemp [size-10]) != 0 || (finData [0] = uploadTemp [size-11]) != 0 || (finData [0] = uploadTemp [size-12]) != 0 || (finData [0] = uploadTemp [size-13]) != 0 || (finData [0] = uploadTemp [size-14]) != 0 || (finData [0] = uploadTemp [size-15]) != 0 || (finData [0] = uploadTemp [size-16]) != 0 || (finData [0] = uploadTemp [size-17]) != 0 || (finData [0] = uploadTemp [size-18]) != 0 || (finData [0] = uploadTemp [size-19]) != 0 || (finData [0] = uploadTemp [size-20]) != 0){
        usleep(50000);
        fin.read((char*)uploadTemp, size+50);
        
        if ((finData [0] = uploadTemp [size-1]) != 0 || (finData [0] = uploadTemp [size-2]) != 0 || (finData [0] = uploadTemp [size-3]) != 0 || (finData [0] = uploadTemp [size-4]) != 0 || (finData [0] = uploadTemp [size-5]) != 0 || (finData [0] = uploadTemp [size-6]) != 0 || (finData [0] = uploadTemp [size-7]) != 0 || (finData [0] = uploadTemp [size-8]) != 0 || (finData [0] = uploadTemp [size-9]) != 0 || (finData [0] = uploadTemp [size-10]) != 0 || (finData [0] = uploadTemp [size-11]) != 0 || (finData [0] = uploadTemp [size-12]) != 0 || (finData [0] = uploadTemp [size-13]) != 0 || (finData [0] = uploadTemp [size-14]) != 0 || (finData [0] = uploadTemp [size-15]) != 0 || (finData [0] = uploadTemp [size-16]) != 0 || (finData [0] = uploadTemp [size-17]) != 0 || (finData [0] = uploadTemp [size-18]) != 0 || (finData [0] = uploadTemp [size-19]) != 0 || (finData [0] = uploadTemp [size-20]) != 0){
            errorFind = 1;
        }
    }
    
    fin.close();
    
    if (errorFind == 0){
        int readPosition = 0;
        int stepCount = 0;
        
        do{
            
            if (stepCount == 0){
                finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                finData [1] = uploadTemp [readPosition], readPosition++;
                finData [2] = uploadTemp [readPosition], readPosition++; //--2 X Position
                finData [3] = uploadTemp [readPosition], readPosition++; //--3 +-
                finData [4] = uploadTemp [readPosition], readPosition++;
                finData [5] = uploadTemp [readPosition], readPosition++; //--4 Y Position
                finData [6] = uploadTemp [readPosition], readPosition++;
                finData [7] = uploadTemp [readPosition], readPosition++; //--5 Time point
                finData [8] = uploadTemp [readPosition], readPosition++; //--6 Event type
                finData [9] = uploadTemp [readPosition], readPosition++; //--7 +-
                finData [10] = uploadTemp [readPosition], readPosition++;
                finData [11] = uploadTemp [readPosition], readPosition++;
                finData [12] = uploadTemp [readPosition], readPosition++;
                finData [13] = uploadTemp [readPosition], readPosition++; //--8 Next cell/fuse no
                finData [14] = uploadTemp [readPosition], readPosition++; //--9 +-
                finData [15] = uploadTemp [readPosition], readPosition++;
                finData [16] = uploadTemp [readPosition], readPosition++;
                finData [17] = uploadTemp [readPosition], readPosition++;
                finData [18] = uploadTemp [readPosition], readPosition++; //--10 Cell no
                finData [19] = uploadTemp [readPosition], readPosition++;
                finData [20] = uploadTemp [readPosition], readPosition++;
                finData [21] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                finData [22] = uploadTemp [readPosition], readPosition++;
                finData [23] = uploadTemp [readPosition], readPosition++;
                finData [24] = uploadTemp [readPosition], readPosition++; //--12 Lineage no Fuse
                
                if (finData [0] == 1) finData [2] = (finData [1]*256+finData [2])*-1;
                else finData [2] = finData [1]*256+finData [2];
                
                if (finData [3] == 1) finData [5] = (finData [4]*256+finData [5])*-1;
                else finData [5] = finData [4]*256+finData [5];
                
                finData [7] = finData [6]*256+finData [7];
                
                if (finData [9] == 1) finData [13] = (finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13])*-1;
                else finData [13] = finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13];
                
                if (finData [14] == 1) finData [18] = (finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18])*-1;
                else finData [18] = finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18];
                
                finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                
                if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                else{
                    
                    arrayLineageRepairData [lineageDataRepairCount] = finData [2], lineageDataRepairCount++;
                    arrayLineageRepairData [lineageDataRepairCount] = finData [5], lineageDataRepairCount++;
                    arrayLineageRepairData [lineageDataRepairCount] = finData [7], lineageDataRepairCount++;
                    arrayLineageRepairData [lineageDataRepairCount] = finData [8], lineageDataRepairCount++;
                    arrayLineageRepairData [lineageDataRepairCount] = finData [13], lineageDataRepairCount++;
                    arrayLineageRepairData [lineageDataRepairCount] = finData [18], lineageDataRepairCount++;
                    arrayLineageRepairData [lineageDataRepairCount] = finData [21], lineageDataRepairCount++;
                    arrayLineageRepairData [lineageDataRepairCount] = finData [24], lineageDataRepairCount++;
                }
            }
            
        } while (stepCount != 3);
        
        delete [] uploadTemp;
        
        if (processType == 0){
            string xPositionString;
            string yPositionString;
            string timeString;
            string eventString;
            string parCellString;
            string cellString;
            string lingString;
            string perLingString;
            string lineNumberString;
            string extractString;
            
            //for (int counterA = 0; counterA < listStringCount; counterA++){
            //    cout<<arrayListString [counterA]<<" list"<<endl;
            //}
            
            for (int counter1 = 0; counter1 < listStringCount; counter1++){
                if ((int)arrayListString [counter1].find("&&R") != -1){
                    extractString = arrayListString [counter1].substr(arrayListString [counter1].find("//")+2);
                    xPositionString = extractString.substr(1, extractString.find("/")-1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    yPositionString = extractString.substr(1, extractString.find("/")-1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    timeString = extractString.substr(1, extractString.find("/")-1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    eventString = extractString.substr(1, extractString.find("/")-1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    parCellString = extractString.substr(1, extractString.find("/")-1);
                    parCellString = parCellString.substr(parCellString.find("c")+1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    cellString = extractString.substr(1, extractString.find("/")-1);
                    cellString = cellString.substr(cellString.find("C")+1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    lingString = extractString.substr(2, extractString.find("/")-2);
                    extractString = extractString.substr(extractString.find("/")+1);
                    perLingString = extractString.substr(2, extractString.find("~~")-2);
                    extractString = arrayListString [counter1].substr(arrayListString [counter1].find("~~")+2);
                    lineNumberString = extractString.substr(0, extractString.find("++"));
                    
                    arrayLineageRepairData [atoi(lineNumberString.c_str())*8] = atoi(xPositionString.c_str());
                    arrayLineageRepairData [atoi(lineNumberString.c_str())*8+1] = atoi(yPositionString.c_str());
                    arrayLineageRepairData [atoi(lineNumberString.c_str())*8+2] = atoi(timeString.c_str());
                    arrayLineageRepairData [atoi(lineNumberString.c_str())*8+3] = atoi(eventString.c_str());
                    arrayLineageRepairData [atoi(lineNumberString.c_str())*8+4] = atoi(parCellString.c_str());
                    arrayLineageRepairData [atoi(lineNumberString.c_str())*8+5] = atoi(cellString.c_str());
                    arrayLineageRepairData [atoi(lineNumberString.c_str())*8+6] = atoi(lingString.c_str());
                    arrayLineageRepairData [atoi(lineNumberString.c_str())*8+7] = atoi(perLingString.c_str());
                }
            }
        }
        else if (processType == 1){
            string lineNumberString;
            string extractString;
            
            for (int counter1 = 0; counter1 < listStringCount; counter1++){
                if ((int)arrayListString [counter1].find("&&R") != -1){
                    extractString = arrayListString [counter1].substr(arrayListString [counter1].find("~~")+2);
                    lineNumberString = extractString.substr(0, extractString.find("++")+1);
                    arrayLineageRepairData [atoi(lineNumberString.c_str())*8] = -2;
                }
            }
            
            int *arrayLineageRepairDataTemp = new int [lineageDataRepairCount+10];
            int lineageDataRepairTempCount = 0;
            
            for (int counter1 = 0; counter1 < lineageDataRepairCount/8; counter1++){
                if (arrayLineageRepairData [counter1*8] != -2){
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayLineageRepairData [counter1*8], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayLineageRepairData [counter1*8+1], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayLineageRepairData [counter1*8+2], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayLineageRepairData [counter1*8+3], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayLineageRepairData [counter1*8+4], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayLineageRepairData [counter1*8+5], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayLineageRepairData [counter1*8+6], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayLineageRepairData [counter1*8+7], lineageDataRepairTempCount++;
                }
            }
            
            lineageDataRepairCount = 0;
            
            for (int counter1 = 0; counter1 < lineageDataRepairTempCount; counter1++) arrayLineageRepairData [lineageDataRepairCount] = arrayLineageRepairDataTemp [counter1], lineageDataRepairCount++;
            
            delete [] arrayLineageRepairDataTemp;
        }
    }
    else returnValue = -1;
    
    return returnValue;
}

-(void)lineageDataSave{
    //for (int counterA = 0; counterA < lineageDataRepairCount/8; counterA++){
    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageRepairData [counterA*8+counterB];
    //    cout<<" arrayLineageRepairData "<<counterA<<endl;
    //}
    
    //-----Lineage Data Save-----
    char *writingArray = new char [lineageDataRepairCount/8*25+25];
    
    unsigned long indexCount = 0;
    int readBit [4];
    int dataTemp = 0;
    
    for (int counter1 = 0; counter1 < lineageDataRepairCount/8; counter1++){
        if (arrayLineageRepairData [counter1*8] < 0){
            writingArray [indexCount] = 1, indexCount++;
            dataTemp = arrayLineageRepairData [counter1*8]*-1;
        }
        else{
            
            writingArray [indexCount] = 0, indexCount++;
            dataTemp = arrayLineageRepairData [counter1*8];
        }
        
        readBit [0] = dataTemp/256;
        dataTemp = dataTemp%256;
        readBit [1] = dataTemp;
        
        writingArray [indexCount] = (char)readBit [0], indexCount++;
        writingArray [indexCount] = (char)readBit [1], indexCount++;
        
        if (arrayLineageRepairData [counter1*8+1] < 0){
            writingArray [indexCount] = 1, indexCount++;
            dataTemp = arrayLineageRepairData [counter1*8+1]*-1;
        }
        else{
            
            writingArray [indexCount] = 0, indexCount++;
            dataTemp = arrayLineageRepairData [counter1*8+1];
        }
        
        readBit [0] = dataTemp/256;
        dataTemp = dataTemp%256;
        readBit [1] = dataTemp;
        
        writingArray [indexCount] = (char)readBit [0], indexCount++;
        writingArray [indexCount] = (char)readBit [1], indexCount++;
        
        dataTemp = arrayLineageRepairData [counter1*8+2];
        readBit [0] = dataTemp/256;
        dataTemp = dataTemp%256;
        readBit [1] = dataTemp;
        
        writingArray [indexCount] = (char)readBit [0], indexCount++;
        writingArray [indexCount] = (char)readBit [1], indexCount++;
        
        writingArray [indexCount] = (char)arrayLineageRepairData [counter1*8+3], indexCount++;
        
        if (arrayLineageRepairData [counter1*8+4] < 0){
            writingArray [indexCount] = 1, indexCount++;
            dataTemp = arrayLineageRepairData [counter1*8+4]*-1;
        }
        else{
            
            writingArray [indexCount] = 0, indexCount++;
            dataTemp = arrayLineageRepairData [counter1*8+4];
        }
        
        readBit [0] = dataTemp/16777216;
        dataTemp = dataTemp%16777216;
        readBit [1] = dataTemp/65536;
        dataTemp = dataTemp%65536;
        readBit [2] = dataTemp/256;
        dataTemp = dataTemp%256;
        readBit [3] = dataTemp;
        
        writingArray [indexCount] = (char)readBit [0], indexCount++;
        writingArray [indexCount] = (char)readBit [1], indexCount++;
        writingArray [indexCount] = (char)readBit [2], indexCount++;
        writingArray [indexCount] = (char)readBit [3], indexCount++;
        
        if (arrayLineageRepairData [counter1*8+5] < 0){
            writingArray [indexCount] = 1, indexCount++;
            dataTemp = arrayLineageRepairData [counter1*8+5]*-1;
        }
        else{
            
            writingArray [indexCount] = 0, indexCount++;
            dataTemp = arrayLineageRepairData [counter1*8+5];
        }
        
        readBit [0] = dataTemp/16777216;
        dataTemp = dataTemp%16777216;
        readBit [1] = dataTemp/65536;
        dataTemp = dataTemp%65536;
        readBit [2] = dataTemp/256;
        dataTemp = dataTemp%256;
        readBit [3] = dataTemp;
        
        writingArray [indexCount] = (char)readBit [0], indexCount++;
        writingArray [indexCount] = (char)readBit [1], indexCount++;
        writingArray [indexCount] = (char)readBit [2], indexCount++;
        writingArray [indexCount] = (char)readBit [3], indexCount++;
        
        dataTemp = arrayLineageRepairData [counter1*8+6];
        readBit [0] = dataTemp/65536;
        dataTemp = dataTemp%65536;
        readBit [1] = dataTemp/256;
        dataTemp = dataTemp%256;
        readBit [2] = dataTemp;
        
        writingArray [indexCount] = (char)readBit [0], indexCount++;
        writingArray [indexCount] = (char)readBit [1], indexCount++;
        writingArray [indexCount] = (char)readBit [2], indexCount++;
        
        dataTemp = arrayLineageRepairData [counter1*8+7];
        readBit [0] = dataTemp/65536;
        dataTemp = dataTemp%65536;
        readBit [1] = dataTemp/256;
        dataTemp = dataTemp%256;
        readBit [2] = dataTemp;
        
        writingArray [indexCount] = (char)readBit [0], indexCount++;
        writingArray [indexCount] = (char)readBit [1], indexCount++;
        writingArray [indexCount] = (char)readBit [2], indexCount++;
    }
    
    for (int counter1 = 0; counter1 < 25; counter1++) writingArray [indexCount] = 0, indexCount++;
    
    ofstream outfile (lineageDataPath.c_str(), ofstream::binary);
    outfile.write ((char*) writingArray, indexCount);
    outfile.close();
    
    delete [] writingArray;
}

-(int)masterDataSetList:(long)size :(int)processType :(int)dataType{
    int returnValue = 0;
    int readingError = 0;
    
    ifstream fin;
    
    int finData [17];
    
    fin.open(masterDataRevPath.c_str(), ios::in | ios::binary);
    
    if (fin.is_open()){
        uint8_t *uploadTemp = new uint8_t [size+50];
        fin.read((char*)uploadTemp, size+50);
        
        if ((finData [0] = uploadTemp [size-1]) != 0 || (finData [0] = uploadTemp [size-2]) != 0 || (finData [0] = uploadTemp [size-3]) != 0 || (finData [0] = uploadTemp [size-4]) != 0 || (finData [0] = uploadTemp [size-5]) != 0 || (finData [0] = uploadTemp [size-6]) != 0 || (finData [0] = uploadTemp [size-7]) != 0 || (finData [0] = uploadTemp [size-8]) != 0 || (finData [0] = uploadTemp [size-9]) != 0 || (finData [0] = uploadTemp [size-10]) != 0 || (finData [0] = uploadTemp [size-11]) != 0 || (finData [0] = uploadTemp [size-12]) != 0){
            usleep(50000);
            fin.read((char*)uploadTemp, size+50);
            
            if ((finData [0] = uploadTemp [size-1]) != 0 || (finData [0] = uploadTemp [size-2]) != 0 || (finData [0] = uploadTemp [size-3]) != 0 || (finData [0] = uploadTemp [size-4]) != 0 || (finData [0] = uploadTemp [size-5]) != 0 || (finData [0] = uploadTemp [size-6]) != 0 || (finData [0] = uploadTemp [size-7]) != 0 || (finData [0] = uploadTemp [size-8]) != 0 || (finData [0] = uploadTemp [size-9]) != 0 || (finData [0] = uploadTemp [size-10]) != 0 || (finData [0] = uploadTemp [size-11]) != 0 || (finData [0] = uploadTemp [size-12]) != 0){
                usleep(50000);
                fin.read((char*)uploadTemp, size+50);
                
                if ((finData [0] = uploadTemp [size-1]) != 0 || (finData [0] = uploadTemp [size-2]) != 0 || (finData [0] = uploadTemp [size-3]) != 0 || (finData [0] = uploadTemp [size-4]) != 0 || (finData [0] = uploadTemp [size-5]) != 0 || (finData [0] = uploadTemp [size-6]) != 0 || (finData [0] = uploadTemp [size-7]) != 0 || (finData [0] = uploadTemp [size-8]) != 0 || (finData [0] = uploadTemp [size-9]) != 0 || (finData [0] = uploadTemp [size-10]) != 0 || (finData [0] = uploadTemp [size-11]) != 0 || (finData [0] = uploadTemp [size-12]) != 0){
                    readingError = 1;
                }
            }
        }
        
        fin.close();
        
        if (readingError == 0){
            int readPosition = 0;
            int stepCount = 0;
            
            do{
                
                if (stepCount == 0){
                    finData [0] = uploadTemp [readPosition], readPosition++;
                    finData [1] = uploadTemp [readPosition], readPosition++; //--1
                    finData [2] = uploadTemp [readPosition], readPosition++;
                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                    finData [4] = uploadTemp [readPosition], readPosition++; //--3
                    finData [5] = uploadTemp [readPosition], readPosition++;
                    finData [6] = uploadTemp [readPosition], readPosition++;
                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                    finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                    finData [9] = uploadTemp [readPosition], readPosition++;
                    finData [10] = uploadTemp [readPosition], readPosition++;
                    finData [11] = uploadTemp [readPosition], readPosition++;
                    finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                    finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                    finData [14] = uploadTemp [readPosition], readPosition++;
                    finData [15] = uploadTemp [readPosition], readPosition++;
                    finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                    
                    finData [1] = finData [0]*256+finData [1];
                    finData [3] = finData [2]*256+finData [3];
                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                    
                    if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                    else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                    
                    finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                    
                    if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                    else{
                        
                        arrayPositionReviseVer [positionReviseVerCount] = finData [1], positionReviseVerCount++;
                        arrayPositionReviseVer [positionReviseVerCount] = finData [3], positionReviseVerCount++;
                        arrayPositionReviseVer [positionReviseVerCount] = finData [4], positionReviseVerCount++;
                        arrayPositionReviseVer [positionReviseVerCount] = finData [7], positionReviseVerCount++;
                        arrayPositionReviseVer [positionReviseVerCount] = finData [12], positionReviseVerCount++;
                        arrayPositionReviseVer [positionReviseVerCount] = finData [13], positionReviseVerCount++;
                        arrayPositionReviseVer [positionReviseVerCount] = finData [16], positionReviseVerCount++;
                    }
                }
                else if (stepCount == 1){
                    finData [0] = uploadTemp [readPosition], readPosition++;
                    finData [1] = uploadTemp [readPosition], readPosition++;
                    finData [2] = uploadTemp [readPosition], readPosition++; //--1
                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                    finData [4] = uploadTemp [readPosition], readPosition++; //--3
                    finData [5] = uploadTemp [readPosition], readPosition++;
                    finData [6] = uploadTemp [readPosition], readPosition++;
                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                    finData [8] = uploadTemp [readPosition], readPosition++;
                    finData [9] = uploadTemp [readPosition], readPosition++; //--5
                    finData [10] = uploadTemp [readPosition], readPosition++; //--6
                    
                    finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                    finData [9] = finData [8]*256+finData [9];
                    
                    if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                    else{
                        
                        arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [2], repairDataHoldVerCount++;
                        arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [3], repairDataHoldVerCount++;
                        arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [4], repairDataHoldVerCount++;
                        arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [7], repairDataHoldVerCount++;
                        arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [9], repairDataHoldVerCount++;
                        arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [10], repairDataHoldVerCount++;
                    }
                }
                else if (stepCount == 2){
                    finData [0] = uploadTemp [readPosition], readPosition++;
                    finData [1] = uploadTemp [readPosition], readPosition++; //--1
                    finData [2] = uploadTemp [readPosition], readPosition++;
                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                    finData [4] = uploadTemp [readPosition], readPosition++;
                    finData [5] = uploadTemp [readPosition], readPosition++;
                    finData [6] = uploadTemp [readPosition], readPosition++; //--3
                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                    finData [8] = uploadTemp [readPosition], readPosition++;
                    finData [9] = uploadTemp [readPosition], readPosition++;
                    finData [10] = uploadTemp [readPosition], readPosition++; //--5
                    finData [11] = uploadTemp [readPosition], readPosition++; //--6
                    
                    finData [1] = finData [0]*256+finData [1];
                    finData [3] = finData [2]*256+finData [3];
                    finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                    finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                    
                    if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                    else{
                        
                        arrayGravityCenterVerRev [gravityCenterRevVerCount] = finData [1], gravityCenterRevVerCount++;
                        arrayGravityCenterVerRev [gravityCenterRevVerCount] = finData [3], gravityCenterRevVerCount++;
                        arrayGravityCenterVerRev [gravityCenterRevVerCount] = finData [6], gravityCenterRevVerCount++;
                        arrayGravityCenterVerRev [gravityCenterRevVerCount] = finData [7], gravityCenterRevVerCount++;
                        arrayGravityCenterVerRev [gravityCenterRevVerCount] = finData [10], gravityCenterRevVerCount++;
                        arrayGravityCenterVerRev [gravityCenterRevVerCount] = finData [11], gravityCenterRevVerCount++;
                    }
                }
                
            } while (stepCount != 3);
        }
        
        delete [] uploadTemp;
    }
    
    if (readingError == 0){
        if (dataType == 2){
            if (processType == 0){
                string xPositionString;
                string yPositionString;
                string averageString;
                string connectString;
                string cellString;
                string statusString;
                string lingString;
                string lineNumberString;
                string extractString;
                
                for (int counter1 = 0; counter1 < listStringCount; counter1++){
                    if ((int)arrayListString [counter1].find("&&R") != -1){
                        extractString = arrayListString [counter1].substr(arrayListString [counter1].find("//")+2);
                        xPositionString = extractString.substr(1, extractString.find("/")-1);
                        extractString = extractString.substr(extractString.find("/")+1);
                        yPositionString = extractString.substr(1, extractString.find("/")-1);
                        extractString = extractString.substr(extractString.find("/")+1);
                        averageString = extractString.substr(1, extractString.find("/")-1);
                        extractString = extractString.substr(extractString.find("/")+1);
                        connectString = extractString.substr(1, extractString.find("/")-1);
                        extractString = extractString.substr(extractString.find("/")+1);
                        cellString = extractString.substr(1, extractString.find("/")-1);
                        cellString = cellString.substr(cellString.find("C")+1);
                        extractString = extractString.substr(extractString.find("/")+1);
                        statusString = extractString.substr(1, extractString.find("/")-1);
                        extractString = extractString.substr(extractString.find("/")+1);
                        lingString = extractString.substr(2, extractString.find("~~")-2);
                        extractString = arrayListString [counter1].substr(arrayListString [counter1].find("~~")+2);
                        lineNumberString = extractString.substr(0, extractString.find("++"));
                        
                        arrayPositionReviseVer [atoi(lineNumberString.c_str())*7] = atoi(xPositionString.c_str());
                        arrayPositionReviseVer [atoi(lineNumberString.c_str())*7+1] = atoi(yPositionString.c_str());
                        arrayPositionReviseVer [atoi(lineNumberString.c_str())*7+2] = atoi(averageString.c_str());
                        arrayPositionReviseVer [atoi(lineNumberString.c_str())*7+3] = atoi(connectString.c_str());
                        arrayPositionReviseVer [atoi(lineNumberString.c_str())*7+4] = atoi(cellString.c_str());
                        arrayPositionReviseVer [atoi(lineNumberString.c_str())*7+5] = atoi(statusString.c_str());
                        arrayPositionReviseVer [atoi(lineNumberString.c_str())*7+6] = atoi(lingString.c_str());
                    }
                }
            }
            else{
                
                string lineNumberString;
                string extractString;
                
                for (int counter1 = 0; counter1 < listStringCount; counter1++){
                    if ((int)arrayListString [counter1].find("&&R") != -1){
                        extractString = arrayListString [counter1].substr(arrayListString [counter1].find("~~")+2);
                        lineNumberString = extractString.substr(0, extractString.find("++")+1);
                        arrayPositionReviseVer [atoi(lineNumberString.c_str())*7] = -1;
                    }
                }
                
                int *arrayLineageRepairDataTemp = new int [positionReviseVerCount+10];
                int lineageDataRepairTempCount = 0;
                
                for (int counter1 = 0; counter1 < positionReviseVerCount/7; counter1++){
                    if (arrayPositionReviseVer [counter1*7] != -1){
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayPositionReviseVer [counter1*7], lineageDataRepairTempCount++;
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayPositionReviseVer [counter1*7+1], lineageDataRepairTempCount++;
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayPositionReviseVer [counter1*7+2], lineageDataRepairTempCount++;
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayPositionReviseVer [counter1*7+3], lineageDataRepairTempCount++;
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayPositionReviseVer [counter1*7+4], lineageDataRepairTempCount++;
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayPositionReviseVer [counter1*7+5], lineageDataRepairTempCount++;
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayPositionReviseVer [counter1*7+6], lineageDataRepairTempCount++;
                    }
                }
                
                positionReviseVerCount = 0;
                
                for (int counter1 = 0; counter1 < lineageDataRepairTempCount; counter1++) arrayPositionReviseVer [positionReviseVerCount] = arrayLineageRepairDataTemp [counter1], positionReviseVerCount++;
                
                delete [] arrayLineageRepairDataTemp;
            }
        }
        else if (dataType == 4){
            if (processType == 0){
                string xPositionString;
                string yPositionString;
                string totalString;
                string averageString;
                string connectString;
                string lineNumberString;
                string extractString;
                
                for (int counter1 = 0; counter1 < listStringCount; counter1++){
                    if ((int)arrayListString [counter1].find("&&R") != -1){
                        extractString = arrayListString [counter1].substr(arrayListString [counter1].find("//")+2);
                        xPositionString = extractString.substr(1, extractString.find("/")-1);
                        extractString = extractString.substr(extractString.find("/")+1);
                        yPositionString = extractString.substr(1, extractString.find("/")-1);
                        extractString = extractString.substr(extractString.find("/")+1);
                        totalString = extractString.substr(1, extractString.find("/")-1);
                        extractString = extractString.substr(extractString.find("/")+1);
                        averageString = extractString.substr(1, extractString.find("/")-1);
                        extractString = extractString.substr(extractString.find("/")+1);
                        connectString = extractString.substr(1, extractString.find("/")-1);
                        extractString = arrayListString [counter1].substr(arrayListString [counter1].find("~~")+2);
                        lineNumberString = extractString.substr(0, extractString.find("++"));
                        
                        arrayGravityCenterVerRev [atoi(lineNumberString.c_str())*6] = atoi(xPositionString.c_str());
                        arrayGravityCenterVerRev [atoi(lineNumberString.c_str())*6+1] = atoi(yPositionString.c_str());
                        arrayGravityCenterVerRev [atoi(lineNumberString.c_str())*6+2] = atoi(totalString.c_str());
                        arrayGravityCenterVerRev [atoi(lineNumberString.c_str())*6+3] = atoi(averageString.c_str());
                        arrayGravityCenterVerRev [atoi(lineNumberString.c_str())*6+4] = atoi(connectString.c_str());
                        arrayGravityCenterVerRev [atoi(lineNumberString.c_str())*6+5] = 0;
                    }
                }
            }
            else{
                
                string lineNumberString;
                string extractString;
                
                for (int counter1 = 0; counter1 < listStringCount; counter1++){
                    if ((int)arrayListString [counter1].find("&&R") != -1){
                        extractString = arrayListString [counter1].substr(arrayListString [counter1].find("~~")+2);
                        lineNumberString = extractString.substr(0, extractString.find("++")+1);
                        arrayGravityCenterVerRev [atoi(lineNumberString.c_str())*6] = -1;
                    }
                }
                
                int *arrayLineageRepairDataTemp = new int [gravityCenterRevVerCount+10];
                int lineageDataRepairTempCount = 0;
                
                for (int counter1 = 0; counter1 < gravityCenterRevVerCount/6; counter1++){
                    if (arrayGravityCenterVerRev [counter1*6] != -1){
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayGravityCenterVerRev [counter1*6], lineageDataRepairTempCount++;
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayGravityCenterVerRev [counter1*6+1], lineageDataRepairTempCount++;
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayGravityCenterVerRev [counter1*6+2], lineageDataRepairTempCount++;
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayGravityCenterVerRev [counter1*6+3], lineageDataRepairTempCount++;
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayGravityCenterVerRev [counter1*6+4], lineageDataRepairTempCount++;
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayGravityCenterVerRev [counter1*6+5], lineageDataRepairTempCount++;
                    }
                }
                
                gravityCenterRevVerCount = 0;
                
                for (int counter1 = 0; counter1 < lineageDataRepairTempCount; counter1++) arrayGravityCenterVerRev [gravityCenterRevVerCount] = arrayLineageRepairDataTemp [counter1], gravityCenterRevVerCount++;
                
                delete [] arrayLineageRepairDataTemp;
            }
        }
        else if (dataType == 6){
            if (processType == 0){
                string connectString;
                string proTypeString;
                string cutString;
                string pairString;
                string dimString;
                string lineNumberString;
                string extractString;
                
                for (int counter1 = 0; counter1 < listStringCount; counter1++){
                    if ((int)arrayListString [counter1].find("&&R") != -1){
                        extractString = arrayListString [counter1].substr(arrayListString [counter1].find("//")+2);
                        connectString = extractString.substr(1, extractString.find("/")-1);
                        extractString = extractString.substr(extractString.find("/")+1);
                        proTypeString = extractString.substr(1, extractString.find("/")-1);
                        extractString = extractString.substr(extractString.find("/")+1);
                        cutString = extractString.substr(1, extractString.find("/")-1);
                        extractString = extractString.substr(extractString.find("/")+1);
                        pairString = extractString.substr(1, extractString.find("/")-1);
                        extractString = extractString.substr(extractString.find("/")+1);
                        dimString = extractString.substr(1, extractString.find("/")-1);
                        extractString = arrayListString [counter1].substr(arrayListString [counter1].find("~~")+2);
                        lineNumberString = extractString.substr(0, extractString.find("++")+1);
                        
                        arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*6] = atoi(connectString.c_str());
                        arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*6+1] = atoi(proTypeString.c_str());
                        arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*6+2] = atoi(cutString.c_str());
                        arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*6+3] = atoi(pairString.c_str());
                        arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*6+4] = atoi(dimString.c_str());
                        arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*6+5] = 0;
                    }
                }
            }
            else{
                
                string lineNumberString;
                string extractString;
                
                for (int counter1 = 0; counter1 < listStringCount; counter1++){
                    if ((int)arrayListString [counter1].find("&&R") != -1){
                        extractString = arrayListString [counter1].substr(arrayListString [counter1].find("~~")+2);
                        lineNumberString = extractString.substr(0, extractString.find("++")+1);
                        arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*6] = -1;
                    }
                }
                
                int *arrayLineageRepairDataTemp = new int [repairDataHoldVerCount+10];
                int lineageDataRepairTempCount = 0;
                
                for (int counter1 = 0; counter1 < repairDataHoldVerCount/6; counter1++){
                    if (arrayRepairDataHoldVerRev [counter1*6] != -1){
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*6], lineageDataRepairTempCount++;
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*6+1], lineageDataRepairTempCount++;
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*6+2], lineageDataRepairTempCount++;
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*6+3], lineageDataRepairTempCount++;
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*6+4], lineageDataRepairTempCount++;
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*6+5], lineageDataRepairTempCount++;
                    }
                }
                
                repairDataHoldVerCount = 0;
                
                for (int counter1 = 0; counter1 < lineageDataRepairTempCount; counter1++) arrayRepairDataHoldVerRev [repairDataHoldVerCount] = arrayLineageRepairDataTemp [counter1], repairDataHoldVerCount++;
                
                delete [] arrayLineageRepairDataTemp;
            }
        }
    }
    else returnValue = -1;
    
    return returnValue;
}

-(void)masterDataSave{
    unsigned long indexCount = 0;
    int readBit [4];
    int dataTemp = 0;
    
    char *writingArray = new char [(positionReviseVerCount/7+repairDataHoldVerCount/6+gravityCenterRevVerCount/6)*17+50];
    
    for (int counter1 = 0; counter1 < positionReviseVerCount/7; counter1++){
        dataTemp = arrayPositionReviseVer [counter1*7];
        readBit [0] = dataTemp/256;
        dataTemp = dataTemp%256;
        readBit [1] = dataTemp;
        
        writingArray [indexCount] = (char)readBit [0], indexCount++;
        writingArray [indexCount] = (char)readBit [1], indexCount++;
        
        dataTemp = arrayPositionReviseVer [counter1*7+1];
        readBit [0] = dataTemp/256;
        dataTemp = dataTemp%256;
        readBit [1] = dataTemp;
        
        writingArray [indexCount] = (char)readBit [0], indexCount++;
        writingArray [indexCount] = (char)readBit [1], indexCount++;
        
        writingArray [indexCount] = (char)arrayPositionReviseVer [counter1*7+2], indexCount++;
        
        dataTemp = arrayPositionReviseVer [counter1*7+3];
        readBit [0] = dataTemp/65536;
        dataTemp = dataTemp%65536;
        readBit [1] = dataTemp/256;
        dataTemp = dataTemp%256;
        readBit [2] = dataTemp;
        
        writingArray [indexCount] = (char)readBit [0], indexCount++;
        writingArray [indexCount] = (char)readBit [1], indexCount++;
        writingArray [indexCount] = (char)readBit [2], indexCount++;
        
        dataTemp = arrayPositionReviseVer [counter1*7+4];
        
        if (dataTemp < 0) dataTemp = dataTemp*-1, writingArray [indexCount] = 1, indexCount++;
        else writingArray [indexCount] = 0, indexCount++;
        
        readBit [0] = dataTemp/16777216;
        dataTemp = dataTemp%16777216;
        readBit [1] = dataTemp/65536;
        dataTemp = dataTemp%65536;
        readBit [2] = dataTemp/256;
        dataTemp = dataTemp%256;
        readBit [3] = dataTemp;
        
        writingArray [indexCount] = (char)readBit [0], indexCount++;
        writingArray [indexCount] = (char)readBit [1], indexCount++;
        writingArray [indexCount] = (char)readBit [2], indexCount++;
        writingArray [indexCount] = (char)readBit [3], indexCount++;
        
        writingArray [indexCount] = (char)arrayPositionReviseVer [counter1*7+5], indexCount++;
        
        dataTemp = arrayPositionReviseVer [counter1*7+6];
        readBit [0] = dataTemp/65536;
        dataTemp = dataTemp%65536;
        readBit [1] = dataTemp/256;
        dataTemp = dataTemp%256;
        readBit [2] = dataTemp;
        
        writingArray [indexCount] = (char)readBit [0], indexCount++;
        writingArray [indexCount] = (char)readBit [1], indexCount++;
        writingArray [indexCount] = (char)readBit [2], indexCount++;
    }
    
    for (int counter1 = 0; counter1 < 17; counter1++) writingArray [indexCount] = 0, indexCount++;
    
    for (int counter1 = 0; counter1 < repairDataHoldVerCount/6; counter1++){
        dataTemp = arrayRepairDataHoldVerRev [counter1*6];
        readBit [0] = dataTemp/65536;
        dataTemp = dataTemp%65536;
        readBit [1] = dataTemp/256;
        dataTemp = dataTemp%256;
        readBit [2] = dataTemp;
        
        writingArray [indexCount] = (char)readBit [0], indexCount++;
        writingArray [indexCount] = (char)readBit [1], indexCount++;
        writingArray [indexCount] = (char)readBit [2], indexCount++;
        
        writingArray [indexCount] = (char)arrayRepairDataHoldVerRev [counter1*6+1], indexCount++;
        
        writingArray [indexCount] = (char)arrayRepairDataHoldVerRev [counter1*6+2], indexCount++;
        
        dataTemp = arrayRepairDataHoldVerRev [counter1*6+3];
        readBit [0] = dataTemp/65536;
        dataTemp = dataTemp%65536;
        readBit [1] = dataTemp/256;
        dataTemp = dataTemp%256;
        readBit [2] = dataTemp;
        
        writingArray [indexCount] = (char)readBit [0], indexCount++;
        writingArray [indexCount] = (char)readBit [1], indexCount++;
        writingArray [indexCount] = (char)readBit [2], indexCount++;
        
        dataTemp = arrayRepairDataHoldVerRev [counter1*6+4];
        readBit [0] = dataTemp/256;
        dataTemp = dataTemp%256;
        readBit [1] = dataTemp;
        
        writingArray [indexCount] = (char)readBit [0], indexCount++;
        writingArray [indexCount] = (char)readBit [1], indexCount++;
        
        writingArray [indexCount] = (char)arrayRepairDataHoldVerRev [counter1*6+5], indexCount++;
    }
    
    for (int counter1 = 0; counter1 < 11; counter1++) writingArray [indexCount] = 0, indexCount++;
    
    for (int counter1 = 0; counter1 < gravityCenterRevVerCount/6; counter1++){
        dataTemp = arrayGravityCenterVerRev [counter1*6];
        readBit [0] = dataTemp/256;
        dataTemp = dataTemp%256;
        readBit [1] = dataTemp;
        
        writingArray [indexCount] = (char)readBit [0], indexCount++;
        writingArray [indexCount] = (char)readBit [1], indexCount++;
        
        dataTemp = arrayGravityCenterVerRev [counter1*6+1];
        readBit [0] = dataTemp/256;
        dataTemp = dataTemp%256;
        readBit [1] = dataTemp;
        
        writingArray [indexCount] = (char)readBit [0], indexCount++;
        writingArray [indexCount] = (char)readBit [1], indexCount++;
        
        dataTemp = arrayGravityCenterVerRev [counter1*6+2];
        readBit [0] = dataTemp/65536;
        dataTemp = dataTemp%65536;
        readBit [1] = dataTemp/256;
        dataTemp = dataTemp%256;
        readBit [2] = dataTemp;
        
        writingArray [indexCount] = (char)readBit [0], indexCount++;
        writingArray [indexCount] = (char)readBit [1], indexCount++;
        writingArray [indexCount] = (char)readBit [2], indexCount++;
        
        writingArray [indexCount] = (char)arrayGravityCenterVerRev [counter1*6+3], indexCount++;
        
        dataTemp = arrayGravityCenterVerRev [counter1*6+4];
        readBit [0] = dataTemp/65536;
        dataTemp = dataTemp%65536;
        readBit [1] = dataTemp/256;
        dataTemp = dataTemp%256;
        readBit [2] = dataTemp;
        
        writingArray [indexCount] = (char)readBit [0], indexCount++;
        writingArray [indexCount] = (char)readBit [1], indexCount++;
        writingArray [indexCount] = (char)readBit [2], indexCount++;
        
        writingArray [indexCount] = (char)arrayGravityCenterVerRev [counter1*6+5], indexCount++;
    }
    
    for (int counter1 = 0; counter1 < 11; counter1++) writingArray [indexCount] = 0, indexCount++;
    
    ofstream outfile (masterDataRevPath.c_str(), ofstream::binary);
    outfile.write ((char*)writingArray, indexCount);
    outfile.close();
    
    delete [] writingArray;
}

-(void)timeSelectedList:(long)size :(int)processType{
    ifstream fin;
    
    int finData [20];
    
    fin.open(lineageDataPath.c_str(), ios::in | ios::binary);
    
    if (fin.is_open()){
        uint8_t *uploadTemp = new uint8_t [size+50];
        fin.read((char*)uploadTemp, size+1);
        fin.close();
        
        int readPosition = 0;
        int stepCount = 0;
        
        do{
            
            if (stepCount == 0){
                finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                finData [1] = uploadTemp [readPosition], readPosition++;
                finData [2] = uploadTemp [readPosition], readPosition++;
                finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                finData [4] = uploadTemp [readPosition], readPosition++;
                finData [5] = uploadTemp [readPosition], readPosition++;
                finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                finData [7] = uploadTemp [readPosition], readPosition++;
                finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                finData [13] = uploadTemp [readPosition], readPosition++;
                finData [14] = uploadTemp [readPosition], readPosition++;
                finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                finData [16] = uploadTemp [readPosition], readPosition++;
                finData [17] = uploadTemp [readPosition], readPosition++;
                finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                
                finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                finData [8] = finData [7]*256+finData [8];
                finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                
                if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                else{
                    
                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [0], repairDataHoldVerCount++; //-----Selected, removed, eliminated status-----
                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [3], repairDataHoldVerCount++; //-----When new line is created, enter line number which creates-----
                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [6], repairDataHoldVerCount++; //-----PositionRevise Start-----
                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [8], repairDataHoldVerCount++; //-----Cut line number-----
                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [9], repairDataHoldVerCount++; //-----X Start-----
                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [10], repairDataHoldVerCount++; //-----X End-----
                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [11], repairDataHoldVerCount++; //-----Y Start-----
                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [12], repairDataHoldVerCount++; //-----Y End-----
                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [15], repairDataHoldVerCount++; //-----Connect-----
                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [18], repairDataHoldVerCount++; //-----Lineage-----
                }
            }
            
        } while (stepCount != 3);
        
        delete [] uploadTemp;
        
        if (processType == 0){
            string statusString;
            string startString;
            string connectString;
            string lingString;
            string lineNumberString;
            string extractString;
            
            for (int counter1 = 0; counter1 < listStringCount; counter1++){
                if ((int)arrayListString [counter1].find("&&R") != -1){
                    extractString = arrayListString [counter1].substr(arrayListString [counter1].find("//")+2);
                    statusString = extractString.substr(1, extractString.find("/")-1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    startString = extractString.substr(1, extractString.find("/")-1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    connectString = extractString.substr(1, extractString.find("/")-1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    lingString = extractString.substr(2, extractString.find("~~")-2);
                    extractString = arrayListString [counter1].substr(arrayListString [counter1].find("~~")+2);
                    lineNumberString = extractString.substr(0, extractString.find("++")+1);
                    
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*10] = atoi(statusString.c_str());
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*10+1] = 0;
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*10+2] = atoi(startString.c_str());
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*10+3] = 0;
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*10+4] = 0;
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*10+5] = 0;
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*10+6] = 0;
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*10+7] = 0;
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*10+8] = atoi(connectString.c_str());
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*10+9] = atoi(lingString.c_str());
                }
            }
        }
        else{
            
            string lineNumberString;
            string extractString;
            
            for (int counter1 = 0; counter1 < listStringCount; counter1++){
                if ((int)arrayListString [counter1].find("&&R") != -1){
                    extractString = arrayListString [counter1].substr(arrayListString [counter1].find("~~")+2);
                    lineNumberString = extractString.substr(0, extractString.find("++")+1);
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*10] = -1;
                }
            }
            
            int *arrayLineageRepairDataTemp = new int [repairDataHoldVerCount+10];
            int lineageDataRepairTempCount = 0;
            
            for (int counter1 = 0; counter1 < repairDataHoldVerCount/10; counter1++){
                if (arrayRepairDataHoldVerRev [counter1*10] != -1){
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*10], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*10+1], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*10+2], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*10+3], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*10+4], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*10+5], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*10+6], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*10+7], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*10+8], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*10+9], lineageDataRepairTempCount++;
                }
            }
            
            repairDataHoldVerCount = 0;
            
            for (int counter1 = 0; counter1 < lineageDataRepairTempCount; counter1++) arrayRepairDataHoldVerRev [repairDataHoldVerCount] = arrayLineageRepairDataTemp [counter1], repairDataHoldVerCount++;
            
            delete [] arrayLineageRepairDataTemp;
        }
        
        char *writingArray = new char [repairDataHoldVerCount/10*19+20];
        
        unsigned long indexCount = 0;
        int connectNumberTemp = 0;
        int dataTemp = 0;
        int readBit [4];
        
        for (int counter3 = 0; counter3 < repairDataHoldVerCount/10; counter3++){
            writingArray [indexCount] = (char)arrayRepairDataHoldVerRev [counter3*10], indexCount++;
            writingArray [indexCount] = 0, indexCount++;
            writingArray [indexCount] = 0, indexCount++;
            writingArray [indexCount] = 0, indexCount++;
            
            dataTemp = arrayRepairDataHoldVerRev [counter3*10+2];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = 0, indexCount++;
            writingArray [indexCount] = 0, indexCount++;
            
            writingArray [indexCount] = (char)arrayRepairDataHoldVerRev  [counter3*10+4], indexCount++;
            writingArray [indexCount] = (char)arrayRepairDataHoldVerRev  [counter3*10+5], indexCount++;
            writingArray [indexCount] = (char)arrayRepairDataHoldVerRev  [counter3*10+6], indexCount++;
            writingArray [indexCount] = (char)arrayRepairDataHoldVerRev  [counter3*10+7], indexCount++;
            
            dataTemp = arrayRepairDataHoldVerRev  [counter3*10+8];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            if (arrayRepairDataHoldVerRev  [counter3*10] == 3 || arrayRepairDataHoldVerRev  [counter3*10] == 4) connectNumberTemp = 0;
            else connectNumberTemp = arrayRepairDataHoldVerRev  [counter3*10+9];
            
            dataTemp = connectNumberTemp;
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
        }
        
        for (int counter3 = 0; counter3 < 19; counter3++) writingArray [indexCount] = 0, indexCount++;
        
        ofstream outfile2 (lineageDataPath.c_str(), ofstream::binary);
        outfile2.write ((char*) writingArray, indexCount);
        outfile2.close();
        
        delete [] writingArray;
    }
}

-(void)connectRLList:(long)size :(int)processType{
    ifstream fin;
    
    int finData [20];
    
    fin.open(lineageDataPath.c_str(), ios::in | ios::binary);
    
    if (fin.is_open()){
        uint8_t *uploadTemp = new uint8_t [size+50];
        fin.read((char*)uploadTemp, size+1);
        fin.close();
        
        int readPosition = 0;
        int stepCount = 0;
        
        do{
            
            if (stepCount == 0){
                finData [0] = uploadTemp [readPosition], readPosition++;
                finData [1] = uploadTemp [readPosition], readPosition++;
                finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                finData [3] = uploadTemp [readPosition], readPosition++;
                finData [4] = uploadTemp [readPosition], readPosition++;
                finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                finData [6] = uploadTemp [readPosition], readPosition++;
                finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                finData [9] = uploadTemp [readPosition], readPosition++;
                finData [10] = uploadTemp [readPosition], readPosition++;
                finData [11] = uploadTemp [readPosition], readPosition++;
                finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                
                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                finData [7] = finData [6]*256+finData [7];
                
                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                
                if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                else{
                    
                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [2], repairDataHoldVerCount++;
                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [5], repairDataHoldVerCount++;
                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [7], repairDataHoldVerCount++;
                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [12], repairDataHoldVerCount++;
                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [13], repairDataHoldVerCount++;
                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [14], repairDataHoldVerCount++;
                }
            }
            
        } while (stepCount != 3);
        
        delete [] uploadTemp;
        
        if (processType == 0){
            string lingString;
            string connectString;
            string timeString;
            string cellString;
            string targetString;
            string lineNumberString;
            string extractString;
            
            for (int counter1 = 0; counter1 < listStringCount; counter1++){
                if ((int)arrayListString [counter1].find("&&R") != -1){
                    extractString = arrayListString [counter1].substr(arrayListString [counter1].find("//")+2);
                    lingString = extractString.substr(2, extractString.find("/")-2);
                    extractString = extractString.substr(extractString.find("/")+1);
                    connectString = extractString.substr(1, extractString.find("/")-1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    timeString = extractString.substr(1, extractString.find("/")-1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    cellString = extractString.substr(1, extractString.find("/")-1);
                    cellString = cellString.substr(cellString.find("C")+1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    targetString = extractString.substr(1, extractString.find("/")-1);
                    extractString = arrayListString [counter1].substr(arrayListString [counter1].find("~~")+2);
                    lineNumberString = extractString.substr(0, extractString.find("++")+1);
                    
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*6] = atoi(lingString.c_str());
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*6+1] = atoi(connectString.c_str());
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*6+2] = atoi(timeString.c_str());
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*6+3] = atoi(cellString.c_str());
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*6+4] = atoi(targetString.c_str());
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*6+5] = 0;
                }
            }
        }
        else{
            
            string lineNumberString;
            string extractString;
            
            for (int counter1 = 0; counter1 < listStringCount; counter1++){
                if ((int)arrayListString [counter1].find("&&R") != -1){
                    extractString = arrayListString [counter1].substr(arrayListString [counter1].find("~~")+2);
                    lineNumberString = extractString.substr(0, extractString.find("++")+1);
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*6] = -1;
                }
            }
            
            int *arrayLineageRepairDataTemp = new int [repairDataHoldVerCount+10];
            int lineageDataRepairTempCount = 0;
            
            for (int counter1 = 0; counter1 < repairDataHoldVerCount/6; counter1++){
                if (arrayRepairDataHoldVerRev [counter1*6] != -1){
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*6], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*6+1], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*6+2], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*6+3], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*6+4], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*6+5], lineageDataRepairTempCount++;
                }
            }
            
            repairDataHoldVerCount = 0;
            
            for (int counter1 = 0; counter1 < lineageDataRepairTempCount; counter1++) arrayRepairDataHoldVerRev [repairDataHoldVerCount] = arrayLineageRepairDataTemp [counter1], repairDataHoldVerCount++;
            
            delete [] arrayLineageRepairDataTemp;
        }
        
        char *writingArray = new char [repairDataHoldVerCount/6*16+16];
        
        unsigned long indexCount = 0;
        int readBit [4];
        int dataTemp = 0;
        
        for (int counter1 = 0; counter1 < repairDataHoldVerCount/6; counter1++){
            dataTemp = arrayRepairDataHoldVerRev [counter1*6];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayRepairDataHoldVerRev [counter1*6+1];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayRepairDataHoldVerRev [counter1*6+2];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            if (arrayRepairDataHoldVerRev [counter1*6+3] < 0){
                writingArray [indexCount] = 1, indexCount++;
                dataTemp = arrayRepairDataHoldVerRev [counter1*6+3]*-1;
            }
            else{
                
                writingArray [indexCount] = 0, indexCount++;
                dataTemp = arrayRepairDataHoldVerRev [counter1*6+3];
            }
            
            readBit [0] = dataTemp/16777216;
            dataTemp = dataTemp%16777216;
            readBit [1] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [2] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [3] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            writingArray [indexCount] = (char)readBit [3], indexCount++;
            
            writingArray [indexCount] = 0, indexCount++;
            
            writingArray [indexCount] = (char)arrayRepairDataHoldVerRev [counter1*6+5], indexCount++;
        }
        
        for (int counter1 = 0; counter1 < 15; counter1++) writingArray [indexCount] = 0, indexCount++;
        
        ofstream outfile2 (lineageDataPath.c_str(), ofstream::binary);
        outfile2.write ((char*) writingArray, indexCount);
        outfile2.close();
        
        delete [] writingArray;
    }
}

-(int)fluorescentLineList:(long)size :(int)processType{
    int returnValue = 0;
    
    ifstream fin;
    
    int finData [20];
    
    fin.open(lineageDataPath.c_str(), ios::in | ios::binary);
    
    int errorFind = 0;
    
    if (fin.is_open()){
        uint8_t *uploadTemp = new uint8_t [size+50];
        fin.read((char*)uploadTemp, size+50);
        
        if ((finData [0] = uploadTemp [size-1]) != 0 || (finData [0] = uploadTemp [size-2]) != 0 || (finData [0] = uploadTemp [size-3]) != 0 || (finData [0] = uploadTemp [size-4]) != 0 || (finData [0] = uploadTemp [size-5]) != 0 || (finData [0] = uploadTemp [size-6]) != 0 || (finData [0] = uploadTemp [size-7]) != 0 || (finData [0] = uploadTemp [size-8]) != 0){
            usleep(50000);
            fin.read((char*)uploadTemp, size+50);
            
            if ((finData [0] = uploadTemp [size-1]) != 0 || (finData [0] = uploadTemp [size-2]) != 0 || (finData [0] = uploadTemp [size-3]) != 0 || (finData [0] = uploadTemp [size-4]) != 0 || (finData [0] = uploadTemp [size-5]) != 0 || (finData [0] = uploadTemp [size-6]) != 0 || (finData [0] = uploadTemp [size-7]) != 0 || (finData [0] = uploadTemp [size-8]) != 0){
                usleep(50000);
                fin.read((char*)uploadTemp, size+50);
                
                if ((finData [0] = uploadTemp [size-1]) != 0 || (finData [0] = uploadTemp [size-2]) != 0 || (finData [0] = uploadTemp [size-3]) != 0 || (finData [0] = uploadTemp [size-4]) != 0 || (finData [0] = uploadTemp [size-5]) != 0 || (finData [0] = uploadTemp [size-6]) != 0 || (finData [0] = uploadTemp [size-7]) != 0 || (finData [0] = uploadTemp [size-8]) != 0){
                    errorFind = 1;
                }
            }
        }
        
        
        fin.close();
        
        if (errorFind == 0){
            int readPosition = 0;
            int stepCount = 0;
            
            do{
                
                if (stepCount == 0){
                    finData [0] = uploadTemp [readPosition], readPosition++;
                    finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                    finData [2] = uploadTemp [readPosition], readPosition++;
                    finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                    finData [4] = uploadTemp [readPosition], readPosition++;
                    finData [5] = uploadTemp [readPosition], readPosition++;
                    finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                    finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                    
                    finData [1] = finData [0]*256+finData [1];
                    finData [3] = finData [2]*256+finData [3];
                    finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                    
                    if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                    else{
                        
                        arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [1], repairDataHoldVerCount++;
                        arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [3], repairDataHoldVerCount++;
                        arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [6], repairDataHoldVerCount++;
                        arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [7], repairDataHoldVerCount++;
                    }
                }
                
            } while (stepCount != 3);
        }
        
        delete [] uploadTemp;
        
        
        if (errorFind == 0){
            if (processType == 0){
                string xPositionString;
                string yPositionString;
                string connectString;
                string chNumberString;
                string lineNumberString;
                string extractString;
                
                for (int counter1 = 0; counter1 < listStringCount; counter1++){
                    if ((int)arrayListString [counter1].find("&&R") != -1){
                        extractString = arrayListString [counter1].substr(arrayListString [counter1].find("//")+2);
                        xPositionString = extractString.substr(1, extractString.find("/")-1);
                        extractString = extractString.substr(extractString.find("/")+1);
                        yPositionString = extractString.substr(1, extractString.find("/")-1);
                        extractString = extractString.substr(extractString.find("/")+1);
                        connectString = extractString.substr(1, extractString.find("/")-1);
                        extractString = extractString.substr(extractString.find("/")+1);
                        chNumberString = extractString.substr(1, extractString.find("~~")-1);
                        extractString = arrayListString [counter1].substr(arrayListString [counter1].find("~~")+2);
                        lineNumberString = extractString.substr(0, extractString.find("++")+1);
                        
                        arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*4] = atoi(xPositionString.c_str());
                        arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*4+1] = atoi(yPositionString.c_str());
                        arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*4+2] = atoi(connectString.c_str());
                        arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*4+3] = atoi(chNumberString.c_str());
                    }
                }
            }
            else{
                
                string lineNumberString;
                string extractString;
                
                for (int counter1 = 0; counter1 < listStringCount; counter1++){
                    if ((int)arrayListString [counter1].find("&&R") != -1){
                        extractString = arrayListString [counter1].substr(arrayListString [counter1].find("~~")+2);
                        lineNumberString = extractString.substr(0, extractString.find("++")+1);
                        arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*4] = -1;
                    }
                }
                
                int *arrayLineageRepairDataTemp = new int [repairDataHoldVerCount+10];
                int lineageDataRepairTempCount = 0;
                
                for (int counter1 = 0; counter1 < repairDataHoldVerCount/4; counter1++){
                    if (arrayRepairDataHoldVerRev [counter1*4] != -1){
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*4], lineageDataRepairTempCount++;
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*4+1], lineageDataRepairTempCount++;
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*4+2], lineageDataRepairTempCount++;
                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*4+3], lineageDataRepairTempCount++;
                    }
                }
                
                repairDataHoldVerCount = 0;
                
                for (int counter1 = 0; counter1 < lineageDataRepairTempCount; counter1++) arrayRepairDataHoldVerRev [repairDataHoldVerCount] = arrayLineageRepairDataTemp [counter1], repairDataHoldVerCount++;
                
                delete [] arrayLineageRepairDataTemp;
            }
            
            int indexCount = 0;
            int readBit [4];
            int dataTemp = 0;
            
            char *writingArray = new char [repairDataHoldVerCount*2+200];
            
            for (int counter2 = 0; counter2 < repairDataHoldVerCount/4; counter2++){
                dataTemp = arrayRepairDataHoldVerRev [counter2*4];
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                dataTemp = arrayRepairDataHoldVerRev [counter2*4+1];
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                dataTemp = arrayRepairDataHoldVerRev [counter2*4+2];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                
                writingArray [indexCount] = (char)arrayRepairDataHoldVerRev [counter2*4+3], indexCount++;
            }
            
            for (int counter2 = 0; counter2 < 8; counter2++) writingArray [indexCount] = 0, indexCount++;
            
            ofstream outfile3 (lineageDataPath.c_str(), ofstream::binary);
            outfile3.write ((char*)writingArray, indexCount);
            outfile3.close();
            
            delete [] writingArray;
        }
        else returnValue = -1;
    }
    
    return returnValue;
}

-(void)fluorescentAreaList:(long)size :(int)processType{
    ifstream fin;
    
    int finData [20];
    
    fin.open(lineageDataPath.c_str(), ios::in | ios::binary);
    
    if (fin.is_open()){
        uint8_t *uploadTemp = new uint8_t [size+50];
        fin.read((char*)uploadTemp, size+1);
        fin.close();
        
        int readPosition = 0;
        int stepCount = 0;
        
        do{
            
            if (stepCount == 0){
                finData [0] = uploadTemp [readPosition], readPosition++;
                finData [1] = uploadTemp [readPosition], readPosition++;
                finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                finData [5] = uploadTemp [readPosition], readPosition++;
                finData [6] = uploadTemp [readPosition], readPosition++;
                finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                
                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                
                if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                else{
                    
                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [2], repairDataHoldVerCount++;
                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [3], repairDataHoldVerCount++;
                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [4], repairDataHoldVerCount++;
                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [7], repairDataHoldVerCount++;
                }
            }
            
        } while (stepCount != 3);
        
        delete [] uploadTemp;
        
        if (processType == 0){
            string connectString;
            string chNumberString;
            string chValueString;
            string chAreaString;
            string lineNumberString;
            string extractString;
            
            for (int counter1 = 0; counter1 < listStringCount; counter1++){
                if ((int)arrayListString [counter1].find("&&R") != -1){
                    extractString = arrayListString [counter1].substr(arrayListString [counter1].find("//")+2);
                    connectString = extractString.substr(1, extractString.find("/")-1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    chNumberString = extractString.substr(1, extractString.find("/")-1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    chValueString = extractString.substr(1, extractString.find("/")-1);
                    extractString = extractString.substr(extractString.find("/")+1);
                    chAreaString = extractString.substr(1, extractString.find("~~")-1);
                    extractString = arrayListString [counter1].substr(arrayListString [counter1].find("~~")+2);
                    lineNumberString = extractString.substr(0, extractString.find("++")+1);
                    
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*4] = atoi(connectString.c_str());
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*4+1] = atoi(chNumberString.c_str());
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*4+2] = atoi(chValueString.c_str());
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*4+3] = atoi(chAreaString.c_str());
                }
            }
        }
        else{
            
            string lineNumberString;
            string extractString;
            
            for (int counter1 = 0; counter1 < listStringCount; counter1++){
                if ((int)arrayListString [counter1].find("&&R") != -1){
                    extractString = arrayListString [counter1].substr(arrayListString [counter1].find("~~")+2);
                    lineNumberString = extractString.substr(0, extractString.find("++")+1);
                    arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*4] = -1;
                }
            }
            
            int *arrayLineageRepairDataTemp = new int [repairDataHoldVerCount+10];
            int lineageDataRepairTempCount = 0;
            
            for (int counter1 = 0; counter1 < repairDataHoldVerCount/4; counter1++){
                if (arrayRepairDataHoldVerRev [counter1*4] != -1){
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*4], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*4+1], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*4+2], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*4+3], lineageDataRepairTempCount++;
                }
            }
            
            repairDataHoldVerCount = 0;
            
            for (int counter1 = 0; counter1 < lineageDataRepairTempCount; counter1++) arrayRepairDataHoldVerRev [repairDataHoldVerCount] = arrayLineageRepairDataTemp [counter1], repairDataHoldVerCount++;
            
            delete [] arrayLineageRepairDataTemp;
        }
        
        int indexCount = 0;
        int readBit [4];
        int dataTemp = 0;
        
        char *writingArray = new char [repairDataHoldVerCount*2+20];
        
        for (int counter2 = 0; counter2 < repairDataHoldVerCount/4; counter2++){
            dataTemp = arrayRepairDataHoldVerRev [counter2*4];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)arrayRepairDataHoldVerRev [counter2*4+1], indexCount++;
            writingArray [indexCount] = (char)arrayRepairDataHoldVerRev [counter2*4+2], indexCount++;
            
            dataTemp = arrayRepairDataHoldVerRev [counter2*4+3];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
        }
        
        for (int counter2 = 0; counter2 < 8; counter2++) writingArray [indexCount] = 0, indexCount++;
        
        ofstream outfile3 (lineageDataPath.c_str(), ofstream::binary);
        outfile3.write ((char*)writingArray, indexCount);
        outfile3.close();
        
        delete [] writingArray;
    }
}

-(void)fluorescentCutList:(int)processType{
    ifstream fin;
    
    fin.open(lineageDataPath.c_str(), ios::in | ios::binary);
    
    string getString;
    
    if (fin.is_open()){
        for (int counter1 = 0; counter1 < imageEndHold; counter1++){
            getline(fin, getString);
            
            if (getString != "End"){
                arrayRepairDataHoldVerRev [repairDataHoldVerCount] = atoi(getString.c_str()), repairDataHoldVerCount++;
                getline(fin, getString);
                arrayRepairDataHoldVerRev [repairDataHoldVerCount] = atoi(getString.c_str()), repairDataHoldVerCount++;
                getline(fin, getString);
                arrayRepairDataHoldVerRev [repairDataHoldVerCount] = atoi(getString.c_str()), repairDataHoldVerCount++;
                getline(fin, getString);
                arrayRepairDataHoldVerRev [repairDataHoldVerCount] = atoi(getString.c_str()), repairDataHoldVerCount++;
                getline(fin, getString);
                arrayRepairDataHoldVerRev [repairDataHoldVerCount] = atoi(getString.c_str()), repairDataHoldVerCount++;
                getline(fin, getString);
                arrayRepairDataHoldVerRev [repairDataHoldVerCount] = atoi(getString.c_str()), repairDataHoldVerCount++;
                getline(fin, getString);
                arrayRepairDataHoldVerRev [repairDataHoldVerCount] = atoi(getString.c_str()), repairDataHoldVerCount++;
            }
            else{
                
                break;
            }
        }
        
        fin.close();
    }
    
    if (processType == 0){
        string timeString;
        string chString1;
        string chString2;
        string chString3;
        string chString4;
        string chString5;
        string chString6;
        string lineNumberString;
        string extractString;
        
        for (int counter1 = 0; counter1 < listStringCount; counter1++){
            if ((int)arrayListString [counter1].find("&&R") != -1){
                extractString = arrayListString [counter1].substr(arrayListString [counter1].find("//")+2);
                timeString = extractString.substr(1, extractString.find("/")-1);
                extractString = extractString.substr(extractString.find("/")+1);
                chString1 = extractString.substr(1, extractString.find("/")-1);
                extractString = extractString.substr(extractString.find("/")+1);
                chString2 = extractString.substr(1, extractString.find("/")-1);
                extractString = extractString.substr(extractString.find("/")+1);
                chString3 = extractString.substr(1, extractString.find("/")-1);
                extractString = extractString.substr(extractString.find("/")+1);
                chString4 = extractString.substr(1, extractString.find("/")-1);
                extractString = extractString.substr(extractString.find("/")+1);
                chString5 = extractString.substr(1, extractString.find("/")-1);
                extractString = extractString.substr(extractString.find("/")+1);
                chString6 = extractString.substr(1, extractString.find("~~")-1);
                extractString = arrayListString [counter1].substr(arrayListString [counter1].find("~~")+2);
                lineNumberString = extractString.substr(0, extractString.find("++")+1);
                
                arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*7] = atoi(timeString.c_str());
                arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*7+1] = atoi(chString1.c_str());
                arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*7+2] = atoi(chString2.c_str());
                arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*7+3] = atoi(chString3.c_str());
                arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*7+4] = atoi(chString4.c_str());
                arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*7+5] = atoi(chString5.c_str());
                arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*7+6] = atoi(chString6.c_str());
            }
        }
    }
    else{
        
        string lineNumberString;
        string extractString;
        
        for (int counter1 = 0; counter1 < listStringCount; counter1++){
            if ((int)arrayListString [counter1].find("&&R") != -1){
                extractString = arrayListString [counter1].substr(arrayListString [counter1].find("~~")+2);
                lineNumberString = extractString.substr(0, extractString.find("++")+1);
                arrayRepairDataHoldVerRev [atoi(lineNumberString.c_str())*7] = -1;
            }
        }
        
        int *arrayLineageRepairDataTemp = new int [repairDataHoldVerCount+10];
        int lineageDataRepairTempCount = 0;
        
        for (int counter1 = 0; counter1 < repairDataHoldVerCount/7; counter1++){
            if (arrayRepairDataHoldVerRev [counter1*7] != -1){
                arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*7], lineageDataRepairTempCount++;
                arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*7+1], lineageDataRepairTempCount++;
                arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*7+2], lineageDataRepairTempCount++;
                arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*7+3], lineageDataRepairTempCount++;
                arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*7+4], lineageDataRepairTempCount++;
                arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*7+5], lineageDataRepairTempCount++;
                arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayRepairDataHoldVerRev [counter1*7+6], lineageDataRepairTempCount++;
            }
        }
        
        repairDataHoldVerCount = 0;
        
        for (int counter1 = 0; counter1 < lineageDataRepairTempCount; counter1++) arrayRepairDataHoldVerRev [repairDataHoldVerCount] = arrayLineageRepairDataTemp [counter1], repairDataHoldVerCount++;
        
        delete [] arrayLineageRepairDataTemp;
    }
    
    ofstream oin;
    oin.open(lineageDataPath.c_str(), ios::out);
    
    for (int counter1 = 0; counter1 < repairDataHoldVerCount; counter1++) oin<<arrayRepairDataHoldVerRev [counter1]<<endl;
    
    oin<<"End"<<endl;
    oin.close();
}

-(void)lineageRelDataSet{
    if (treatmentNameHold == nameStringRep){
        saveInfo = nameStringRep;
        
        dataSaveRead = [[DataSaveRead alloc] init];
        [dataSaveRead lineageDataRead];
    }
    
    int cellEnterCount = 0;
    
    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
        if (arrayLineageData [counter1*8+3] == 1 || arrayLineageData [counter1*8+3] == 31 || arrayLineageData [counter1*8+3] == 41 || arrayLineageData [counter1*8+3] == 51 || arrayLineageData [counter1*8+3] == 13) cellEnterCount++;
    }
    
    //-----Lineage Start/End List-----
    //==========1. lineage no, 2. cell no, 3. X position, 4. Y position, 5. start, 6. image start, 7. end, 8. image end==========
    string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+ analysisID+"_"+nameStringRep+"_LineageStartEnd";
    
    int *arrayLineageStartEndTemp = new int [cellEnterCount*8+100];
    int lineageStartEndTempCount = 0;
    
    int cellNumberStart = -1;
    int lineageNumberStart = 0;
    int firstEntryFind = 0;
    
    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
        if ((arrayLineageData [counter1*8+6] != lineageNumberStart || arrayLineageData [counter1*8+5] != cellNumberStart) && firstEntryFind == 0){
            lineageNumberStart = arrayLineageData [counter1*8+6];
            cellNumberStart = arrayLineageData [counter1*8+5];
            
            arrayLineageStartEndTemp [lineageStartEndTempCount] = lineageNumberStart, lineageStartEndTempCount++;
            arrayLineageStartEndTemp [lineageStartEndTempCount] = cellNumberStart, lineageStartEndTempCount++;
            arrayLineageStartEndTemp [lineageStartEndTempCount] = arrayLineageData [counter1*8], lineageStartEndTempCount++;
            arrayLineageStartEndTemp [lineageStartEndTempCount] = arrayLineageData [counter1*8+1], lineageStartEndTempCount++;
            arrayLineageStartEndTemp [lineageStartEndTempCount] = counter1, lineageStartEndTempCount++;
            arrayLineageStartEndTemp [lineageStartEndTempCount] = arrayLineageData [counter1*8+2], lineageStartEndTempCount++;
            
            firstEntryFind = 1;
        }
        else if ((arrayLineageData [counter1*8+6] != lineageNumberStart || arrayLineageData [counter1*8+5] != cellNumberStart) && firstEntryFind == 1){
            lineageNumberStart = arrayLineageData [counter1*8+6];
            cellNumberStart = arrayLineageData [counter1*8+5];
            
            arrayLineageStartEndTemp [lineageStartEndTempCount] = counter1-1, lineageStartEndTempCount++;
            arrayLineageStartEndTemp [lineageStartEndTempCount] = arrayLineageData [(counter1-1)*8+2], lineageStartEndTempCount++;
            arrayLineageStartEndTemp [lineageStartEndTempCount] = lineageNumberStart, lineageStartEndTempCount++;
            arrayLineageStartEndTemp [lineageStartEndTempCount] = cellNumberStart, lineageStartEndTempCount++;
            arrayLineageStartEndTemp [lineageStartEndTempCount] = arrayLineageData [counter1*8], lineageStartEndTempCount++;
            arrayLineageStartEndTemp [lineageStartEndTempCount] = arrayLineageData [counter1*8+1], lineageStartEndTempCount++;
            arrayLineageStartEndTemp [lineageStartEndTempCount] = counter1, lineageStartEndTempCount++;
            arrayLineageStartEndTemp [lineageStartEndTempCount] = arrayLineageData [counter1*8+2], lineageStartEndTempCount++;
        }
        
        if (counter1 == lineageDataCount/8-1){
            arrayLineageStartEndTemp [lineageStartEndTempCount] = counter1, lineageStartEndTempCount++;
            arrayLineageStartEndTemp [lineageStartEndTempCount] = arrayLineageData [counter1*8+2], lineageStartEndTempCount++;
        }
    }
    
    //for (int counterA = 0; counterA < lineageStartEndCount/8; counterA++){
    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageStartEnd [counterA*8 +counterB];
    //    cout<<" arrayLineageStartEnd "<<counterA<<endl;
    //}
    
    if (lineageStartEndTempCount != 0){
        char *mainDataEntry = new char [lineageStartEndTempCount*7+10];
        int totalEntryCount = 0;
        
        string extension;
        
        for (int counter1 = 0; counter1 < lineageStartEndTempCount; counter1++){
            extension = to_string(arrayLineageStartEndTemp [counter1]);
            
            for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
            }
            
            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
        }
        
        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
        
        ofstream outfile2 (connectStartEndPath.c_str(), ofstream::binary);
        outfile2.write (mainDataEntry, totalEntryCount);
        outfile2.close();
        
        delete [] mainDataEntry;
    }
    
    if (treatmentNameHold == nameStringRep){
        lineageStartEndCount = 0;
        
        for (int counter1 = 0; counter1 < lineageStartEndTempCount; counter1++) arrayLineageStartEnd [lineageStartEndCount] = arrayLineageStartEndTemp [counter1], lineageStartEndCount++;
    }
    
    delete [] arrayLineageStartEndTemp;
}

@end
