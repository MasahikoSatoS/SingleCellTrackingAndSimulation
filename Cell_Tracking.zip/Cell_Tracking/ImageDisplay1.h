//
//  ImageDisplay1.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2/2/17.
//
//

#ifndef IMAGEDISPLAY1_H
#define IMAGEDISPLAY1_H
#import "Controller.h" 
#endif

@interface ImageDisplay1 : NSView {
    IBOutlet NSImage *seqImage1;
    
    id merge;
    id lineSet;
    id dataSaveRead;
}

-(void)keyDown:(NSEvent *)event;
-(void)mouseDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
