//
//  ImageListTable.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2015-02-10.
//
//

#import "ImageListTable.h"

NSString *notificationToImageListTable = @"notificationExecuteImageListTable";

@implementation ImageListTable

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToImageListTable object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [initialViewList setDataSource:self];
    [initialViewList reloadData];
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    string trackDataPath = trackDataFolderPath+"/"+analysisImageNameSelect+"_Series";
    trackingListCount = 0;
    int tableViewContent = 0;
    
    string entry;
    
    DIR *dir = opendir(trackDataPath.c_str());
    struct dirent *dent;
    
    if (dir != NULL){
        while ((dent = readdir(dir))){
            entry = dent -> d_name;
            
            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                if ((int)entry.find("_TrackData") != -1){
                    if (trackingListCount+2 > trackingListLimit){
                        string *arrayUpDate = new string [trackingListCount+10];
                        
                        for (int counter1 = 0; counter1 < trackingListCount; counter1++) arrayUpDate [counter1] = arrayTrackingList [counter1];
                        
                        delete [] arrayTrackingList;
                        arrayTrackingList = new string [trackingListLimit+500];
                        trackingListLimit = trackingListLimit+500;
                        
                        for (int counter1 = 0; counter1 < trackingListCount; counter1++) arrayTrackingList [counter1] = arrayUpDate [counter1];
                        delete [] arrayUpDate;
                    }
                    
                    arrayTrackingList [trackingListCount] = entry.substr(0, entry.find("_TrackData"));
                    trackingListCount++;
                    tableViewContent++;
                }
            }
        }
        
        closedir(dir);
        
        //-----Directory Sort-----
        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
        
        for (int counter1 = 0; counter1 < trackingListCount; counter1++){
            [unsortedArray addObject:@(arrayTrackingList [counter1].c_str())];
        }
        
        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
        
        for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
            arrayTrackingList [counter1] = [unsortedArray [counter1] UTF8String];
        }
    }
    
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    string trackName = arrayTrackingList [rowIndex];
    
    NSAttributedString *attrStr;
    
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
    
    if ([[aTableColumn identifier] isEqualToString:@"COL4"]){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(trackName.c_str()) attributes:attributes];
    }
    else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    
    return attrStr;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToImageListTable object:nil];
}

@end
