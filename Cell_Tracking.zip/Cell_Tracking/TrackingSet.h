//
// TrackingSet.h
// Cell_Tracking
//
// Created by Masahiko Sato on 13/09/27.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef TRACKINGSET_H
#define TRACKINGSET_H

#import "Controller.h" 
#endif

@interface TrackingSet : NSObject {
    id expandLine;
    id fileUpdate;
}

-(int)trackingSetMain:(int)processType;

@end
