//
// ImageList.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 07/08/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "ImageList.h"

NSString *notificationToImageList = @"notificationExecuteImageList";

@implementation ImageList

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToImageList object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    imageListWindController = [[NSWindowController alloc] initWithWindowNibName:@"ImageList"];
    [imageListWindController showWindow:self];
    
    saveDataStatus = 0;
    analysisIDSelect = "";
    analysisImageNameSelect = "";
}

-(void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [imageList frame];
    CGFloat windowHeight = windowSize.size.height;
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [imageList setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [analysisCurrent setStringValue:@"nil"];
    [analysisIDCurrent setStringValue:@"nil"];
    [analysisSeriesDisplay setStringValue:@"nil"];
    [analysisIDDisplay setStringValue:@"nil"];
    [analysisIDChange setStringValue:@""];
    [timeSetDisplay setStringValue:@"nil"];
    
    [channelDisplayCh2 setTextColor:[NSColor blackColor]];
    [channelDisplayCh2 setStringValue:@"Channel 2:"];
    [channelDisplay2 setTextColor:[NSColor blackColor]];
    [channelDisplay2 setStringValue:@"nil"];
    [channelDisplayCh3 setTextColor:[NSColor blackColor]];
    [channelDisplayCh3 setStringValue:@"Channel 3:"];
    [channelDisplay3 setTextColor:[NSColor blackColor]];
    [channelDisplay3 setStringValue:@"nil"];
    [channelDisplayCh4 setTextColor:[NSColor blackColor]];
    [channelDisplayCh4 setStringValue:@"Channel 4:"];
    [channelDisplay4 setTextColor:[NSColor blackColor]];
    [channelDisplay4 setStringValue:@"nil"];
    [channelDisplayCh5 setTextColor:[NSColor blackColor]];
    [channelDisplayCh5 setStringValue:@"Channel 5:"];
    [channelDisplay5 setTextColor:[NSColor blackColor]];
    [channelDisplay5 setStringValue:@"nil"];
    [channelDisplayCh6 setTextColor:[NSColor blackColor]];
    [channelDisplayCh6 setStringValue:@"Channel 6:"];
    [channelDisplay6 setTextColor:[NSColor blackColor]];
    [channelDisplay6 setStringValue:@"nil"];
    [channelDisplayCh7 setTextColor:[NSColor blackColor]];
    [channelDisplayCh7 setStringValue:@"Channel 7:"];
    [channelDisplay7 setTextColor:[NSColor blackColor]];
    [channelDisplay7 setStringValue:@"nil"];
    
    [imageListBrowser setTarget:self];
    [imageListBrowser setDoubleAction:@selector(browserDoubleClick:)];
    [timeViewList setDataSource:self];
    
    for (NSTableColumn* column in [timeViewList tableColumns]) {
        if ([[column identifier] isEqualToString:@"COL1"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Treat" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL2"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"T.One" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL3"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"T.End" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL4"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"T.Max" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL5"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"IF" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL6"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Last" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
    }
}

-(int)browser:(NSBrowser *)sender numberOfRowsInColumn:(int)column{
    directoryInitialInfoCount = 0;
    
    if (column == 0){
        string entry;
        
        DIR *dir = opendir(imageFolderPath.c_str());
        struct dirent *dent;
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if ((int)entry.find("_Image") != -1){
                        if (directoryInitialInfoCount+2 > directoryInitialInfoLimit){
                            string *arrayUpDate = new string [directoryInitialInfoCount+10];
                            
                            for (int counter1 = 0; counter1 < directoryInitialInfoCount; counter1++) arrayUpDate [counter1] = arrayDirectoryInitialInfo [counter1];
                            
                            delete [] arrayDirectoryInitialInfo;
                            arrayDirectoryInitialInfo = new string [directoryInitialInfoLimit+500];
                            directoryInitialInfoLimit = directoryInitialInfoLimit+500;
                            
                            for (int counter1 = 0; counter1 < directoryInitialInfoCount; counter1++) arrayDirectoryInitialInfo [counter1] = arrayUpDate [counter1];
                            delete [] arrayUpDate;
                        }
                        
                        arrayDirectoryInitialInfo [directoryInitialInfoCount] = entry.substr(0, entry.find("_Image")), directoryInitialInfoCount++;
                    }
                }
            }
            
            closedir(dir);
            
            //-----Directory Sort-----
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < directoryInitialInfoCount; counter1++){
                [unsortedArray addObject:@(arrayDirectoryInitialInfo [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayDirectoryInitialInfo [counter1] = [unsortedArray [counter1] UTF8String];
            }
        }
    }
    
    if (column == 1){
        NSString *path;
        path = [sender path];
        
        string analysisFolderPath = imageFolderPath+[path UTF8String]+"_Image";
        string analysisNameTemp = [path UTF8String];
        
        if (analysisNameTemp != ""){
            analysisImageNameSelect = analysisNameTemp.substr(1);
            [analysisSeriesDisplay setStringValue:@(analysisImageNameSelect.c_str())];
            
            string entry;
            
            DIR *dir = opendir(analysisFolderPath.c_str());
            struct dirent *dent;
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if ((int)entry.find("_Stitch") != -1){
                            if (directoryInitialInfoCount+2 > directoryInitialInfoLimit){
                                string *arrayUpDate = new string [directoryInitialInfoCount+10];
                                
                                for (int counter1 = 0; counter1 < directoryInitialInfoCount; counter1++) arrayUpDate [counter1] = arrayDirectoryInitialInfo [counter1];
                                
                                delete [] arrayDirectoryInitialInfo;
                                arrayDirectoryInitialInfo = new string [directoryInitialInfoLimit+500];
                                directoryInitialInfoLimit = directoryInitialInfoLimit+500;
                                
                                for (int counter1 = 0; counter1 < directoryInitialInfoCount; counter1++) arrayDirectoryInitialInfo [counter1] = arrayUpDate [counter1];
                                delete [] arrayUpDate;
                            }
                            
                            arrayDirectoryInitialInfo [directoryInitialInfoCount] = entry.substr(0, entry.find("_Stitch")), directoryInitialInfoCount++;
                        }
                    }
                }
                
                closedir(dir);
                
                //-----Directory Sort-----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < directoryInitialInfoCount; counter1++){
                    [unsortedArray addObject:@(arrayDirectoryInitialInfo [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayDirectoryInitialInfo [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
        }
    }
    
    return directoryInitialInfoCount;
}

-(void)browser:(NSBrowser *)sender willDisplayCell:(id)cell atRow:(int)row column:(int)column{
    if (column == 0){
        string folderName = arrayDirectoryInitialInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLoaded:YES];
    }
    
    if (column == 1){
        string folderName = arrayDirectoryInitialInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLeaf:YES];
    }
}

-(IBAction)browserDoubleClick:(id)browser{
    NSString *nodePath = [browser path];
    string nodePathString = [nodePath UTF8String];
    
    if (nodePathString != ""){
        nodePathString = nodePathString.substr(1);
        
        if ((int)nodePathString.find("/") == -1){
            string analysisFolderPath = imageFolderPath+"/"+nodePathString+"_Image";
            string entry;
            string entry2;
            string analysisFolderPath2;
            string extractString;
            string extractString2;
            string extractString3;
            
            fluorescentColorTemp1 = 0;
            fluorescentColorTemp2 = 0;
            fluorescentColorTemp3 = 0;
            fluorescentColorTemp4 = 0;
            fluorescentColorTemp5 = 0;
            fluorescentColorTemp6 = 0;
            fluoColorCountTemp = 0;
            int entryCheck1 = 0;
            int entryCheck2 = 0;
            int entryCheck3 = 0;
            int entryCheck4 = 0;
            int entryCheck5 = 0;
            int entryCheck6 = 0;
            int entryCheck7 = 0;
            int entryCheck8 = 0;
            int entryCheck9 = 0;
            
            fluorescentColorNameTemp1 = "";
            fluorescentColorNameTemp2 = "";
            fluorescentColorNameTemp3 = "";
            fluorescentColorNameTemp4 = "";
            fluorescentColorNameTemp5 = "";
            fluorescentColorNameTemp6 = "";
            fluorescentDisplayCount = 0;
            fluorescentDisplayMax = 0;
            
            selectedTreatmentProcCount = 0;
            for (int counter1 = 0; counter1 < 100; counter1++) arraySelectedTreatmentProc [counter1] = "nil";
            
            for (int counter1 = 0; counter1 < 450; counter1++) arrayIFDataHold [counter1] = "nil";
            
            DIR *dir = opendir(analysisFolderPath.c_str());
            struct dirent *dent;
            DIR *dir2;
            struct dirent *dent2;
            
            fileDeleteCount = 0;
            int fileNumberCount = 0;
            int fileLastPoint = 0;
            int firstIFImageNo = 0;
            int findString2 = 0;
            int entryBMPNo = 0;
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if (fileDeleteCount+5 > fileDeleteLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate fileDeleteUpDate];
                        }
                        
                        arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                    }
                }
                
                closedir(dir);
                
                //-----Directory Sort-----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                    [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
            
            int fileDeleteCount2 = 0;
            int fileDeleteLimit2 = 1000;
            string *arrayFileDelete2 = new string [1000];
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                entry = arrayFileDelete [counter1];
                
                if ((int)entry.find("_Stitch") != -1){
                    entry = entry.substr(0, entry.find("_Stitch"));
                    arraySelectedTreatmentProc [selectedTreatmentProcCount] = entry, selectedTreatmentProcCount++;
                    analysisFolderPath2 = analysisFolderPath+"/"+entry+"_Stitch";
                    
                    dir2 = opendir(analysisFolderPath2.c_str());
                    
                    fileDeleteCount2 = 0;
                    
                    if (dir2 != NULL){
                        while ((dent2 = readdir(dir2))){
                            entry2 = dent2 -> d_name;
                            
                            if (fileDeleteCount2+5 > fileDeleteLimit2){
                                string *arrayUpDate = new string [fileDeleteCount2+10];
                                
                                for (int counter2 = 0; counter2 < fileDeleteCount2; counter2++) arrayUpDate [counter2] = arrayFileDelete2 [counter2];
                                
                                delete [] arrayFileDelete2;
                                arrayFileDelete2 = new string [fileDeleteLimit2+500];
                                fileDeleteLimit2 = fileDeleteLimit2+500;
                                
                                for (int counter2 = 0; counter2 < fileDeleteCount2; counter2++) arrayFileDelete2 [counter2] = arrayUpDate [counter2];
                                delete [] arrayUpDate;
                            }
                            
                            arrayFileDelete2 [fileDeleteCount2] = entry2, fileDeleteCount2++;
                        }
                        
                        closedir(dir2);
                        
                        //-----Directory Sort-----
                        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                        
                        for (int counter2 = 0; counter2 < fileDeleteCount2; counter2++){
                            [unsortedArray addObject:@(arrayFileDelete2 [counter2].c_str())];
                        }
                        
                        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                        
                        for (NSUInteger counter2 = 0; counter2 < [unsortedArray count]; counter2++){
                            arrayFileDelete2 [counter2] = [unsortedArray [counter2] UTF8String];
                        }
                    }
                    
                    fileNumberCount = 0;
                    fileLastPoint = 0;
                    firstIFImageNo = 10000;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount2; counter2++){
                        entry2 = arrayFileDelete2 [counter2];
                        findString2 = (int)entry2.find("STimage");
                        
                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && findString2 != -1){
                            extractString = entry2.substr(8, 4);
                            
                            if (fileNumberCount < atoi(extractString.c_str()) && (int)entry2.find("BMP") == -1 && (int)entry2.find("TIF") == -1) fileNumberCount = atoi(extractString.c_str());
                            if (fileLastPoint < atoi(extractString.c_str())) fileLastPoint = atoi(extractString.c_str());
                            if (firstIFImageNo > atoi(extractString.c_str()) && ((int)entry2.find("BMP") != -1 || (int)entry2.find("TIF") != -1)) firstIFImageNo = atoi(extractString.c_str());
                        }
                        
                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && (int)entry2.find("_") != -1){
                            if ((int)entry2.find("_1_") != -1){
                                findString2 = (int)entry2.find("_1_");
                                
                                if (((int)entry2.find(".bmp") != -1 || (int)entry2.find(".tif") != -1) && entryCheck1 == 0){
                                    if ((int)entry2.find(".bmp") != -1) extractString = entry2.substr((unsigned long)findString2+3, entry2.find(".bmp")-(unsigned long)findString2-3);
                                    else if ((int)entry2.find(".tif") != -1) extractString = entry2.substr((unsigned long)findString2+3, entry2.find(".tif")-(unsigned long)findString2-3);
                                    
                                    if (fluoColorCountTemp == 0){
                                        fluorescentColorTemp1 = 1;
                                        fluorescentColorNameTemp1 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck1 = 1;
                                    }
                                    else if (fluoColorCountTemp == 1){
                                        fluorescentColorTemp2 = 1;
                                        fluorescentColorNameTemp2 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck1 = 1;
                                    }
                                    else if (fluoColorCountTemp == 2){
                                        fluorescentColorTemp3 = 1;
                                        fluorescentColorNameTemp3 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck1 = 1;
                                    }
                                    else if (fluoColorCountTemp == 3){
                                        fluorescentColorTemp4 = 1;
                                        fluorescentColorNameTemp4 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck1 = 1;
                                    }
                                    else if (fluoColorCountTemp == 4){
                                        fluorescentColorTemp5 = 1;
                                        fluorescentColorNameTemp5 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck1 = 1;
                                    }
                                    else if (fluoColorCountTemp == 5){
                                        fluorescentColorTemp6 = 1;
                                        fluorescentColorNameTemp6 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck1 = 1;
                                    }
                                }
                                
                                if ((int)entry2.find(".BMP") != -1 || (int)entry2.find(".TIF") != -1){
                                    if ((int)entry2.find(".BMP") != -1){
                                        extractString2 = entry2.substr((unsigned long)findString2+3, entry2.find(".BMP")-(unsigned long)findString2-3);
                                        extractString3 = entry2.substr(entry2.find(".BMP")+4);
                                    }
                                    else if ((int)entry2.find(".TIF") != -1){
                                        extractString2 = entry2.substr((unsigned long)findString2+3, entry2.find(".TIF")-(unsigned long)findString2-3);
                                        extractString3 = entry2.substr(entry2.find(".TIF")+4);
                                    }
                                    
                                    entryBMPNo = atoi(extractString3.c_str())-1;
                                    
                                    if (entryBMPNo <= 27){
                                        if (arrayIFDataHold [entryBMPNo*15+13] == "nil"){
                                            arrayIFDataHold [entryBMPNo*15] = extractString3;
                                            arrayIFDataHold [entryBMPNo*15+1] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+7] = "1";
                                            arrayIFDataHold [entryBMPNo*15+13] = "1";
                                            arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "1" && arrayIFDataHold [entryBMPNo*15+7] != "1"){
                                            arrayIFDataHold [entryBMPNo*15+2] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+8] = "1";
                                            arrayIFDataHold [entryBMPNo*15+13] = "2";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "2" && arrayIFDataHold [entryBMPNo*15+7] != "1" && arrayIFDataHold [entryBMPNo*15+8] != "1"){
                                            arrayIFDataHold [entryBMPNo*15+3] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+9] = "1";
                                            arrayIFDataHold [entryBMPNo*15+13] = "3";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "3" && arrayIFDataHold [entryBMPNo*15+7] != "1" && arrayIFDataHold [entryBMPNo*15+8] != "1" && arrayIFDataHold [entryBMPNo*15+9] != "1"){
                                            arrayIFDataHold [entryBMPNo*15+4] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+10] = "1";
                                            arrayIFDataHold [entryBMPNo*15+13] = "4";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "4" && arrayIFDataHold [entryBMPNo*15+7] != "1" && arrayIFDataHold [entryBMPNo*15+8] != "1" && arrayIFDataHold [entryBMPNo*15+9] != "1" && arrayIFDataHold [entryBMPNo*15+10] != "1"){
                                            arrayIFDataHold [entryBMPNo*15+5] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+11] = "1";
                                            arrayIFDataHold [entryBMPNo*15+13] = "5";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "5" && arrayIFDataHold [entryBMPNo*15+7] != "1" && arrayIFDataHold [entryBMPNo*15+8] != "1" && arrayIFDataHold [entryBMPNo*15+9] != "1" && arrayIFDataHold [entryBMPNo*15+10] != "1" && arrayIFDataHold [entryBMPNo*15+11] != "1"){
                                            arrayIFDataHold [entryBMPNo*15+6] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+12] = "1";
                                            arrayIFDataHold [entryBMPNo*15+13] = "6";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            if ((int)entry2.find("_2_") != -1){
                                findString2 = (int)entry2.find("_2_");
                                
                                if (((int)entry2.find(".bmp") != -1 || (int)entry2.find(".tif") != -1) && entryCheck2 == 0){
                                    if ((int)entry2.find(".bmp") != -1) extractString = entry2.substr((unsigned long)findString2+3, entry2.find(".bmp")-(unsigned long)findString2-3);
                                    else if ((int)entry2.find(".tif") != -1) extractString = entry2.substr((unsigned long)findString2+3, entry2.find(".tif")-(unsigned long)findString2-3);
                                    
                                    if (fluoColorCountTemp == 0){
                                        fluorescentColorTemp1 = 2;
                                        fluorescentColorNameTemp1 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck2 = 1;
                                    }
                                    else if (fluoColorCountTemp == 1){
                                        fluorescentColorTemp2 = 2;
                                        fluorescentColorNameTemp2 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck2 = 1;
                                    }
                                    else if (fluoColorCountTemp == 2){
                                        fluorescentColorTemp3 = 2;
                                        fluorescentColorNameTemp3 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck2 = 1;
                                    }
                                    else if (fluoColorCountTemp == 3){
                                        fluorescentColorTemp4 = 2;
                                        fluorescentColorNameTemp4 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck2 = 1;
                                    }
                                    else if (fluoColorCountTemp == 4){
                                        fluorescentColorTemp5 = 2;
                                        fluorescentColorNameTemp5 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck2 = 1;
                                    }
                                    else if (fluoColorCountTemp == 5){
                                        fluorescentColorTemp6 = 2;
                                        fluorescentColorNameTemp6 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck2 = 1;
                                    }
                                }
                                
                                if ((int)entry2.find(".BMP") != -1 || (int)entry2.find(".TIF") != -1){
                                    if ((int)entry2.find(".BMP") != -1){
                                        extractString2 = entry2.substr((unsigned long)findString2+3, entry2.find(".BMP")-(unsigned long)findString2-3);
                                        extractString3 = entry2.substr(entry2.find(".BMP")+4);
                                    }
                                    else if ((int)entry2.find(".TIF") != -1){
                                        extractString2 = entry2.substr((unsigned long)findString2+3, entry2.find(".TIF")-(unsigned long)findString2-3);
                                        extractString3 = entry2.substr(entry2.find(".TIF")+4);
                                    }
                                    
                                    entryBMPNo = atoi(extractString3.c_str())-1;
                                    
                                    if (entryBMPNo <= 27){
                                        if (arrayIFDataHold [entryBMPNo*15+13] == "nil"){
                                            arrayIFDataHold [entryBMPNo*15] = extractString3;
                                            arrayIFDataHold [entryBMPNo*15+1] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+7] = "2";
                                            arrayIFDataHold [entryBMPNo*15+13] = "1";
                                            arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "1" && arrayIFDataHold [entryBMPNo*15+7] != "2"){
                                            arrayIFDataHold [entryBMPNo*15+2] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+8] = "2";
                                            arrayIFDataHold [entryBMPNo*15+13] = "2";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "2" && arrayIFDataHold [entryBMPNo*15+7] != "2" && arrayIFDataHold [entryBMPNo*15+8] != "2"){
                                            arrayIFDataHold [entryBMPNo*15+3] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+9] = "2";
                                            arrayIFDataHold [entryBMPNo*15+13] = "3";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "3" && arrayIFDataHold [entryBMPNo*15+7] != "2" && arrayIFDataHold [entryBMPNo*15+8] != "2" && arrayIFDataHold [entryBMPNo*15+9] != "2"){
                                            arrayIFDataHold [entryBMPNo*15+4] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+10] = "2";
                                            arrayIFDataHold [entryBMPNo*15+13] = "4";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "4" && arrayIFDataHold [entryBMPNo*15+7] != "2" && arrayIFDataHold [entryBMPNo*15+8] != "2" && arrayIFDataHold [entryBMPNo*15+9] != "2" && arrayIFDataHold [entryBMPNo*15+10] != "2"){
                                            arrayIFDataHold [entryBMPNo*15+5] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+11] = "2";
                                            arrayIFDataHold [entryBMPNo*15+13] = "5";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "5" && arrayIFDataHold [entryBMPNo*15+7] != "2" && arrayIFDataHold [entryBMPNo*15+8] != "2" && arrayIFDataHold [entryBMPNo*15+9] != "2" && arrayIFDataHold [entryBMPNo*15+10] != "2" && arrayIFDataHold [entryBMPNo*15+11] != "2"){
                                            arrayIFDataHold [entryBMPNo*15+6] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+12] = "2";
                                            arrayIFDataHold [entryBMPNo*15+13] = "6";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            if ((int)entry2.find("_3_") != -1){
                                findString2 = (int)entry2.find("_3_");
                                
                                if (((int)entry2.find(".bmp") != -1 || (int)entry2.find(".tif") != -1) && entryCheck3 == 0){
                                    if ((int)entry2.find(".bmp") != -1) extractString = entry2.substr((unsigned long)findString2+3, entry2.find(".bmp")-(unsigned long)findString2-3);
                                    else if ((int)entry2.find(".tif") != -1) extractString = entry2.substr((unsigned long)findString2+3, entry2.find(".tif")-(unsigned long)findString2-3);
                                    
                                    if (fluoColorCountTemp == 0){
                                        fluorescentColorTemp1 = 3;
                                        fluorescentColorNameTemp1 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck3 = 1;
                                    }
                                    else if (fluoColorCountTemp == 1){
                                        fluorescentColorTemp2 = 3;
                                        fluorescentColorNameTemp2 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck3 = 1;
                                    }
                                    else if (fluoColorCountTemp == 2){
                                        fluorescentColorTemp3 = 3;
                                        fluorescentColorNameTemp3 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck3 = 1;
                                    }
                                    else if (fluoColorCountTemp == 3){
                                        fluorescentColorTemp4 = 3;
                                        fluorescentColorNameTemp4 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck3 = 1;
                                    }
                                    else if (fluoColorCountTemp == 4){
                                        fluorescentColorTemp5 = 3;
                                        fluorescentColorNameTemp5 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck3 = 1;
                                    }
                                    else if (fluoColorCountTemp == 5){
                                        fluorescentColorTemp6 = 3;
                                        fluorescentColorNameTemp5 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck3 = 1;
                                    }
                                }
                                
                                if ((int)entry2.find(".BMP") != -1 || (int)entry2.find(".TIF") != -1){
                                    if ((int)entry2.find(".BMP") != -1){
                                        extractString2 = entry2.substr((unsigned long)findString2+3, entry2.find(".BMP")-(unsigned long)findString2-3);
                                        extractString3 = entry2.substr(entry2.find(".BMP")+4);
                                    }
                                    else if ((int)entry2.find(".TIF") != -1){
                                        extractString2 = entry2.substr((unsigned long)findString2+3, entry2.find(".TIF")-(unsigned long)findString2-3);
                                        extractString3 = entry2.substr(entry2.find(".TIF")+4);
                                    }
                                    
                                    entryBMPNo = atoi(extractString3.c_str())-1;
                                    
                                    if (entryBMPNo <= 27){
                                        if (arrayIFDataHold [entryBMPNo*15+13] == "nil"){
                                            arrayIFDataHold [entryBMPNo*15] = extractString3;
                                            arrayIFDataHold [entryBMPNo*15+1] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+7] = "3";
                                            arrayIFDataHold [entryBMPNo*15+13] = "1";
                                            arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "1" && arrayIFDataHold [entryBMPNo*15+7] != "3"){
                                            arrayIFDataHold [entryBMPNo*15+2] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+8] = "3";
                                            arrayIFDataHold [entryBMPNo*15+13] = "2";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "2" && arrayIFDataHold [entryBMPNo*15+7] != "3" && arrayIFDataHold [entryBMPNo*15+8] != "3"){
                                            arrayIFDataHold [entryBMPNo*15+3] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+9] = "3";
                                            arrayIFDataHold [entryBMPNo*15+13] = "3";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "3" && arrayIFDataHold [entryBMPNo*15+7] != "3" && arrayIFDataHold [entryBMPNo*15+8] != "3" && arrayIFDataHold [entryBMPNo*15+9] != "3"){
                                            arrayIFDataHold [entryBMPNo*15+4] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+10] = "3";
                                            arrayIFDataHold [entryBMPNo*15+13] = "4";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "4" && arrayIFDataHold [entryBMPNo*15+7] != "3" && arrayIFDataHold [entryBMPNo*15+8] != "3" && arrayIFDataHold [entryBMPNo*15+9] != "3" && arrayIFDataHold [entryBMPNo*15+10] != "3"){
                                            arrayIFDataHold [entryBMPNo*15+5] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+11] = "3";
                                            arrayIFDataHold [entryBMPNo*15+13] = "5";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "5" && arrayIFDataHold [entryBMPNo*15+7] != "3" && arrayIFDataHold [entryBMPNo*15+8] != "3" && arrayIFDataHold [entryBMPNo*15+9] != "3" && arrayIFDataHold [entryBMPNo*15+10] != "3" && arrayIFDataHold [entryBMPNo*15+11] != "3"){
                                            arrayIFDataHold [entryBMPNo*15+6] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+12] = "3";
                                            arrayIFDataHold [entryBMPNo*15+13] = "6";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            if ((int)entry2.find("_4_") != -1){
                                findString2 = (int)entry2.find("_4_");
                                
                                if (((int)entry2.find(".bmp") != -1 || (int)entry2.find(".tif") != -1) && entryCheck4 == 0){
                                    if ((int)entry2.find(".bmp") != -1) extractString = entry2.substr((unsigned long)findString2+3, entry2.find(".bmp")-(unsigned long)findString2-3);
                                    else if ((int)entry2.find(".tif") != -1) extractString = entry2.substr((unsigned long)findString2+3, entry2.find(".tif")-(unsigned long)findString2-3);
                                    
                                    if (fluoColorCountTemp == 0){
                                        fluorescentColorTemp1 = 4;
                                        fluorescentColorNameTemp1 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck4 = 1;
                                    }
                                    else if (fluoColorCountTemp == 1){
                                        fluorescentColorTemp2 = 4;
                                        fluorescentColorNameTemp2 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck4 = 1;
                                    }
                                    else if (fluoColorCountTemp == 2){
                                        fluorescentColorTemp3 = 4;
                                        fluorescentColorNameTemp3 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck4 = 1;
                                    }
                                    else if (fluoColorCountTemp == 3){
                                        fluorescentColorTemp4 = 4;
                                        fluorescentColorNameTemp4 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck4 = 1;
                                    }
                                    else if (fluoColorCountTemp == 4){
                                        fluorescentColorTemp5 = 4;
                                        fluorescentColorNameTemp5 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck4 = 1;
                                    }
                                    else if (fluoColorCountTemp == 5){
                                        fluorescentColorTemp6 = 4;
                                        fluorescentColorNameTemp6 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck4 = 1;
                                    }
                                }
                                
                                if ((int)entry2.find(".BMP") != -1 || (int)entry2.find(".TIF") != -1){
                                    if ((int)entry2.find(".BMP") != -1){
                                        extractString2 = entry2.substr((unsigned long)findString2+3, entry2.find(".BMP")-(unsigned long)findString2-3);
                                        extractString3 = entry2.substr(entry2.find(".BMP")+4);
                                    }
                                    else if ((int)entry2.find(".TIF") != -1){
                                        extractString2 = entry2.substr((unsigned long)findString2+3, entry2.find(".TIF")-(unsigned long)findString2-3);
                                        extractString3 = entry2.substr(entry2.find(".TIF")+4);
                                    }
                                    
                                    entryBMPNo = atoi(extractString3.c_str())-1;
                                    
                                    if (entryBMPNo <= 27){
                                        if (arrayIFDataHold [entryBMPNo*15+13] == "nil"){
                                            arrayIFDataHold [entryBMPNo*15] = extractString3;
                                            arrayIFDataHold [entryBMPNo*15+1] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+7] = "4";
                                            arrayIFDataHold [entryBMPNo*15+13] = "1";
                                            arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "1" && arrayIFDataHold [entryBMPNo*15+7] != "4"){
                                            arrayIFDataHold [entryBMPNo*15+2] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+8] = "4";
                                            arrayIFDataHold [entryBMPNo*15+13] = "2";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "2" && arrayIFDataHold [entryBMPNo*15+7] != "4" && arrayIFDataHold [entryBMPNo*15+8] != "4"){
                                            arrayIFDataHold [entryBMPNo*15+3] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+9] = "4";
                                            arrayIFDataHold [entryBMPNo*15+13] = "3";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "3" && arrayIFDataHold [entryBMPNo*15+7] != "4" && arrayIFDataHold [entryBMPNo*15+8] != "4" && arrayIFDataHold [entryBMPNo*15+9] != "4"){
                                            arrayIFDataHold [entryBMPNo*15+4] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+10] = "4";
                                            arrayIFDataHold [entryBMPNo*15+13] = "4";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "4" && arrayIFDataHold [entryBMPNo*15+7] != "4" && arrayIFDataHold [entryBMPNo*15+8] != "4" && arrayIFDataHold [entryBMPNo*15+9] != "4" && arrayIFDataHold [entryBMPNo*15+10] != "4"){
                                            arrayIFDataHold [entryBMPNo*15+5] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+11] = "4";
                                            arrayIFDataHold [entryBMPNo*15+13] = "5";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "5" && arrayIFDataHold [entryBMPNo*15+7] != "4" && arrayIFDataHold [entryBMPNo*15+8] != "4" && arrayIFDataHold [entryBMPNo*15+9] != "4" && arrayIFDataHold [entryBMPNo*15+10] != "4" && arrayIFDataHold [entryBMPNo*15+11] != "4"){
                                            arrayIFDataHold [entryBMPNo*15+6] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+12] = "4";
                                            arrayIFDataHold [entryBMPNo*15+13] = "6";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            if ((int)entry2.find("_5_") != -1){
                                findString2 = (int)entry2.find("_5_");
                                
                                if (((int)entry2.find(".bmp") != -1 || (int)entry2.find(".tif") != -1) && entryCheck5 == 0){
                                    if ((int)entry2.find(".bmp") != -1) extractString = entry2.substr((unsigned long)findString2+3, entry2.find(".bmp")-(unsigned long)findString2-3);
                                    else if ((int)entry2.find(".tif") != -1) extractString = entry2.substr((unsigned long)findString2+3, entry2.find(".tif")-(unsigned long)findString2-3);
                                    
                                    if (fluoColorCountTemp == 0){
                                        fluorescentColorTemp1 = 5;
                                        fluorescentColorNameTemp1 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck5 = 1;
                                    }
                                    else if (fluoColorCountTemp == 1){
                                        fluorescentColorTemp2 = 5;
                                        fluorescentColorNameTemp2 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck5 = 1;
                                    }
                                    else if (fluoColorCountTemp == 2){
                                        fluorescentColorTemp3 = 5;
                                        fluorescentColorNameTemp3 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck5 = 1;
                                    }
                                    else if (fluoColorCountTemp == 3){
                                        fluorescentColorTemp4 = 5;
                                        fluorescentColorNameTemp4 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck5 = 1;
                                    }
                                    else if (fluoColorCountTemp == 4){
                                        fluorescentColorTemp5 = 5;
                                        fluorescentColorNameTemp5 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck5 = 1;
                                    }
                                    else if (fluoColorCountTemp == 5){
                                        fluorescentColorTemp6 = 5;
                                        fluorescentColorNameTemp6 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck5 = 1;
                                    }
                                }
                                
                                if ((int)entry2.find(".BMP") != -1 || (int)entry2.find(".TIF") != -1){
                                    if ((int)entry2.find(".BMP") != -1){
                                        extractString2 = entry2.substr((unsigned long)findString2+3, entry2.find(".BMP")-(unsigned long)findString2-3);
                                        extractString3 = entry2.substr(entry2.find(".BMP")+4);
                                    }
                                    else if ((int)entry2.find(".TIF") != -1){
                                        extractString2 = entry2.substr((unsigned long)findString2+3, entry2.find(".TIF")-(unsigned long)findString2-3);
                                        extractString3 = entry2.substr(entry2.find(".TIF")+4);
                                    }
                                    
                                    entryBMPNo = atoi(extractString3.c_str())-1;
                                    
                                    if (entryBMPNo <= 27){
                                        if (arrayIFDataHold [entryBMPNo*15+13] == "nil"){
                                            arrayIFDataHold [entryBMPNo*15] = extractString3;
                                            arrayIFDataHold [entryBMPNo*15+1] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+7] = "5";
                                            arrayIFDataHold [entryBMPNo*15+13] = "1";
                                            arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "1" && arrayIFDataHold [entryBMPNo*15+7] != "5"){
                                            arrayIFDataHold [entryBMPNo*15+2] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+8] = "5";
                                            arrayIFDataHold [entryBMPNo*15+13] = "2";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "2" && arrayIFDataHold [entryBMPNo*15+7] != "5" && arrayIFDataHold [entryBMPNo*15+8] != "5"){
                                            arrayIFDataHold [entryBMPNo*15+3] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+9] = "5";
                                            arrayIFDataHold [entryBMPNo*15+13] = "3";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "3" && arrayIFDataHold [entryBMPNo*15+7] != "5" && arrayIFDataHold [entryBMPNo*15+8] != "5" && arrayIFDataHold [entryBMPNo*15+9] != "5"){
                                            arrayIFDataHold [entryBMPNo*15+4] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+10] = "5";
                                            arrayIFDataHold [entryBMPNo*15+13] = "4";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "4" && arrayIFDataHold [entryBMPNo*15+7] != "5" && arrayIFDataHold [entryBMPNo*15+8] != "5" && arrayIFDataHold [entryBMPNo*15+9] != "5" && arrayIFDataHold [entryBMPNo*15+10] != "5"){
                                            arrayIFDataHold [entryBMPNo*15+5] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+11] = "5";
                                            arrayIFDataHold [entryBMPNo*15+13] = "5";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "5" && arrayIFDataHold [entryBMPNo*15+7] != "5" && arrayIFDataHold [entryBMPNo*15+8] != "5" && arrayIFDataHold [entryBMPNo*15+9] != "5" && arrayIFDataHold [entryBMPNo*15+10] != "5" && arrayIFDataHold [entryBMPNo*15+11] != "5"){
                                            arrayIFDataHold [entryBMPNo*15+6] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+12] = "5";
                                            arrayIFDataHold [entryBMPNo*15+13] = "6";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            if ((int)entry2.find("_6_") != -1){
                                findString2 = (int)entry2.find("_6_");
                                
                                if (((int)entry2.find(".bmp") != -1 || (int)entry2.find(".tif") != -1) && entryCheck6 == 0){
                                    if ((int)entry2.find(".bmp") != -1) extractString = entry2.substr((unsigned long)findString2+3, entry2.find(".bmp")-(unsigned long)findString2-3);
                                    else if ((int)entry2.find(".tif") != -1) extractString = entry2.substr((unsigned long)findString2+3, entry2.find(".tif")-(unsigned long)findString2-3);
                                    
                                    if (fluoColorCountTemp == 0){
                                        fluorescentColorTemp1 = 6;
                                        fluorescentColorNameTemp1 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck6 = 1;
                                    }
                                    else if (fluoColorCountTemp == 1){
                                        fluorescentColorTemp2 = 6;
                                        fluorescentColorNameTemp2 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck6 = 1;
                                    }
                                    else if (fluoColorCountTemp == 2){
                                        fluorescentColorTemp3 = 6;
                                        fluorescentColorNameTemp3 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck6 = 1;
                                    }
                                    else if (fluoColorCountTemp == 3){
                                        fluorescentColorTemp4 = 6;
                                        fluorescentColorNameTemp4 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck6 = 1;
                                    }
                                    else if (fluoColorCountTemp == 4){
                                        fluorescentColorTemp5 = 6;
                                        fluorescentColorNameTemp5 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck6 = 1;
                                    }
                                    else if (fluoColorCountTemp == 5){
                                        fluorescentColorTemp6 = 6;
                                        fluorescentColorNameTemp6 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck6 = 1;
                                    }
                                }
                                
                                if ((int)entry2.find(".BMP") != -1 || (int)entry2.find(".TIF") != -1){
                                    if ((int)entry2.find(".BMP") != -1){
                                        extractString2 = entry2.substr((unsigned long)findString2+3, entry2.find(".BMP")-(unsigned long)findString2-3);
                                        extractString3 = entry2.substr(entry2.find(".BMP")+4);
                                    }
                                    else if ((int)entry2.find(".TIF") != -1){
                                        extractString2 = entry2.substr((unsigned long)findString2+3, entry2.find(".TIF")-(unsigned long)findString2-3);
                                        extractString3 = entry2.substr(entry2.find(".TIF")+4);
                                    }
                                    
                                    entryBMPNo = atoi(extractString3.c_str())-1;
                                    
                                    if (entryBMPNo <= 27){
                                        if (arrayIFDataHold [entryBMPNo*15+13] == "nil"){
                                            arrayIFDataHold [entryBMPNo*15] = extractString3;
                                            arrayIFDataHold [entryBMPNo*15+1] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+7] = "6";
                                            arrayIFDataHold [entryBMPNo*15+13] = "1";
                                            arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "1" && arrayIFDataHold [entryBMPNo*15+4] != "6"){
                                            arrayIFDataHold [entryBMPNo*15+2] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+8] = "6";
                                            arrayIFDataHold [entryBMPNo*15+13] = "2";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "2" && arrayIFDataHold [entryBMPNo*15+7] != "6" && arrayIFDataHold [entryBMPNo*15+8] != "6"){
                                            arrayIFDataHold [entryBMPNo*15+3] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+9] = "6";
                                            arrayIFDataHold [entryBMPNo*15+13] = "3";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "3" && arrayIFDataHold [entryBMPNo*15+7] != "6" && arrayIFDataHold [entryBMPNo*15+8] != "6" && arrayIFDataHold [entryBMPNo*15+9] != "6"){
                                            arrayIFDataHold [entryBMPNo*15+4] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+10] = "6";
                                            arrayIFDataHold [entryBMPNo*15+13] = "4";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "4" && arrayIFDataHold [entryBMPNo*15+7] != "6" && arrayIFDataHold [entryBMPNo*15+8] != "6" && arrayIFDataHold [entryBMPNo*15+9] != "6" && arrayIFDataHold [entryBMPNo*15+10] != "6"){
                                            arrayIFDataHold [entryBMPNo*15+5] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+11] = "6";
                                            arrayIFDataHold [entryBMPNo*15+13] = "5";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "5" && arrayIFDataHold [entryBMPNo*15+7] != "6" && arrayIFDataHold [entryBMPNo*15+8] != "6" && arrayIFDataHold [entryBMPNo*15+9] != "6" && arrayIFDataHold [entryBMPNo*15+10] != "6" && arrayIFDataHold [entryBMPNo*15+11] != "6"){
                                            arrayIFDataHold [entryBMPNo*15+6] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+12] = "6";
                                            arrayIFDataHold [entryBMPNo*15+13] = "6";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            if ((int)entry2.find("_7_") != -1){
                                findString2 = (int)entry2.find("_7_");
                                
                                if (((int)entry2.find(".bmp") != -1 || (int)entry2.find(".tif") != -1) && entryCheck7 == 0){
                                    if ((int)entry2.find(".bmp") != -1) extractString = entry2.substr((unsigned long)findString2+3, entry2.find(".bmp")-(unsigned long)findString2-3);
                                    else if ((int)entry2.find(".tif") != -1) extractString = entry2.substr((unsigned long)findString2+3, entry2.find(".tif")-(unsigned long)findString2-3);
                                    
                                    if (fluoColorCountTemp == 0){
                                        fluorescentColorTemp1 = 7;
                                        fluorescentColorNameTemp1 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck7 = 1;
                                    }
                                    else if (fluoColorCountTemp == 1){
                                        fluorescentColorTemp2 = 7;
                                        fluorescentColorNameTemp2 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck7 = 1;
                                    }
                                    else if (fluoColorCountTemp == 2){
                                        fluorescentColorTemp3 = 7;
                                        fluorescentColorNameTemp3 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck7 = 1;
                                    }
                                    else if (fluoColorCountTemp == 3){
                                        fluorescentColorTemp4 = 7;
                                        fluorescentColorNameTemp4 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck7 = 1;
                                    }
                                    else if (fluoColorCountTemp == 4){
                                        fluorescentColorTemp5 = 7;
                                        fluorescentColorNameTemp5 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck7 = 1;
                                    }
                                    else if (fluoColorCountTemp == 5){
                                        fluorescentColorTemp6 = 7;
                                        fluorescentColorNameTemp6 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck7 = 1;
                                    }
                                }
                                
                                if ((int)entry2.find(".BMP") != -1 || (int)entry2.find(".TIF") != -1){
                                    if ((int)entry2.find(".BMP") != -1){
                                        extractString2 = entry2.substr((unsigned long)findString2+3, entry2.find(".BMP")-(unsigned long)findString2-3);
                                        extractString3 = entry2.substr(entry2.find(".BMP")+4);
                                    }
                                    else if ((int)entry2.find(".TIF") != -1){
                                        extractString2 = entry2.substr((unsigned long)findString2+3, entry2.find(".TIF")-(unsigned long)findString2-3);
                                        extractString3 = entry2.substr(entry2.find(".TIF")+4);
                                    }
                                    
                                    entryBMPNo = atoi(extractString3.c_str())-1;
                                    
                                    if (entryBMPNo <= 27){
                                        if (arrayIFDataHold [entryBMPNo*15+13] == "nil"){
                                            arrayIFDataHold [entryBMPNo*15] = extractString3;
                                            arrayIFDataHold [entryBMPNo*15+1] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+7] = "7";
                                            arrayIFDataHold [entryBMPNo*15+13] = "1";
                                            arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "1" && arrayIFDataHold [entryBMPNo*15+7] != "7"){
                                            arrayIFDataHold [entryBMPNo*15+2] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+8] = "7";
                                            arrayIFDataHold [entryBMPNo*15+3] = "2";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "2" && arrayIFDataHold [entryBMPNo*15+7] != "7" && arrayIFDataHold [entryBMPNo*15+8] != "7"){
                                            arrayIFDataHold [entryBMPNo*15+3] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+9] = "7";
                                            arrayIFDataHold [entryBMPNo*15+13] = "3";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "3" && arrayIFDataHold [entryBMPNo*15+7] != "7" && arrayIFDataHold [entryBMPNo*15+8] != "7" && arrayIFDataHold [entryBMPNo*15+9] != "7"){
                                            arrayIFDataHold [entryBMPNo*15+4] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+10] = "7";
                                            arrayIFDataHold [entryBMPNo*15+13] = "4";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "4" && arrayIFDataHold [entryBMPNo*15+7] != "7" && arrayIFDataHold [entryBMPNo*15+8] != "7" && arrayIFDataHold [entryBMPNo*15+9] != "7" && arrayIFDataHold [entryBMPNo*15+10] != "7"){
                                            arrayIFDataHold [entryBMPNo*15+5] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+11] = "7";
                                            arrayIFDataHold [entryBMPNo*15+13] = "5";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "5" && arrayIFDataHold [entryBMPNo*15+7] != "7" && arrayIFDataHold [entryBMPNo*15+8] != "7" && arrayIFDataHold [entryBMPNo*15+9] != "7" && arrayIFDataHold [entryBMPNo*15+10] != "7" && arrayIFDataHold [entryBMPNo*15+11] != "7"){
                                            arrayIFDataHold [entryBMPNo*15+6] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+12] = "7";
                                            arrayIFDataHold [entryBMPNo*15+13] = "6";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            if ((int)entry2.find("_8_") != -1){
                                findString2 = (int)entry2.find("_8_");
                                
                                if (((int)entry2.find(".bmp") != -1 || (int)entry2.find(".tif") != -1) && entryCheck8 == 0){
                                    if ((int)entry2.find(".bmp") != -1) extractString = entry2.substr((unsigned long)findString2+3, entry2.find(".bmp")-(unsigned long)findString2-3);
                                    else if ((int)entry2.find(".tif") != -1) extractString = entry2.substr((unsigned long)findString2+3, entry2.find(".tif")-(unsigned long)findString2-3);
                                    
                                    if (fluoColorCountTemp == 0){
                                        fluorescentColorTemp1 = 8;
                                        fluorescentColorNameTemp1 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck8 = 1;
                                    }
                                    else if (fluoColorCountTemp == 1){
                                        fluorescentColorTemp2 = 8;
                                        fluorescentColorNameTemp2 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck8 = 1;
                                    }
                                    else if (fluoColorCountTemp == 2){
                                        fluorescentColorTemp3 = 8;
                                        fluorescentColorNameTemp3 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck8 = 1;
                                    }
                                    else if (fluoColorCountTemp == 3){
                                        fluorescentColorTemp4 = 8;
                                        fluorescentColorNameTemp4 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck8 = 1;
                                    }
                                    else if (fluoColorCountTemp == 4){
                                        fluorescentColorTemp5 = 8;
                                        fluorescentColorNameTemp5 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck8 = 1;
                                    }
                                    else if (fluoColorCountTemp == 5){
                                        fluorescentColorTemp6 = 8;
                                        fluorescentColorNameTemp6 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck8 = 1;
                                    }
                                }
                                
                                if ((int)entry2.find(".BMP") != -1 || (int)entry2.find(".TIF") != -11){
                                    if ((int)entry2.find(".BMP") != -1){
                                        extractString2 = entry2.substr((unsigned long)findString2+3, entry2.find(".BMP")-(unsigned long)findString2-3);
                                        extractString3 = entry2.substr(entry2.find(".BMP")+4);
                                    }
                                    else if ((int)entry2.find(".TIF") != -1){
                                        extractString2 = entry2.substr((unsigned long)findString2+3, entry2.find(".TIF")-(unsigned long)findString2-3);
                                        extractString3 = entry2.substr(entry2.find(".TIF")+4);
                                    }
                                    
                                    entryBMPNo = atoi(extractString3.c_str())-1;
                                    
                                    if (entryBMPNo <= 27){
                                        if (arrayIFDataHold [entryBMPNo*15+13] == "nil"){
                                            arrayIFDataHold [entryBMPNo*15] = extractString3;
                                            arrayIFDataHold [entryBMPNo*15+1] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+7] = "8";
                                            arrayIFDataHold [entryBMPNo*15+13] = "1";
                                            arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "1" && arrayIFDataHold [entryBMPNo*15+7] != "8"){
                                            arrayIFDataHold [entryBMPNo*15+2] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+8] = "8";
                                            arrayIFDataHold [entryBMPNo*15+13] = "2";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "2" && arrayIFDataHold [entryBMPNo*15+7] != "8" && arrayIFDataHold [entryBMPNo*15+8] != "8"){
                                            arrayIFDataHold [entryBMPNo*15+3] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+9] = "8";
                                            arrayIFDataHold [entryBMPNo*15+13] = "3";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "3" && arrayIFDataHold [entryBMPNo*15+7] != "8" && arrayIFDataHold [entryBMPNo*15+8] != "8" && arrayIFDataHold [entryBMPNo*15+9] != "8"){
                                            arrayIFDataHold [entryBMPNo*15+4] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+10] = "8";
                                            arrayIFDataHold [entryBMPNo*15+13] = "4";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "4" && arrayIFDataHold [entryBMPNo*15+7] != "8" && arrayIFDataHold [entryBMPNo*15+8] != "8" && arrayIFDataHold [entryBMPNo*15+9] != "8" && arrayIFDataHold [entryBMPNo*15+10] != "8"){
                                            arrayIFDataHold [entryBMPNo*15+5] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+11] = "8";
                                            arrayIFDataHold [entryBMPNo*15+13] = "5";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "5" && arrayIFDataHold [entryBMPNo*15+7] != "8" && arrayIFDataHold [entryBMPNo*15+8] != "8" && arrayIFDataHold [entryBMPNo*15+9] != "8" && arrayIFDataHold [entryBMPNo*15+10] != "8" && arrayIFDataHold [entryBMPNo*15+11] != "8"){
                                            arrayIFDataHold [entryBMPNo*15+6] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+12] = "8";
                                            arrayIFDataHold [entryBMPNo*15+13] = "6";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            if ((int)entry2.find("_9_") != -1){
                                findString2 = (int)entry2.find("_9_");
                                
                                if (((int)entry2.find(".bmp") != -1 || (int)entry2.find(".tif") != -1) && entryCheck9 == 0){
                                    if ((int)entry2.find(".bmp") != -1) extractString = entry2.substr((unsigned long)findString2+3, entry2.find(".bmp")-(unsigned long)findString2-3);
                                    else if ((int)entry2.find(".tif") != -1) extractString = entry2.substr((unsigned long)findString2+3, entry2.find(".tif")-(unsigned long)findString2-3);
                                    
                                    if (fluoColorCountTemp == 0){
                                        fluorescentColorTemp1 = 9;
                                        fluorescentColorNameTemp1 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck9 = 1;
                                    }
                                    else if (fluoColorCountTemp == 1){
                                        fluorescentColorTemp2 = 9;
                                        fluorescentColorNameTemp2 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck9 = 1;
                                    }
                                    else if (fluoColorCountTemp == 2){
                                        fluorescentColorTemp3 = 9;
                                        fluorescentColorNameTemp3 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck9 = 1;
                                    }
                                    else if (fluoColorCountTemp == 3){
                                        fluorescentColorTemp4 = 9;
                                        fluorescentColorNameTemp4 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck9 = 1;
                                    }
                                    else if (fluoColorCountTemp == 4){
                                        fluorescentColorTemp5 = 9;
                                        fluorescentColorNameTemp5 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck9 = 1;
                                    }
                                    else if (fluoColorCountTemp == 5){
                                        fluorescentColorTemp6 = 9;
                                        fluorescentColorNameTemp6 = extractString;
                                        fluoColorCountTemp++;
                                        entryCheck9 = 1;
                                    }
                                }
                                
                                if ((int)entry2.find(".BMP") != -1 || (int)entry2.find(".TIF") != -1){
                                    if ((int)entry2.find(".BMP") != -1){
                                        extractString2 = entry2.substr((unsigned long)findString2+3, entry2.find(".BMP")-(unsigned long)findString2-3);
                                        extractString3 = entry2.substr(entry2.find(".BMP")+4);
                                    }
                                    else if ((int)entry2.find(".TIF") != -1){
                                        extractString2 = entry2.substr((unsigned long)findString2+3, entry2.find(".TIF")-(unsigned long)findString2-3);
                                        extractString3 = entry2.substr(entry2.find(".TIF")+4);
                                    }
                                    
                                    entryBMPNo = atoi(extractString3.c_str())-1;
                                    
                                    if (entryBMPNo <= 27){
                                        if (arrayIFDataHold [entryBMPNo*15+13] == "nil"){
                                            arrayIFDataHold [entryBMPNo*15] = extractString3;
                                            arrayIFDataHold [entryBMPNo*15+1] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+7] = "9";
                                            arrayIFDataHold [entryBMPNo*15+13] = "1";
                                            arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "1" && arrayIFDataHold [entryBMPNo*15+7] != "9"){
                                            arrayIFDataHold [entryBMPNo*15+2] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+8] = "9";
                                            arrayIFDataHold [entryBMPNo*15+13] = "2";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "2" && arrayIFDataHold [entryBMPNo*15+7] != "9" && arrayIFDataHold [entryBMPNo*15+8] != "9"){
                                            arrayIFDataHold [entryBMPNo*15+3] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+9] = "9";
                                            arrayIFDataHold [entryBMPNo*15+13] = "3";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "3" && arrayIFDataHold [entryBMPNo*15+7] != "9" && arrayIFDataHold [entryBMPNo*15+8] != "9" && arrayIFDataHold [entryBMPNo*15+9] != "9"){
                                            arrayIFDataHold [entryBMPNo*15+4] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+10] = "9";
                                            arrayIFDataHold [entryBMPNo*15+13] = "4";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "4" && arrayIFDataHold [entryBMPNo*15+7] != "9" && arrayIFDataHold [entryBMPNo*15+8] != "9" && arrayIFDataHold [entryBMPNo*15+9] != "9" && arrayIFDataHold [entryBMPNo*15+10] != "9"){
                                            arrayIFDataHold [entryBMPNo*15+5] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+11] = "9";
                                            arrayIFDataHold [entryBMPNo*15+13] = "5";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                        else if (arrayIFDataHold [entryBMPNo*15+13] == "5" && arrayIFDataHold [entryBMPNo*15+7] != "9" && arrayIFDataHold [entryBMPNo*15+8] != "9" && arrayIFDataHold [entryBMPNo*15+9] != "9" && arrayIFDataHold [entryBMPNo*15+10] != "9" && arrayIFDataHold [entryBMPNo*15+11] != "9"){
                                            arrayIFDataHold [entryBMPNo*15+6] = extractString2;
                                            arrayIFDataHold [entryBMPNo*15+12] = "9";
                                            arrayIFDataHold [entryBMPNo*15+13] = "6";
                                            
                                            if (atoi(extractString.c_str()) < atoi(arrayIFDataHold [entryBMPNo*15+14].c_str())){
                                                arrayIFDataHold [entryBMPNo*15+14] = extractString;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    arraySelectedTreatmentProc [selectedTreatmentProcCount] = "1", selectedTreatmentProcCount++;
                    arraySelectedTreatmentProc [selectedTreatmentProcCount] = to_string (fileNumberCount), selectedTreatmentProcCount++;
                    arraySelectedTreatmentProc [selectedTreatmentProcCount] = to_string (fileNumberCount), selectedTreatmentProcCount++;
                    
                    if (firstIFImageNo == 10000){
                        arraySelectedTreatmentProc [selectedTreatmentProcCount] = "nil", selectedTreatmentProcCount++;
                    }
                    else arraySelectedTreatmentProc [selectedTreatmentProcCount] = to_string (firstIFImageNo), selectedTreatmentProcCount++;
                    
                    arraySelectedTreatmentProc [selectedTreatmentProcCount] = to_string (fileLastPoint), selectedTreatmentProcCount++;
                }
            }
            
            //for (int counterA = 0; counterA < 150/15; counterA++){
            //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<<arrayIFDataHold [counterA*15+counterB];
            //    cout<<" arrayIFDataHold "<<counterA<<endl;
            //}
            
            delete [] arrayFileDelete2;
            
            for (int counter1 = 0; counter1 < 450; counter1 = counter1+9){
                if (arrayIFDataHold [counter1] != "nil") fluorescentDisplayMax++;
                else{
                    
                    break;
                }
            }
            
            if (fluoColorCountTemp != 0){
                if (fluorescentColorTemp1 == 1){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorNameTemp1.c_str())];
                }
                else if (fluorescentColorTemp1 == 2){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorNameTemp1.c_str())];
                }
                else if (fluorescentColorTemp1 == 3){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorNameTemp1.c_str())];
                }
                else if (fluorescentColorTemp1 == 4){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorNameTemp1.c_str())];
                }
                else if (fluorescentColorTemp1 == 5){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorNameTemp1.c_str())];
                }
                else if (fluorescentColorTemp1 == 6){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorNameTemp1.c_str())];
                }
                else if (fluorescentColorTemp1 == 7){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorNameTemp1.c_str())];
                }
                else if (fluorescentColorTemp1 == 8){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorNameTemp1.c_str())];
                }
                else if (fluorescentColorTemp1 == 9){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorNameTemp1.c_str())];
                }
                else{
                    
                    [channelDisplayCh2 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor whiteColor]];
                    [channelDisplay2 setStringValue:@"nil"];
                }
                
                if (fluorescentColorTemp2 == 1){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorNameTemp2.c_str())];
                }
                else if (fluorescentColorTemp2 == 2){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorNameTemp2.c_str())];
                }
                else if (fluorescentColorTemp2 == 3){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorNameTemp2.c_str())];
                }
                else if (fluorescentColorTemp2 == 4){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorNameTemp2.c_str())];
                }
                else if (fluorescentColorTemp2 == 5){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorNameTemp2.c_str())];
                }
                else if (fluorescentColorTemp2 == 6){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorNameTemp2.c_str())];
                }
                else if (fluorescentColorTemp2 == 7){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorNameTemp2.c_str())];
                }
                else if (fluorescentColorTemp2 == 8){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorNameTemp2.c_str())];
                }
                else if (fluorescentColorTemp2 == 9){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorNameTemp2.c_str())];
                }
                else{
                    
                    [channelDisplayCh3 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor whiteColor]];
                    [channelDisplay3 setStringValue:@"nil"];
                }
                
                if (fluorescentColorTemp3 == 1){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorNameTemp3.c_str())];
                }
                else if (fluorescentColorTemp3 == 2){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorNameTemp3.c_str())];
                }
                else if (fluorescentColorTemp3 == 3){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorNameTemp3.c_str())];
                }
                else if (fluorescentColorTemp3 == 4){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorNameTemp3.c_str())];
                }
                else if (fluorescentColorTemp3 == 5){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorNameTemp3.c_str())];
                }
                else if (fluorescentColorTemp3 == 6){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorNameTemp3.c_str())];
                }
                else if (fluorescentColorTemp3 == 7){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorNameTemp3.c_str())];
                }
                else if (fluorescentColorTemp3 == 8){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorNameTemp3.c_str())];
                }
                else if (fluorescentColorTemp3 == 9){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorNameTemp3.c_str())];
                }
                else{
                    
                    [channelDisplayCh4 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor whiteColor]];
                    [channelDisplay4 setStringValue:@"nil"];
                }
                
                if (fluorescentColorTemp4 == 1){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorNameTemp4.c_str())];
                }
                else if (fluorescentColorTemp4 == 2){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorNameTemp4.c_str())];
                }
                else if (fluorescentColorTemp4 == 3){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorNameTemp4.c_str())];
                }
                else if (fluorescentColorTemp4 == 4){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorNameTemp4.c_str())];
                }
                else if (fluorescentColorTemp4 == 5){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorNameTemp4.c_str())];
                }
                else if (fluorescentColorTemp4 == 6){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorNameTemp4.c_str())];
                }
                else if (fluorescentColorTemp4 == 7){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorNameTemp4.c_str())];
                }
                else if (fluorescentColorTemp4 == 8){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorNameTemp4.c_str())];
                }
                else if (fluorescentColorTemp4 == 9){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorNameTemp4.c_str())];
                }
                else{
                    
                    [channelDisplayCh5 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor whiteColor]];
                    [channelDisplay5 setStringValue:@"nil"];
                }
                
                if (fluorescentColorTemp5 == 1){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorNameTemp5.c_str())];
                }
                else if (fluorescentColorTemp5 == 2){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorNameTemp5.c_str())];
                }
                else if (fluorescentColorTemp5 == 3){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorNameTemp5.c_str())];
                }
                else if (fluorescentColorTemp5 == 4){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorNameTemp5.c_str())];
                }
                else if (fluorescentColorTemp5 == 5){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorNameTemp5.c_str())];
                }
                else if (fluorescentColorTemp5 == 6){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorNameTemp5.c_str())];
                }
                else if (fluorescentColorTemp5 == 7){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorNameTemp5.c_str())];
                }
                else if (fluorescentColorTemp5 == 8){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorNameTemp5.c_str())];
                }
                else if (fluorescentColorTemp5 == 9){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorNameTemp5.c_str())];
                }
                else{
                    
                    [channelDisplayCh6 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor whiteColor]];
                    [channelDisplay6 setStringValue:@"nil"];
                }
                
                if (fluorescentColorTemp6 == 1){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorNameTemp6.c_str())];
                }
                else if (fluorescentColorTemp6 == 2){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorNameTemp6.c_str())];
                }
                else if (fluorescentColorTemp6 == 3){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorNameTemp6.c_str())];
                }
                else if (fluorescentColorTemp6 == 4){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorNameTemp6.c_str())];
                }
                else if (fluorescentColorTemp6 == 5){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorNameTemp6.c_str())];
                }
                else if (fluorescentColorTemp6 == 6){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorNameTemp6.c_str())];
                }
                else if (fluorescentColorTemp6 == 7){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorNameTemp6.c_str())];
                }
                else if (fluorescentColorTemp6 == 8){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorNameTemp6.c_str())];
                }
                else if (fluorescentColorTemp6 == 9){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorNameTemp6.c_str())];
                }
                else{
                    
                    [channelDisplayCh7 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor whiteColor]];
                    [channelDisplay7 setStringValue:@"nil"];
                }
                
                [fluoType setStringValue:@"Live"];
            }
            else if (fluorescentDisplayMax != 0){
                string fluorescentColorIFNoTemp1 = arrayIFDataHold [7];
                string fluorescentColorIFNoTemp2 = arrayIFDataHold [8];
                string fluorescentColorIFNoTemp3 = arrayIFDataHold [9];
                string fluorescentColorIFNoTemp4 = arrayIFDataHold [10];
                string fluorescentColorIFNoTemp5 = arrayIFDataHold [11];
                string fluorescentColorIFNoTemp6 = arrayIFDataHold [12];
                string fluorescentColorIFNameTemp1 = arrayIFDataHold [1];
                string fluorescentColorIFNameTemp2 = arrayIFDataHold [2];
                string fluorescentColorIFNameTemp3 = arrayIFDataHold [3];
                string fluorescentColorIFNameTemp4 = arrayIFDataHold [4];
                string fluorescentColorIFNameTemp5 = arrayIFDataHold [5];
                string fluorescentColorIFNameTemp6 = arrayIFDataHold [6];
                
                if (fluorescentColorIFNoTemp1 == "1"){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
                }
                else if (fluorescentColorIFNoTemp1 == "2"){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
                }
                else if (fluorescentColorIFNoTemp1 == "3"){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
                }
                else if (fluorescentColorIFNoTemp1 == "4"){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
                }
                else if (fluorescentColorIFNoTemp1 == "5"){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
                }
                else if (fluorescentColorIFNoTemp1 == "6"){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
                }
                else if (fluorescentColorIFNoTemp1 == "7"){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
                }
                else if (fluorescentColorIFNoTemp1 == "8"){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
                }
                else if (fluorescentColorIFNoTemp1 == "9"){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
                }
                else{
                    
                    [channelDisplayCh2 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor whiteColor]];
                    [channelDisplay2 setStringValue:@"nil"];
                }
                
                if (fluorescentColorIFNoTemp2 == "1"){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
                }
                else if (fluorescentColorIFNoTemp2 == "2"){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
                }
                else if (fluorescentColorIFNoTemp2 == "3"){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
                }
                else if (fluorescentColorIFNoTemp2 == "4"){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
                }
                else if (fluorescentColorIFNoTemp2 == "5"){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
                }
                else if (fluorescentColorIFNoTemp2 == "6"){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
                }
                else if (fluorescentColorIFNoTemp2 == "7"){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
                }
                else if (fluorescentColorIFNoTemp2 == "8"){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
                }
                else if (fluorescentColorIFNoTemp2 == "9"){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
                }
                else{
                    
                    [channelDisplayCh3 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor whiteColor]];
                    [channelDisplay3 setStringValue:@"nil"];
                }
                
                if (fluorescentColorIFNoTemp3 == "1"){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
                }
                else if (fluorescentColorIFNoTemp3 == "2"){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
                }
                else if (fluorescentColorIFNoTemp3 == "3"){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
                }
                else if (fluorescentColorIFNoTemp3 == "4"){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
                }
                else if (fluorescentColorIFNoTemp3 == "5"){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
                }
                else if (fluorescentColorIFNoTemp3 == "6"){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
                }
                else if (fluorescentColorIFNoTemp3 == "7"){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
                }
                else if (fluorescentColorIFNoTemp3 == "8"){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
                }
                else if (fluorescentColorIFNoTemp3 == "9"){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
                }
                else{
                    
                    [channelDisplayCh4 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor whiteColor]];
                    [channelDisplay4 setStringValue:@"nil"];
                }
                
                if (fluorescentColorIFNoTemp4 == "1"){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
                }
                else if (fluorescentColorIFNoTemp4 == "2"){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
                }
                else if (fluorescentColorIFNoTemp4 == "3"){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
                }
                else if (fluorescentColorIFNoTemp4 == "4"){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
                }
                else if (fluorescentColorIFNoTemp4 == "5"){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
                }
                else if (fluorescentColorIFNoTemp4 == "6"){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
                }
                else if (fluorescentColorIFNoTemp4 == "7"){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
                }
                else if (fluorescentColorIFNoTemp4 == "8"){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
                }
                else if (fluorescentColorIFNoTemp4 == "9"){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
                }
                else{
                    
                    [channelDisplayCh5 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor whiteColor]];
                    [channelDisplay5 setStringValue:@"nil"];
                }
                
                if (fluorescentColorIFNoTemp5 == "1"){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
                }
                else if (fluorescentColorIFNoTemp5 == "2"){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
                }
                else if (fluorescentColorIFNoTemp5 == "3"){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
                }
                else if (fluorescentColorIFNoTemp5 == "4"){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
                }
                else if (fluorescentColorIFNoTemp5 == "5"){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
                }
                else if (fluorescentColorIFNoTemp5 == "6"){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
                }
                else if (fluorescentColorIFNoTemp5 == "7"){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
                }
                else if (fluorescentColorIFNoTemp5 == "8"){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
                }
                else if (fluorescentColorIFNoTemp5 == "9"){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
                }
                else{
                    
                    [channelDisplayCh6 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor whiteColor]];
                    [channelDisplay6 setStringValue:@"nil"];
                }
                
                if (fluorescentColorIFNoTemp6 == "1"){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
                }
                else if (fluorescentColorIFNoTemp6 == "2"){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
                }
                else if (fluorescentColorIFNoTemp6 == "3"){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
                }
                else if (fluorescentColorIFNoTemp6 == "4"){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
                }
                else if (fluorescentColorIFNoTemp6 == "5"){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
                }
                else if (fluorescentColorIFNoTemp6 == "6"){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
                }
                else if (fluorescentColorIFNoTemp6 == "7"){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
                }
                else if (fluorescentColorIFNoTemp6 == "8"){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
                }
                else if (fluorescentColorIFNoTemp6 == "9"){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
                }
                else{
                    
                    [channelDisplayCh7 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor whiteColor]];
                    [channelDisplay7 setStringValue:@"nil"];
                }
                
                [fluoType setStringValue:@"IF-1"];
            }
            
            [timeSetDisplay setStringValue:@(nodePathString.c_str())];
            
            if (analysisIDSelect == ""){
                analysisIDSelect = nodePathString;
                [analysisIDDisplay setStringValue:@(nodePathString.c_str())];
            }
            
            listTableCall = 1;
            
            [timeViewList reloadData];
            
            //for (int counterA = 0; counterA < selectedTreatmentProcCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arraySelectedTreatmentProc [counterA*6+counterB];
            //    cout<<" arraySelectedTreatmentProc "<<counterA<<endl;
            //}
        }
    }
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = selectedTreatmentProcCount/6;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    string trackName = arraySelectedTreatmentProc [rowIndex*6];
    string timeOneSet = arraySelectedTreatmentProc [rowIndex*6+1];
    string timeEndSet = arraySelectedTreatmentProc [rowIndex*6+2];
    string timeMaxSet = arraySelectedTreatmentProc [rowIndex*6+3];
    string firstIFSet = arraySelectedTreatmentProc [rowIndex*6+4];
    string lastImageSet = arraySelectedTreatmentProc [rowIndex*6+5];
    
    NSAttributedString *attrStr;
    
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
    
    if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(trackName.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
        [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(timeOneSet.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL3"]){
        [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(timeEndSet.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL4"]){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(timeMaxSet.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL5"]){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(firstIFSet.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL6"]){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(lastImageSet.c_str()) attributes:attributes];
    }
    else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    
    return attrStr;
}

-(void)tableView:(NSTableView *)aTableView setObjectValue:(id)anObject forTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    string stringExtract;
    string stringExtract2;
    string objectString;
    string extension;
    
    NSString *columnIdentifer = [aTableColumn identifier];
    NSString *objectInfo = anObject;
    
    int columnNo = 2;
    
    if ([columnIdentifer isEqualToString:@"COL2"]) columnNo = 2;
    else if ([columnIdentifer isEqualToString:@"COL3"]) columnNo = 3;
    
    if (columnNo == 2 || columnNo == 3){
        if (columnNo == 2){
            objectString = [objectInfo UTF8String];
            int timeOneCheck = atoi(objectString.c_str());
            int timeEndCheck = 0;
            int timeMaxCheck = 0;
            int sourceCheck = 0;
            
            stringExtract = arraySelectedTreatmentProc [rowIndex*6+2];
            timeEndCheck = atoi(stringExtract.c_str());
            stringExtract = arraySelectedTreatmentProc [rowIndex*6+3];
            timeMaxCheck = atoi(stringExtract.c_str());
            
            if (timeMaxCheck != 0 && timeMaxCheck-10 > timeOneCheck && timeOneCheck >= 0){
                if ((timeEndCheck != 0 && timeOneCheck < timeEndCheck-10) || timeOneCheck == 0){
                    sourceCheck = 1;
                }
            }
            
            if (sourceCheck == 1){
                int othersCheck = 0;
                int moMatchCheck = 0;
                
                for (int counter1 = 0; counter1 < selectedTreatmentProcCount/6; counter1++){
                    stringExtract = arraySelectedTreatmentProc [counter1*6+2];
                    timeEndCheck = atoi(stringExtract.c_str());
                    stringExtract = arraySelectedTreatmentProc [counter1*6+3];
                    timeMaxCheck = atoi(stringExtract.c_str());
                    
                    othersCheck = 0;
                    
                    if (timeMaxCheck != 0 && timeMaxCheck-10 > timeOneCheck && timeOneCheck >= 0){
                        if ((timeEndCheck != 0 && timeOneCheck < timeEndCheck-10) || timeOneCheck == 0) othersCheck = 1;
                    }
                    
                    if (othersCheck == 0) moMatchCheck = 1;
                }
                
                if (moMatchCheck == 0){
                    for (int counter1 = 0; counter1 < selectedTreatmentProcCount/6; counter1++){
                        arraySelectedTreatmentProc [counter1*6+1] = to_string (timeOneCheck);
                    }
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [timeViewList reloadData];
                }
            }
        }
        
        if (columnNo == 3){
            objectString = [objectInfo UTF8String];
            int timeEndCheck = atoi(objectString.c_str());
            
            stringExtract = arraySelectedTreatmentProc [rowIndex*6+1];
            int timeOneCheck = atoi(stringExtract.c_str());
            stringExtract = arraySelectedTreatmentProc [rowIndex*6+3];
            int timeMaxCheck = atoi(stringExtract.c_str());
            
            if (timeMaxCheck != 0 && timeMaxCheck >= timeEndCheck && timeEndCheck > 0){
                if (timeOneCheck != 0 && timeEndCheck > timeOneCheck+10){
                    arraySelectedTreatmentProc [rowIndex*6+2] = to_string (timeEndCheck);
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [timeViewList reloadData];
                }
            }
        }
    }
}

-(IBAction)changeID:(id)sender{
    int errorFlag = 0;
    string newAnalysisID = [[analysisIDChange stringValue] UTF8String];
    
    if (newAnalysisID.length() < 4 || newAnalysisID.length() > 15) errorFlag = 1;
    if ((int)newAnalysisID.find(" ") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(",") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(".") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("/") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(",") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(":") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("<") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(">") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("'") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("[") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("]") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("=") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("+") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("{") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("}") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(")") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("(") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("*") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("&") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("^") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("%") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("$") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("#") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("@") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("!") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("`") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("~") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("|") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("-") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("_") >= 0) errorFlag = 1;
    
    if (errorFlag == 1){
        [analysisIDChange setStringValue:@"nil"];
        [analysisIDChange setStringValue:@""];
    }
    else{
        
        analysisIDSelect = newAnalysisID;
        [analysisIDDisplay setStringValue:@(newAnalysisID.c_str())];
        [analysisIDChange setStringValue:@""];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)setData:(id)sender{
    if (analysisImageNameSelect != ""){
        if (analysisSavingInProgress == 0){
            int findFlag = 0;
            string trackAnalysisNameFolderPath = trackDataFolderPath+"/"+analysisImageNameSelect+"_Series";
            string entry;
            
            DIR *dir;
            struct dirent *dent;
            
            dir = opendir(trackAnalysisNameFolderPath.c_str());
            
            if (dir != NULL){
                findFlag = 0;
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (analysisIDSelect == "" || (analysisIDSelect != "" && analysisIDSelect+"_TrackData" == entry)){
                        findFlag = 1;
                        break;
                    }
                }
                
                closedir(dir);
            }
            
            if (findFlag == 0){
                int entryCheck = 0;
                saveDataStatus = 1;
                treatmentStatusCount = 0;
                
                for (int counter1 = 0; counter1 < selectedTreatmentProcCount/6; counter1++){
                    if (arraySelectedTreatmentProc [counter1*6+1] != "0"){
                        entryCheck = 1;
                        
                        arrayTreatmentStatus [treatmentStatusCount] = arraySelectedTreatmentProc [counter1*6], treatmentStatusCount++;
                        arrayTreatmentStatus [treatmentStatusCount] = "0", treatmentStatusCount++;
                        arrayTreatmentStatus [treatmentStatusCount] = "0", treatmentStatusCount++;
                        arrayTreatmentStatus [treatmentStatusCount] = "0", treatmentStatusCount++;
                        arrayTreatmentStatus [treatmentStatusCount] = arraySelectedTreatmentProc [counter1*6+1], treatmentStatusCount++;
                        arrayTreatmentStatus [treatmentStatusCount] = arraySelectedTreatmentProc [counter1*6+2], treatmentStatusCount++;
                        arrayTreatmentStatus [treatmentStatusCount] = arraySelectedTreatmentProc [counter1*6+3], treatmentStatusCount++;
                        arrayTreatmentStatus [treatmentStatusCount] = arraySelectedTreatmentProc [counter1*6+4], treatmentStatusCount++;
                        arrayTreatmentStatus [treatmentStatusCount] = arraySelectedTreatmentProc [counter1*6+5], treatmentStatusCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < treatmentStatusCount/9; counterA++){
                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayTreatmentStatus [counterA*9+counterB];
                //    cout<<" arrayTreatmentStatus "<<counterA<<endl;
                //}
                
                if (entryCheck != 0){
                    saveDataStatus = 1;
                    analysisImageName = analysisImageNameSelect;
                    analysisID = analysisIDSelect;
                    
                    [analysisCurrent setStringValue:@(analysisImageName.c_str())];
                    [analysisIDCurrent setStringValue:@(analysisID.c_str())];
                    
                    trackAnalysisNameFolderPath = trackDataFolderPath+"/"+analysisImageName+"_Series";
                    mkdir(trackAnalysisNameFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    string trackAnalysisIDFolderPath = trackAnalysisNameFolderPath+"/"+analysisID+"_TrackData";
                    int createFolder = mkdir(trackAnalysisIDFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    if (createFolder != -1){
                        string savedDataPath = trackDataFolderPath+"/*LineageTrackingCurrent.dat";
                        string trackTreatmentFolderPath = "";
                        string dataTemp;
                        
                        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
                            dataTemp = arrayTreatmentStatus [counter1*9];
                            trackTreatmentFolderPath = trackAnalysisIDFolderPath+"/"+dataTemp+"_Treat";
                            mkdir(trackTreatmentFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                            
                            trackTreatmentFolderPath = trackAnalysisIDFolderPath+"/"+dataTemp+"_Connect";
                            mkdir(trackTreatmentFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                        }
                        
                        ofstream oin;
                        oin.open(savedDataPath.c_str(), ios::out);
                        oin<<analysisImageName<<endl;
                        oin<<analysisID<<endl;
                        oin<<autoExpand<<endl;
                        oin<<autoExpandLine<<endl;
                        oin<<trackingCheckInterval<<endl;
                        oin<<queueDisplayOptions<<endl;
                        oin<<doneDisplayOptions<<endl;
                        oin<<imageReturnPosition<<endl;
                        oin<<fluoColorCountTemp<<endl;
                        oin<<fluorescentColorTemp1<<endl;
                        oin<<fluorescentColorTemp2<<endl;
                        oin<<fluorescentColorTemp3<<endl;
                        oin<<fluorescentColorTemp4<<endl;
                        oin<<fluorescentColorTemp5<<endl;
                        oin<<fluorescentColorTemp6<<endl;
                        
                        if (fluorescentColorNameTemp1 != "") oin<<fluorescentColorNameTemp1<<endl;
                        else oin<<"nil"<<endl;
                        
                        if (fluorescentColorNameTemp2 != "") oin<<fluorescentColorNameTemp2<<endl;
                        else oin<<"nil"<<endl;
                        
                        if (fluorescentColorNameTemp3 != "") oin<<fluorescentColorNameTemp3<<endl;
                        else oin<<"nil"<<endl;
                        
                        if (fluorescentColorNameTemp4 != "") oin<<fluorescentColorNameTemp4<<endl;
                        else oin<<"nil"<<endl;
                        
                        if (fluorescentColorNameTemp5 != "") oin<<fluorescentColorNameTemp5<<endl;
                        else oin<<"nil"<<endl;
                        
                        if (fluorescentColorNameTemp6 != "") oin<<fluorescentColorNameTemp6<<endl;
                        else oin<<"nil"<<endl;
                        
                        for (int counter1 = 0; counter1 < treatmentStatusCount; counter1++) oin<<arrayTreatmentStatus [counter1]<<endl;
                        
                        oin<<"IFDATA"<<endl;
                        
                        for (int counter1 = 0; counter1 < 450; counter1 = counter1+15){
                            if (arrayIFDataHold [counter1] != "nil"){
                                oin<<arrayIFDataHold [counter1]<<endl;
                                oin<<arrayIFDataHold [counter1+1]<<endl;
                                oin<<arrayIFDataHold [counter1+2]<<endl;
                                oin<<arrayIFDataHold [counter1+3]<<endl;
                                oin<<arrayIFDataHold [counter1+4]<<endl;
                                oin<<arrayIFDataHold [counter1+5]<<endl;
                                oin<<arrayIFDataHold [counter1+6]<<endl;
                                oin<<arrayIFDataHold [counter1+7]<<endl;
                                oin<<arrayIFDataHold [counter1+8]<<endl;
                                oin<<arrayIFDataHold [counter1+9]<<endl;
                                oin<<arrayIFDataHold [counter1+10]<<endl;
                                oin<<arrayIFDataHold [counter1+11]<<endl;
                                oin<<arrayIFDataHold [counter1+12]<<endl;
                                oin<<arrayIFDataHold [counter1+13]<<endl;
                                oin<<arrayIFDataHold [counter1+14]<<endl;
                            }
                            else{
                                
                                break;
                            }
                        }
                        
                        oin<<"END"<<endl;
                        oin.close();
                        
                        string trackAnalysisSaveFilePath = trackAnalysisIDFolderPath+"/"+"*TrackingSetting.dat";
                        
                        oin.open(trackAnalysisSaveFilePath.c_str(), ios::out);
                        oin<<analysisImageName<<endl;
                        oin<<analysisID<<endl;
                        oin<<autoExpand<<endl;
                        oin<<autoExpandLine<<endl;
                        oin<<trackingCheckInterval<<endl;
                        oin<<queueDisplayOptions<<endl;
                        oin<<doneDisplayOptions<<endl;
                        oin<<imageReturnPosition<<endl;
                        
                        oin<<fluoColorCountTemp<<endl;
                        oin<<fluorescentColorTemp1<<endl;
                        oin<<fluorescentColorTemp2<<endl;
                        oin<<fluorescentColorTemp3<<endl;
                        oin<<fluorescentColorTemp4<<endl;
                        oin<<fluorescentColorTemp5<<endl;
                        oin<<fluorescentColorTemp6<<endl;
                        
                        if (fluorescentColorNameTemp1 != "") oin<<fluorescentColorNameTemp1<<endl;
                        else oin<<"nil"<<endl;
                        
                        if (fluorescentColorNameTemp2 != "") oin<<fluorescentColorNameTemp2<<endl;
                        else oin<<"nil"<<endl;
                        
                        if (fluorescentColorNameTemp3 != "") oin<<fluorescentColorNameTemp3<<endl;
                        else oin<<"nil"<<endl;
                        
                        if (fluorescentColorNameTemp4 != "") oin<<fluorescentColorNameTemp4<<endl;
                        else oin<<"nil"<<endl;
                        
                        if (fluorescentColorNameTemp5 != "") oin<<fluorescentColorNameTemp5<<endl;
                        else oin<<"nil"<<endl;
                        
                        if (fluorescentColorNameTemp6 != "") oin<<fluorescentColorNameTemp6<<endl;
                        else oin<<"nil"<<endl;
                        
                        for (int counter1 = 0; counter1 < treatmentStatusCount; counter1++) oin<<arrayTreatmentStatus [counter1]<<endl;
                        
                        oin<<"IFDATA"<<endl;
                        
                        for (int counter1 = 0; counter1 < 450; counter1 = counter1+15){
                            if (arrayIFDataHold [counter1] != "nil"){
                                oin<<arrayIFDataHold [counter1]<<endl;
                                oin<<arrayIFDataHold [counter1+1]<<endl;
                                oin<<arrayIFDataHold [counter1+2]<<endl;
                                oin<<arrayIFDataHold [counter1+3]<<endl;
                                oin<<arrayIFDataHold [counter1+4]<<endl;
                                oin<<arrayIFDataHold [counter1+5]<<endl;
                                oin<<arrayIFDataHold [counter1+6]<<endl;
                                oin<<arrayIFDataHold [counter1+7]<<endl;
                                oin<<arrayIFDataHold [counter1+8]<<endl;
                                oin<<arrayIFDataHold [counter1+9]<<endl;
                                oin<<arrayIFDataHold [counter1+10]<<endl;
                                oin<<arrayIFDataHold [counter1+11]<<endl;
                                oin<<arrayIFDataHold [counter1+12]<<endl;
                                oin<<arrayIFDataHold [counter1+13]<<endl;
                                oin<<arrayIFDataHold [counter1+14]<<endl;
                            }
                            else{
                                
                                break;
                            }
                        }
                        
                        oin<<"END"<<endl;
                        oin.close();
                    }
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    setStatus1 = 1;
                }
                else{
                    
                    [analysisIDChange setStringValue:@""];
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"No Data For Saving"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                [analysisIDChange setStringValue:@""];
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Used ID"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Save/Load In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Selected Analysis Name"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)fluorescentDisplay:(id)sender{
    if (analysisSavingInProgress == 0){
        if (fluoColorCountTemp != 0 && fluorescentDisplayMax != 0){
            fluorescentDisplayCount++;
            
            if (fluorescentDisplayCount > fluorescentDisplayMax) fluorescentDisplayCount = 0;
            
            if (fluorescentDisplayCount == 0){
                if (fluorescentColorTemp1 == 1){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorNameTemp1.c_str())];
                }
                else if (fluorescentColorTemp1 == 2){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorNameTemp1.c_str())];
                }
                else if (fluorescentColorTemp1 == 3){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorNameTemp1.c_str())];
                }
                else if (fluorescentColorTemp1 == 4){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorNameTemp1.c_str())];
                }
                else if (fluorescentColorTemp1 == 5){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorNameTemp1.c_str())];
                }
                else if (fluorescentColorTemp1 == 6){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorNameTemp1.c_str())];
                }
                else if (fluorescentColorTemp1 == 7){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorNameTemp1.c_str())];
                }
                else if (fluorescentColorTemp1 == 8){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorNameTemp1.c_str())];
                }
                else if (fluorescentColorTemp1 == 9){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorNameTemp1.c_str())];
                }
                else{
                    
                    [channelDisplayCh2 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor whiteColor]];
                    [channelDisplay2 setStringValue:@"nil"];
                }
                
                if (fluorescentColorTemp2 == 1){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorNameTemp2.c_str())];
                }
                else if (fluorescentColorTemp2 == 2){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorNameTemp2.c_str())];
                }
                else if (fluorescentColorTemp2 == 3){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorNameTemp2.c_str())];
                }
                else if (fluorescentColorTemp2 == 4){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorNameTemp2.c_str())];
                }
                else if (fluorescentColorTemp2 == 5){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorNameTemp2.c_str())];
                }
                else if (fluorescentColorTemp2 == 6){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorNameTemp2.c_str())];
                }
                else if (fluorescentColorTemp2 == 7){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorNameTemp2.c_str())];
                }
                else if (fluorescentColorTemp2 == 8){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorNameTemp2.c_str())];
                }
                else if (fluorescentColorTemp2 == 9){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorNameTemp2.c_str())];
                }
                else{
                    
                    [channelDisplayCh3 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor whiteColor]];
                    [channelDisplay3 setStringValue:@"nil"];
                }
                
                if (fluorescentColorTemp3 == 1){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorNameTemp3.c_str())];
                }
                else if (fluorescentColorTemp3 == 2){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorNameTemp3.c_str())];
                }
                else if (fluorescentColorTemp3 == 3){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorNameTemp3.c_str())];
                }
                else if (fluorescentColorTemp3 == 4){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorNameTemp3.c_str())];
                }
                else if (fluorescentColorTemp3 == 5){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorNameTemp3.c_str())];
                }
                else if (fluorescentColorTemp3 == 6){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorNameTemp3.c_str())];
                }
                else if (fluorescentColorTemp3 == 7){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorNameTemp3.c_str())];
                }
                else if (fluorescentColorTemp3 == 8){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorNameTemp3.c_str())];
                }
                else if (fluorescentColorTemp3 == 9){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorNameTemp3.c_str())];
                }
                else{
                    
                    [channelDisplayCh4 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor whiteColor]];
                    [channelDisplay4 setStringValue:@"nil"];
                }
                
                if (fluorescentColorTemp4 == 1){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorNameTemp4.c_str())];
                }
                else if (fluorescentColorTemp4 == 2){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorNameTemp4.c_str())];
                }
                else if (fluorescentColorTemp4 == 3){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorNameTemp4.c_str())];
                }
                else if (fluorescentColorTemp4 == 4){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorNameTemp4.c_str())];
                }
                else if (fluorescentColorTemp4 == 5){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorNameTemp4.c_str())];
                }
                else if (fluorescentColorTemp4 == 6){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorNameTemp4.c_str())];
                }
                else if (fluorescentColorTemp4 == 7){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorNameTemp4.c_str())];
                }
                else if (fluorescentColorTemp4 == 8){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorNameTemp4.c_str())];
                }
                else if (fluorescentColorTemp4 == 9){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorNameTemp4.c_str())];
                }
                else{
                    
                    [channelDisplayCh5 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor whiteColor]];
                    [channelDisplay5 setStringValue:@"nil"];
                }
                
                if (fluorescentColorTemp5 == 1){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorNameTemp5.c_str())];
                }
                else if (fluorescentColorTemp5 == 2){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorNameTemp5.c_str())];
                }
                else if (fluorescentColorTemp5 == 3){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorNameTemp5.c_str())];
                }
                else if (fluorescentColorTemp5 == 4){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorNameTemp5.c_str())];
                }
                else if (fluorescentColorTemp5 == 5){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorNameTemp5.c_str())];
                }
                else if (fluorescentColorTemp5 == 6){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorNameTemp5.c_str())];
                }
                else if (fluorescentColorTemp5 == 7){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorNameTemp5.c_str())];
                }
                else if (fluorescentColorTemp5 == 8){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorNameTemp5.c_str())];
                }
                else if (fluorescentColorTemp5 == 9){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorNameTemp5.c_str())];
                }
                else{
                    
                    [channelDisplayCh6 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor whiteColor]];
                    [channelDisplay6 setStringValue:@"nil"];
                }
                
                if (fluorescentColorTemp6 == 1){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorNameTemp6.c_str())];
                }
                else if (fluorescentColorTemp6 == 2){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorNameTemp6.c_str())];
                }
                else if (fluorescentColorTemp6 == 3){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorNameTemp6.c_str())];
                }
                else if (fluorescentColorTemp6 == 4){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorNameTemp6.c_str())];
                }
                else if (fluorescentColorTemp6 == 5){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorNameTemp6.c_str())];
                }
                else if (fluorescentColorTemp6 == 6){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorNameTemp6.c_str())];
                }
                else if (fluorescentColorTemp6 == 7){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorNameTemp6.c_str())];
                }
                else if (fluorescentColorTemp6 == 8){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorNameTemp6.c_str())];
                }
                else if (fluorescentColorTemp6 == 9){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorNameTemp6.c_str())];
                }
                else{
                    
                    [channelDisplayCh7 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor whiteColor]];
                    [channelDisplay7 setStringValue:@"nil"];
                }
                
                if (fluoColorCountTemp != 0) [fluoType setStringValue:@"Live"];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                string fluorescentColorIFNoTemp1 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+7];
                string fluorescentColorIFNoTemp2 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+8];
                string fluorescentColorIFNoTemp3 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+9];
                string fluorescentColorIFNoTemp4 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+10];
                string fluorescentColorIFNoTemp5 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+11];
                string fluorescentColorIFNoTemp6 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+12];
                string fluorescentColorIFNameTemp1 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+1];
                string fluorescentColorIFNameTemp2 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+2];
                string fluorescentColorIFNameTemp3 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+3];
                string fluorescentColorIFNameTemp4 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+4];
                string fluorescentColorIFNameTemp5 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+5];
                string fluorescentColorIFNameTemp6 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+6];
                
                if (fluorescentColorIFNoTemp1 == "1"){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
                }
                else if (fluorescentColorIFNoTemp1 == "2"){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
                }
                else if (fluorescentColorIFNoTemp1 == "3"){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
                }
                else if (fluorescentColorIFNoTemp1 == "4"){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
                }
                else if (fluorescentColorIFNoTemp1 == "5"){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
                }
                else if (fluorescentColorIFNoTemp1 == "6"){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
                }
                else if (fluorescentColorIFNoTemp1 == "7"){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
                }
                else if (fluorescentColorIFNoTemp1 == "8"){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
                }
                else if (fluorescentColorIFNoTemp1 == "9"){
                    [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
                }
                else{
                    
                    [channelDisplayCh2 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh2 setStringValue:@"Channel 2:"];
                    [channelDisplay2 setTextColor:[NSColor whiteColor]];
                    [channelDisplay2 setStringValue:@"nil"];
                }
                
                if (fluorescentColorIFNoTemp2 == "1"){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
                }
                else if (fluorescentColorIFNoTemp2 == "2"){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
                }
                else if (fluorescentColorIFNoTemp2 == "3"){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
                }
                else if (fluorescentColorIFNoTemp2 == "4"){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
                }
                else if (fluorescentColorIFNoTemp2 == "5"){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
                }
                else if (fluorescentColorIFNoTemp2 == "6"){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
                }
                else if (fluorescentColorIFNoTemp2 == "7"){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
                }
                else if (fluorescentColorIFNoTemp2 == "8"){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
                }
                else if (fluorescentColorIFNoTemp2 == "9"){
                    [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
                }
                else{
                    
                    [channelDisplayCh3 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh3 setStringValue:@"Channel 3:"];
                    [channelDisplay3 setTextColor:[NSColor whiteColor]];
                    [channelDisplay3 setStringValue:@"nil"];
                }
                
                if (fluorescentColorIFNoTemp3 == "1"){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
                }
                else if (fluorescentColorIFNoTemp3 == "2"){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
                }
                else if (fluorescentColorIFNoTemp3 == "3"){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
                }
                else if (fluorescentColorIFNoTemp3 == "4"){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
                }
                else if (fluorescentColorIFNoTemp3 == "5"){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
                }
                else if (fluorescentColorIFNoTemp3 == "6"){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
                }
                else if (fluorescentColorIFNoTemp3 == "7"){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
                }
                else if (fluorescentColorIFNoTemp3 == "8"){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
                }
                else if (fluorescentColorIFNoTemp3 == "9"){
                    [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
                }
                else{
                    
                    [channelDisplayCh4 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh4 setStringValue:@"Channel 4:"];
                    [channelDisplay4 setTextColor:[NSColor whiteColor]];
                    [channelDisplay4 setStringValue:@"nil"];
                }
                
                if (fluorescentColorIFNoTemp4 == "1"){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
                }
                else if (fluorescentColorIFNoTemp4 == "2"){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
                }
                else if (fluorescentColorIFNoTemp4 == "3"){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
                }
                else if (fluorescentColorIFNoTemp4 == "4"){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
                }
                else if (fluorescentColorIFNoTemp4 == "5"){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
                }
                else if (fluorescentColorIFNoTemp4 == "6"){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
                }
                else if (fluorescentColorIFNoTemp4 == "7"){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
                }
                else if (fluorescentColorIFNoTemp4 == "8"){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
                }
                else if (fluorescentColorIFNoTemp4 == "9"){
                    [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
                }
                else{
                    
                    [channelDisplayCh5 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh5 setStringValue:@"Channel 5:"];
                    [channelDisplay5 setTextColor:[NSColor whiteColor]];
                    [channelDisplay5 setStringValue:@"nil"];
                }
                
                if (fluorescentColorIFNoTemp5 == "1"){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
                }
                else if (fluorescentColorIFNoTemp5 == "2"){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
                }
                else if (fluorescentColorIFNoTemp5 == "3"){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
                }
                else if (fluorescentColorIFNoTemp5 == "4"){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
                }
                else if (fluorescentColorIFNoTemp5 == "5"){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
                }
                else if (fluorescentColorIFNoTemp5 == "6"){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
                }
                else if (fluorescentColorIFNoTemp5 == "7"){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
                }
                else if (fluorescentColorIFNoTemp5 == "8"){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
                }
                else if (fluorescentColorIFNoTemp5 == "9"){
                    [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
                }
                else{
                    
                    [channelDisplayCh6 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh6 setStringValue:@"Channel 6:"];
                    [channelDisplay6 setTextColor:[NSColor whiteColor]];
                    [channelDisplay6 setStringValue:@"nil"];
                }
                
                if (fluorescentColorIFNoTemp6 == "1"){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
                }
                else if (fluorescentColorIFNoTemp6 == "2"){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
                }
                else if (fluorescentColorIFNoTemp6 == "3"){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
                }
                else if (fluorescentColorIFNoTemp6 == "4"){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
                }
                else if (fluorescentColorIFNoTemp6 == "5"){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
                }
                else if (fluorescentColorIFNoTemp6 == "6"){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
                }
                else if (fluorescentColorIFNoTemp6 == "7"){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
                }
                else if (fluorescentColorIFNoTemp6 == "8"){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
                }
                else if (fluorescentColorIFNoTemp6 == "9"){
                    [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                    [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
                }
                else{
                    
                    [channelDisplayCh7 setTextColor:[NSColor whiteColor]];
                    [channelDisplayCh7 setStringValue:@"Channel 7:"];
                    [channelDisplay7 setTextColor:[NSColor whiteColor]];
                    [channelDisplay7 setStringValue:@"nil"];
                }
                
                string extension = to_string(fluorescentDisplayCount);
                string displayIFNo = "IF-"+extension;
                
                [fluoType setStringValue:@(displayIFNo.c_str())];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        
        if (fluoColorCountTemp == 0 && fluorescentDisplayMax != 0){
            fluorescentDisplayCount++;
            
            if (fluorescentDisplayCount > fluorescentDisplayMax) fluorescentDisplayCount = 1;
            
            string fluorescentColorIFNoTemp1 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+7];
            string fluorescentColorIFNoTemp2 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+8];
            string fluorescentColorIFNoTemp3 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+9];
            string fluorescentColorIFNoTemp4 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+10];
            string fluorescentColorIFNoTemp5 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+11];
            string fluorescentColorIFNoTemp6 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+12];
            string fluorescentColorIFNameTemp1 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+1];
            string fluorescentColorIFNameTemp2 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+2];
            string fluorescentColorIFNameTemp3 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+3];
            string fluorescentColorIFNameTemp4 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+4];
            string fluorescentColorIFNameTemp5 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+5];
            string fluorescentColorIFNameTemp6 = arrayIFDataHold [(fluorescentDisplayCount-1)*15+6];
            
            if (fluorescentColorIFNoTemp1 == "1"){
                [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                [channelDisplayCh2 setStringValue:@"Channel 2:"];
                [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
            }
            else if (fluorescentColorIFNoTemp1 == "2"){
                [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                [channelDisplayCh2 setStringValue:@"Channel 2:"];
                [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
            }
            else if (fluorescentColorIFNoTemp1 == "3"){
                [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                [channelDisplayCh2 setStringValue:@"Channel 2:"];
                [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
            }
            else if (fluorescentColorIFNoTemp1 == "4"){
                [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                [channelDisplayCh2 setStringValue:@"Channel 2:"];
                [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
            }
            else if (fluorescentColorIFNoTemp1 == "5"){
                [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                [channelDisplayCh2 setStringValue:@"Channel 2:"];
                [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
            }
            else if (fluorescentColorIFNoTemp1 == "6"){
                [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                [channelDisplayCh2 setStringValue:@"Channel 2:"];
                [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
            }
            else if (fluorescentColorIFNoTemp1 == "7"){
                [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                [channelDisplayCh2 setStringValue:@"Channel 2:"];
                [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
            }
            else if (fluorescentColorIFNoTemp1 == "8"){
                [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                [channelDisplayCh2 setStringValue:@"Channel 2:"];
                [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
            }
            else if (fluorescentColorIFNoTemp1 == "9"){
                [channelDisplayCh2 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                [channelDisplayCh2 setStringValue:@"Channel 2:"];
                [channelDisplay2 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                [channelDisplay2 setStringValue:@(fluorescentColorIFNameTemp1.c_str())];
            }
            else{
                
                [channelDisplayCh2 setTextColor:[NSColor whiteColor]];
                [channelDisplayCh2 setStringValue:@"Channel 2:"];
                [channelDisplay2 setTextColor:[NSColor whiteColor]];
                [channelDisplay2 setStringValue:@"nil"];
            }
            
            if (fluorescentColorIFNoTemp2 == "1"){
                [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                [channelDisplayCh3 setStringValue:@"Channel 3:"];
                [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
            }
            else if (fluorescentColorIFNoTemp2 == "2"){
                [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                [channelDisplayCh3 setStringValue:@"Channel 3:"];
                [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
            }
            else if (fluorescentColorIFNoTemp2 == "3"){
                [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                [channelDisplayCh3 setStringValue:@"Channel 3:"];
                [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
            }
            else if (fluorescentColorIFNoTemp2 == "4"){
                [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                [channelDisplayCh3 setStringValue:@"Channel 3:"];
                [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
            }
            else if (fluorescentColorIFNoTemp2 == "5"){
                [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                [channelDisplayCh3 setStringValue:@"Channel 3:"];
                [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
            }
            else if (fluorescentColorIFNoTemp2 == "6"){
                [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                [channelDisplayCh3 setStringValue:@"Channel 3:"];
                [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
            }
            else if (fluorescentColorIFNoTemp2 == "7"){
                [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                [channelDisplayCh3 setStringValue:@"Channel 3:"];
                [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
            }
            else if (fluorescentColorIFNoTemp2 == "8"){
                [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                [channelDisplayCh3 setStringValue:@"Channel 3:"];
                [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
            }
            else if (fluorescentColorIFNoTemp2 == "9"){
                [channelDisplayCh3 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                [channelDisplayCh3 setStringValue:@"Channel 3:"];
                [channelDisplay3 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                [channelDisplay3 setStringValue:@(fluorescentColorIFNameTemp2.c_str())];
            }
            else{
                
                [channelDisplayCh3 setTextColor:[NSColor whiteColor]];
                [channelDisplayCh3 setStringValue:@"Channel 3:"];
                [channelDisplay3 setTextColor:[NSColor whiteColor]];
                [channelDisplay3 setStringValue:@"nil"];
            }
            
            if (fluorescentColorIFNoTemp3 == "1"){
                [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                [channelDisplayCh4 setStringValue:@"Channel 4:"];
                [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
            }
            else if (fluorescentColorIFNoTemp3 == "2"){
                [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                [channelDisplayCh4 setStringValue:@"Channel 4:"];
                [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
            }
            else if (fluorescentColorIFNoTemp3 == "3"){
                [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                [channelDisplayCh4 setStringValue:@"Channel 4:"];
                [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
            }
            else if (fluorescentColorIFNoTemp3 == "4"){
                [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                [channelDisplayCh4 setStringValue:@"Channel 4:"];
                [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
            }
            else if (fluorescentColorIFNoTemp3 == "5"){
                [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                [channelDisplayCh4 setStringValue:@"Channel 4:"];
                [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
            }
            else if (fluorescentColorIFNoTemp3 == "6"){
                [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                [channelDisplayCh4 setStringValue:@"Channel 4:"];
                [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
            }
            else if (fluorescentColorIFNoTemp3 == "7"){
                [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                [channelDisplayCh4 setStringValue:@"Channel 4:"];
                [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
            }
            else if (fluorescentColorIFNoTemp3 == "8"){
                [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                [channelDisplayCh4 setStringValue:@"Channel 4:"];
                [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
            }
            else if (fluorescentColorIFNoTemp3 == "9"){
                [channelDisplayCh4 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                [channelDisplayCh4 setStringValue:@"Channel 4:"];
                [channelDisplay4 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                [channelDisplay4 setStringValue:@(fluorescentColorIFNameTemp3.c_str())];
            }
            else{
                
                [channelDisplayCh4 setTextColor:[NSColor whiteColor]];
                [channelDisplayCh4 setStringValue:@"Channel 4:"];
                [channelDisplay4 setTextColor:[NSColor whiteColor]];
                [channelDisplay4 setStringValue:@"nil"];
            }
            
            if (fluorescentColorIFNoTemp4 == "1"){
                [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                [channelDisplayCh5 setStringValue:@"Channel 5:"];
                [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
            }
            else if (fluorescentColorIFNoTemp4 == "2"){
                [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                [channelDisplayCh5 setStringValue:@"Channel 5:"];
                [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
            }
            else if (fluorescentColorIFNoTemp4 == "3"){
                [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                [channelDisplayCh5 setStringValue:@"Channel 5:"];
                [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
            }
            else if (fluorescentColorIFNoTemp4 == "4"){
                [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                [channelDisplayCh5 setStringValue:@"Channel 5:"];
                [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
            }
            else if (fluorescentColorIFNoTemp4 == "5"){
                [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                [channelDisplayCh5 setStringValue:@"Channel 5:"];
                [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
            }
            else if (fluorescentColorIFNoTemp4 == "6"){
                [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                [channelDisplayCh5 setStringValue:@"Channel 5:"];
                [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
            }
            else if (fluorescentColorIFNoTemp4 == "7"){
                [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                [channelDisplayCh5 setStringValue:@"Channel 5:"];
                [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
            }
            else if (fluorescentColorIFNoTemp4 == "8"){
                [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                [channelDisplayCh5 setStringValue:@"Channel 5:"];
                [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
            }
            else if (fluorescentColorIFNoTemp4 == "9"){
                [channelDisplayCh5 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                [channelDisplayCh5 setStringValue:@"Channel 5:"];
                [channelDisplay5 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                [channelDisplay5 setStringValue:@(fluorescentColorIFNameTemp4.c_str())];
            }
            else{
                
                [channelDisplayCh5 setTextColor:[NSColor whiteColor]];
                [channelDisplayCh5 setStringValue:@"Channel 5:"];
                [channelDisplay5 setTextColor:[NSColor whiteColor]];
                [channelDisplay5 setStringValue:@"nil"];
            }
            
            if (fluorescentColorIFNoTemp5 == "1"){
                [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                [channelDisplayCh6 setStringValue:@"Channel 6:"];
                [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
            }
            else if (fluorescentColorIFNoTemp5 == "2"){
                [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                [channelDisplayCh6 setStringValue:@"Channel 6:"];
                [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
            }
            else if (fluorescentColorIFNoTemp5 == "3"){
                [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                [channelDisplayCh6 setStringValue:@"Channel 6:"];
                [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
            }
            else if (fluorescentColorIFNoTemp5 == "4"){
                [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                [channelDisplayCh6 setStringValue:@"Channel 6:"];
                [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
            }
            else if (fluorescentColorIFNoTemp5 == "5"){
                [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                [channelDisplayCh6 setStringValue:@"Channel 6:"];
                [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
            }
            else if (fluorescentColorIFNoTemp5 == "6"){
                [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                [channelDisplayCh6 setStringValue:@"Channel 6:"];
                [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
            }
            else if (fluorescentColorIFNoTemp5 == "7"){
                [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                [channelDisplayCh6 setStringValue:@"Channel 6:"];
                [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
            }
            else if (fluorescentColorIFNoTemp5 == "8"){
                [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                [channelDisplayCh6 setStringValue:@"Channel 6:"];
                [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
            }
            else if (fluorescentColorIFNoTemp5 == "9"){
                [channelDisplayCh6 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                [channelDisplayCh6 setStringValue:@"Channel 6:"];
                [channelDisplay6 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                [channelDisplay6 setStringValue:@(fluorescentColorIFNameTemp5.c_str())];
            }
            else{
                
                [channelDisplayCh6 setTextColor:[NSColor whiteColor]];
                [channelDisplayCh6 setStringValue:@"Channel 6:"];
                [channelDisplay6 setTextColor:[NSColor whiteColor]];
                [channelDisplay6 setStringValue:@"nil"];
            }
            
            if (fluorescentColorIFNoTemp6 == "1"){
                [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                [channelDisplayCh7 setStringValue:@"Channel 7:"];
                [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
                [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
            }
            else if (fluorescentColorIFNoTemp6 == "2"){
                [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                [channelDisplayCh7 setStringValue:@"Channel 7:"];
                [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
                [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
            }
            else if (fluorescentColorIFNoTemp6 == "3"){
                [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                [channelDisplayCh7 setStringValue:@"Channel 7:"];
                [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
                [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
            }
            else if (fluorescentColorIFNoTemp6 == "4"){
                [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                [channelDisplayCh7 setStringValue:@"Channel 7:"];
                [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
                [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
            }
            else if (fluorescentColorIFNoTemp6 == "5"){
                [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                [channelDisplayCh7 setStringValue:@"Channel 7:"];
                [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
                [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
            }
            else if (fluorescentColorIFNoTemp6 == "6"){
                [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                [channelDisplayCh7 setStringValue:@"Channel 7:"];
                [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
                [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
            }
            else if (fluorescentColorIFNoTemp6 == "7"){
                [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                [channelDisplayCh7 setStringValue:@"Channel 7:"];
                [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
                [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
            }
            else if (fluorescentColorIFNoTemp6 == "8"){
                [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                [channelDisplayCh7 setStringValue:@"Channel 7:"];
                [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
                [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
            }
            else if (fluorescentColorIFNoTemp6 == "9"){
                [channelDisplayCh7 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                [channelDisplayCh7 setStringValue:@"Channel 7:"];
                [channelDisplay7 setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
                [channelDisplay7 setStringValue:@(fluorescentColorIFNameTemp6.c_str())];
            }
            else{
                
                [channelDisplayCh7 setTextColor:[NSColor whiteColor]];
                [channelDisplayCh7 setStringValue:@"Channel 7:"];
                [channelDisplay7 setTextColor:[NSColor whiteColor]];
                [channelDisplay7 setStringValue:@"nil"];
            }
            
            string extension = to_string(fluorescentDisplayCount);
            string displayIFNo = "IF-"+extension;
            
            [fluoType setStringValue:@(displayIFNo.c_str())];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Save/Load In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)closeWindow:(id)sender{
    [imageList orderOut:self];
    initialSetOperation = 2;
    listTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (initialSetOperation == 3){
        [imageList makeKeyAndOrderFront:self];
        initialSetOperation = 1;
        [listTimer invalidate];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToImageList object:nil];
}

@end
