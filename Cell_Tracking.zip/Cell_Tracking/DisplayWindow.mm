//
// DisplayWindow.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 11/08/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "DisplayWindow.h"

NSString *notificationToNavigationWindow = @"notificationExecuteNavigationWindow";

@implementation DisplayWindow

- (id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    
    if (self != nil){
        displayImage = [[NSImage alloc] initWithContentsOfFile:@""];
        
        mouseDragFlag = 0;
        previousValue = 0;
        previousImageNumber = -1;
        
        silhouetteSwitchStatus= 0;
        connectDisplayStatus = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToNavigationWindow object:nil];
    }
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    int dataLoadingCheck = 0;
    
    if (timeOneStatus == 0){
        if (synchroOn == 1){
            if (imageNumberTrackForDisplay > timeEndHold) imageNumberDisplayForDisplay = timeEndHold;
            else imageNumberDisplayForDisplay = imageNumberTrackForDisplay;
            
            xPositionDisplay = xPositionTrack;
            yPositionDisplay = yPositionTrack;
            
            int processType = 5;
            trackingSet = [[TrackingSet alloc] init];
            dataLoadingCheck = [trackingSet trackingSetMain:processType];
            
            if (dataLoadingCheck == 0) synchroOn = 0;
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Data Read Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if (dataLoadingCheck == 0){
            if (verificationPositionCall == 1){
                if (imageNumberTrackForDisplay > timeEndHold) imageNumberDisplayForDisplay = timeEndHold;
                else imageNumberDisplayForDisplay = imageNumberTrackForDisplay;
                
                xPositionDisplay = xPositionVer-imageWidthDisplay/2;
                yPositionDisplay = (imageHeightDisplay-yPositionVer)-imageHeightDisplay/2;
                magnificationDisplay = (int)(200/((double)(50/(double)imageWidthDisplay)*500)*10);
                
                int processType = 5;
                trackingSet = [[TrackingSet alloc] init];
                dataLoadingCheck = [trackingSet trackingSetMain:processType];
                
                if (dataLoadingCheck == 1){
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Data Read Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            
            if (dataLoadingCheck == 0){
                string extensionString2;
                
                if (imageNumberDisplayForDisplay == 0 && displayJump == 0 && imageNumber <= timeEndHold) extensionString2 = to_string(imageNumber);
                else if (imageNumberDisplayForDisplay == 0 && displayJump == 0 && imageNumber > timeEndHold) extensionString2 = to_string(timeEndHold);
                else if (imageNumberTrackForDisplay <= timeEndHold) extensionString2 = to_string(imageNumberDisplayForDisplay);
                else extensionString2 = to_string(timeEndHold);
                
                if ((imageNumberDisplayForDisplay == 0 && previousImageNumber != imageNumber) || previousImageNumber == imageNumberDisplayForDisplay || previousImageNumber != imageNumberDisplayForDisplay || (treatmentNameHold != "" && treatmentNameKeep != treatmentNameHold)){
                    if (imageNumberDisplayForDisplay == 0){
                        if (imageNumber <= timeEndHold) previousImageNumber = imageNumber;
                        else previousImageNumber = timeEndHold;
                    }
                    else previousImageNumber = imageNumberDisplayForDisplay;
                    
                    if (treatmentNameKeep != treatmentNameHold) imageReadTimingNavigation = 1;
                    
                    if (extensionString2.length() == 1) extensionString2 = "000"+extensionString2;
                    else if (extensionString2.length() == 2) extensionString2 = "00"+extensionString2;
                    else if (extensionString2.length() == 3) extensionString2 = "0"+extensionString2;
                    
                    if (silhouetteSwitchStatus == 1){
                        displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+exType;
                        
                        ifstream fin;
                        
                        int totalSize = imageDimension*imageDimension*4;
                        int readDataTemp = 0;
                        
                        uint8_t *uploadTemp = new uint8_t [totalSize+1];
                        fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            if (exType == ".tif" || exTypeIF == ".TIF"){
                                fin.read((char*)uploadTemp, totalSize+1);
                                fin.close();
                                
                                int dataConversion [4];
                                int endianType = 0;
                                int value0 = 0;
                                int value1 = 0;
                                int value2 = 0;
                                
                                unsigned long headPosition = 0;
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                if (tifImageColorGray == 0){
                                    NSBitmapImageRep *bitmapReps;
                                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                                    
                                    unsigned char *bitmapData = [bitmapReps bitmapData];
                                    
                                    for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                        readDataTemp = uploadTemp [counter1];
                                        
                                        if (readDataTemp == 100) *bitmapData++ = 0;
                                        else if (readDataTemp < cutDisplayValueHold) *bitmapData++ = 0;
                                        else *bitmapData++ = 150;
                                    }
                                    
                                    displayImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                    [displayImage addRepresentation:bitmapReps];
                                    
                                }
                                else if (tifImageColorGray == 1){
                                    NSBitmapImageRep *bitmapReps = nil;
                                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                                    
                                    unsigned char *bitmapData = [bitmapReps bitmapData];
                                    
                                    for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                        value0 = uploadTemp [counter1];
                                        value1 = uploadTemp [counter1+1];
                                        value2 = uploadTemp [counter1+2];
                                        
                                        *bitmapData++ = (unsigned char)value0;
                                        *bitmapData++ = (unsigned char)value1;
                                        *bitmapData++ = (unsigned char)value2;
                                        *bitmapData++ = 0;
                                    }
                                    
                                    displayImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                    [displayImage addRepresentation:bitmapReps];
                                }
                            }
                            else if (exType == ".bmp" || exTypeIF == ".BMP"){
                                fin.read((char*)uploadTemp, totalSize+1);
                                fin.close();
                                
                                NSBitmapImageRep *bitmapReps;
                                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                                
                                unsigned char *bitmapData = [bitmapReps bitmapData];
                                
                                fin.read((char*)uploadTemp, totalSize+1);
                                fin.close();
                                
                                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                        readDataTemp = uploadTemp [1078+counter1*imageDimension+counter2];
                                        
                                        if (readDataTemp == 100) *bitmapData++ = 0;
                                        else if (readDataTemp < cutDisplayValueHold) *bitmapData++ = 0;
                                        else *bitmapData++ = 150;
                                    }
                                }
                                
                                displayImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                [displayImage addRepresentation:bitmapReps];
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                    else if (connectDisplayStatus == 1){
                        extensionString2 = to_string(imageNumberDisplayForDisplay);
                        
                        if (extensionString2.length() == 1) extensionString2 = "000"+extensionString2;
                        else if (extensionString2.length() == 2) extensionString2 = "00"+extensionString2;
                        else if (extensionString2.length() == 3) extensionString2 = "0"+extensionString2;
                        
                        string revisedMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extensionString2+"_"+analysisID+"_"+treatmentNameHold+"_RevisedMap";
                        
                        int imageSize = 0;
                        
                        for (int counter2 = 0; counter2 < imageSizeListCount/2; counter2++){
                            if (arrayImageSizeList [counter2*2] == treatmentNameHold){
                                imageSize = atoi(arrayImageSizeList [counter2*2+1].c_str());
                                break;
                            }
                        }
                        
                        int **revisedMapVer = new int *[imageSize+1];
                        for (int counter2 = 0; counter2 < imageSize+1; counter2++) revisedMapVer [counter2] = new int [imageSize+1];
                        
                        for (int counter3 = 0; counter3 < imageSize; counter3++){
                            for (int counter4 = 0; counter4 < imageSize; counter4++){
                                revisedMapVer [counter3][counter4] = 0;
                            }
                        }
                        
                        int totalSize = imageSize*imageSize*4;
                        
                        ifstream fin;
                        
                        fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            uint8_t *upload2 = new uint8_t [totalSize+50];
                            fin.read((char*)upload2, totalSize+1);
                            fin.close();
                            
                            int yDimensionCount = 0;
                            int xDimensionCount = 0;
                            int pixData = 0;
                            int readBit [4];
                            
                            for (int counter3 = 0; counter3 < totalSize; counter3 = counter3+4){
                                readBit [0] = upload2[counter3];
                                readBit [1] = upload2[counter3+1];
                                readBit [2] = upload2[counter3+2];
                                readBit [3] = upload2[counter3+3];
                                
                                pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                                
                                for (int counter4 = 0; counter4 < readBit [3]; counter4++){
                                    revisedMapVer [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                                }
                                
                                if (xDimensionCount == imageSize){
                                    xDimensionCount = 0;
                                    yDimensionCount++;
                                    
                                    if (yDimensionCount == imageSize){
                                        break;
                                    }
                                }
                            }
                            
                            delete [] upload2;
                            
                            NSBitmapImageRep *bitmapRepsCR;
                            bitmapRepsCR = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                            
                            unsigned char *bitmapDataCR = [bitmapRepsCR bitmapData];
                            
                            if (connectVer == 0){
                                for (int counterY = 0; counterY < imageDimension; counterY++){
                                    for (int counterX = 0; counterX < imageDimension; counterX++){
                                        if (revisedMapVer [counterY][counterX] == 0) *bitmapDataCR++ = 0;
                                        else if (revisedMapVer [counterY][counterX]%9 == 0) *bitmapDataCR++ = 25;
                                        else if (revisedMapVer [counterY][counterX]%9 == 1) *bitmapDataCR++ = 50;
                                        else if (revisedMapVer [counterY][counterX]%9 == 2) *bitmapDataCR++ = 75;
                                        else if (revisedMapVer [counterY][counterX]%9 == 3) *bitmapDataCR++ = 100;
                                        else if (revisedMapVer [counterY][counterX]%9 == 4) *bitmapDataCR++ = 125;
                                        else if (revisedMapVer [counterY][counterX]%9 == 5) *bitmapDataCR++ = 150;
                                        else if (revisedMapVer [counterY][counterX]%9 == 6) *bitmapDataCR++ = 175;
                                        else if (revisedMapVer [counterY][counterX]%9 == 7) *bitmapDataCR++ = 200;
                                        else if (revisedMapVer [counterY][counterX]%9 == 8) *bitmapDataCR++ = 225;
                                    }
                                }
                            }
                            else{
                                
                                for (int counterY = 0; counterY < imageDimension; counterY++){
                                    for (int counterX = 0; counterX < imageDimension; counterX++){
                                        if (revisedMapVer [counterY][counterX] == connectVer) *bitmapDataCR++ = 150;
                                        else *bitmapDataCR++ = 0;
                                    }
                                }
                            }
                            
                            displayImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [displayImage addRepresentation:bitmapRepsCR];
                        }
                        
                        for (int counter1 = 0; counter1 < imageSize+1; counter1++){
                            delete [] revisedMapVer [counter1];
                        }
                        
                        delete [] revisedMapVer;
                    }
                    else{
                        
                        displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+exType;
                        
                        ifstream fin;
                        
                        int totalSize = imageDimension*imageDimension*4;
                        
                        uint8_t *uploadTemp = new uint8_t [totalSize+1];
                        fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            if (exType == ".tif" || exTypeIF == ".TIF"){
                                fin.read((char*)uploadTemp, totalSize+1);
                                fin.close();
                                
                                int dataConversion [4];
                                int endianType = 0;
                                int value0 = 0;
                                int value1 = 0;
                                int value2 = 0;
                                
                                unsigned long headPosition = 0;
                                
                                dataConversion [0] = uploadTemp [0];
                                dataConversion [1] = uploadTemp [1];
                                
                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                else endianType = 0;
                                
                                headPosition = 0;
                                
                                if (endianType == 1){
                                    dataConversion [0] = uploadTemp [7];
                                    dataConversion [1] = uploadTemp [6];
                                    dataConversion [2] = uploadTemp [5];
                                    dataConversion [3] = uploadTemp [4];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                else if (endianType == 0){
                                    dataConversion [0] = uploadTemp [4];
                                    dataConversion [1] = uploadTemp [5];
                                    dataConversion [2] = uploadTemp [6];
                                    dataConversion [3] = uploadTemp [7];
                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                }
                                
                                if (tifImageColorGray == 0){
                                    NSBitmapImageRep *bitmapReps;
                                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                                    
                                    unsigned char *bitmapData = [bitmapReps bitmapData];
                                    
                                    for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                        *bitmapData++ = uploadTemp [counter1];
                                    }
                                    
                                    displayImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                    [displayImage addRepresentation:bitmapReps];
                                }
                                else if (tifImageColorGray == 1){
                                    NSBitmapImageRep *bitmapReps = nil;
                                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                                    
                                    unsigned char *bitmapData = [bitmapReps bitmapData];
                                    
                                    for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                        value0 = uploadTemp [counter1];
                                        value1 = uploadTemp [counter1+1];
                                        value2 = uploadTemp [counter1+2];
                                        
                                        *bitmapData++ = (unsigned char)value0;
                                        *bitmapData++ = (unsigned char)value1;
                                        *bitmapData++ = (unsigned char)value2;
                                        *bitmapData++ = 0;
                                    }
                                    
                                    displayImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                    [displayImage addRepresentation:bitmapReps];
                                }
                            }
                            else if (exType == ".bmp" || exTypeIF == ".BMP"){
                                fin.read((char*)uploadTemp, totalSize+1);
                                fin.close();
                                
                                NSBitmapImageRep *bitmapReps;
                                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                                
                                unsigned char *bitmapData = [bitmapReps bitmapData];
                                
                                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                        *bitmapData++ = uploadTemp [1078+counter1*imageDimension+counter2];
                                    }
                                }
                                
                                displayImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                [displayImage addRepresentation:bitmapReps];
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                }
            }
        }
    }
    else{
        
        if (previousImageNumber != timeOneHold) previousImageNumber = timeOneHold;
        
        string extensionString2 = to_string(timeOneHold);
        
        if (extensionString2.length() == 1) extensionString2 = "000"+extensionString2;
        else if (extensionString2.length() == 2) extensionString2 = "00"+extensionString2;
        else if (extensionString2.length() == 3) extensionString2 = "0"+extensionString2;
        
        displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+exType;
        
        ifstream fin;
        
        int totalSize = imageDimension*imageDimension*4;
        
        uint8_t *uploadTemp = new uint8_t [totalSize+1];
        fin.open(displayImagePath.c_str(), ios::in | ios::binary);
        
        if (fin.is_open()){
            int readDataTemp = 0;
            
            if (exType == ".tif" || exTypeIF == ".TIF"){
                fin.read((char*)uploadTemp, totalSize+1);
                fin.close();
                
                int dataConversion [4];
                int endianType = 0;
                int value0 = 0;
                int value1 = 0;
                int value2 = 0;
                
                unsigned long headPosition = 0;
                
                dataConversion [0] = uploadTemp [0];
                dataConversion [1] = uploadTemp [1];
                
                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                else endianType = 0;
                
                headPosition = 0;
                
                if (endianType == 1){
                    dataConversion [0] = uploadTemp [7];
                    dataConversion [1] = uploadTemp [6];
                    dataConversion [2] = uploadTemp [5];
                    dataConversion [3] = uploadTemp [4];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                else if (endianType == 0){
                    dataConversion [0] = uploadTemp [4];
                    dataConversion [1] = uploadTemp [5];
                    dataConversion [2] = uploadTemp [6];
                    dataConversion [3] = uploadTemp [7];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                
                if (tifImageColorGray == 0){
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                    
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                        readDataTemp = uploadTemp [counter1];
                        
                        if (readDataTemp == 100) *bitmapData++ = 0;
                        else if (readDataTemp < cutDisplayValueHold) *bitmapData++ = 0;
                        else *bitmapData++ = 150;
                    }
                    
                    displayImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                    [displayImage addRepresentation:bitmapReps];
                }
                else if (tifImageColorGray == 1){
                    NSBitmapImageRep *bitmapReps = nil;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                    
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                        value0 = uploadTemp [counter1];
                        value1 = uploadTemp [counter1+1];
                        value2 = uploadTemp [counter1+2];
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value1;
                        *bitmapData++ = (unsigned char)value2;
                        *bitmapData++ = 0;
                    }
                    
                    displayImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                    [displayImage addRepresentation:bitmapReps];
                }
            }
            else if (exType == ".bmp" || exTypeIF == ".BMP"){
                fin.read((char*)uploadTemp, totalSize+1);
                fin.close();
                
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                fin.read((char*)uploadTemp, totalSize+1);
                fin.close();
                
                for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                    for (int counter2 = 0; counter2 < imageDimension; counter2++){
                        readDataTemp = uploadTemp [1078+counter1*imageDimension+counter2];
                        
                        if (readDataTemp == 100) *bitmapData++ = 0;
                        else if (readDataTemp < cutDisplayValueHold) *bitmapData++ = 0;
                        else *bitmapData++ = 150;
                    }
                }
                
                displayImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                [displayImage addRepresentation:bitmapReps];
            }
            
            imageNumberDisplayForDisplay = timeOneHold;
        }
        
        delete [] uploadTemp;
        
        if (synchroOn == 1){
            xPositionDisplay = xPositionTrack;
            yPositionDisplay = yPositionTrack;
            synchroOn = 0;
        }
    }
    
    if (dataLoadingCheck == 0){
        if (imageNumberDisplayForDisplay == 0){
            if (imageNumber <= timeEndHold) imageNumberDisplayForDisplay = imageNumber;
            else imageNumberDisplayForDisplay = timeEndHold;
            
            xPositionDisplay = 0;
            yPositionDisplay = 0;
            xPositionAdjustDisplay = 0;
            yPositionAdjustDisplay = 0;
            magnificationDisplay = 10;
        }
        
        imageWidthDisplay = (int)([displayImage size].width);
        imageHeightDisplay = (int)([displayImage size].height);
        
        //-----Window size and Position re-adjust-----
        int vertical = 500+78;
        int horizontal = 500;
        
        windowWidthDisplay = imageWidthDisplay/(double)horizontal;
        windowHeightDisplay = imageHeightDisplay/(double)(vertical-78);
        
        if (displayWindowCall == 2) displayWindowCall = 3;
        if (lineSetWindowCallDisplay == 1) lineSetWindowCallDisplay = 2;
        
        if (timeOneStatus == 0 && lineSetWindowCallDisplay == 0 && trackingOn == 1 && (cellLineageNoHold != "" || cellNoHold != "") && verificationPositionCall == 0){
            xPositionDisplay = xCellPosition-imageWidthDisplay/2;
            yPositionDisplay = (imageHeightDisplay-yCellPosition)-imageHeightDisplay/2;
        }
        
        xPositionAdjustDisplay = (imageWidthDisplay-imageWidthDisplay/(double)(magnificationDisplay*0.1))/(double)2;
        yPositionAdjustDisplay = (imageHeightDisplay-imageHeightDisplay/(double)(magnificationDisplay*0.1))/(double)2;
        
        [self setNeedsDisplay:YES];
    }
}

-(void)mouseDown:(NSEvent *)event{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDownDisplay = clickPoint.x;
        yPointDownDisplay = clickPoint.y;
        [self setNeedsDisplay:YES];
    }
}

-(void)mouseUp:(NSEvent *)event{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        xPositionDisplay = xPositionDisplay+xPositionMoveDisplay;
        yPositionDisplay = yPositionDisplay+yPositionMoveDisplay;
        xPositionMoveDisplay = 0;
        yPositionMoveDisplay = 0;
        mouseDragFlag = 0;
        [self setNeedsDisplay:YES];
    }
}

- (void)mouseDragged:(NSEvent *)event{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDragDisplay = clickPoint.x;
        yPointDragDisplay = clickPoint.y;
        xPositionMoveDisplay = (xPointDownDisplay-xPointDragDisplay)*windowWidthDisplay/(double)(magnificationDisplay*0.1);
        yPositionMoveDisplay = (yPointDownDisplay-yPointDragDisplay)*windowHeightDisplay/(double)(magnificationDisplay*0.1);
        mouseDragFlag = 1;
        [self setNeedsDisplay:YES];
    }
}

-(void)keyDown:(NSEvent *)event{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        int keyCode = [event keyCode];
        int proceedFlag = 0;
        
        //-----Original size-----
        if (keyCode == 6){
            proceedFlag = 1;
            xPositionDisplay = 0;
            yPositionDisplay = 0;
            xPositionAdjustDisplay = 0;
            yPositionAdjustDisplay = 0;
            magnificationDisplay = 10;
        }
        
        //-----Magnification Magnify-----
        if (keyCode == 125){
            if (magnificationDisplay >= 12 && magnificationDisplay <= 500){
                proceedFlag = 1;
                
                if (magnificationDisplay-10 < 12) magnificationDisplay = 10;
                else magnificationDisplay = magnificationDisplay-10;
                
                xPositionAdjustDisplay = -1*(imageWidthDisplay/(double)(magnificationDisplay*0.1)-imageWidthDisplay)/(double)2;
                yPositionAdjustDisplay = -1*(imageHeightDisplay/(double)(magnificationDisplay*0.1)-imageHeightDisplay)/(double)2;
            }
        }
        
        //-----Magnification Reduction-----
        if (keyCode == 126){
            if (magnificationDisplay >= 10 && magnificationDisplay <= 498){
                proceedFlag = 1;
                
                if (magnificationDisplay+10 > 498) magnificationDisplay = 498;
                else magnificationDisplay = magnificationDisplay+10;
                
                xPositionAdjustDisplay = (imageWidthDisplay-imageWidthDisplay/(double)(magnificationDisplay*0.1))/(double)2;
                yPositionAdjustDisplay = (imageHeightDisplay-imageHeightDisplay/(double)(magnificationDisplay*0.1))/(double)2;
            }
        }
        
        //-----Magnification space bar-----
        if (keyCode == 49){
            proceedFlag = 1;
            magnificationDisplay = (int)(200/((double)(50/(double)imageWidthDisplay)*(double)500)*(double)10);
            xPositionAdjustDisplay = (imageWidthDisplay-imageWidthDisplay/(double)(magnificationDisplay*0.1))/(double)2;
            yPositionAdjustDisplay = (imageHeightDisplay-imageHeightDisplay/(double)(magnificationDisplay*0.1))/(double)2;
        }
        
        //-----Jump TimeOne "J"-----
        if (keyCode == 38) imageNumberDisplayForDisplay = timeOneHold;
        
        //-----Jump TimeEnd "L"-----
        if (keyCode == 37) imageNumberDisplayForDisplay = timeEndHold;
        
        //-----Image Back-----
        if (keyCode == 123){
            if (imageNumberDisplayForDisplay > 1 & imageNumberDisplayForDisplay <= timeEndHold){
                if (imageNumberDisplayForDisplay-1 < 1) imageNumberDisplayForDisplay = 1;
                else imageNumberDisplayForDisplay = imageNumberDisplayForDisplay-1;
                
                inputNumber = imageNumberDisplayForDisplay;
                inputNumberCall = 1;
            }
        }
        
        //-----Image Forward-----
        if (keyCode == 124){
            if (imageNumberDisplayForDisplay >= 1 && imageNumberDisplayForDisplay < timeEndHold){
                if (imageNumberDisplayForDisplay+1 > timeEndHold) imageNumberDisplayForDisplay = timeEndHold;
                else imageNumberDisplayForDisplay = imageNumberDisplayForDisplay+1;
                
                inputNumber = imageNumberDisplayForDisplay;
                inputNumberCall = 1;
            }
        }
        
        //-----Silhouette status change (V)-----
        if (keyCode == 9 && timeOneStatus == 0){
            if (silhouetteSwitchStatus == 0){
                silhouetteSwitchStatus = 1;
                connectDisplayStatus = 0;
                connectVer = 0;
            }
            else if (silhouetteSwitchStatus == 1){
                silhouetteSwitchStatus = 0;
                connectDisplayStatus = 0;
                connectVer = 0;
            }
        }
        
        //-----connect show (C)-----
        if (keyCode == 8 && timeOneStatus == 0){
            if (connectDisplayStatus == 0){
                connectDisplayStatus = 1;
                silhouetteSwitchStatus = 0;
            }
            else if (connectDisplayStatus == 1){
                connectDisplayStatus = 0;
                silhouetteSwitchStatus = 0;
                connectVer = 0;
            }
        }
        
        if (keyCode == 123 || keyCode == 124 || keyCode == 38 || keyCode == 37 || keyCode == 9 || keyCode == 49 || keyCode == 126 || keyCode == 8){
            proceedFlag = 1;
            
            if ((timeOneStatus == 0 && silhouetteSwitchStatus == 0 && connectDisplayStatus == 0) || (timeOneStatus == 2 && imageNumberDisplayForDisplay != timeOneHold)){
                string extensionString2 = to_string(imageNumberDisplayForDisplay);
                
                if (extensionString2.length() == 1) extensionString2 = "000"+extensionString2;
                else if (extensionString2.length() == 2) extensionString2 = "00"+extensionString2;
                else if (extensionString2.length() == 3) extensionString2 = "0"+extensionString2;
                
                displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+exType;
                
                ifstream fin;
                
                int totalSize = imageDimension*imageDimension*4;
                
                uint8_t *uploadTemp = new uint8_t [totalSize+1];
                fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    if (exType == ".tif"){
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        int dataConversion [4];
                        int endianType = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        
                        unsigned long headPosition = 0;
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        if (tifImageColorGray == 0){
                            NSBitmapImageRep *bitmapReps;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                *bitmapData++ = uploadTemp [counter1];
                            }
                            
                            displayImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [displayImage addRepresentation:bitmapReps];
                            
                        }
                        else if (tifImageColorGray == 1){
                            NSBitmapImageRep *bitmapReps = nil;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                value0 = uploadTemp [counter1];
                                value1 = uploadTemp [counter1+1];
                                value2 = uploadTemp [counter1+2];
                                
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value1;
                                *bitmapData++ = (unsigned char)value2;
                                *bitmapData++ = 0;
                            }
                            
                            displayImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [displayImage addRepresentation:bitmapReps];
                        }
                    }
                    else if (exType == ".bmp"){
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        NSBitmapImageRep *bitmapReps;
                        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                        
                        unsigned char *bitmapData = [bitmapReps bitmapData];
                        
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                *bitmapData++ = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                        }
                        
                        displayImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                        [displayImage addRepresentation:bitmapReps];
                    }
                }
                
                delete [] uploadTemp;
            }
            else if (silhouetteSwitchStatus == 1){
                string extensionString2 = to_string(imageNumberDisplayForDisplay);
                
                if (extensionString2.length() == 1) extensionString2 = "000"+extensionString2;
                else if (extensionString2.length() == 2) extensionString2 = "00"+extensionString2;
                else if (extensionString2.length() == 3) extensionString2 = "0"+extensionString2;
                
                displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+exType;
                
                ifstream fin;
                
                int totalSize = imageDimension*imageDimension*4;
                int readDataTemp = 0;
                
                uint8_t *uploadTemp = new uint8_t [totalSize+1];
                fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    if (exType == ".tif"){
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        int dataConversion [4];
                        int endianType = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        
                        unsigned long headPosition = 0;
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        if (tifImageColorGray == 0){
                            NSBitmapImageRep *bitmapReps;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                readDataTemp = uploadTemp [counter1];
                                
                                if (readDataTemp == 100) *bitmapData++ = 0;
                                else if (readDataTemp < cutDisplayValueHold) *bitmapData++ = 0;
                                else *bitmapData++ = 150;
                            }
                            
                            displayImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [displayImage addRepresentation:bitmapReps];
                        }
                        else if (tifImageColorGray == 1){
                            NSBitmapImageRep *bitmapReps = nil;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                value0 = uploadTemp [counter1];
                                value1 = uploadTemp [counter1+1];
                                value2 = uploadTemp [counter1+2];
                                
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value1;
                                *bitmapData++ = (unsigned char)value2;
                                *bitmapData++ = 0;
                            }
                            
                            displayImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [displayImage addRepresentation:bitmapReps];
                        }
                    }
                    else if (exType == ".bmp"){
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        NSBitmapImageRep *bitmapReps;
                        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                        
                        unsigned char *bitmapData = [bitmapReps bitmapData];
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                readDataTemp = uploadTemp [1078+counter1*imageDimension+counter2];
                                
                                if (readDataTemp == 100) *bitmapData++ = 0;
                                else if (readDataTemp < cutDisplayValueHold) *bitmapData++ = 0;
                                else *bitmapData++ = 150;
                            }
                        }
                        
                        displayImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                        [displayImage addRepresentation:bitmapReps];
                    }
                }
                
                delete [] uploadTemp;
            }
            else if (connectDisplayStatus == 1){
                string extensionString2 = to_string(imageNumberDisplayForDisplay);
                
                if (extensionString2.length() == 1) extensionString2 = "000"+extensionString2;
                else if (extensionString2.length() == 2) extensionString2 = "00"+extensionString2;
                else if (extensionString2.length() == 3) extensionString2 = "0"+extensionString2;
                
                string revisedMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extensionString2+"_"+analysisID+"_"+treatmentNameHold+"_RevisedMap";
                
                int imageSize = 0;
                
                for (int counter2 = 0; counter2 < imageSizeListCount/2; counter2++){
                    if (arrayImageSizeList [counter2*2] == treatmentNameHold){
                        imageSize = atoi(arrayImageSizeList [counter2*2+1].c_str());
                        break;
                    }
                }
                
                int **revisedMapVer = new int *[imageSize+1];
                for (int counter2 = 0; counter2 < imageSize+1; counter2++) revisedMapVer [counter2] = new int [imageSize+1];
                
                for (int counter3 = 0; counter3 < imageSize; counter3++){
                    for (int counter4 = 0; counter4 < imageSize; counter4++){
                        revisedMapVer [counter3][counter4] = 0;
                    }
                }
                
                int totalSize = imageSize*imageSize*4;
                
                ifstream fin;
                
                fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *upload2 = new uint8_t [totalSize+50];
                    fin.read((char*)upload2, totalSize+1);
                    fin.close();
                    
                    int yDimensionCount = 0;
                    int xDimensionCount = 0;
                    int pixData = 0;
                    int readBit [4];
                    
                    for (int counter3 = 0; counter3 < totalSize; counter3 = counter3+4){
                        readBit [0] = upload2[counter3];
                        readBit [1] = upload2[counter3+1];
                        readBit [2] = upload2[counter3+2];
                        readBit [3] = upload2[counter3+3];
                        
                        pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                        
                        for (int counter4 = 0; counter4 < readBit [3]; counter4++){
                            revisedMapVer [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                        }
                        
                        if (xDimensionCount == imageSize){
                            xDimensionCount = 0;
                            yDimensionCount++;
                            
                            if (yDimensionCount == imageSize){
                                break;
                            }
                        }
                    }
                    
                    delete [] upload2;
                    
                    NSBitmapImageRep *bitmapRepsCR;
                    bitmapRepsCR = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                    unsigned char *bitmapDataCR = [bitmapRepsCR bitmapData];
                    
                    if (connectVer == 0){
                        for (int counterY = 0; counterY < imageDimension; counterY++){
                            for (int counterX = 0; counterX < imageDimension; counterX++){
                                if (revisedMapVer [counterY][counterX] == 0) *bitmapDataCR++ = 0;
                                else if (revisedMapVer [counterY][counterX]%9 == 0) *bitmapDataCR++ = 25;
                                else if (revisedMapVer [counterY][counterX]%9 == 1) *bitmapDataCR++ = 50;
                                else if (revisedMapVer [counterY][counterX]%9 == 2) *bitmapDataCR++ = 75;
                                else if (revisedMapVer [counterY][counterX]%9 == 3) *bitmapDataCR++ = 100;
                                else if (revisedMapVer [counterY][counterX]%9 == 4) *bitmapDataCR++ = 125;
                                else if (revisedMapVer [counterY][counterX]%9 == 5) *bitmapDataCR++ = 150;
                                else if (revisedMapVer [counterY][counterX]%9 == 6) *bitmapDataCR++ = 175;
                                else if (revisedMapVer [counterY][counterX]%9 == 7) *bitmapDataCR++ = 200;
                                else if (revisedMapVer [counterY][counterX]%9 == 8) *bitmapDataCR++ = 225;
                            }
                        }
                    }
                    else{
                        
                        for (int counterY = 0; counterY < imageDimension; counterY++){
                            for (int counterX = 0; counterX < imageDimension; counterX++){
                                if (revisedMapVer [counterY][counterX] == connectVer) *bitmapDataCR++ = 150;
                                else *bitmapDataCR++ = 0;
                            }
                        }
                    }
                    
                    displayImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                    [displayImage addRepresentation:bitmapRepsCR];
                }
                
                for (int counter1 = 0; counter1 < imageSize+1; counter1++){
                    delete [] revisedMapVer [counter1];
                }
                
                delete [] revisedMapVer;
            }
            
            int dataLoadingCheck = 0;
            int processType = 5;
            trackingSet = [[TrackingSet alloc] init];
            dataLoadingCheck = [trackingSet trackingSetMain:processType];
            
            if (dataLoadingCheck == 1){
                proceedFlag = 0;
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Data Read Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if (proceedFlag == 1) [self setNeedsDisplay:YES];
    }
}

//-----First Responder-----
-(BOOL)acceptsFirstResponder{
    return YES;
}

- (void)drawRect:(NSRect)rect {
    [[NSColor blackColor] set];
    
    NSBezierPath *path;
    path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 500, 500)];
    [path fill];
    
    NSRect srcRect;
    srcRect.origin.x = xPositionDisplay+xPositionAdjustDisplay+xPositionMoveDisplay;
    srcRect.origin.y = yPositionDisplay+yPositionAdjustDisplay+yPositionMoveDisplay;
    srcRect.size.width = imageWidthDisplay/(double)(magnificationDisplay*0.1);
    srcRect.size.height = imageHeightDisplay/(double)(magnificationDisplay*0.1);
    
    [displayImage drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
    
    if (mouseDragFlag == 0 && imageEndHold != 0){
        double xPositionAdjustDouble = xPositionAdjustDisplay+xPositionDisplay;
        double yPositionAdjustDouble = yPositionAdjustDisplay+yPositionDisplay;
        double xCalculationValue = 1/(double)windowWidthDisplay*magnificationDisplay*0.1;
        double yCalculationValue = 1/(double)windowHeightDisplay*magnificationDisplay*0.1;
        double magnificationDisplay2 = magnificationDisplay*0.1*0.35;
        double magnificationLine = magnificationDisplay*0.1;
        double magnificationFont = magnificationDisplay*0.08*1.5;
        double displayFrequencyTemp = (2-xPositionAdjustDouble)*xCalculationValue-(1-xPositionAdjustDouble)*xCalculationValue;
        int displayFrequency = (int)displayFrequencyTemp;
        
        if (lineTypeSet == 1){
            if (displayFrequencyTemp <= 0.3 && displayFrequencyTemp != 0) displayFrequency = (int)(9/(double)displayFrequencyTemp);
            else if (displayFrequencyTemp <= 0.5 && displayFrequencyTemp > 0.3) displayFrequency = (int)(7/(double)displayFrequencyTemp);
            else if (displayFrequencyTemp <= 1 && displayFrequencyTemp > 0.5) displayFrequency = (int)(5/(double)displayFrequencyTemp);
            else if (displayFrequencyTemp <= 2 && displayFrequencyTemp > 1) displayFrequency = 4;
            else if (displayFrequencyTemp <= 3 && displayFrequencyTemp > 2) displayFrequency = 3;
            else if (displayFrequencyTemp <= 4 && displayFrequencyTemp > 3) displayFrequency = 2;
            else if (displayFrequencyTemp > 4) displayFrequency = 1;
        }
        else{
            
            if (displayFrequencyTemp <= 0.3 && displayFrequencyTemp != 0) displayFrequency = (int)(8/(double)displayFrequencyTemp);
            else if (displayFrequencyTemp <= 0.5 && displayFrequencyTemp > 0.3) displayFrequency = (int)(6/(double)displayFrequencyTemp);
            else if (displayFrequencyTemp <= 1 && displayFrequencyTemp > 0.5) displayFrequency = (int)(4/(double)displayFrequencyTemp);
            else if (displayFrequencyTemp <= 2 && displayFrequencyTemp > 1) displayFrequency = 2;
            else if (displayFrequencyTemp <= 3 && displayFrequencyTemp > 2) displayFrequency = 1;
            else if (displayFrequencyTemp <= 4 && displayFrequencyTemp > 3) displayFrequency = 1;
            else if (displayFrequencyTemp > 4) displayFrequency = 1;
        }
        
        CGFloat sizeCalculation = 512*xCalculationValue;
        sizeCalculation = (sizeCalculation/(double)500)*0.5;
        
        if (sizeCalculation >= 2) sizeCalculation = 2;
        
        int xPointMarkTemp = 0;
        int yPointMarkTemp = 0;
        
        if (timeOneStatus == 0){
            NSBezierPath *path3;
            [NSBezierPath setDefaultLineWidth:sizeCalculation];
            
            NSPoint positionAA;
            NSPoint positionBB;
            NSPoint positionCC;
            NSPoint positionDD;
            
            NSPoint pointA;
            NSAttributedString *attrStrA;
            NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
            [attributesA setObject:[NSFont systemFontOfSize:magnificationFont] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
            NSString *vectorNumberDisplay = @"";
            
            string lineageExtract = "";
            string cellNumberExtract = "";
            int lineageExtractInt = 0;
            int cellNoExtractInt = -1;
            
            if (cellLineageNoHold != ""){
                lineageExtract = cellLineageNoHold.substr(1);
                lineageExtractInt = atoi(lineageExtract.c_str());
            }
            
            if (cellNoHold != ""){
                cellNumberExtract = cellNoHold.substr(1);
                cellNoExtractInt = atoi(cellNumberExtract.c_str());
            }
            
            //for (int counterA = 0; counterA < masterLineSelectedDisplayCount/10; counterA++){
            //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayMasterLineSelectedDisplay [counterA*10+counterB];
            //	cout<<" arrayMasterLineSelectedDisplay "<<counterA<<endl;
            //}
            
            int startPoint = 0;
            int noiseStatusLine = 0;
            int endPoint = 0;
            
            if (characterDisplayNavFlag == 1 || characterDisplayNavFlag == 0){
                for (int counter1 = 0; counter1 < masterLineSelectedDisplayCount/10; counter1++){
                    if (arrayMasterLineSelectedDisplay [counter1*10] == 0 || arrayMasterLineSelectedDisplay [counter1*10] == 1 || arrayMasterLineSelectedDisplay [counter1*10] == 2 || arrayMasterLineSelectedDisplay [counter1*10] == 7){
                        startPoint = arrayMasterLineSelectedDisplay [counter1*10+2];
                        noiseStatusLine = arrayMasterLineSelectedDisplay [counter1*10];
                        
                        if (counter1+1 < masterLineSelectedDisplayCount/10) endPoint = arrayMasterLineSelectedDisplay [(counter1+1)*10+2]-1;
                        else endPoint = masterLineForDisplayCount/7-1;
                        
                        for (int counter2 = startPoint; counter2 <= endPoint; counter2 = counter2+displayFrequency){
                            if (lineageExtract != "" && cellNumberExtract != "" && arrayMasterLineForDisplay [counter2*7+6] == lineageExtractInt && arrayMasterLineForDisplay [counter2*7+4] == cellNoExtractInt){
                                xPointMarkTemp = (int)((arrayMasterLineForDisplay [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                yPointMarkTemp = (int)(((imageHeightTrack-arrayMasterLineForDisplay [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 500 && yPointMarkTemp >= 0 && yPointMarkTemp <= 500){
                                    [[NSColor blueColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                    [path3 fill];
                                }
                            }
                            else if ((arrayMasterLineForDisplay [counter2*7+5] == 0 && noiseStatusLine != 2) || arrayMasterLineForDisplay [counter2*7+5] == 1){
                                xPointMarkTemp = (int)((arrayMasterLineForDisplay [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                yPointMarkTemp = (int)(((imageHeightDisplay-arrayMasterLineForDisplay [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 500 && yPointMarkTemp >= 0 && yPointMarkTemp <= 500){
                                    [[NSColor greenColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                    [path3 fill];
                                }
                            }
                            else if (arrayMasterLineForDisplay [counter2*7+5] == 0 && noiseStatusLine == 2){
                                xPointMarkTemp = (int)((arrayMasterLineForDisplay [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                yPointMarkTemp = (int)(((imageHeightDisplay-arrayMasterLineForDisplay [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 500 && yPointMarkTemp >= 0 && yPointMarkTemp <= 500){
                                    [[NSColor grayColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                    [path3 fill];
                                }
                            }
                        }
                    }
                }
            }
            
            [[NSColor whiteColor] set];
            [attributesA setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
            [attributesA removeObjectForKey:NSBackgroundColorAttributeName];
            [attributesA setObject:[NSFont systemFontOfSize:magnificationFont] forKey:NSFontAttributeName];
            
            if (characterDisplayNavFlag == 1 || characterDisplayNavFlag == 0){
                for (int counter1 = 0; counter1 < masterLineSelectedDisplayCount/10; counter1++){
                    if (arrayMasterLineSelectedDisplay [counter1*10] == 0 || arrayMasterLineSelectedDisplay [counter1*10] == 1 || arrayMasterLineSelectedDisplay [counter1*10] == 2 || arrayMasterLineSelectedDisplay [counter1*10] == 7){
                        if (arrayMasterLineForDisplay [arrayMasterLineSelectedDisplay [counter1*10+2]*7+6] == 0){
                            xPointMarkTemp = (int)((arrayMasterLineGravityCenterDisplay [counter1*6]-xPositionAdjustDouble)*(double)xCalculationValue);
                            yPointMarkTemp = (int)(((imageHeightDisplay-arrayMasterLineGravityCenterDisplay [counter1*6+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                            
                            if (xPointMarkTemp >= 0 && xPointMarkTemp <= 500 && yPointMarkTemp >= 0 && yPointMarkTemp <= 500){
                                positionAA.x = xPointMarkTemp-magnificationLine;
                                positionAA.y = yPointMarkTemp;
                                positionBB.x = xPointMarkTemp+magnificationLine;
                                positionBB.y = yPointMarkTemp;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                
                                positionCC.x = xPointMarkTemp;
                                positionCC.y = yPointMarkTemp-magnificationLine;
                                positionDD.x = xPointMarkTemp;
                                positionDD.y = yPointMarkTemp+magnificationLine;
                                [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                                
                                vectorNumberDisplay = [NSString stringWithFormat:@"%d", arrayMasterLineGravityCenterDisplay [counter1*6+4]];
                                
                                attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                                
                                pointA.x = xPointMarkTemp+magnificationLine*0.3;
                                pointA.y = yPointMarkTemp+magnificationLine*0.3;
                                [attrStrA drawAtPoint:pointA];
                            }
                        }
                    }
                }
            }
            
            string extension = "";
            string extension2 = "";
            
            [attributesA setObject:[NSFont systemFontOfSize:magnificationFont] forKey:NSFontAttributeName];
            
            previousValue = 0;
            
            for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                if (arrayLineageData [counter1*8] != -1){
                    xPointMarkTemp = (int)((arrayLineageData [counter1*8]-xPositionAdjustDouble)*(double)xCalculationValue);
                    yPointMarkTemp = (int)(((imageHeightDisplay-arrayLineageData [counter1*8+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                    
                    if (arrayLineageData [counter1*8+2] == imageNumberDisplayForDisplay){
                        if (arrayLineageData [counter1*8+6] == lineageExtractInt){
                            [[NSColor redColor] set];
                            [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                            previousValue = 0;
                        }
                        
                        if (arrayLineageData [counter1*8+6] != lineageExtractInt){
                            if (previousValue == 0){
                                [[NSColor magentaColor] set], [attributesA setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
                                previousValue = 1;
                            }
                        }
                        
                        if (xPointMarkTemp >= 0 && xPointMarkTemp <= 500 && yPointMarkTemp >= 0 && yPointMarkTemp <= 500){
                            positionAA.x = xPointMarkTemp-magnificationLine;
                            positionAA.y = yPointMarkTemp;
                            positionBB.x = xPointMarkTemp+magnificationLine;
                            positionBB.y = yPointMarkTemp;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            
                            positionCC.x = xPointMarkTemp;
                            positionCC.y = yPointMarkTemp-magnificationLine;
                            positionDD.x = xPointMarkTemp;
                            positionDD.y = yPointMarkTemp+magnificationLine;
                            [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                            
                            extension2 = to_string(arrayLineageData [counter1*8+6]);
                            
                            if (extension2.length() == 1) extension2 = "L0000"+extension2;
                            else if (extension2.length() == 2) extension2 = "L000"+extension2;
                            else if (extension2.length() == 3) extension2 = "L00"+extension2;
                            else if (extension2.length() == 4) extension2 = "L0"+extension2;
                            else if (extension2.length() == 5) extension2 = "L"+extension2;
                            
                            vectorNumberDisplay = @(extension2.c_str());
                            
                            attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                            pointA.x = xPointMarkTemp+magnificationLine*0.3;
                            pointA.y = yPointMarkTemp+magnificationLine*0.3;
                            [attrStrA drawAtPoint:pointA];
                        }
                    }
                }
            }
            
            [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
            [[NSColor whiteColor] set];
            [attributesA setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
            
            for (int counter1 = 0; counter1 < xyPositionListCount/5; counter1++){
                xPointMarkTemp = (int)((arrayXYPositionList [counter1*5+2]-xPositionAdjustDouble)*(double)xCalculationValue);
                yPointMarkTemp = (int)(((imageHeightDisplay-arrayXYPositionList [counter1*5+3])-yPositionAdjustDouble)*(double)yCalculationValue);
                
                if (arrayXYPositionList [counter1*5] == imageNumberDisplayForDisplay && arrayXYPositionList [counter1*5+4] == 1){
                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 500 && yPointMarkTemp >= 0 && yPointMarkTemp <= 500){
                        positionAA.x = xPointMarkTemp-magnificationLine;
                        positionAA.y = yPointMarkTemp;
                        positionBB.x = xPointMarkTemp+magnificationLine;
                        positionBB.y = yPointMarkTemp;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        positionCC.x = xPointMarkTemp;
                        positionCC.y = yPointMarkTemp-magnificationLine;
                        positionDD.x = xPointMarkTemp;
                        positionDD.y = yPointMarkTemp+magnificationLine;
                        [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                        
                        if (cellLineageNoHold != "" && cellNoHold == "") vectorNumberDisplay = @"C000000000";
                        else if (cellLineageNoHold != "" && cellNoHold != "" && (characterDisplayNavFlag == 1 || characterDisplayNavFlag == 0)) vectorNumberDisplay = @(cellNoHold.c_str());
                        else if (cellLineageNoHold != "" && cellNoHold != "" && characterDisplayNavFlag == 2) vectorNumberDisplay = @"TARG";
                        
                        //NSLog (@"%@", vectorNumberDisplay);
                        
                        attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                        pointA.x = xPointMarkTemp+magnificationLine*0.3;
                        pointA.y = yPointMarkTemp+magnificationLine*0.3;
                        [attrStrA drawAtPoint:pointA];
                    }
                }
            }
            
            if (verificationPositionCall == 1){
                xPointMarkTemp = (int)((xPositionVer-xPositionAdjustDouble)*(double)xCalculationValue);
                yPointMarkTemp = (int)(((imageHeightDisplay-yPositionVer)-yPositionAdjustDouble)*(double)yCalculationValue);
                
                [[NSColor blackColor] set];
                positionAA.x = xPointMarkTemp-magnificationLine;
                positionAA.y = yPointMarkTemp;
                positionBB.x = xPointMarkTemp+magnificationLine;
                positionBB.y = yPointMarkTemp;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                positionCC.x = xPointMarkTemp;
                positionCC.y = yPointMarkTemp-magnificationLine;
                positionDD.x = xPointMarkTemp;
                positionDD.y = yPointMarkTemp+magnificationLine;
                [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
            }
            
            //-----Info writing-----
            extension2 = to_string(imageNumberDisplayForDisplay);
            
            [attributesA setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
            [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
            
            string infoDisplayString = "Time: "+extension2;
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
            pointA.x = 10;
            pointA.y = 485;
            [attrStrA drawAtPoint:pointA];
            
            infoDisplayString = "Treatment: "+treatmentNameHold;
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
            pointA.x = 80;
            pointA.y = 485;
            [attrStrA drawAtPoint:pointA];
            
            infoDisplayString = "Lineage: "+cellLineageNoHold;
            
            [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
            attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
            pointA.x = 230;
            pointA.y = 485;
            [attrStrA drawAtPoint:pointA];
            
            if (fluorescentDisplayNo == 0){
                infoDisplayString = "Cut: DIC";
                
                [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 400;
                pointA.y = 485;
                [attrStrA drawAtPoint:pointA];
            }
            else{
                
                infoDisplayString = "Cut: FUL";
                
                [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 400;
                pointA.y = 485;
                [attrStrA drawAtPoint:pointA];
            }
        }
        
        if (timeOneStatus == 2 && imageNumberDisplayForDisplay == timeOneHold){
            NSBezierPath *path3;
            [NSBezierPath setDefaultLineWidth:sizeCalculation];
            
            for (int counter1 = 0; counter1 < positionReviseCount/7; counter1 = counter1+displayFrequency){
                if (arrayPositionRevise [counter1*7+5] == 0){
                    xPointMarkTemp = (int)((arrayPositionRevise [counter1*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter1*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                    
                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 500 && yPointMarkTemp >= 0 && yPointMarkTemp <= 500){
                        [[NSColor yellowColor] set];
                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                        [path3 fill];
                    }
                }
                else if (arrayPositionRevise [counter1*7+5] == 1){
                    xPointMarkTemp = (int)((arrayPositionRevise [counter1*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter1*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                    
                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 500 && yPointMarkTemp >= 0 && yPointMarkTemp <= 500){
                        [[NSColor greenColor] set];
                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                        [path3 fill];
                    }
                }
            }
            
            [[NSColor redColor] set];
            
            for (int counter1 = 0; counter1 < targetHoldCount/3; counter1++){
                xPointMarkTemp = (int)((arrayTargetHold [counter1*3]-xPositionAdjustDouble)*(double)xCalculationValue);
                yPointMarkTemp = (int)(((imageHeightTrack-arrayTargetHold [counter1*3+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                
                if (arrayTargetHoldInfo [(arrayTargetHold [counter1*3+2]-1)*4+2] == 0){
                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                    [path3 fill];
                }
            }
            
            NSPoint positionAA;
            NSPoint positionBB;
            NSPoint positionCC;
            NSPoint positionDD;
            
            NSPoint pointA;
            NSAttributedString *attrStrA;
            NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
            [attributesA setObject:[NSFont systemFontOfSize:magnificationFont] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
            NSString *vectorNumberDisplay;
            
            previousValue = 0;
            int selected = 0;
            
            for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                selected = arrayTimeSelected [counter1*10];
                xPointMarkTemp = (int)((arrayGravityCenterRev [counter1*6]-xPositionAdjustDouble)*(double)xCalculationValue);
                yPointMarkTemp = (int)(((imageHeightTrack-arrayGravityCenterRev [counter1*6+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                
                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 500 && yPointMarkTemp >= 0 && yPointMarkTemp <= 500){
                    if (selected == 0 || selected == 5 || selected == 6){
                        [[NSColor whiteColor] set];
                        [attributesA setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                        previousValue = 0;
                    }
                    else if (selected == 2){
                        [[NSColor cyanColor] set];
                        [attributesA setObject:[NSColor cyanColor] forKey: NSForegroundColorAttributeName];
                        previousValue = 0;
                    }
                    else if (selected == 3 || selected == 4){
                        [[NSColor clearColor] set];
                        [attributesA setObject:[NSColor clearColor] forKey: NSForegroundColorAttributeName];
                        previousValue = 0;
                    }
                    else if (selected == 7){
                        [[NSColor redColor] set];
                        [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                        previousValue = 0;
                    }
                    else if (previousValue == 0){
                        [[NSColor magentaColor] set];
                        [attributesA setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
                        previousValue = 1;
                    }
                    
                    positionAA.x = xPointMarkTemp-magnificationLine;
                    positionAA.y = yPointMarkTemp;
                    positionBB.x = xPointMarkTemp+magnificationLine;
                    positionBB.y = yPointMarkTemp;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    positionCC.x = xPointMarkTemp;
                    positionCC.y = yPointMarkTemp-magnificationLine;
                    positionDD.x = xPointMarkTemp;
                    positionDD.y = yPointMarkTemp+magnificationLine;
                    [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                    
                    vectorNumberDisplay = [NSString stringWithFormat:@"%d", arrayGravityCenterRev [counter1*6+4]];
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                    pointA.x = xPointMarkTemp+magnificationLine*0.3;
                    pointA.y = yPointMarkTemp+magnificationLine*0.3;
                    [attrStrA drawAtPoint:pointA];
                    
                    [attributesA removeObjectForKey:NSBackgroundColorAttributeName];
                }
            }
            
            for (int counter1 = 0; counter1 < targetHoldInfoCount/4; counter1++){
                xPointMarkTemp = (int)((arrayTargetHoldInfo [counter1*4]-xPositionAdjustDouble)*(double)xCalculationValue);
                yPointMarkTemp = (int)(((imageHeightTrack-arrayTargetHoldInfo [counter1*4+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                
                [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
                [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                vectorNumberDisplay = [NSString stringWithFormat:@"%d", arrayTargetHoldInfo [counter1*4+3]];
                
                attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                pointA.x = xPointMarkTemp+magnificationLine*0.3;
                pointA.y = yPointMarkTemp+magnificationLine*0.3;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (timeOneX != 0 && timeOneY != 0){
                xPointMarkTemp = (int)((timeOneX-xPositionAdjustDouble)*(double)xCalculationValue);
                yPointMarkTemp = (int)(((imageHeightTrack-timeOneY)-yPositionAdjustDouble)*(double)yCalculationValue);
                
                [[NSColor redColor] set];
                
                positionAA.x = xPointMarkTemp-magnificationLine;
                positionAA.y = yPointMarkTemp;
                positionBB.x = xPointMarkTemp+magnificationLine;
                positionBB.y = yPointMarkTemp;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                positionCC.x = xPointMarkTemp;
                positionCC.y = yPointMarkTemp-magnificationLine;
                positionDD.x = xPointMarkTemp;
                positionDD.y = yPointMarkTemp+magnificationLine;
                [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                
                NSRect rectangle = NSMakeRect(xPointMarkTemp-magnificationLine*2, yPointMarkTemp-magnificationLine*2, magnificationLine*4, magnificationLine*4);
                NSBezierPath* circlePath = [NSBezierPath bezierPath];
                [circlePath appendBezierPathWithOvalInRect: rectangle];
                [circlePath stroke];
            }
            
            if (lineDraw == 1 || lineDraw == 2){
                [[NSColor redColor] set];
                
                for (int counter1 = 0; counter1 < targetCount/2; counter1++){
                    xPointMarkTemp = (int)((arrayTarget [counter1*2]-xPositionAdjustDouble)*(double)xCalculationValue);
                    yPointMarkTemp = (int)(((imageHeightDisplay-arrayTarget [counter1*2+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                    [path3 fill];
                }
            }
            
            //-----Info writing-----
            string extension2 = to_string(imageNumberDisplayForDisplay);
            
            [attributesA setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
            [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
            
            string infoDisplayString = "Time One";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
            pointA.x = 10;
            pointA.y = 485;
            [attrStrA drawAtPoint:pointA];
            
            infoDisplayString = "Treatment: "+treatmentNameHold;
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
            pointA.x = 80;
            pointA.y = 485;
            [attrStrA drawAtPoint:pointA];
            
            if (fluorescentDisplayNo == 0){
                infoDisplayString = "Cut: DIC";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 400;
                pointA.y = 485;
                [attrStrA drawAtPoint:pointA];
            }
            else{
                
                infoDisplayString = "Cut: FUL";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 400;
                pointA.y = 485;
                [attrStrA drawAtPoint:pointA];
            }
        }
    }
    
    if (imageLoadMonitor > 0) imageLoadMonitor++;
    if (displayJump > 0) displayJump++;
    if (imageReadTimingNavigation >= 1) imageReadTimingNavigation++;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToNavigationWindow object:nil];
}

@end
