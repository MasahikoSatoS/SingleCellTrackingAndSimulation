//
// TrackingWindow.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 11/08/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "TrackingWindow.h"

NSString *notificationToTrackingWindow = @"notificationExecuteTrackingWindow";

@implementation TrackingWindow

- (id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    
    if (self != nil){
        trackingImage = [[NSImage alloc] initWithContentsOfFile:@""];
        
        mouseDragFlag = 0;
        doubleClick = 0;
        xPointLine = 0;
        yPointLine = 0;
        previousValue = 0;
        previousImageNumber = -1;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToTrackingWindow object:nil];
    }
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    string extensionString2;
    
    //cout<<xCellPosition<<" "<<yCellPosition<<" "<<xPositionTrack<<" "<<yPositionTrack<<" "<<imageWidthTrack<<" "<<imageHeightTrack<<" "<<imageNumberTrackForDisplay<<" "<<imageNumber<<" infoA"<<endl;
    
    if (timeOneStatus == 0){
        if (lineModificationFlag == 0 && addDelInsert == 0 && targetLostMark == "" && clearBack == 0 && trackingOn == 1 && listToTrackCall == 0 && cellNoHold == "" && trackJump == 0 && sliderBarSet == 0 && quickLineageCall == 0 && cellJumpFirstLast == 0 && quickConnectCall == 0) extensionString2 = to_string(timeOneHold);
        else if (lineModificationFlag == 0 && addDelInsert == 0 && targetLostMark == "" && clearBack == 0 && trackingOn == 1 && listToTrackCall == 0 && cellNoHold != "C000000000" && trackJump == 0 && quickLineageCall == 0 && cellJumpFirstLast == 0 && quickConnectCall == 0) extensionString2 = to_string(imageNumberTrackForDisplay);
        else if (lineModificationFlag == 1 && addDelInsert == 0 && targetLostMark == "" && clearBack == 0 && listToTrackCall == 0 && quickLineageCall == 0 && cellJumpFirstLast == 0 && quickConnectCall == 0) extensionString2 = to_string(imageNumberTrackForDisplay);
        else if (addDelInsert == 1 && targetLostMark == "" && clearBack == 0 && listToTrackCall == 0 && quickLineageCall == 0 && cellJumpFirstLast == 0 && quickConnectCall == 0) extensionString2 = to_string(imageNumberTrackForDisplay);
        else if ((int)targetLostMark.find("Lost") != -1 && clearBack == 0 && listToTrackCall == 0 && quickLineageCall == 0 && cellJumpFirstLast == 0 && quickConnectCall == 0) extensionString2 = to_string(imageNumberTrackForDisplay);
        else if (clearBack != 0 && listToTrackCall == 0 && sliderBarSet == 0 && quickLineageCall == 0 && cellJumpFirstLast == 0 && quickConnectCall == 0) extensionString2 = to_string(clearBack);
        else if (listToTrackCall == 2) extensionString2 = to_string(imageNumberTrackForDisplay);
        else extensionString2 = to_string(imageNumberTrackForDisplay);
        
        int displayFlag = 0;
        
        if (previousImageNumber != imageNumberTrackForDisplay || (treatmentNameHold != "" && treatmentNameKeep != treatmentNameHold) || (previousImageNumber == imageNumberTrackForDisplay && fluorescentDisplayNo == 0)){
            previousImageNumber = imageNumberTrackForDisplay;
            
            if (treatmentNameKeep != treatmentNameHold) imageReadTiming = 1;
            
            displayFlag = 1;
        }
        else if (previousImageNumber == imageNumberTrackForDisplay && fluorescentDisplayNo != 0) displayFlag = 1;
        
        if (displayFlag == 1){
            string extension2;
            
            if (extensionString2.length() == 1) extensionString2 = "000"+extensionString2;
            else if (extensionString2.length() == 2) extensionString2 = "00"+extensionString2;
            else if (extensionString2.length() == 3) extensionString2 = "0"+extensionString2;
            
            fluorescentDetectionDisplay = 0;
            
            int totalSize = imageDimension*imageDimension*4;
            int phaseOpenCheck = 0;
            
            ifstream fin;
            
            if (fluorescentEntryCount != 0){
                int fluorescentDisplayFind1 = 0;
                int fluorescentDisplayFind2 = 0;
                int fluorescentDisplayFind3 = 0;
                int fluorescentDisplayFind4 = 0;
                int fluorescentDisplayFind5 = 0;
                int fluorescentDisplayFind6 = 0;
                
                extension2 = to_string(fluorescentNo1);
                
                string fluorescentPath1;
                if (ifEntry == 0) fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName1+exType;
                else if (ifEntry == 1) fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName1+exTypeIF+fluorescentRoundNo;
                
                extension2 = to_string(fluorescentNo2);
                
                string fluorescentPath2;
                if (ifEntry == 0) fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName2+exType;
                else if (ifEntry == 1) fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName2+exTypeIF+fluorescentRoundNo;
                
                extension2 = to_string(fluorescentNo3);
                
                string fluorescentPath3;
                if (ifEntry == 0) fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName3+exType;
                else if (ifEntry == 1) fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName3+exTypeIF+fluorescentRoundNo;
                
                extension2 = to_string(fluorescentNo4);
                
                string fluorescentPath4;
                if (ifEntry == 0) fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName4+exType;
                else if (ifEntry == 1) fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName4+exTypeIF+fluorescentRoundNo;
                
                extension2 = to_string(fluorescentNo5);
                
                string fluorescentPath5;
                if (ifEntry == 0) fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName5+exType;
                else if (ifEntry == 1) fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName5+exTypeIF+fluorescentRoundNo;
                
                extension2 = to_string(fluorescentNo6);
                
                string fluorescentPath6;
                if (ifEntry == 0) fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName6+exType;
                else if (ifEntry == 1) fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName6+exTypeIF+fluorescentRoundNo;
                
                struct stat sizeOfFile;
                
                if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0){
                    fluorescentDisplayFind1 = 1;
                }
                if (stat(fluorescentPath2.c_str(), &sizeOfFile) == 0){
                    fluorescentDisplayFind2 = 1;
                }
                if (stat(fluorescentPath3.c_str(), &sizeOfFile) == 0){
                    fluorescentDisplayFind3 = 1;
                }
                if (stat(fluorescentPath4.c_str(), &sizeOfFile) == 0){
                    fluorescentDisplayFind4 = 1;
                }
                if (stat(fluorescentPath5.c_str(), &sizeOfFile) == 0){
                    fluorescentDisplayFind5 = 1;
                }
                if (stat(fluorescentPath6.c_str(), &sizeOfFile) == 0){
                    fluorescentDisplayFind6 = 1;
                }
                
                int fluorescentColorNoHold = 0;
                
                if (fluorescentDisplayNo == 1 && fluorescentDisplayFind1 == 1){
                    displayImagePath = fluorescentPath1;
                    fluorescentColorNoHold = fluorescentNo1;
                }
                else if (fluorescentDisplayNo == 1 && fluorescentDisplayFind1 == 0){
                    if (fluorescentDisplayFind2 == 1){
                        fluorescentDisplayNo = 2;
                        displayImagePath = fluorescentPath2;
                        fluorescentColorNoHold = fluorescentNo2;
                    }
                    else if (fluorescentDisplayFind3 == 1){
                        fluorescentDisplayNo = 3;
                        displayImagePath = fluorescentPath3;
                        fluorescentColorNoHold = fluorescentNo3;
                    }
                    else if (fluorescentDisplayFind4 == 1){
                        fluorescentDisplayNo = 4;
                        displayImagePath = fluorescentPath4;
                        fluorescentColorNoHold = fluorescentNo4;
                    }
                    else if (fluorescentDisplayFind5 == 1){
                        fluorescentDisplayNo = 5;
                        displayImagePath = fluorescentPath5;
                        fluorescentColorNoHold = fluorescentNo5;
                    }
                    else if (fluorescentDisplayFind6 == 1){
                        fluorescentDisplayNo = 6;
                        displayImagePath = fluorescentPath6;
                        fluorescentColorNoHold = fluorescentNo6;
                    }
                    else fluorescentDisplayNo = 0;
                }
                else if (fluorescentDisplayNo == 2 && fluorescentDisplayFind2 == 1){
                    displayImagePath = fluorescentPath2;
                    fluorescentColorNoHold = fluorescentNo2;
                }
                else if (fluorescentDisplayNo == 2 && fluorescentDisplayFind2 == 0){
                    if (fluorescentDisplayFind3 == 1){
                        fluorescentDisplayNo = 3;
                        displayImagePath = fluorescentPath3;
                        fluorescentColorNoHold = fluorescentNo3;
                    }
                    else if (fluorescentDisplayFind4 == 1){
                        fluorescentDisplayNo = 4;
                        displayImagePath = fluorescentPath4;
                        fluorescentColorNoHold = fluorescentNo4;
                    }
                    else if (fluorescentDisplayFind5 == 1){
                        fluorescentDisplayNo = 5;
                        displayImagePath = fluorescentPath5;
                        fluorescentColorNoHold = fluorescentNo5;
                    }
                    else if (fluorescentDisplayFind6 == 1){
                        fluorescentDisplayNo = 6;
                        displayImagePath = fluorescentPath6;
                        fluorescentColorNoHold = fluorescentNo6;
                    }
                    else fluorescentDisplayNo = 0;
                }
                else if (fluorescentDisplayNo == 3 && fluorescentDisplayFind3 == 1){
                    displayImagePath = fluorescentPath3;
                    fluorescentColorNoHold = fluorescentNo3;
                }
                else if (fluorescentDisplayNo == 3 && fluorescentDisplayFind3 == 0){
                    if (fluorescentDisplayFind4 == 1){
                        fluorescentDisplayNo = 4;
                        displayImagePath = fluorescentPath4;
                        fluorescentColorNoHold = fluorescentNo4;
                    }
                    else if (fluorescentDisplayFind5 == 1){
                        fluorescentDisplayNo = 5;
                        displayImagePath = fluorescentPath5;
                        fluorescentColorNoHold = fluorescentNo5;
                    }
                    else if (fluorescentDisplayFind6 == 1){
                        fluorescentDisplayNo = 6;
                        displayImagePath = fluorescentPath6;
                        fluorescentColorNoHold = fluorescentNo6;
                    }
                    else fluorescentDisplayNo = 0;
                }
                else if (fluorescentDisplayNo == 4 && fluorescentDisplayFind4 == 1){
                    displayImagePath = fluorescentPath4;
                    fluorescentColorNoHold = fluorescentNo4;
                }
                else if (fluorescentDisplayNo == 4 && fluorescentDisplayFind4 == 0){
                    if (fluorescentDisplayFind5 == 1){
                        fluorescentDisplayNo = 5;
                        displayImagePath = fluorescentPath5;
                        fluorescentColorNoHold = fluorescentNo5;
                    }
                    else if (fluorescentDisplayFind6 == 1){
                        fluorescentDisplayNo = 6;
                        displayImagePath = fluorescentPath6;
                        fluorescentColorNoHold = fluorescentNo6;
                    }
                    else fluorescentDisplayNo = 0;
                }
                else if (fluorescentDisplayNo == 5 && fluorescentDisplayFind5 == 1){
                    displayImagePath = fluorescentPath5;
                    fluorescentColorNoHold = fluorescentNo5;
                }
                else if (fluorescentDisplayNo == 5 && fluorescentDisplayFind5 == 0){
                    if (fluorescentDisplayFind6 == 1){
                        fluorescentDisplayNo = 6;
                        displayImagePath = fluorescentPath6;
                        fluorescentColorNoHold = fluorescentNo6;
                    }
                    else fluorescentDisplayNo = 0;
                }
                else if (fluorescentDisplayNo == 6 && fluorescentDisplayFind6 == 1){
                    displayImagePath = fluorescentPath6;
                    fluorescentColorNoHold = fluorescentNo6;
                }
                else if (fluorescentDisplayNo == 6 && fluorescentDisplayFind6 == 0) fluorescentDisplayNo = 0;
                
                if (fluorescentDisplayFind1 == 1 || fluorescentDisplayFind2 == 1 || fluorescentDisplayFind3 == 1 || fluorescentDisplayFind4 == 1 || fluorescentDisplayFind5 == 1 || fluorescentDisplayFind6 == 1){
                    fluorescentDetectionDisplay = 1;
                    
                    if (trackingOn != 3){
                        string expandData = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extensionString2+"_"+analysisID+"_"+treatmentNameHold+"_ExtendLineData";
                        
                        long sizeForCopy = 0;
                        long size1 = 0;
                        long size2 = 0;
                        int checkFlag = 0;
                        int readingError = 0;
                        
                        for (int counter1 = 0; counter1 < 6; counter1++){
                            sizeForCopy = 0;
                            
                            if (stat(expandData.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            if (sizeForCopy != 0){
                                if (counter1 == 0) size1 = sizeForCopy;
                                else if (counter1 == 1) size2 = sizeForCopy;
                                else if (counter1 == 2){
                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                        checkFlag = 1;
                                        break;
                                    }
                                    else{
                                        
                                        size1 = 0;
                                        size2 = 0;
                                        usleep (50000);
                                    }
                                }
                                else if (counter1 == 3) size1 = sizeForCopy;
                                else if (counter1 == 4) size2 = sizeForCopy;
                                else if (counter1 == 5){
                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                        checkFlag = 1;
                                    }
                                }
                            }
                        }
                        
                        expandFluorescentOutlineCount = 0;
                        expandFluorescentDataCount = 0;
                        
                        if (checkFlag == 1){
                            if (expandFluorescentOutlineStatus == 1) delete [] expandFluorescentOutline;
                            expandFluorescentOutline = new int [sizeForCopy+50];
                            expandFluorescentOutlineLimit = (int)sizeForCopy+50;
                            expandFluorescentOutlineStatus = 1;
                            
                            fin.open(expandData.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                int finData [8];
                                
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                        usleep(50000);
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                            readingError = 1;
                                        }
                                    }
                                }
                                
                                fin.close();
                                
                                if (readingError == 0){
                                    unsigned long readPosition = 0;
                                    int stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTemp [readPosition], readPosition++;
                                            finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                                            finData [2] = uploadTemp [readPosition], readPosition++;
                                            finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                                            finData [4] = uploadTemp [readPosition], readPosition++;
                                            finData [5] = uploadTemp [readPosition], readPosition++;
                                            finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                            finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                            
                                            finData [1] = finData [0]*256+finData [1];
                                            finData [3] = finData [2]*256+finData [3];
                                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                            
                                            if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                            else{
                                                
                                                expandFluorescentOutline [expandFluorescentOutlineCount] = finData [1], expandFluorescentOutlineCount++;
                                                expandFluorescentOutline [expandFluorescentOutlineCount] = finData [3], expandFluorescentOutlineCount++;
                                                expandFluorescentOutline [expandFluorescentOutlineCount] = finData [6], expandFluorescentOutlineCount++;
                                                expandFluorescentOutline [expandFluorescentOutlineCount] = finData [7], expandFluorescentOutlineCount++;
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                }
                                
                                delete [] uploadTemp;
                            }
                        }
                        else{
                            
                            if (expandFluorescentOutlineStatus == 1) delete [] expandFluorescentOutline;
                            
                            expandFluorescentOutlineCount = 0;
                            expandFluorescentOutlineLimit = 0;
                            expandFluorescentOutlineStatus = 0;
                        }
                        
                        expandData = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extensionString2+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
                        
                        sizeForCopy = 0;
                        
                        if (stat(expandData.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (expandFluorescentDataStatus == 1) delete [] expandFluorescentData;
                            expandFluorescentData = new int [sizeForCopy+50];
                            expandFluorescentDataLimit = (int)sizeForCopy+50;
                            expandFluorescentDataStatus = 1;
                            
                            fin.open(expandData.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                fin.close();
                                
                                unsigned long readPosition = 0;
                                int stepCount = 0;
                                int finData [8];
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++;
                                        finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                        finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                                        
                                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                        
                                        if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                        else{
                                            
                                            expandFluorescentData [expandFluorescentDataCount] = finData [2], expandFluorescentDataCount++;
                                            expandFluorescentData [expandFluorescentDataCount] = finData [3], expandFluorescentDataCount++;
                                            expandFluorescentData [expandFluorescentDataCount] = finData [4], expandFluorescentDataCount++;
                                            expandFluorescentData [expandFluorescentDataCount] = finData [7], expandFluorescentDataCount++;
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                                
                                delete [] uploadTemp;
                            }
                        }
                        else{
                            
                            if (expandFluorescentDataStatus == 1) delete [] expandFluorescentData;
                            
                            expandFluorescentDataCount = 0;
                            expandFluorescentDataLimit = 0;
                            expandFluorescentDataStatus = 0;
                        }
                    }
                }
                
                if (fluorescentDisplayNo == 0){
                    if (phaseStatus == 1){
                        if (ifEntry == 0) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Phase/"+"Phase "+extensionString2+exType;
                        else if (ifEntry == 1) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Phase/"+"Phase "+extensionString2+exTypeIF+fluorescentRoundNo;
                        
                        fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            phaseOpenCheck = 1;
                        }
                    }
                    
                    if (phaseStatus == 0 || phaseOpenCheck == 0){
                        if (ifEntry == 0) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+exType;
                        else if (ifEntry == 1) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+exTypeIF+fluorescentRoundNo;
                    }
                    
                    uint8_t *uploadTemp = new uint8_t [totalSize+1];
                    fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        if (exType == ".tif" || exTypeIF == ".TIF"){
                            fin.read((char*)uploadTemp, totalSize+1);
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            
                            unsigned long headPosition = 0;
                            
                            dataConversion [0] = uploadTemp [0];
                            dataConversion [1] = uploadTemp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTemp [7];
                                dataConversion [1] = uploadTemp [6];
                                dataConversion [2] = uploadTemp [5];
                                dataConversion [3] = uploadTemp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTemp [4];
                                dataConversion [1] = uploadTemp [5];
                                dataConversion [2] = uploadTemp [6];
                                dataConversion [3] = uploadTemp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (tifImageColorGray == 0){
                                NSBitmapImageRep *bitmapReps;
                                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                                
                                unsigned char *bitmapData = [bitmapReps bitmapData];
                                
                                for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                    *bitmapData++ = uploadTemp [counter1];
                                }
                                
                                trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                [trackingImage addRepresentation:bitmapReps];
                            }
                            else if (tifImageColorGray == 1){
                                NSBitmapImageRep *bitmapReps = nil;
                                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                                
                                unsigned char *bitmapData = [bitmapReps bitmapData];
                                
                                for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                    value0 = uploadTemp [counter1];
                                    value1 = uploadTemp [counter1+1];
                                    value2 = uploadTemp [counter1+2];
                                    
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = (unsigned char)value1;
                                    *bitmapData++ = (unsigned char)value2;
                                    *bitmapData++ = 0;
                                }
                                
                                trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                [trackingImage addRepresentation:bitmapReps];
                            }
                        }
                        else if (exType == ".bmp" || exTypeIF == ".BMP"){
                            fin.read((char*)uploadTemp, totalSize+1);
                            fin.close();
                            
                            NSBitmapImageRep *bitmapReps;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                    *bitmapData++ = uploadTemp [1078+counter1*imageDimension+counter2];
                                }
                            }
                            
                            trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [trackingImage addRepresentation:bitmapReps];
                        }
                    }
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    uint8_t *uploadTemp = new uint8_t [totalSize+1];
                    fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        if (exType == ".tif" || exTypeIF == ".TIF"){
                            fin.read((char*)uploadTemp, totalSize+1);
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            
                            unsigned long headPosition = 0;
                            
                            dataConversion [0] = uploadTemp [0];
                            dataConversion [1] = uploadTemp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTemp [7];
                                dataConversion [1] = uploadTemp [6];
                                dataConversion [2] = uploadTemp [5];
                                dataConversion [3] = uploadTemp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTemp [4];
                                dataConversion [1] = uploadTemp [5];
                                dataConversion [2] = uploadTemp [6];
                                dataConversion [3] = uploadTemp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (tifImageColorGray == 0){
                                NSBitmapImageRep *bitmapReps = nil;
                                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                                
                                unsigned char *bitmapData = [bitmapReps bitmapData];
                                
                                int readDataTemp = 0;
                                
                                for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                    readDataTemp = uploadTemp [counter1];
                                    
                                    if (fluorescentDisplayMode == 0){
                                        if (fluorescentDisplayNo == 1 && readDataTemp < fluorescentCutOff1) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 2 && readDataTemp < fluorescentCutOff2) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 3 && readDataTemp < fluorescentCutOff3) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 4 && readDataTemp < fluorescentCutOff4) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 5 && readDataTemp < fluorescentCutOff5) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 6 && readDataTemp < fluorescentCutOff6) readDataTemp = 0;
                                        
                                        if (fluorescentColorNoHold == 1){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 2){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 3){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 4){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 5){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 6){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 7){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.674));
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 8){
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.627));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.125));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.941));
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 9){
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.529));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.808));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.922));
                                            *bitmapData++ = 0;
                                        }
                                    }
                                    else{
                                        
                                        if (fluorescentDisplayRange == 2){
                                            if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else{
                                                
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                        }
                                        else if (fluorescentDisplayRange == 3){
                                            if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*2){
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                            else{
                                                
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                        }
                                        else if (fluorescentDisplayRange == 4){
                                            if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*2){
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                            else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*3){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else{
                                                
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                        }
                                    }
                                }
                                
                                trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                [trackingImage addRepresentation:bitmapReps];
                                
                            }
                            else if (tifImageColorGray == 1){
                                NSBitmapImageRep *bitmapReps = nil;
                                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                                
                                unsigned char *bitmapData = [bitmapReps bitmapData];
                                
                                for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                    value0 = uploadTemp [counter1];
                                    value1 = uploadTemp [counter1+1];
                                    value2 = uploadTemp [counter1+2];
                                    
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = (unsigned char)value1;
                                    *bitmapData++ = (unsigned char)value2;
                                    *bitmapData++ = 0;
                                }
                                
                                trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                [trackingImage addRepresentation:bitmapReps];
                            }
                        }
                        else if (exType == ".bmp" || exTypeIF == ".BMP"){
                            NSBitmapImageRep *bitmapReps = nil;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            int readDataTemp = 0;
                            
                            fin.read((char*)uploadTemp, totalSize+1);
                            fin.close();
                            
                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                    readDataTemp = uploadTemp [1078+counter1*imageDimension+counter2];
                                    
                                    if (fluorescentDisplayMode == 0){
                                        if (fluorescentDisplayNo == 1 && readDataTemp < fluorescentCutOff1) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 2 && readDataTemp < fluorescentCutOff2) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 3 && readDataTemp < fluorescentCutOff3) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 4 && readDataTemp < fluorescentCutOff4) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 5 && readDataTemp < fluorescentCutOff5) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 6 && readDataTemp < fluorescentCutOff6) readDataTemp = 0;
                                        
                                        if (fluorescentColorNoHold == 1){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 2){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 3){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 4){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 5){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 6){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 7){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.674));
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 8){
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.627));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.125));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.941));
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 9){
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.529));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.808));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.922));
                                            *bitmapData++ = 0;
                                        }
                                    }
                                    else{
                                        
                                        if (fluorescentDisplayRange == 2){
                                            if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else{
                                                
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                        }
                                        else if (fluorescentDisplayRange == 3){
                                            if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*2){
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                            else{
                                                
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                        }
                                        else if (fluorescentDisplayRange == 4){
                                            if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*2){
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                            else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*3){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else{
                                                
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [trackingImage addRepresentation:bitmapReps];
                        }
                    }
                    
                    delete [] uploadTemp;
                }
            }
            else{
                
                if (phaseStatus == 1){
                    if (ifEntry == 0) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Phase/"+"Phase "+extensionString2+exType;
                    else if (ifEntry == 1) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Phase/"+"Phase "+extensionString2+exTypeIF+fluorescentRoundNo;
                    
                    fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.close();
                        phaseOpenCheck = 1;
                    }
                }
                
                if (phaseStatus == 0 || phaseOpenCheck == 0){
                    if (ifEntry == 0) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+exType;
                    else if (ifEntry == 1) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+exTypeIF+fluorescentRoundNo;
                }
                
                uint8_t *uploadTemp = new uint8_t [totalSize+1];
                fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    if (exType == ".tif" || exTypeIF == ".TIF"){
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        int dataConversion [4];
                        int endianType = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        
                        unsigned long headPosition = 0;
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        if (tifImageColorGray == 0){
                            NSBitmapImageRep *bitmapReps;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                *bitmapData++ = uploadTemp [counter1];
                            }
                            
                            trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [trackingImage addRepresentation:bitmapReps];
                        }
                        else if (tifImageColorGray == 1){
                            NSBitmapImageRep *bitmapReps = nil;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                value0 = uploadTemp [counter1];
                                value1 = uploadTemp [counter1+1];
                                value2 = uploadTemp [counter1+2];
                                
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value1;
                                *bitmapData++ = (unsigned char)value2;
                                *bitmapData++ = 0;
                            }
                            
                            trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [trackingImage addRepresentation:bitmapReps];
                        }
                    }
                    else if (exType == ".bmp" || exTypeIF == ".BMP"){
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        NSBitmapImageRep *bitmapReps;
                        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                        
                        unsigned char *bitmapData = [bitmapReps bitmapData];
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                *bitmapData++ = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                        }
                        
                        trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                        [trackingImage addRepresentation:bitmapReps];
                    }
                }
                
                delete [] uploadTemp;
            }
        }
    }
    else if (previousImageNumber != timeOneHold || timeOneStatus == 2){
        previousImageNumber = timeOneHold;
        
        string lineageNoExtension = to_string(timeOneHold);
        
        if (lineageNoExtension.length() == 1) lineageNoExtension = "000"+lineageNoExtension;
        else if (lineageNoExtension.length() == 2) lineageNoExtension = "00"+lineageNoExtension;
        else if (lineageNoExtension.length() == 3) lineageNoExtension = "0"+lineageNoExtension;
        
        string extension2;
        
        fluorescentDetectionDisplay = 0;
        
        int totalSize = imageDimension*imageDimension*4;
        int phaseOpenCheck = 0;
        
        ifstream fin;
        
        if (fluorescentEntryCount != 0){
            int fluorescentDisplayFind1 = 0;
            int fluorescentDisplayFind2 = 0;
            int fluorescentDisplayFind3 = 0;
            int fluorescentDisplayFind4 = 0;
            int fluorescentDisplayFind5 = 0;
            int fluorescentDisplayFind6 = 0;
            
            extension2 = to_string(fluorescentNo1);
            
            string fluorescentPath1;
            if (ifEntry == 0) fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName1+exType;
            else if (ifEntry == 1) fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName1+exTypeIF+fluorescentRoundNo;
            
            extension2 = to_string(fluorescentNo2);
            
            string fluorescentPath2;
            if (ifEntry == 0) fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName2+exType;
            else if (ifEntry == 1) fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName2+exTypeIF+fluorescentRoundNo;
            
            extension2 = to_string(fluorescentNo3);
            
            string fluorescentPath3;
            if (ifEntry == 0) fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName3+exType;
            else if (ifEntry == 1) fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName3+exTypeIF+fluorescentRoundNo;
            
            extension2 = to_string(fluorescentNo4);
            
            string fluorescentPath4;
            if (ifEntry == 0) fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName4+exType;
            else if (ifEntry == 1) fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName4+exTypeIF+fluorescentRoundNo;
            
            extension2 = to_string(fluorescentNo5);
            
            string fluorescentPath5;
            if (ifEntry == 0) fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName5+exType;
            else if (ifEntry == 1) fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName5+exTypeIF+fluorescentRoundNo;
            
            extension2 = to_string(fluorescentNo6);
            
            string fluorescentPath6;
            if (ifEntry == 0) fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName6+exType;
            else if (ifEntry == 1) fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName6+exTypeIF+fluorescentRoundNo;
            
            struct stat sizeOfFile;
            
            if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind1 = 1;
            }
            
            if (stat(fluorescentPath2.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind2 = 1;
            }
            
            if (stat(fluorescentPath3.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind3 = 1;
            }
            
            if (stat(fluorescentPath4.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind4 = 1;
            }
            
            if (stat(fluorescentPath5.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind5 = 1;
            }
            
            if (stat(fluorescentPath6.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind6 = 1;
            }
            
            int fluorescentColorNoHold = 0;
            
            if (fluorescentDisplayNo == 1 && fluorescentDisplayFind1 == 1){
                displayImagePath = fluorescentPath1;
                fluorescentColorNoHold = fluorescentNo1;
            }
            else if (fluorescentDisplayNo == 1 && fluorescentDisplayFind1 == 0){
                if (fluorescentDisplayFind2 == 1){
                    fluorescentDisplayNo = 2;
                    displayImagePath = fluorescentPath2;
                    fluorescentColorNoHold = fluorescentNo2;
                }
                else if (fluorescentDisplayFind3 == 1){
                    fluorescentDisplayNo = 3;
                    displayImagePath = fluorescentPath3;
                    fluorescentColorNoHold = fluorescentNo3;
                }
                else if (fluorescentDisplayFind4 == 1){
                    fluorescentDisplayNo = 4;
                    displayImagePath = fluorescentPath4;
                    fluorescentColorNoHold = fluorescentNo4;
                }
                else if (fluorescentDisplayFind5 == 1){
                    fluorescentDisplayNo = 5;
                    displayImagePath = fluorescentPath5;
                    fluorescentColorNoHold = fluorescentNo5;
                }
                else if (fluorescentDisplayFind6 == 1){
                    fluorescentDisplayNo = 6;
                    displayImagePath = fluorescentPath6;
                    fluorescentColorNoHold = fluorescentNo6;
                }
                else fluorescentDisplayNo = 0;
            }
            else if (fluorescentDisplayNo == 2 && fluorescentDisplayFind2 == 1){
                displayImagePath = fluorescentPath2;
                fluorescentColorNoHold = fluorescentNo2;
            }
            else if (fluorescentDisplayNo == 2 && fluorescentDisplayFind2 == 0){
                if (fluorescentDisplayFind3 == 1){
                    fluorescentDisplayNo = 3;
                    displayImagePath = fluorescentPath3;
                    fluorescentColorNoHold = fluorescentNo3;
                }
                else if (fluorescentDisplayFind4 == 1){
                    fluorescentDisplayNo = 4;
                    displayImagePath = fluorescentPath4;
                    fluorescentColorNoHold = fluorescentNo4;
                }
                else if (fluorescentDisplayFind5 == 1){
                    fluorescentDisplayNo = 5;
                    displayImagePath = fluorescentPath5;
                    fluorescentColorNoHold = fluorescentNo5;
                }
                else if (fluorescentDisplayFind6 == 1){
                    fluorescentDisplayNo = 6;
                    displayImagePath = fluorescentPath6;
                    fluorescentColorNoHold = fluorescentNo6;
                }
                else fluorescentDisplayNo = 0;
            }
            else if (fluorescentDisplayNo == 3 && fluorescentDisplayFind3 == 1){
                displayImagePath = fluorescentPath3;
                fluorescentColorNoHold = fluorescentNo3;
            }
            else if (fluorescentDisplayNo == 3 && fluorescentDisplayFind3 == 0){
                if (fluorescentDisplayFind4 == 1){
                    fluorescentDisplayNo = 4;
                    displayImagePath = fluorescentPath4;
                    fluorescentColorNoHold = fluorescentNo4;
                }
                else if (fluorescentDisplayFind5 == 1){
                    fluorescentDisplayNo = 5;
                    displayImagePath = fluorescentPath5;
                    fluorescentColorNoHold = fluorescentNo5;
                }
                else if (fluorescentDisplayFind6 == 1){
                    fluorescentDisplayNo = 6;
                    displayImagePath = fluorescentPath6;
                    fluorescentColorNoHold = fluorescentNo6;
                }
                else fluorescentDisplayNo = 0;
            }
            else if (fluorescentDisplayNo == 4 && fluorescentDisplayFind4 == 1){
                displayImagePath = fluorescentPath4;
                fluorescentColorNoHold = fluorescentNo4;
            }
            else if (fluorescentDisplayNo == 4 && fluorescentDisplayFind4 == 0){
                if (fluorescentDisplayFind5 == 1){
                    fluorescentDisplayNo = 5;
                    displayImagePath = fluorescentPath5;
                    fluorescentColorNoHold = fluorescentNo5;
                }
                else if (fluorescentDisplayFind6 == 1){
                    fluorescentDisplayNo = 6;
                    displayImagePath = fluorescentPath6;
                    fluorescentColorNoHold = fluorescentNo6;
                }
                else fluorescentDisplayNo = 0;
            }
            else if (fluorescentDisplayNo == 5 && fluorescentDisplayFind5 == 1){
                displayImagePath = fluorescentPath5;
                fluorescentColorNoHold = fluorescentNo5;
            }
            else if (fluorescentDisplayNo == 5 && fluorescentDisplayFind5 == 0){
                if (fluorescentDisplayFind6 == 1){
                    fluorescentDisplayNo = 6;
                    displayImagePath = fluorescentPath6;
                    fluorescentColorNoHold = fluorescentNo6;
                }
                else fluorescentDisplayNo = 0;
            }
            else if (fluorescentDisplayNo == 6 && fluorescentDisplayFind6 == 1){
                displayImagePath = fluorescentPath6;
                fluorescentColorNoHold = fluorescentNo6;
            }
            else if (fluorescentDisplayNo == 6 && fluorescentDisplayFind6 == 0) fluorescentDisplayNo = 0;
            
            if (fluorescentDisplayFind1 == 1 || fluorescentDisplayFind2 == 1 || fluorescentDisplayFind3 == 1 || fluorescentDisplayFind4 == 1 || fluorescentDisplayFind5 == 1 || fluorescentDisplayFind6 == 1){
                fluorescentDetectionDisplay = 1;
                
                if (trackingOn != 3){
                    string expandData = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extensionString2+"_"+analysisID+"_"+treatmentNameHold+"_ExtendLineData";
                    
                    long sizeForCopy = 0;
                    long size1 = 0;
                    long size2 = 0;
                    int checkFlag = 0;
                    int readingError = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(expandData.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    expandFluorescentOutlineCount = 0;
                    expandFluorescentDataCount = 0;
                    
                    if (checkFlag == 1){
                        if (expandFluorescentOutlineStatus == 1) delete [] expandFluorescentOutline;
                        expandFluorescentOutline = new int [sizeForCopy+50];
                        expandFluorescentOutlineLimit = (int)sizeForCopy+50;
                        expandFluorescentOutlineStatus = 1;
                        
                        fin.open(expandData.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            int finData [8];
                            
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                        readingError = 1;
                                    }
                                }
                            }
                            
                            fin.close();
                            
                            unsigned long readPosition = 0;
                            int stepCount = 0;
                            
                            if (readingError == 0){
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                                        finData [2] = uploadTemp [readPosition], readPosition++;
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                                        finData [4] = uploadTemp [readPosition], readPosition++;
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                        
                                        finData [1] = finData [0]*256+finData [1];
                                        finData [3] = finData [2]*256+finData [3];
                                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                        
                                        if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                        else{
                                            
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = finData [1], expandFluorescentOutlineCount++;
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = finData [3], expandFluorescentOutlineCount++;
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = finData [6], expandFluorescentOutlineCount++;
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = finData [7], expandFluorescentOutlineCount++;
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                            }
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        if (expandFluorescentOutlineStatus == 1) delete [] expandFluorescentOutline;
                        
                        expandFluorescentOutlineCount = 0;
                        expandFluorescentOutlineLimit = 0;
                        expandFluorescentOutlineStatus = 0;
                    }
                    
                    expandData = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extensionString2+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
                    
                    sizeForCopy = 0;
                    
                    if (stat(expandData.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (expandFluorescentDataStatus == 1) delete [] expandFluorescentData;
                        expandFluorescentData = new int [sizeForCopy+50];
                        expandFluorescentDataLimit = (int)sizeForCopy+50;
                        expandFluorescentDataStatus = 1;
                        
                        fin.open(expandData.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            unsigned long readPosition = 0;
                            int stepCount = 0;
                            int finData [8];
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++;
                                    finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                    finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                                    
                                    finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                    
                                    if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                    else{
                                        
                                        expandFluorescentData [expandFluorescentDataCount] = finData [2], expandFluorescentDataCount++;
                                        expandFluorescentData [expandFluorescentDataCount] = finData [3], expandFluorescentDataCount++;
                                        expandFluorescentData [expandFluorescentDataCount] = finData [4], expandFluorescentDataCount++;
                                        expandFluorescentData [expandFluorescentDataCount] = finData [7], expandFluorescentDataCount++;
                                    }
                                }
                                
                            } while (stepCount != 3);
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        if (expandFluorescentDataStatus == 1) delete [] expandFluorescentData;
                        
                        expandFluorescentDataCount = 0;
                        expandFluorescentDataLimit = 0;
                        expandFluorescentDataStatus = 0;
                    }
                }
            }
            
            if (fluorescentDisplayNo == 0){
                if (phaseStatus == 1){
                    if (ifEntry == 0) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Phase/"+"Phase "+extensionString2+exType;
                    else if (ifEntry == 1) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Phase/"+"Phase "+extensionString2+exTypeIF+fluorescentRoundNo;
                    
                    fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.close();
                        phaseOpenCheck = 1;
                    }
                }
                
                if (phaseStatus == 0 || phaseOpenCheck == 0){
                    if (ifEntry == 0) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+exType;
                    else if (ifEntry == 1) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+exTypeIF+fluorescentRoundNo;
                }
                
                uint8_t *uploadTemp = new uint8_t [totalSize+1];
                fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    if (exType == ".tif" || exTypeIF == ".TIF"){
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        int dataConversion [4];
                        int endianType = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        
                        unsigned long headPosition = 0;
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        if (tifImageColorGray == 0){
                            NSBitmapImageRep *bitmapReps;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                *bitmapData++ = uploadTemp [counter1];
                            }
                            
                            trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [trackingImage addRepresentation:bitmapReps];
                        }
                        else if (tifImageColorGray == 1){
                            NSBitmapImageRep *bitmapReps = nil;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                value0 = uploadTemp [counter1];
                                value1 = uploadTemp [counter1+1];
                                value2 = uploadTemp [counter1+2];
                                
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value1;
                                *bitmapData++ = (unsigned char)value2;
                                *bitmapData++ = 0;
                            }
                            
                            trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [trackingImage addRepresentation:bitmapReps];
                        }
                    }
                    else if (exType == ".bmp" || exTypeIF == ".BMP"){
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        NSBitmapImageRep *bitmapReps;
                        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                        
                        unsigned char *bitmapData = [bitmapReps bitmapData];
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                *bitmapData++ = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                        }
                        
                        trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                        [trackingImage addRepresentation:bitmapReps];
                    }
                }
                
                delete [] uploadTemp;
            }
            else{
                
                uint8_t *uploadTemp = new uint8_t [totalSize+1];
                fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    if (exType == ".tif" || exTypeIF == ".TIF"){
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        int dataConversion [4];
                        int endianType = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        
                        unsigned long headPosition = 0;
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        if (tifImageColorGray == 0){
                            NSBitmapImageRep *bitmapReps = nil;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            int readDataTemp = 0;
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                readDataTemp = uploadTemp [counter1];
                                
                                if (fluorescentDisplayMode == 0){
                                    if (fluorescentDisplayNo == 1 && readDataTemp < fluorescentCutOff1) readDataTemp = 0;
                                    else if (fluorescentDisplayNo == 2 && readDataTemp < fluorescentCutOff2) readDataTemp = 0;
                                    else if (fluorescentDisplayNo == 3 && readDataTemp < fluorescentCutOff3) readDataTemp = 0;
                                    else if (fluorescentDisplayNo == 4 && readDataTemp < fluorescentCutOff4) readDataTemp = 0;
                                    else if (fluorescentDisplayNo == 5 && readDataTemp < fluorescentCutOff5) readDataTemp = 0;
                                    else if (fluorescentDisplayNo == 6 && readDataTemp < fluorescentCutOff6) readDataTemp = 0;
                                    
                                    if (fluorescentColorNoHold == 1){
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 2){
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 3){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 4){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 5){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 6){
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 7){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.674));
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 8){
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.627));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.125));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.941));
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 9){
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.529));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.808));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.922));
                                        *bitmapData++ = 0;
                                    }
                                }
                                else{
                                    
                                    if (fluorescentDisplayRange == 2){
                                        if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else{
                                            
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                    }
                                    else if (fluorescentDisplayRange == 3){
                                        if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*2){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else{
                                            
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                    }
                                    else if (fluorescentDisplayRange == 4){
                                        if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*2){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*3){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else{
                                            
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                    }
                                }
                            }
                            
                            trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [trackingImage addRepresentation:bitmapReps];
                        }
                        else if (tifImageColorGray == 1){
                            NSBitmapImageRep *bitmapReps = nil;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                value0 = uploadTemp [counter1];
                                value1 = uploadTemp [counter1+1];
                                value2 = uploadTemp [counter1+2];
                                
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value1;
                                *bitmapData++ = (unsigned char)value2;
                                *bitmapData++ = 0;
                            }
                            
                            trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [trackingImage addRepresentation:bitmapReps];
                        }
                    }
                    else if (exType == ".bmp" || exTypeIF == ".BMP"){
                        NSBitmapImageRep *bitmapReps = nil;
                        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                        
                        unsigned char *bitmapData = [bitmapReps bitmapData];
                        
                        int readDataTemp = 0;
                        
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                readDataTemp = uploadTemp [1078+counter1*imageDimension+counter2];
                                
                                if (fluorescentDisplayMode == 0){
                                    if (fluorescentDisplayNo == 1 && readDataTemp < fluorescentCutOff1) readDataTemp = 0;
                                    else if (fluorescentDisplayNo == 2 && readDataTemp < fluorescentCutOff2) readDataTemp = 0;
                                    else if (fluorescentDisplayNo == 3 && readDataTemp < fluorescentCutOff3) readDataTemp = 0;
                                    else if (fluorescentDisplayNo == 4 && readDataTemp < fluorescentCutOff4) readDataTemp = 0;
                                    else if (fluorescentDisplayNo == 5 && readDataTemp < fluorescentCutOff5) readDataTemp = 0;
                                    else if (fluorescentDisplayNo == 6 && readDataTemp < fluorescentCutOff6) readDataTemp = 0;
                                    
                                    if (fluorescentColorNoHold == 1){
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 2){
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 3){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 4){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 5){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 6){
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 7){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.674));
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 8){
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.627));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.125));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.941));
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 9){
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.529));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.808));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.922));
                                        *bitmapData++ = 0;
                                    }
                                }
                                else{
                                    
                                    if (fluorescentDisplayRange == 2){
                                        if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else{
                                            
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                    }
                                    else if (fluorescentDisplayRange == 3){
                                        if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*2){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else{
                                            
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                    }
                                    else if (fluorescentDisplayRange == 4){
                                        if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*2){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*3){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else{
                                            
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                    }
                                }
                            }
                        }
                        
                        trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                        [trackingImage addRepresentation:bitmapReps];
                    }
                }
                
                delete [] uploadTemp;
            }
        }
        else{
            
            if (phaseStatus == 1){
                if (ifEntry == 0) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Phase/"+"Phase "+extensionString2+exType;
                else if (ifEntry == 1) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Phase/"+"Phase "+extensionString2+exTypeIF+fluorescentRoundNo;
                
                fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    fin.close();
                    phaseOpenCheck = 1;
                }
            }
            
            if (phaseStatus == 0 || phaseOpenCheck == 0){
                if (ifEntry == 0) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+exType;
                else if (ifEntry == 1) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+exTypeIF+fluorescentRoundNo;
            }
            
            uint8_t *uploadTemp = new uint8_t [totalSize+1];
            fin.open(displayImagePath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                if (exType == ".tif" || exTypeIF == ".TIF"){
                    fin.read((char*)uploadTemp, totalSize+1);
                    fin.close();
                    
                    int dataConversion [4];
                    int endianType = 0;
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    
                    unsigned long headPosition = 0;
                    
                    dataConversion [0] = uploadTemp [0];
                    dataConversion [1] = uploadTemp [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    headPosition = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = uploadTemp [7];
                        dataConversion [1] = uploadTemp [6];
                        dataConversion [2] = uploadTemp [5];
                        dataConversion [3] = uploadTemp [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = uploadTemp [4];
                        dataConversion [1] = uploadTemp [5];
                        dataConversion [2] = uploadTemp [6];
                        dataConversion [3] = uploadTemp [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    if (tifImageColorGray == 0){
                        NSBitmapImageRep *bitmapReps;
                        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                        
                        unsigned char *bitmapData = [bitmapReps bitmapData];
                        
                        for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                            *bitmapData++ = uploadTemp [counter1];
                        }
                        
                        trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                        [trackingImage addRepresentation:bitmapReps];
                    }
                    else if (tifImageColorGray == 1){
                        NSBitmapImageRep *bitmapReps = nil;
                        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                        
                        unsigned char *bitmapData = [bitmapReps bitmapData];
                        
                        for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                            value0 = uploadTemp [counter1];
                            value1 = uploadTemp [counter1+1];
                            value2 = uploadTemp [counter1+2];
                            
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value1;
                            *bitmapData++ = (unsigned char)value2;
                            *bitmapData++ = 0;
                        }
                        
                        trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                        [trackingImage addRepresentation:bitmapReps];
                    }
                }
                else if (exType == ".bmp" || exTypeIF == ".BMP"){
                    fin.read((char*)uploadTemp, totalSize+1);
                    fin.close();
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                    
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                        for (int counter2 = 0; counter2 < imageDimension; counter2++){
                            *bitmapData++ = uploadTemp [1078+counter1*imageDimension+counter2];
                        }
                    }
                    
                    trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                    [trackingImage addRepresentation:bitmapReps];
                }
            }
            
            delete [] uploadTemp;
        }
    }
    
    if (trackingOn == 1 && addDelInsert == 0 && clearBack == 0 && listToTrackCall == 0 && trackJump == 0 && sliderBarSet == 0) imageNumberTrackForDisplay = imageNumber;
    
    imageWidthTrack = (int)[trackingImage size].width;
    imageHeightTrack = (int)[trackingImage size].height;
    
    int vertical = 700+78;
    int horizontal = 700;
    
    windowWidthTrack = imageWidthTrack/(double)horizontal;
    windowHeightTrack = imageHeightTrack/(double)(vertical-78);
    
    if (timeOneStatus == 0 && lineSetWindowCallTrack == 0 && trackingOn == 1 && (cellLineageNoHold == "" && cellNoHold == "") && addDelInsert == 0 && listToTrackCall == 0 && trackJump == 0 && sliderBarSet == 0){
        xPositionTrack = 0;
        yPositionTrack = 0;
        xPositionAdjustTrack = 0;
        yPositionAdjustTrack = 0;
        magnificationTrack = 10;
    }
    
    if (timeOneStatus == 0 && lineSetWindowCallTrack == 0 && trackingOn == 1 && (cellLineageNoHold != "" || cellNoHold != "") && addDelInsert == 0 && listToTrackCall == 0 && trackJump == 0 && sliderBarSet == 0){
        xPositionTrack = xCellPosition-imageWidthTrack/2;
        yPositionTrack = (imageHeightTrack-yCellPosition)-imageHeightTrack/2;
    }
    
    if (tableDataSetDone == 2 && lineSetWindowCallTrack == 0 && addDelInsert == 0 && listToTrackCall == 0 && lineAreaCall == 0 && trackJump == 0 && sliderBarSet == 0){
        xPositionTrack = timeOneX-imageWidthTrack/2;
        yPositionTrack = (imageHeightTrack-timeOneY)-imageHeightTrack/2;
    }
    
    if (timeOneStatus == 2 && timeOneLaunch != 0){
        for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
            if (arrayGravityCenterRev [counter1*6+4] == 1){
                xPositionTrack = arrayGravityCenterRev [counter1*6]-imageWidthTrack/2;
                yPositionTrack = (imageHeightTrack-arrayGravityCenterRev [counter1*6+1])-imageHeightTrack/2;
                break;
            }
        }
        
        int connectStatusTemp = arrayTimeSelected [0];
        
        if (connectStatusTemp == 0 || connectStatusTemp == 1 || connectStatusTemp == 7) timeOneConnectStatus = "SXY";
        else if (connectStatusTemp == 2) timeOneConnectStatus = "B";
        else timeOneConnectStatus = "D";
    }
    
    if (lineSetWindowCallTrack == 1 && addDelInsert == 0 && listToTrackCall == 0 && trackJump == 0) lineSetWindowCallTrack = 2;
    
    xPositionAdjustTrack = (imageWidthTrack-imageWidthTrack/(double)(magnificationTrack*0.1))/(double)2;
    yPositionAdjustTrack = (imageHeightTrack-imageHeightTrack/(double)(magnificationTrack*0.1))/(double)2;
    
    if ((trackingOn == 3) && trackingLowerLimit <= imageNumberTrackForDisplay && trackingUpperLimit >= imageNumberTrackForDisplay) trackingPermit = 1;
    else trackingPermit = 0;
    
    //cout<<xCellPosition<<" "<<yCellPosition<<" "<<xPositionTrack<<" "<<yPositionTrack<<" "<<imageWidthTrack<<" "<<imageHeightTrack<<" "<<imageNumberTrackForDisplay<<" "<<imageNumber<<" info2"<<endl;
    
    [self setNeedsDisplay:YES];
}

-(void)mouseDown:(NSEvent *)event{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDownTrack = clickPoint.x;
        yPointDownTrack = clickPoint.y;
        
        if (areaSelectStatus == 1){
            areaSelectStatus = 2;
            xPointDragTrack = xPointDownTrack;
            yPointDragTrack = yPointDownTrack;
        }
        
        if (lineDraw == 1){
            targetCount = 0;
            xPointLine = (int)xPointDownTrack;
            yPointLine = (int)yPointDownTrack;
            lineDraw = 2;
        }
        
        [self setNeedsDisplay:YES];
    }
}

-(void)mouseUp:(NSEvent *)event{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        
        if (lineDraw == 2){
            lineDraw = 1;
            xPointLine = (int)clickPoint.x;
            yPointLine = (int)clickPoint.y;
        }
        
        xPositionTrack = xPositionTrack+xPositionMoveTrack;
        yPositionTrack = yPositionTrack+yPositionMoveTrack;
        xPositionMoveTrack = 0;
        yPositionMoveTrack = 0;
        mouseDragFlag = 0;
        
        if (areaSelectStatus == 2){
            areaSelectStatus = 1;
            tableDataSetDone = 1;
            tableTrackingProcessing = 0;
            trackingTableSetDone = 0;
        }
        
        double xPositionAdjustDouble = xPositionAdjustTrack+xPositionTrack;
        double yPositionAdjustDouble = yPositionAdjustTrack+yPositionTrack;
        double xCalculationValue = 1/(double)windowWidthTrack*magnificationTrack*0.1;
        double yCalculationValue = 1/(double)windowHeightTrack*magnificationTrack*0.1;
        
        int xPointMarkTemp = (int)(clickPoint.x/(double)xCalculationValue+xPositionAdjustDouble);
        int yPointMarkTemp = (int)((clickPoint.y/(double)yCalculationValue+yPositionAdjustDouble-imageHeightTrack)*-1);
        
        if (timeOneStatus == 2){
            
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //	cout<<" arrayTimeSelected "<<counterA<<endl;
            //}
            
            if (yPointMarkTemp >= 0 && yPointMarkTemp < imageDimension && xPointMarkTemp >= 0 && xPointMarkTemp < imageDimension){
                currentConnectNo = revisedWorkingMap [yPointMarkTemp][xPointMarkTemp];
                
                if (timeOneQuickSet != 0 && currentConnectNo != 0){
                    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                        if (arrayTimeSelected [counter1*10+8] == currentConnectNo){
                            if (timeOneQuickSet == 1) arrayTimeSelected [counter1*10] = 7;
                            else if (timeOneQuickSet == 2) arrayTimeSelected [counter1*10] = 1;
                            else if (timeOneQuickSet == 3 && arrayTimeSelected [counter1*10] == 7) arrayTimeSelected [counter1*10] = 6;
                            else if (timeOneQuickSet == 3 && arrayTimeSelected [counter1*10] == 1) arrayTimeSelected [counter1*10] = 5;
                            else if (timeOneQuickSet == 4) arrayTimeSelected [counter1*10] = 2;
                            
                            break;
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                        if (arrayPositionRevise [counter1*7+3] == currentConnectNo && (arrayPositionRevise [counter1*7+5] == 0 || arrayPositionRevise [counter1*7+5] == 1)){
                            arrayPositionRevise [counter1*7+6] = currentConnectNo;
                            
                            if (timeOneQuickSet == 1 || timeOneQuickSet == 2) arrayPositionRevise [counter1*7+5] = 1;
                            else if (timeOneQuickSet == 3 || timeOneQuickSet == 4) arrayPositionRevise [counter1*7+5] = 0;
                            
                            arrayPositionRevise [counter1*7+4] = 0;
                        }
                    }
                }
            }
        }
        
        int listFindFlag = 0;
        
        if (listOnOffFlag == 1){
            if (clickPoint.x > 10 && clickPoint.x < 250){
                int lineFindNumber = -1;
                int firstLinePosition = 645;
                
                for (int counter1 = 0; counter1 < 10; counter1++){
                    if (clickPoint.y >= firstLinePosition && clickPoint.y <= firstLinePosition+10){
                        lineFindNumber = counter1;
                        break;
                    }
                    
                    firstLinePosition = firstLinePosition-20;
                }
                
                if (lineFindNumber != -1 && lineFindNumber < listHoldCount/5){
                    listHoldProcessFlag = lineFindNumber;
                    listFindFlag = 1;
                    forceSetAutoFlag = 0;
                }
            }
        }
        
        if (listFindFlag == 0){
            if (timeOneStatus == 0 && trackingOn == 1 && imageDimension != 0){
                if (revisedWorkingMapStatus2 == 0 || (revisedWorkingMapStatus2 == 1 && revisedWorkingMapSize2 != imageDimension) || (revisedWorkingMapStatus2 == 1 && revisedWorkingMapName2 != treatmentNameHold)){
                    if ((revisedWorkingMapStatus2 == 1 && revisedWorkingMapSize2 != imageDimension) || (revisedWorkingMapStatus2 == 1 && revisedWorkingMapName2 != treatmentNameHold)){
                        for (int counter1 = 0; counter1 < revisedWorkingMapSize2+1; counter1++) delete [] revisedWorkingMap2 [counter1];
                        
                        delete [] revisedWorkingMap2;
                    }
                    
                    revisedWorkingMap2 = new int *[imageDimension+1];
                    
                    for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                        revisedWorkingMap2 [counter1] = new int [imageDimension+1];
                    }
                    
                    if (revisedWorkingMapStatus2 == 1 && revisedWorkingMapName2 != treatmentNameHold) revisedWorkingMapTime2 = 0;
                    
                    revisedWorkingMapSize2 = imageDimension;
                    revisedWorkingMapName2 = treatmentNameHold;
                    revisedWorkingMapStatus2 = 1;
                }
                
                if (yPointMarkTemp >= 0 && yPointMarkTemp < imageDimension && xPointMarkTemp >= 0 && xPointMarkTemp < imageDimension){
                    string extension2 = to_string(imageNumberTrackForDisplay);
                    
                    if (extension2.length() == 1) extension2 = "000"+extension2;
                    else if (extension2.length() == 2) extension2 = "00"+extension2;
                    else if (extension2.length() == 3) extension2 = "0"+extension2;
                    
                    string revisedMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension2+"_"+analysisID+"_"+treatmentNameHold+"_RevisedMap";
                    
                    struct stat sizeOfFile;
                    
                    if (stat(revisedMapPath.c_str(), &sizeOfFile) == 0){
                        if (revisedWorkingMapTime2 != imageNumberTrackForDisplay){
                            revisedWorkingMapTime2 = imageNumberTrackForDisplay;
                            
                            ifstream fin;
                            
                            int readBit [4];
                            int yDimensionCount = 0;
                            int xDimensionCount = 0;
                            int pixData = 0;
                            int sizeTotal = imageDimension*imageDimension*4;
                            
                            fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                uint8_t *upload2 = new uint8_t [sizeTotal+50];
                                fin.read((char*)upload2, sizeTotal);
                                fin.close();
                                
                                yDimensionCount = 0;
                                xDimensionCount = 0;
                                
                                for (int counter1 = 0; counter1 < sizeTotal; counter1 = counter1+4){
                                    readBit [0] = upload2[counter1];
                                    readBit [1] = upload2[counter1+1];
                                    readBit [2] = upload2[counter1+2];
                                    readBit [3] = upload2[counter1+3];
                                    
                                    pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                                    
                                    for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                                        revisedWorkingMap2 [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                                    }
                                    
                                    if (xDimensionCount == imageDimension){
                                        xDimensionCount = 0;
                                        yDimensionCount++;
                                        
                                        if (yDimensionCount == imageDimension){
                                            break;
                                        }
                                    }
                                }
                                
                                delete [] upload2;
                            }
                        }
                        
                        if (revisedWorkingMap2 [yPointMarkTemp][xPointMarkTemp] != 0){
                            quickLineageCall = 1;
                            quickLineageConnect = revisedWorkingMap2 [yPointMarkTemp][xPointMarkTemp];
                        }
                    }
                }
            }
            
            if (timeOneStatus == 0 && trackingOn == 3 && imageDimension != 0){
                quickConnectCall = 1;
                quickLineageConnect = revisedWorkingMap [yPointMarkTemp][xPointMarkTemp];
            }
        }
        
        NSInteger clickCount = [event clickCount];
        
        if (clickCount == 2) doubleClick = 1;
        
        [self setNeedsDisplay:YES];
    }
}

- (void)mouseDragged:(NSEvent *)event{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        
        if (windowLock == 0){
            xPointDragTrack = clickPoint.x;
            yPointDragTrack = clickPoint.y;
            xPositionMoveTrack = (xPointDownTrack-xPointDragTrack)*windowWidthTrack/(double)(magnificationTrack*0.1);
            yPositionMoveTrack = (yPointDownTrack-yPointDragTrack)*windowHeightTrack/(double)(magnificationTrack*0.1);
            mouseDragFlag = 1;
        }
        
        if (lineDraw == 2){
            xPointLine = (int)clickPoint.x;
            yPointLine = (int)clickPoint.y;
        }
        
        if (areaSelectStatus == 2){
            xPointDragTrack = clickPoint.x;
            yPointDragTrack = clickPoint.y;
        }
        
        [self setNeedsDisplay:YES];
    }
}

-(void)keyDown:(NSEvent *)event{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        int keyCode = [event keyCode];
        int firstPintHit = 0;
        int endPointHit = 0;
        
        //cout<<keyCode <<" KeyCode "<<endl;
        
        if (divisionTypeHold == 0 && fusionOperation == 0) cellDivisionSetCount = 0;
        
        int proceedFlag = 0;
        
        //-----Original size "Z"-----
        if (keyCode == 6 && keyLockON == 0){
            xPositionTrack = 0;
            yPositionTrack = 0;
            xPositionAdjustTrack = 0;
            yPositionAdjustTrack = 0;
            magnificationTrack = 10;
            proceedFlag = 1;
        }
        
        //-----Magnification Magnify-----
        if (keyCode == 125){
            if (magnificationTrack >= 12 && magnificationTrack <= 500){
                if (magnificationTrack-10 < 12) magnificationTrack = 10;
                else magnificationTrack = magnificationTrack-10;
                
                proceedFlag = 1;
                xPositionAdjustTrack = -1*(imageWidthTrack/(double)(magnificationTrack*0.1)-imageWidthTrack)/(double)2;
                yPositionAdjustTrack = -1*(imageHeightTrack/(double)(magnificationTrack*0.1)-imageHeightTrack)/(double)2;
            }
        }
        
        //-----Magnification Reduction-----
        if (keyCode == 126){
            if (magnificationTrack >= 10 && magnificationTrack <= 498){
                if (magnificationTrack+10 > 498) magnificationTrack = 498;
                else magnificationTrack = magnificationTrack+10;
                
                proceedFlag = 1;
                xPositionAdjustTrack = (imageWidthTrack-imageWidthTrack/(double)(magnificationTrack*0.1))/(double)2;
                yPositionAdjustTrack = (imageHeightTrack-imageHeightTrack/(double)(magnificationTrack*0.1))/(double)2;
            }
        }
        
        //-----Magnification space bar-----
        if (keyCode == 49){
            proceedFlag = 1;
            magnificationTrack = (int)(200/((double)(50/(double)imageWidthTrack)*700)*10);
            xPositionAdjustTrack = (imageWidthTrack-imageWidthTrack/(double)(magnificationTrack*0.1))/(double)2;
            yPositionAdjustTrack = (imageHeightTrack-imageHeightTrack/(double)(magnificationTrack*0.1))/(double)2;
        }
        
        //-----Select All "S"-----
        if (keyCode == 1 && keyLockON == 0 && areaSelectStatus > 0 && timeOneStatus == 2){
            proceedFlag = 1;
            
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                if (arrayTimeSelected [counter1*10] == 5) arrayTimeSelected [counter1*10] = 1;
                else if (arrayTimeSelected [counter1*10] == 6) arrayTimeSelected [counter1*10] = 7;
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            tableDataSetDone = 1;
            tableTrackingProcessing = 0;
            trackingTableSetDone = 0;
        }
        
        //-----Fluorescent Channel "A"-----
        if (keyCode == 0){
            if (fluorescentDetectionDisplay == 1){
                if ((divisionTypeHold == 0 && fusionOperation == 0 && fusionStatusFollow == 0) || (divisionTypeHold != 0 && cellDivisionSetCount == divisionTypeHold) || (fusionOperation == 1 && fusionStatusFollow == 1)){
                    if (fluorescentDisplayNo == 0 && fluorescentEntryCount > 0){
                        fluorescentDisplayNo = 1;
                        fluorescentValueDisplayControl = 1;
                    }
                    else if (fluorescentDisplayNo == 1 && fluorescentEntryCount > 1){
                        fluorescentDisplayNo = 2;
                        fluorescentValueDisplayControl = 1;
                    }
                    else if (fluorescentDisplayNo == 1 && fluorescentEntryCount == 1) fluorescentDisplayNo = 0;
                    else if (fluorescentDisplayNo == 2 && fluorescentEntryCount > 2){
                        fluorescentDisplayNo = 3;
                        fluorescentValueDisplayControl = 1;
                    }
                    else if (fluorescentDisplayNo == 2 && fluorescentEntryCount == 2) fluorescentDisplayNo = 0;
                    else if (fluorescentDisplayNo == 3 && fluorescentEntryCount > 3){
                        fluorescentDisplayNo = 4;
                        fluorescentValueDisplayControl = 1;
                    }
                    else if (fluorescentDisplayNo == 3 && fluorescentEntryCount == 3) fluorescentDisplayNo = 0;
                    else if (fluorescentDisplayNo == 4 && fluorescentEntryCount > 4){
                        fluorescentDisplayNo = 5;
                        fluorescentValueDisplayControl = 1;
                    }
                    else if (fluorescentDisplayNo == 4 && fluorescentEntryCount == 4) fluorescentDisplayNo = 0;
                    else if (fluorescentDisplayNo == 5 && fluorescentEntryCount > 5){
                        fluorescentDisplayNo = 6;
                        fluorescentValueDisplayControl = 1;
                    }
                    else if (fluorescentDisplayNo == 5 && fluorescentEntryCount == 5) fluorescentDisplayNo = 0;
                    else if (fluorescentDisplayNo == 6 && fluorescentEntryCount == 6) fluorescentDisplayNo = 0;
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        
        //cout<<trackingOn<<" "<<trackingLowerLimit<<" "<<imageNumberTrackForDisplay<<" "<<trackingUpperLimit<<" "<<lineModificationFlag <<" Limit"<<endl;
        
        if (trackingOn == 3 && trackingLowerLimit <= imageNumberTrackForDisplay && trackingUpperLimit >= imageNumberTrackForDisplay && lineModificationFlag == 1 && ifEntry == 0){
            //-----BD "D"-----
            if (keyCode == 2 && keyLockON == 0 && targetLostMark == "" && fluorescentDisplayNo == 0){
                forceSetAutoFlag = 0;
                cellDivisionSetCount = 0;
                divisionTypeHold = 2;
                keyLockON = 1;
                
                eventSet = [[EventSet alloc] init];
                proceedFlag = [eventSet bipolarDivisionSet];
                
                if (proceedFlag == 0){
                    cellDivisionSetCount = 0;
                    divisionTypeHold = 0;
                    keyLockON = 0;
                    proceedFlag = 1;
                }
            }
            
            //-----TD "T"-----
            if (keyCode == 17 && keyLockON == 0 && targetLostMark == "" && fluorescentDisplayNo == 0){
                forceSetAutoFlag = 0;
                cellDivisionSetCount = 0;
                divisionTypeHold = 3;
                keyLockON = 1;
                
                eventSet = [[EventSet alloc] init];
                proceedFlag = [eventSet tripolarDivisionSet];
                
                if (proceedFlag == 0){
                    cellDivisionSetCount = 0;
                    divisionTypeHold = 0;
                    keyLockON = 0;
                    proceedFlag = 1;
                }
            }
            
            //-----HD "H"-----
            if (keyCode == 4 && keyLockON == 0 && targetLostMark == "" && fluorescentDisplayNo == 0){
                forceSetAutoFlag = 0;
                cellDivisionSetCount = 0;
                divisionTypeHold = 4;
                keyLockON = 1;
                
                eventSet = [[EventSet alloc] init];
                proceedFlag = [eventSet tetrapolarDivisionSet];
                
                if (proceedFlag == 0){
                    cellDivisionSetCount = 0;
                    divisionTypeHold = 0;
                    keyLockON = 0;
                    proceedFlag = 1;
                }
            }
            
            //-----M "M"-----
            if (keyCode == 46 && keyLockON == 0 && targetLostMark == "" && timeOneStatus == 0){
                forceSetAutoFlag = 0;
                proceedFlag = 1;
                eventSet = [[EventSet alloc] init];
                [eventSet mitosisSet];
            }
            
            //-----IP "P"-----
            if (keyCode == 35 && keyLockON == 0 && targetLostMark == ""){
                forceSetAutoFlag = 0;
                proceedFlag = 1;
                eventSet = [[EventSet alloc] init];
                [eventSet impartialMitosisSet];
            }
            
            //-----Fusion "F"-----
            if (keyCode == 3 && keyLockON == 0 && targetLostMark == ""){
                forceSetAutoFlag = 0;
                fusionOperation = 1;
                keyLockON = 1;
                
                eventSet = [[EventSet alloc] init];
                proceedFlag = [eventSet cellFusionSet];
                
                if (proceedFlag == 0){
                    fusionOperation = 0;
                    fusionPartnerLin = 0;
                    fusionPartnerCellNo = -1;
                    fusionStatusFollow = 0;
                    keyLockON = 0;
                    proceedFlag = 1;
                }
            }
            
            //-----Fusion Mark "W"-----
            if (keyCode == 13 && keyLockON == 0 && targetLostMark == ""){
                forceSetAutoFlag = 0;
                proceedFlag = 1;
                eventSet = [[EventSet alloc] init];
                [eventSet fusionMarkSet];
            }
            
            //-----CD "E"-----
            if (keyCode == 14 && keyLockON == 0 && targetLostMark == ""){
                forceSetAutoFlag = 0;
                proceedFlag = 1;
                eventSet = [[EventSet alloc] init];
                [eventSet cellDeathSet];
            }
            
            //-----OF "O"-----
            if (keyCode == 31 && keyLockON == 0 && targetLostMark == ""){
                forceSetAutoFlag = 0;
                proceedFlag = 1;
                eventSet = [[EventSet alloc] init];
                [eventSet outOfFrameSet];
            }
            
            //-----Correction "C"-----
            if (keyCode == 8 && keyLockON == 0){
                forceSetAutoFlag = 0;
                proceedFlag = 1;
                eventSet = [[EventSet alloc] init];
                [eventSet correctionSet];
            }
        }
        
        //-----Jump TimeOne "J"-----
        if (keyCode == 38 && keyLockON == 0 && timeOneStatus == 0 && trackingOn == 1){
            forceSetAutoFlag = 0;
            
            imageNumberTrackForDisplay = timeOneHold;
            firstPintHit = 1;
            
            if (ifEntry == 1){
                ifEntry = 0;
                fluorescentNo1 = fluorescentNoHold1;
                fluorescentNo2 = fluorescentNoHold2;
                fluorescentNo3 = fluorescentNoHold3;
                fluorescentNo4 = fluorescentNoHold4;
                fluorescentNo5 = fluorescentNoHold5;
                fluorescentNo6 = fluorescentNoHold6;
                fluorescentEntryCount = fluorescentEntryCountHold;
                fluorescentName1 = fluorescentNameHold1;
                fluorescentName2 = fluorescentNameHold2;
                fluorescentName3 = fluorescentNameHold3;
                fluorescentName4 = fluorescentNameHold4;
                fluorescentName5 = fluorescentNameHold5;
                fluorescentName6 = fluorescentNameHold6;
                
                string extension = to_string(timeOneHold);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                string extension2 = to_string(fluorescentNo1);
                string fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+exType;
                
                struct stat sizeOfFile;
                
                if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0){
                    int matchFind = 0;
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                        if (arrayFluorescentCutOff [counter1*7] == imageNumberTrackForDisplay){
                            fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                            fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                            fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                            fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                            fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                            fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                            matchFind = 1;
                            break;
                        }
                    }
                    
                    if (matchFind == 0){
                        string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
                        
                        if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                            fluorescentCutOff1 = 150;
                            fluorescentCutOff2 = 150;
                            fluorescentCutOff3 = 150;
                            fluorescentCutOff4 = 150;
                            fluorescentCutOff5 = 150;
                            fluorescentCutOff6 = 150;
                            
                            if (fluorescentCutOffStatus == 0){
                                arrayFluorescentCutOff = new int [imageEndHold*7];
                                fluorescentCutOffCount = 0;
                                fluorescentCutOffStatus = 1;
                            }
                            
                            arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            
                            ofstream oin;
                            oin.open(cutOffPath.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                            
                            oin<<"End"<<endl;
                            oin.close();
                        }
                        else{
                            
                            fluorescentCutOff1 = 150;
                            fluorescentCutOff2 = 150;
                            fluorescentCutOff3 = 150;
                            fluorescentCutOff4 = 150;
                            fluorescentCutOff5 = 150;
                            fluorescentCutOff6 = 150;
                            
                            if (fluorescentCutOffStatus == 0){
                                arrayFluorescentCutOff = new int [imageEndHold*7];
                                fluorescentCutOffCount = 0;
                                fluorescentCutOffStatus = 1;
                            }
                            
                            arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            
                            ofstream oin;
                            oin.open(cutOffPath.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                            
                            oin<<"End"<<endl;
                            oin.close();
                        }
                    }
                }
            }
            
            setStatus4 = 4;
        }
        
        //-----Jump TimeEnd "L"-----
        if (keyCode == 37 && keyLockON == 0 && timeOneStatus == 0 && trackingOn == 1){
            forceSetAutoFlag = 0;
            
            if (ifEntry == 0) imageNumberTrackForDisplay = timeEndHold;
            
            endPointHit = 1;
            
            if (ifStartHold != 0 && ifEntry == 1){
                imageNumberTrackForDisplay = imageEndHold;
                
                int nextLoad = 0;
                
                for (int counter1 = 0; counter1 < 450; counter1 = counter1+15){
                    if (atoi(arrayIFDataHold [counter1].c_str()) != 0 && atoi(arrayIFDataHold [counter1+14].c_str()) <= imageNumberTrackForDisplay){
                        nextLoad = counter1/15+1;
                    }
                    else if (atoi(arrayIFDataHold [counter1].c_str()) == 0){
                        break;
                    }
                }
                
                if (nextLoad > 0){
                    nextLoad--;
                    
                    fluorescentNo1 = 0;
                    fluorescentNo2 = 0;
                    fluorescentNo3 = 0;
                    fluorescentNo4 = 0;
                    fluorescentNo5 = 0;
                    fluorescentNo6 = 0;
                    fluorescentEntryCount = 0;
                    fluorescentName1 = "";
                    fluorescentName2 = "";
                    fluorescentName3 = "";
                    fluorescentName4 = "";
                    fluorescentName5 = "";
                    fluorescentName6 = "";
                    
                    fluorescentEntryCount = atoi(arrayIFDataHold [nextLoad*15+13].c_str());
                    fluorescentRoundNo = arrayIFDataHold [nextLoad*15];
                    
                    if (fluorescentEntryCount >= 1){
                        fluorescentNo1 = atoi(arrayIFDataHold [nextLoad*15+7].c_str());
                        fluorescentName1 = arrayIFDataHold [nextLoad*15+1];
                    }
                    
                    if (fluorescentEntryCount >= 2){
                        fluorescentNo2 = atoi(arrayIFDataHold [nextLoad*15+8].c_str());
                        fluorescentName2 = arrayIFDataHold [nextLoad*15+2];
                    }
                    
                    if (fluorescentEntryCount >= 3){
                        fluorescentNo3 = atoi(arrayIFDataHold [nextLoad*15+9].c_str());
                        fluorescentName3 = arrayIFDataHold [nextLoad*15+3];
                    }
                    
                    if (fluorescentEntryCount >= 4){
                        fluorescentNo4 = atoi(arrayIFDataHold [nextLoad*15+10].c_str());
                        fluorescentName4 = arrayIFDataHold [nextLoad*15+4];
                    }
                    
                    if (fluorescentEntryCount >= 5){
                        fluorescentNo5 = atoi(arrayIFDataHold [nextLoad*15+11].c_str());
                        fluorescentName5 = arrayIFDataHold [nextLoad*15+5];
                    }
                    
                    if (fluorescentEntryCount >= 6){
                        fluorescentNo6 = atoi(arrayIFDataHold [nextLoad*15+12].c_str());
                        fluorescentName6 = arrayIFDataHold [nextLoad*15+6];
                    }
                    
                    if (lineModificationFlag == 1 && trackingUpperLimit < imageNumberTrackForDisplay){
                        trackingUpperLimit = imageNumberTrackForDisplay;
                        trackingOnInfoDisplay = 1;
                    }
                }
                
                string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
                
                struct stat sizeOfFile;
                
                if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                    int matchFind = 0;
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                        if (arrayFluorescentCutOff [counter1*7] == imageNumberTrackForDisplay){
                            fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                            fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                            fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                            fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                            fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                            fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                            matchFind = 1;
                            
                            break;
                        }
                    }
                    
                    if (matchFind == 0){
                        int nearestCount = 0;
                        
                        for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                            if (arrayFluorescentCutOff [counter1*7] < imageNumberTrackForDisplay){
                                if (nearestCount < arrayFluorescentCutOff [counter1*7]){
                                    nearestCount = arrayFluorescentCutOff [counter1*7];
                                    fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                    fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                    fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                    fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                                    fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                                    fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                                }
                            }
                        }
                        
                        if (fluorescentCutOffStatus == 0){
                            arrayFluorescentCutOff = new int [imageEndHold*7];
                            fluorescentCutOffCount = 0;
                            fluorescentCutOffStatus = 1;
                        }
                        
                        if (nearestCount != 0){
                            arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
                        }
                        else{
                            
                            arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        }
                        
                        ofstream oin;
                        oin.open(cutOffPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                        
                        oin<<"End"<<endl;
                        oin.close();
                    }
                }
                else{
                    
                    fluorescentCutOff1 = 150;
                    fluorescentCutOff2 = 150;
                    fluorescentCutOff3 = 150;
                    fluorescentCutOff4 = 150;
                    fluorescentCutOff5 = 150;
                    fluorescentCutOff6 = 150;
                    
                    if (fluorescentCutOffStatus == 0){
                        arrayFluorescentCutOff = new int [imageEndHold*7];
                        fluorescentCutOffCount = 0;
                        fluorescentCutOffStatus = 1;
                    }
                    
                    arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    
                    ofstream oin;
                    oin.open(cutOffPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                    
                    oin<<"End"<<endl;
                    oin.close();
                }
                
                fluorescentValueDisplayControl = 1;
                
                if (lineModificationFlag == 1 && trackingUpperLimit < imageNumberTrackForDisplay){
                    trackingUpperLimit = imageNumberTrackForDisplay;
                    trackingOnInfoDisplay = 1;
                }
            }
            
            setStatus4 = 4;
            
            if (ifEntry == 0) fluorescentDisplayNo = 0;
        }
        
        //-----Line Set Short Cut "Q"-----
        if (keyCode == 12 && timeOneStatus == 0 && keyLockON == 0 && trackingOn == 3 && fusionOperation == 0 && divisionTypeHold == 0  && targetLostMark == ""){
            forceSetAutoFlag = 0;
            
            string cellLineageExtract = cellLineageNoHold.substr(1);
            string cellNoExtract = cellNoHold.substr(1);
            int cellLineageTempInt = atoi(cellLineageExtract.c_str());
            int cellNumberTempInt = atoi(cellNoExtract.c_str());
            int connectExpandTemp = 0;
            
            for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt){
                    connectExpandTemp = arrayConnectLineageRel [counter1*6+1];
                    break;
                }
            }
            
            int startPosition = arrayTimeSelected [(connectExpandTemp-1)*10+2]; //====PS
            
            referenceLineCount = 0;
            
            for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                if (arrayPositionRevise [counter1*7+3] == connectExpandTemp){
                    if (referenceLineCount+4 > referenceLineLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate referenceLineCountUpDate];
                    }
                    
                    arrayReferenceLine [referenceLineCount] = arrayPositionRevise [counter1*7], referenceLineCount++;
                    arrayReferenceLine [referenceLineCount] = arrayPositionRevise [counter1*7+1], referenceLineCount++;
                }
                else{
                    
                    break;
                }
            }
            
            int processType = 2;
            lineSet = [[LineSet alloc] init];
            [lineSet lineSetProcess:processType];
        }
        
        //-----Re-do "U"-----
        if (keyCode == 32 && keyLockON == 0 && timeOneStatus == 0 && trackingOn == 3){
            forceSetAutoFlag = 0;
            
            if (autoRefStatus == 0) autoRefStatus = 1;
            else autoRefStatus = 0;
            
            proceedFlag = 1;
        }
        
        //-----Cell set "X"-----
        if (keyCode == 7 && keyLockON == 0 && timeOneStatus == 2){
            if (currentConnectNo != 0){
                int connectCheck = arrayTimeSelected[(currentConnectNo-1)*10];
                int startPosition = 0;
                
                if (connectCheck == 0 || connectCheck == 1 || connectCheck == 7 || connectCheck == 2){
                    startPosition = 0;
                    
                    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                        if (arrayTimeSelected [counter1*10+8] == currentConnectNo){
                            arrayTimeSelected [counter1*10] = 7;
                            startPosition = arrayTimeSelected [counter1*10+2];
                            break;
                        }
                    }
                    
                    for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                        if (arrayPositionRevise [counter1*7+3] == currentConnectNo){
                            arrayPositionRevise [counter1*7+6] = currentConnectNo;
                            arrayPositionRevise [counter1*7+5] = 1;
                            arrayPositionRevise [counter1*7+4] = 0;
                        }
                        else{
                            
                            break;
                        }
                    }
                }
                
                proceedFlag = 1;
            }
            
            timeOneQuickSet = 1;
        }
        
        //-----Jump to Cell Top "X"-----
        if (keyCode == 7 && keyLockON == 0 && timeOneStatus == 0 && trackingOn == 1){
            cellJumpFirstLast = 1;
            forceSetAutoFlag = 0;
        }
        
        //-----Jump to Cell Last "Y"-----
        if (keyCode == 16 && keyLockON == 0 && timeOneStatus == 0 && trackingOn == 1){
            cellJumpFirstLast = 2;
            forceSetAutoFlag = 0;
        }
        
        //-----Jump to Check point "S"-----
        if (keyCode == 1 && keyLockON == 0 && timeOneStatus == 0 && trackingOn == 1){
            cellJumpFirstLast = 3;
            forceSetAutoFlag = 0;
        }
        
        //-----Track Target "S"-----
        if (keyCode == 1 && keyLockON == 0 && timeOneStatus == 2){
            if (currentConnectNo != 0){
                int connectCheck = arrayTimeSelected[(currentConnectNo-1)*10];
                int startPosition = 0;
                
                if (connectCheck == 0 || connectCheck == 1 || connectCheck == 7 || connectCheck == 2){
                    startPosition = 0;
                    
                    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                        if (arrayTimeSelected [counter1*10+8] == currentConnectNo){
                            arrayTimeSelected [counter1*10] = 1;
                            startPosition = arrayTimeSelected [counter1*10+2];
                            break;
                        }
                    }
                    
                    for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                        if (arrayPositionRevise [counter1*7+3] == currentConnectNo){
                            arrayPositionRevise [counter1*7+6] = currentConnectNo;
                            arrayPositionRevise [counter1*7+5] = 1;
                            arrayPositionRevise [counter1*7+4] = 0;
                        }
                        else{
                            
                            break;
                        }
                    }
                }
                
                proceedFlag = 1;
            }
            
            timeOneQuickSet = 2;
        }
        
        //-----Exclude "Y"-----
        if (keyCode == 16 && keyLockON == 0 && timeOneStatus == 2){
            if (currentConnectNo != 0){
                int connectCheck = arrayTimeSelected[(currentConnectNo-1)*10];
                int startPosition = 0;
                
                if (connectCheck == 0 || connectCheck == 1 || connectCheck == 7 || connectCheck == 2){
                    startPosition = 0;
                    
                    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                        if (arrayTimeSelected [counter1*10+8] == currentConnectNo){
                            if (arrayTimeSelected [counter1*10] == 7) arrayTimeSelected [counter1*10] = 6;
                            else if (arrayTimeSelected [counter1*10] == 1) arrayTimeSelected [counter1*10] = 5;
                            else if (arrayTimeSelected [counter1*10] == 2) arrayTimeSelected [counter1*10] = 5;
                            
                            startPosition = arrayTimeSelected [counter1*10+2];
                            break;
                        }
                    }
                    
                    for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                        if (arrayPositionRevise [counter1*7+3] == currentConnectNo){
                            arrayPositionRevise [counter1*7+6] = currentConnectNo;
                            arrayPositionRevise [counter1*7+5] = 0;
                            arrayPositionRevise [counter1*7+4] = 0;
                        }
                        else{
                            
                            break;
                        }
                    }
                }
                
                proceedFlag = 1;
            }
            
            timeOneQuickSet = 3;
        }
        
        //-----Remove "B"-----
        if (keyCode == 11 && keyLockON == 0 && timeOneStatus == 2){
            if (currentConnectNo != 0){
                int connectCheck = arrayTimeSelected[(currentConnectNo-1)*10];
                int startPosition = 0;
                
                if (connectCheck == 0 || connectCheck == 1 || connectCheck == 7 || connectCheck == 2){
                    startPosition = 0;
                    
                    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                        if (arrayTimeSelected [counter1*10+8] == currentConnectNo){
                            arrayTimeSelected [counter1*10] = 2;
                            startPosition = arrayTimeSelected [counter1*10+2];
                            break;
                        }
                    }
                    
                    for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                        if (arrayPositionRevise [counter1*7+3] == currentConnectNo){
                            arrayPositionRevise [counter1*7+6] = currentConnectNo;
                            arrayPositionRevise [counter1*7+5] = 0;
                            arrayPositionRevise [counter1*7+4] = 0;
                        }
                        else{
                            
                            break;
                        }
                    }
                }
                
                proceedFlag = 1;
            }
            
            timeOneQuickSet = 4;
        }
        
        //-----Group Check "G"-----
        if (keyCode == 5 && timeOneStatus == 2){
            int typeSet = 2;
            targetFind2 = [[TargetFind2 alloc] init];
            [targetFind2 interpretationFirst:typeSet];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            proceedFlag = 1;
        }
        
        //-----Line/Area Lock release "V"-----
        if (keyCode == 9 && timeOneStatus == 2){
            if (areaSelectStatus == 1 || lineDraw == 1){
                areaSelectStatus = 0;
                lineDraw = 0;
                windowLock = 0;
            }
            
            proceedFlag = 1;
        }
        
        //-----Merge Group Local "M"-----
        if (keyCode == 46 && timeOneStatus == 2){
            if (currentConnectNo != 0){
                int connectCheck = arrayTimeSelected[(currentConnectNo-1)*10];
                
                if (connectCheck == 0 || connectCheck == 1 || connectCheck == 7 || connectCheck == 2){
                    int connectFindNumber = 0;
                    int groupNoTemp = groupNumberList [currentConnectNo];
                    
                    for (int counter1 = 1; counter1 < groupNumberListCount; counter1++){
                        if (groupNumberList [counter1] == groupNoTemp || groupNumberList [counter1] == groupNoTemp*-1) connectFindNumber++;
                    }
                    
                    if (connectFindNumber > 1){
                        merge = [[Merge alloc] init];
                        [merge mergeMain:groupNoTemp:connectFindNumber];
                        
                        int lineDrawStatus = 0;
                        
                        if (lineDraw == 0){
                            lineDraw = 1;
                            lineDrawStatus = 1;
                        }
                        
                        int processType = 2;
                        lineSet = [[LineSet alloc] init];
                        [lineSet lineSetProcess:processType];
                        
                        if (lineDrawStatus == 1) lineDraw = 0;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                }
            }
        }
        
        //-----Merge Group All "N"-----
        if (keyCode == 45 && timeOneStatus == 2){
            mergeAllFlag = 1;
            
            int lineDrawStatus = 0;
            
            if (lineDraw == 0){
                lineDraw = 1;
                lineDrawStatus = 1;
            }
            
            int connectFindNumber = 0;
            int groupNoTemp = 0;
            int processType = 0;
            
            for (int counter1 = 1; counter1 < groupNumberListCount; counter1++){
                if (groupNumberList [counter1] > 0){
                    connectFindNumber = 0;
                    groupNoTemp = groupNumberList [counter1];
                    
                    for (int counter2 = 1; counter2 < groupNumberListCount; counter2++){
                        if (groupNumberList [counter2] == groupNoTemp || groupNumberList [counter2] == groupNoTemp*-1) connectFindNumber++;
                    }
                    
                    if (connectFindNumber > 1){
                        merge = [[Merge alloc] init];
                        [merge mergeMain:groupNoTemp:connectFindNumber];
                        
                        processType = 2;
                        lineSet = [[LineSet alloc] init];
                        [lineSet lineSetProcess:processType];
                    }
                }
            }
            
            if (lineDrawStatus == 1) lineDraw = 0;
            
            mergeAllFlag = 0;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            proceedFlag = 1;
        }
        
        //-----Merge Connect "C"-----
        if (keyCode == 8 && timeOneStatus == 2){
            if (currentConnectNo != 0){
                int connectCheck = arrayTimeSelected[(currentConnectNo-1)*10];
                
                if (connectCheck == 0 || connectCheck == 1 || connectCheck == 7 || connectCheck == 2){
                    if (currentConnectNo != 0){
                        int lineDrawStatus = 0;
                        
                        if (lineDraw == 0){
                            lineDraw = 1;
                            lineDrawStatus = 1;
                        }
                        
                        merge = [[Merge alloc] init];
                        [merge mergeConnect];
                        
                        if (referenceLineCount != 0){
                            int processType = 2;
                            lineSet = [[LineSet alloc] init];
                            [lineSet lineSetProcess:processType];
                        }
                        
                        if (lineDrawStatus == 1) lineDraw = 0;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                }
            }
        }
        
        //-----Merge Attach "H"-----
        if (keyCode == 4 && timeOneStatus == 2){
            if (currentConnectNo != 0){
                int connectCheck = arrayTimeSelected[(currentConnectNo-1)*10];
                
                if (connectCheck == 0 || connectCheck == 1 || connectCheck == 7 || connectCheck == 2){
                    merge = [[Merge alloc] init];
                    int mergeResult = [merge mergeAttach];
                    
                    if (mergeResult != 0){
                        int lineDrawStatus = 0;
                        
                        if (lineDraw == 0){
                            lineDraw = 1;
                            lineDrawStatus = 1;
                        }
                        
                        int processType = 2;
                        lineSet = [[LineSet alloc] init];
                        [lineSet lineSetProcess:processType];
                        
                        if (lineDrawStatus == 1) lineDraw = 0;
                        
                        mergeAllFlag = 0;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        proceedFlag = 1;
                    }
                }
            }
        }
        
        //-----Extend "I"-----
        if (keyCode == 34 && timeOneStatus == 2){
            if (currentConnectNo != 0){
                int connectCheck = arrayTimeSelected[(currentConnectNo-1)*10];
                
                if (connectCheck == 0 || connectCheck == 1 || connectCheck == 7 || connectCheck == 2){
                    int lineDrawStatus = 0;
                    
                    if (lineDraw == 0){
                        lineDraw = 1;
                        lineDrawStatus = 1;
                    }
                    
                    mergeAllFlag = 1;
                    
                    [self mergeExtend:currentConnectNo];
                    
                    if (lineDrawStatus == 1) lineDraw = 0;
                    
                    mergeAllFlag = 0;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    proceedFlag = 1;
                }
            }
        }
        
        //-----Line set short cut "1"-----
        if (keyCode == 18 && timeOneStatus == 2){
            saveShortCutNumber = 2;
        }
        
        //-----Quick Line Set "="-----
        if (keyCode == 24 && timeOneStatus == 2){
            quickLineSetCall = 2;
        }
        
        //-----Extend "I" Tracking-----
        if (keyCode == 34 && timeOneStatus == 0 && trackingOn == 3){
            forceSetAutoFlag = 0;
            
            if (divisionTypeHold == 0 && fusionOperation == 0 && fluorescentDisplayNo == 0 && targetLostMark == ""){
                string cellLineageExtract = cellLineageNoHold.substr(1);
                string cellNumberExtract = cellNoHold.substr(1);
                int cellLineageTempInt = atoi(cellLineageExtract.c_str());
                int cellNumberTempInt = atoi(cellNumberExtract.c_str());
                int connectExpandTemp = 0;
                
                for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                    if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt){
                        connectExpandTemp = arrayConnectLineageRel [counter1*6+1];
                        break;
                    }
                }
                
                if (connectExpandTemp != 0){
                    int lineDrawStatus = 0;
                    
                    if (lineDraw == 0){
                        lineDraw = 1;
                        lineDrawStatus = 1;
                    }
                    
                    mergeAllFlag = 1;
                    
                    [self mergeExtendTrack:connectExpandTemp];
                    
                    if (lineDrawStatus == 1) lineDraw = 0;
                    
                    mergeAllFlag = 0;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    proceedFlag = 1;
                }
            }
            else if (divisionTypeHold == 0 && fusionOperation == 0 && fluorescentDisplayNo != 0 && targetLostMark == ""){
                string cellLineageExtract = cellLineageNoHold.substr(1);
                string cellNumberExtract = cellNoHold.substr(1);
                int cellLineageTempInt = atoi(cellLineageExtract.c_str());
                int cellNumberTempInt = atoi(cellNumberExtract.c_str());
                int connectExpandTemp = 0;
                
                for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                    if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt){
                        connectExpandTemp = arrayConnectLineageRel [counter1*6+1];
                        break;
                    }
                }
                
                if (connectExpandTemp != 0){
                    int returnResults2 = 0;
                    
                    if (autoExpand == 1){
                        expandLine = [[ExpandLine alloc] init];
                        returnResults2 = [expandLine lineExtendTrackType3:connectExpandTemp];
                    }
                    
                    if (autoExpand == 0 || (autoExpand == 1 && returnResults2 == 1)){
                        int *expandFluorescentOutlineTemp = new int [expandFluorescentOutlineCount+50];
                        int expandFluorescentOutlineTempCount = 0;
                        int *expandFluorescentDataTemp = new int [expandFluorescentDataCount+50];
                        int expandFluorescentDataTempCount = 0;
                        
                        int maxPointDimX = 0;
                        int maxPointDimY = 0;
                        int minPointDimX = 1000000;
                        int minPointDimY = 1000000;
                        
                        if (ifEntry == 0){
                            for (int counter1 = 0; counter1 < expandFluorescentOutlineCount/4; counter1++){
                                if (expandFluorescentOutline [counter1*4+2] != connectExpandTemp || expandFluorescentOutline [counter1*4+3] != fluorescentDisplayNo){
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter1*4], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter1*4+1], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter1*4+2], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter1*4+3], expandFluorescentOutlineTempCount++;
                                }
                            }
                        }
                        else if (ifEntry == 1){
                            for (int counter1 = 0; counter1 < expandFluorescentOutlineCount/4; counter1++){
                                if (expandFluorescentOutline [counter1*4+2] != connectExpandTemp || expandFluorescentOutline [counter1*4+3] != fluorescentDisplayNo+3){
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter1*4], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter1*4+1], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter1*4+2], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter1*4+3], expandFluorescentOutlineTempCount++;
                                }
                            }
                        }
                        
                        int startPosition = arrayTimeSelected [(connectExpandTemp-1)*10+2]; //====PS
                        
                        for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                            if (arrayPositionRevise [counter1*7+3] == connectExpandTemp){
                                expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineTempCount++;
                                expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineTempCount++;
                                expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter1*7+3], expandFluorescentOutlineTempCount++;
                                
                                if (ifEntry == 0) expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = fluorescentDisplayNo, expandFluorescentOutlineTempCount++;
                                else if (ifEntry == 1) expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = fluorescentDisplayNo+6, expandFluorescentOutlineTempCount++;
                                
                                if (maxPointDimX < arrayPositionRevise [counter1*7]) maxPointDimX = arrayPositionRevise [counter1*7]; //====PS
                                if (minPointDimX > arrayPositionRevise [counter1*7]) minPointDimX = arrayPositionRevise [counter1*7];
                                if (maxPointDimY < arrayPositionRevise [counter1*7+1]) maxPointDimY = arrayPositionRevise [counter1*7+1];
                                if (minPointDimY > arrayPositionRevise [counter1*7+1]) minPointDimY = arrayPositionRevise [counter1*7+1];
                            }
                            else{
                                
                                break;
                            }
                        }
                        
                        if (expandFluorescentOutlineStatus == 1) delete [] expandFluorescentOutline;
                        expandFluorescentOutline = new int [expandFluorescentOutlineTempCount+1000];
                        expandFluorescentOutlineCount = 0;
                        expandFluorescentOutlineLimit = expandFluorescentOutlineTempCount+1000;
                        expandFluorescentOutlineStatus = 1;
                        
                        for (int counter1 = 0; counter1 < expandFluorescentOutlineTempCount; counter1++) expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter1], expandFluorescentOutlineCount++;
                        
                        delete [] expandFluorescentOutlineTemp;
                        
                        int pixelValueTemp = 0;
                        int pixelAreaTemp = 0;
                        
                        for (int counterY = minPointDimY; counterY <= maxPointDimY; counterY++){
                            for (int counterX = minPointDimX; counterX <= maxPointDimX; counterX++){
                                if (revisedWorkingMap [counterY][counterX] == connectExpandTemp){
                                    if (fluorescentDisplayNo == 1){
                                        if (fluorescentCutOff1 >= fluorescentMap1 [counterY][counterX]) pixelValueTemp = pixelValueTemp+fluorescentMap1 [counterY][counterX];
                                        pixelAreaTemp++;
                                    }
                                    
                                    if (fluorescentDisplayNo == 2){
                                        if (fluorescentCutOff2 >= fluorescentMap2 [counterY][counterX]) pixelValueTemp = pixelValueTemp+fluorescentMap2 [counterY][counterX];
                                        pixelAreaTemp++;
                                    }
                                    
                                    if (fluorescentDisplayNo == 3){
                                        if (fluorescentCutOff3 >= fluorescentMap3 [counterY][counterX]) pixelValueTemp = pixelValueTemp+fluorescentMap3 [counterY][counterX];
                                        pixelAreaTemp++;
                                    }
                                    
                                    if (fluorescentDisplayNo == 4){
                                        if (fluorescentCutOff4 >= fluorescentMap4 [counterY][counterX]) pixelValueTemp = pixelValueTemp+fluorescentMap4 [counterY][counterX];
                                        pixelAreaTemp++;
                                    }
                                    
                                    if (fluorescentDisplayNo == 5){
                                        if (fluorescentCutOff5 >= fluorescentMap5 [counterY][counterX]) pixelValueTemp = pixelValueTemp+fluorescentMap5 [counterY][counterX];
                                        pixelAreaTemp++;
                                    }
                                    
                                    if (fluorescentDisplayNo == 6){
                                        if (fluorescentCutOff6 >= fluorescentMap6 [counterY][counterX]) pixelValueTemp = pixelValueTemp+fluorescentMap6 [counterY][counterX];
                                        pixelAreaTemp++;
                                    }
                                }
                            }
                        }
                        
                        if (ifEntry == 0){
                            for (int counter1 = 0; counter1 < expandFluorescentDataCount/4; counter1++){
                                if (expandFluorescentData [counter1*4] != connectExpandTemp || expandFluorescentData [counter1*4+1] != fluorescentDisplayNo){
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = expandFluorescentData [counter1*4], expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = expandFluorescentData [counter1*4+1], expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = expandFluorescentData [counter1*4+2], expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = expandFluorescentData [counter1*4+3], expandFluorescentDataTempCount++;
                                }
                            }
                        }
                        
                        if (ifEntry == 1){
                            for (int counter1 = 0; counter1 < expandFluorescentDataCount/4; counter1++){
                                if (expandFluorescentData [counter1*4] != connectExpandTemp || expandFluorescentData [counter1*4+1] != fluorescentDisplayNo+6){
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = expandFluorescentData [counter1*4], expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = expandFluorescentData [counter1*4+1], expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = expandFluorescentData [counter1*4+2], expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = expandFluorescentData [counter1*4+3], expandFluorescentDataTempCount++;
                                }
                            }
                        }
                        
                        if (expandFluorescentDataStatus == 1){
                            expandFluorescentData = new int [expandFluorescentDataTempCount+1000];
                            expandFluorescentDataCount = 0;
                            expandFluorescentDataLimit = expandFluorescentDataTempCount+1000;
                            expandFluorescentDataStatus = 1;
                        }
                        
                        for (int counter1 = 0; counter1 < expandFluorescentDataTempCount; counter1++) expandFluorescentData [expandFluorescentDataCount] = expandFluorescentDataTemp [counter1], expandFluorescentDataCount++;
                        
                        delete [] expandFluorescentDataTemp;
                        
                        double averageArea = pixelValueTemp/(double)pixelAreaTemp;
                        
                        if (expandFluorescentDataCount+20 > expandFluorescentDataLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate expandFluorescentDataUpDate];
                        }
                        
                        expandFluorescentData [expandFluorescentDataCount] = connectExpandTemp, expandFluorescentDataCount++;
                        
                        if (ifEntry == 0) expandFluorescentData [expandFluorescentDataCount] = fluorescentDisplayNo, expandFluorescentDataCount++;
                        else if (ifEntry == 1) expandFluorescentData [expandFluorescentDataCount] = fluorescentDisplayNo+6, expandFluorescentDataCount++;
                        
                        expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                        expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp, expandFluorescentDataCount++;
                    }
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    proceedFlag = 1;
                }
            }
            else if (divisionTypeHold == 0 && fusionOperation == 0 && (int)targetLostMark.find("Lost") != -1){
                if (targetPrevHoldCount != 0){
                    if (targetStatus == 0){
                        arrayTarget = new int [targetPrevHoldCount+500];
                        targetCount = 0;
                        targetLimit = targetPrevHoldCount+500;
                        targetStatus = 1;
                    }
                    
                    targetCount = 0;
                    
                    for (int counter1 = 0; counter1 < targetPrevHoldCount/2; counter1++){
                        arrayTarget [targetCount] = arrayTargetPrevHold [counter1*2], targetCount++;
                        arrayTarget [targetCount] = arrayTargetPrevHold [counter1*2+1], targetCount++;
                    }
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                proceedFlag = 1;
            }
        }
        
        //-----Extend All "K"-----
        if (keyCode == 40 && timeOneStatus == 2){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert addButtonWithTitle:@"Cancel"];
            [alert setMessageText:@"May Need Time (> 3 min)"];
            [alert setAlertStyle:NSAlertStyleWarning];
            
            if ([alert runModal] == NSAlertFirstButtonReturn){
                dicAllStartFlag = 1;
            }
        }
        
        //-----Area reset "W"-----
        if (keyCode == 13 && timeOneStatus == 2){
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                if (arrayTimeSelected [counter1*10] == 5) arrayTimeSelected [counter1*10] = 1;
                else if (arrayTimeSelected [counter1*10] == 6) arrayTimeSelected [counter1*10] = 7;
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            proceedFlag = 1;
        }
        
        //-----Save short cut "`"-----
        if (keyCode == 50 && timeOneStatus == 0 && trackingOn == 3){
            saveShortCutNumber = 1;
        }
        
        //-----Line set short cut "1"-----
        if (keyCode == 18 && timeOneStatus == 0 && trackingOn == 3){
            saveShortCutNumber = 2;
            forceSetAutoFlag = 0;
        }
        
        //-----Save rem/end short cut "2"-----
        if (keyCode == 19 && timeOneStatus == 0 && trackingOn == 3){
            saveShortCutNumber = 3;
        }
        
        //-----Save OK short cut "3"-----
        if (keyCode == 20 && timeOneStatus == 0 && trackingOn == 1){
            saveShortCutNumber = 4;
            forceSetAutoFlag = 0;
        }
        
        //-----Force set "G"-----
        if (keyCode == 5 && timeOneStatus == 0 && trackingOn == 3){
            saveShortCutNumber = 5;
            forceSetAutoFlag = 1;
        }
        
        //-----Merge Selected "B"-----
        if (keyCode == 11 && trackingOn == 3){
            forceSetAutoFlag = 0;
            
            if (mergeSelectCount >= 1){
                int lineDrawStatus = 0;
                
                if (lineDraw == 0){
                    lineDraw = 1;
                    lineDrawStatus = 1;
                }
                
                merge = [[Merge alloc] init];
                [merge mergeSelected];
                
                if (referenceLineCount != 0){
                    int processType = 2;
                    lineSet = [[LineSet alloc] init];
                    [lineSet lineSetProcess:processType];
                }
                
                if (lineDrawStatus == 1) lineDraw = 0;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        
        //-----Quick Line Set "="-----
        if (keyCode == 24 && timeOneStatus == 0 && trackingOn == 1){
            quickLineSetCall = 1;
        }
        
        //-----Image Back-----
        if (keyCode == 123 && timeOneStatus == 0){
            forceSetAutoFlag = 0;
            
            if (imageNumberTrackForDisplay > 1 & imageNumberTrackForDisplay <= imageEndHold){
                if (imageNumberTrackForDisplay-1 < 1){
                    imageNumberTrackForDisplay = 1;
                }
                else imageNumberTrackForDisplay = imageNumberTrackForDisplay-1;
                
                mergeSelectCount = 0;
                
                if (ifStartHold != 0 && ifStartHold-1 == imageNumberTrackForDisplay && ifEntry == 1){
                    ifEntry = 0;
                    fluorescentNo1 = fluorescentNoHold1;
                    fluorescentNo2 = fluorescentNoHold2;
                    fluorescentNo3 = fluorescentNoHold3;
                    fluorescentNo4 = fluorescentNoHold4;
                    fluorescentNo5 = fluorescentNoHold5;
                    fluorescentNo6 = fluorescentNoHold6;
                    fluorescentEntryCount = fluorescentEntryCountHold;
                    fluorescentName1 = fluorescentNameHold1;
                    fluorescentName2 = fluorescentNameHold2;
                    fluorescentName3 = fluorescentNameHold3;
                    fluorescentName4 = fluorescentNameHold4;
                    fluorescentName5 = fluorescentNameHold5;
                    fluorescentName6 = fluorescentNameHold6;
                    
                    string extension = to_string(timeOneHold);
                    
                    if (extension.length() == 1) extension = "000"+extension;
                    else if (extension.length() == 2) extension = "00"+extension;
                    else if (extension.length() == 3) extension = "0"+extension;
                    
                    string extension2 = to_string(fluorescentNo1);
                    
                    string fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+exType;
                    
                    struct stat sizeOfFile;
                    
                    if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0){
                        int matchFind = 0;
                        
                        for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                            if (arrayFluorescentCutOff [counter1*7] == imageNumberTrackForDisplay){
                                fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                                fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                                fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                                matchFind = 1;
                                break;
                            }
                        }
                        
                        if (matchFind == 0){
                            string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
                            
                            if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                                int nearestCount = 0;
                                
                                for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                                    if (arrayFluorescentCutOff [counter1*7] < imageNumberTrackForDisplay){
                                        if (nearestCount < arrayFluorescentCutOff [counter1*7]){
                                            nearestCount = arrayFluorescentCutOff [counter1*7];
                                            fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                            fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                            fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                            fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                                            fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                                            fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                                        }
                                    }
                                }
                                
                                if (fluorescentCutOffStatus == 0){
                                    arrayFluorescentCutOff = new int [imageEndHold*7];
                                    fluorescentCutOffCount = 0;
                                    fluorescentCutOffStatus = 1;
                                }
                                
                                if (nearestCount != 0){
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
                                }
                                else{
                                    
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                }
                                
                                ofstream oin;
                                oin.open(cutOffPath.c_str(), ios::out);
                                
                                for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                                
                                oin<<"End"<<endl;
                                oin.close();
                            }
                            else{
                                
                                fluorescentCutOff1 = 150;
                                fluorescentCutOff2 = 150;
                                fluorescentCutOff3 = 150;
                                fluorescentCutOff4 = 150;
                                fluorescentCutOff5 = 150;
                                fluorescentCutOff6 = 150;
                                
                                if (fluorescentCutOffStatus == 0){
                                    arrayFluorescentCutOff = new int [imageEndHold*7];
                                    fluorescentCutOffCount = 0;
                                    fluorescentCutOffStatus = 1;
                                }
                                
                                arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                
                                ofstream oin;
                                oin.open(cutOffPath.c_str(), ios::out);
                                
                                for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                                
                                oin<<"End"<<endl;
                                oin.close();
                            }
                        }
                    }
                    
                    fluorescentValueDisplayControl = 1;
                }
                else if (ifStartHold != 0 && ifStartHold <= imageNumberTrackForDisplay && ifEntry == 1){
                    int nextLoad = 0;
                    
                    for (int counter1 = 0; counter1 < 450; counter1 = counter1+15){
                        if (atoi(arrayIFDataHold [counter1].c_str()) != 0 && atoi(arrayIFDataHold [counter1+14].c_str()) <= imageNumberTrackForDisplay){
                            nextLoad = counter1/9+1;
                        }
                        else if (atoi(arrayIFDataHold [counter1].c_str()) == 0){
                            break;
                        }
                    }
                    
                    if (nextLoad > 0){
                        nextLoad--;
                        
                        fluorescentNo1 = 0;
                        fluorescentNo2 = 0;
                        fluorescentNo3 = 0;
                        fluorescentNo4 = 0;
                        fluorescentNo5 = 0;
                        fluorescentNo6 = 0;
                        fluorescentEntryCount = 0;
                        fluorescentName1 = "";
                        fluorescentName2 = "";
                        fluorescentName3 = "";
                        fluorescentName4 = "";
                        fluorescentName5 = "";
                        fluorescentName6 = "";
                        
                        fluorescentEntryCount = atoi(arrayIFDataHold [nextLoad*15+13].c_str());
                        fluorescentRoundNo = arrayIFDataHold [nextLoad*15];
                        
                        if (fluorescentEntryCount >= 1){
                            fluorescentNo1 = atoi(arrayIFDataHold [nextLoad*15+7].c_str());
                            fluorescentName1 = arrayIFDataHold [nextLoad*15+1];
                        }
                        
                        if (fluorescentEntryCount >= 2){
                            fluorescentNo2 = atoi(arrayIFDataHold [nextLoad*15+8].c_str());
                            fluorescentName2 = arrayIFDataHold [nextLoad*15+2];
                        }
                        
                        if (fluorescentEntryCount >= 3){
                            fluorescentNo3 = atoi(arrayIFDataHold [nextLoad*15+9].c_str());
                            fluorescentName3 = arrayIFDataHold [nextLoad*15+3];
                        }
                        
                        if (fluorescentEntryCount >= 4){
                            fluorescentNo4 = atoi(arrayIFDataHold [nextLoad*15+10].c_str());
                            fluorescentName4 = arrayIFDataHold [nextLoad*15+4];
                        }
                        
                        if (fluorescentEntryCount >= 5){
                            fluorescentNo5 = atoi(arrayIFDataHold [nextLoad*15+11].c_str());
                            fluorescentName5 = arrayIFDataHold [nextLoad*15+5];
                        }
                        
                        if (fluorescentEntryCount >= 6){
                            fluorescentNo6 = atoi(arrayIFDataHold [nextLoad*15+12].c_str());
                            fluorescentName6 = arrayIFDataHold [nextLoad*15+6];
                        }
                    }
                    
                    string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
                    
                    struct stat sizeOfFile;
                    
                    if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                        int matchFind = 0;
                        
                        for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                            if (arrayFluorescentCutOff [counter1*7] == imageNumberTrackForDisplay){
                                fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+1];
                                fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+2];
                                fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+3];
                                matchFind = 1;
                                
                                break;
                            }
                        }
                        
                        if (matchFind == 0){
                            int nearestCount = 0;
                            
                            for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                                if (arrayFluorescentCutOff [counter1*7] < imageNumberTrackForDisplay){
                                    if (nearestCount < arrayFluorescentCutOff [counter1*7]){
                                        nearestCount = arrayFluorescentCutOff [counter1*7];
                                        fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                        fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                        fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                        fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+1];
                                        fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+2];
                                        fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+3];
                                    }
                                }
                            }
                            
                            if (fluorescentCutOffStatus == 0){
                                arrayFluorescentCutOff = new int [imageEndHold*7];
                                fluorescentCutOffCount = 0;
                                fluorescentCutOffStatus = 1;
                            }
                            
                            if (nearestCount != 0){
                                arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
                            }
                            else{
                                
                                arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            }
                            
                            ofstream oin;
                            oin.open(cutOffPath.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                            
                            oin<<"End"<<endl;
                            oin.close();
                        }
                    }
                    else{
                        
                        fluorescentCutOff1 = 150;
                        fluorescentCutOff2 = 150;
                        fluorescentCutOff3 = 150;
                        fluorescentCutOff4 = 150;
                        fluorescentCutOff5 = 150;
                        fluorescentCutOff6 = 150;
                        
                        if (fluorescentCutOffStatus == 0){
                            arrayFluorescentCutOff = new int [imageEndHold*7];
                            fluorescentCutOffCount = 0;
                            fluorescentCutOffStatus = 1;
                        }
                        
                        arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        
                        ofstream oin;
                        oin.open(cutOffPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                        
                        oin<<"End"<<endl;
                        oin.close();
                    }
                    
                    fluorescentValueDisplayControl = 1;
                }
                
                if (ifEntry == 0) fluorescentDisplayNo = 0;
                
                setStatus4 = 4;
            }
            else if (imageNumberTrackForDisplay-1 == 1) firstPintHit = 1;
        }
        
        //-----Position to the first F-----
        if (keyCode == 3 && timeOneStatus == 2){
            if (currentPositionSet > 0){
                currentPositionSet = 1;
                
                if (arrayTimeSelected [0] == 0 || arrayTimeSelected [0] == 1 || arrayTimeSelected [0] == 2 || arrayTimeSelected [0] == 7){
                    currentConnectNo = currentPositionSet;
                }
                else currentConnectNo = 0;
                
                for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                    if (arrayGravityCenterRev [counter1*6+4] == currentPositionSet){
                        xPositionTrack = arrayGravityCenterRev [counter1*6]-imageWidthTrack/2;
                        yPositionTrack = (imageHeightTrack-arrayGravityCenterRev [counter1*6+1])-imageHeightTrack/2;
                        break;
                    }
                }
                
                proceedFlag = 1;
            }
        }
        
        //-----Position to the last E-----
        if (keyCode == 14 && timeOneStatus == 2){
            if (currentPositionSet > 0){
                currentPositionSet = timeSelectedCount/10;
                
                if (arrayTimeSelected [(currentPositionSet-1)] == 0 || arrayTimeSelected [(currentPositionSet-1)] == 1 || arrayTimeSelected [(currentPositionSet-1)] == 2 || arrayTimeSelected [(currentPositionSet-1)] == 7){
                    currentConnectNo = currentPositionSet;
                }
                else currentConnectNo = 0;
                
                for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                    if (arrayGravityCenterRev [counter1*6+4] == currentPositionSet){
                        xPositionTrack = arrayGravityCenterRev [counter1*6]-imageWidthTrack/2;
                        yPositionTrack = (imageHeightTrack-arrayGravityCenterRev [counter1*6+1])-imageHeightTrack/2;
                        break;
                    }
                }
                
                proceedFlag = 1;
            }
        }
        
        //-----Next List "9"-----
        if (keyCode == 25 && timeOneStatus == 0){
            forceSetAutoFlag = 0;
            
            if (fluorescentDisplayNo == 0 && tableListSwitch == 1 && trackingOn == 1){
                if (tableCurrentRowHold < doneListDisplayCount/5){
                    string treatmentNameStringTemp = arrayDoneListDisplay [tableCurrentRowHold*5];
                    string cellLineageStringTemp = arrayDoneListDisplay [tableCurrentRowHold*5+1];
                    string cellNumberStringTemp = arrayDoneListDisplay [tableCurrentRowHold*5+2];
                    
                    int fileCheck = 0;
                    
                    ifstream fin;
                    
                    string connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageData";
                    string connectDataStatus = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageStatus";
                    string connectDataStatus2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Treat/"+cellLineageStringTemp+"/"+analysisID+"_"+cellLineageStringTemp+"_CellStatus";
                    string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageStartEnd";
                    
                    fin.open(connectDataPath.c_str(), ios::in);
                    if (fin.is_open()) fin.close(), fileCheck++;
                    
                    fin.open(connectDataStatus.c_str(), ios::in);
                    if (fin.is_open()) fin.close(), fileCheck++;
                    
                    fin.open(connectDataStatus2.c_str(), ios::in);
                    if (fin.is_open()) fin.close(), fileCheck++;
                    
                    fin.open(connectStartEndPath.c_str(), ios::in);
                    if (fin.is_open()) fin.close(), fileCheck++;
                    
                    if (fileCheck == 4){
                        string imageNumberLast = "";
                        string imageCheckTime = "";
                        string treatmentNameHoldPrev = treatmentNameHold;
                        
                        treatmentNameHold = arrayDoneListDisplay [tableCurrentRowHold*5];
                        cellLineageNoHold = arrayDoneListDisplay [tableCurrentRowHold*5+1];
                        cellNoHold = arrayDoneListDisplay [tableCurrentRowHold*5+2];
                        
                        imageNumberLast = arrayDoneListDisplay [tableCurrentRowHold*5+3];
                        if ((int)imageNumberLast.find(":") != -1) imageNumberLast = imageNumberLast.substr(0, imageNumberLast.find(":"));
                        
                        imageCheckTime = arrayDoneListDisplay [tableCurrentRowHold*5+3];
                        if ((int)imageCheckTime.find(":") != -1) imageCheckTime = imageCheckTime.substr(imageCheckTime.find(":")+1);
                        
                        if (imageReturnPosition == 0 && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "AX" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "AA" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "AM" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "AXA" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "AXM" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "AAM" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "AXAM" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "BX" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "BA" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "BM" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "BXA" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "BXM" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "BAM" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "BXAM"){
                            imageNumber = atoi(imageNumberLast.c_str());
                            imageReturnPositionSet = 1;
                        }
                        else{
                            
                            imageNumber = atoi(imageCheckTime.c_str());
                            imageReturnPositionSet = 2;
                        }
                        
                        errorInfoFlag = arrayDoneListDisplay [tableCurrentRowHold*5+4];
                        
                        long sizeForCopy = 0;
                        
                        saveInfo = treatmentNameStringTemp;
                        
                        dataSaveRead = [[DataSaveRead alloc] init];
                        [dataSaveRead lineageDataRead];
                        
                        sizeForCopy = 0;
                        
                        struct stat sizeOfFile;
                        
                        if (stat(connectDataStatus.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (cellLineageInfoStatus == 0){
                            arrayCellLineageInfo = new int [sizeForCopy*2+50];
                            cellLineageInfoLimit = (int)sizeForCopy*2+50;
                            cellLineageInfoStatus = 1;
                        }
                        else if (sizeForCopy*2 > cellLineageInfoCount){
                            delete [] arrayCellLineageInfo;
                            arrayCellLineageInfo = new int [sizeForCopy*2+50];
                            cellLineageInfoLimit = (int)sizeForCopy*2+50;
                        }
                        
                        cellLineageInfoCount = 0;
                        
                        fin.open(connectDataStatus.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            char *uploadTemp = new char [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            string dataString = "";
                            int readPosition = 0;
                            
                            do{
                                
                                if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                else if (dataString != "End") arrayCellLineageInfo [cellLineageInfoCount] = atoi(dataString.c_str()), cellLineageInfoCount++, dataString = "";
                                
                                readPosition++;
                                
                            } while (dataString != "End");
                            
                            delete [] uploadTemp;
                        }
                        
                        //for (int counterA = 0; counterA < cellLineageInfoCount/3; counterA++){
                        //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayCellLineageInfo [counterA*3+counterB];
                        //    cout<<" arrayCellLineageInfo "<<counterA<<endl;
                        //}
                        
                        sizeForCopy = 0;
                        
                        if (stat(connectStartEndPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (lineageStartEndStatus == 0){
                            arrayLineageStartEnd = new int [sizeForCopy+50];
                            lineageStartEndLimit = (int)sizeForCopy+50;
                            lineageStartEndStatus = 1;
                        }
                        else if (sizeForCopy > lineageStartEndCount){
                            delete [] arrayLineageStartEnd;
                            arrayLineageStartEnd = new int [sizeForCopy+50];
                            lineageStartEndLimit = (int)sizeForCopy+50;
                        }
                        
                        lineageStartEndCount = 0;
                        
                        fin.open(connectStartEndPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            char *uploadTemp = new char [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            string dataString = "";
                            int readPosition = 0;
                            
                            do{
                                
                                if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                else if (dataString != "End"){
                                    arrayLineageStartEnd [lineageStartEndCount] = atoi(dataString.c_str()), lineageStartEndCount++;
                                    dataString = "";
                                }
                                
                                readPosition++;
                                
                            } while (dataString != "End");
                            
                            delete [] uploadTemp;
                        }
                        
                        sizeForCopy = 0;
                        
                        if (stat(connectDataStatus2.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (cellNumberInfoStatus == 1) delete [] arrayCellNumberInfo;
                        arrayCellNumberInfo = new int [sizeForCopy*2+50];
                        cellNumberInfoCount = 0;
                        cellNumberInfoLimit = (int)sizeForCopy*2+50;
                        cellNumberInfoStatus = 1;
                        
                        fin.open(connectDataStatus2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            char *uploadTemp = new char [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            string dataString = "";
                            int readPosition = 0;
                            
                            do{
                                
                                if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                else if (dataString != "End"){
                                    arrayCellNumberInfo [cellNumberInfoCount] = atoi(dataString.c_str()), cellNumberInfoCount++;
                                    dataString = "";
                                }
                                
                                readPosition++;
                                
                            } while (dataString != "End");
                            
                            delete [] uploadTemp;
                        }
                        
                        //for (int counterA = 0; counterA < cellNumberInfoCount/7; counterA++){
                        //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayCellNumberInfo [counterA*7+counterB];
                        //    cout<<" arrayCellNumberInfo "<<counterA<<endl;
                        //}
                        
                        if (seqOpenFlag == 1 && imageSeqOperation == 1){
                            seqImageFirst = 0;
                            seqImageLast = atoi(imageNumberLast.c_str());
                            seqImageCheck = atoi(imageCheckTime.c_str());
                            seqImageMitosis = 0;
                            seqImageFusionMark = 0;
                            seqImageTop = atoi(imageCheckTime.c_str());
                            
                            seqImageNoSet1 = 0;
                            seqImageNoSet2 = 0;
                            seqImageNoSet3 = 0;
                            seqImageNoSet4 = 0;
                            seqImageNoSet5 = 0;
                            seqImageNoSet6 = 0;
                            seqImageNoSet7 = 0;
                            seqImageNoSet8 = 0;
                            seqImageNoSet9 = 0;
                            seqImageNoSet10 = 0;
                        }
                        
                        setStatus7 = 0;
                        listCrickMonitor = 1;
                        
                        //for (int counterA = 0; counterA < lineageStartEndCount/8; counterA++){
                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageStartEnd [counterA*8 +counterB];
                        //    cout<<" arrayLineageStartEnd "<<counterA<<endl;
                        //}
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                }
            }
            else if (fluorescentDisplayNo == 0 && tableListSwitch == 2 && trackingOn == 1){
                if (tableCurrentRowHold < queueListDisplayCount/6){
                    string treatmentNameStringTemp = arrayQueueListDisplay [tableCurrentRowHold*6];
                    string cellLineageStringTemp = arrayQueueListDisplay [tableCurrentRowHold*6+1];
                    string cellNumberStringTemp = arrayQueueListDisplay [tableCurrentRowHold*6+2];
                    
                    int fileCheck = 0;
                    
                    ifstream fin;
                    
                    string connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageData";
                    string connectDataStatus = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageStatus";
                    string connectDataStatus2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Treat/"+cellLineageStringTemp+"/"+analysisID+"_"+cellLineageStringTemp+"_CellStatus";
                    string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageStartEnd";
                    
                    fin.open(connectDataPath.c_str(), ios::in);
                    if (fin.is_open()) fin.close(), fileCheck++;
                    
                    fin.open(connectDataStatus.c_str(), ios::in);
                    if (fin.is_open()) fin.close(), fileCheck++;
                    
                    fin.open(connectDataStatus2.c_str(), ios::in);
                    if (fin.is_open()) fin.close(), fileCheck++;
                    
                    fin.open(connectDataStatus2.c_str(), ios::in);
                    if (fin.is_open()) fin.close(), fileCheck++;
                    
                    string imageNumberLast = "";
                    string imageCheckTime = "";
                    
                    if (fileCheck == 4){
                        string treatmentNameHoldPrev = treatmentNameHold;
                        
                        treatmentNameHold = arrayQueueListDisplay [tableCurrentRowHold*6];
                        cellLineageNoHold = arrayQueueListDisplay [tableCurrentRowHold*6+1];
                        cellNoHold = arrayQueueListDisplay [tableCurrentRowHold*6+2];
                        
                        imageNumberLast = arrayQueueListDisplay [tableCurrentRowHold*6+3];
                        if ((int)imageNumberLast.find(":") != -1) imageNumberLast = imageNumberLast.substr(0, imageNumberLast.find(":"));
                        
                        imageCheckTime = arrayQueueListDisplay [tableCurrentRowHold*6+3];
                        if ((int)imageCheckTime.find(":") != -1) imageCheckTime = imageCheckTime.substr(imageCheckTime.find(":")+1);
                        
                        if (imageReturnPosition == 0 && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "AX" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "AA" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "AM" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "AXA" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "AXM" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "AAM" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "AXAM" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "BX" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "BA" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "BM" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "BXA" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "BXM" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "BAM" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "BXAM"){
                            imageNumber = atoi(imageNumberLast.c_str());
                            imageReturnPositionSet = 1;
                        }
                        else{
                            
                            imageNumber = atoi(imageCheckTime.c_str());
                            imageReturnPositionSet = 2;
                        }
                        
                        long sizeForCopy = 0;
                        
                        saveInfo = treatmentNameStringTemp;
                        
                        dataSaveRead = [[DataSaveRead alloc] init];
                        [dataSaveRead lineageDataRead];
                        
                        //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
                        //	cout<<" arrayLineageData "<<counterA<<endl;
                        //}
                        
                        struct stat sizeOfFile;
                        
                        sizeForCopy = 0;
                        
                        if (stat(connectDataStatus.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (cellLineageInfoStatus == 0){
                            arrayCellLineageInfo = new int [sizeForCopy*2+50];
                            cellLineageInfoLimit = (int)sizeForCopy*2+50;
                            cellLineageInfoStatus = 1;
                        }
                        else if (sizeForCopy*2 > cellLineageInfoCount){
                            delete [] arrayCellLineageInfo;
                            arrayCellLineageInfo = new int [sizeForCopy*2+50];
                            cellLineageInfoLimit = (int)sizeForCopy*2+50;
                        }
                        
                        cellLineageInfoCount = 0;
                        
                        fin.open(connectDataStatus.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            char *uploadTemp = new char [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            string dataString = "";
                            int readPosition = 0;
                            
                            do{
                                
                                if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                else if (dataString != "End"){
                                    arrayCellLineageInfo [cellLineageInfoCount] = atoi(dataString.c_str()), cellLineageInfoCount++;
                                    dataString = "";
                                }
                                
                                readPosition++;
                                
                            } while (dataString != "End");
                            
                            delete [] uploadTemp;
                        }
                        
                        sizeForCopy = 0;
                        
                        if (stat(connectStartEndPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (lineageStartEndStatus == 0){
                            arrayLineageStartEnd = new int [sizeForCopy+50];
                            lineageStartEndLimit = (int)sizeForCopy+50;
                            lineageStartEndStatus = 1;
                        }
                        else if (sizeForCopy > lineageStartEndCount){
                            delete [] arrayLineageStartEnd;
                            arrayLineageStartEnd = new int [sizeForCopy+50];
                            lineageStartEndLimit = (int)sizeForCopy+50;
                        }
                        
                        lineageStartEndCount = 0;
                        
                        fin.open(connectStartEndPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            char *uploadTemp = new char [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            string dataString = "";
                            int readPosition = 0;
                            
                            do{
                                
                                if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                else if (dataString != "End"){
                                    arrayLineageStartEnd [lineageStartEndCount] = atoi(dataString.c_str()), lineageStartEndCount++;
                                    dataString = "";
                                }
                                
                                readPosition++;
                                
                            } while (dataString != "End");
                            
                            delete [] uploadTemp;
                        }
                        
                        sizeForCopy = 0;
                        
                        if (stat(connectDataStatus2.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (cellNumberInfoStatus == 1) delete [] arrayCellNumberInfo;
                        arrayCellNumberInfo = new int [sizeForCopy*2+50];
                        cellNumberInfoCount = 0;
                        cellNumberInfoLimit = (int)sizeForCopy*2+50;
                        cellNumberInfoStatus = 1;
                        
                        fin.open(connectDataStatus2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            char *uploadTemp = new char [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            string dataString = "";
                            int readPosition = 0;
                            
                            do{
                                
                                if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                else if (dataString != "End"){
                                    arrayCellNumberInfo [cellNumberInfoCount] = atoi(dataString.c_str()), cellNumberInfoCount++;
                                    dataString = "";
                                }
                                
                                readPosition++;
                                
                            } while (dataString != "End");
                            
                            delete [] uploadTemp;
                        }
                        
                        //for (int counterA = 0; counterA < cellNumberInfoCount/7; counterA++){
                        //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayCellNumberInfo [counterA*7+counterB];
                        //    cout<<" arrayCellNumberInfo "<<counterA<<endl;
                        //}
                        
                        if (seqOpenFlag == 1 && imageSeqOperation == 1){
                            seqImageFirst = 0;
                            seqImageLast = atoi(imageNumberLast.c_str());
                            seqImageCheck = atoi(imageCheckTime.c_str());
                            seqImageMitosis = 0;
                            seqImageFusionMark = 0;
                            seqImageTop = atoi(imageCheckTime.c_str());
                            
                            seqImageNoSet1 = 0;
                            seqImageNoSet2 = 0;
                            seqImageNoSet3 = 0;
                            seqImageNoSet4 = 0;
                            seqImageNoSet5 = 0;
                            seqImageNoSet6 = 0;
                            seqImageNoSet7 = 0;
                            seqImageNoSet8 = 0;
                            seqImageNoSet9 = 0;
                            seqImageNoSet10 = 0;
                        }
                        
                        setStatus7 = 0;
                        errorInfoFlag = "nil";
                        listCrickMonitor = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                }
            }
            else if (fluorescentDivisionStatus == 1 && fluorescentDivisionTime == imageNumberTrackForDisplay && ((fluorescentDivisionTime < ifStartHold && fluorescentDivisionCh == fluorescentDisplayNo) || (fluorescentDivisionTime >= ifStartHold && fluorescentDivisionCh-6 == fluorescentDisplayNo)) && tableListSwitch == 2 && trackingOn == 1){
                if (tableCurrentRowHold+1 < queueListDisplayCount/6){
                    tableCurrentRowHold++;
                    
                    int skipCount = 0;
                    int matchFind = 0;
                    
                    for (int counter1 = tableCurrentRowHold; counter1 < queueListDisplayCount/6; counter1++){
                        if (atoi(arrayQueueListDisplay [counter1*6+3].substr(0, arrayQueueListDisplay [counter1*6+3].find(":")).c_str()) >= imageNumberTrackForDisplay){
                            matchFind = 1;
                            break;
                        }
                        else skipCount++;
                    }
                    
                    if (matchFind == 1 && skipCount != 0) tableCurrentRowHold = tableCurrentRowHold+skipCount;
                    
                    //for (int counterA = 0; counterA < queueListDisplayCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueListDisplay [counterA*6+counterB];
                    //    cout<<" arrayQueueListDisplay "<<counterA<<endl;
                    //}
                    
                    if (matchFind != 0){
                        string treatmentNameStringTemp = arrayQueueListDisplay [tableCurrentRowHold*6];
                        string cellLineageStringTemp = arrayQueueListDisplay [tableCurrentRowHold*6+1];
                        string cellNumberStringTemp = arrayQueueListDisplay [tableCurrentRowHold*6+2];
                        
                        int fileCheck = 0;
                        
                        ifstream fin;
                        
                        string connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageData";
                        string connectDataStatus = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageStatus";
                        string connectDataStatus2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Treat/"+cellLineageStringTemp+"/"+analysisID+"_"+cellLineageStringTemp+"_CellStatus";
                        string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageStartEnd";
                        
                        fin.open(connectDataPath.c_str(), ios::in);
                        if (fin.is_open()) fin.close(), fileCheck++;
                        
                        fin.open(connectDataStatus.c_str(), ios::in);
                        if (fin.is_open()) fin.close(), fileCheck++;
                        
                        fin.open(connectDataStatus2.c_str(), ios::in);
                        if (fin.is_open()) fin.close(), fileCheck++;
                        
                        fin.open(connectDataStatus2.c_str(), ios::in);
                        if (fin.is_open()) fin.close(), fileCheck++;
                        
                        string imageNumberLast = "";
                        string imageCheckTime = "";
                        
                        if (fileCheck == 4){
                            string treatmentNameHoldPrev = treatmentNameHold;
                            
                            treatmentNameHold = arrayQueueListDisplay [tableCurrentRowHold*6];
                            cellLineageNoHold = arrayQueueListDisplay [tableCurrentRowHold*6+1];
                            cellNoHold = arrayQueueListDisplay [tableCurrentRowHold*6+2];
                            
                            if (imageReturnPosition == 0){
                                imageNumber = fluorescentDivisionTime;
                                imageReturnPositionSet = 1;
                            }
                            else{
                                
                                imageNumber = fluorescentDivisionTime;
                                imageReturnPositionSet = 2;
                            }
                            
                            long sizeForCopy = 0;
                            
                            saveInfo = treatmentNameStringTemp;
                            
                            dataSaveRead = [[DataSaveRead alloc] init];
                            [dataSaveRead lineageDataRead];
                            
                            struct stat sizeOfFile;
                            
                            sizeForCopy = 0;
                            
                            if (stat(connectDataStatus.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            if (cellLineageInfoStatus == 0){
                                arrayCellLineageInfo = new int [sizeForCopy*2+50];
                                cellLineageInfoLimit = (int)sizeForCopy*2+50;
                                cellLineageInfoStatus = 1;
                            }
                            else if (sizeForCopy*2 > cellLineageInfoCount){
                                delete [] arrayCellLineageInfo;
                                arrayCellLineageInfo = new int [sizeForCopy*2+50];
                                cellLineageInfoLimit = (int)sizeForCopy*2+50;
                            }
                            
                            cellLineageInfoCount = 0;
                            
                            fin.open(connectDataStatus.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                char *uploadTemp = new char [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                string dataString = "";
                                int readPosition = 0;
                                
                                do{
                                    
                                    if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                    else if (dataString != "End"){
                                        arrayCellLineageInfo [cellLineageInfoCount] = atoi(dataString.c_str()), cellLineageInfoCount++;
                                        dataString = "";
                                    }
                                    
                                    readPosition++;
                                    
                                } while (dataString != "End");
                                
                                delete [] uploadTemp;
                            }
                            
                            //for (int counterA = 0; counterA < cellLineageInfoCount/3; counterA++){
                            //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayCellLineageInfo [counterA*3+counterB];
                            //	cout<<" arrayCellLineageInfo "<<counterA<<endl;
                            //}
                            
                            sizeForCopy = 0;
                            
                            if (stat(connectStartEndPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            if (lineageStartEndStatus == 0){
                                arrayLineageStartEnd = new int [sizeForCopy+50];
                                lineageStartEndLimit = (int)sizeForCopy+50;
                                lineageStartEndStatus = 1;
                            }
                            else if (sizeForCopy > lineageStartEndCount){
                                delete [] arrayLineageStartEnd;
                                arrayLineageStartEnd = new int [sizeForCopy+50];
                                lineageStartEndLimit = (int)sizeForCopy+50;
                            }
                            
                            lineageStartEndCount = 0;
                            
                            fin.open(connectStartEndPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                char *uploadTemp = new char [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                string dataString = "";
                                int readPosition = 0;
                                
                                do{
                                    
                                    if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                    else if (dataString != "End"){
                                        arrayLineageStartEnd [lineageStartEndCount] = atoi(dataString.c_str()), lineageStartEndCount++;
                                        dataString = "";
                                    }
                                    
                                    readPosition++;
                                    
                                } while (dataString != "End");
                                
                                delete [] uploadTemp;
                            }
                            
                            sizeForCopy = 0;
                            
                            if (stat(connectDataStatus2.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            if (cellNumberInfoStatus == 1) delete [] arrayCellNumberInfo;
                            arrayCellNumberInfo = new int [sizeForCopy*2+50];
                            cellNumberInfoCount = 0;
                            cellNumberInfoLimit = (int)sizeForCopy*2+50;
                            cellNumberInfoStatus = 1;
                            
                            fin.open(connectDataStatus2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                char *uploadTemp = new char [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                string dataString = "";
                                int readPosition = 0;
                                
                                do{
                                    
                                    if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                    else if (dataString != "End"){
                                        arrayCellNumberInfo [cellNumberInfoCount] = atoi(dataString.c_str()), cellNumberInfoCount++;
                                        dataString = "";
                                    }
                                    
                                    readPosition++;
                                    
                                } while (dataString != "End");
                                
                                delete [] uploadTemp;
                            }
                            
                            string cellLineageExtract = cellLineageNoHold.substr(1);
                            string cellNoExtract = cellNoHold.substr(1);
                            int lineageAmendTemp = atoi(cellLineageExtract.c_str());
                            int cellAmendTemp = atoi(cellNoExtract.c_str());
                            int connectFluorescentLevel = 0;
                            
                            for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                                if (arrayConnectLineageRel [counter1*6] == lineageAmendTemp && arrayConnectLineageRel [counter1*6+3] == cellAmendTemp){
                                    connectFluorescentLevel = arrayConnectLineageRel [counter1*6+1];
                                    break;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < fluorescentLevelDataCount/4; counter1++){
                                if (fluorescentLevelDataHold [counter1*4] == connectFluorescentLevel && fluorescentLevelDataHold [counter1*4+1] == fluorescentDivisionCh){
                                    fluorescentLevelValueHold = fluorescentLevelDataHold [counter1*4+2];
                                    
                                    break;
                                }
                            }
                            
                            errorInfoFlag = "nil";
                            listCrickMonitor = 1;
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                    }
                }
            }
        }
        
        //-----Move image seq window top-----
        if (keyCode == 29 && timeOneStatus == 0 && trackingOn != 0 && seqOpenFlag == 1 && imageSeqOperation == 1){
            seqWindowFront = 1;
        }
        
        //-----Fluorescent level set 0 "4"-----
        if (keyCode == 21 && timeOneStatus == 0){
            if (fluorescentDivisionStatus == 1 && fluorescentDivisionTime == imageNumberTrackForDisplay && ((fluorescentDivisionTime <= timeEndHold && fluorescentDivisionCh == fluorescentDisplayNo) || (fluorescentDivisionTime > timeEndHold && fluorescentDivisionCh-6 == fluorescentDisplayNo)) && trackingOn == 1 && fluorescentDivisionNo != 0){
                string cellLineageExtract = cellLineageNoHold.substr(1);
                string cellNoExtract = cellNoHold.substr(1);
                int lineageAmendTemp = atoi(cellLineageExtract.c_str());
                int cellAmendTemp = atoi(cellNoExtract.c_str());
                
                string extension = to_string(fluorescentDivisionTime);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                string connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
                
                struct stat sizeOfFile;
                
                long sizeForCopy = 0;
                
                if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                int *arrayConnectLineageRelLevel = new int [sizeForCopy+50];
                int connectLineageRelLevelCount = 0;
                
                ifstream fin;
                
                fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    int finData [19];
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                            finData [3] = uploadTemp [readPosition], readPosition++;
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                            finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++;
                            finData [11] = uploadTemp [readPosition], readPosition++;
                            finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                            finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                            finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                            finData [7] = finData [6]*256+finData [7];
                            
                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                            
                            if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                            else{
                                
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [2], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [5], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [7], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [12], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [13], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [14], connectLineageRelLevelCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
                
                int connectFluorescentLevel = 0;
                
                for (int counter1 = 0; counter1 < connectLineageRelLevelCount/6; counter1++){
                    if (arrayConnectLineageRelLevel [counter1*6] == lineageAmendTemp && arrayConnectLineageRelLevel [counter1*6+3] == cellAmendTemp){
                        connectFluorescentLevel = arrayConnectLineageRelLevel [counter1*6+1];
                        break;
                    }
                }
                
                delete [] arrayConnectLineageRelLevel;
                
                int findFlag = 0;
                
                for (int counter1 = 0; counter1 < fluorescentLevelDataCount/4; counter1++){
                    if (fluorescentLevelDataHold [counter1*4] == connectFluorescentLevel && fluorescentLevelDataHold [counter1*4+1] == fluorescentDivisionCh){
                        fluorescentLevelDataHold [counter1*4+2] = 0;
                        fluorescentLevelValueHold = 0;
                        fluorescentSaveCount++;
                        
                        break;
                    }
                }
                
                if (findFlag == 0 && connectFluorescentLevel != 0){
                    if (fluorescentLevelDataCount+10 > fluorescentLevelDataLimit){
                        int *arrayUpDate = new int [fluorescentLevelDataCount+10];
                        
                        for (int counter1 = 0; counter1 < fluorescentLevelDataCount; counter1++) arrayUpDate [counter1] = fluorescentLevelDataHold [counter1];
                        
                        delete [] fluorescentLevelDataHold;
                        fluorescentLevelDataHold = new int [fluorescentLevelDataLimit+10000];
                        fluorescentLevelDataLimit = fluorescentLevelDataLimit+10000;
                        
                        for (int counter1 = 0; counter1 < fluorescentLevelDataCount; counter1++) fluorescentLevelDataHold [counter1] = arrayUpDate [counter1];
                        delete [] arrayUpDate;
                    }
                    
                    fluorescentLevelDataHold [fluorescentLevelDataCount] = connectFluorescentLevel, fluorescentLevelDataCount++;
                    fluorescentLevelDataHold [fluorescentLevelDataCount] = fluorescentDivisionCh, fluorescentLevelDataCount++;
                    fluorescentLevelDataHold [fluorescentLevelDataCount] = 0, fluorescentLevelDataCount++;
                    fluorescentLevelDataHold [fluorescentLevelDataCount] = 0, fluorescentLevelDataCount++;
                    
                    fluorescentSaveCount++;
                }
                
                if (fluorescentSaveCount == 200){
                    fluorescentSaveCount = 0;
                    
                    if (fluorescentLevelDataCount != 0){
                        int readBit [3];
                        int dataTemp = 0;
                        unsigned long indexCount = 0;
                        
                        char *writingArray = new char [fluorescentLevelDataCount*2+20];
                        
                        for (int counter1 = 0; counter1 < fluorescentLevelDataCount/4; counter1++){
                            dataTemp = fluorescentLevelDataHold [counter1*4];
                            
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            writingArray [indexCount] = (char)fluorescentLevelDataHold [counter1*4+1], indexCount++;
                            writingArray [indexCount] = (char)fluorescentLevelDataHold [counter1*4+2], indexCount++;
                            
                            dataTemp = fluorescentLevelDataHold [counter1*4+3];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                        }
                        
                        for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                        
                        ofstream outfile2 (fluorescentSavePath.c_str(), ofstream::binary);
                        outfile2.write ((char*)writingArray, indexCount);
                        outfile2.close();
                        
                        delete [] writingArray;
                    }
                }
                
                proceedFlag = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        
        //-----Fluorescent level set 100/50//33/25 "5"-----
        if (keyCode == 23 && timeOneStatus == 0){
            if (fluorescentDivisionStatus == 1 && fluorescentDivisionTime == imageNumberTrackForDisplay && ((fluorescentDivisionTime <= timeEndHold && fluorescentDivisionCh == fluorescentDisplayNo) || (fluorescentDivisionTime > timeEndHold && fluorescentDivisionCh-6 == fluorescentDisplayNo)) && trackingOn == 1 && fluorescentDivisionNo != 0){
                string cellLineageExtract = cellLineageNoHold.substr(1);
                string cellNoExtract = cellNoHold.substr(1);
                int lineageAmendTemp = atoi(cellLineageExtract.c_str());
                int cellAmendTemp = atoi(cellNoExtract.c_str());
                
                string extension = to_string(fluorescentDivisionTime);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                string connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
                
                struct stat sizeOfFile;
                
                long sizeForCopy = 0;
                
                if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                int *arrayConnectLineageRelLevel = new int [sizeForCopy+50];
                int connectLineageRelLevelCount = 0;
                
                ifstream fin;
                
                fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    int finData [19];
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                            finData [3] = uploadTemp [readPosition], readPosition++;
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                            finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++;
                            finData [11] = uploadTemp [readPosition], readPosition++;
                            finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                            finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                            finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                            finData [7] = finData [6]*256+finData [7];
                            
                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                            
                            if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                            else{
                                
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [2], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [5], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [7], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [12], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [13], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [14], connectLineageRelLevelCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
                
                int connectFluorescentLevel = 0;
                
                for (int counter1 = 0; counter1 < connectLineageRelLevelCount/6; counter1++){
                    if (arrayConnectLineageRelLevel [counter1*6] == lineageAmendTemp && arrayConnectLineageRelLevel [counter1*6+3] == cellAmendTemp){
                        connectFluorescentLevel = arrayConnectLineageRelLevel [counter1*6+1];
                        break;
                    }
                }
                
                delete [] arrayConnectLineageRelLevel;
                
                int findFlag = 0;
                
                for (int counter1 = 0; counter1 < fluorescentLevelDataCount/4; counter1++){
                    if (fluorescentLevelDataHold [counter1*4] == connectFluorescentLevel && fluorescentLevelDataHold [counter1*4+1] == fluorescentDivisionCh){
                        if (fluorescentDivisionNo == 1){
                            fluorescentLevelDataHold [counter1*4+2] = 100;
                            fluorescentLevelValueHold = 100;
                        }
                        else if (fluorescentDivisionNo == 2){
                            fluorescentLevelDataHold [counter1*4+2] = 50;
                            fluorescentLevelValueHold = 50;
                        }
                        else if (fluorescentDivisionNo == 3){
                            fluorescentLevelDataHold [counter1*4+2] = 33;
                            fluorescentLevelValueHold = 33;
                        }
                        else if (fluorescentDivisionNo == 4){
                            fluorescentLevelDataHold [counter1*4+2] = 25;
                            fluorescentLevelValueHold = 25;
                        }
                        
                        fluorescentSaveCount++;
                        findFlag = 1;
                        
                        break;
                    }
                }
                
                if (findFlag == 0 && connectFluorescentLevel != 0){
                    if (fluorescentLevelDataCount+10 > fluorescentLevelDataLimit){
                        int *arrayUpDate = new int [fluorescentLevelDataCount+10];
                        
                        for (int counter1 = 0; counter1 < fluorescentLevelDataCount; counter1++) arrayUpDate [counter1] = fluorescentLevelDataHold [counter1];
                        
                        delete [] fluorescentLevelDataHold;
                        fluorescentLevelDataHold = new int [fluorescentLevelDataLimit+10000];
                        fluorescentLevelDataLimit = fluorescentLevelDataLimit+10000;
                        
                        for (int counter1 = 0; counter1 < fluorescentLevelDataCount; counter1++) fluorescentLevelDataHold [counter1] = arrayUpDate [counter1];
                        delete [] arrayUpDate;
                    }
                    
                    fluorescentLevelDataHold [fluorescentLevelDataCount] = connectFluorescentLevel, fluorescentLevelDataCount++;
                    fluorescentLevelDataHold [fluorescentLevelDataCount] = fluorescentDivisionCh, fluorescentLevelDataCount++;
                    
                    if (fluorescentDivisionNo == 1){
                        fluorescentLevelDataHold [fluorescentLevelDataCount] = 100, fluorescentLevelDataCount++;
                        fluorescentLevelDataHold [fluorescentLevelDataCount] = 100, fluorescentLevelDataCount++;
                        fluorescentLevelValueHold = 100;
                    }
                    else if (fluorescentDivisionNo == 2){
                        fluorescentLevelDataHold [fluorescentLevelDataCount] = 50, fluorescentLevelDataCount++;
                        fluorescentLevelDataHold [fluorescentLevelDataCount] = 50, fluorescentLevelDataCount++;
                        fluorescentLevelValueHold = 50;
                    }
                    else if (fluorescentDivisionNo == 3){
                        fluorescentLevelDataHold [fluorescentLevelDataCount] = 33, fluorescentLevelDataCount++;
                        fluorescentLevelDataHold [fluorescentLevelDataCount] = 33, fluorescentLevelDataCount++;
                        fluorescentLevelValueHold = 33;
                    }
                    else if (fluorescentDivisionNo == 4){
                        fluorescentLevelDataHold [fluorescentLevelDataCount] = 25, fluorescentLevelDataCount++;
                        fluorescentLevelDataHold [fluorescentLevelDataCount] = 25, fluorescentLevelDataCount++;
                        fluorescentLevelValueHold = 25;
                    }
                    
                    fluorescentSaveCount++;
                }
                
                //for (int counterA = 0; counterA < fluorescentLevelDataCount/4; counterA++){
                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<fluorescentLevelDataHold [counterA*4+counterB];
                //    cout<<" fluorescentLevelDataHold "<<counterA<<endl;
                //}
                
                if (fluorescentSaveCount == 200){
                    fluorescentSaveCount = 0;
                    
                    if (fluorescentLevelDataCount != 0){
                        int readBit [3];
                        int dataTemp = 0;
                        unsigned long indexCount = 0;
                        
                        char *writingArray = new char [fluorescentLevelDataCount*2+20];
                        
                        for (int counter1 = 0; counter1 < fluorescentLevelDataCount/4; counter1++){
                            dataTemp = fluorescentLevelDataHold [counter1*4];
                            
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            writingArray [indexCount] = (char)fluorescentLevelDataHold [counter1*4+1], indexCount++;
                            writingArray [indexCount] = (char)fluorescentLevelDataHold [counter1*4+2], indexCount++;
                            
                            dataTemp = fluorescentLevelDataHold [counter1*4+3];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                        }
                        
                        for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                        
                        ofstream outfile2 (fluorescentSavePath.c_str(), ofstream::binary);
                        outfile2.write ((char*)writingArray, indexCount);
                        outfile2.close();
                        
                        delete [] writingArray;
                    }
                }
                
                proceedFlag = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        
        //-----Fluorescent level set 100/66/50 "6"-----
        if (keyCode == 22 && timeOneStatus == 0){
            if (fluorescentDivisionStatus == 1 && fluorescentDivisionTime == imageNumberTrackForDisplay && ((fluorescentDivisionTime <= timeEndHold && fluorescentDivisionCh == fluorescentDisplayNo) || (fluorescentDivisionTime > timeEndHold && fluorescentDivisionCh-6 == fluorescentDisplayNo)) && trackingOn == 1 && fluorescentDivisionNo >= 2){
                string cellLineageExtract = cellLineageNoHold.substr(1);
                string cellNoExtract = cellNoHold.substr(1);
                int lineageAmendTemp = atoi(cellLineageExtract.c_str());
                int cellAmendTemp = atoi(cellNoExtract.c_str());
                
                string extension = to_string(fluorescentDivisionTime);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                string connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
                
                struct stat sizeOfFile;
                
                long sizeForCopy = 0;
                
                if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                int *arrayConnectLineageRelLevel = new int [sizeForCopy+50];
                int connectLineageRelLevelCount = 0;
                
                ifstream fin;
                
                fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    int finData [19];
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                            finData [3] = uploadTemp [readPosition], readPosition++;
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                            finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++;
                            finData [11] = uploadTemp [readPosition], readPosition++;
                            finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                            finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                            finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                            finData [7] = finData [6]*256+finData [7];
                            
                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                            
                            if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                            else{
                                
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [2], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [5], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [7], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [12], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [13], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [14], connectLineageRelLevelCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
                
                int connectFluorescentLevel = 0;
                
                for (int counter1 = 0; counter1 < connectLineageRelLevelCount/6; counter1++){
                    if (arrayConnectLineageRelLevel [counter1*6] == lineageAmendTemp && arrayConnectLineageRelLevel [counter1*6+3] == cellAmendTemp){
                        connectFluorescentLevel = arrayConnectLineageRelLevel [counter1*6+1];
                        break;
                    }
                }
                
                delete [] arrayConnectLineageRelLevel;
                
                int findFlag = 0;
                
                for (int counter1 = 0; counter1 < fluorescentLevelDataCount/4; counter1++){
                    if (fluorescentLevelDataHold [counter1*4] == connectFluorescentLevel && fluorescentLevelDataHold [counter1*4+1] == fluorescentDivisionCh){
                        if (fluorescentDivisionNo == 2){
                            fluorescentLevelDataHold [counter1*4+2] = 100;
                            fluorescentLevelValueHold = 100;
                        }
                        else if (fluorescentDivisionNo == 3){
                            fluorescentLevelDataHold [counter1*4+2] = 66;
                            fluorescentLevelValueHold = 66;
                        }
                        else if (fluorescentDivisionNo == 4){
                            fluorescentLevelDataHold [counter1*4+2] = 50;
                            fluorescentLevelValueHold = 50;
                        }
                        
                        fluorescentSaveCount++;
                        findFlag = 1;
                        
                        break;
                    }
                }
                
                if (findFlag == 0 && connectFluorescentLevel != 0){
                    if (fluorescentLevelDataCount+10 > fluorescentLevelDataLimit){
                        int *arrayUpDate = new int [fluorescentLevelDataCount+10];
                        
                        for (int counter1 = 0; counter1 < fluorescentLevelDataCount; counter1++) arrayUpDate [counter1] = fluorescentLevelDataHold [counter1];
                        
                        delete [] fluorescentLevelDataHold;
                        fluorescentLevelDataHold = new int [fluorescentLevelDataLimit+10000];
                        fluorescentLevelDataLimit = fluorescentLevelDataLimit+10000;
                        
                        for (int counter1 = 0; counter1 < fluorescentLevelDataCount; counter1++) fluorescentLevelDataHold [counter1] = arrayUpDate [counter1];
                        delete [] arrayUpDate;
                    }
                    
                    fluorescentLevelDataHold [fluorescentLevelDataCount] = connectFluorescentLevel, fluorescentLevelDataCount++;
                    fluorescentLevelDataHold [fluorescentLevelDataCount] = fluorescentDivisionCh, fluorescentLevelDataCount++;
                    
                    if (fluorescentDivisionNo == 2){
                        fluorescentLevelDataHold [fluorescentLevelDataCount] = 100, fluorescentLevelDataCount++;
                        fluorescentLevelDataHold [fluorescentLevelDataCount] = 100, fluorescentLevelDataCount++;
                        fluorescentLevelValueHold = 100;
                    }
                    else if (fluorescentDivisionNo == 3){
                        fluorescentLevelDataHold [fluorescentLevelDataCount] = 66, fluorescentLevelDataCount++;
                        fluorescentLevelDataHold [fluorescentLevelDataCount] = 66, fluorescentLevelDataCount++;
                        fluorescentLevelValueHold = 66;
                    }
                    else if (fluorescentDivisionNo == 4){
                        fluorescentLevelDataHold [fluorescentLevelDataCount] = 50, fluorescentLevelDataCount++;
                        fluorescentLevelDataHold [fluorescentLevelDataCount] = 50, fluorescentLevelDataCount++;
                        fluorescentLevelValueHold = 50;
                    }
                    
                    fluorescentSaveCount++;
                }
                
                if (fluorescentSaveCount == 200){
                    fluorescentSaveCount = 0;
                    
                    if (fluorescentLevelDataCount != 0){
                        int readBit [3];
                        int dataTemp = 0;
                        unsigned long indexCount = 0;
                        
                        char *writingArray = new char [fluorescentLevelDataCount*2+20];
                        
                        for (int counter1 = 0; counter1 < fluorescentLevelDataCount/4; counter1++){
                            dataTemp = fluorescentLevelDataHold [counter1*4];
                            
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            writingArray [indexCount] = (char)fluorescentLevelDataHold [counter1*4+1], indexCount++;
                            writingArray [indexCount] = (char)fluorescentLevelDataHold [counter1*4+2], indexCount++;
                            
                            dataTemp = fluorescentLevelDataHold [counter1*4+3];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                        }
                        
                        for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                        
                        ofstream outfile2 (fluorescentSavePath.c_str(), ofstream::binary);
                        outfile2.write ((char*)writingArray, indexCount);
                        outfile2.close();
                        
                        delete [] writingArray;
                    }
                }
                
                proceedFlag = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        
        //-----Fluorescent level set 100/75 "7"-----
        if (keyCode == 26 && timeOneStatus == 0){
            if (fluorescentDivisionStatus == 1 && fluorescentDivisionTime == imageNumberTrackForDisplay && ((fluorescentDivisionTime <= timeEndHold && fluorescentDivisionCh == fluorescentDisplayNo) || (fluorescentDivisionTime > timeEndHold && fluorescentDivisionCh-6 == fluorescentDisplayNo)) && trackingOn == 1 && fluorescentDivisionNo >= 3){
                string cellLineageExtract = cellLineageNoHold.substr(1);
                string cellNoExtract = cellNoHold.substr(1);
                int lineageAmendTemp = atoi(cellLineageExtract.c_str());
                int cellAmendTemp = atoi(cellNoExtract.c_str());
                
                string extension = to_string(fluorescentDivisionTime);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                string connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
                
                struct stat sizeOfFile;
                
                long sizeForCopy = 0;
                
                if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                int *arrayConnectLineageRelLevel = new int [sizeForCopy+50];
                int connectLineageRelLevelCount = 0;
                
                ifstream fin;
                
                fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    int finData [19];
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                            finData [3] = uploadTemp [readPosition], readPosition++;
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                            finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++;
                            finData [11] = uploadTemp [readPosition], readPosition++;
                            finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                            finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                            finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                            finData [7] = finData [6]*256+finData [7];
                            
                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                            
                            if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                            else{
                                
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [2], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [5], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [7], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [12], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [13], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [14], connectLineageRelLevelCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
                
                int connectFluorescentLevel = 0;
                
                for (int counter1 = 0; counter1 < connectLineageRelLevelCount/6; counter1++){
                    if (arrayConnectLineageRelLevel [counter1*6] == lineageAmendTemp && arrayConnectLineageRelLevel [counter1*6+3] == cellAmendTemp){
                        connectFluorescentLevel = arrayConnectLineageRelLevel [counter1*6+1];
                        break;
                    }
                }
                
                delete [] arrayConnectLineageRelLevel;
                
                int findFlag = 0;
                
                for (int counter1 = 0; counter1 < fluorescentLevelDataCount/4; counter1++){
                    if (fluorescentLevelDataHold [counter1*4] == connectFluorescentLevel && fluorescentLevelDataHold [counter1*4+1] == fluorescentDivisionCh){
                        if (fluorescentDivisionNo == 3){
                            fluorescentLevelDataHold [counter1*4+2] = 100;
                            fluorescentLevelValueHold = 100;
                        }
                        else if (fluorescentDivisionNo == 4){
                            fluorescentLevelDataHold [counter1*4+2] = 75;
                            fluorescentLevelValueHold = 75;
                        }
                        
                        fluorescentSaveCount++;
                        findFlag = 1;
                        
                        break;
                    }
                }
                
                if (findFlag == 0 && connectFluorescentLevel != 0){
                    if (fluorescentLevelDataCount+10 > fluorescentLevelDataLimit){
                        int *arrayUpDate = new int [fluorescentLevelDataCount+10];
                        
                        for (int counter1 = 0; counter1 < fluorescentLevelDataCount; counter1++) arrayUpDate [counter1] = fluorescentLevelDataHold [counter1];
                        
                        delete [] fluorescentLevelDataHold;
                        fluorescentLevelDataHold = new int [fluorescentLevelDataLimit+10000];
                        fluorescentLevelDataLimit = fluorescentLevelDataLimit+10000;
                        
                        for (int counter1 = 0; counter1 < fluorescentLevelDataCount; counter1++) fluorescentLevelDataHold [counter1] = arrayUpDate [counter1];
                        delete [] arrayUpDate;
                    }
                    
                    fluorescentLevelDataHold [fluorescentLevelDataCount] = connectFluorescentLevel, fluorescentLevelDataCount++;
                    fluorescentLevelDataHold [fluorescentLevelDataCount] = fluorescentDivisionCh, fluorescentLevelDataCount++;
                    
                    if (fluorescentDivisionNo == 3){
                        fluorescentLevelDataHold [fluorescentLevelDataCount] = 100, fluorescentLevelDataCount++;
                        fluorescentLevelDataHold [fluorescentLevelDataCount] = 100, fluorescentLevelDataCount++;
                        fluorescentLevelValueHold = 100;
                    }
                    else if (fluorescentDivisionNo == 4){
                        fluorescentLevelDataHold [fluorescentLevelDataCount] = 75, fluorescentLevelDataCount++;
                        fluorescentLevelDataHold [fluorescentLevelDataCount] = 75, fluorescentLevelDataCount++;
                        fluorescentLevelValueHold = 75;
                    }
                    
                    fluorescentSaveCount++;
                }
                
                if (fluorescentSaveCount == 200){
                    fluorescentSaveCount = 0;
                    
                    if (fluorescentLevelDataCount != 0){
                        int readBit [3];
                        int dataTemp = 0;
                        unsigned long indexCount = 0;
                        
                        char *writingArray = new char [fluorescentLevelDataCount*2+20];
                        
                        for (int counter1 = 0; counter1 < fluorescentLevelDataCount/4; counter1++){
                            dataTemp = fluorescentLevelDataHold [counter1*4];
                            
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            writingArray [indexCount] = (char)fluorescentLevelDataHold [counter1*4+1], indexCount++;
                            writingArray [indexCount] = (char)fluorescentLevelDataHold [counter1*4+2], indexCount++;
                            
                            dataTemp = fluorescentLevelDataHold [counter1*4+3];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                        }
                        
                        for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                        
                        ofstream outfile2 (fluorescentSavePath.c_str(), ofstream::binary);
                        outfile2.write ((char*)writingArray, indexCount);
                        outfile2.close();
                        
                        delete [] writingArray;
                    }
                }
                
                proceedFlag = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        
        //-----Fluorescent level set 100 "8"-----
        if (keyCode == 28 && timeOneStatus == 0){
            if (fluorescentDivisionStatus == 1 && fluorescentDivisionTime == imageNumberTrackForDisplay && ((fluorescentDivisionTime <= timeEndHold && fluorescentDivisionCh == fluorescentDisplayNo) || (fluorescentDivisionTime > timeEndHold && fluorescentDivisionCh-6 == fluorescentDisplayNo)) && trackingOn == 1 && fluorescentDivisionNo == 4){
                string cellLineageExtract = cellLineageNoHold.substr(1);
                string cellNoExtract = cellNoHold.substr(1);
                int lineageAmendTemp = atoi(cellLineageExtract.c_str());
                int cellAmendTemp = atoi(cellNoExtract.c_str());
                
                string extension = to_string(fluorescentDivisionTime);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                string connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
                
                struct stat sizeOfFile;
                
                long sizeForCopy = 0;
                
                if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                int *arrayConnectLineageRelLevel = new int [sizeForCopy+50];
                int connectLineageRelLevelCount = 0;
                
                ifstream fin;
                
                fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    int finData [19];
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                            finData [3] = uploadTemp [readPosition], readPosition++;
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                            finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++;
                            finData [11] = uploadTemp [readPosition], readPosition++;
                            finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                            finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                            finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                            finData [7] = finData [6]*256+finData [7];
                            
                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                            
                            if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                            else{
                                
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [2], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [5], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [7], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [12], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [13], connectLineageRelLevelCount++;
                                arrayConnectLineageRelLevel [connectLineageRelLevelCount] = finData [14], connectLineageRelLevelCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
                
                int connectFluorescentLevel = 0;
                
                for (int counter1 = 0; counter1 < connectLineageRelLevelCount/6; counter1++){
                    if (arrayConnectLineageRelLevel [counter1*6] == lineageAmendTemp && arrayConnectLineageRelLevel [counter1*6+3] == cellAmendTemp){
                        connectFluorescentLevel = arrayConnectLineageRelLevel [counter1*6+1];
                        break;
                    }
                }
                
                delete [] arrayConnectLineageRelLevel;
                
                int findFlag = 0;
                
                for (int counter1 = 0; counter1 < fluorescentLevelDataCount/4; counter1++){
                    if (fluorescentLevelDataHold [counter1*4] == connectFluorescentLevel && fluorescentLevelDataHold [counter1*4+1] == fluorescentDivisionCh){
                        if (fluorescentDivisionNo == 4){
                            fluorescentLevelDataHold [counter1*4+2] = 100;
                            fluorescentLevelValueHold = 100;
                        }
                        
                        fluorescentSaveCount++;
                        findFlag = 1;
                        
                        break;
                    }
                }
                
                if (findFlag == 0 && connectFluorescentLevel != 0){
                    if (fluorescentLevelDataCount+10 > fluorescentLevelDataLimit){
                        int *arrayUpDate = new int [fluorescentLevelDataCount+10];
                        
                        for (int counter1 = 0; counter1 < fluorescentLevelDataCount; counter1++) arrayUpDate [counter1] = fluorescentLevelDataHold [counter1];
                        
                        delete [] fluorescentLevelDataHold;
                        fluorescentLevelDataHold = new int [fluorescentLevelDataLimit+10000];
                        fluorescentLevelDataLimit = fluorescentLevelDataLimit+10000;
                        
                        for (int counter1 = 0; counter1 < fluorescentLevelDataCount; counter1++) fluorescentLevelDataHold [counter1] = arrayUpDate [counter1];
                        delete [] arrayUpDate;
                    }
                    
                    fluorescentLevelDataHold [fluorescentLevelDataCount] = connectFluorescentLevel, fluorescentLevelDataCount++;
                    fluorescentLevelDataHold [fluorescentLevelDataCount] = fluorescentDivisionCh, fluorescentLevelDataCount++;
                    
                    if (fluorescentDivisionNo == 4){
                        fluorescentLevelDataHold [fluorescentLevelDataCount] = 100, fluorescentLevelDataCount++;
                        fluorescentLevelDataHold [fluorescentLevelDataCount] = 100, fluorescentLevelDataCount++;
                        fluorescentLevelValueHold = 100;
                    }
                    
                    fluorescentSaveCount++;
                }
                
                if (fluorescentSaveCount == 200){
                    fluorescentSaveCount = 0;
                    
                    if (fluorescentLevelDataCount != 0){
                        int readBit [3];
                        int dataTemp = 0;
                        unsigned long indexCount = 0;
                        
                        char *writingArray = new char [fluorescentLevelDataCount*2+20];
                        
                        for (int counter1 = 0; counter1 < fluorescentLevelDataCount/4; counter1++){
                            dataTemp = fluorescentLevelDataHold [counter1*4];
                            
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            writingArray [indexCount] = (char)fluorescentLevelDataHold [counter1*4+1], indexCount++;
                            writingArray [indexCount] = (char)fluorescentLevelDataHold [counter1*4+2], indexCount++;
                            
                            dataTemp = fluorescentLevelDataHold [counter1*4+3];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                        }
                        
                        for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                        
                        ofstream outfile2 (fluorescentSavePath.c_str(), ofstream::binary);
                        outfile2.write ((char*)writingArray, indexCount);
                        outfile2.close();
                        
                        delete [] writingArray;
                    }
                }
                
                proceedFlag = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        
        //-----Connect Back Time One-----
        if (keyCode == 123 && timeOneStatus == 2){
            if (currentPositionSet > 0){
                //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                //    cout<<" arrayTimeSelected "<<counterA<<endl;
                //}
                
                int connectDataFind = 0;
                
                for (int counter1 = timeSelectedCount/10-1; counter1 >= 0; counter1--){
                    if ((backForwardMode == 0 && arrayTimeSelected [counter1*10+8] < currentPositionSet) || (backForwardMode == 1 && arrayTimeSelected [counter1*10+8] < currentPositionSet && arrayTimeSelected [counter1*10] != 2) || (backForwardMode == 2 && arrayTimeSelected [counter1*10+8] < currentPositionSet && (arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7 || arrayTimeSelected [counter1*10] == 0)) || (backForwardMode == 3 && arrayTimeSelected [counter1*10+8] < currentPositionSet && (arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7))){
                        
                        currentPositionSet = arrayTimeSelected [counter1*10+8];
                        
                        if (arrayTimeSelected [counter1*10] == 0 || arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 2 || arrayTimeSelected [counter1*10] == 7){
                            currentConnectNo = currentPositionSet;
                        }
                        else currentConnectNo = 0;
                        
                        if (arrayTimeSelected [counter1*10] == 0 || arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7) timeOneConnectStatus = "SXY";
                        else if (arrayTimeSelected [counter1*10] == 2) timeOneConnectStatus = "B";
                        else timeOneConnectStatus = "D";
                        
                        connectDataFind = 1;
                        break;
                    }
                }
                
                if (connectDataFind == 1){
                    for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                        if (arrayGravityCenterRev [counter1*6+4] == currentPositionSet){
                            xPositionTrack = arrayGravityCenterRev [counter1*6]-imageWidthTrack/2;
                            yPositionTrack = (imageHeightTrack-arrayGravityCenterRev [counter1*6+1])-imageHeightTrack/2;
                            break;
                        }
                    }
                    
                    proceedFlag = 1;
                }
            }
        }
        
        //-----Image Forward-----
        if (keyCode == 124 && timeOneStatus == 0 && fusionOperation == 0){
            if (imageNumberTrackForDisplay >= 1 && imageNumberTrackForDisplay < imageEndHold){
                if (imageNumberTrackForDisplay+1 > imageEndHold){
                    imageNumberTrackForDisplay = imageEndHold;
                }
                else imageNumberTrackForDisplay = imageNumberTrackForDisplay+1;
                
                mergeSelectCount = 0;
                
                //<<ifStartHold<<" "<<imageNumberTrackForDisplay<<" "<<ifEntry<<" IF data"<<endl;
                
                if (ifStartHold != 0 && ifStartHold == imageNumberTrackForDisplay){
                    ifEntry = 1;
                    fluorescentNoHold1 = fluorescentNo1;
                    fluorescentNoHold2 = fluorescentNo2;
                    fluorescentNoHold3 = fluorescentNo3;
                    fluorescentNoHold4 = fluorescentNo4;
                    fluorescentNoHold5 = fluorescentNo5;
                    fluorescentNoHold6 = fluorescentNo6;
                    fluorescentEntryCountHold = fluorescentEntryCount;
                    fluorescentNameHold1 = fluorescentName1;
                    fluorescentNameHold2 = fluorescentName2;
                    fluorescentNameHold3 = fluorescentName3;
                    fluorescentNameHold4 = fluorescentName4;
                    fluorescentNameHold5 = fluorescentName5;
                    fluorescentNameHold6 = fluorescentName6;
                    
                    fluorescentNo1 = 0;
                    fluorescentNo2 = 0;
                    fluorescentNo3 = 0;
                    fluorescentNo4 = 0;
                    fluorescentNo5 = 0;
                    fluorescentNo6 = 0;
                    fluorescentEntryCount = 0;
                    fluorescentName1 = "";
                    fluorescentName2 = "";
                    fluorescentName3 = "";
                    fluorescentName4 = "";
                    fluorescentName5 = "";
                    fluorescentName6 = "";
                    
                    fluorescentEntryCount = atoi(arrayIFDataHold [13].c_str());
                    fluorescentRoundNo = arrayIFDataHold [0];
                    
                    if (fluorescentEntryCount >= 1){
                        fluorescentNo1 = atoi(arrayIFDataHold [7].c_str());
                        fluorescentName1 = arrayIFDataHold [1];
                    }
                    
                    if (fluorescentEntryCount >= 2){
                        fluorescentNo2 = atoi(arrayIFDataHold [8].c_str());
                        fluorescentName2 = arrayIFDataHold [2];
                    }
                    
                    if (fluorescentEntryCount >= 3){
                        fluorescentNo3 = atoi(arrayIFDataHold [9].c_str());
                        fluorescentName3 = arrayIFDataHold [3];
                    }
                    
                    if (fluorescentEntryCount >= 4){
                        fluorescentNo4 = atoi(arrayIFDataHold [10].c_str());
                        fluorescentName4 = arrayIFDataHold [4];
                    }
                    
                    if (fluorescentEntryCount >= 5){
                        fluorescentNo5 = atoi(arrayIFDataHold [11].c_str());
                        fluorescentName5 = arrayIFDataHold [5];
                    }
                    
                    if (fluorescentEntryCount >= 6){
                        fluorescentNo6 = atoi(arrayIFDataHold [12].c_str());
                        fluorescentName6 = arrayIFDataHold [6];
                    }
                    
                    if (lineModificationFlag == 1 && trackingUpperLimit < imageNumberTrackForDisplay){
                        trackingUpperLimit = imageNumberTrackForDisplay;
                        trackingOnInfoDisplay = 1;
                    }
                    
                    string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
                    
                    struct stat sizeOfFile;
                    
                    if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                        int matchFind = 0;
                        
                        for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                            if (arrayFluorescentCutOff [counter1*7] == imageNumberTrackForDisplay){
                                fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                                fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                                fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                                matchFind = 1;
                                
                                break;
                            }
                        }
                        
                        if (matchFind == 0){
                            int nearestCount = 0;
                            
                            for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                                if (arrayFluorescentCutOff [counter1*7] < imageNumberTrackForDisplay){
                                    if (nearestCount < arrayFluorescentCutOff [counter1*7]){
                                        nearestCount = arrayFluorescentCutOff [counter1*7];
                                        fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                        fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                        fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                        fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                                        fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                                        fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                                    }
                                }
                            }
                            
                            if (fluorescentCutOffStatus == 0){
                                arrayFluorescentCutOff = new int [imageEndHold*7];
                                fluorescentCutOffCount = 0;
                                fluorescentCutOffStatus = 1;
                            }
                            
                            if (nearestCount != 0){
                                arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
                            }
                            else{
                                
                                arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            }
                            
                            ofstream oin;
                            oin.open(cutOffPath.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                            
                            oin<<"End"<<endl;
                            oin.close();
                        }
                    }
                    else{
                        
                        fluorescentCutOff1 = 150;
                        fluorescentCutOff2 = 150;
                        fluorescentCutOff3 = 150;
                        fluorescentCutOff4 = 150;
                        fluorescentCutOff5 = 150;
                        fluorescentCutOff6 = 150;
                        
                        if (fluorescentCutOffStatus == 0){
                            arrayFluorescentCutOff = new int [imageEndHold*7];
                            fluorescentCutOffCount = 0;
                            fluorescentCutOffStatus = 1;
                        }
                        
                        arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        
                        ofstream oin;
                        oin.open(cutOffPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                        
                        oin<<"End"<<endl;
                        oin.close();
                    }
                    
                    fluorescentValueDisplayControl = 1;
                }
                else if (ifStartHold != 0 && ifStartHold < imageNumberTrackForDisplay && ifEntry == 1){
                    int nextLoad = 0;
                    
                    for (int counter1 = 0; counter1 < 450; counter1 = counter1+15){
                        if (atoi(arrayIFDataHold [counter1].c_str()) != 0 && atoi(arrayIFDataHold [counter1+14].c_str()) <= imageNumberTrackForDisplay){
                            nextLoad = counter1/15+1;
                        }
                        else if (atoi(arrayIFDataHold [counter1].c_str()) == 0){
                            break;
                        }
                    }
                    
                    if (nextLoad > 0){
                        nextLoad--;
                        
                        fluorescentNo1 = 0;
                        fluorescentNo2 = 0;
                        fluorescentNo3 = 0;
                        fluorescentNo4 = 0;
                        fluorescentNo5 = 0;
                        fluorescentNo6 = 0;
                        fluorescentEntryCount = 0;
                        fluorescentName1 = "";
                        fluorescentName2 = "";
                        fluorescentName3 = "";
                        fluorescentName4 = "";
                        fluorescentName5 = "";
                        fluorescentName6 = "";
                        
                        //for (int counterA = 0; counterA < 90/9; counterA++){
                        //   for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayIFDataHold [counterA*9+counterB];
                        //   cout<<" arrayIFDataHold "<<counterA<<endl;
                        //}
                        
                        fluorescentEntryCount = atoi(arrayIFDataHold [nextLoad*15+13].c_str());
                        fluorescentRoundNo = arrayIFDataHold [nextLoad*15];
                        
                        if (fluorescentEntryCount >= 1){
                            fluorescentNo1 = atoi(arrayIFDataHold [nextLoad*15+7].c_str());
                            fluorescentName1 = arrayIFDataHold [nextLoad*15+1];
                        }
                        
                        if (fluorescentEntryCount >= 2){
                            fluorescentNo2 = atoi(arrayIFDataHold [nextLoad*15+8].c_str());
                            fluorescentName2 = arrayIFDataHold [nextLoad*15+2];
                        }
                        
                        if (fluorescentEntryCount >= 3){
                            fluorescentNo3 = atoi(arrayIFDataHold [nextLoad*15+9].c_str());
                            fluorescentName3 = arrayIFDataHold [nextLoad*15+3];
                        }
                        
                        if (fluorescentEntryCount >= 4){
                            fluorescentNo4 = atoi(arrayIFDataHold [nextLoad*15+10].c_str());
                            fluorescentName4 = arrayIFDataHold [nextLoad*15+4];
                        }
                        
                        if (fluorescentEntryCount >= 5){
                            fluorescentNo5 = atoi(arrayIFDataHold [nextLoad*15+11].c_str());
                            fluorescentName5 = arrayIFDataHold [nextLoad*15+5];
                        }
                        
                        if (fluorescentEntryCount >= 6){
                            fluorescentNo6 = atoi(arrayIFDataHold [nextLoad*15+12].c_str());
                            fluorescentName6 = arrayIFDataHold [nextLoad*15+6];
                        }
                        
                        if (lineModificationFlag == 1 && trackingUpperLimit < imageNumberTrackForDisplay){
                            trackingUpperLimit = imageNumberTrackForDisplay;
                            trackingOnInfoDisplay = 1;
                        }
                    }
                    
                    string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
                    
                    struct stat sizeOfFile;
                    
                    if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                        int matchFind = 0;
                        
                        for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                            if (arrayFluorescentCutOff [counter1*7] == imageNumberTrackForDisplay){
                                fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                                fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                                fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                                matchFind = 1;
                                
                                break;
                            }
                        }
                        
                        if (matchFind == 0){
                            int nearestCount = 0;
                            
                            for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                                if (arrayFluorescentCutOff [counter1*7] < imageNumberTrackForDisplay){
                                    if (nearestCount < arrayFluorescentCutOff [counter1*7]){
                                        nearestCount = arrayFluorescentCutOff [counter1*7];
                                        fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                        fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                        fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                        fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                                        fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                                        fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                                    }
                                }
                            }
                            
                            if (fluorescentCutOffStatus == 0){
                                arrayFluorescentCutOff = new int [imageEndHold*7];
                                fluorescentCutOffCount = 0;
                                fluorescentCutOffStatus = 1;
                            }
                            
                            if (nearestCount != 0){
                                arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
                            }
                            else{
                                
                                arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            }
                            
                            ofstream oin;
                            oin.open(cutOffPath.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                            
                            oin<<"End"<<endl;
                            oin.close();
                        }
                    }
                    else{
                        
                        fluorescentCutOff1 = 150;
                        fluorescentCutOff2 = 150;
                        fluorescentCutOff3 = 150;
                        fluorescentCutOff4 = 150;
                        fluorescentCutOff5 = 150;
                        fluorescentCutOff6 = 150;
                        
                        if (fluorescentCutOffStatus == 0){
                            arrayFluorescentCutOff = new int [imageEndHold*7];
                            fluorescentCutOffCount = 0;
                            fluorescentCutOffStatus = 1;
                        }
                        
                        arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        
                        ofstream oin;
                        oin.open(cutOffPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                        
                        oin<<"End"<<endl;
                        oin.close();
                    }
                    
                    fluorescentValueDisplayControl = 1;
                    
                    if (lineModificationFlag == 1 && trackingUpperLimit < imageNumberTrackForDisplay){
                        trackingUpperLimit = imageNumberTrackForDisplay;
                        trackingOnInfoDisplay = 1;
                    }
                }
                
                if (ifEntry == 0) fluorescentDisplayNo = 0;
                
                setStatus4 = 4;
            }
            else if (imageNumberTrackForDisplay == imageEndHold) endPointHit = 1;
        }
        else{
            
            if (fusionOperation == 1){
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        //-----Connect Forward-----
        if (keyCode == 124 && timeOneStatus == 2){
            if (currentPositionSet > 0){
                int connectDataFind = 0;
                
                for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                    if ((backForwardMode == 0 && arrayTimeSelected [counter1*10+8] > currentPositionSet) || (backForwardMode == 1 && arrayTimeSelected [counter1*10+8] > currentPositionSet && arrayTimeSelected [counter1*10] != 2) || (backForwardMode == 2 && arrayTimeSelected [counter1*10+8] > currentPositionSet && (arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7 || arrayTimeSelected [counter1*10] == 0)) || (backForwardMode == 3 && arrayTimeSelected [counter1*10+8] > currentPositionSet && (arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7))){
                        
                        currentPositionSet = arrayTimeSelected [counter1*10+8];
                        
                        if (arrayTimeSelected [counter1*10] == 0 || arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 2 || arrayTimeSelected [counter1*10] == 7){
                            currentConnectNo = currentPositionSet;
                        }
                        else currentConnectNo = 0;
                        
                        if (arrayTimeSelected [counter1*10] == 0 || arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7) timeOneConnectStatus = "SXY";
                        else if (arrayTimeSelected [counter1*10] == 2) timeOneConnectStatus = "B";
                        else timeOneConnectStatus = "D";
                        
                        connectDataFind = 1;
                        break;
                    }
                }
                
                if (connectDataFind == 1){
                    for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                        if (arrayGravityCenterRev [counter1*6+4] == currentPositionSet){
                            xPositionTrack = arrayGravityCenterRev [counter1*6]-imageWidthTrack/2;
                            yPositionTrack = (imageHeightTrack-arrayGravityCenterRev [counter1*6+1])-imageHeightTrack/2;
                            break;
                        }
                    }
                    
                    proceedFlag = 1;
                }
            }
        }
        
        if ((keyCode == 124 || keyCode == 123) && timeOneStatus == 0 && divisionTypeHold >= 2){
            int divSetCount = 0;
            int saveProceedFlag = 0;
            forceSetAutoFlag = 0;
            
            string connectDivString1 = "";
            string connectDivString2 = "";
            string connectDivString3 = "";
            string connectDivString4 = "";
            int connectDivInt1 = 0;
            int connectDivInt2 = 0;
            int connectDivInt3 = 0;
            int connectDivInt4 = 0;
            
            if (divisionTypeHold >= 2){
                connectDivString1 = cellNoHoldDiv1.substr(1);
                connectDivString2 = cellNoHoldDiv2.substr(1);
                connectDivInt1 = atoi(connectDivString1.c_str());
                connectDivInt2 = atoi(connectDivString2.c_str());
            }
            
            if (divisionTypeHold >= 3){
                connectDivString3 = cellNoHoldDiv3.substr(1);
                connectDivInt3 = atoi(connectDivString3.c_str());
            }
            
            if (divisionTypeHold == 4){
                connectDivString4 = cellNoHoldDiv4.substr(1);
                connectDivInt4 = atoi(connectDivString4.c_str());
            }
            
            //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
            //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
            //	cout<<" arrayEventSequence "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                if (divisionTypeHold >= 2 && arrayEventSequence [counter1*4] != 0 && arrayEventSequence [counter1*4+3] == connectDivInt1) divSetCount++;
                if (divisionTypeHold >= 2 && arrayEventSequence [counter1*4] != 0 && arrayEventSequence [counter1*4+3] == connectDivInt2) divSetCount++;
                if (divisionTypeHold >= 3 && arrayEventSequence [counter1*4] != 0 && arrayEventSequence [counter1*4+3] == connectDivInt3) divSetCount++;
                if (divisionTypeHold == 4 && arrayEventSequence [counter1*4] != 0 && arrayEventSequence [counter1*4+3] == connectDivInt4) divSetCount++;
            }
            
            if (divisionTypeHold == 2 && divSetCount == 2) saveProceedFlag = 1;
            if (divisionTypeHold == 3 && divSetCount == 3) saveProceedFlag = 1;
            if (divisionTypeHold == 4 && divSetCount == 4) saveProceedFlag = 1;
            
            if (saveProceedFlag == 1){
                if (keyCode == 124){
                    lineModificationFlag = 1;
                    keyLockON = 0;
                    trackingUpperLimit = imageNumberTrackForDisplay-1;
                    trackingOnInfoDisplay = 1;
                }
                
                if (keyCode == 123){
                    lineModificationFlag = 1;
                    keyLockON = 0;
                    trackingUpperLimit = imageNumberTrackForDisplay+1;
                    trackingOnInfoDisplay = 1;
                }
            }
            else{
                
                if (keyCode == 124){
                    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay-1) arrayEventSequence [counter1*4] = 0;
                    }
                    
                    for (int counter1 = 0; counter1 < lineageGRCurrentCount/4; counter1++){
                        if (arrayLineageGRCurrent [counter1*4] == imageNumberTrackForDisplay-1) arrayLineageGRCurrent [counter1*4] = 0;
                    }
                }
                
                if (keyCode == 123){
                    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay+1) arrayEventSequence [counter1*4] = 0;
                    }
                    
                    for (int counter1 = 0; counter1 < lineageGRCurrentCount/4; counter1++){
                        if (arrayLineageGRCurrent [counter1*4] == imageNumberTrackForDisplay+1) arrayLineageGRCurrent [counter1*4] = 0;
                    }
                }
                
                cellNoHoldDiv1 = "";
                cellNoHoldDiv2 = "";
                cellNoHoldDiv3 = "";
                cellNoHoldDiv4 = "";
                lineModificationFlag = 0;
                cellDivisionSetCount = 0;
                divisionTypeHold = 0;
                keyLockON = 3;
            }
        }
        
        if (keyCode == 123 && timeOneStatus == 0 && fusionOperation == 1){
            forceSetAutoFlag = 0;
            
            if (fusionStatusFollow == 1){
                fusionOperation = 0;
                fusionPartnerLin = 0;
                fusionPartnerCellNo = -1;
                fusionStatusFollow = 0;
                
                if (keyCode == 123){
                    //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
                    //    cout<<" arrayEventSequence "<<counterA<<endl;
                    //}
                    
                    keyLockON = 0;
                    
                    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                        if (arrayEventSequence [counter1*4+1] == 91 && arrayEventSequence [counter1*4] == imageNumberTrackForDisplay+1){
                            arrayEventSequence [counter1*4+1] = 2;
                            arrayEventSequence [counter1*4] = 0;
                        }
                    }
                }
            }
            else{
                
                fusionOperation = 0;
                fusionPartnerLin = 0;
                fusionPartnerCellNo = -1;
                fusionStatusFollow = 0;
                keyLockON = 0;
                lineModificationFlag = 1;
            }
        }
        
        //-----N Force to set circle around cursor point-----
        if (keyCode == 45 && fusionOperation == 0 && keyLockON == 0 && timeOneStatus == 0){
            double xPositionAdjustDouble = xPositionAdjustTrack+xPositionTrack;
            double yPositionAdjustDouble = yPositionAdjustTrack+yPositionTrack;
            double xCalculationValue = 1/(double)windowWidthTrack*magnificationTrack*0.1;
            double yCalculationValue = 1/(double)windowHeightTrack*magnificationTrack*0.1;
            
            int xPointMarkTemp = (int)(xPointDownTrack/(double)xCalculationValue+xPositionAdjustDouble);
            int yPointMarkTemp = (int)((yPointDownTrack/(double)yCalculationValue+yPositionAdjustDouble-imageHeightTrack)*-1);
            
            if (targetPrevHoldCount != 0){
                targetCount = 0;
                
                int xCenterTarget = 0;
                int yCenterTarget = 0;
                int maxPointDimX = 0;
                int maxPointDimY = 0;
                int minPointDimX = 1000000;
                int minPointDimY = 1000000;
                
                for (int counter1 = 0; counter1 < targetPrevHoldCount/2; counter1++){
                    if (maxPointDimX < arrayTargetPrevHold [counter1*2]) maxPointDimX = arrayTargetPrevHold [counter1*2];
                    if (minPointDimX > arrayTargetPrevHold [counter1*2]) minPointDimX = arrayTargetPrevHold [counter1*2];
                    if (maxPointDimY < arrayTargetPrevHold [counter1*2+1]) maxPointDimY = arrayTargetPrevHold [counter1*2+1];
                    if (minPointDimY > arrayTargetPrevHold [counter1*2+1]) minPointDimY = arrayTargetPrevHold [counter1*2+1];
                }
                
                xCenterTarget = xPointMarkTemp-((int)((maxPointDimX-minPointDimX)/(double)2)+minPointDimX);
                yCenterTarget = yPointMarkTemp-((int)((maxPointDimY-minPointDimY)/(double)2)+minPointDimY);
                
                //cout<<xCenterTarget <<" "<<yCenterTarget <<" "<<xPointMarkTemp<<" "<<yPointMarkTemp<<" "<<(int)((maxPointDimX-minPointDimX)/(double)2)+minPointDimX<<" "<<(int)((maxPointDimY-minPointDimY)/(double)2)+minPointDimY<<" SD"<<endl;
                
                if (minPointDimX != 1000000 && minPointDimY != 1000000){
                    int positionCheck = 0;
                    
                    for (int counter1 = 0; counter1 < targetPrevHoldCount/2; counter1++){
                        if (xCenterTarget+arrayTargetPrevHold [counter1*2] < 0 && xCenterTarget+arrayTargetPrevHold [counter1*2] >= imageDimension) positionCheck = 1;
                        if (yCenterTarget+arrayTargetPrevHold [counter1*2+1] < 0 && yCenterTarget+arrayTargetPrevHold [counter1*2+1] >= imageDimension) positionCheck = 1;
                    }
                    
                    if (positionCheck == 0){
                        if (targetStatus == 0){
                            arrayTarget = new int [targetPrevHoldCount+500];
                            targetCount = 0;
                            targetLimit = targetPrevHoldCount+500;
                            targetStatus = 1;
                        }
                        
                        targetCount = 0;
                        
                        for (int counter1 = 0; counter1 < targetPrevHoldCount/2; counter1++){
                            arrayTarget [targetCount] = arrayTargetPrevHold [counter1*2]+xCenterTarget, targetCount++;
                            arrayTarget [targetCount] = arrayTargetPrevHold [counter1*2+1]+yCenterTarget, targetCount++;
                        }
                        
                        saveShortCutNumber = 5;
                    }
                }
            }
        }
        
        //-----N Force to set circle around cursor point-----
        if (keyCode == 9 && fusionOperation == 0 && keyLockON == 0 && timeOneStatus == 0){
            double xPositionAdjustDouble = xPositionAdjustTrack+xPositionTrack;
            double yPositionAdjustDouble = yPositionAdjustTrack+yPositionTrack;
            double xCalculationValue = 1/(double)windowWidthTrack*magnificationTrack*0.1;
            double yCalculationValue = 1/(double)windowHeightTrack*magnificationTrack*0.1;
            
            int xPointMarkTemp = (int)(xPointDownTrack/(double)xCalculationValue+xPositionAdjustDouble);
            int yPointMarkTemp = (int)((yPointDownTrack/(double)yCalculationValue+yPositionAdjustDouble-imageHeightTrack)*-1);
            
            if (targetPrevHoldCount != 0){
                targetCount = 0;
                
                int xCenterTarget = 0;
                int yCenterTarget = 0;
                int maxPointDimX = 0;
                int maxPointDimY = 0;
                int minPointDimX = 1000000;
                int minPointDimY = 1000000;
                
                for (int counter1 = 0; counter1 < targetPrevHoldCount/2; counter1++){
                    if (maxPointDimX < arrayTargetPrevHold [counter1*2]) maxPointDimX = arrayTargetPrevHold [counter1*2];
                    if (minPointDimX > arrayTargetPrevHold [counter1*2]) minPointDimX = arrayTargetPrevHold [counter1*2];
                    if (maxPointDimY < arrayTargetPrevHold [counter1*2+1]) maxPointDimY = arrayTargetPrevHold [counter1*2+1];
                    if (minPointDimY > arrayTargetPrevHold [counter1*2+1]) minPointDimY = arrayTargetPrevHold [counter1*2+1];
                }
                
                xCenterTarget = xPointMarkTemp-((int)((maxPointDimX-minPointDimX)/(double)2)+minPointDimX);
                yCenterTarget = yPointMarkTemp-((int)((maxPointDimY-minPointDimY)/(double)2)+minPointDimY);
                
                //cout<<xCenterTarget <<" "<<yCenterTarget <<" "<<xPointMarkTemp<<" "<<yPointMarkTemp<<" "<<(int)((maxPointDimX-minPointDimX)/(double)2)+minPointDimX<<" "<<(int)((maxPointDimY-minPointDimY)/(double)2)+minPointDimY<<" SD"<<endl;
                
                if (minPointDimX != 1000000 && minPointDimY != 1000000){
                    int positionCheck = 0;
                    
                    for (int counter1 = 0; counter1 < targetPrevHoldCount/2; counter1++){
                        if (xCenterTarget+arrayTargetPrevHold [counter1*2] < 0 && xCenterTarget+arrayTargetPrevHold [counter1*2] >= imageDimension) positionCheck = 1;
                        if (yCenterTarget+arrayTargetPrevHold [counter1*2+1] < 0 && yCenterTarget+arrayTargetPrevHold [counter1*2+1] >= imageDimension) positionCheck = 1;
                    }
                    
                    if (positionCheck == 0){
                        if (targetStatus == 0){
                            arrayTarget = new int [targetPrevHoldCount+500];
                            targetCount = 0;
                            targetLimit = targetPrevHoldCount+500;
                            targetStatus = 1;
                        }
                        
                        targetCount = 0;
                        
                        for (int counter1 = 0; counter1 < targetPrevHoldCount/2; counter1++){
                            arrayTarget [targetCount] = arrayTargetPrevHold [counter1*2]+xCenterTarget, targetCount++;
                            arrayTarget [targetCount] = arrayTargetPrevHold [counter1*2+1]+yCenterTarget, targetCount++;
                        }
                        
                        saveShortCutNumber = 6;
                    }
                }
            }
        }
        
        int saveResultsReturn = 0;
        
        if ((keyCode == 123 || (keyCode == 124 && fusionOperation == 0) || keyCode == 38 || keyCode == 37 || keyCode == 0) && (keyLockON == 0 || keyLockON == 3) && timeOneStatus == 0){
            divisionWarningType = 0;
            divisionWarning = "";
            proceedFlag = 1;
            
            int fluorescentCurrentStatus = 0;
            string extension2;
            
            string extension = to_string(imageNumberTrackForDisplay);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            if (fluorescentDetectionDisplay == 1) fluorescentCurrentStatus = 1;
            
            fluorescentDetectionDisplay = 0;
            
            int totalSize = imageDimension*imageDimension*4;
            int phaseOpenCheck = 0;
            
            ifstream fin;
            
            if (fluorescentEntryCount != 0){
                int fluorescentDisplayFind1 = 0;
                int fluorescentDisplayFind2 = 0;
                int fluorescentDisplayFind3 = 0;
                int fluorescentDisplayFind4 = 0;
                int fluorescentDisplayFind5 = 0;
                int fluorescentDisplayFind6 = 0;
                
                extension2 = to_string(fluorescentNo1);
                
                string fluorescentPath1;
                
                if (ifEntry == 0) fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+exType;
                else if (ifEntry == 1) fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+exTypeIF+fluorescentRoundNo;
                
                extension2 = to_string(fluorescentNo2);
                
                string fluorescentPath2;
                
                if (ifEntry == 0) fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName2+exType;
                else if (ifEntry == 1) fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName2+exTypeIF+fluorescentRoundNo;
                
                extension2 = to_string(fluorescentNo3);
                
                string fluorescentPath3;
                
                if (ifEntry == 0) fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName3+exType;
                else if (ifEntry == 1) fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName3+exTypeIF+fluorescentRoundNo;
                
                extension2 = to_string(fluorescentNo4);
                
                string fluorescentPath4;
                if (ifEntry == 0) fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName4+exType;
                else if (ifEntry == 1) fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName4+exTypeIF+fluorescentRoundNo;
                
                extension2 = to_string(fluorescentNo5);
                
                string fluorescentPath5;
                if (ifEntry == 0) fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName5+exType;
                else if (ifEntry == 1) fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName5+exTypeIF+fluorescentRoundNo;
                
                extension2 = to_string(fluorescentNo6);
                
                string fluorescentPath6;
                if (ifEntry == 0) fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName6+exType;
                else if (ifEntry == 1) fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName6+exTypeIF+fluorescentRoundNo;
                
                struct stat sizeOfFile;
                
                if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0){
                    fluorescentDisplayFind1 = 1;
                }
                
                if (stat(fluorescentPath2.c_str(), &sizeOfFile) == 0){
                    fluorescentDisplayFind2 = 1;
                }
                
                if (stat(fluorescentPath3.c_str(), &sizeOfFile) == 0){
                    fluorescentDisplayFind3 = 1;
                }
                
                if (stat(fluorescentPath4.c_str(), &sizeOfFile) == 0){
                    fluorescentDisplayFind4 = 1;
                }
                
                if (stat(fluorescentPath5.c_str(), &sizeOfFile) == 0){
                    fluorescentDisplayFind5 = 1;
                }
                
                if (stat(fluorescentPath6.c_str(), &sizeOfFile) == 0){
                    fluorescentDisplayFind6 = 1;
                }
                
                int fluorescentColorNoHold = 0;
                
                if (fluorescentDisplayNo == 1 && fluorescentDisplayFind1 == 1){
                    displayImagePath = fluorescentPath1;
                    fluorescentColorNoHold = fluorescentNo1;
                }
                else if (fluorescentDisplayNo == 1 && fluorescentDisplayFind1 == 0){
                    if (fluorescentDisplayFind2 == 1){
                        fluorescentDisplayNo = 2;
                        displayImagePath = fluorescentPath2;
                        fluorescentColorNoHold = fluorescentNo2;
                    }
                    else if (fluorescentDisplayFind3 == 1){
                        fluorescentDisplayNo = 3;
                        displayImagePath = fluorescentPath3;
                        fluorescentColorNoHold = fluorescentNo3;
                    }
                    else if (fluorescentDisplayFind4 == 1){
                        fluorescentDisplayNo = 4;
                        displayImagePath = fluorescentPath4;
                        fluorescentColorNoHold = fluorescentNo4;
                    }
                    else if (fluorescentDisplayFind5 == 1){
                        fluorescentDisplayNo = 5;
                        displayImagePath = fluorescentPath5;
                        fluorescentColorNoHold = fluorescentNo5;
                    }
                    else if (fluorescentDisplayFind6 == 1){
                        fluorescentDisplayNo = 6;
                        displayImagePath = fluorescentPath6;
                        fluorescentColorNoHold = fluorescentNo6;
                    }
                    else fluorescentDisplayNo = 0;
                }
                else if (fluorescentDisplayNo == 2 && fluorescentDisplayFind2 == 1){
                    displayImagePath = fluorescentPath2;
                    fluorescentColorNoHold = fluorescentNo2;
                }
                else if (fluorescentDisplayNo == 2 && fluorescentDisplayFind2 == 0){
                    if (fluorescentDisplayFind3 == 1){
                        fluorescentDisplayNo = 3;
                        displayImagePath = fluorescentPath3;
                        fluorescentColorNoHold = fluorescentNo3;
                    }
                    else if (fluorescentDisplayFind4 == 1){
                        fluorescentDisplayNo = 4;
                        displayImagePath = fluorescentPath4;
                        fluorescentColorNoHold = fluorescentNo4;
                    }
                    else if (fluorescentDisplayFind5 == 1){
                        fluorescentDisplayNo = 5;
                        displayImagePath = fluorescentPath5;
                        fluorescentColorNoHold = fluorescentNo5;
                    }
                    else if (fluorescentDisplayFind6 == 1){
                        fluorescentDisplayNo = 6;
                        displayImagePath = fluorescentPath6;
                        fluorescentColorNoHold = fluorescentNo6;
                    }
                    else fluorescentDisplayNo = 0;
                }
                else if (fluorescentDisplayNo == 3 && fluorescentDisplayFind3 == 1){
                    displayImagePath = fluorescentPath3;
                    fluorescentColorNoHold = fluorescentNo3;
                }
                else if (fluorescentDisplayNo == 3 && fluorescentDisplayFind3 == 0){
                    if (fluorescentDisplayFind4 == 1){
                        fluorescentDisplayNo = 4;
                        displayImagePath = fluorescentPath4;
                        fluorescentColorNoHold = fluorescentNo4;
                    }
                    else if (fluorescentDisplayFind5 == 1){
                        fluorescentDisplayNo = 5;
                        displayImagePath = fluorescentPath5;
                        fluorescentColorNoHold = fluorescentNo5;
                    }
                    else if (fluorescentDisplayFind6 == 1){
                        fluorescentDisplayNo = 6;
                        displayImagePath = fluorescentPath6;
                        fluorescentColorNoHold = fluorescentNo6;
                    }
                    else fluorescentDisplayNo = 0;
                }
                else if (fluorescentDisplayNo == 4 && fluorescentDisplayFind4 == 1){
                    displayImagePath = fluorescentPath4;
                    fluorescentColorNoHold = fluorescentNo4;
                }
                else if (fluorescentDisplayNo == 4 && fluorescentDisplayFind4 == 0){
                    if (fluorescentDisplayFind5 == 1){
                        fluorescentDisplayNo = 5;
                        displayImagePath = fluorescentPath5;
                        fluorescentColorNoHold = fluorescentNo5;
                    }
                    else if (fluorescentDisplayFind6 == 1){
                        fluorescentDisplayNo = 6;
                        displayImagePath = fluorescentPath6;
                        fluorescentColorNoHold = fluorescentNo6;
                    }
                    else fluorescentDisplayNo = 0;
                }
                else if (fluorescentDisplayNo == 5 && fluorescentDisplayFind5 == 1){
                    displayImagePath = fluorescentPath5;
                    fluorescentColorNoHold = fluorescentNo5;
                }
                else if (fluorescentDisplayNo == 5 && fluorescentDisplayFind5 == 0){
                    if (fluorescentDisplayFind6 == 1){
                        fluorescentDisplayNo = 6;
                        displayImagePath = fluorescentPath6;
                        fluorescentColorNoHold = fluorescentNo6;
                    }
                    else fluorescentDisplayNo = 0;
                }
                else if (fluorescentDisplayNo == 6 && fluorescentDisplayFind6 == 1){
                    displayImagePath = fluorescentPath6;
                    fluorescentColorNoHold = fluorescentNo6;
                }
                else if (fluorescentDisplayNo == 6 && fluorescentDisplayFind6 == 0) fluorescentDisplayNo = 0;
                
                if (fluorescentDisplayFind1 == 1 || fluorescentDisplayFind2 == 1 || fluorescentDisplayFind3 == 1 || fluorescentDisplayFind4 == 1 || fluorescentDisplayFind5 == 1 || fluorescentDisplayFind6 == 1){
                    fluorescentDetectionDisplay = 1;
                    
                    if (keyCode == 123 || keyCode == 124){
                        NSSound *sound = [NSSound soundNamed:@"Frog"];
                        [sound play];
                    }
                }
                
                if (fluorescentDisplayNo == 0){
                    if (phaseStatus == 1){
                        if (ifEntry == 0) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Phase/"+"Phase "+extension+exType;
                        else if (ifEntry == 1) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Phase/"+"Phase "+extension+exTypeIF+fluorescentRoundNo;
                        
                        fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            phaseOpenCheck = 1;
                        }
                    }
                    
                    if (phaseStatus == 0 || phaseOpenCheck == 0){
                        if (ifEntry == 0) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+exType;
                        else if (ifEntry == 1) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+exTypeIF+fluorescentRoundNo;
                    }
                    
                    uint8_t *uploadTemp = new uint8_t [totalSize+1];
                    fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        if (exType == ".tif" || exTypeIF == ".TIF"){
                            fin.read((char*)uploadTemp, totalSize+1);
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            
                            unsigned long headPosition = 0;
                            
                            dataConversion [0] = uploadTemp [0];
                            dataConversion [1] = uploadTemp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTemp [7];
                                dataConversion [1] = uploadTemp [6];
                                dataConversion [2] = uploadTemp [5];
                                dataConversion [3] = uploadTemp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTemp [4];
                                dataConversion [1] = uploadTemp [5];
                                dataConversion [2] = uploadTemp [6];
                                dataConversion [3] = uploadTemp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (tifImageColorGray == 0){
                                NSBitmapImageRep *bitmapReps;
                                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                                
                                unsigned char *bitmapData = [bitmapReps bitmapData];
                                
                                for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                    *bitmapData++ = uploadTemp [counter1];
                                }
                                
                                trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                [trackingImage addRepresentation:bitmapReps];
                            }
                            else if (tifImageColorGray == 1){
                                NSBitmapImageRep *bitmapReps = nil;
                                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                                
                                unsigned char *bitmapData = [bitmapReps bitmapData];
                                
                                for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                    value0 = uploadTemp [counter1];
                                    value1 = uploadTemp [counter1+1];
                                    value2 = uploadTemp [counter1+2];
                                    
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = (unsigned char)value1;
                                    *bitmapData++ = (unsigned char)value2;
                                    *bitmapData++ = 0;
                                }
                                
                                trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                [trackingImage addRepresentation:bitmapReps];
                            }
                        }
                        else if (exType == ".bmp" || exTypeIF == ".BMP"){
                            fin.read((char*)uploadTemp, totalSize+1);
                            fin.close();
                            
                            NSBitmapImageRep *bitmapReps;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                    *bitmapData++ = uploadTemp [1078+counter1*imageDimension+counter2];
                                }
                            }
                            
                            trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [trackingImage addRepresentation:bitmapReps];
                        }
                    }
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    uint8_t *uploadTemp = new uint8_t [totalSize+1];
                    fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        if (exType == ".tif" || exTypeIF == ".TIF"){
                            fin.read((char*)uploadTemp, totalSize+1);
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            
                            unsigned long headPosition = 0;
                            
                            dataConversion [0] = uploadTemp [0];
                            dataConversion [1] = uploadTemp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTemp [7];
                                dataConversion [1] = uploadTemp [6];
                                dataConversion [2] = uploadTemp [5];
                                dataConversion [3] = uploadTemp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTemp [4];
                                dataConversion [1] = uploadTemp [5];
                                dataConversion [2] = uploadTemp [6];
                                dataConversion [3] = uploadTemp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (tifImageColorGray == 0){
                                NSBitmapImageRep *bitmapReps = nil;
                                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                                
                                unsigned char *bitmapData = [bitmapReps bitmapData];
                                
                                int readDataTemp = 0;
                                
                                for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                    readDataTemp = uploadTemp [counter1];
                                    
                                    if (fluorescentDisplayMode == 0){
                                        if (fluorescentDisplayNo == 1 && readDataTemp < fluorescentCutOff1) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 2 && readDataTemp < fluorescentCutOff2) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 3 && readDataTemp < fluorescentCutOff3) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 4 && readDataTemp < fluorescentCutOff4) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 5 && readDataTemp < fluorescentCutOff5) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 6 && readDataTemp < fluorescentCutOff6) readDataTemp = 0;
                                        
                                        if (fluorescentColorNoHold == 1){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 2){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 3){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 4){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 5){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 6){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 7){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.674));
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 8){
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.627));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.125));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.941));
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 9){
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.529));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.808));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.922));
                                            *bitmapData++ = 0;
                                        }
                                    }
                                    else{
                                        
                                        if (fluorescentDisplayRange == 2){
                                            if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else{
                                                
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                        }
                                        else if (fluorescentDisplayRange == 3){
                                            if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*2){
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                            else{
                                                
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                        }
                                        else if (fluorescentDisplayRange == 4){
                                            if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*2){
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                            else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*3){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else{
                                                
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                        }
                                    }
                                }
                                
                                trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                [trackingImage addRepresentation:bitmapReps];
                                
                            }
                            else if (tifImageColorGray == 1){
                                NSBitmapImageRep *bitmapReps = nil;
                                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                                
                                unsigned char *bitmapData = [bitmapReps bitmapData];
                                
                                for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                    value0 = uploadTemp [counter1];
                                    value1 = uploadTemp [counter1+1];
                                    value2 = uploadTemp [counter1+2];
                                    
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = (unsigned char)value1;
                                    *bitmapData++ = (unsigned char)value2;
                                    *bitmapData++ = 0;
                                }
                                
                                trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                [trackingImage addRepresentation:bitmapReps];
                            }
                        }
                        else if (exType == ".bmp" || exTypeIF == ".BMP"){
                            NSBitmapImageRep *bitmapReps = nil;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            int readDataTemp = 0;
                            
                            fin.read((char*)uploadTemp, totalSize+1);
                            fin.close();
                            
                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                    readDataTemp = uploadTemp [1078+counter1*imageDimension+counter2];
                                    
                                    if (fluorescentDisplayMode == 0){
                                        if (fluorescentDisplayNo == 1 && readDataTemp < fluorescentCutOff1) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 2 && readDataTemp < fluorescentCutOff2) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 3 && readDataTemp < fluorescentCutOff3) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 4 && readDataTemp < fluorescentCutOff4) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 5 && readDataTemp < fluorescentCutOff5) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 6 && readDataTemp < fluorescentCutOff6) readDataTemp = 0;
                                        
                                        if (fluorescentColorNoHold == 1){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 2){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 3){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 4){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 5){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 6){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 7){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.674));
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 8){
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.627));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.125));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.941));
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 9){
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.529));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.808));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.922));
                                            *bitmapData++ = 0;
                                        }
                                    }
                                    else{
                                        
                                        if (fluorescentDisplayRange == 2){
                                            if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else{
                                                
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                        }
                                        else if (fluorescentDisplayRange == 3){
                                            if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*2){
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                            else{
                                                
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                        }
                                        else if (fluorescentDisplayRange == 4){
                                            if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*2){
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                            else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*3){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else{
                                                
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [trackingImage addRepresentation:bitmapReps];
                        }
                    }
                    
                    delete [] uploadTemp;
                }
            }
            else{
                
                if (phaseStatus == 1){
                    if (ifEntry == 0) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Phase/"+"Phase "+extension+exType;
                    else if (ifEntry == 1) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Phase/"+"Phase "+extension+exTypeIF+fluorescentRoundNo;
                    
                    fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.close();
                        phaseOpenCheck = 1;
                    }
                }
                
                if (phaseStatus == 0 || phaseOpenCheck == 0){
                    if (ifEntry == 0) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+exType;
                    else if (ifEntry == 1) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+exTypeIF+fluorescentRoundNo;
                }
                
                uint8_t *uploadTemp = new uint8_t [totalSize+1];
                fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    if (exType == ".tif" || exTypeIF == ".TIF"){
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        int dataConversion [4];
                        int endianType = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        
                        unsigned long headPosition = 0;
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        if (tifImageColorGray == 0){
                            NSBitmapImageRep *bitmapReps;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                *bitmapData++ = uploadTemp [counter1];
                            }
                            
                            trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [trackingImage addRepresentation:bitmapReps];
                        }
                        else if (tifImageColorGray == 1){
                            NSBitmapImageRep *bitmapReps = nil;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                value0 = uploadTemp [counter1];
                                value1 = uploadTemp [counter1+1];
                                value2 = uploadTemp [counter1+2];
                                
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value1;
                                *bitmapData++ = (unsigned char)value2;
                                *bitmapData++ = 0;
                            }
                            
                            trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [trackingImage addRepresentation:bitmapReps];
                        }
                    }
                    else if (exType == ".bmp" || exTypeIF == ".BMP"){
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        NSBitmapImageRep *bitmapReps;
                        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                        
                        unsigned char *bitmapData = [bitmapReps bitmapData];
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                *bitmapData++ = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                        }
                        
                        trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                        [trackingImage addRepresentation:bitmapReps];
                    }
                }
                
                delete [] uploadTemp;
            }
            
            //-----Line Data Read-----
            if (keyCode == 123 && trackingOn == 3 && trackingLowerLimit > imageNumberTrackForDisplay && trackingLowerLimit <= imageNumberTrackForDisplay+1){
                int dataLoadingCheck = 0;
                
                if (ifEntry == 0){
                    int processType = 3;
                    trackingSet = [[TrackingSet alloc] init];
                    dataLoadingCheck = [trackingSet trackingSetMain:processType];
                    trackingPermit = 0;
                }
                else if (ifEntry == 1){
                    int processType = 6;
                    trackingSet = [[TrackingSet alloc] init];
                    dataLoadingCheck = [trackingSet trackingSetMain:processType];
                    trackingPermit = 0;
                }
                
                trackingPermit = 0;
                
                if (dataLoadingCheck == 0){
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Data Read Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            
            if (keyCode == 124 && trackingOn == 3 && trackingUpperLimit < imageNumberTrackForDisplay && trackingUpperLimit >= imageNumberTrackForDisplay-1){
                int dataLoadingCheck = 0;
                
                if (ifEntry == 0){
                    int processType = 3;
                    trackingSet = [[TrackingSet alloc] init];
                    dataLoadingCheck = [trackingSet trackingSetMain:processType];
                    trackingPermit = 0;
                }
                else if (ifEntry == 1){
                    int processType = 6;
                    trackingSet = [[TrackingSet alloc] init];
                    dataLoadingCheck = [trackingSet trackingSetMain:processType];
                    trackingPermit = 0;
                }
                
                trackingPermit = 0;
                
                if (dataLoadingCheck == 0){
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Data Read Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            
            if (trackingOn == 3 && trackingLowerLimit <= imageNumberTrackForDisplay && trackingUpperLimit >= imageNumberTrackForDisplay){
                // cout<<lineModificationFlag<<" "<<keyCode<<" "<<trackingUpperLimit<<" "<<imageNumberTrackForDisplay-1<<" "<<overTimeRemoveFlag<<" Info"<<endl;
                
                int loadingCheck = 0;
                
                if (lineModificationFlag == 1 && keyCode == 124 && trackingUpperLimit >= imageNumberTrackForDisplay-1){
                    if (overTimeRemoveFlag == 1){
                        string connectDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold;
                        string entry;
                        string stringExtract;
                        string removePath;
                        
                        fileDeleteCount = 0;
                        
                        DIR *dir = opendir(connectDataTempPath.c_str());
                        struct dirent *dent;
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (fileDeleteCount+5 > fileDeleteLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate fileDeleteUpDate];
                                }
                                
                                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                            }
                            
                            closedir(dir);
                            
                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                entry = arrayFileDelete [counter1];
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    if (entry.length() > 4 && entry.find("_") == 4){
                                        stringExtract = entry.substr(0, 4);
                                        
                                        if (atoi(stringExtract.c_str()) > imageNumberTrackForDisplay-1){
                                            removePath = connectDataTempPath+"/"+entry;
                                            remove(removePath.c_str());
                                        }
                                    }
                                }
                            }
                        }
                        
                        overTimeRemoveFlag = 0;
                    }
                    
                    if (divisionFusionCancelFlag == 0){
                        if (endPointHit == 1){
                            int processType2 = 2;
                            int gravityCenterCheckMode = 0;
                            trackingDataSave = [[TrackingDataSave alloc] init];
                            saveResultsReturn = [trackingDataSave trackingDataSaveTemp:processType2:fluorescentCurrentStatus:gravityCenterCheckMode];
                        }
                        else{
                            
                            int processType2 = 1;
                            int gravityCenterCheckMode = 0;
                            trackingDataSave = [[TrackingDataSave alloc] init];
                            saveResultsReturn = [trackingDataSave trackingDataSaveTemp:processType2:fluorescentCurrentStatus:gravityCenterCheckMode];
                        }
                    }
                    else divisionFusionCancelFlag = 0;
                }
                else if (lineModificationFlag == 1 && keyCode == 123 && trackingLowerLimit <= imageNumberTrackForDisplay+1){
                    //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
                    //    cout<<" arrayEventSequence "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < eventSequenceHoldCount/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequenceHold [counterA*4+counterB];
                    //    cout<<" arrayEventSequenceHold "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < lineageGRCurrentCount/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrent [counterA*4+counterB];
                    //    cout<<" arrayLineageGRCurrent "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < lineageGravityCenterCurrentHoldCount/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGravityCenterCurrentHold [counterA*4+counterB];
                    //    cout<<" arrayLineageGravityCenterCurrentHold "<<counterA<<endl;
                    //}
                    
                    referenceLineCount = 0;
                    int correctionGR = 0;
                    int retainingImageNo = 0;
                    
                    if (eventSequenceHoldCount != 0) retainingImageNo = arrayEventSequenceHold [0];
                    else retainingImageNo = 0;
                    
                    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                        if (arrayEventSequence [counter1*4] == 0 || imageNumberTrackForDisplay == retainingImageNo || trackingUpperLimit == imageNumberTrackForDisplay-1);
                        else if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay+1){
                            arrayEventSequence [counter1*4] = 0;
                            correctionGR = 1;
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < eventSequenceHoldCount/4; counter1++){
                        if (arrayEventSequenceHold [counter1*4] == imageNumberTrackForDisplay+1 && correctionGR == 1){
                            if (eventSequenceCount+4 > eventSequenceLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate eventSequenceUpDate];
                            }
                            
                            arrayEventSequence [eventSequenceCount] = arrayEventSequenceHold [counter1*4], eventSequenceCount++;
                            arrayEventSequence [eventSequenceCount] = arrayEventSequenceHold [counter1*4+1], eventSequenceCount++;
                            arrayEventSequence [eventSequenceCount] = arrayEventSequenceHold [counter1*4+2], eventSequenceCount++;
                            arrayEventSequence [eventSequenceCount] = arrayEventSequenceHold [counter1*4+3], eventSequenceCount++;
                        }
                    }
                    
                    if (overTimeRemoveFlag == 1){
                        string connectDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold;
                        string entry;
                        string stringExtract;
                        string removePath;
                        
                        fileDeleteCount = 0;
                        
                        DIR *dir = opendir(connectDataTempPath.c_str());
                        struct dirent *dent;
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (fileDeleteCount+5 > fileDeleteLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate fileDeleteUpDate];
                                }
                                
                                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                            }
                            
                            closedir(dir);
                            
                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                entry = arrayFileDelete [counter1];
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    if (entry.length() > 4 && entry.find("_") == 4){
                                        stringExtract = entry.substr(0, 4);
                                        
                                        if (atoi(stringExtract.c_str()) > imageNumberTrackForDisplay+1){
                                            removePath = connectDataTempPath+"/"+entry;
                                            remove(removePath.c_str());
                                        }
                                    }
                                }
                            }
                        }
                        
                        overTimeRemoveFlag = 0;
                    }
                    
                    correctionGR = 0;
                    
                    if (lineageGravityCenterCurrentHoldCount != 0) retainingImageNo = arrayLineageGravityCenterCurrentHold [0];
                    else retainingImageNo = 0;
                    
                    for (int counter1 = 0; counter1 < lineageGRCurrentCount/4; counter1++){
                        if (arrayLineageGRCurrent [counter1*4] == 0 || imageNumberTrackForDisplay == retainingImageNo || trackingUpperLimit == imageNumberTrackForDisplay-1);
                        else if (arrayLineageGRCurrent [counter1*4] == imageNumberTrackForDisplay+1){
                            arrayLineageGRCurrent [counter1*4] = 0;
                            correctionGR = 1;
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < lineageGravityCenterCurrentHoldCount/4; counter1++){
                        if (arrayLineageGravityCenterCurrentHold [counter1*4] == imageNumberTrackForDisplay+1 && correctionGR == 1){
                            if (lineageGRCurrentCount+8 > lineageGRCurrentLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate lineageGRCurrentUpDate];
                            }
                            
                            arrayLineageGRCurrent [lineageGRCurrentCount] = arrayLineageGravityCenterCurrentHold [counter1*4], lineageGRCurrentCount++;
                            arrayLineageGRCurrent [lineageGRCurrentCount] = arrayLineageGravityCenterCurrentHold [counter1*4+1], lineageGRCurrentCount++;
                            arrayLineageGRCurrent [lineageGRCurrentCount] = arrayLineageGravityCenterCurrentHold [counter1*4+2], lineageGRCurrentCount++;
                            arrayLineageGRCurrent [lineageGRCurrentCount] = arrayLineageGravityCenterCurrentHold [counter1*4+3], lineageGRCurrentCount++;
                        }
                    }
                    
                    int refLineFind = 0;
                    string lineageNumberTemp = cellLineageNoHold.substr(1);
                    string cellNumberTemp = cellNoHold.substr(1);
                    
                    for (int counter1 = 0; counter1 <positionReviseCount/7; counter1++){
                        if (arrayPositionRevise [counter1*7+4] == atoi(lineageNumberTemp.c_str()) && arrayPositionRevise [counter1*7+6] == atoi(lineageNumberTemp.c_str())) refLineFind++;
                    }
                    
                    if ((fusionOperation == 0 && divisionFusionCancelFlag == 0 && refLineFind != 0) || (fusionOperation == 1 && divisionFusionCancelFlag == 0 && refLineFind != 0) || divisionTypeHold != 0 || ifEntry == 1){
                        if (firstPintHit == 1){
                            int processType2 = 2;
                            int gravityCenterCheckMode = 0;
                            trackingDataSave = [[TrackingDataSave alloc] init];
                            saveResultsReturn = [trackingDataSave trackingDataSaveTemp:processType2:fluorescentCurrentStatus:gravityCenterCheckMode];
                        }
                        else{
                            
                            int processType2 = 3;
                            int gravityCenterCheckMode = 0;
                            trackingDataSave = [[TrackingDataSave alloc] init];
                            saveResultsReturn = [trackingDataSave trackingDataSaveTemp:processType2:fluorescentCurrentStatus:gravityCenterCheckMode];
                        }
                    }
                    else divisionFusionCancelFlag = 0;
                }
                
                if (saveResultsReturn == 0){
                    if (ifEntry == 0){
                        int setCheck = 0;
                        
                        if (keyCode == 124){
                            int processType2 = 4;
                            trackingSet = [[TrackingSet alloc] init];
                            setCheck = [trackingSet trackingSetMain:processType2];
                        }
                        
                        int processType = 2;
                        
                        if (keyCode != 0){
                            trackingSet = [[TrackingSet alloc] init];
                            loadingCheck = [trackingSet trackingSetMain:processType];
                        }
                        
                        if (loadingCheck == 0){
                            if (keyCode == 124 && keyLockON == 0 && autoRefStatus == 1){
                                string cellNoString = cellNoHold.substr(1);
                                
                                for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                                    if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay && (arrayEventSequence [counter1*4+3] != atoi(cellNoString.c_str()) || arrayEventSequence [counter1*4+1] == 91 || arrayEventSequence [counter1*4+1] == 92)){
                                        setCheck = 0;
                                    }
                                }
                                
                                if (setCheck == 1 && referenceLineCount != 0){
                                    proceedFlag = 0;
                                    processType = 2;
                                    lineSet = [[LineSet alloc] init];
                                    [lineSet lineSetProcess:processType];
                                }
                            }
                            else{
                                
                                referenceLineCount = 0;
                                keyLockON = 0;
                            }
                            
                            if ((int)targetLostMark.find("Lost") != -1 && forceSetAutoFlag == 1 && targetPrevHoldCount != 0){
                                if (targetStatus == 0){
                                    arrayTarget = new int [targetPrevHoldCount+500];
                                    targetCount = 0;
                                    targetLimit = targetPrevHoldCount+500;
                                    targetStatus = 1;
                                }
                                
                                targetCount = 0;
                                
                                for (int counter1 = 0; counter1 < targetPrevHoldCount/2; counter1++){
                                    arrayTarget [targetCount] = arrayTargetPrevHold [counter1*2], targetCount++;
                                    arrayTarget [targetCount] = arrayTargetPrevHold [counter1*2+1], targetCount++;
                                }
                                
                                saveShortCutNumber = 5;
                            }
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Data Read Error"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                            
                            referenceLineCount = 0;
                            keyLockON = 0;
                        }
                    }
                    
                    if (ifEntry == 1){
                        int processType = 7;
                        
                        if (keyCode != 0){
                            trackingSet = [[TrackingSet alloc] init];
                            loadingCheck = [trackingSet trackingSetMain:processType];
                            
                            if (loadingCheck == 1){
                                NSAlert *alert = [[NSAlert alloc] init];
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Data Read Error"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                    }
                    
                    if (loadingCheck == 0) trackingPermit = 1;
                }
            }
            else if (trackingOn == 3 && (trackingLowerLimit > imageNumberTrackForDisplay || trackingUpperLimit < imageNumberTrackForDisplay)){
                keyLockON = 0;
                
                if (lineModificationFlag == 1 && keyCode == 124 && overTimeRemoveFlag == 1){
                    string connectDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold;
                    string entry;
                    string stringExtract;
                    string removePath;
                    
                    fileDeleteCount = 0;
                    
                    DIR *dir = opendir(connectDataTempPath.c_str());
                    struct dirent *dent;
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (fileDeleteCount+5 > fileDeleteLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate fileDeleteUpDate];
                            }
                            
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                        
                        closedir(dir);
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            entry = arrayFileDelete [counter1];
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if (entry.length() > 4 && entry.find("_") == 4){
                                    stringExtract = entry.substr(0, 4);
                                    
                                    if (atoi(stringExtract.c_str()) > imageNumberTrackForDisplay-1){
                                        removePath = connectDataTempPath+"/"+entry;
                                        remove(removePath.c_str());
                                    }
                                }
                            }
                        }
                    }
                    
                    overTimeRemoveFlag = 0;
                }
                
                int blockFlag = 0;
                
                for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                    if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay-1){
                        if (arrayEventSequence [counter1*4+1] == 32 || arrayEventSequence [counter1*4+1] == 42 || arrayEventSequence [counter1*4+1] == 52){
                            blockFlag = 1;
                            break;
                        }
                    }
                    
                    if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay-1){
                        if (arrayEventSequence [counter1*4+1] == 91){
                            blockFlag = 1;
                            break;
                        }
                    }
                }
                
                int dummyFusionCheck = 0;
                
                string extensionLineage = to_string(imageNumberTrackForDisplay-1);
                
                if (extensionLineage.length() == 1) extensionLineage = "000"+extensionLineage;
                else if (extensionLineage.length() == 2) extensionLineage = "00"+extensionLineage;
                else if (extensionLineage.length() == 3) extensionLineage = "0"+extensionLineage;
                
                string connectDataTempPathDummy = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_MasterDataTempD";
                
                struct stat sizeOfFile;
                
                if (stat(connectDataTempPathDummy.c_str(), &sizeOfFile) == 0){
                    if (blockFlag == 1) dummyFusionCheck = 1;
                }
                
                if (lineModificationFlag == 1 && keyCode == 124 && trackingUpperLimit >= imageNumberTrackForDisplay-1 && dummyFusionCheck == 0){
                    if (endPointHit == 1){
                        int processType2 = 2;
                        int gravityCenterCheckMode = 0;
                        trackingDataSave = [[TrackingDataSave alloc] init];
                        saveResultsReturn = [trackingDataSave trackingDataSaveTemp:processType2:fluorescentCurrentStatus:gravityCenterCheckMode];
                    }
                    else{
                        
                        int processType2 = 1;
                        int gravityCenterCheckMode = 0;
                        trackingDataSave = [[TrackingDataSave alloc] init];
                        saveResultsReturn = [trackingDataSave trackingDataSaveTemp:processType2:fluorescentCurrentStatus:gravityCenterCheckMode];
                    }
                }
                
                if (saveResultsReturn == 0){
                    positionReviseCount = 0;
                    gravityCenterRevCount = 0;
                    timeSelectedHoldCount = 0;
                    targetHoldInfoCount = 0;
                    connectLineageRelCount = 0;
                    
                    int dataLoadingCheck = 0;
                    
                    if (ifEntry == 0){
                        int processType = 3;
                        trackingSet = [[TrackingSet alloc] init];
                        dataLoadingCheck = [trackingSet trackingSetMain:processType];
                        trackingPermit = 0;
                    }
                    else if (ifEntry == 1){
                        int processType = 6;
                        trackingSet = [[TrackingSet alloc] init];
                        dataLoadingCheck = [trackingSet trackingSetMain:processType];
                        trackingPermit = 0;
                    }
                    
                    trackingPermit = 0;
                    tableTrackingProcessing = 0;
                    trackingTableSetDone = 1;
                    
                    if (dataLoadingCheck == 1){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Data Read Error"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            else{
                
                int dataLoadingCheck = 0;
                
                if (ifEntry == 0){
                    int processType = 3;
                    trackingSet = [[TrackingSet alloc] init];
                    dataLoadingCheck = [trackingSet trackingSetMain:processType];
                    trackingPermit = 0;
                }
                else if (ifEntry == 1){
                    int processType = 6;
                    trackingSet = [[TrackingSet alloc] init];
                    dataLoadingCheck = [trackingSet trackingSetMain:processType];
                    trackingPermit = 0;
                }
                
                if (dataLoadingCheck == 1){
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Data Read Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        
        if (keyCode == 0 && timeOneStatus == 2 && saveResultsReturn == 0){
            proceedFlag = 1;
            
            fluorescentDetectionDisplay = 0;
            
            int totalSize = imageDimension*imageDimension*4;
            int phaseOpenCheck = 0;
            
            ifstream fin;
            
            if (fluorescentEntryCount != 0){
                string lineageNoExtension = to_string(timeOneHold);
                
                if (lineageNoExtension.length() == 1) lineageNoExtension = "000"+lineageNoExtension;
                else if (lineageNoExtension.length() == 2) lineageNoExtension = "00"+lineageNoExtension;
                else if (lineageNoExtension.length() == 3) lineageNoExtension = "0"+lineageNoExtension;
                
                int fluorescentDisplayFind1 = 0;
                int fluorescentDisplayFind2 = 0;
                int fluorescentDisplayFind3 = 0;
                int fluorescentDisplayFind4 = 0;
                int fluorescentDisplayFind5 = 0;
                int fluorescentDisplayFind6 = 0;
                
                string extension2 = to_string(fluorescentNo1);
                
                string fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+"_"+extension2+"_"+fluorescentName1+exType;
                
                extension2 = to_string(fluorescentNo2);
                
                string fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+"_"+extension2+"_"+fluorescentName2+exType;
                
                extension2 = to_string(fluorescentNo3);
                
                string fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+"_"+extension2+"_"+fluorescentName3+exType;
                
                extension2 = to_string(fluorescentNo4);
                
                string fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+"_"+extension2+"_"+fluorescentName4+exType;
                
                extension2 = to_string(fluorescentNo5);
                
                string fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+"_"+extension2+"_"+fluorescentName5+exType;
                
                extension2 = to_string(fluorescentNo6);
                
                string fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+"_"+extension2+"_"+fluorescentName6+exType;
                
                struct stat sizeOfFile;
                
                if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0){
                    fluorescentDisplayFind1 = 1;
                }
                
                if (stat(fluorescentPath2.c_str(), &sizeOfFile) == 0){
                    fluorescentDisplayFind2 = 1;
                }
                
                if (stat(fluorescentPath3.c_str(), &sizeOfFile) == 0){
                    fluorescentDisplayFind3 = 1;
                }
                
                if (stat(fluorescentPath4.c_str(), &sizeOfFile) == 0){
                    fluorescentDisplayFind4 = 1;
                }
                
                if (stat(fluorescentPath5.c_str(), &sizeOfFile) == 0){
                    fluorescentDisplayFind5 = 1;
                }
                
                if (stat(fluorescentPath6.c_str(), &sizeOfFile) == 0){
                    fluorescentDisplayFind6 = 1;
                }
                
                int fluorescentColorNoHold = 0;
                
                if (fluorescentDisplayNo == 1 && fluorescentDisplayFind1 == 1){
                    displayImagePath = fluorescentPath1;
                    fluorescentColorNoHold = fluorescentNo1;
                }
                else if (fluorescentDisplayNo == 1 && fluorescentDisplayFind1 == 0){
                    if (fluorescentDisplayFind2 == 1){
                        fluorescentDisplayNo = 2;
                        displayImagePath = fluorescentPath2;
                        fluorescentColorNoHold = fluorescentNo2;
                    }
                    else if (fluorescentDisplayFind3 == 1){
                        fluorescentDisplayNo = 3;
                        displayImagePath = fluorescentPath3;
                        fluorescentColorNoHold = fluorescentNo3;
                    }
                    else if (fluorescentDisplayFind4 == 1){
                        fluorescentDisplayNo = 4;
                        displayImagePath = fluorescentPath4;
                        fluorescentColorNoHold = fluorescentNo4;
                    }
                    else if (fluorescentDisplayFind5 == 1){
                        fluorescentDisplayNo = 5;
                        displayImagePath = fluorescentPath5;
                        fluorescentColorNoHold = fluorescentNo5;
                    }
                    else if (fluorescentDisplayFind6 == 1){
                        fluorescentDisplayNo = 6;
                        displayImagePath = fluorescentPath6;
                        fluorescentColorNoHold = fluorescentNo6;
                    }
                    else fluorescentDisplayNo = 0;
                }
                else if (fluorescentDisplayNo == 2 && fluorescentDisplayFind2 == 1){
                    displayImagePath = fluorescentPath2;
                    fluorescentColorNoHold = fluorescentNo2;
                }
                else if (fluorescentDisplayNo == 2 && fluorescentDisplayFind2 == 0){
                    if (fluorescentDisplayFind3 == 1){
                        fluorescentDisplayNo = 3;
                        displayImagePath = fluorescentPath3;
                        fluorescentColorNoHold = fluorescentNo3;
                    }
                    else if (fluorescentDisplayFind4 == 1){
                        fluorescentDisplayNo = 4;
                        displayImagePath = fluorescentPath4;
                        fluorescentColorNoHold = fluorescentNo4;
                    }
                    else if (fluorescentDisplayFind5 == 1){
                        fluorescentDisplayNo = 5;
                        displayImagePath = fluorescentPath5;
                        fluorescentColorNoHold = fluorescentNo5;
                    }
                    else if (fluorescentDisplayFind6 == 1){
                        fluorescentDisplayNo = 6;
                        displayImagePath = fluorescentPath6;
                        fluorescentColorNoHold = fluorescentNo6;
                    }
                    else fluorescentDisplayNo = 0;
                }
                else if (fluorescentDisplayNo == 3 && fluorescentDisplayFind3 == 1){
                    displayImagePath = fluorescentPath3;
                    fluorescentColorNoHold = fluorescentNo3;
                }
                else if (fluorescentDisplayNo == 3 && fluorescentDisplayFind3 == 0){
                    if (fluorescentDisplayFind4 == 1){
                        fluorescentDisplayNo = 4;
                        displayImagePath = fluorescentPath4;
                        fluorescentColorNoHold = fluorescentNo4;
                    }
                    else if (fluorescentDisplayFind5 == 1){
                        fluorescentDisplayNo = 5;
                        displayImagePath = fluorescentPath5;
                        fluorescentColorNoHold = fluorescentNo5;
                    }
                    else if (fluorescentDisplayFind6 == 1){
                        fluorescentDisplayNo = 6;
                        displayImagePath = fluorescentPath6;
                        fluorescentColorNoHold = fluorescentNo6;
                    }
                    else fluorescentDisplayNo = 0;
                }
                else if (fluorescentDisplayNo == 4 && fluorescentDisplayFind4 == 1){
                    displayImagePath = fluorescentPath4;
                    fluorescentColorNoHold = fluorescentNo4;
                }
                else if (fluorescentDisplayNo == 4 && fluorescentDisplayFind4 == 0){
                    if (fluorescentDisplayFind5 == 1){
                        fluorescentDisplayNo = 5;
                        displayImagePath = fluorescentPath5;
                        fluorescentColorNoHold = fluorescentNo5;
                    }
                    else if (fluorescentDisplayFind6 == 1){
                        fluorescentDisplayNo = 6;
                        displayImagePath = fluorescentPath6;
                        fluorescentColorNoHold = fluorescentNo6;
                    }
                    else fluorescentDisplayNo = 0;
                }
                else if (fluorescentDisplayNo == 5 && fluorescentDisplayFind5 == 1){
                    displayImagePath = fluorescentPath5;
                    fluorescentColorNoHold = fluorescentNo5;
                }
                else if (fluorescentDisplayNo == 5 && fluorescentDisplayFind5 == 0){
                    if (fluorescentDisplayFind6 == 1){
                        fluorescentDisplayNo = 6;
                        displayImagePath = fluorescentPath6;
                        fluorescentColorNoHold = fluorescentNo6;
                    }
                    else fluorescentDisplayNo = 0;
                }
                else if (fluorescentDisplayNo == 6 && fluorescentDisplayFind6 == 1){
                    displayImagePath = fluorescentPath6;
                    fluorescentColorNoHold = fluorescentNo6;
                }
                else if (fluorescentDisplayNo == 6 && fluorescentDisplayFind6 == 0) fluorescentDisplayNo = 0;
                
                if (fluorescentDisplayFind1 == 1 || fluorescentDisplayFind2 == 1 || fluorescentDisplayFind3 == 1 || fluorescentDisplayFind4 == 1 || fluorescentDisplayFind5 == 1 || fluorescentDisplayFind6 == 1) fluorescentDetectionDisplay = 1;
                
                if (fluorescentDisplayNo == 0){
                    if (phaseStatus == 1){
                        displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Phase/"+"Phase "+lineageNoExtension+exType;
                        
                        fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            phaseOpenCheck = 1;
                        }
                    }
                    
                    if (phaseStatus == 0 || phaseOpenCheck == 0){
                        displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+exType;
                    }
                    
                    uint8_t *uploadTemp = new uint8_t [totalSize+1];
                    fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        if (exType == ".tif"){
                            fin.read((char*)uploadTemp, totalSize+1);
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            
                            unsigned long headPosition = 0;
                            
                            dataConversion [0] = uploadTemp [0];
                            dataConversion [1] = uploadTemp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTemp [7];
                                dataConversion [1] = uploadTemp [6];
                                dataConversion [2] = uploadTemp [5];
                                dataConversion [3] = uploadTemp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTemp [4];
                                dataConversion [1] = uploadTemp [5];
                                dataConversion [2] = uploadTemp [6];
                                dataConversion [3] = uploadTemp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (tifImageColorGray == 0){
                                NSBitmapImageRep *bitmapReps;
                                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                                
                                unsigned char *bitmapData = [bitmapReps bitmapData];
                                
                                for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                    *bitmapData++ = uploadTemp [counter1];
                                }
                                
                                trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                [trackingImage addRepresentation:bitmapReps];
                            }
                            else if (tifImageColorGray == 1){
                                NSBitmapImageRep *bitmapReps = nil;
                                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                                
                                unsigned char *bitmapData = [bitmapReps bitmapData];
                                
                                for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                    value0 = uploadTemp [counter1];
                                    value1 = uploadTemp [counter1+1];
                                    value2 = uploadTemp [counter1+2];
                                    
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = (unsigned char)value1;
                                    *bitmapData++ = (unsigned char)value2;
                                    *bitmapData++ = 0;
                                }
                                
                                trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                [trackingImage addRepresentation:bitmapReps];
                            }
                        }
                        else if (exType == ".bmp"){
                            fin.read((char*)uploadTemp, totalSize+1);
                            fin.close();
                            
                            NSBitmapImageRep *bitmapReps;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                    *bitmapData++ = uploadTemp [1078+counter1*imageDimension+counter2];
                                }
                            }
                            
                            trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [trackingImage addRepresentation:bitmapReps];
                        }
                    }
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    uint8_t *uploadTemp = new uint8_t [totalSize];
                    fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        if (exType == ".tif"){
                            fin.read((char*)uploadTemp, totalSize+1);
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            
                            unsigned long headPosition = 0;
                            
                            dataConversion [0] = uploadTemp [0];
                            dataConversion [1] = uploadTemp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTemp [7];
                                dataConversion [1] = uploadTemp [6];
                                dataConversion [2] = uploadTemp [5];
                                dataConversion [3] = uploadTemp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTemp [4];
                                dataConversion [1] = uploadTemp [5];
                                dataConversion [2] = uploadTemp [6];
                                dataConversion [3] = uploadTemp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (tifImageColorGray == 0){
                                NSBitmapImageRep *bitmapReps = nil;
                                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                                
                                unsigned char *bitmapData = [bitmapReps bitmapData];
                                
                                int readDataTemp = 0;
                                
                                for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                    readDataTemp = uploadTemp [counter1];
                                    
                                    if (fluorescentDisplayMode == 0){
                                        if (fluorescentDisplayNo == 1 && readDataTemp < fluorescentCutOff1) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 2 && readDataTemp < fluorescentCutOff2) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 3 && readDataTemp < fluorescentCutOff3) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 4 && readDataTemp < fluorescentCutOff4) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 5 && readDataTemp < fluorescentCutOff5) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 6 && readDataTemp < fluorescentCutOff6) readDataTemp = 0;
                                        
                                        if (fluorescentColorNoHold == 1){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 2){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 3){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 4){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 5){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 6){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 7){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.674));
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 8){
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.627));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.125));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.941));
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 9){
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.529));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.808));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.922));
                                            *bitmapData++ = 0;
                                        }
                                    }
                                    else{
                                        
                                        if (fluorescentDisplayRange == 2){
                                            if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else{
                                                
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                        }
                                        else if (fluorescentDisplayRange == 3){
                                            if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*2){
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                            else{
                                                
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                        }
                                        else if (fluorescentDisplayRange == 4){
                                            if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*2){
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                            else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*3){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else{
                                                
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                        }
                                    }
                                }
                                
                                trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                [trackingImage addRepresentation:bitmapReps];
                            }
                            else if (tifImageColorGray == 1){
                                NSBitmapImageRep *bitmapReps = nil;
                                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                                
                                unsigned char *bitmapData = [bitmapReps bitmapData];
                                
                                for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                    value0 = uploadTemp [counter1];
                                    value1 = uploadTemp [counter1+1];
                                    value2 = uploadTemp [counter1+2];
                                    
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = (unsigned char)value1;
                                    *bitmapData++ = (unsigned char)value2;
                                    *bitmapData++ = 0;
                                }
                                
                                trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                [trackingImage addRepresentation:bitmapReps];
                            }
                        }
                        else if (exType == ".bmp"){
                            NSBitmapImageRep *bitmapReps = nil;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            int readDataTemp = 0;
                            
                            fin.read((char*)uploadTemp, totalSize+1);
                            fin.close();
                            
                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                    readDataTemp = uploadTemp [1078+counter1*imageDimension+counter2];
                                    
                                    if (fluorescentDisplayMode == 0){
                                        if (fluorescentDisplayNo == 1 && readDataTemp < fluorescentCutOff1) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 2 && readDataTemp < fluorescentCutOff2) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 3 && readDataTemp < fluorescentCutOff3) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 4 && readDataTemp < fluorescentCutOff4) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 5 && readDataTemp < fluorescentCutOff5) readDataTemp = 0;
                                        else if (fluorescentDisplayNo == 6 && readDataTemp < fluorescentCutOff6) readDataTemp = 0;
                                        
                                        if (fluorescentColorNoHold == 1){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 2){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 3){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 4){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 5){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 6){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 7){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.674));
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 8){
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.627));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.125));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.941));
                                            *bitmapData++ = 0;
                                        }
                                        else if (fluorescentColorNoHold == 9){
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.529));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.808));
                                            *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.922));
                                            *bitmapData++ = 0;
                                        }
                                    }
                                    else{
                                        
                                        if (fluorescentDisplayRange == 2){
                                            if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else{
                                                
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                        }
                                        else if (fluorescentDisplayRange == 3){
                                            if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*2){
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                            else{
                                                
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                        }
                                        else if (fluorescentDisplayRange == 4){
                                            if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*2){
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                            else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*3){
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                            }
                                            else{
                                                
                                                *bitmapData++ = (unsigned char)readDataTemp;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                                *bitmapData++ = 0;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [trackingImage addRepresentation:bitmapReps];
                        }
                    }
                    
                    delete [] uploadTemp;
                }
            }
            else{
                
                string lineageNoExtension = to_string(timeOneHold);
                
                if (phaseStatus == 1){
                    displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Phase/"+"Phase "+lineageNoExtension+exType;
                    
                    fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.close();
                        phaseOpenCheck = 1;
                    }
                }
                
                if (phaseStatus == 0 || phaseOpenCheck == 0){
                    displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+exType;
                }
                
                uint8_t *uploadTemp = new uint8_t [totalSize];
                fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    if (exType == ".tif"){
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        int dataConversion [4];
                        int endianType = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        
                        unsigned long headPosition = 0;
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        if (tifImageColorGray == 0){
                            NSBitmapImageRep *bitmapReps;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                *bitmapData++ = uploadTemp [counter1];
                            }
                            
                            trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [trackingImage addRepresentation:bitmapReps];
                        }
                        else if (tifImageColorGray == 1){
                            NSBitmapImageRep *bitmapReps = nil;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                value0 = uploadTemp [counter1];
                                value1 = uploadTemp [counter1+1];
                                value2 = uploadTemp [counter1+2];
                                
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value1;
                                *bitmapData++ = (unsigned char)value2;
                                *bitmapData++ = 0;
                            }
                            
                            trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [trackingImage addRepresentation:bitmapReps];
                        }
                    }
                    else if (exType == ".bmp"){
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        NSBitmapImageRep *bitmapReps;
                        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                        
                        unsigned char *bitmapData = [bitmapReps bitmapData];
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                *bitmapData++ = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                        }
                        
                        trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                        [trackingImage addRepresentation:bitmapReps];
                    }
                }
                
                delete [] uploadTemp;
            }
        }
        
        if (keyCode == 0 && keyLockON == 1 && fluorescentDetectionDisplay == 1 && timeOneStatus == 0 && saveResultsReturn == 0){
            proceedFlag = 1;
            
            string extension2;
            string extension = to_string(imageNumberTrackForDisplay);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            int fluorescentDisplayFind1 = 0;
            int fluorescentDisplayFind2 = 0;
            int fluorescentDisplayFind3 = 0;
            int fluorescentDisplayFind4 = 0;
            int fluorescentDisplayFind5 = 0;
            int fluorescentDisplayFind6 = 0;
            
            extension2 = to_string(fluorescentNo1);
            
            string fluorescentPath1;
            if (ifEntry == 0) fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+exType;
            else if (ifEntry == 1) fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+exTypeIF+fluorescentRoundNo;
            
            extension2 = to_string(fluorescentNo2);
            
            string fluorescentPath2;
            if (ifEntry == 0) fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName2+exType;
            else if (ifEntry == 1) fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName2+exTypeIF+fluorescentRoundNo;
            
            extension2 = to_string(fluorescentNo3);
            
            string fluorescentPath3;
            if (ifEntry == 0) fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName3+exType;
            else if (ifEntry == 1) fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName3+exTypeIF+fluorescentRoundNo;
            
            extension2 = to_string(fluorescentNo4);
            
            string fluorescentPath4;
            if (ifEntry == 0) fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName4+exType;
            else if (ifEntry == 1) fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName4+exTypeIF+fluorescentRoundNo;
            
            extension2 = to_string(fluorescentNo5);
            
            string fluorescentPath5;
            if (ifEntry == 0) fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName5+exType;
            else if (ifEntry == 1) fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName5+exTypeIF+fluorescentRoundNo;
            
            extension2 = to_string(fluorescentNo6);
            
            string fluorescentPath6;
            if (ifEntry == 0) fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName6+exType;
            else if (ifEntry == 1) fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName6+exTypeIF+fluorescentRoundNo;
            
            struct stat sizeOfFile;
            
            if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind1 = 1;
            }
            
            if (stat(fluorescentPath2.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind2 = 1;
            }
            
            if (stat(fluorescentPath3.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind3 = 1;
            }
            
            if (stat(fluorescentPath4.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind4 = 1;
            }
            
            if (stat(fluorescentPath5.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind5 = 1;
            }
            
            if (stat(fluorescentPath6.c_str(), &sizeOfFile) == 0){
                fluorescentDisplayFind6 = 1;
            }
            
            int fluorescentColorNoHold = 0;
            
            if (fluorescentDisplayNo == 1 && fluorescentDisplayFind1 == 1){
                displayImagePath = fluorescentPath1;
                fluorescentColorNoHold = fluorescentNo1;
            }
            else if (fluorescentDisplayNo == 1 && fluorescentDisplayFind1 == 0){
                if (fluorescentDisplayFind2 == 1){
                    fluorescentDisplayNo = 2;
                    displayImagePath = fluorescentPath2;
                    fluorescentColorNoHold = fluorescentNo2;
                }
                else if (fluorescentDisplayFind3 == 1){
                    fluorescentDisplayNo = 3;
                    displayImagePath = fluorescentPath3;
                    fluorescentColorNoHold = fluorescentNo3;
                }
                else if (fluorescentDisplayFind4 == 1){
                    fluorescentDisplayNo = 4;
                    displayImagePath = fluorescentPath4;
                    fluorescentColorNoHold = fluorescentNo4;
                }
                else if (fluorescentDisplayFind5 == 1){
                    fluorescentDisplayNo = 5;
                    displayImagePath = fluorescentPath5;
                    fluorescentColorNoHold = fluorescentNo5;
                }
                else if (fluorescentDisplayFind6 == 1){
                    fluorescentDisplayNo = 6;
                    displayImagePath = fluorescentPath6;
                    fluorescentColorNoHold = fluorescentNo6;
                }
                else fluorescentDisplayNo = 0;
            }
            else if (fluorescentDisplayNo == 2 && fluorescentDisplayFind2 == 1){
                displayImagePath = fluorescentPath2;
                fluorescentColorNoHold = fluorescentNo2;
            }
            else if (fluorescentDisplayNo == 2 && fluorescentDisplayFind2 == 0){
                if (fluorescentDisplayFind3 == 1){
                    fluorescentDisplayNo = 3;
                    displayImagePath = fluorescentPath3;
                    fluorescentColorNoHold = fluorescentNo3;
                }
                else if (fluorescentDisplayFind4 == 1){
                    fluorescentDisplayNo = 4;
                    displayImagePath = fluorescentPath4;
                    fluorescentColorNoHold = fluorescentNo4;
                }
                else if (fluorescentDisplayFind5 == 1){
                    fluorescentDisplayNo = 5;
                    displayImagePath = fluorescentPath5;
                    fluorescentColorNoHold = fluorescentNo5;
                }
                else if (fluorescentDisplayFind6 == 1){
                    fluorescentDisplayNo = 6;
                    displayImagePath = fluorescentPath6;
                    fluorescentColorNoHold = fluorescentNo6;
                }
                else fluorescentDisplayNo = 0;
            }
            else if (fluorescentDisplayNo == 3 && fluorescentDisplayFind3 == 1){
                displayImagePath = fluorescentPath3;
                fluorescentColorNoHold = fluorescentNo3;
            }
            else if (fluorescentDisplayNo == 3 && fluorescentDisplayFind3 == 0){
                if (fluorescentDisplayFind4 == 1){
                    fluorescentDisplayNo = 4;
                    displayImagePath = fluorescentPath4;
                    fluorescentColorNoHold = fluorescentNo4;
                }
                else if (fluorescentDisplayFind5 == 1){
                    fluorescentDisplayNo = 5;
                    displayImagePath = fluorescentPath5;
                    fluorescentColorNoHold = fluorescentNo5;
                }
                else if (fluorescentDisplayFind6 == 1){
                    fluorescentDisplayNo = 6;
                    displayImagePath = fluorescentPath6;
                    fluorescentColorNoHold = fluorescentNo6;
                }
                else fluorescentDisplayNo = 0;
            }
            else if (fluorescentDisplayNo == 4 && fluorescentDisplayFind4 == 1){
                displayImagePath = fluorescentPath4;
                fluorescentColorNoHold = fluorescentNo4;
            }
            else if (fluorescentDisplayNo == 4 && fluorescentDisplayFind4 == 0){
                if (fluorescentDisplayFind5 == 1){
                    fluorescentDisplayNo = 5;
                    displayImagePath = fluorescentPath5;
                    fluorescentColorNoHold = fluorescentNo5;
                }
                else if (fluorescentDisplayFind6 == 1){
                    fluorescentDisplayNo = 6;
                    displayImagePath = fluorescentPath6;
                    fluorescentColorNoHold = fluorescentNo6;
                }
                else fluorescentDisplayNo = 0;
            }
            else if (fluorescentDisplayNo == 5 && fluorescentDisplayFind5 == 1){
                displayImagePath = fluorescentPath5;
                fluorescentColorNoHold = fluorescentNo5;
            }
            else if (fluorescentDisplayNo == 5 && fluorescentDisplayFind5 == 0){
                if (fluorescentDisplayFind6 == 1){
                    fluorescentDisplayNo = 6;
                    displayImagePath = fluorescentPath6;
                    fluorescentColorNoHold = fluorescentNo6;
                }
                else fluorescentDisplayNo = 0;
            }
            else if (fluorescentDisplayNo == 6 && fluorescentDisplayFind6 == 1){
                displayImagePath = fluorescentPath6;
                fluorescentColorNoHold = fluorescentNo6;
            }
            else if (fluorescentDisplayNo == 6 && fluorescentDisplayFind6 == 0) fluorescentDisplayNo = 0;
            
            int totalSize = imageDimension*imageDimension*4;
            int phaseOpenCheck = 0;
            
            ifstream fin;
            
            if (fluorescentDisplayNo == 0){
                if (phaseStatus == 1){
                    if (ifEntry == 0) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Phase/"+"Phase "+extension+exType;
                    else if (ifEntry == 1) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Phase/"+"Phase "+extension+exTypeIF+fluorescentRoundNo;
                    
                    fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.close();
                        phaseOpenCheck = 1;
                    }
                }
                
                if (phaseStatus == 0 || phaseOpenCheck == 0){
                    if (ifEntry == 0) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Phase/"+"Phase "+extension+exType;
                    else if (ifEntry == 1) displayImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Phase/"+"Phase "+extension+exTypeIF+fluorescentRoundNo;
                }
                
                uint8_t *uploadTemp = new uint8_t [totalSize+1];
                fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    if (exType == ".tif" || exTypeIF == ".TIF"){
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        int dataConversion [4];
                        int endianType = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        
                        unsigned long headPosition = 0;
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        if (tifImageColorGray == 0){
                            NSBitmapImageRep *bitmapReps;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                *bitmapData++ = uploadTemp [counter1];
                            }
                            
                            trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [trackingImage addRepresentation:bitmapReps];
                        }
                        else if (tifImageColorGray == 1){
                            NSBitmapImageRep *bitmapReps = nil;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                value0 = uploadTemp [counter1];
                                value1 = uploadTemp [counter1+1];
                                value2 = uploadTemp [counter1+2];
                                
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value1;
                                *bitmapData++ = (unsigned char)value2;
                                *bitmapData++ = 0;
                            }
                            
                            trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [trackingImage addRepresentation:bitmapReps];
                        }
                    }
                    else if (exType == ".bmp" || exTypeIF == ".BMP"){
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        NSBitmapImageRep *bitmapReps;
                        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                        
                        unsigned char *bitmapData = [bitmapReps bitmapData];
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                *bitmapData++ = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                        }
                        
                        trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                        [trackingImage addRepresentation:bitmapReps];
                    }
                }
                
                delete [] uploadTemp;
            }
            else{
                
                uint8_t *uploadTemp = new uint8_t [totalSize+1];
                fin.open(displayImagePath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    if (exType == ".tif" || exTypeIF == ".TIF"){
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        int dataConversion [4];
                        int endianType = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        
                        unsigned long headPosition = 0;
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        if (tifImageColorGray == 0){
                            NSBitmapImageRep *bitmapReps = nil;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            int readDataTemp = 0;
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                readDataTemp = uploadTemp [counter1];
                                
                                if (fluorescentDisplayMode == 0){
                                    if (fluorescentDisplayNo == 1 && readDataTemp < fluorescentCutOff1) readDataTemp = 0;
                                    else if (fluorescentDisplayNo == 2 && readDataTemp < fluorescentCutOff2) readDataTemp = 0;
                                    else if (fluorescentDisplayNo == 3 && readDataTemp < fluorescentCutOff3) readDataTemp = 0;
                                    else if (fluorescentDisplayNo == 4 && readDataTemp < fluorescentCutOff4) readDataTemp = 0;
                                    else if (fluorescentDisplayNo == 5 && readDataTemp < fluorescentCutOff5) readDataTemp = 0;
                                    else if (fluorescentDisplayNo == 6 && readDataTemp < fluorescentCutOff6) readDataTemp = 0;
                                    
                                    if (fluorescentColorNoHold == 1){
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 2){
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 3){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 4){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 5){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 6){
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 7){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.674));
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 8){
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.627));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.125));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.941));
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 9){
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.529));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.808));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.922));
                                        *bitmapData++ = 0;
                                    }
                                }
                                else{
                                    
                                    if (fluorescentDisplayRange == 2){
                                        if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else{
                                            
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                    }
                                    else if (fluorescentDisplayRange == 3){
                                        if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*2){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else{
                                            
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                    }
                                    else if (fluorescentDisplayRange == 4){
                                        if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*2){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*3){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else{
                                            
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                    }
                                }
                            }
                            
                            trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [trackingImage addRepresentation:bitmapReps];
                        }
                        else if (tifImageColorGray == 1){
                            NSBitmapImageRep *bitmapReps = nil;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                value0 = uploadTemp [counter1];
                                value1 = uploadTemp [counter1+1];
                                value2 = uploadTemp [counter1+2];
                                
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value1;
                                *bitmapData++ = (unsigned char)value2;
                                *bitmapData++ = 0;
                            }
                            
                            trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [trackingImage addRepresentation:bitmapReps];
                        }
                    }
                    else if (exType == ".bmp" || exTypeIF == ".BMP"){
                        NSBitmapImageRep *bitmapReps = nil;
                        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                        
                        unsigned char *bitmapData = [bitmapReps bitmapData];
                        
                        int readDataTemp = 0;
                        
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                readDataTemp = uploadTemp [1078+counter1*imageDimension+counter2];
                                
                                if (fluorescentDisplayMode == 0){
                                    if (fluorescentDisplayNo == 1 && readDataTemp < fluorescentCutOff1) readDataTemp = 0;
                                    else if (fluorescentDisplayNo == 2 && readDataTemp < fluorescentCutOff2) readDataTemp = 0;
                                    else if (fluorescentDisplayNo == 3 && readDataTemp < fluorescentCutOff3) readDataTemp = 0;
                                    else if (fluorescentDisplayNo == 4 && readDataTemp < fluorescentCutOff4) readDataTemp = 0;
                                    else if (fluorescentDisplayNo == 5 && readDataTemp < fluorescentCutOff5) readDataTemp = 0;
                                    else if (fluorescentDisplayNo == 6 && readDataTemp < fluorescentCutOff6) readDataTemp = 0;
                                    
                                    if (fluorescentColorNoHold == 1){
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 2){
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 3){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 4){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 5){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 6){
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 7){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.674));
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 8){
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.627));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.125));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.941));
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 9){
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.529));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.808));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.922));
                                        *bitmapData++ = 0;
                                    }
                                }
                                else{
                                    
                                    if (fluorescentDisplayRange == 2){
                                        if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else{
                                            
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                    }
                                    else if (fluorescentDisplayRange == 3){
                                        if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*2){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else{
                                            
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                    }
                                    else if (fluorescentDisplayRange == 4){
                                        if (readDataTemp < fluorescentDisplayMax/(double)fluorescentDisplayRange){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*2){
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                        else if (readDataTemp < (fluorescentDisplayMax/(double)fluorescentDisplayRange)*3){
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                        }
                                        else{
                                            
                                            *bitmapData++ = (unsigned char)readDataTemp;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                            *bitmapData++ = 0;
                                        }
                                    }
                                }
                            }
                        }
                        
                        trackingImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                        [trackingImage addRepresentation:bitmapReps];
                    }
                }
                
                delete [] uploadTemp;
            }
        }
        
        if (saveResultsReturn == 0 && proceedFlag == 1) [self setNeedsDisplay:YES];
    }
}

//-----First Responder-----
-(BOOL)acceptsFirstResponder{
    return YES;
}

- (void)drawRect:(NSRect)rect {
    [[NSColor blackColor] set];
    
    NSBezierPath *path;
    path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 700, 700)];
    [path fill];
    
    NSRect srcRect;
    srcRect.origin.x = xPositionTrack+xPositionAdjustTrack+xPositionMoveTrack;
    srcRect.origin.y = yPositionTrack+yPositionAdjustTrack+yPositionMoveTrack;
    srcRect.size.width = imageWidthTrack/(double)(magnificationTrack*0.1);
    srcRect.size.height = imageHeightTrack/(double)(magnificationTrack*0.1);
    
    [trackingImage drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
    
    if (mouseDragFlag == 0 && imageEndHold != 0){
        double xPositionAdjustDouble = xPositionAdjustTrack+xPositionTrack;
        double yPositionAdjustDouble = yPositionAdjustTrack+yPositionTrack;
        double xCalculationValue = 1/(double)windowWidthTrack*magnificationTrack*0.1;
        double yCalculationValue = 1/(double)windowHeightTrack*magnificationTrack*0.1;
        double magnificationDisplay2 = magnificationTrack*0.1*0.4*lineWidth;
        double magnificationLine = magnificationTrack*0.1*2.0;
        double magnificationFont = magnificationTrack*0.08*3.5;
        
        // for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
        // 	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
        //	cout<<" arrayTimeSelected "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
        //  	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
        // 	cout<<" arrayGravityCenterRev "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
        //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
        //	cout<<" arrayPositionRevise "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
        //   cout<<" arrayConnectLineageRel "<<counterA<<endl;
        //}
        
        double displayFrequencyTemp = (2-xPositionAdjustDouble)*xCalculationValue-(1-xPositionAdjustDouble)*xCalculationValue;
        int displayFrequency = (int)displayFrequencyTemp;
        
        if (lineTypeSet == 1){
            if (displayFrequencyTemp <= 0.3 && displayFrequencyTemp != 0) displayFrequency = (int)(9/(double)displayFrequencyTemp);
            else if (displayFrequencyTemp <= 0.5 && displayFrequencyTemp > 0.3) displayFrequency = (int)(7/(double)displayFrequencyTemp);
            else if (displayFrequencyTemp <= 1 && displayFrequencyTemp > 0.5) displayFrequency = (int)(5/(double)displayFrequencyTemp);
            else if (displayFrequencyTemp <= 2 && displayFrequencyTemp > 1) displayFrequency = 4;
            else if (displayFrequencyTemp <= 3 && displayFrequencyTemp > 2) displayFrequency = 3;
            else if (displayFrequencyTemp <= 4 && displayFrequencyTemp > 3) displayFrequency = 2;
            else if (displayFrequencyTemp > 4) displayFrequency = 1;
        }
        else{
            
            if (displayFrequencyTemp <= 0.3 && displayFrequencyTemp != 0) displayFrequency = (int)(8/(double)displayFrequencyTemp);
            else if (displayFrequencyTemp <= 0.5 && displayFrequencyTemp > 0.3) displayFrequency = (int)(6/(double)displayFrequencyTemp);
            else if (displayFrequencyTemp <= 1 && displayFrequencyTemp > 0.5) displayFrequency = (int)(4/(double)displayFrequencyTemp);
            else if (displayFrequencyTemp <= 2 && displayFrequencyTemp > 1) displayFrequency = 2;
            else if (displayFrequencyTemp <= 3 && displayFrequencyTemp > 2) displayFrequency = 1;
            else if (displayFrequencyTemp <= 4 && displayFrequencyTemp > 3) displayFrequency = 1;
            else if (displayFrequencyTemp > 4) displayFrequency = 1;
        }
        
        CGFloat sizeCalculation = 512*xCalculationValue;
        sizeCalculation = (sizeCalculation/(double)700)*0.5;
        
        if (sizeCalculation >= 3) sizeCalculation = 3;
        
        string extension2 = "";
        string eventString = "";
        
        //-----Tracking Mode-----
        if (timeOneStatus == 0){
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //	cout<<" arrayTimeSelected "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
            //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
            //	cout<<" arrayEventSequencey "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < lineageGRCurrentCount/4; counterA++){
            //  for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrent [counterA*4+counterB];
            //    cout<<" arrayLineageGRCurrent "<<counterA<<endl;
            //}
            
            //-----Double crick for window lock-----
            if (doubleClick == 1 && trackingOn == 3){
                doubleClick = 0;
                
                if (lineDraw == 1 && doubleClickStatusHold == 0){
                    windowLock = 0;
                    lineDraw = 0;
                    doubleClickStatusHold = 2;
                }
                else if (lineDraw == 0 && doubleClickStatusHold == 2){
                    windowLock = 1;
                    lineDraw = 1;
                    doubleClickStatusHold = 0;
                }
            }
            
            NSBezierPath *path3;
            
            NSPoint positionAA;
            NSPoint positionBB;
            NSPoint positionCC;
            NSPoint positionDD;
            
            NSPoint pointA;
            NSAttributedString *attrStrA;
            NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
            NSString *vectorNumberDisplay;
            
            //-----Whole line data, TrackingOn = 1, or TrackingOn = 3, outside of range-----
            [NSBezierPath setDefaultLineWidth:sizeCalculation];
            [attributesA setObject:[NSFont systemFontOfSize:magnificationFont] forKey:NSFontAttributeName];
            [attributesA removeObjectForKey:NSBackgroundColorAttributeName];
            
            string lineageExtract = "";
            string cellNumberExtract = "";
            int lineageExtractInt = 0;
            int cellNoExtractInt = -1;
            
            if (cellLineageNoHold != ""){
                lineageExtract = cellLineageNoHold.substr(1);
                lineageExtractInt = atoi(lineageExtract.c_str());
            }
            if (cellNoHold != ""){
                cellNumberExtract = cellNoHold.substr(1);
                cellNoExtractInt = atoi(cellNumberExtract.c_str());
            }
            
            int startPoint = 0;
            int noiseLineStatus = 0;
            int endPoint = 0;
            int xPointMarkTemp = 0;
            int yPointMarkTemp = 0;
            int endHoldTemp = 0;
            
            if (trackingOn == 1 || (trackingOn == 3 && trackingPermit == 0)){
                //for (int counterA = 0; counterA < masterLineSelectedCount/10; counterA++){
                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayMasterLineSelected [counterA*10+counterB];
                //    cout<<" arrayMasterLineSelected "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < masterLineForTrackingCount/7; counterA++){
                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayMasterLineForTracking [counterA*7+counterB];
                //    cout<<" arrayMasterLineForTracking "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < connectLineListLocalCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineListLocal [counterA*6+counterB];
                //	cout<<" arrayConnectLineListLocal "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < masterLineSelectedCount/10; counter1++){
                    if (arrayMasterLineSelected [counter1*10] == 0 || arrayMasterLineSelected [counter1*10] == 1 || arrayMasterLineSelected [counter1*10] == 2 || arrayMasterLineSelected [counter1*10] == 7){
                        startPoint = arrayMasterLineSelected [counter1*10+2];
                        noiseLineStatus = arrayMasterLineSelected [counter1*10];
                        
                        if (counter1+1 < masterLineSelectedCount/10) endPoint = arrayMasterLineSelected [(counter1+1)*10+2]-1;
                        else endPoint = masterLineForTrackingCount/7-1;
                        
                        endHoldTemp = 0;
                        
                        for (int counter2 = 0; counter2 < cellEndHoldCount/2; counter2++){
                            if (arrayMasterLineForTracking [startPoint*7+6] == cellEndHold [counter2*2] && arrayMasterLineForTracking [startPoint*7+4] == cellEndHold [counter2*2+1]){
                                endHoldTemp = 1;
                                break;
                            }
                        }
                        
                        for (int counter2 = startPoint; counter2 <= endPoint; counter2 = counter2+displayFrequency){
                            if (lineageExtract != "" && cellNumberExtract != "" && arrayMasterLineForTracking [counter2*7+6] == lineageExtractInt && arrayMasterLineForTracking [counter2*7+4] == cellNoExtractInt){
                                xPointMarkTemp = (int)((arrayMasterLineForTracking [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                yPointMarkTemp = (int)(((imageHeightTrack-arrayMasterLineForTracking [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                    [[NSColor cyanColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                    [path3 fill];
                                }
                            }
                            else if ((arrayMasterLineForTracking [counter2*7+5] == 0 && noiseLineStatus != 2) || arrayMasterLineForTracking [counter2*7+5] == 1){
                                xPointMarkTemp = (int)((arrayMasterLineForTracking [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                yPointMarkTemp = (int)(((imageHeightTrack-arrayMasterLineForTracking [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                
                                if (endHoldTemp == 0){
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor greenColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else{
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor brownColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                            }
                            else if (arrayMasterLineForTracking [counter2*7+5] == 0 && noiseLineStatus == 2){
                                xPointMarkTemp = (int)((arrayMasterLineForTracking [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                yPointMarkTemp = (int)(((imageHeightTrack-arrayMasterLineForTracking [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                    [[NSColor grayColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                    [path3 fill];
                                }
                            }
                        }
                    }
                }
                
                [[NSColor blueColor] set];
                
                for (int counter1 = 0; counter1 < connectLineListLocalCount/6; counter1++){ //-----Amended line-----
                    if (arrayConnectLineListLocal [counter1*6+5] == imageNumberTrackForDisplay){
                        xPointMarkTemp = (int)((arrayConnectLineListLocal [counter1*6]-xPositionAdjustDouble)*(double)xCalculationValue);
                        yPointMarkTemp = (int)(((imageHeightTrack-arrayConnectLineListLocal [counter1*6+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                        [path3 stroke];
                    }
                }
                
                //for (int counterA = 0; counterA < masterLineGravityCenterCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayMasterLineGravityCenter [counterA*6+counterB];
                //    cout<<" arrayMasterLineGravityCenter "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < associateDataCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayAssociateData [counterA*6+counterB];
                //	cout<<" arrayAssociateData "<<counterA<<endl;
                //}
                
                [[NSColor blackColor] set];
                [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                int selectNo = 0;
                
                for (int counter1 = 0; counter1 < masterLineSelectedCount/10; counter1++){
                    if (arrayMasterLineSelected [counter1*10] == 0 || arrayMasterLineSelected [counter1*10] == 1 || arrayMasterLineSelected [counter1*10] == 2 || arrayMasterLineSelected [counter1*10] == 7){
                        if (arrayMasterLineForTracking [arrayMasterLineSelected [counter1*10+2]*7+6] == 0){
                            xPointMarkTemp = (int)((arrayMasterLineGravityCenter [counter1*6]-xPositionAdjustDouble)*(double)xCalculationValue);
                            yPointMarkTemp = (int)(((imageHeightTrack-arrayMasterLineGravityCenter [counter1*6+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                            
                            if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                positionAA.x = xPointMarkTemp-magnificationLine;
                                positionAA.y = yPointMarkTemp;
                                positionBB.x = xPointMarkTemp+magnificationLine;
                                positionBB.y = yPointMarkTemp;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                
                                positionCC.x = xPointMarkTemp;
                                positionCC.y = yPointMarkTemp-magnificationLine;
                                positionDD.x = xPointMarkTemp;
                                positionDD.y = yPointMarkTemp+magnificationLine;
                                [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                                
                                if (characterDisplayFlag == 1 || characterDisplayFlag == 0){
                                    selectNo = 0;
                                    
                                    for (int counter2 = 0; counter2 < mergeSelectCount; counter2++){
                                        if (arrayMergeSelect [counter2] == arrayMasterLineGravityCenter [counter1*6+4]){
                                            selectNo = 1;
                                            break;
                                        }
                                    }
                                    
                                    if (selectNo == 0){
                                        vectorNumberDisplay = [NSString stringWithFormat:@"%d", arrayMasterLineGravityCenter [counter1*6+4]];
                                        
                                        attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                                        
                                        pointA.x = xPointMarkTemp+magnificationLine*0.3;
                                        pointA.y = yPointMarkTemp+magnificationLine*0.3;
                                        [attrStrA drawAtPoint:pointA];
                                    }
                                    else{
                                        
                                        [[NSColor blueColor] set];
                                        [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                                        
                                        vectorNumberDisplay = [NSString stringWithFormat:@"%d", arrayMasterLineGravityCenter [counter1*6+4]];
                                        
                                        attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                                        
                                        pointA.x = xPointMarkTemp+magnificationLine*0.3;
                                        pointA.y = yPointMarkTemp+magnificationLine*0.3;
                                        [attrStrA drawAtPoint:pointA];
                                        
                                        [[NSColor blackColor] set];
                                        [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                                    }
                                }
                            }
                        }
                    }
                }
                
                //NSLog (@"%@", vectorNumberDisplay);
                
                if (fluorescentDetectionDisplay == 1 && fluorescentDisplayNo != 0){
                    [[NSColor magentaColor] set];
                    
                    for (int counter1 = 0; counter1 < expandFluorescentOutlineCount/4; counter1 = counter1+displayFrequency){
                        if (expandFluorescentOutline [counter1*4+3] == fluorescentDisplayNo || expandFluorescentOutline [counter1*4+3] == fluorescentDisplayNo+6){
                            xPointMarkTemp = (int)((expandFluorescentOutline [counter1*4]-xPositionAdjustDouble)*(double)xCalculationValue);
                            yPointMarkTemp = (int)(((imageHeightTrack-expandFluorescentOutline [counter1*4+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                            
                            if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                [path3 stroke];
                            }
                        }
                    }
                }
            }
            
            string extensionDisplay = to_string(imageNumberTrackForDisplay);
            
            if (extensionDisplay.length() == 1) extensionDisplay = "000"+extensionDisplay;
            else if (extensionDisplay.length() == 2) extensionDisplay = "00"+extensionDisplay;
            else if (extensionDisplay.length() == 3) extensionDisplay = "0"+extensionDisplay;
            
            string connectDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionDisplay+"_MasterDataTemp";
            
            int trackingFront = 0;
            
            struct stat sizeOfFile;
            
            if (stat(connectDataTempPath.c_str(), &sizeOfFile) == 0 && divisionTypeHold == 0 && fusionOperation == 0){
                trackingFront = 1;
            }
            else if (lineModificationFlag == 1 && divisionTypeHold == 0 && fusionOperation == 0) trackingFront = 1;
            else trackingFront = 0;
            
            if (trackingOn == 3 && trackingPermit == 1){
                string cellNoHoldDivString1 = "";
                string cellNoHoldDivString2 = "";
                string cellNoHoldDivString3 = "";
                string cellNoHoldDivString4 = "";
                int cellNoHoldDivInt1 = -1;
                int cellNoHoldDivInt2 = -1;
                int cellNoHoldDivInt3 = -1;
                int cellNoHoldDivInt4 = -1;
                
                if (cellNoHoldDiv1 != ""){
                    cellNoHoldDivString1 = cellNoHoldDiv1.substr(1);
                    cellNoHoldDivInt1 = atoi(cellNoHoldDivString1.c_str());
                }
                
                if (cellNoHoldDiv2 != ""){
                    cellNoHoldDivString2 = cellNoHoldDiv2.substr(1);
                    cellNoHoldDivInt2 = atoi(cellNoHoldDivString2.c_str());
                }
                
                if (cellNoHoldDiv3 != ""){
                    cellNoHoldDivString3 = cellNoHoldDiv3.substr(1);
                    cellNoHoldDivInt3 = atoi(cellNoHoldDivString3.c_str());
                }
                
                if (cellNoHoldDiv4 != ""){
                    cellNoHoldDivString4 = cellNoHoldDiv4.substr(1);
                    cellNoHoldDivInt4 = atoi(cellNoHoldDivString4.c_str());
                }
                
                int removeMark = 0;
                int valueTemp = 0;
                int valueTemp2 = 0;
                int valueTemp3 = 0;
                int arrayTargetTemp = 0;
                
                //for (int counterA = 0; counterA < connectLineListLocalCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineListLocal [counterA*6+counterB];
                //    cout<<" arrayConnectLineListLocal "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
                //   cout<<" arrayConnectLineageRel "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                    if (arrayTimeSelected [counter1*10] == 0 || arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7 || arrayTimeSelected [counter1*10] == 2){
                        startPoint = arrayTimeSelected [counter1*10+2];
                        removeMark = arrayTimeSelected [counter1*10];
                        
                        if (counter1+1 < timeSelectedCount/10) endPoint = arrayTimeSelected [(counter1+1)*10+2]-1;
                        else endPoint = positionReviseCount/7-1;
                        
                        endHoldTemp = 0;
                        
                        for (int counter2 = 0; counter2 < cellEndHoldCount/2; counter2++){
                            if (arrayMasterLineForTracking [startPoint*7+6] == cellEndHold [counter2*2] && arrayMasterLineForTracking [startPoint*7+4] == cellEndHold [counter2*2+1]){
                                endHoldTemp = 1;
                                break;
                            }
                        }
                        
                        for (int counter2 = startPoint; counter2 <= endPoint; counter2 = counter2+displayFrequency){
                            valueTemp = arrayPositionRevise [counter2*7+6];
                            valueTemp2 = arrayPositionRevise [counter2*7+4];
                            valueTemp3 = arrayPositionRevise [counter2*7+5];
                            
                            if (trackingFront == 1){
                                if (lineageExtract != "" && cellNumberExtract != "" && valueTemp3 == 1 && valueTemp == lineageExtractInt && valueTemp2 == cellNoExtractInt){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        if (ifEntry == 0) [[NSColor yellowColor] set];
                                        else [[NSColor redColor] set];
                                        
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if ((valueTemp3 == 1 || valueTemp3 == 0) && divisionTypeHold == 0 && valueTemp2 == cellNoHoldDivInt1 && lineageExtract != "" && valueTemp == lineageExtractInt){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor yellowColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if ((valueTemp3 == 1 || valueTemp3 == 0) && divisionTypeHold == 0 && valueTemp2 == cellNoHoldDivInt2 && lineageExtract != "" && valueTemp == lineageExtractInt){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor yellowColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if ((valueTemp3 == 1 || valueTemp3 == 0) && divisionTypeHold == 0 && valueTemp2 == cellNoHoldDivInt3 && lineageExtract != "" && valueTemp == lineageExtractInt){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor yellowColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if ((valueTemp3 == 1 || valueTemp3 == 0) && divisionTypeHold == 0 && valueTemp2 == cellNoHoldDivInt4 && lineageExtract != "" && valueTemp == lineageExtractInt){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor yellowColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if ((valueTemp3 == 1 || valueTemp3 == 0) && fusionOperation == 0 && fusionPartnerLin != 0 && fusionPartnerCellNo != -1 && valueTemp == fusionPartnerLin && valueTemp2 == fusionPartnerCellNo){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor yellowColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if (valueTemp3 == 1 || (valueTemp3 == 0 && removeMark != 2)){ //=======================================
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (endHoldTemp == 0){
                                        if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                            [[NSColor greenColor] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                            [path3 fill];
                                        }
                                    }
                                    else{
                                        
                                        if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                            [[NSColor brownColor] set];
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                            [path3 fill];
                                        }
                                    }
                                }
                                else if (valueTemp3 == 0 && removeMark == 2){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor grayColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                            }
                            else if (trackingFront == 0){
                                if ((divisionTypeHold < 2 || (divisionTypeHold >= 2 && cellDivisionSetCount == 0)) && lineageExtract != "" && cellNumberExtract != "" && valueTemp3 == 1 && valueTemp == lineageExtractInt && valueTemp2 == cellNoExtractInt){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor cyanColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if (divisionTypeHold == 2 && ((cellDivisionSetCount == 1 && valueTemp2 == cellNoHoldDivInt1) || (cellDivisionSetCount == 2 && valueTemp2 == cellNoHoldDivInt2)) && lineageExtract != "" && valueTemp == lineageExtractInt){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor cyanColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if (divisionTypeHold == 2 && cellDivisionSetCount >= 1 && lineageExtract != "" && valueTemp == lineageExtractInt && (valueTemp2 == cellNoHoldDivInt1 || valueTemp2 == cellNoHoldDivInt2)){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor purpleColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if (divisionTypeHold == 2 && cellDivisionSetCount >= 1 && lineageExtract != "" && valueTemp == lineageExtractInt){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor greenColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if (divisionTypeHold == 3 && ((cellDivisionSetCount == 1 && valueTemp2 == cellNoHoldDivInt1) || (cellDivisionSetCount == 2 && valueTemp2 == cellNoHoldDivInt2) || (cellDivisionSetCount == 3 && valueTemp2 == cellNoHoldDivInt3)) && lineageExtract != "" && valueTemp == lineageExtractInt){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor cyanColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if (divisionTypeHold == 3 && cellDivisionSetCount >= 1 && lineageExtract != "" && valueTemp == lineageExtractInt && (valueTemp2 == cellNoHoldDivInt1 || valueTemp2 == cellNoHoldDivInt2 || valueTemp2 == cellNoHoldDivInt3)){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor purpleColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if (divisionTypeHold == 3 && cellDivisionSetCount >= 1 && lineageExtract != "" && valueTemp == lineageExtractInt){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor greenColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if (divisionTypeHold == 4 && ((cellDivisionSetCount == 1 && valueTemp2 == cellNoHoldDivInt1) || (cellDivisionSetCount == 2 && valueTemp2 == cellNoHoldDivInt2) || (cellDivisionSetCount == 3 && valueTemp2 == cellNoHoldDivInt3) || (cellDivisionSetCount == 4 && valueTemp2 == cellNoHoldDivInt4)) && lineageExtract != "" && valueTemp == lineageExtractInt){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor cyanColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if (divisionTypeHold == 4 && cellDivisionSetCount >= 1 && lineageExtract != "" && valueTemp == lineageExtractInt && (valueTemp2 == cellNoHoldDivInt1 || valueTemp2 == cellNoHoldDivInt2 || valueTemp2 == cellNoHoldDivInt3 || valueTemp2 == cellNoHoldDivInt4)){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor purpleColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if (divisionTypeHold == 4 && cellDivisionSetCount >= 1 && lineageExtract != "" && valueTemp == lineageExtractInt){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor greenColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if (divisionTypeHold == 2 && cellDivisionSetCount >= 1 && lineageExtract != "" && valueTemp == lineageExtractInt && valueTemp2 != cellNoHoldDivInt1 && valueTemp2 != cellNoHoldDivInt2);
                                else if (divisionTypeHold == 3 && cellDivisionSetCount >= 1 && lineageExtract != "" && valueTemp == lineageExtractInt && valueTemp2 != cellNoHoldDivInt1 && valueTemp2 != cellNoHoldDivInt2 && valueTemp2 != cellNoHoldDivInt3);
                                else if (divisionTypeHold == 4 && cellDivisionSetCount >= 1 && lineageExtract != "" && valueTemp == lineageExtractInt && valueTemp2 != cellNoHoldDivInt1 && valueTemp2 != cellNoHoldDivInt2 && valueTemp2 != cellNoHoldDivInt3 && valueTemp2 != cellNoHoldDivInt4);
                                else if (fusionOperation == 1 && fusionPartnerLin != 0 && valueTemp == fusionPartnerLin && valueTemp2 == fusionPartnerCellNo){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor purpleColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if ((valueTemp3 == 1 || valueTemp3 == 0) && divisionTypeHold == 0 && valueTemp2 == cellNoHoldDivInt1 && lineageExtract != "" && valueTemp == lineageExtractInt){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor cyanColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if ((valueTemp3 == 1 || valueTemp3 == 0) && divisionTypeHold == 0 && valueTemp2 == cellNoHoldDivInt2 && lineageExtract != "" && valueTemp == lineageExtractInt){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor cyanColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if ((valueTemp3 == 1 || valueTemp3 == 0) && divisionTypeHold == 0 && valueTemp2 == cellNoHoldDivInt3 && lineageExtract != "" && valueTemp == lineageExtractInt){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor cyanColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if ((valueTemp3 == 1 || valueTemp3 == 0) && divisionTypeHold == 0 && valueTemp2 == cellNoHoldDivInt4 && lineageExtract != "" && valueTemp == lineageExtractInt){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor cyanColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if ((valueTemp3 == 1 || valueTemp3 == 0) && fusionOperation == 0 && fusionPartnerLin != 0 && fusionPartnerCellNo != -1 && valueTemp == fusionPartnerLin && valueTemp2 == fusionPartnerCellNo && lineageExtract != "" && valueTemp == lineageExtractInt){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    [[NSColor cyanColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                    [path3 fill];
                                }
                                else if (valueTemp3 == 1 || (valueTemp3 == 0 && removeMark != 2)){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor greenColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                                else if (valueTemp3 == 0 && removeMark == 2){
                                    xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                    yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                    
                                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                        [[NSColor grayColor] set];
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                        [path3 fill];
                                    }
                                }
                            }
                        }
                    }
                }
                
                [[NSColor blueColor] set];
                
                for (int counter1 = 0; counter1 < connectLineListLocalCount/6; counter1++){ //-----Amended line-----
                    if (imageNumberTrackForDisplay < firstModificationPoint && arrayConnectLineListLocal [counter1*6+5] == imageNumberTrackForDisplay){
                        xPointMarkTemp = (int)((arrayConnectLineListLocal [counter1*6]-xPositionAdjustDouble)*(double)xCalculationValue);
                        yPointMarkTemp = (int)(((imageHeightTrack-arrayConnectLineListLocal [counter1*6+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                        [path3 stroke];
                    }
                }
                
                //-----GR center, non Lineage connect-----
                [[NSColor blackColor] set];
                [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                int selectNo = 0;
                
                for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                    if (arrayTimeSelected [counter1*10] == 0 || arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7 || arrayTimeSelected [counter1*10] == 2){
                        if (arrayPositionRevise [arrayTimeSelected [counter1*10+2]*7+6] == 0){
                            xPointMarkTemp = (int)((arrayGravityCenterRev [counter1*6]-xPositionAdjustDouble)*(double)xCalculationValue);
                            yPointMarkTemp = (int)(((imageHeightTrack-arrayGravityCenterRev [counter1*6+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                            
                            if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                positionAA.x = xPointMarkTemp-magnificationLine;
                                positionAA.y = yPointMarkTemp;
                                positionBB.x = xPointMarkTemp+magnificationLine;
                                positionBB.y = yPointMarkTemp;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                
                                positionCC.x = xPointMarkTemp;
                                positionCC.y = yPointMarkTemp-magnificationLine;
                                positionDD.x = xPointMarkTemp;
                                positionDD.y = yPointMarkTemp+magnificationLine;
                                [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                                
                                selectNo = 0;
                                
                                for (int counter2 = 0; counter2 < mergeSelectCount; counter2++){
                                    if (arrayMergeSelect [counter2] == arrayGravityCenterRev [counter1*6+4]){
                                        selectNo = 1;
                                        break;
                                    }
                                }
                                
                                if (characterDisplayFlag == 1 || characterDisplayFlag == 0){
                                    if (selectNo == 0){
                                        vectorNumberDisplay = [NSString stringWithFormat:@"%d", arrayGravityCenterRev [counter1*6+4]];
                                        
                                        attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                                        pointA.x = xPointMarkTemp+magnificationLine*0.3;
                                        pointA.y = yPointMarkTemp+magnificationLine*0.3;
                                        [attrStrA drawAtPoint:pointA];
                                    }
                                    else{
                                        
                                        [[NSColor blueColor] set];
                                        [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                                        
                                        vectorNumberDisplay = [NSString stringWithFormat:@"%d", arrayGravityCenterRev [counter1*6+4]];
                                        
                                        attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                                        pointA.x = xPointMarkTemp+magnificationLine*0.3;
                                        pointA.y = yPointMarkTemp+magnificationLine*0.3;
                                        [attrStrA drawAtPoint:pointA];
                                        
                                        [[NSColor blackColor] set];
                                        [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                                    }
                                }
                            }
                        }
                    }
                }
                
                // NSLog (@"%@", vectorNumberDisplay);
                
                //-----Cut line display-----
                [[NSColor redColor] set];
                
                for (int counter1 = 0; counter1 < targetHoldCount/3; counter1++){
                    xPointMarkTemp = (int)((arrayTargetHold [counter1*3]-xPositionAdjustDouble)*(double)xCalculationValue);
                    yPointMarkTemp = (int)(((imageHeightTrack-arrayTargetHold [counter1*3+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                    
                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                        if (arrayTargetHoldInfo [(arrayTargetHold [counter1*3+2]-1)*4+2] == 0){
                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                            [path3 fill];
                        }
                    }
                }
                
                //-----Cut line number display-----
                [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                
                if (targetHoldInfoCount/4 != 0){
                    for (int counter1 = 0; counter1 < targetHoldInfoCount/4; counter1++){
                        xPointMarkTemp = (int)((arrayTargetHoldInfo [counter1*4]-xPositionAdjustDouble)*(double)xCalculationValue);
                        yPointMarkTemp = (int)(((imageHeightTrack-arrayTargetHoldInfo [counter1*4+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                        
                        if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                            vectorNumberDisplay = [NSString stringWithFormat:@"%d", arrayTargetHoldInfo [counter1*4+3]];
                            
                            attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                            pointA.x = xPointMarkTemp+magnificationLine;
                            pointA.y = yPointMarkTemp+magnificationLine;
                            [attrStrA drawAtPoint:pointA];
                        }
                    }
                }
                
                //NSLog (@"%@", vectorNumberDisplay);
                
                //-----Line point display-----
                if (lineDraw == 2){ //-----Point Data entry to arrayTarget-----
                    if (targetCount+4 > targetLimit){
                        int *arrayTargetUpDate = new int [targetCount+10];
                        
                        for (int counter1 = 0; counter1 < targetCount; counter1++) arrayTargetUpDate [counter1] = arrayTarget [counter1];
                        
                        delete [] arrayTarget;
                        arrayTarget = new int [targetLimit+1000];
                        targetLimit = targetLimit+1000;
                        
                        for (int counter1 = 0; counter1 < targetCount; counter1++) arrayTarget [counter1] = arrayTargetUpDate [counter1];
                        delete [] arrayTargetUpDate;
                    }
                    
                    arrayTargetTemp = (int)(xPointLine/(double)xCalculationValue+xPositionAdjustDouble);
                    arrayTarget [targetCount] = arrayTargetTemp, targetCount++;
                    arrayTargetTemp = (int)((yPointLine/(double)yCalculationValue+yPositionAdjustDouble-imageHeightTrack)*-1);
                    arrayTarget [targetCount] = arrayTargetTemp, targetCount++;
                }
                
                if (lineDraw == 1 || lineDraw == 2){ //-----Point display-----
                    for (int counter1 = 0; counter1 < targetCount/2; counter1++){
                        xPointMarkTemp = (int)((arrayTarget [counter1*2]-xPositionAdjustDouble)*(double)xCalculationValue);
                        yPointMarkTemp = (int)(((imageHeightTrack-arrayTarget [counter1*2+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                        [path3 fill];
                    }
                }
                
                if (fluorescentDetectionDisplay == 1 && fluorescentDisplayNo != 0){
                    [[NSColor magentaColor] set];
                    
                    for (int counter1 = 0; counter1 < expandFluorescentOutlineCount/4; counter1 = counter1+displayFrequency){
                        if (expandFluorescentOutline [counter1*4+3] == fluorescentDisplayNo || expandFluorescentOutline [counter1*4+3] == fluorescentDisplayNo+6){
                            xPointMarkTemp = (int)((expandFluorescentOutline [counter1*4]-xPositionAdjustDouble)*(double)xCalculationValue);
                            yPointMarkTemp = (int)(((imageHeightTrack-expandFluorescentOutline [counter1*4+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                            
                            if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                [path3 stroke];
                            }
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
            //	cout<<" arrayLineageData "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //	cout<<" arrayTimeSelected "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
            //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
            //	cout<<" arrayEventSequence "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < lineageGRCurrentCount/4; counterA++){
            //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrent [counterA*4+counterB];
            //	cout<<" arrayLineageGRCurrent "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
            //	cout<<" arrayPositionRevise "<<counterA<<endl;
            //}
            
            //-----Lineage data (Linage number display)-----
            //for (int counterA = 0; counterA < lineageStartEndCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageStartEnd [counterA*8 +counterB];
            //	cout<<" arrayLineageStartEnd "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < lineageGRCurrentCount/4; counterA++){
            //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrent [counterA*4+counterB];
            //	cout<<" arrayLineageGRCurrent "<<counterA<<endl;
            //}
            
            previousValue = 0;
            int displayOnFlag = 0;
            
            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                if (imageNumberTrackForDisplay >= arrayLineageStartEnd [counter1*8+5] && imageNumberTrackForDisplay <= arrayLineageStartEnd [counter1*8+7]){
                    for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                        xPointMarkTemp = (int)((arrayLineageData [counter2*8]-xPositionAdjustDouble)*(double)xCalculationValue);
                        yPointMarkTemp = (int)(((imageHeightTrack-arrayLineageData [counter2*8+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                        displayOnFlag = 0;
                        
                        if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                            //-----Event type 1: I, 2: P, DStart:31, DEnd: 32, 33, 34, TStart:41, TEnd: 42, 43, 44, HStart: 51, HEnd: 52, 53, 54, 55, M: 6, CD: 7, OF: 8, FUEnd: 91, FUCont: 92-----
                            //-----FMark: 10, MD: 11, EF: 12, NE: 13 (in the event that cell enter image, create Dummy entry mark in Time One)-----
                            
                            if (arrayLineageData [counter2*8+2] == imageNumberTrackForDisplay && arrayLineageData [counter2*8+3] != 13){
                                eventString = "";
                                
                                if (arrayLineageData [counter2*8+6] == lineageExtractInt && arrayLineageData [counter2*8+5] == cellNoExtractInt); //-----Select by Lineage number-----
                                else if (arrayLineageData [counter2*8+6] == lineageExtractInt && arrayLineageData [counter2*8+5] != cellNoExtractInt){
                                    
                                    displayOnFlag = 1;
                                    previousValue = 0;
                                    
                                    if (arrayLineageData [counter2*8+3] == 1){
                                        [[NSColor whiteColor] set], [attributesA setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                                        eventString = "I";
                                    } //-----I-----
                                    else if (arrayLineageData [counter2*8+3] == 2){
                                        [[NSColor whiteColor] set], [attributesA setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                                    } //-----P-----
                                    else if (arrayLineageData [counter2*8+3] == 31 || arrayLineageData [counter2*8+3] == 32 || arrayLineageData [counter2*8+3] == 33){
                                        [[NSColor redColor] set], [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                                        eventString = "B";
                                    } //-----BD-----
                                    else if (arrayLineageData [counter2*8+3] == 41 || arrayLineageData [counter2*8+3] == 42 || arrayLineageData [counter2*8+3] == 43 || arrayLineageData [counter2*8+3] == 44){
                                        [[NSColor redColor] set], [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                                        eventString = "T";
                                    } //-----TD-----
                                    else if (arrayLineageData [counter2*8+3] == 51 || arrayLineageData [counter2*8+3] == 52 || arrayLineageData [counter2*8+3] == 53 || arrayLineageData [counter2*8+3] == 54 || arrayLineageData [counter2*8+3] == 55){
                                        [[NSColor redColor] set], [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                                        eventString = "H";
                                    } //-----HD-----
                                    else if (arrayLineageData [counter2*8+3] == 6){
                                        [[NSColor cyanColor] set], [attributesA setObject:[NSColor cyanColor] forKey: NSForegroundColorAttributeName];
                                        eventString = "M";
                                    } //-----M-----
                                    else if (arrayLineageData [counter2*8+3] == 7){
                                        [[NSColor blueColor] set], [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                                        eventString = "C";
                                    } //-----CD-----
                                    else if (arrayLineageData [counter2*8+3] == 8){
                                        [[NSColor blackColor] set], [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                                        eventString = "O";
                                    } //-----OF-----
                                    else if (arrayLineageData [counter2*8+3] == 91){
                                        int fuseLink = arrayLineageData [counter2*8+7];
                                        
                                        [[NSColor purpleColor] set], [attributesA setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                                        eventString = "-"+to_string(fuseLink)+"F";
                                    } //-----FU-----
                                    else if (arrayLineageData [counter2*8+3] == 92) displayOnFlag = 0;
                                    else if (arrayLineageData [counter2*8+3] == 10){
                                        [[NSColor orangeColor] set], [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                                        eventString = "W";
                                    } //-----FM-----
                                    else if (arrayLineageData [counter2*8+3] == 11){
                                        [[NSColor redColor] set], [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                                        eventString = "P";
                                    } //-----MD-----
                                }
                                else if (arrayLineageData [counter2*8+6] != lineageExtractInt){ //-----Select by Lineage number, Non-Target-----
                                    displayOnFlag = 1;
                                    
                                    if (arrayLineageData [counter2*8+3] == 10 && fusionMarkImage == 10000){
                                        [[NSColor blackColor] set], [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                                        eventString = "W";
                                        previousValue = 0;
                                    } //-----FM-----
                                    else if (arrayLineageData [counter2*8+3] == 10 && fusionMarkImage != 10000 && arrayLineageData [counter2*8+2] == fusionMarkImage && arrayLineageData [counter2*8+5] == fusionPartnerLin && arrayLineageData [counter2*8+6] == fusionPartnerCellNo){
                                        [[NSColor orangeColor] set], [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                                        previousValue = 0;
                                    } //-----FM-MK-Hide-----
                                    else if (arrayLineageData [counter2*8+3] == 91){
                                        int fuseLink = arrayLineageData [counter2*8+7];
                                        
                                        [[NSColor orangeColor] set], [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                                        eventString = "-"+to_string(fuseLink)+"F";
                                        previousValue = 0;
                                    } //-----FU-----
                                    else if (arrayLineageData [counter2*8+3] == 92) displayOnFlag = 0;
                                    else if (previousValue == 0){
                                        [[NSColor orangeColor] set], [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                                        previousValue = 1;
                                    }
                                }
                                
                                if (displayOnFlag == 1){
                                    positionAA.x = xPointMarkTemp-magnificationLine;
                                    positionAA.y = yPointMarkTemp;
                                    positionBB.x = xPointMarkTemp+magnificationLine;
                                    positionBB.y = yPointMarkTemp;
                                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                    
                                    positionCC.x = xPointMarkTemp;
                                    positionCC.y = yPointMarkTemp-magnificationLine;
                                    positionDD.x = xPointMarkTemp;
                                    positionDD.y = yPointMarkTemp+magnificationLine;
                                    [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                                    
                                    if (characterDisplayFlag == 1 || characterDisplayFlag == 0){
                                        extension2 = to_string(arrayLineageData [counter2*8+6]);
                                        
                                        if (extension2.length() == 1) extension2 = "L0000"+extension2+eventString;
                                        else if (extension2.length() == 2) extension2 = "L000"+extension2+eventString;
                                        else if (extension2.length() == 3) extension2 = "L00"+extension2+eventString;
                                        else if (extension2.length() == 4) extension2 = "L0"+extension2+eventString;
                                        else if (extension2.length() == 5) extension2 = "L"+extension2+eventString;
                                        
                                        vectorNumberDisplay = @(extension2.c_str());
                                        
                                        attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                                        pointA.x = xPointMarkTemp+magnificationLine*0.3;
                                        pointA.y = yPointMarkTemp+magnificationLine*0.3;
                                        [attrStrA drawAtPoint:pointA];
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            //NSLog (@"%@", vectorNumberDisplay);
            
            //-----Target Cell Number Display-----
            string eventTypeDisplay = "";
            string eventTypeDisplay1 = "";
            string eventTypeDisplay2 = "";
            string eventTypeDisplay3 = "";
            string eventTypeDisplay4 = "";
            int cellNoDisplay1 = -1;
            int cellNoDisplay2 = -1;
            int cellNoDisplay3 = -1;
            int cellNoDisplay4 = -1;
            [[NSColor redColor] set];
            
            if (cellNoHold != ""){
                [attributesA setObject:[NSFont systemFontOfSize:magnificationFont] forKey:NSFontAttributeName];
                
                //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
                //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
                //	cout<<" arrayEventSequence "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < lineageGRCurrentCount/4; counterA++){
                //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrent [counterA*4+counterB];
                //	cout<<" arrayLineageGRCurrent "<<counterA<<endl;
                //}
                
                if (trackingOn == 3){
                    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                            if (arrayEventSequence [counter1*4+1] == 1){
                                eventTypeDisplay = cellNoHold+"_IN";
                                [attributesA setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                            } //-----I-----
                            else if (arrayEventSequence [counter1*4+1] == 2){
                                eventTypeDisplay = cellNoHold;
                                [attributesA setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                            } //-----P-----
                            else if (arrayEventSequence [counter1*4+1] == 31){
                                eventTypeDisplay = cellNoHold+"_BD";
                                [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                            } //-----BD-----
                            else if (arrayEventSequence [counter1*4+1] == 32  && cellNoHoldDiv1 != ""){
                                eventTypeDisplay1 = cellNoHoldDiv1+"_BD1";
                                cellNoDisplay1 = arrayEventSequence [counter1*4+3];
                                [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                            } //-----BD-----
                            else if (arrayEventSequence [counter1*4+1] == 33){
                                eventTypeDisplay2 = cellNoHoldDiv2+"_BD2";
                                cellNoDisplay2 = arrayEventSequence [counter1*4+3];
                                [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                            } //-----BD-----
                            else if (arrayEventSequence [counter1*4+1] == 32 && cellNoHoldDiv1 == ""){
                                eventTypeDisplay = cellNoHold+"_BDE";
                                [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                            } //-----BD-----
                            else if (arrayEventSequence [counter1*4+1] == 41){
                                eventTypeDisplay = cellNoHold+"_TD";
                                [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                            } //-----TD-----
                            else if (arrayEventSequence [counter1*4+1] == 42  && cellNoHoldDiv1 != ""){
                                eventTypeDisplay1 = cellNoHoldDiv1+"_TD1";
                                cellNoDisplay1 = arrayEventSequence [counter1*4+3];
                                [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                            } //-----TD-----
                            else if (arrayEventSequence [counter1*4+1] == 43){
                                eventTypeDisplay2 = cellNoHoldDiv1+"_TD2";
                                cellNoDisplay2 = arrayEventSequence [counter1*4+3];
                                [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                            } //-----TD-----
                            else if (arrayEventSequence [counter1*4+1] == 44){
                                eventTypeDisplay3 = cellNoHoldDiv3+"_TD3";
                                cellNoDisplay3 = arrayEventSequence [counter1*4+3];
                                [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                            } //-----TD-----
                            else if (arrayEventSequence [counter1*4+1] == 42 && cellNoHoldDiv1 == ""){
                                eventTypeDisplay = cellNoHold+"_TDE";
                                [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                            } //-----TD-----
                            else if (arrayEventSequence [counter1*4+1] == 51){
                                eventTypeDisplay = cellNoHold+"_HD";
                                [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                            } //-----HD-----
                            else if (arrayEventSequence [counter1*4+1] == 52 && cellNoHoldDiv1 != ""){
                                eventTypeDisplay1 = cellNoHoldDiv1+"_HD1";
                                cellNoDisplay1 = arrayEventSequence [counter1*4+3];
                                [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                            } //-----HD-----
                            else if (arrayEventSequence [counter1*4+1] == 53){
                                eventTypeDisplay2 = cellNoHoldDiv2+"_HD2";
                                cellNoDisplay2 = arrayEventSequence [counter1*4+3];
                                [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                            } //-----HD-----
                            else if (arrayEventSequence [counter1*4+1] == 54){
                                eventTypeDisplay3 = cellNoHoldDiv3+"_HD3";
                                cellNoDisplay3 = arrayEventSequence [counter1*4+3];
                                [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                            } //-----HD-----
                            else if (arrayEventSequence [counter1*4+1] == 55){
                                eventTypeDisplay4 = cellNoHoldDiv4+"_HD4";
                                cellNoDisplay4 = arrayEventSequence [counter1*4+3];
                                [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                            } //-----HD-----
                            else if (arrayEventSequence [counter1*4+1] == 52 && cellNoHoldDiv1 == ""){
                                eventTypeDisplay = cellNoHold+"_HDE";
                                [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                            } //-----HD-----
                            else if (arrayEventSequence [counter1*4+1] == 6){
                                eventTypeDisplay = cellNoHold+"_MI";
                                [attributesA setObject:[NSColor cyanColor] forKey: NSForegroundColorAttributeName];
                            } //-----M-----
                            else if (arrayEventSequence [counter1*4+1] == 7){
                                eventTypeDisplay = cellNoHold+"_CD";
                                [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                            } //-----CD-----
                            else if (arrayEventSequence [counter1*4+1] == 8){
                                eventTypeDisplay = cellNoHold+"_OF";
                                [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                            } //-----OF-----
                            else if (arrayEventSequence [counter1*4+1] == 91){
                                eventTypeDisplay = cellNoHold+"_FU";
                                [attributesA setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                            } //-----FU-----
                            else if (arrayEventSequence [counter1*4+1] == 92){
                                eventTypeDisplay = "FU92";
                            } //-----FU-----
                            else if (arrayEventSequence [counter1*4+1] == 10){
                                eventTypeDisplay = cellNoHold+"_FM";
                                [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                            } //-----FM-----
                            else if (arrayEventSequence [counter1*4+1] == 11){
                                eventTypeDisplay = cellNoHold+"_ID";
                                [attributesA setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
                            } //-----MD-----
                        }
                    }
                    
                    if (eventTypeDisplay == "" && eventTypeDisplay1 == "" && eventTypeDisplay2 == "" && eventTypeDisplay3 == "" && eventTypeDisplay4 == ""){
                        eventTypeDisplay = cellNoHold;
                        [attributesA setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                    }
                    
                    if (eventTypeDisplay == "FU92") eventTypeDisplay = "";
                }
                
                if (trackingOn == 1){
                    for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                        if (imageNumberTrackForDisplay >= arrayLineageStartEnd [counter1*8+5] && imageNumberTrackForDisplay <= arrayLineageStartEnd [counter1*8+7]){
                            for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                                if (arrayLineageData [counter2*8+2] == imageNumberTrackForDisplay && arrayLineageData [counter2*8+5] == cellNoExtractInt && arrayLineageData [counter2*8+6] == lineageExtractInt){
                                    if (arrayLineageData [counter2*8+3] == 1){
                                        eventTypeDisplay = cellNoHold+"_IN";
                                        [attributesA setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                                    } //-----I-----
                                    else if (arrayLineageData [counter2*8+3] == 2){
                                        eventTypeDisplay = cellNoHold;
                                        [attributesA setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                                    } //-----P-----
                                    else if (arrayLineageData [counter2*8+3] == 31){
                                        eventTypeDisplay = cellNoHold+"_BDS";
                                        [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                                    } //-----BD-----
                                    else if (arrayLineageData [counter2*8+3] == 32){
                                        eventTypeDisplay = cellNoHold+"_BDE";
                                        [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                                    } //-----BD-----
                                    else if (arrayLineageData [counter2*8+3] == 41){
                                        eventTypeDisplay = cellNoHold+"_TDS";
                                        [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                                    } //-----TD-----
                                    else if (arrayLineageData [counter2*8+3] == 42){
                                        eventTypeDisplay = cellNoHold+"_TDE";
                                        [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                                    } //-----TD-----
                                    else if (arrayLineageData [counter2*8+3] == 51){
                                        eventTypeDisplay = cellNoHold+"_HDS";
                                        [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                                    } //-----HD-----
                                    else if (arrayLineageData [counter2*8+3] == 52){
                                        eventTypeDisplay = cellNoHold+"_HDE";
                                        [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                                    } //-----HD-----
                                    else if (arrayLineageData [counter2*8+3] == 6){
                                        eventTypeDisplay = cellNoHold+"_MI";
                                        [attributesA setObject:[NSColor cyanColor] forKey: NSForegroundColorAttributeName];
                                    } //-----M-----
                                    else if (arrayLineageData [counter2*8+3] == 7){
                                        eventTypeDisplay = cellNoHold+"_CD";
                                        [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                                    } //-----CD-----
                                    else if (arrayLineageData [counter2*8+3] == 8){
                                        eventTypeDisplay = cellNoHold+"_OF";
                                        [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                                    } //-----OF-----
                                    else if (arrayLineageData [counter2*8+3] == 91){
                                        eventTypeDisplay = cellNoHold+"_FU";
                                        [attributesA setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                                    } //-----FU-----
                                    else if (arrayLineageData [counter2*8+3] == 10){
                                        eventTypeDisplay = cellNoHold+"_FM";
                                        [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                                    } //-----FM-----
                                    else if (arrayLineageData [counter2*8+3] == 11){
                                        eventTypeDisplay = cellNoHold+"_ID";
                                        [attributesA setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
                                    } //-----MD-----
                                }
                            }
                        }
                    }
                }
            }
            else{
                
                eventTypeDisplay = cellNoHold;
                [attributesA setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
            }
            
            //for (int counterA = 0; counterA < xyPositionListCount/5; counterA++){
            //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayXYPositionList [counterA*5+counterB];
            //	cout<<" arrayXYPositionList "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < lineageGRCurrentCount/4; counterA++){
            //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrent [counterA*4+counterB];
            //	cout<<" arrayLineageGRCurrent "<<counterA<<endl;
            //}
            
            int findFlag = 0;
            
            if (trackingOn == 1 || (trackingOn == 3 && trackingPermit == 0) || (trackingOn == 3 && trackingPermit == 1 && imageNumberTrackForDisplay > firstModificationPoint)){
                string cellNoString;
                
                for (int counter1 = 0; counter1 < xyPositionListCount/5; counter1++){
                    xPointMarkTemp = (int)((arrayXYPositionList [counter1*5+2]-xPositionAdjustDouble)*(double)xCalculationValue);
                    yPointMarkTemp = (int)(((imageHeightTrack-arrayXYPositionList [counter1*5+3])-yPositionAdjustDouble)*(double)yCalculationValue);
                    
                    if (arrayXYPositionList [counter1*5] == imageNumberTrackForDisplay && arrayXYPositionList [counter1*5+4] == 1 && eventTypeDisplay1 == ""){
                        findFlag = 1;
                        
                        positionAA.x = xPointMarkTemp-magnificationLine;
                        positionAA.y = yPointMarkTemp;
                        positionBB.x = xPointMarkTemp+magnificationLine;
                        positionBB.y = yPointMarkTemp;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        positionCC.x = xPointMarkTemp;
                        positionCC.y = yPointMarkTemp-magnificationLine;
                        positionDD.x = xPointMarkTemp;
                        positionDD.y = yPointMarkTemp+magnificationLine;
                        [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                        
                        if ((cellLineageNoHold != "" && cellNoHold == "") || (cellLineageNoHold == "" && cellNoHold == "")) vectorNumberDisplay = @"";
                        else if (cellLineageNoHold != "" && cellNoHold != ""){
                            cellNoString = "";
                            
                            for (int counter2 = 0; counter2 < (int)eventTypeDisplay.length(); counter2++){
                                if (eventTypeDisplay.substr((unsigned long)counter2, 1) != "0") cellNoString = cellNoString+eventTypeDisplay.substr((unsigned long)counter2, 1);
                            }
                            
                            if ((int)cellNoString.find("C_") != -1){
                                cellNoString = cellNoString.substr(1);
                                cellNoString = "C0"+cellNoString;
                            }
                            
                            if (cellNoString == "C") cellNoString = "C0";
                            
                            if (lineagePartnerInfoCount != 0){
                                if (cellNoString.find("FM") != 1){
                                    for (int counter2 = 0; counter2 < lineagePartnerInfoCount/6; counter2++){
                                        if (atoi(arrayLineagePartnerInfo [counter2*6+3].c_str()) == imageNumberTrackForDisplay && atoi(arrayLineagePartnerInfo [counter2*6+1].c_str()) == lineageExtractInt && atoi(arrayLineagePartnerInfo [counter2*6+2].c_str()) == cellNoExtractInt){
                                            cellNoString = cellNoString+": L"+arrayLineagePartnerInfo [counter2*6+4]+": C"+arrayLineagePartnerInfo [counter2*6+5];
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            vectorNumberDisplay = @(cellNoString.c_str());
                        }
                        
                        //NSLog (@"%@", vectorNumberDisplay);
                        
                        attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                        pointA.x = xPointMarkTemp+magnificationLine*0.3;
                        pointA.y = yPointMarkTemp+magnificationLine*0.3;
                        [attrStrA drawAtPoint:pointA];
                        
                        break;
                    }
                }
            }
            
            if (findFlag == 0){
                //-----Target Cell Number Display-----
                string cellNoString;
                
                for (int counter1 = 0; counter1 < lineageGRCurrentCount/4; counter1++){
                    if (arrayLineageGRCurrent [counter1*4] == imageNumberTrackForDisplay){
                        xPointMarkTemp = (int)((arrayLineageGRCurrent [counter1*4+1]-xPositionAdjustDouble)*(double)xCalculationValue);
                        yPointMarkTemp = (int)(((imageHeightTrack-arrayLineageGRCurrent [counter1*4+2])-yPositionAdjustDouble)*(double)yCalculationValue);
                        vectorNumberDisplay = @"";
                        
                        if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                            if (cellLineageNoHold != "" && cellNoHold == "") vectorNumberDisplay = @"C0";
                            else if (cellLineageNoHold != "" && cellNoHold != "" && arrayLineageGRCurrent [counter1*4+3] == cellNoDisplay4){
                                cellNoString = "";
                                
                                for (int counter2 = 0; counter2 < (int)eventTypeDisplay4.length(); counter2++){
                                    if (eventTypeDisplay4.substr((unsigned long)counter2, 1) != "0") cellNoString = cellNoString+eventTypeDisplay4.substr((unsigned long)counter2, 1);
                                }
                                
                                vectorNumberDisplay = @(cellNoString.c_str());
                            }
                            else if (cellLineageNoHold != "" && cellNoHold != "" && arrayLineageGRCurrent [counter1*4+3] == cellNoDisplay3){
                                cellNoString = "";
                                
                                for (int counter2 = 0; counter2 < (int)eventTypeDisplay3.length(); counter2++){
                                    if (eventTypeDisplay3.substr((unsigned long)counter2, 1) != "0") cellNoString = cellNoString+eventTypeDisplay3.substr((unsigned long)counter2, 1);
                                }
                                
                                vectorNumberDisplay = @(cellNoString.c_str());
                            }
                            else if (cellLineageNoHold != "" && cellNoHold != "" && arrayLineageGRCurrent [counter1*4+3] == cellNoDisplay2){
                                cellNoString = "";
                                
                                for (int counter2 = 0; counter2 < (int)eventTypeDisplay2.length(); counter2++){
                                    if (eventTypeDisplay2.substr((unsigned long)counter2, 1) != "0") cellNoString = cellNoString+eventTypeDisplay2.substr((unsigned long)counter2, 1);
                                }
                                
                                vectorNumberDisplay = @(cellNoString.c_str());
                            }
                            else if (cellLineageNoHold != "" && cellNoHold != "" && arrayLineageGRCurrent [counter1*4+3] == cellNoDisplay1){
                                cellNoString = "";
                                
                                for (int counter2 = 0; counter2 < (int)eventTypeDisplay1.length(); counter2++){
                                    if (eventTypeDisplay1.substr((unsigned long)counter2, 1) != "0") cellNoString = cellNoString+eventTypeDisplay1.substr((unsigned long)counter2, 1);
                                }
                                
                                vectorNumberDisplay = @(cellNoString.c_str());
                            }
                            else if (cellLineageNoHold != "" && cellNoHold != ""){
                                cellNoString = "";
                                
                                for (int counter2 = 0; counter2 < (int)eventTypeDisplay.length(); counter2++){
                                    if (eventTypeDisplay.substr((unsigned long)counter2, 1) != "0") cellNoString = cellNoString+eventTypeDisplay.substr((unsigned long)counter2, 1);
                                }
                                
                                if ((int)cellNoString.find("C_") != -1){
                                    cellNoString = cellNoString.substr(1);
                                    cellNoString = "C0"+cellNoString;
                                }
                                
                                if (cellNoString == "C") cellNoString = "C0";
                                
                                if (lineagePartnerInfoCount != 0){
                                    if (cellNoString.find("FM") != 1){
                                        for (int counter2 = 0; counter2 < lineagePartnerInfoCount/6; counter2++){
                                            if (atoi(arrayLineagePartnerInfo [counter2*6+3].c_str()) == imageNumberTrackForDisplay && atoi(arrayLineagePartnerInfo [counter2*6+1].c_str()) == lineageExtractInt && atoi(arrayLineagePartnerInfo [counter2*6+2].c_str()) == cellNoExtractInt){
                                                cellNoString = cellNoString+": L"+arrayLineagePartnerInfo [counter2*6+4]+": C"+arrayLineagePartnerInfo [counter2*6+5];
                                                break;
                                            }
                                        }
                                    }
                                }
                                
                                vectorNumberDisplay = @(cellNoString.c_str());
                            }
                            
                            if ([vectorNumberDisplay length] != 0){
                                positionAA.x = xPointMarkTemp-magnificationLine;
                                positionAA.y = yPointMarkTemp;
                                positionBB.x = xPointMarkTemp+magnificationLine;
                                positionBB.y = yPointMarkTemp;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                
                                positionCC.x = xPointMarkTemp;
                                positionCC.y = yPointMarkTemp-magnificationLine;
                                positionDD.x = xPointMarkTemp;
                                positionDD.y = yPointMarkTemp+magnificationLine;
                                [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                                
                                attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                                pointA.x = xPointMarkTemp+magnificationLine*0.3;
                                pointA.y = yPointMarkTemp+magnificationLine*0.3;
                                [attrStrA drawAtPoint:pointA];
                            }
                        }
                    }
                }
            }
            
            //-----Info writing-----
            [attributesA setObject:[NSFont systemFontOfSize:12] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
            [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
            
            string infoDisplayString = "Time: "+to_string(imageNumberTrackForDisplay);
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
            pointA.x = 10;
            pointA.y = 685;
            [attrStrA drawAtPoint:pointA];
            
            infoDisplayString = "Treatment: "+treatmentNameHold;
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
            pointA.x = 80;
            pointA.y = 685;
            [attrStrA drawAtPoint:pointA];
            
            [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
            infoDisplayString = "Lineage: "+cellLineageNoHold;
            attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
            pointA.x = 230;
            pointA.y = 685;
            [attrStrA drawAtPoint:pointA];
            
            if (trackingOn == 3 && cellDivisionSetCount == 0 && divisionTypeHold == 0 && fusionOperation == 0 && doubleClickStatusHold == 0 && autoRefStatus == 1){
                [attributesA setObject:[NSColor cyanColor] forKey: NSForegroundColorAttributeName];
                infoDisplayString = "Operation: ON_AS";
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 350;
                pointA.y = 685;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (trackingOn == 3 && cellDivisionSetCount == 0 && divisionTypeHold == 0 && fusionOperation == 0 && doubleClickStatusHold == 0 && autoRefStatus == 0){
                [attributesA setObject:[NSColor cyanColor] forKey: NSForegroundColorAttributeName];
                infoDisplayString = "Operation: ON";
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 350;
                pointA.y = 685;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (trackingOn == 3 && cellDivisionSetCount == 0 && divisionTypeHold == 0 && fusionOperation == 0 && doubleClickStatusHold == 2){
                [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                infoDisplayString = "Operation: D_CLICK";
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 350;
                pointA.y = 685;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (trackingOn == 3 && divisionTypeHold == 2){
                if (cellDivisionSetCount == 0 || cellDivisionSetCount == 1){
                    [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                    infoDisplayString = "Operation: BD1";
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 350;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                
                if (cellDivisionSetCount == 2){
                    [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                    infoDisplayString = "Operation: BD2";
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 350;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
            }
            
            if (trackingOn == 3 && divisionTypeHold == 3){
                if (cellDivisionSetCount == 0 || cellDivisionSetCount == 1){
                    [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                    infoDisplayString = "Operation: TD1";
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 350;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                
                if (cellDivisionSetCount == 2){
                    [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                    infoDisplayString = "Operation: TD2";
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 350;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                
                if (cellDivisionSetCount == 3){
                    [attributesA setObject:[NSColor cyanColor] forKey: NSForegroundColorAttributeName];
                    infoDisplayString = "Operation: TD3";
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 350;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
            }
            
            if (trackingOn == 3 && divisionTypeHold == 4){
                if (cellDivisionSetCount == 0 || cellDivisionSetCount == 1){
                    [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                    infoDisplayString = "Operation: HD1";
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 350;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                if (cellDivisionSetCount == 2){
                    [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                    infoDisplayString = "Operation: HD2";
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 350;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                
                if (cellDivisionSetCount == 3){
                    [attributesA setObject:[NSColor cyanColor] forKey: NSForegroundColorAttributeName];
                    infoDisplayString = "Operation: HD3";
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 350;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                
                if (cellDivisionSetCount == 4){
                    [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                    infoDisplayString = "Operation: HD4";
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 350;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
            }
            
            if (trackingOn == 3 && fusionOperation == 1){
                [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                infoDisplayString = "Operation: FU";
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 350;
                pointA.y = 685;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (trackingOn == 3 && trackingPermit == 1 && firstModificationPoint != 10000 && divisionWarning == "" && targetLostMark == ""){
                int eventEntryLast = firstModificationPoint-1;
                int eventEntryLastCount = firstModificationPoint;
                int eventFindFlag = 0;
                
                for (int counter1 = firstModificationPoint; counter1 <= imageNumberTrackForDisplay; counter1++){
                    eventFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < eventSequenceCount/4; counter2++){
                        if (arrayEventSequence [counter2*4] == eventEntryLastCount){
                            eventEntryLast++;
                            eventEntryLastCount++;
                            eventFindFlag = 1;
                            break;
                        }
                    }
                    
                    if (eventFindFlag == 0){
                        break;
                    }
                }
                
                [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                
                infoDisplayString = "LastEntry: "+to_string(eventEntryLast);
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 480;
                pointA.y = 685;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (trackingOn == 3 && trackingPermit == 1 && firstModificationPoint != 10000 && divisionWarning == "" && targetLostMark != ""){
                [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                
                infoDisplayString = "Tracking: "+targetLostMark;
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 480;
                pointA.y = 685;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (trackingOn == 3 && trackingPermit == 1 && firstModificationPoint != 10000 && divisionWarning != "" && divisionWarningType == 1){
                [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                
                infoDisplayString = "Event: "+divisionWarning;
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 480;
                pointA.y = 685;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (trackingOn == 3 && trackingPermit == 1 && firstModificationPoint != 10000 && divisionWarning != "" && divisionWarningType == 2){
                [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                
                infoDisplayString = "Event: "+divisionWarning;
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 480;
                pointA.y = 685;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (trackingOn == 3 && gravityCenterNotRecorded != "nil"){
                [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                
                infoDisplayString = "GC set error: "+gravityCenterNotRecorded;
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 10;
                pointA.y = 10;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (fluorescentDetectionDisplay == 1){
                if (fluorescentDisplayNo == 0 && ifEntry == 0){
                    [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo: Find";
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                else if (fluorescentDisplayNo == 1 && ifEntry == 0){
                    if (fluorescentNo1 == 1) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 2) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 3) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 4) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 5) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 6) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 7) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 8) [attributesA setObject:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 9) [attributesA setObject:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo: "+fluorescentName1;
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                else if (fluorescentDisplayNo == 2 && ifEntry == 0){
                    if (fluorescentNo2 == 1) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 2) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 3) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 4) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 5) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 6) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 7) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 8) [attributesA setObject:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 9) [attributesA setObject:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo: "+fluorescentName2;
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                else if (fluorescentDisplayNo == 3 && ifEntry == 0){
                    if (fluorescentNo3 == 1) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 2) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 3) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 4) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 5) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 6) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 7) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 8) [attributesA setObject:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 9) [attributesA setObject:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo: "+fluorescentName3;
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                else if (fluorescentDisplayNo == 4 && ifEntry == 0){
                    if (fluorescentNo4 == 1) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 2) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 3) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 4) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 5) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 6) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 7) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 8) [attributesA setObject:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 9) [attributesA setObject:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo: "+fluorescentName4;
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                else if (fluorescentDisplayNo == 5 && ifEntry == 0){
                    if (fluorescentNo5 == 1) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 2) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 3) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 4) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 5) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 6) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 7) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 8) [attributesA setObject:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 9) [attributesA setObject:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo: "+fluorescentName5;
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                else if (fluorescentDisplayNo == 6 && ifEntry == 0){
                    if (fluorescentNo6 == 1) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 2) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 3) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 4) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 5) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 6) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 7) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 8) [attributesA setObject:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 9) [attributesA setObject:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo: "+fluorescentName6;
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                else if (fluorescentDisplayNo == 0 && ifEntry == 1){
                    [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo-IF: Find";
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                else if (fluorescentDisplayNo == 1 && ifEntry == 1){
                    if (fluorescentNo1 == 1) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 2) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 3) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 4) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 5) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 6) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 7) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 8) [attributesA setObject:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 9) [attributesA setObject:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo-IF: "+fluorescentName1;
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                else if (fluorescentDisplayNo == 2 && ifEntry == 1){
                    if (fluorescentNo2 == 1) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 2) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 3) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 4) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 5) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 6) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 7) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 8) [attributesA setObject:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 9) [attributesA setObject:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo-IF: "+fluorescentName2;
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                else if (fluorescentDisplayNo == 3 && ifEntry == 1){
                    if (fluorescentNo3 == 1) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 2) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 3) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 4) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 5) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 6) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 7) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 8) [attributesA setObject:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 9) [attributesA setObject:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo-IF: "+fluorescentName3;
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                else if (fluorescentDisplayNo == 4 && ifEntry == 1){
                    if (fluorescentNo4 == 1) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 2) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 3) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 4) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 5) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 6) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 7) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 8) [attributesA setObject:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 9) [attributesA setObject:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo-IF: "+fluorescentName4;
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                else if (fluorescentDisplayNo == 5 && ifEntry == 1){
                    if (fluorescentNo5 == 1) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 2) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 3) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 4) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 5) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 6) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 7) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 8) [attributesA setObject:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 9) [attributesA setObject:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo-IF: "+fluorescentName5;
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                else if (fluorescentDisplayNo == 6 && ifEntry == 1){
                    if (fluorescentNo6 == 1) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 2) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 3) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 4) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 5) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 6) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 7) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 8) [attributesA setObject:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 9) [attributesA setObject:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo-IF: "+fluorescentName6;
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                
                if (fluorescentDivisionStatus == 1 && fluorescentDivisionTime == imageNumberTrackForDisplay && ((fluorescentDivisionTime <= timeEndHold && fluorescentDivisionCh == fluorescentDisplayNo) || (fluorescentDivisionTime > timeEndHold && fluorescentDivisionCh-6 == fluorescentDisplayNo)) && trackingOn == 1){
                    [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                    
                    if (fluorescentLevelValueHold != 10){
                        if (fluorescentDivisionNo == 1) infoDisplayString = "Fluorescent Level Set: CH; "+to_string(fluorescentDivisionCh)+" Key4; 0, key5; 100 Value; "+to_string(fluorescentLevelValueHold);
                        else if (fluorescentDivisionNo == 2) infoDisplayString = "Fluorescent Level Set: CH; "+to_string(fluorescentDivisionCh)+" Key4; 0, key5; 50, key6; 100 Value; "+to_string(fluorescentLevelValueHold);
                        else if (fluorescentDivisionNo == 3) infoDisplayString = "Fluorescent Level Set: CH; "+to_string(fluorescentDivisionCh)+" Key4; 0, key5; 33, key6; 66, key7; 100 Value; "+to_string(fluorescentLevelValueHold);
                        else if (fluorescentDivisionNo == 4) infoDisplayString = "Fluorescent Level Set: CH; "+to_string(fluorescentDivisionCh)+" Key4; 0, key5; 25, key6; 50, key7; 75, key8; 100 Value; "+to_string(fluorescentLevelValueHold);
                    }
                    else{
                        
                        if (fluorescentDivisionNo == 1) infoDisplayString = "Fluorescent Level Set: CH; "+to_string(fluorescentDivisionCh)+" Key4; 0, key5; 100 Value; none";
                        else if (fluorescentDivisionNo == 2) infoDisplayString = "Fluorescent Level Set: CH; "+to_string(fluorescentDivisionCh)+" Key4; 0, key5; 50, key6; 100 Value; none";
                        else if (fluorescentDivisionNo == 3) infoDisplayString = "Fluorescent Level Set: CH; "+to_string(fluorescentDivisionCh)+" Key4; 0, key5; 33, key6; 66, key7; 100 Value; none";
                        else if (fluorescentDivisionNo == 4) infoDisplayString = "Fluorescent Level Set: CH; "+to_string(fluorescentDivisionCh)+" Key4; 0, key5; 25, key6; 50, key7; 75, key8; 100 Value; none";
                    }
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 10;
                    pointA.y = 5;
                    [attrStrA drawAtPoint:pointA];
                }
            }
            
            if (listOnOffFlag == 1 && (trackingOn == 1 || trackingOn == 3)){
                [attributesA setObject:[NSColor cyanColor] forKey: NSForegroundColorAttributeName];
                
                if (tableListSwitch == 1){
                    listHoldCount = 0;
                    
                    int entryCount = 0;
                    string statusNoList;
                    
                    for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                        statusNoList = arrayDoneList [counter1*5+4];
                        
                        if ((int)statusNoList.find("OK") == -1){
                            arrayListHold [listHoldCount] = arrayDoneList [counter1*5], listHoldCount++;
                            arrayListHold [listHoldCount] = arrayDoneList [counter1*5+1], listHoldCount++;
                            arrayListHold [listHoldCount] = arrayDoneList [counter1*5+2], listHoldCount++;
                            arrayListHold [listHoldCount] = arrayDoneList [counter1*5+3], listHoldCount++;
                            arrayListHold [listHoldCount] = arrayDoneList [counter1*5+4], listHoldCount++;
                            
                            entryCount++;
                        }
                        
                        if (entryCount == 10){
                            break;
                        }
                    }
                    
                    if (listHoldCount != 0){
                        int firstLinePosition = 645;
                        
                        for (int counter1 = 0; counter1 < 10; counter1++){
                            infoDisplayString = "C: "+arrayListHold [counter1*5+3]+": "+arrayListHold [counter1*5]+": "+arrayListHold [counter1*5+1]+": "+arrayListHold [counter1*5+2]+": "+arrayListHold [counter1*5+4];
                            attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                            pointA.x = 10;
                            pointA.y = firstLinePosition;
                            [attrStrA drawAtPoint:pointA];
                            
                            firstLinePosition = firstLinePosition-20;
                            
                            if ((counter1+1)*5 == listHoldCount){
                                break;
                            }
                        }
                    }
                    else{
                        
                        infoDisplayString = "C: No Remaining Data to be Checked";
                        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                        pointA.x = 10;
                        pointA.y = 645;
                        [attrStrA drawAtPoint:pointA];
                    }
                }
                
                if (tableListSwitch == 2){
                    listHoldCount = 0;
                    
                    int entryCount = 0;
                    string imageNoList;
                    string imageNoLimitList;
                    
                    for (int counter1 = 0; counter1 < queueListCount/5; counter1++){
                        imageNoList = arrayQueueList [counter1*6+3];
                        
                        if ((int)imageNoList.find(":") != -1) imageNoList = imageNoList.substr(0, imageNoList.find(":"));
                        
                        imageNoLimitList = arrayQueueList [counter1*6+3];
                        
                        if ((int)imageNoLimitList.find(":") != -1) imageNoLimitList = imageNoLimitList.substr(imageNoLimitList.find(":")+1);
                        
                        if (imageNoList != imageNoLimitList){
                            arrayListHold [listHoldCount] = arrayQueueList [counter1*6], listHoldCount++;
                            arrayListHold [listHoldCount] = arrayQueueList [counter1*6+1], listHoldCount++;
                            arrayListHold [listHoldCount] = arrayQueueList [counter1*6+2], listHoldCount++;
                            arrayListHold [listHoldCount] = arrayQueueList [counter1*6+3], listHoldCount++;
                            arrayListHold [listHoldCount] = "Queue", listHoldCount++;
                            
                            entryCount++;
                        }
                        
                        if (entryCount == 10){
                            break;
                        }
                    }
                    
                    if (listHoldCount != 0){
                        int firstLinePosition = 645;
                        
                        for (int counter1 = 0; counter1 < 10; counter1++){
                            infoDisplayString = "Q: "+arrayListHold [counter1*5+3]+": "+arrayListHold [counter1*5]+": "+arrayListHold [counter1*5+1]+": "+arrayListHold [counter1*5+2];
                            attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                            pointA.x = 10;
                            pointA.y = firstLinePosition;
                            [attrStrA drawAtPoint:pointA];
                            
                            firstLinePosition = firstLinePosition-20;
                            
                            if ((counter1+1)*5 == listHoldCount){
                                break;
                            }
                        }
                    }
                    else{
                        
                        infoDisplayString = "Q: No Remaining Data to be Checked";
                        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                        pointA.x = 10;
                        pointA.y = 645;
                        [attrStrA drawAtPoint:pointA];
                    }
                }
            }
        }
        
        //-----Time One mode-----
        if (timeOneStatus == 2){
            NSBezierPath *path3;
            [NSBezierPath setDefaultLineWidth:sizeCalculation];
            
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //	cout<<" arrayTimeSelected "<<counterA<<endl;
            //}
            
            int startPoint = 0;
            int removeMark = 0;
            int connectTemp = 0;
            int xPointMarkTemp = 0;
            int yPointMarkTemp = 0;
            
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                if (arrayTimeSelected [counter1*10] == 0 || arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7 || arrayTimeSelected [counter1*10] == 2 || arrayTimeSelected [counter1*10] == 5 || arrayTimeSelected [counter1*10] == 6){
                    startPoint = arrayTimeSelected [counter1*10+2];
                    removeMark = arrayTimeSelected [counter1*10];
                    
                    connectTemp = 0;
                    
                    for (int counter2 = startPoint; counter2 < positionReviseCount/7; counter2 = counter2+displayFrequency){
                        if (connectTemp == 0){
                            connectTemp = arrayPositionRevise [counter2*7+3];
                            
                            if (removeMark == 0 || removeMark == 5 || removeMark == 6){
                                xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                    [[NSColor yellowColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                    [path3 fill];
                                }
                            }
                            else if (removeMark == 2){
                                xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                    [[NSColor grayColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                    [path3 fill];
                                }
                            }
                            else if (removeMark == 1 || removeMark == 7){
                                xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                    [[NSColor greenColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                    [path3 fill];
                                }
                            }
                        }
                        else if (connectTemp == arrayPositionRevise [counter2*7+3]){
                            if (removeMark == 0 || removeMark == 5 || removeMark == 6){
                                xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                    [[NSColor yellowColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                    [path3 fill];
                                }
                            }
                            else if (removeMark == 2){
                                xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                    [[NSColor grayColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                    [path3 fill];
                                }
                            }
                            else if (removeMark == 1 || removeMark == 7){
                                xPointMarkTemp = (int)((arrayPositionRevise [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                                yPointMarkTemp = (int)(((imageHeightTrack-arrayPositionRevise [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                                
                                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                                    [[NSColor greenColor] set];
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                    [path3 fill];
                                }
                            }
                        }
                        else if (connectTemp != arrayPositionRevise [counter2*7+3]){
                            break;
                        }
                    }
                }
            }
            
            if (fluorescentDetectionDisplay == 1 && fluorescentDisplayNo != 0){
                [[NSColor magentaColor] set];
                
                for (int counter1 = 0; counter1 < expandFluorescentOutlineCount/4; counter1 = counter1+displayFrequency){
                    if (expandFluorescentOutline [counter1*4+3] == fluorescentDisplayNo || expandFluorescentOutline [counter1*4+3] == fluorescentDisplayNo+6){
                        xPointMarkTemp = (int)((expandFluorescentOutline [counter1*4]-xPositionAdjustDouble)*(double)xCalculationValue);
                        yPointMarkTemp = (int)(((imageHeightTrack-expandFluorescentOutline [counter1*4+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                        
                        if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                            [path3 stroke];
                        }
                    }
                }
            }
            
            //-----Cut line display-----
            for (int counter1 = 0; counter1 < targetHoldCount/3; counter1 = counter1+displayFrequency){
                xPointMarkTemp = (int)((arrayTargetHold [counter1*3]-xPositionAdjustDouble)*(double)xCalculationValue);
                yPointMarkTemp = (int)(((imageHeightTrack-arrayTargetHold [counter1*3+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                
                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                    if (arrayTargetHoldInfo [(arrayTargetHold [counter1*3+2]-1)*4+2] == 0){
                        [[NSColor redColor] set];
                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                        [path3 fill];
                    }
                }
            }
            
            //-----GR Center Display-----
            NSPoint positionAA;
            NSPoint positionBB;
            NSPoint positionCC;
            NSPoint positionDD;
            
            positionAA.x = 0;
            positionAA.y = 350;
            positionBB.x = 700;
            positionBB.y = 350;
            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            
            positionCC.x = 350;
            positionCC.y = 0;
            positionDD.x = 350;
            positionDD.y = 700;
            [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
            
            NSPoint pointA;
            NSAttributedString *attrStrA;
            NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
            
            [attributesA setObject:[NSFont systemFontOfSize:magnificationFont] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
            [attributesA removeObjectForKey:NSBackgroundColorAttributeName];
            NSString *vectorNumberDisplay;
            
            int *arrayTimeSelectedTemp = new int [gravityCenterRevCount/6*2+50];
            int timeSelectedTempCount = 0;
            
            int selected = 0;
            
            for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                selected = arrayTimeSelected [counter1*10];
                xPointMarkTemp = (int)((arrayGravityCenterRev [counter1*6]-xPositionAdjustDouble)*(double)xCalculationValue);
                yPointMarkTemp = (int)(((imageHeightTrack-arrayGravityCenterRev [counter1*6+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                
                if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                    if (areaSelectStatus == 2 || areaSelectStatus == 3){
                        if (xPointDragTrack-xPointDownTrack > 0 && yPointDragTrack-yPointDownTrack > 0 && xPointMarkTemp > xPointDownTrack && xPointMarkTemp < xPointDragTrack && yPointMarkTemp > yPointDownTrack && yPointMarkTemp < yPointDragTrack){
                            [[NSColor redColor] set];
                            [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                            arrayTimeSelectedTemp [timeSelectedTempCount] = 1;
                            timeSelectedTempCount++;
                            arrayTimeSelectedTemp [timeSelectedTempCount] = counter1;
                            timeSelectedTempCount++;
                            areaSelectStatus = 3;
                        }
                        else if (xPointDragTrack-xPointDownTrack < 0 && yPointDragTrack-yPointDownTrack > 0 && xPointMarkTemp < xPointDownTrack && xPointMarkTemp > xPointDragTrack && yPointMarkTemp > yPointDownTrack && yPointMarkTemp < yPointDragTrack){
                            
                            [[NSColor redColor] set];
                            [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                            arrayTimeSelectedTemp [timeSelectedTempCount] = 1;
                            timeSelectedTempCount++;
                            arrayTimeSelectedTemp [timeSelectedTempCount] = counter1;
                            timeSelectedTempCount++;
                            areaSelectStatus = 3;
                        }
                        else if (xPointDragTrack-xPointDownTrack > 0 && yPointDragTrack-yPointDownTrack < 0 && xPointMarkTemp > xPointDownTrack && xPointMarkTemp < xPointDragTrack && yPointMarkTemp < yPointDownTrack && yPointMarkTemp > yPointDragTrack){
                            
                            [[NSColor redColor] set];
                            [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                            arrayTimeSelectedTemp [timeSelectedTempCount] = 1;
                            timeSelectedTempCount++;
                            arrayTimeSelectedTemp [timeSelectedTempCount] = counter1;
                            timeSelectedTempCount++;
                            areaSelectStatus = 3;
                        }
                        else if (xPointDragTrack-xPointDownTrack < 0 && yPointDragTrack-yPointDownTrack < 0 && xPointMarkTemp < xPointDownTrack && xPointMarkTemp > xPointDragTrack && yPointMarkTemp < yPointDownTrack && yPointMarkTemp > yPointDragTrack){
                            
                            [[NSColor redColor] set];
                            [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                            arrayTimeSelectedTemp [timeSelectedTempCount] = 1;
                            timeSelectedTempCount++;
                            arrayTimeSelectedTemp [timeSelectedTempCount] = counter1;
                            timeSelectedTempCount++;
                            areaSelectStatus = 3;
                        }
                        else{
                            
                            [[NSColor orangeColor] set];
                            [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                            arrayTimeSelectedTemp [timeSelectedTempCount] = 0;
                            timeSelectedTempCount++;
                            arrayTimeSelectedTemp [timeSelectedTempCount] = counter1;
                            timeSelectedTempCount++;
                        }
                        
                        if (selected == 3 || selected == 4){
                            [[NSColor clearColor] set];
                            [attributesA setObject:[NSColor clearColor] forKey: NSForegroundColorAttributeName];
                        }
                    }
                    if (areaSelectStatus == 0 || areaSelectStatus == 1){
                        if (selected == 0 || selected == 5 || selected == 6){
                            [[NSColor blackColor] set];
                            [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                        }
                        else if (selected == 3 || selected == 4){
                            [[NSColor clearColor] set];
                            [attributesA setObject:[NSColor clearColor] forKey: NSForegroundColorAttributeName];
                        }
                        else if (selected == 7){
                            [[NSColor redColor] set];
                            [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                        }
                        else if (selected == 2){
                            [[NSColor purpleColor] set];
                            [attributesA setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                        }
                        else{
                            
                            [[NSColor orangeColor] set];
                            [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                        }
                    }
                    
                    positionAA.x = xPointMarkTemp-magnificationLine;
                    positionAA.y = yPointMarkTemp;
                    positionBB.x = xPointMarkTemp+magnificationLine;
                    positionBB.y = yPointMarkTemp;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    positionCC.x = xPointMarkTemp;
                    positionCC.y = yPointMarkTemp-magnificationLine;
                    positionDD.x = xPointMarkTemp;
                    positionDD.y = yPointMarkTemp+magnificationLine;
                    [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                    
                    if (characterDisplayFlag == 1 || characterDisplayFlag == 0){
                        vectorNumberDisplay = [NSString stringWithFormat:@"%d", arrayGravityCenterRev [counter1*6+4]];
                        
                        attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                        pointA.x = xPointMarkTemp+magnificationLine*0.3;
                        pointA.y = yPointMarkTemp+magnificationLine*0.3;
                        [attrStrA drawAtPoint:pointA];
                    }
                }
                else{
                    
                    arrayTimeSelectedTemp [timeSelectedTempCount] = 0;
                    timeSelectedTempCount++;
                    arrayTimeSelectedTemp [timeSelectedTempCount] = counter1;
                    timeSelectedTempCount++;
                }
            }
            
            //-----Cut line number display-----
            [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            if (targetHoldInfoCount/4 != 0){
                for (int counter1 = 0; counter1 < targetHoldInfoCount/4; counter1++){
                    xPointMarkTemp = (int)((arrayTargetHoldInfo [counter1*4]-xPositionAdjustDouble)*(double)xCalculationValue);
                    yPointMarkTemp = (int)(((imageHeightTrack-arrayTargetHoldInfo [counter1*4+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                    
                    if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                        vectorNumberDisplay = [NSString stringWithFormat:@"%d", arrayTargetHoldInfo [counter1*4+3]];
                        
                        attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                        pointA.x = xPointMarkTemp+magnificationLine*0.3;
                        pointA.y = yPointMarkTemp+magnificationLine*0.3;
                        [attrStrA drawAtPoint:pointA];
                    }
                }
            }
            
            //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
            //	cout<<" arrayPositionRevise "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < timeSelectedTempCount/2; counterA++){
            //	for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<arrayTimeSelectedTemp [counterA*2+counterB];
            //	cout<<" arrayTimeSelectedTemp "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //	cout<<" arrayTimeSelected "<<counterA<<endl;
            //}
            
            //-----Points in and out of square set-----
            if (areaSelectStatus == 3){
                areaSelectStatus = 2;
                
                for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                    if (arrayTimeSelectedTemp [counter1*2+1] == counter1 && arrayTimeSelectedTemp [counter1*2] == 1){
                        if (arrayTimeSelected [counter1*10] == 5) arrayTimeSelected [counter1*10] = 1;
                        else if (arrayTimeSelected [counter1*10] == 6) arrayTimeSelected [counter1*10] = 7;
                    }
                    else if (arrayTimeSelectedTemp [counter1*2+1] == counter1 && arrayTimeSelectedTemp [counter1*2] == 0){
                        if (arrayTimeSelected [counter1*10] == 1) arrayTimeSelected [counter1*10] = 5;
                        else if (arrayTimeSelected [counter1*10] == 7) arrayTimeSelected [counter1*10] = 6;
                    }
                }
            }
            
            delete [] arrayTimeSelectedTemp;
            
            //-----Area mode square display-----
            if (areaSelectStatus == 2){
                [[NSColor redColor] set];
                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointDownTrack, yPointDownTrack, xPointDragTrack-xPointDownTrack, yPointDragTrack-yPointDownTrack)];
                [path3 stroke];
            }
            
            //-----Selected XY point display-----
            if (timeOneX != 0 && timeOneY != 0){
                xPointMarkTemp = (int)((timeOneX-xPositionAdjustDouble)*(double)xCalculationValue);
                yPointMarkTemp = (int)(((imageHeightTrack-timeOneY)-yPositionAdjustDouble)*(double)yCalculationValue);
                [[NSColor redColor] set];
                
                positionAA.x = xPointMarkTemp-magnificationLine;
                positionAA.y = yPointMarkTemp;
                positionBB.x = xPointMarkTemp+magnificationLine;
                positionBB.y = yPointMarkTemp;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                positionCC.x = xPointMarkTemp;
                positionCC.y = yPointMarkTemp-magnificationLine;
                positionDD.x = xPointMarkTemp;
                positionDD.y = yPointMarkTemp+magnificationLine;
                [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                
                NSRect rectangle = NSMakeRect(xPointMarkTemp-magnificationLine*2, yPointMarkTemp-magnificationLine*2, magnificationLine*4, magnificationLine*4);
                NSBezierPath* circlePath = [NSBezierPath bezierPath];
                [circlePath appendBezierPathWithOvalInRect: rectangle];
                [circlePath stroke];
                
                xPositionDisplay = timeOneX-imageWidthDisplay/2;
                yPositionDisplay = (imageHeightDisplay-timeOneY)-imageHeightDisplay/2;
            }
            
            //-----Line point display-----
            if (lineDraw == 2){ //-----point Data entry to arrayTarget-----
                if (targetCount+4 > targetLimit){
                    int *arrayTargetUpDate = new int [targetCount+10];
                    
                    for (int counter1 = 0; counter1 < targetCount; counter1++) arrayTargetUpDate [counter1] = arrayTarget [counter1];
                    
                    delete [] arrayTarget;
                    arrayTarget = new int [targetLimit+1000];
                    targetLimit = targetLimit+1000;
                    
                    for (int counter1 = 0; counter1 < targetCount; counter1++) arrayTarget [counter1] = arrayTargetUpDate [counter1];
                    delete [] arrayTargetUpDate;
                }
                
                int arrayTargetTemp = (int)(xPointLine/(double)xCalculationValue+xPositionAdjustDouble);
                arrayTarget [targetCount] = arrayTargetTemp, targetCount++;
                arrayTargetTemp = (int)((yPointLine/(double)yCalculationValue+yPositionAdjustDouble-imageHeightTrack)*-1);
                arrayTarget [targetCount] = arrayTargetTemp, targetCount++;
            }
            
            if (lineDraw == 1 || lineDraw == 2){ //-----Point display-----
                [[NSColor redColor] set];
                
                for (int counter1 = 0; counter1 < targetCount/2; counter1++){
                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect((arrayTarget [counter1*2]-xPositionAdjustDouble)*xCalculationValue, ((imageHeightTrack-arrayTarget [counter1*2+1])-yPositionAdjustDouble)*yCalculationValue, magnificationDisplay2, magnificationDisplay2)];
                    [path3 fill];
                }
            }
            
            //-----Info Display-----
            [attributesA setObject:[NSFont systemFontOfSize:12] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
            [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
            
            string infoDisplayString = "Time One";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
            pointA.x = 10;
            pointA.y = 685;
            [attrStrA drawAtPoint:pointA];
            
            if (areaSelectStatus == 1){
                [attributesA setObject:[NSColor cyanColor] forKey: NSForegroundColorAttributeName];
                infoDisplayString = "Area Select";
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 100;
                pointA.y = 685;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (lineDraw == 1){
                [attributesA setObject:[NSColor yellowColor] forKey: NSForegroundColorAttributeName];
                infoDisplayString = "Line Draw";
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 100;
                pointA.y = 685;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (timeOneQuickSet == 1){
                [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                infoDisplayString = "Cell_Conf.";
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 200;
                pointA.y = 685;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (timeOneQuickSet == 2){
                [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                infoDisplayString = "Track";
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 200;
                pointA.y = 685;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (timeOneQuickSet == 3){
                [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                infoDisplayString = "Non-Track";
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 200;
                pointA.y = 685;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (timeOneQuickSet == 4){
                [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                infoDisplayString = "Noise";
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 200;
                pointA.y = 685;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (currentConnectNo != 0){
                [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                infoDisplayString = "Connect: "+to_string(currentConnectNo);
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 300;
                pointA.y = 685;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (currentPositionSet != 0){
                [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                infoDisplayString = "Position: "+to_string(currentPositionSet)+" "+timeOneConnectStatus;
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 400;
                pointA.y = 685;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (fluorescentDetectionDisplay == 1){
                if (fluorescentDisplayNo == 0){
                    [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo: Find";
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                
                if (fluorescentDisplayNo == 1){
                    if (fluorescentNo1 == 1) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 2) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 3) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 4) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 5) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 6) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 7) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 8) [attributesA setObject:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo1 == 9) [attributesA setObject:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo: "+fluorescentName1;
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                
                if (fluorescentDisplayNo == 2){
                    if (fluorescentNo2 == 1) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 2) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 3) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 4) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 5) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 6) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 7) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 8) [attributesA setObject:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo2 == 9) [attributesA setObject:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo: "+fluorescentName2;
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                
                if (fluorescentDisplayNo == 3){
                    if (fluorescentNo3 == 1) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 2) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 3) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 4) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 5) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 6) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 7) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 8) [attributesA setObject:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo3 == 9) [attributesA setObject:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo: "+fluorescentName3;
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                
                if (fluorescentDisplayNo == 4){
                    if (fluorescentNo4 == 1) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 2) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 3) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 4) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 5) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 6) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 7) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 8) [attributesA setObject:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo4 == 9) [attributesA setObject:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo: "+fluorescentName4;
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                
                if (fluorescentDisplayNo == 5){
                    if (fluorescentNo5 == 1) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 2) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 3) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 4) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 5) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 6) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 7) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 8) [attributesA setObject:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo5 == 9) [attributesA setObject:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo: "+fluorescentName5;
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
                
                if (fluorescentDisplayNo == 6){
                    if (fluorescentNo6 == 1) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 2) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 3) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 4) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 5) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 6) [attributesA setObject:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 7) [attributesA setObject:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 8) [attributesA setObject:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] forKey: NSForegroundColorAttributeName];
                    else if (fluorescentNo6 == 9) [attributesA setObject:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] forKey: NSForegroundColorAttributeName];
                    
                    infoDisplayString = "Fluo: "+fluorescentName6;
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = 600;
                    pointA.y = 685;
                    [attrStrA drawAtPoint:pointA];
                }
            }
        }
    }
    
    if (imageLoadMonitor > 0) imageLoadMonitor++;
    if (addDelInsert == 1) addDelInsert++;
    if (clearBack == 1) clearBack++;
    if (listToTrackCall == 2) listToTrackCall++;
    if (lineAreaCall == 1) lineAreaCall++;
    if (trackJump == 1) trackJump++;
    if (imageReadTiming == 1) imageReadTiming++;
    if (sliderBarSet == 1) sliderBarSet++;
    if (cellJumpFirstLast == 7) cellJumpFirstLast++;
    if (quickLineageCall == 2) quickLineageCall++;
    if (quickConnectCall == 2) quickConnectCall++;
    if (timeOneLaunch == 1) timeOneLaunch++;
}

-(void)mergeExtend:(int)groupNoMerge{
    //=============Time one DIC expand============
    
    int maxPointDimX = 0;
    int maxPointDimY = 0;
    int minPointDimX = 1000000;
    int minPointDimY = 1000000;
    
    for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
        if (arrayTimeSelected [counter2*10+8] == groupNoMerge){
            for (int counter3 = arrayTimeSelected [counter2*10+2]; counter3 < positionReviseCount/7; counter3++){
                if (arrayPositionRevise [counter3*7+3] == groupNoMerge){
                    if (maxPointDimX < arrayPositionRevise [counter3*7]) maxPointDimX = arrayPositionRevise [counter3*7];
                    if (minPointDimX > arrayPositionRevise [counter3*7]) minPointDimX = arrayPositionRevise [counter3*7];
                    if (maxPointDimY < arrayPositionRevise [counter3*7+1]) maxPointDimY = arrayPositionRevise [counter3*7+1];
                    if (minPointDimY > arrayPositionRevise [counter3*7+1]) minPointDimY = arrayPositionRevise [counter3*7+1];
                }
                else{
                    
                    break;
                }
            }
        }
    }
    
    //=========A
    int horizontalLength2 = (maxPointDimX-minPointDimX)/2*2;
    int verticalLength2 = (maxPointDimY-minPointDimY)/2*2;
    int dimension2 = 0;
    int dimension2A = 0;
    int dimension2B = 0;
    
    if (horizontalLength2 >= verticalLength2) dimension2 = horizontalLength2+10;
    if (horizontalLength2 < verticalLength2) dimension2 = verticalLength2+10;
    
    dimension2A = (dimension2/2)*6;
    dimension2B = ((dimension2+20)/2)*6;
    
    int horizontalStart2A = minPointDimX-(dimension2A-horizontalLength2)/2;
    int verticalStart2A = minPointDimY-(dimension2A-verticalLength2)/2;
    int horizontalStart2B = minPointDimX-(dimension2B-horizontalLength2)/2;
    int verticalStart2B = minPointDimY-(dimension2B-verticalLength2)/2;
    //==========A
    
    int startY = 0;
    int endY = 0;
    int startX = 0;
    int endX = 0;
    
    //=========B
    int *findReviseConnect = new int [1000];
    for (int counter2 = 0; counter2 < 1000; counter2++) findReviseConnect [counter2] = 0;
    
    int **rangeMatrixA = new int *[dimension2A+4];
    
    for (int counter2 = 0; counter2 < dimension2A+4; counter2++){
        rangeMatrixA [counter2] = new int [dimension2A+4];
    }
    
    int **rangeMatrixB = new int *[dimension2B+4];
    
    for (int counter2 = 0; counter2 < dimension2B+4; counter2++){
        rangeMatrixB [counter2] = new int [dimension2B+4];
    }
    
    int *connectAnalysisXA = new int [dimension2A*4];
    int *connectAnalysisYA = new int [dimension2A*4];
    int *connectAnalysisTempXA = new int [dimension2A*4];
    int *connectAnalysisTempYA = new int [dimension2A*4];
    
    int *connectAnalysisXB = new int [dimension2B*4];
    int *connectAnalysisYB = new int [dimension2B*4];
    int *connectAnalysisTempXB = new int [dimension2B*4];
    int *connectAnalysisTempYB = new int [dimension2B*4];
    
    int freePixelFind = 0;
    int processConnectPosition = 0;
    int processConnectPosition2 = 0;
    int maxConnectRevise = 0;
    int findReviseConnectLimit = 1000;
    int connectivityNumberA = 0;
    int connectivityNumberB = 0;
    int connectAnalysisCount = 0;
    int terminationFlag = 0;
    int connectAnalysisTempCount = 0;
    int xSource = 0;
    int ySource = 0;
    int connectTemp = 0;
    int maxConnect = 0;
    int processConnectNo = 0;
    int findFlag = 0;
    int cutOffFinal = 0;
    
    for (int counter2 = cutStatusDic; counter2 < 240; counter2 = counter2+10){ //====DIC
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                    if (sourceImage [counterY+verticalStart2A][counterX+horizontalStart2A] == 100) rangeMatrixA [counterY][counterX] = 0;
                    else if (sourceImage [counterY+verticalStart2A][counterX+horizontalStart2A] < counter2) rangeMatrixA [counterY][counterX] = 0;
                    else rangeMatrixA [counterY][counterX] = -150;
                }
                else rangeMatrixA [counterY][counterX] = 0;
            }
        }
        
        for (int counterY = 0; counterY < dimension2B; counterY++){
            for (int counterX = 0; counterX < dimension2B; counterX++){
                if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                    if (sourceImage [counterY+verticalStart2B][counterX+horizontalStart2B] == 100) rangeMatrixB [counterY][counterX] = 0;
                    else if (sourceImage [counterY+verticalStart2B][counterX+horizontalStart2B] < counter2) rangeMatrixB [counterY][counterX] = 0;
                    else rangeMatrixB [counterY][counterX] = -150;
                }
                else rangeMatrixB [counterY][counterX] = 0;
            }
        }
        
        //-----MapA-----
        connectivityNumberA = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (rangeMatrixA [counterY][counterX] == -150){
                    connectivityNumberA++;
                    rangeMatrixA [counterY][counterX] = connectivityNumberA;
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixA [counterY-1][counterX-1] == -150){
                        rangeMatrixA [counterY-1][counterX-1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && rangeMatrixA [counterY-1][counterX] == -150){
                        rangeMatrixA [counterY-1][counterX] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && counterX+1 < dimension2A && rangeMatrixA [counterY-1][counterX+1] == -150){
                        rangeMatrixA [counterY-1][counterX+1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension2A && rangeMatrixA [counterY][counterX+1] == -150){
                        rangeMatrixA [counterY][counterX+1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2A && counterX+1 < dimension2A && rangeMatrixA [counterY+1][counterX+1] == -150){
                        rangeMatrixA [counterY+1][counterX+1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2A && rangeMatrixA [counterY+1][counterX] == -150){
                        rangeMatrixA [counterY+1][counterX] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2A && counterX-1 >= 0 && rangeMatrixA [counterY+1][counterX-1] == -150){
                        rangeMatrixA [counterY+1][counterX-1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && rangeMatrixA [counterY][counterX-1] == -150){
                        rangeMatrixA [counterY][counterX-1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                xSource = connectAnalysisXA [counter3], ySource = connectAnalysisYA [counter3];
                                
                                if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrixA [ySource-1][xSource-1] == -150){
                                    rangeMatrixA [ySource-1][xSource-1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && rangeMatrixA [ySource-1][xSource] == -150){
                                    rangeMatrixA [ySource-1][xSource] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && xSource+1 < dimension2A && rangeMatrixA [ySource-1][xSource+1] == -150){
                                    rangeMatrixA [ySource-1][xSource+1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension2A && rangeMatrixA [ySource][xSource+1] == -150){
                                    rangeMatrixA [ySource][xSource+1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 > dimension2A && xSource+1 < dimension2A && rangeMatrixA [ySource+1][xSource+1] == -150){
                                    rangeMatrixA [ySource+1][xSource+1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension2A && rangeMatrixA [ySource+1][xSource] == -150){
                                    rangeMatrixA [ySource+1][xSource] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension2A && xSource-1 >= 0 && rangeMatrixA [ySource+1][xSource-1] == -150){
                                    rangeMatrixA [ySource+1][xSource-1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && rangeMatrixA [ySource][xSource-1] == -150){
                                    rangeMatrixA [ySource][xSource-1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                connectAnalysisXA [counter3] = connectAnalysisTempXA [counter3], connectAnalysisYA [counter3] = connectAnalysisTempYA [counter3];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //-----Determine number of pixels-----
        int *connectedPix = new int [connectivityNumberA+50];
        
        for (int counter3 = 0; counter3 <= connectivityNumberA; counter3++) connectedPix [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (rangeMatrixA [counterY][counterX] != 0) connectedPix [rangeMatrixA [counterY][counterX]]++;
            }
        }
        
        //-----Map up-date-----
        connectTemp = 1;
        
        for (int counter3 = 1; counter3 <= connectivityNumberA; counter3++){
            if (connectedPix [counter3] < 10) connectedPix [counter3] = 0;
            else{
                
                connectedPix [counter3] = connectTemp;
                connectTemp++;
            }
        }
        
        maxConnect = 0;
        maxConnectRevise = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A];
                    
                    if ((connectTemp = rangeMatrixA [counterY][counterX]) != 0) rangeMatrixA [counterY][counterX] = connectedPix [connectTemp];
                    else rangeMatrixA [counterY][counterX] = 0;
                    
                    if (rangeMatrixA [counterY][counterX] > maxConnect) maxConnect = rangeMatrixA [counterY][counterX];
                }
            }
        }
        
        delete [] connectedPix;
        
        int *findConnectNo = new int [maxConnect+5];
        for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo [counter3] = 0;
        
        if (maxConnectRevise+10 > findReviseConnectLimit){
            delete [] findReviseConnect;
            findReviseConnect = new int [maxConnectRevise+50];
            findReviseConnectLimit = maxConnectRevise+50;
        }
        
        for (int counter3 = 0; counter3 < maxConnectRevise+5; counter3++) findReviseConnect [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] == groupNoMerge){
                        if (rangeMatrixA [counterY][counterX] != 0) findConnectNo [rangeMatrixA [counterY][counterX]]++;
                    }
                }
            }
        }
        
        processConnectNo = 0;
        processConnectPosition = 0;
        
        for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
            if (findConnectNo [counter3] > processConnectNo){
                processConnectNo = findConnectNo [counter3];
                processConnectPosition = counter3;
            }
        }
        
        if (processConnectPosition != 0){
            freePixelFind = 0;
            
            for (int counterY = 0; counterY < dimension2A; counterY++){
                for (int counterX = 0; counterX < dimension2A; counterX++){
                    if (rangeMatrixA [counterY][counterX] == processConnectPosition){
                        if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                            if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] != 0){
                                findReviseConnect [revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A]]++;
                            }
                            
                            if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] == 0) freePixelFind = 1;
                        }
                    }
                }
            }
            
            //-----MapB-----
            connectivityNumberB = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (rangeMatrixB [counterY][counterX] == -150){
                        connectivityNumberB++;
                        rangeMatrixB [counterY][counterX] = connectivityNumberB;
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixB [counterY-1][counterX-1] == -150){
                            rangeMatrixB [counterY-1][counterX-1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && rangeMatrixB [counterY-1][counterX] == -150){
                            rangeMatrixB [counterY-1][counterX] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && counterX+1 < dimension2B && rangeMatrixB [counterY-1][counterX+1] == -150){
                            rangeMatrixB [counterY-1][counterX+1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension2B && rangeMatrixB [counterY][counterX+1] == -150){
                            rangeMatrixB [counterY][counterX+1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2B && counterX+1 < dimension2B && rangeMatrixB [counterY+1][counterX+1] == -150){
                            rangeMatrixB [counterY+1][counterX+1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2B && rangeMatrixB [counterY+1][counterX] == -150){
                            rangeMatrixB [counterY+1][counterX] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2B && counterX-1 >= 0 && rangeMatrixB [counterY+1][counterX-1] == -150){
                            rangeMatrixB [counterY+1][counterX-1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && rangeMatrixB [counterY][counterX-1] == -150){
                            rangeMatrixB [counterY][counterX-1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                    xSource = connectAnalysisXB [counter3], ySource = connectAnalysisYB [counter3];
                                    
                                    if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrixB [ySource-1][xSource-1] == -150){
                                        rangeMatrixB [ySource-1][xSource-1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && rangeMatrixB [ySource-1][xSource] == -150){
                                        rangeMatrixB [ySource-1][xSource] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && xSource+1 < dimension2B && rangeMatrixB [ySource-1][xSource+1] == -150){
                                        rangeMatrixB [ySource-1][xSource+1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension2B && rangeMatrixB [ySource][xSource+1] == -150){
                                        rangeMatrixB [ySource][xSource+1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 > dimension2B && xSource+1 < dimension2B && rangeMatrixB [ySource+1][xSource+1] == -150){
                                        rangeMatrixB [ySource+1][xSource+1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension2B && rangeMatrixB [ySource+1][xSource] == -150){
                                        rangeMatrixB [ySource+1][xSource] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension2B && xSource-1 >= 0 && rangeMatrixB [ySource+1][xSource-1] == -150){
                                        rangeMatrixB [ySource+1][xSource-1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && rangeMatrixB [ySource][xSource-1] == -150){
                                        rangeMatrixB [ySource][xSource-1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                    connectAnalysisXB [counter3] = connectAnalysisTempXB [counter3], connectAnalysisYB [counter3] = connectAnalysisTempYB [counter3];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //-----Determine number of pixels-----
            connectedPix = new int [connectivityNumberB+50];
            
            for (int counter3 = 0; counter3 <= connectivityNumberB; counter3++) connectedPix [counter3] = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (rangeMatrixB [counterY][counterX] != 0) connectedPix [rangeMatrixB [counterY][counterX]]++;
                }
            }
            
            //-----Map up-date-----
            connectTemp = 1;
            
            for (int counter3 = 1; counter3 <= connectivityNumberB; counter3++){
                if (connectedPix [counter3] < 10) connectedPix [counter3] = 0;
                else{
                    
                    connectedPix [counter3] = connectTemp;
                    connectTemp++;
                }
            }
            
            maxConnect = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                        if ((connectTemp = rangeMatrixB [counterY][counterX]) != 0) rangeMatrixB [counterY][counterX] = connectedPix [connectTemp];
                        else rangeMatrixB [counterY][counterX] = 0;
                        
                        if (rangeMatrixB [counterY][counterX] > maxConnect) maxConnect = rangeMatrixB [counterY][counterX];
                    }
                }
            }
            
            delete [] connectedPix;
            
            int *findConnectNo2 = new int [maxConnect+5];
            for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo2 [counter3] = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                        if (revisedWorkingMap [counterY+verticalStart2B][counterX+horizontalStart2B] == groupNoMerge){
                            if (rangeMatrixB [counterY][counterX] != 0) findConnectNo2 [rangeMatrixB [counterY][counterX]]++;
                        }
                    }
                }
            }
            
            processConnectNo = 0;
            processConnectPosition2 = 0;
            
            for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
                if (findConnectNo2 [counter3] > processConnectNo){
                    processConnectNo = findConnectNo2 [counter3];
                    processConnectPosition2 = counter3;
                }
            }
            
            if (processConnectPosition2 != 0){
                for (int counterY = 0; counterY < dimension2A; counterY++){
                    for (int counterX = 0; counterX < dimension2A; counterX++){
                        if ((counterY+verticalStart2A)-verticalStart2B >= 0 && (counterY+verticalStart2A)-verticalStart2B < dimension2B && (counterX+horizontalStart2A)-horizontalStart2B >= 0 && (counterX+horizontalStart2A)-horizontalStart2B < dimension2B){
                            rangeMatrixB [(counterY+verticalStart2A)-verticalStart2B][(counterX+horizontalStart2A)-horizontalStart2B] = 0;
                        }
                    }
                }
                
                findFlag = 0;
                
                for (int counterY = 0; counterY < dimension2B; counterY++){
                    for (int counterX = 0; counterX < dimension2B; counterX++){
                        if (rangeMatrixB [counterY][counterX] == processConnectPosition2){
                            findFlag = 1;
                            break;
                        }
                    }
                }
                
                if (findFlag == 0){
                    cutOffFinal = counter2;
                    
                    delete [] findConnectNo2;
                    delete [] findConnectNo;
                    break;
                }
            }
            else{
                
                if (counter2 != 20) cutOffFinal = counter2-10;
                else cutOffFinal = 0;
                
                delete [] findConnectNo2;
                delete [] findConnectNo;
                break;
            }
            
            delete [] findConnectNo2;
        }
        else{
            
            if (counter2 != 20) cutOffFinal = counter2-10;
            else cutOffFinal = 0;
            
            delete [] findConnectNo;
            break;
        }
        
        delete [] findConnectNo;
    }
    
    delete [] connectAnalysisXA;
    delete [] connectAnalysisYA;
    delete [] connectAnalysisTempXA;
    delete [] connectAnalysisTempYA;
    
    delete [] connectAnalysisXB;
    delete [] connectAnalysisYB;
    delete [] connectAnalysisTempXB;
    delete [] connectAnalysisTempYB;
    
    for (int counter2 = 0; counter2 < dimension2A+4; counter2++){
        delete [] rangeMatrixA [counter2];
    }
    
    delete [] rangeMatrixA;
    
    for (int counter2 = 0; counter2 < dimension2B+4; counter2++){
        delete [] rangeMatrixB [counter2];
    }
    
    delete [] rangeMatrixB;
    //-----BB
    
    if (cutOffFinal != 0 && freePixelFind == 1){
        int extendConnectCount = 0;
        
        for (int counter2 = 1; counter2 < maxConnectRevise+1; counter2++){
            if (findReviseConnect [counter2] != 0) extendConnectCount++;
        }
        
        int *extendConnectList = new int [extendConnectCount*2+1];
        extendConnectCount = 0;
        
        for (int counter2 = 1; counter2 < maxConnectRevise+1; counter2++){
            if (findReviseConnect [counter2] != 0){
                extendConnectList [extendConnectCount] = counter2, extendConnectCount++;
                extendConnectList [extendConnectCount] = 0, extendConnectCount++;
            }
        }
        
        int connectFind = 0;
        int startPosition = 0;
        
        for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
            connectTemp = arrayTimeSelected [counter2*10+8];
            connectFind = 0;
            
            for (int counter3 = 0; counter3 < extendConnectCount/2; counter3++){
                if (extendConnectList [counter3*2] == connectTemp) connectFind = 1;
            }
            
            if (connectFind == 1){
                startPosition = arrayTimeSelected [counter2*10+2];
                
                for (int counter3 = startPosition; counter3 < positionReviseCount/7; counter3++){
                    if (arrayPositionRevise [counter3*7+3] == connectTemp){
                        if (maxPointDimX < arrayPositionRevise [counter3*7]) maxPointDimX = arrayPositionRevise [counter3*7];
                        if (minPointDimX > arrayPositionRevise [counter3*7]) minPointDimX = arrayPositionRevise [counter3*7];
                        if (maxPointDimY < arrayPositionRevise [counter3*7+1]) maxPointDimY = arrayPositionRevise [counter3*7+1];
                        if (minPointDimY > arrayPositionRevise [counter3*7+1]) minPointDimY = arrayPositionRevise [counter3*7+1];
                    }
                    else{
                        
                        break;
                    }
                }
            }
        }
        
        int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
        int verticalLength = (maxPointDimY-minPointDimY)/2*2;
        int dimension = 0;
        
        if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
        if (horizontalLength < verticalLength) dimension = verticalLength+30;
        
        dimension = (dimension/2)*2;
        
        int horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
        int verticalStart = minPointDimY-(dimension-verticalLength)/2;
        
        //=======CC
        int **rangeMatrix = new int *[dimension+4];
        
        for (int counter2 = 0; counter2 < dimension+4; counter2++){
            rangeMatrix [counter2] = new int [dimension+4];
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                    if (sourceImage [counterY+verticalStart][counterX+horizontalStart] == 100) rangeMatrix [counterY][counterX] = 0;
                    else if (sourceImage [counterY+verticalStart][counterX+horizontalStart] < cutOffFinal) rangeMatrix [counterY][counterX] = 0;
                    else rangeMatrix [counterY][counterX] = -150;
                }
                else rangeMatrix [counterY][counterX] = 0;
            }
        }
        
        int *connectAnalysisX = new int [dimension*4];
        int *connectAnalysisY = new int [dimension*4];
        int *connectAnalysisTempX = new int [dimension*4];
        int *connectAnalysisTempY = new int [dimension*4];
        
        int connectivityNumber = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (rangeMatrix [counterY][counterX] == -150){
                    connectivityNumber++;
                    rangeMatrix [counterY][counterX] = connectivityNumber;
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrix [counterY-1][counterX-1] == -150){
                        rangeMatrix [counterY-1][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && rangeMatrix [counterY-1][counterX] == -150){
                        rangeMatrix [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && counterX+1 < dimension && rangeMatrix [counterY-1][counterX+1] == -150){
                        rangeMatrix [counterY-1][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension && rangeMatrix [counterY][counterX+1] == -150){
                        rangeMatrix [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && counterX+1 < dimension && rangeMatrix [counterY+1][counterX+1] == -150){
                        rangeMatrix [counterY+1][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && rangeMatrix [counterY+1][counterX] == -150){
                        rangeMatrix [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && counterX-1 >= 0 && rangeMatrix [counterY+1][counterX-1] == -150){
                        rangeMatrix [counterY+1][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && rangeMatrix [counterY][counterX-1] == -150){
                        rangeMatrix [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                
                                if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrix [ySource-1][xSource-1] == -150){
                                    rangeMatrix [ySource-1][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && rangeMatrix [ySource-1][xSource] == -150){
                                    rangeMatrix [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && xSource+1 < dimension && rangeMatrix [ySource-1][xSource+1] == -150){
                                    rangeMatrix [ySource-1][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension && rangeMatrix [ySource][xSource+1] == -150){
                                    rangeMatrix [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 > dimension && xSource+1 < dimension && rangeMatrix [ySource+1][xSource+1] == -150){
                                    rangeMatrix [ySource+1][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && rangeMatrix [ySource+1][xSource] == -150){
                                    rangeMatrix [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && xSource-1 >= 0 && rangeMatrix [ySource+1][xSource-1] == -150){
                                    rangeMatrix [ySource+1][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && rangeMatrix [ySource][xSource-1] == -150){
                                    rangeMatrix [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //-----Determine number of pixels-----
        int *connectedPix = new int [connectivityNumber+50];
        
        for (int counter3 = 0; counter3 <= connectivityNumber; counter3++) connectedPix [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (rangeMatrix [counterY][counterX] != 0) connectedPix [rangeMatrix [counterY][counterX]]++;
            }
        }
        
        //-----Map up-date-----
        connectTemp = 1;
        
        for (int counter3 = 1; counter3 <= connectivityNumber; counter3++){
            if (connectedPix [counter3] < 10) connectedPix [counter3] = 0;
            else{
                
                connectedPix [counter3] = connectTemp;
                connectTemp++;
            }
        }
        
        maxConnect = 0;
        maxConnectRevise = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart];
                    
                    if ((connectTemp = rangeMatrix [counterY][counterX]) != 0) rangeMatrix [counterY][counterX] = connectedPix [connectTemp];
                    else rangeMatrix [counterY][counterX] = 0;
                    
                    if (rangeMatrix [counterY][counterX] > maxConnect) maxConnect = rangeMatrix [counterY][counterX];
                }
            }
        }
        
        delete [] connectedPix;
        
        int *findConnectNo = new int [maxConnect+5];
        for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo [counter3] = 0;
        
        if (maxConnectRevise+10 > findReviseConnectLimit){
            delete [] findReviseConnect;
            findReviseConnect = new int [maxConnectRevise+50];
        }
        
        for (int counter3 = 0; counter3 < maxConnectRevise+5; counter3++) findReviseConnect [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] == groupNoMerge){
                        if (rangeMatrix [counterY][counterX] != 0) findConnectNo [rangeMatrix [counterY][counterX]]++;
                    }
                }
            }
        }
        
        processConnectNo = 0;
        processConnectPosition = 0;
        
        for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
            if (findConnectNo [counter3] > processConnectNo){
                processConnectNo = findConnectNo [counter3];
                processConnectPosition = counter3;
            }
        }
        //========CC
        
        int **connectivityMapTemp = new int *[dimension+1];
        int **connectivityMapTemp2 = new int *[dimension+1];
        
        for (int counter2 = 0; counter2 < dimension+1; counter2++){
            connectivityMapTemp [counter2] = new int [dimension+1];
            connectivityMapTemp2 [counter2] = new int [dimension+1];
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = 0;
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (rangeMatrix  [counterY][counterX] == processConnectPosition){
                    connectivityMapTemp [counterY][counterX] = -1;
                }
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
        //    cout<<" connectivityMapTemp "<<counterA<<endl;
        //}
        
        if (minPointDimY-30 >= 0) startY = minPointDimY-30;
        else startY = 0;
        
        if (maxPointDimY+30 < imageDimension) endY = maxPointDimY+31;
        else endY = imageDimension;
        
        if (minPointDimX-30 >= 0) startX = minPointDimX-30;
        else startX = 0;
        
        if (maxPointDimX+30 < imageDimension) endX = maxPointDimX+31;
        else endX = imageDimension;
        
        for (int counterY = startY; counterY < endY; counterY++){
            for (int counterX = startX; counterX < endX; counterX++){
                connectFind = 0;
                
                for (int counter3 = 0; counter3 < extendConnectCount/2; counter3++){
                    if (extendConnectList [counter3*2] == revisedWorkingMap [counterY][counterX]) connectFind = 1;
                }
                
                if (connectFind == 1){
                    if (counterY-verticalStart > 0 && counterY-verticalStart < dimension && counterX-horizontalStart > 0 && counterX-horizontalStart < dimension)
                        connectivityMapTemp [counterY-verticalStart][counterX-horizontalStart] = revisedWorkingMap [counterY][counterX];
                }
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
        //    cout<<" connectivityMapTemp "<<counterA<<endl;
        //}
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                connectivityMapTemp2 [counterY][counterX] = connectivityMapTemp [counterY][counterX];
            }
        }
        
        terminationFlag = 0;
        int startOrder = 0;
        int findFreePoint = 0;
        int connectNo = 0;
        int remainingCheck = 0;
        
        do{
            
            for (int counter2 = startOrder; counter2 < extendConnectCount/2; counter2++){
                connectNo = extendConnectList [counter2*2];
                
                if (extendConnectList [counter2*2+1] == 0){
                    findFreePoint = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp [counterY][counterX] == connectNo){
                                if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMapTemp [counterY-1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX+1 < dimension && connectivityMapTemp [counterY+1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                }
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                    }
                    
                    if (findFreePoint == 0) extendConnectList [counter2*2+1] = 1;
                }
            }
            
            for (int counter2 = 0; counter2 < startOrder; counter2++){
                connectNo = extendConnectList [counter2*2];
                
                if (extendConnectList [counter2*2+1] == 0){
                    findFreePoint = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp [counterY][counterX] == connectNo){
                                if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMapTemp [counterY-1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == processConnectPosition){
                                    connectivityMapTemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX+1 < dimension && connectivityMapTemp [counterY+1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                }
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                    }
                    
                    if (findFreePoint == 0) extendConnectList [counter2*2+1] = 1;
                }
            }
            
            remainingCheck = 0;
            
            for (int counter2 = 0; counter2 < extendConnectCount/2; counter2++){
                if (extendConnectList [counter2*2+1] == 0) remainingCheck = 1;
            }
            
            if (remainingCheck == 0) terminationFlag = 1;
            
            startOrder++;
            
            if (startOrder == extendConnectCount/2) startOrder = 0;
            
        } while (terminationFlag == 0);
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
        //    cout<<" connectivityMapTemp "<<counterA<<endl;
        //}
        
        int largestConnect = 0;
        int largestConnectNo = 0;
        int xPositionTempStart = 0;
        int yPositionTempStart = 0;
        int lineSize = 0;
        int constructedLineCount = 0;
        int processType = 0;
        
        for (int counter2 = 0; counter2 < extendConnectCount/2; counter2++){
            if (connectDataExchangeStatus == 1) connectDataExchange [extendConnectList [counter2*2]] = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp [counterY][counterX] == extendConnectList [counter2*2]) connectivityMapTemp2 [counterY][counterX] = 1;
                    else connectivityMapTemp2 [counterY][counterX] = 0;
                }
            }
            
            //-----Connectivity analysis, For Zero-----
            connectivityNumber = -3;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] == 0){
                        connectivityNumber = connectivityNumber+2;
                        connectivityMapTemp2 [counterY][counterX] = connectivityNumber;
                        
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0){
                            connectivityMapTemp2 [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0){
                            connectivityMapTemp2 [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0){
                            connectivityMapTemp2 [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0){
                            connectivityMapTemp2 [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                    xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                    
                                    if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                        connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                        connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                        connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                        connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                    connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //-----Remove connectivity groups, which attach edge, extract inner part of Linked Line-----
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] == -1) connectivityMapTemp2 [counterY][counterX] = 0;
                }
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] != 0){
                        if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                        else if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                        else if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                        else if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                    }
                }
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] > 0) connectivityMapTemp2 [counterY][counterX] = 0;
                    if (connectivityMapTemp2 [counterY][counterX] < 0) connectivityMapTemp2 [counterY][counterX] = 1;
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
            //    cout<<" connectivityMapTemp2 "<<counterA<<endl;
            //}
            
            connectivityNumber = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (connectivityMapTemp2 [counterY2][counterX2] == 0){
                        connectivityNumber--;
                        connectAnalysisCount = 0;
                        
                        connectivityMapTemp2 [counterY2][counterX2] = connectivityNumber;
                        
                        if (counterY2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2] == 0){
                            connectivityMapTemp2 [counterY2-1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                        }
                        if (counterX2+1 < dimension && connectivityMapTemp2 [counterY2][counterX2+1] == 0){
                            connectivityMapTemp2 [counterY2][counterX2+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        if (counterY2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2] == 0){
                            connectivityMapTemp2 [counterY2+1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                        }
                        if (counterX2-1 >= 0 && connectivityMapTemp2 [counterY2][counterX2-1] == 0){
                            connectivityMapTemp2 [counterY2][counterX2-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                    xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                    
                                    if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                        connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                        connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                        connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                        connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                    connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
            //    cout<<" connectivityMapTemp2 "<<counterA<<endl;
            //}
            
            //-----Determine number of pixels-----
            connectivityNumber = connectivityNumber*-1;
            
            connectedPix = new int [connectivityNumber+50];
            
            for (int counter3 = 0; counter3 <= connectivityNumber; counter3++) connectedPix [counter3] = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (connectivityMapTemp2 [counterY2][counterX2] < -1){
                        connectedPix [connectivityMapTemp2 [counterY2][counterX2]*-1]++;
                    }
                }
            }
            
            int **newConnectivityMapTemp = new int *[dimension+4];
            for (int counter3 = 0; counter3 < dimension+4; counter3++) newConnectivityMapTemp [counter3] = new int [dimension+4];
            
            for (int counterY = 0; counterY < dimension+4; counterY++){
                for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
            }
            
            largestConnect = 0;
            largestConnectNo = 0;
            
            for (int counter3 = 2; counter3 <= connectivityNumber; counter3++){
                if (connectedPix [counter3] > largestConnect){
                    largestConnect = connectedPix [counter3];
                    largestConnectNo = counter3;
                }
            }
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (connectivityMapTemp2 [counterY2][counterX2] == largestConnectNo*-1){
                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                            connectivityMapTemp2 [counterY2-1][counterX2-1] = 0;
                        }
                        if (counterY2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                            connectivityMapTemp2 [counterY2-1][counterX2] = 0;
                        }
                        if (counterY2-1 >= 0 && counterX2+1 < dimension && connectivityMapTemp2 [counterY2-1][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                            connectivityMapTemp2 [counterY2-1][counterX2+1] = 0;
                        }
                        if (counterX2+1 < dimension && connectivityMapTemp2 [counterY2][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                            connectivityMapTemp2 [counterY2][counterX2+1] = 0;
                        }
                        if (counterY2+1 < dimension && counterX2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                            connectivityMapTemp2 [counterY2+1][counterX2+1] = 0;
                        }
                        if (counterY2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                            connectivityMapTemp2 [counterY2+1][counterX2] = 0;
                        }
                        if (counterY2+1 < dimension && counterX2-1 >= 0 && connectivityMapTemp2 [counterY2+1][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                            connectivityMapTemp2 [counterY2+1][counterX2-1] = 0;
                        }
                        if (counterX2-1 >= 0 && connectivityMapTemp2 [counterY2][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                            connectivityMapTemp2 [counterY2][counterX2-1] = 0;
                        }
                    }
                }
            }
            
            delete [] connectedPix;
            
            xPositionTempStart = 0;
            yPositionTempStart = 0;
            lineSize = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                        connectivityMapTemp2 [counterY2][counterX2] = 1;
                        
                        xPositionTempStart = counterX2;
                        yPositionTempStart = counterY2;
                        lineSize++;
                    }
                    else connectivityMapTemp2 [counterY2][counterX2] = 0;
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
            //    cout<<" connectivityMapTemp2 "<<counterA<<endl;
            //}
            
            for (int counter3 = 0; counter3 < dimension+4; counter3++) delete [] newConnectivityMapTemp [counter3];
            delete [] newConnectivityMapTemp;
            
            constructedLineCount = 0;
            
            int *arrayNewLines = new int [lineSize*2+50];
            
            connectivityMapTemp2 [yPositionTempStart][xPositionTempStart] = -1;
            arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
            arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
            
            do{
                
                findFlag = 0;
                terminationFlag = 0;
                
                if (xPositionTempStart+1 < dimension){
                    if (connectivityMapTemp2 [yPositionTempStart][xPositionTempStart+1] == 1){
                        connectivityMapTemp2 [yPositionTempStart][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                        connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (yPositionTempStart+1 < dimension && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart] == 1){
                        connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                        yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                        connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (xPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart][xPositionTempStart-1] == 1){
                        connectivityMapTemp2 [yPositionTempStart][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                        connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart] == 1){
                        connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                        yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                
                if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                        connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                    }
                }
                
            } while (terminationFlag == 1);
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
            //	cout<<" connectivityMapTemp2 "<<counterA<<endl;
            //}
            
            referenceLineCount = 0;
            
            for (int counter3 = 0; counter3 < constructedLineCount/2; counter3++){
                if (referenceLineCount+4 > referenceLineLimit){
                    fileUpdate = [[FileUpdate alloc] init];
                    [fileUpdate referenceLineCountUpDate];
                }
                
                arrayReferenceLine [referenceLineCount] = arrayNewLines [counter3*2], referenceLineCount++;
                arrayReferenceLine [referenceLineCount] = arrayNewLines [counter3*2+1], referenceLineCount++;
            }
            
            delete [] arrayNewLines;
            
            processType = 4;
            lineSet = [[LineSet alloc] init];
            [lineSet lineSetProcess:processType];
        }
        
        delete [] connectAnalysisX;
        delete [] connectAnalysisY;
        delete [] connectAnalysisTempX;
        delete [] connectAnalysisTempY;
        
        delete [] extendConnectList;
        
        for (int counter2 = 0; counter2 < dimension+1; counter2++){
            delete [] connectivityMapTemp [counter2];
            delete [] connectivityMapTemp2 [counter2];
        }
        
        delete [] connectivityMapTemp;
        delete [] connectivityMapTemp2;
        
        for (int counter2 = 0; counter2 < dimension+4; counter2++){
            delete [] rangeMatrix [counter2];
        }
        
        delete [] rangeMatrix;
        
        delete [] findConnectNo;
    }
    
    delete [] findReviseConnect;
}

-(void)mergeExtendTrack:(int)groupNoMerge{
    //=========Tracking mode, DIC expand (command I), Expand All Connect group within the scope========
    
    int maxPointDimX = 0;
    int maxPointDimY = 0;
    int minPointDimX = 1000000;
    int minPointDimY = 1000000;
    
    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
        if (arrayTimeSelected [counter1*10+8] == groupNoMerge){
            for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                if (arrayPositionRevise [counter2*7+3] == groupNoMerge){
                    if (maxPointDimX < arrayPositionRevise [counter2*7]) maxPointDimX = arrayPositionRevise [counter2*7];
                    if (minPointDimX > arrayPositionRevise [counter2*7]) minPointDimX = arrayPositionRevise [counter2*7];
                    if (maxPointDimY < arrayPositionRevise [counter2*7+1]) maxPointDimY = arrayPositionRevise [counter2*7+1];
                    if (minPointDimY > arrayPositionRevise [counter2*7+1]) minPointDimY = arrayPositionRevise [counter2*7+1];
                }
                else{
                    
                    break;
                }
            }
        }
    }
    
    //=========A
    int horizontalLength2 = (maxPointDimX-minPointDimX)/2*2;
    int verticalLength2 = (maxPointDimY-minPointDimY)/2*2;
    int dimension2 = 0;
    int dimension2A = 0;
    int dimension2B = 0;
    
    if (horizontalLength2 >= verticalLength2) dimension2 = horizontalLength2+10;
    if (horizontalLength2 < verticalLength2) dimension2 = verticalLength2+10;
    
    dimension2A = (dimension2/2)*6;
    dimension2B = ((dimension2+20)/2)*6;
    
    int horizontalStart2A = minPointDimX-(dimension2A-horizontalLength2)/2;
    int verticalStart2A = minPointDimY-(dimension2A-verticalLength2)/2;
    int horizontalStart2B = minPointDimX-(dimension2B-horizontalLength2)/2;
    int verticalStart2B = minPointDimY-(dimension2B-verticalLength2)/2;
    //==========A
    
    int startY = 0;
    int endY = 0;
    int startX = 0;
    int endX = 0;
    
    //=========B
    int *findReviseConnect = new int [1000];
    for (int counter2 = 0; counter2 < 1000; counter2++) findReviseConnect [counter2] = 0;
    
    int **rangeMatrixA = new int *[dimension2A+4];
    
    for (int counter2 = 0; counter2 < dimension2A+4; counter2++){
        rangeMatrixA [counter2] = new int [dimension2A+4];
    }
    
    int **rangeMatrixB = new int *[dimension2B+4];
    
    for (int counter2 = 0; counter2 < dimension2B+4; counter2++){
        rangeMatrixB [counter2] = new int [dimension2B+4];
    }
    
    int *connectAnalysisXA = new int [dimension2A*4];
    int *connectAnalysisYA = new int [dimension2A*4];
    int *connectAnalysisTempXA = new int [dimension2A*4];
    int *connectAnalysisTempYA = new int [dimension2A*4];
    
    int *connectAnalysisXB = new int [dimension2B*4];
    int *connectAnalysisYB = new int [dimension2B*4];
    int *connectAnalysisTempXB = new int [dimension2B*4];
    int *connectAnalysisTempYB = new int [dimension2B*4];
    
    int freePixelFind = 0;
    int processConnectPosition = 0;
    int processConnectPosition2 = 0;
    int maxConnectRevise = 0;
    int findReviseConnectLimit = 1000;
    int connectivityNumberA = 0;
    int connectivityNumberB = 0;
    int connectAnalysisCount = 0;
    int terminationFlag = 0;
    int connectAnalysisTempCount = 0;
    int xSource = 0;
    int ySource = 0;
    int connectTemp = 0;
    int maxConnect = 0;
    int processConnectNo = 0;
    int findFlag = 0;
    int cutOffFinal = 0;
    
    for (int counter2 = cutStatusDic; counter2 < 240; counter2 = counter2+10){ //====DIC
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                    if (sourceImage [counterY+verticalStart2A][counterX+horizontalStart2A] == 100) rangeMatrixA [counterY][counterX] = 0;
                    else if (sourceImage [counterY+verticalStart2A][counterX+horizontalStart2A] < counter2) rangeMatrixA [counterY][counterX] = 0;
                    else rangeMatrixA [counterY][counterX] = -150;
                }
                else rangeMatrixA [counterY][counterX] = 0;
            }
        }
        
        for (int counterY = 0; counterY < dimension2B; counterY++){
            for (int counterX = 0; counterX < dimension2B; counterX++){
                if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                    if (sourceImage [counterY+verticalStart2B][counterX+horizontalStart2B] == 100) rangeMatrixB [counterY][counterX] = 0;
                    else if (sourceImage [counterY+verticalStart2B][counterX+horizontalStart2B] < counter2) rangeMatrixB [counterY][counterX] = 0;
                    else rangeMatrixB [counterY][counterX] = -150;
                }
                else rangeMatrixB [counterY][counterX] = 0;
            }
        }
        
        //-----MapA-----
        connectivityNumberA = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (rangeMatrixA [counterY][counterX] == -150){
                    connectivityNumberA++;
                    rangeMatrixA [counterY][counterX] = connectivityNumberA;
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixA [counterY-1][counterX-1] == -150){
                        rangeMatrixA [counterY-1][counterX-1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && rangeMatrixA [counterY-1][counterX] == -150){
                        rangeMatrixA [counterY-1][counterX] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && counterX+1 < dimension2A && rangeMatrixA [counterY-1][counterX+1] == -150){
                        rangeMatrixA [counterY-1][counterX+1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension2A && rangeMatrixA [counterY][counterX+1] == -150){
                        rangeMatrixA [counterY][counterX+1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2A && counterX+1 < dimension2A && rangeMatrixA [counterY+1][counterX+1] == -150){
                        rangeMatrixA [counterY+1][counterX+1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2A && rangeMatrixA [counterY+1][counterX] == -150){
                        rangeMatrixA [counterY+1][counterX] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2A && counterX-1 >= 0 && rangeMatrixA [counterY+1][counterX-1] == -150){
                        rangeMatrixA [counterY+1][counterX-1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && rangeMatrixA [counterY][counterX-1] == -150){
                        rangeMatrixA [counterY][counterX-1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                xSource = connectAnalysisXA [counter3], ySource = connectAnalysisYA [counter3];
                                
                                if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrixA [ySource-1][xSource-1] == -150){
                                    rangeMatrixA [ySource-1][xSource-1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && rangeMatrixA [ySource-1][xSource] == -150){
                                    rangeMatrixA [ySource-1][xSource] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && xSource+1 < dimension2A && rangeMatrixA [ySource-1][xSource+1] == -150){
                                    rangeMatrixA [ySource-1][xSource+1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension2A && rangeMatrixA [ySource][xSource+1] == -150){
                                    rangeMatrixA [ySource][xSource+1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 > dimension2A && xSource+1 < dimension2A && rangeMatrixA [ySource+1][xSource+1] == -150){
                                    rangeMatrixA [ySource+1][xSource+1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension2A && rangeMatrixA [ySource+1][xSource] == -150){
                                    rangeMatrixA [ySource+1][xSource] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension2A && xSource-1 >= 0 && rangeMatrixA [ySource+1][xSource-1] == -150){
                                    rangeMatrixA [ySource+1][xSource-1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && rangeMatrixA [ySource][xSource-1] == -150){
                                    rangeMatrixA [ySource][xSource-1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                connectAnalysisXA [counter3] = connectAnalysisTempXA [counter3], connectAnalysisYA [counter3] = connectAnalysisTempYA [counter3];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //-----Determine number of pixels-----
        int *connectedPix = new int [connectivityNumberA+50];
        
        for (int counter3 = 0; counter3 <= connectivityNumberA; counter3++) connectedPix [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (rangeMatrixA [counterY][counterX] != 0) connectedPix [rangeMatrixA [counterY][counterX]]++;
            }
        }
        
        //-----Map up-date-----
        connectTemp = 1;
        
        for (int counter3 = 1; counter3 <= connectivityNumberA; counter3++){
            if (connectedPix [counter3] < 10) connectedPix [counter3] = 0;
            else{
                
                connectedPix [counter3] = connectTemp;
                connectTemp++;
            }
        }
        
        maxConnect = 0;
        maxConnectRevise = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A];
                    
                    if ((connectTemp = rangeMatrixA [counterY][counterX]) != 0) rangeMatrixA [counterY][counterX] = connectedPix [connectTemp];
                    else rangeMatrixA [counterY][counterX] = 0;
                    
                    if (rangeMatrixA [counterY][counterX] > maxConnect) maxConnect = rangeMatrixA [counterY][counterX];
                }
            }
        }
        
        delete [] connectedPix;
        
        int *findConnectNo = new int [maxConnect+5];
        for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo [counter3] = 0;
        
        if (maxConnectRevise+10 > findReviseConnectLimit){
            delete [] findReviseConnect;
            findReviseConnect = new int [maxConnectRevise+50];
            findReviseConnectLimit = maxConnectRevise+50;
        }
        
        for (int counter3 = 0; counter3 < maxConnectRevise+5; counter3++) findReviseConnect [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] == groupNoMerge){
                        if (rangeMatrixA [counterY][counterX] != 0) findConnectNo [rangeMatrixA [counterY][counterX]]++;
                    }
                }
            }
        }
        
        processConnectNo = 0;
        processConnectPosition = 0;
        
        for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
            if (findConnectNo [counter3] > processConnectNo){
                processConnectNo = findConnectNo [counter3];
                processConnectPosition = counter3;
            }
        }
        
        if (processConnectPosition != 0){
            freePixelFind = 0;
            
            for (int counterY = 0; counterY < dimension2A; counterY++){
                for (int counterX = 0; counterX < dimension2A; counterX++){
                    if (rangeMatrixA [counterY][counterX] == processConnectPosition){
                        if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                            if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] != 0){
                                findReviseConnect [revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A]]++;
                            }
                            
                            if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] == 0) freePixelFind = 1;
                        }
                    }
                }
            }
            
            //-----MapB-----
            connectivityNumberB = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (rangeMatrixB [counterY][counterX] == -150){
                        connectivityNumberB++;
                        rangeMatrixB [counterY][counterX] = connectivityNumberB;
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixB [counterY-1][counterX-1] == -150){
                            rangeMatrixB [counterY-1][counterX-1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && rangeMatrixB [counterY-1][counterX] == -150){
                            rangeMatrixB [counterY-1][counterX] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && counterX+1 < dimension2B && rangeMatrixB [counterY-1][counterX+1] == -150){
                            rangeMatrixB [counterY-1][counterX+1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension2B && rangeMatrixB [counterY][counterX+1] == -150){
                            rangeMatrixB [counterY][counterX+1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2B && counterX+1 < dimension2B && rangeMatrixB [counterY+1][counterX+1] == -150){
                            rangeMatrixB [counterY+1][counterX+1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2B && rangeMatrixB [counterY+1][counterX] == -150){
                            rangeMatrixB [counterY+1][counterX] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2B && counterX-1 >= 0 && rangeMatrixB [counterY+1][counterX-1] == -150){
                            rangeMatrixB [counterY+1][counterX-1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && rangeMatrixB [counterY][counterX-1] == -150){
                            rangeMatrixB [counterY][counterX-1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                    xSource = connectAnalysisXB [counter3], ySource = connectAnalysisYB [counter3];
                                    
                                    if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrixB [ySource-1][xSource-1] == -150){
                                        rangeMatrixB [ySource-1][xSource-1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && rangeMatrixB [ySource-1][xSource] == -150){
                                        rangeMatrixB [ySource-1][xSource] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && xSource+1 < dimension2B && rangeMatrixB [ySource-1][xSource+1] == -150){
                                        rangeMatrixB [ySource-1][xSource+1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension2B && rangeMatrixB [ySource][xSource+1] == -150){
                                        rangeMatrixB [ySource][xSource+1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 > dimension2B && xSource+1 < dimension2B && rangeMatrixB [ySource+1][xSource+1] == -150){
                                        rangeMatrixB [ySource+1][xSource+1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension2B && rangeMatrixB [ySource+1][xSource] == -150){
                                        rangeMatrixB [ySource+1][xSource] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension2B && xSource-1 >= 0 && rangeMatrixB [ySource+1][xSource-1] == -150){
                                        rangeMatrixB [ySource+1][xSource-1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && rangeMatrixB [ySource][xSource-1] == -150){
                                        rangeMatrixB [ySource][xSource-1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                    connectAnalysisXB [counter3] = connectAnalysisTempXB [counter3], connectAnalysisYB [counter3] = connectAnalysisTempYB [counter3];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //-----Determine number of pixels-----
            connectedPix = new int [connectivityNumberB+50];
            
            for (int counter3 = 0; counter3 <= connectivityNumberB; counter3++) connectedPix [counter3] = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (rangeMatrixB [counterY][counterX] != 0) connectedPix [rangeMatrixB [counterY][counterX]]++;
                }
            }
            
            //-----Map up-date-----
            connectTemp = 1;
            
            for (int counter3 = 1; counter3 <= connectivityNumberB; counter3++){
                if (connectedPix [counter3] < 10) connectedPix [counter3] = 0;
                else{
                    
                    connectedPix [counter3] = connectTemp;
                    connectTemp++;
                }
            }
            
            maxConnect = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                        if ((connectTemp = rangeMatrixB [counterY][counterX]) != 0) rangeMatrixB [counterY][counterX] = connectedPix [connectTemp];
                        else rangeMatrixB [counterY][counterX] = 0;
                        
                        if (rangeMatrixB [counterY][counterX] > maxConnect) maxConnect = rangeMatrixB [counterY][counterX];
                    }
                }
            }
            
            delete [] connectedPix;
            
            int *findConnectNo2 = new int [maxConnect+5];
            for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo2 [counter3] = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                        if (revisedWorkingMap [counterY+verticalStart2B][counterX+horizontalStart2B] == groupNoMerge){
                            if (rangeMatrixB [counterY][counterX] != 0) findConnectNo2 [rangeMatrixB [counterY][counterX]]++;
                        }
                    }
                }
            }
            
            processConnectNo = 0;
            processConnectPosition2 = 0;
            
            for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
                if (findConnectNo2 [counter3] > processConnectNo){
                    processConnectNo = findConnectNo2 [counter3];
                    processConnectPosition2 = counter3;
                }
            }
            
            if (processConnectPosition2 != 0){
                for (int counterY = 0; counterY < dimension2A; counterY++){
                    for (int counterX = 0; counterX < dimension2A; counterX++){
                        if ((counterY+verticalStart2A)-verticalStart2B >= 0 && (counterY+verticalStart2A)-verticalStart2B < dimension2B && (counterX+horizontalStart2A)-horizontalStart2B >= 0 && (counterX+horizontalStart2A)-horizontalStart2B < dimension2B){
                            rangeMatrixB [(counterY+verticalStart2A)-verticalStart2B][(counterX+horizontalStart2A)-horizontalStart2B] = 0;
                        }
                    }
                }
                
                findFlag = 0;
                
                for (int counterY = 0; counterY < dimension2B; counterY++){
                    for (int counterX = 0; counterX < dimension2B; counterX++){
                        if (rangeMatrixB [counterY][counterX] == processConnectPosition2){
                            findFlag = 1;
                            break;
                        }
                    }
                }
                
                if (findFlag == 0){
                    cutOffFinal = counter2;
                    
                    delete [] findConnectNo;
                    delete [] findConnectNo2;
                    break;
                }
            }
            else{
                
                if (counter2 != 20) cutOffFinal = counter2-10;
                else cutOffFinal = 0;
                
                delete [] findConnectNo;
                delete [] findConnectNo2;
                break;
            }
            
            delete [] findConnectNo2;
        }
        else{
            
            if (counter2 != 20) cutOffFinal = counter2-10;
            else cutOffFinal = 0;
            
            delete [] findConnectNo;
            break;
        }
        
        delete [] findConnectNo;
    }
    
    delete [] connectAnalysisXA;
    delete [] connectAnalysisYA;
    delete [] connectAnalysisTempXA;
    delete [] connectAnalysisTempYA;
    
    delete [] connectAnalysisXB;
    delete [] connectAnalysisYB;
    delete [] connectAnalysisTempXB;
    delete [] connectAnalysisTempYB;
    
    for (int counter2 = 0; counter2 < dimension2A+4; counter2++){
        delete [] rangeMatrixA [counter2];
    }
    
    delete [] rangeMatrixA;
    
    for (int counter2 = 0; counter2 < dimension2B+4; counter2++){
        delete [] rangeMatrixB [counter2];
    }
    
    delete [] rangeMatrixB;
    //-----BB
    
    if (cutOffFinal != 0 && freePixelFind == 1){
        int extendConnectCount = 0;
        
        for (int counter1 = 1; counter1 < maxConnectRevise+1; counter1++){
            if (findReviseConnect [counter1] != 0) extendConnectCount++;
        }
        
        int *extendConnectList = new int [extendConnectCount*2+4];
        extendConnectCount = 0;
        
        for (int counter1 = 1; counter1 < maxConnectRevise+1; counter1++){
            if (findReviseConnect [counter1] != 0){
                extendConnectList [extendConnectCount] = counter1, extendConnectCount++;
                extendConnectList [extendConnectCount] = 0, extendConnectCount++;
            }
        }
        
        int connectFind = 0;
        
        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
            connectFind = 0;
            
            for (int counter2 = 0; counter2 < extendConnectCount/2; counter2++){
                if (extendConnectList [counter2*2] == arrayTimeSelected [counter1*10+8]) connectFind = 1;
            }
            
            if (connectFind == 1){
                for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                    if (arrayPositionRevise [counter2*7+3] == arrayTimeSelected [counter1*10+8]){
                        if (maxPointDimX < arrayPositionRevise [counter2*7]) maxPointDimX = arrayPositionRevise [counter2*7];
                        if (minPointDimX > arrayPositionRevise [counter2*7]) minPointDimX = arrayPositionRevise [counter2*7];
                        if (maxPointDimY < arrayPositionRevise [counter2*7+1]) maxPointDimY = arrayPositionRevise [counter2*7+1];
                        if (minPointDimY > arrayPositionRevise [counter2*7+1]) minPointDimY = arrayPositionRevise [counter2*7+1];
                    }
                    else{
                        
                        break;
                    }
                }
            }
        }
        
        int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
        int verticalLength = (maxPointDimY-minPointDimY)/2*2;
        int dimension = 0;
        
        if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
        if (horizontalLength < verticalLength) dimension = verticalLength+30;
        
        dimension = (dimension/2)*2;
        
        int horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
        int verticalStart = minPointDimY-(dimension-verticalLength)/2;
        
        //=======CC
        int **rangeMatrix = new int *[dimension+4];
        
        for (int counter2 = 0; counter2 < dimension+4; counter2++){
            rangeMatrix [counter2] = new int [dimension+4];
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                    if (sourceImage [counterY+verticalStart][counterX+horizontalStart] == 100) rangeMatrix [counterY][counterX] = 0;
                    else if (sourceImage [counterY+verticalStart][counterX+horizontalStart] < cutOffFinal) rangeMatrix [counterY][counterX] = 0;
                    else rangeMatrix [counterY][counterX] = -150;
                }
                else rangeMatrix [counterY][counterX] = 0;
            }
        }
        
        int *connectAnalysisX = new int [dimension*4];
        int *connectAnalysisY = new int [dimension*4];
        int *connectAnalysisTempX = new int [dimension*4];
        int *connectAnalysisTempY = new int [dimension*4];
        
        int connectivityNumber = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (rangeMatrix [counterY][counterX] == -150){
                    connectivityNumber++;
                    rangeMatrix [counterY][counterX] = connectivityNumber;
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrix [counterY-1][counterX-1] == -150){
                        rangeMatrix [counterY-1][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && rangeMatrix [counterY-1][counterX] == -150){
                        rangeMatrix [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && counterX+1 < dimension && rangeMatrix [counterY-1][counterX+1] == -150){
                        rangeMatrix [counterY-1][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension && rangeMatrix [counterY][counterX+1] == -150){
                        rangeMatrix [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && counterX+1 < dimension && rangeMatrix [counterY+1][counterX+1] == -150){
                        rangeMatrix [counterY+1][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && rangeMatrix [counterY+1][counterX] == -150){
                        rangeMatrix [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && counterX-1 >= 0 && rangeMatrix [counterY+1][counterX-1] == -150){
                        rangeMatrix [counterY+1][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && rangeMatrix [counterY][counterX-1] == -150){
                        rangeMatrix [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                
                                if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrix [ySource-1][xSource-1] == -150){
                                    rangeMatrix [ySource-1][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && rangeMatrix [ySource-1][xSource] == -150){
                                    rangeMatrix [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && xSource+1 < dimension && rangeMatrix [ySource-1][xSource+1] == -150){
                                    rangeMatrix [ySource-1][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension && rangeMatrix [ySource][xSource+1] == -150){
                                    rangeMatrix [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 > dimension && xSource+1 < dimension && rangeMatrix [ySource+1][xSource+1] == -150){
                                    rangeMatrix [ySource+1][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && rangeMatrix [ySource+1][xSource] == -150){
                                    rangeMatrix [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && xSource-1 >= 0 && rangeMatrix [ySource+1][xSource-1] == -150){
                                    rangeMatrix [ySource+1][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && rangeMatrix [ySource][xSource-1] == -150){
                                    rangeMatrix [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //-----Determine number of pixels-----
        int *connectedPix = new int [connectivityNumber+50];
        
        for (int counter3 = 0; counter3 <= connectivityNumber; counter3++) connectedPix [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (rangeMatrix [counterY][counterX] != 0) connectedPix [rangeMatrix [counterY][counterX]]++;
            }
        }
        
        //-----Map up-date-----
        connectTemp = 1;
        
        for (int counter3 = 1; counter3 <= connectivityNumber; counter3++){
            if (connectedPix [counter3] < 10) connectedPix [counter3] = 0;
            else{
                
                connectedPix [counter3] = connectTemp;
                connectTemp++;
            }
        }
        
        maxConnect = 0;
        maxConnectRevise = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart];
                    
                    if ((connectTemp = rangeMatrix [counterY][counterX]) != 0) rangeMatrix [counterY][counterX] = connectedPix [connectTemp];
                    else rangeMatrix [counterY][counterX] = 0;
                    
                    if (rangeMatrix [counterY][counterX] > maxConnect) maxConnect = rangeMatrix [counterY][counterX];
                }
            }
        }
        
        delete [] connectedPix;
        
        int *findConnectNo = new int [maxConnect+5];
        for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo [counter3] = 0;
        
        if (maxConnectRevise+10 > findReviseConnectLimit){
            delete [] findReviseConnect;
            findReviseConnect = new int [maxConnectRevise+50];
        }
        
        for (int counter3 = 0; counter3 < maxConnectRevise+5; counter3++) findReviseConnect [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] == groupNoMerge){
                        if (rangeMatrix [counterY][counterX] != 0) findConnectNo [rangeMatrix [counterY][counterX]]++;
                    }
                }
            }
        }
        
        processConnectNo = 0;
        processConnectPosition = 0;
        
        for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
            if (findConnectNo [counter3] > processConnectNo){
                processConnectNo = findConnectNo [counter3];
                processConnectPosition = counter3;
            }
        }
        //========CC
        
        int **connectivityMapTemp = new int *[dimension+1];
        int **connectivityMapTemp2 = new int *[dimension+1];
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            connectivityMapTemp [counter1] = new int [dimension+1];
            connectivityMapTemp2 [counter1] = new int [dimension+1];
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = 0;
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (rangeMatrix [counterY][counterX] == processConnectPosition){
                    connectivityMapTemp [counterY][counterX] = -1;
                }
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
        //	cout<<" connectivityMapTemp "<<counterA<<endl;
        //}
        
        if (minPointDimY-30 >= 0) startY = minPointDimY-30;
        else startY = 0;
        
        if (maxPointDimY+30 < imageDimension) endY = maxPointDimY+31;
        else endY = imageDimension;
        
        if (minPointDimX-30 >= 0) startX = minPointDimX-30;
        else startX = 0;
        
        if (maxPointDimX+30 < imageDimension) endX = maxPointDimX+31;
        else endX = imageDimension;
        
        for (int counterY = startY; counterY < endY; counterY++){
            for (int counterX = startX; counterX < endX; counterX++){
                connectFind = 0;
                
                for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                    if (extendConnectList [counter1*2] == revisedWorkingMap [counterY][counterX]) connectFind = 1;
                }
                
                if (connectFind == 1){
                    if (counterY-verticalStart > 0 && counterY-verticalStart < dimension && counterX-horizontalStart > 0 && counterX-horizontalStart < dimension)
                        connectivityMapTemp [counterY-verticalStart][counterX-horizontalStart] = revisedWorkingMap [counterY][counterX];
                }
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
        //	cout<<" connectivityMapTemp "<<counterA<<endl;
        //}
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                connectivityMapTemp2 [counterY][counterX] = connectivityMapTemp [counterY][counterX];
            }
        }
        
        terminationFlag = 0;
        int startOrder = 0;
        int findFreePoint = 0;
        int connectNo = 0;
        int remainingCheck = 0;
        
        do{
            
            for (int counter1 = startOrder; counter1 < extendConnectCount/2; counter1++){
                connectNo = extendConnectList [counter1*2];
                
                if (extendConnectList [counter1*2+1] == 0){
                    findFreePoint = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp [counterY][counterX] == connectNo){
                                if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMapTemp [counterY-1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX+1 < dimension && connectivityMapTemp [counterY+1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                }
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                    }
                    
                    if (findFreePoint == 0) extendConnectList [counter1*2+1] = 1;
                }
            }
            
            for (int counter1 = 0; counter1 < startOrder; counter1++){
                connectNo = extendConnectList [counter1*2];
                
                if (extendConnectList [counter1*2+1] == 0){
                    findFreePoint = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp [counterY][counterX] == connectNo){
                                if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMapTemp [counterY-1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == processConnectPosition){
                                    connectivityMapTemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX+1 < dimension && connectivityMapTemp [counterY+1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                }
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                    }
                    
                    if (findFreePoint == 0) extendConnectList [counter1*2+1] = 1;
                }
            }
            
            remainingCheck = 0;
            
            for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                if (extendConnectList [counter1*2+1] == 0) remainingCheck = 1;
            }
            
            if (remainingCheck == 0) terminationFlag = 1;
            
            startOrder++;
            
            if (startOrder == extendConnectCount/2) startOrder = 0;
            
        } while (terminationFlag == 0);
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
        //    cout<<" connectivityMapTemp "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < extendConnectCount/2; counterA++){
        //    cout<<counterA<<" "<<extendConnectList [counterA*2]<<" "<<extendConnectList [counterA*2+1]<<" extendConnectList"<<endl;
        //}
        
        for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
            if (extendConnectList [counter1*2] == groupNoMerge){
                extendConnectList [counter1*2] = 0;
                break;
            }
        }
        
        extendConnectList [extendConnectCount] = groupNoMerge, extendConnectCount++;  //-----Move group to the end of list-----
        extendConnectList [extendConnectCount] = 0, extendConnectCount++;
        
        int largestConnect = 0;
        int largestConnectNo = 0;
        int xPositionTempStart = 0;
        int yPositionTempStart = 0;
        int lineSize = 0;
        int constructedLineCount = 0;
        int processType = 0;
        
        for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
            if (extendConnectList [counter1*2] != 0){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapTemp [counterY][counterX] == extendConnectList [counter1*2]) connectivityMapTemp2 [counterY][counterX] = 1;
                        else connectivityMapTemp2 [counterY][counterX] = 0;
                    }
                }
                
                //-----Connectivity analysis, For Zero-----
                
                connectivityNumber = -3;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapTemp2 [counterY][counterX] == 0){
                            connectivityNumber = connectivityNumber+2;
                            connectivityMapTemp2 [counterY][counterX] = connectivityNumber;
                            
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0){
                                connectivityMapTemp2 [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0){
                                connectivityMapTemp2 [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0){
                                connectivityMapTemp2 [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0){
                                connectivityMapTemp2 [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                        
                                        if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                            connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                            connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                            connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                            connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //-----Remove connectivity groups, which attach edge, extract inner part of Linked Line-----
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapTemp2 [counterY][counterX] == -1) connectivityMapTemp2 [counterY][counterX] = 0;
                    }
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapTemp2 [counterY][counterX] != 0){
                            if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                            else if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                            else if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                            else if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                        }
                    }
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapTemp2 [counterY][counterX] > 0) connectivityMapTemp2 [counterY][counterX] = 0;
                        if (connectivityMapTemp2 [counterY][counterX] < 0) connectivityMapTemp2 [counterY][counterX] = 1;
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
                //	cout<<" connectivityMapTemp2 "<<counterA<<endl;
                //}
                
                connectivityNumber = 0;
                
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                        if (connectivityMapTemp2 [counterY2][counterX2] == 0){
                            connectivityNumber--;
                            connectAnalysisCount = 0;
                            
                            connectivityMapTemp2 [counterY2][counterX2] = connectivityNumber;
                            
                            if (counterY2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2] == 0){
                                connectivityMapTemp2 [counterY2-1][counterX2] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                            }
                            if (counterX2+1 < dimension && connectivityMapTemp2 [counterY2][counterX2+1] == 0){
                                connectivityMapTemp2 [counterY2][counterX2+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                            }
                            if (counterY2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2] == 0){
                                connectivityMapTemp2 [counterY2+1][counterX2] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                            }
                            if (counterX2-1 >= 0 && connectivityMapTemp2 [counterY2][counterX2-1] == 0){
                                connectivityMapTemp2 [counterY2][counterX2-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                        
                                        if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                            connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                            connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                            connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                            connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
                //	cout<<" connectivityMapTemp2 "<<counterA<<endl;
                //}
                
                //-----Determine number of pixels-----
                connectivityNumber = connectivityNumber*-1;
                
                connectedPix = new int [connectivityNumber+50];
                
                for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPix [counter2] = 0;
                
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                        if (connectivityMapTemp2 [counterY2][counterX2] < -1){
                            connectedPix [connectivityMapTemp2 [counterY2][counterX2]*-1]++;
                        }
                    }
                }
                
                int **newConnectivityMapTemp = new int *[dimension+4];
                for (int counter2 = 0; counter2 < dimension+4; counter2++) newConnectivityMapTemp [counter2] = new int [dimension+4];
                
                for (int counterY = 0; counterY < dimension+4; counterY++){
                    for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
                }
                
                largestConnect = 0;
                largestConnectNo = 0;
                
                for (int counter2 = 2; counter2 <= connectivityNumber; counter2++){
                    if (connectedPix [counter2] > largestConnect){
                        largestConnect = connectedPix [counter2];
                        largestConnectNo = counter2;
                    }
                }
                
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                        if (connectivityMapTemp2 [counterY2][counterX2] == largestConnectNo*-1){
                            if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                                connectivityMapTemp2 [counterY2-1][counterX2-1] = 0;
                            }
                            if (counterY2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                                connectivityMapTemp2 [counterY2-1][counterX2] = 0;
                            }
                            if (counterY2-1 >= 0 && counterX2+1 < dimension && connectivityMapTemp2 [counterY2-1][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                                connectivityMapTemp2 [counterY2-1][counterX2+1] = 0;
                            }
                            if (counterX2+1 < dimension && connectivityMapTemp2 [counterY2][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                                connectivityMapTemp2 [counterY2][counterX2+1] = 0;
                            }
                            if (counterY2+1 < dimension && counterX2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                                connectivityMapTemp2 [counterY2+1][counterX2+1] = 0;
                            }
                            if (counterY2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                                connectivityMapTemp2 [counterY2+1][counterX2] = 0;
                            }
                            if (counterY2+1 < dimension && counterX2-1 >= 0 && connectivityMapTemp2 [counterY2+1][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                                connectivityMapTemp2 [counterY2+1][counterX2-1] = 0;
                            }
                            if (counterX2-1 >= 0 && connectivityMapTemp2 [counterY2][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                                connectivityMapTemp2 [counterY2][counterX2-1] = 0;
                            }
                        }
                    }
                }
                
                delete [] connectedPix;
                
                xPositionTempStart = 0;
                yPositionTempStart = 0;
                lineSize = 0;
                
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                        if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                            connectivityMapTemp2 [counterY2][counterX2] = 1;
                            
                            xPositionTempStart = counterX2;
                            yPositionTempStart = counterY2;
                            lineSize++;
                        }
                        else connectivityMapTemp2 [counterY2][counterX2] = 0;
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
                //	cout<<" connectivityMapTemp2 "<<counterA<<endl;
                //}
                
                for (int counter2 = 0; counter2 < dimension+4; counter2++) delete [] newConnectivityMapTemp [counter2];
                delete [] newConnectivityMapTemp;
                
                constructedLineCount = 0;
                
                int *arrayNewLines = new int [lineSize*2+50];
                
                connectivityMapTemp2 [yPositionTempStart][xPositionTempStart] = -1;
                arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                
                do{
                    
                    findFlag = 0;
                    terminationFlag = 0;
                    
                    if (xPositionTempStart+1 < dimension){
                        if (connectivityMapTemp2 [yPositionTempStart][xPositionTempStart+1] == 1){
                            connectivityMapTemp2 [yPositionTempStart][xPositionTempStart+1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    
                    if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                        if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                            connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    
                    if (yPositionTempStart+1 < dimension && findFlag == 0){
                        if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart] == 1){
                            connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                            yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    
                    if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                        if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                            connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    
                    if (xPositionTempStart-1 >= 0 && findFlag == 0){
                        if (connectivityMapTemp2 [yPositionTempStart][xPositionTempStart-1] == 1){
                            connectivityMapTemp2 [yPositionTempStart][xPositionTempStart-1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    
                    if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                        if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                            connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    
                    if (yPositionTempStart-1 >= 0 && findFlag == 0){
                        if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart] == 1){
                            connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                            yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    
                    if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                        if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                            connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                        }
                    }
                    
                } while (terminationFlag == 1);
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
                //	cout<<" connectivityMapTemp2 "<<counterA<<endl;
                //}
                
                referenceLineCount = 0;
                
                for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                    if (referenceLineCount+4 > referenceLineLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate referenceLineCountUpDate];
                    }
                    
                    arrayReferenceLine [referenceLineCount] = arrayNewLines [counter2*2], referenceLineCount++;
                    arrayReferenceLine [referenceLineCount] = arrayNewLines [counter2*2+1], referenceLineCount++;
                }
                
                delete [] arrayNewLines;
                
                if (counter1 == extendConnectCount/2-1){
                    processType = 2;
                    lineSet = [[LineSet alloc] init];
                    [lineSet lineSetProcess:processType];
                }
                else{
                    
                    processType = 3;
                    lineSet = [[LineSet alloc] init];
                    [lineSet lineSetProcess:processType];
                }
            }
        }
        
        delete [] connectAnalysisX;
        delete [] connectAnalysisY;
        delete [] connectAnalysisTempX;
        delete [] connectAnalysisTempY;
        
        delete [] extendConnectList;
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            delete [] connectivityMapTemp [counter1];
            delete [] connectivityMapTemp2 [counter1];
        }
        
        delete [] connectivityMapTemp;
        delete [] connectivityMapTemp2;
        
        for (int counter2 = 0; counter2 < dimension+4; counter2++){
            delete [] rangeMatrix [counter2];
        }
        
        delete [] rangeMatrix;
        
        delete [] findConnectNo;
    }
    
    delete [] findReviseConnect;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToTrackingWindow object:nil];
}

@end
