//
// AddDeleteAuto.h
// Cell_Tracking
//
// Created by Masahiko Sato on 14/01/27.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef ADDDELETEAUTO_H
#define ADDDELETEAUTO_H
#import "Controller.h" 
#endif

@interface AddDeleteAuto : NSObject {
    id fileUpdate;
}

-(int)delLineageMain:(int)connectNoDel :(int)processType :(int)delCellNo :(int)startPointSet;

@end
