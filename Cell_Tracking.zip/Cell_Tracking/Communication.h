//
// Communication.h
// Cell_Tracking
//
// Created by Masahiko Sato on 10/08/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef COMMUNICATION_H
#define COMMUNICATION_H
#import "Controller.h"
#endif

@interface Communication : NSObject {
    int autoProcessTimingCount; //Auto processing timing count
    int autoProcessTiming; //Auto processing timing
    int readingTrialCount; //Reading timing count
    
    NSTimer *communicationTimer;
    
    id trackRecordAuto;
    id addDeleteAuto;
    id fileUpdate;
    id dataSaveRead;
}

-(id)init;
-(void)dealloc;
-(void)communicationMain;
-(int)doneProcess;
-(void)timeEndRevise;

@end
