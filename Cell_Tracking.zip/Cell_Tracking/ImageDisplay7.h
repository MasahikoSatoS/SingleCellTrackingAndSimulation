//
//  ImageDisplay7.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2/2/17.
//
//

#ifndef IMAGEDISPLAY7_H
#define IMAGEDISPLAY7_H
#import "Controller.h" 
#endif

@interface ImageDisplay7 : NSView {
    IBOutlet NSImage *seqImage7;
    
    id merge;
    id lineSet;
    id dataSaveRead;
}

-(void)keyDown:(NSEvent *)event;
-(void)mouseDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
