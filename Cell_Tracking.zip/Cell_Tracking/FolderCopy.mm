//
//  FolderCopy.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 10/3/16.
//
//

#import "FolderCopy.h"

@implementation FolderCopy

-(void)folderCopyMain{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        mainSavingInProgress = 1;
        
        try{
            try{
                
                errorNoHold = 0;
                
                unsigned int incrementSizeCont;
                int errorCheckThrow = 0;
                
                if (queueRestartFlag == 7 || cleaningManualProgress == 4){
                    destinationAnalysisPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"TempTrack_TrackData";
                    sourceAnalysisPath = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData";
                    
                    destinationName = analysisID;
                }
                else if (restoreDataFlag == 4){
                    sourceAnalysisPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"TempTrack_TrackData";
                    destinationAnalysisPath = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData";
                    
                    destinationName = analysisID;
                }
                
                DIR *dir;
                struct dirent *dent;
                DIR *dir2;
                struct dirent *dent2;
                DIR *dir3;
                struct dirent *dent3;
                DIR *dir4;
                struct dirent *dent4;
                
                unsigned long folderSize = 0;
                
                NSArray *contents;
                NSEnumerator *enumerator;
                NSString *path;
                contents = [[NSFileManager defaultManager] subpathsAtPath:@(sourceAnalysisPath.c_str())];
                enumerator = [contents objectEnumerator];
                
                while (path = [enumerator nextObject]){
                    NSDictionary *fileAttributes = [[NSFileManager defaultManager] attributesOfItemAtPath:[@(sourceAnalysisPath.c_str()) stringByAppendingPathComponent:path] error:nil];
                    folderSize +=[fileAttributes fileSize];
                }
                
                string stringExtract;
                string sizeCheckPath = "";
                
                int findString2 = (int)destinationAnalysisPath.find("/Volumes");
                
                if (findString2 != -1){
                    stringExtract = destinationAnalysisPath.substr(8);
                    
                    if ((int)stringExtract.find("/") != -1){
                        stringExtract = stringExtract.substr(1);
                        stringExtract = stringExtract.substr(0, stringExtract.find("/"));
                        sizeCheckPath = "/Volumes/"+stringExtract+"/";
                    }
                }
                else sizeCheckPath = "/";
                
                NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(sizeCheckPath.c_str()) error:nil];
                unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
                unsigned long refSize = (unsigned long)2097152000+folderSize;
                
                if (freeSize > refSize){
                    incrementSizeCont = 0;
                    
                    progressValue = folderSize;
                    progressTiming = 1;
                    
                    do usleep(10);
                    while (progressTiming == 1);
                    
                    //-----Create destination folder-----
                    mkdir(destinationAnalysisPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    //-----Copy start-----
                    string entry;
                    string entry2;
                    string entry3;
                    string entry4;
                    string destAnalysisPath2;
                    string sourceAnalysisPath2;
                    string copyFilePath;
                    string destinationFilePath;
                    string destAnalysisPath3;
                    string sourceAnalysisPath3;
                    string destAnalysisPath4;
                    string sourceAnalysisPath4;
                    string frontTemp;
                    string behindTemp;
                    
                    int sourceNameLength = (int)analysisID.length();
                    int timeNumberTemp;
                    struct stat sizeOfFile;
                    
                    dir = opendir(sourceAnalysisPath.c_str());
                    
                    if (dir != NULL){
                        long sizeForCopy = 0;
                        int findString1 = 0;
                        int trackingBaseDataTempCount = 0;
                        
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                findString1 = (int)entry.find("_Connect");
                                
                                //-----Connect copy-----
                                if (findString1 != -1){
                                    destAnalysisPath2 = destinationAnalysisPath+"/"+entry;
                                    sourceAnalysisPath2 = sourceAnalysisPath+"/"+entry;
                                    
                                    //-----Create Connect folder-----
                                    mkdir(destAnalysisPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                    
                                    dir2 = opendir(sourceAnalysisPath2.c_str());
                                    
                                    if (dir2 != NULL){
                                        while ((dent2 = readdir(dir2))){
                                            entry2 = dent2 -> d_name;
                                            
                                            if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                                copyFilePath = sourceAnalysisPath2+"/"+entry2;
                                                
                                                if (destinationName != analysisID){
                                                    if (entry2.find(analysisID) == 0){
                                                        behindTemp = entry2.substr((unsigned long)sourceNameLength);
                                                        destinationFilePath = destAnalysisPath2+"/"+destinationName+behindTemp;
                                                    }
                                                    else{
                                                        
                                                        frontTemp = entry2.substr(0, 5);
                                                        behindTemp = entry2.substr(5+(unsigned long)sourceNameLength);
                                                        destinationFilePath = destAnalysisPath2+"/"+frontTemp+destinationName+behindTemp;
                                                    }
                                                }
                                                else destinationFilePath = destAnalysisPath2+"/"+entry2;
                                                
                                                timeNumberTemp = atoi(entry2.substr(0, 4).c_str());
                                                
                                                if (queueRestartFlag == 7){
                                                    if (arrayTimePointSaveList [timeNumberTemp] == 1 || (int)entry2.find("CutOffData") != -1 || (int)entry2.find("LineageData") != -1|| (int)entry2.find("LineageStartEnd") != -1|| (int)entry2.find("LineageStatus") != -1|| (int)entry2.find("MitosisData") != -1){
                                                        if (stat(copyFilePath.c_str(), &sizeOfFile) == 0){
                                                            sizeForCopy = sizeOfFile.st_size;
                                                            
                                                            ifstream infile (copyFilePath.c_str(), ifstream::binary);
                                                            ofstream outfile (destinationFilePath.c_str(), ofstream::binary);
                                                            
                                                            if (infile.is_open() && outfile.is_open()){
                                                                char* buffer = new char[sizeForCopy];
                                                                infile.read (buffer, sizeForCopy);
                                                                outfile.write (buffer, sizeForCopy);
                                                                delete[] buffer;
                                                                
                                                                outfile.close();
                                                                infile.close();
                                                                
                                                                incrementSizeCont = incrementSizeCont+(unsigned int)sizeForCopy;
                                                                
                                                                progressValue = incrementSizeCont;
                                                                progressTiming = 3;
                                                                
                                                                usleep(1000);
                                                            }
                                                            else{
                                                                
                                                                throw errorCheckThrow;
                                                            }
                                                        }
                                                    }
                                                }
                                                else{
                                                    
                                                    if (stat(copyFilePath.c_str(), &sizeOfFile) == 0){
                                                        sizeForCopy = sizeOfFile.st_size;
                                                        
                                                        ifstream infile (copyFilePath.c_str(), ifstream::binary);
                                                        ofstream outfile (destinationFilePath.c_str(), ofstream::binary);
                                                        
                                                        if (infile.is_open() && outfile.is_open()){
                                                            char* buffer = new char[sizeForCopy];
                                                            infile.read (buffer, sizeForCopy);
                                                            outfile.write (buffer, sizeForCopy);
                                                            delete[] buffer;
                                                            
                                                            outfile.close();
                                                            infile.close();
                                                            
                                                            incrementSizeCont = incrementSizeCont+(unsigned int)sizeForCopy;
                                                            
                                                            progressValue = incrementSizeCont;
                                                            progressTiming = 3;
                                                            
                                                            usleep(1000);
                                                        }
                                                        else{
                                                            
                                                            throw errorCheckThrow;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                        closedir (dir2);
                                    }
                                }
                                
                                if ((int)entry.find("_Treat") != -1){
                                    destAnalysisPath2 = destinationAnalysisPath+"/"+entry;
                                    sourceAnalysisPath2 = sourceAnalysisPath+"/"+entry;
                                    
                                    //-----Create Treat Folder-----
                                    mkdir(destAnalysisPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                    
                                    dir2 = opendir(sourceAnalysisPath2.c_str());
                                    
                                    if (dir2 != NULL){
                                        while ((dent2 = readdir(dir2))){
                                            entry2 = dent2 -> d_name;
                                            
                                            if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                                destAnalysisPath3 = destAnalysisPath2+"/"+entry2;
                                                sourceAnalysisPath3 = sourceAnalysisPath2+"/"+entry2;
                                                
                                                //-----Create Lineage Folder-----
                                                mkdir(destAnalysisPath3.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                                
                                                dir3 = opendir(sourceAnalysisPath3.c_str());
                                                
                                                if (dir3 != NULL){
                                                    while ((dent3 = readdir(dir3))){
                                                        entry3 = dent3 -> d_name;
                                                        
                                                        if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store"){
                                                            if ((int)entry3.find("C") != -1 && (int)entry3.find("CellStatus") == -1){
                                                                destAnalysisPath4 = destAnalysisPath3+"/"+entry3;
                                                                sourceAnalysisPath4 = sourceAnalysisPath3+"/"+entry3;
                                                                
                                                                //-----Create Cell Folder-----
                                                                mkdir(destAnalysisPath4.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                                                
                                                                dir4 = opendir(sourceAnalysisPath4.c_str());
                                                                
                                                                if (dir4 != NULL){
                                                                    while ((dent4 = readdir(dir4))){
                                                                        entry4 = dent4 -> d_name;
                                                                        
                                                                        if (entry4 != "." && entry4 != ".." && entry4 != ".DS_Store"){
                                                                            copyFilePath = sourceAnalysisPath4+"/"+entry4;
                                                                            
                                                                            if (destinationName != analysisID){
                                                                                if (entry4.find(analysisID) == 0){
                                                                                    behindTemp = entry4.substr((unsigned long)sourceNameLength);
                                                                                    destinationFilePath = destAnalysisPath4+"/"+destinationName+behindTemp;
                                                                                }
                                                                                else destinationFilePath = destAnalysisPath4+"/"+entry4;
                                                                            }
                                                                            else destinationFilePath = destAnalysisPath4+"/"+entry4;
                                                                            
                                                                            if (stat(copyFilePath.c_str(), &sizeOfFile) == 0){
                                                                                sizeForCopy = sizeOfFile.st_size;
                                                                                
                                                                                ifstream infile (copyFilePath.c_str(), ifstream::binary);
                                                                                ofstream outfile (destinationFilePath.c_str(), ofstream::binary);
                                                                                
                                                                                if (infile.is_open() && outfile.is_open()){
                                                                                    char* buffer = new char[sizeForCopy];
                                                                                    infile.read (buffer, sizeForCopy);
                                                                                    outfile.write (buffer, sizeForCopy);
                                                                                    delete[] buffer;
                                                                                    
                                                                                    outfile.close();
                                                                                    infile.close();
                                                                                    
                                                                                    incrementSizeCont = incrementSizeCont+(unsigned int)sizeForCopy;
                                                                                    
                                                                                    progressValue = incrementSizeCont;
                                                                                    progressTiming = 3;
                                                                                    
                                                                                    usleep(1000);
                                                                                }
                                                                                else{
                                                                                    
                                                                                    throw errorCheckThrow;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                    
                                                                    closedir (dir4);
                                                                }
                                                            }
                                                            
                                                            if ((int)entry3.find("C") != -1 && (int)entry3.find("CellStatus") != -1){
                                                                copyFilePath = sourceAnalysisPath3+"/"+entry3;
                                                                
                                                                if (destinationName != analysisID){
                                                                    if (entry3.find(analysisID) == 0){
                                                                        behindTemp = entry3.substr((unsigned long)sourceNameLength);
                                                                        destinationFilePath = destAnalysisPath3+"/"+destinationName+behindTemp;
                                                                    }
                                                                    else destinationFilePath = destAnalysisPath3+"/"+entry3;
                                                                }
                                                                else destinationFilePath = destAnalysisPath3+"/"+entry3;
                                                                
                                                                if (stat(copyFilePath.c_str(), &sizeOfFile) == 0){
                                                                    sizeForCopy = sizeOfFile.st_size;
                                                                    
                                                                    ifstream infile (copyFilePath.c_str(), ifstream::binary);
                                                                    ofstream outfile (destinationFilePath.c_str(), ofstream::binary);
                                                                    
                                                                    if (infile.is_open() && outfile.is_open()){
                                                                        char* buffer = new char[sizeForCopy];
                                                                        infile.read (buffer, sizeForCopy);
                                                                        outfile.write (buffer, sizeForCopy);
                                                                        delete[] buffer;
                                                                        
                                                                        outfile.close();
                                                                        infile.close();
                                                                        
                                                                        incrementSizeCont = incrementSizeCont+(unsigned int)sizeForCopy;
                                                                        
                                                                        progressValue = incrementSizeCont;
                                                                        progressTiming = 3;
                                                                        
                                                                        usleep(1000);
                                                                    }
                                                                    else{
                                                                        
                                                                        throw errorCheckThrow;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                    
                                                    closedir (dir3);
                                                }
                                            }
                                        }
                                        
                                        closedir (dir2);
                                    }
                                }
                                
                                if ((int)entry.find("dat") != -1 && (int)entry.find("TrackingSetting.dat") == -1){
                                    copyFilePath = sourceAnalysisPath+"/"+entry;
                                    destinationFilePath = destinationAnalysisPath+"/"+entry;
                                    
                                    if (stat(copyFilePath.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                        
                                        ifstream infile (copyFilePath.c_str(), ifstream::binary);
                                        ofstream outfile (destinationFilePath.c_str(), ofstream::binary);
                                        
                                        if (infile.is_open() && outfile.is_open()){
                                            char* buffer = new char[sizeForCopy];
                                            infile.read (buffer, sizeForCopy);
                                            outfile.write (buffer, sizeForCopy);
                                            delete[] buffer;
                                            
                                            outfile.close();
                                            infile.close();
                                            
                                            incrementSizeCont = incrementSizeCont+(unsigned int)sizeForCopy;
                                            
                                            progressValue = incrementSizeCont;
                                            progressTiming = 3;
                                            
                                            usleep(1000);
                                        }
                                        else{
                                            
                                            throw errorCheckThrow;
                                        }
                                    }
                                }
                                
                                if ((int)entry.find("TrackingSetting.dat") != -1){
                                    copyFilePath = sourceAnalysisPath+"/"+entry;
                                    destinationFilePath = destinationAnalysisPath+"/"+entry;
                                    
                                    string *trackingBaseDataTemp = new string [treatmentStatusCount+500];
                                    trackingBaseDataTempCount = 0;
                                    
                                    ifstream fin;
                                    
                                    string getString;
                                    
                                    fin.open(copyFilePath.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        
                                        for (int counter1 = 0; counter1 < 16; counter1++){
                                            getline(fin, getString);
                                            
                                            if (getString != "IFDATA"){
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                            }
                                            else{
                                                
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                break;
                                            }
                                        }
                                        
                                        for (int counter1 = 0; counter1 < 450; counter1 = counter1+15){
                                            getline(fin, getString);
                                            
                                            if (getString != "END"){
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                                getline(fin, getString);
                                                trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                            }
                                            else{
                                                
                                                break;
                                            }
                                        }
                                        
                                        fin.close();
                                    }
                                    else{
                                        
                                        throw errorCheckThrow;
                                    }
                                    
                                    trackingBaseDataTemp [1] = destinationName;
                                    
                                    ofstream oin;
                                    oin.open(destinationFilePath.c_str(), ios::out);
                                    
                                    for (int counter1 = 0; counter1 < trackingBaseDataTempCount; counter1++) oin<<trackingBaseDataTemp [counter1]<<endl;
                                    
                                    oin<<"END"<<endl;
                                    oin.close();
                                    
                                    delete [] trackingBaseDataTemp;
                                }
                            }
                        }
                        
                        closedir(dir);
                        
                        if (queueRestartFlag == 7){
                            for (int counter1 = 0; counter1 < timeEndHold+1; counter1++) arrayTimePointSaveList [counter1] = 0;
                            
                            queueRestartFlag = 8;
                        }
                        
                        if (restoreDataFlag == 4) restoreDataFlag = 5;
                        
                        if (cleaningManualProgress == 4) cleaningManualProgress = 5;
                        
                        if (queueRestartFlag == 0 && cleaningManualProgress == 0){
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    
                    progressTiming = 5;
                    
                    usleep(1000);
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                
                errorNoHold = 0;
            }
            catch (int errorCheckThrow){
                if (progressTiming != 0) progressTiming = 5;
                
                errorNoHold = 1;
            }
        }
        catch (bad_alloc&){
            if (progressTiming != 0) progressTiming = 5;
            
            errorNoHold = 1;
        }
        
        mainSavingInProgress = 0;
    });
}

-(void)folderDeleteMain{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        mainSavingInProgress = 1;
        
        string analysisIDPath;
        
        if (firstTrackStart == 2){
            analysisIDPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"TempTrack_TrackData";
        }
        else if (restoreDataFlag == 2){
            analysisIDPath = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData";
        }
        
        DIR *dir;
        struct dirent *dent;
        DIR *dir2;
        struct dirent *dent2;
        DIR *dir3;
        struct dirent *dent3;
        DIR *dir4;
        struct dirent *dent4;
        
        //-----Check whether source exist-----
        int proceedingFlag = 0;
        
        dir = opendir(analysisIDPath.c_str());
        
        if (dir != NULL){
            proceedingFlag = 1;
            closedir(dir);
        }
        else proceedingFlag = 0;
        
        if (proceedingFlag == 1){
            string entry;
            string entry2;
            string entry3;
            string entry4;
            string sourceAnalysisPath2;
            string sourceAnalysisPath3;
            string sourceAnalysisPath4;
            string sourceAnalysisPath5;
            
            dir = opendir(analysisIDPath.c_str());
            fileDeleteCount = 0;
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        sourceAnalysisPath2 = analysisIDPath+"/"+entry;
                        
                        dir2 = opendir(sourceAnalysisPath2.c_str());
                        
                        if (dir2 != NULL){
                            while ((dent2 = readdir(dir2))){
                                entry2 = dent2 -> d_name;
                                
                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                    sourceAnalysisPath3 = sourceAnalysisPath2+"/"+entry2;
                                    
                                    dir3 = opendir(sourceAnalysisPath3.c_str());
                                    
                                    if (dir3 != NULL){
                                        while ((dent3 = readdir(dir3))){
                                            entry3 = dent3 -> d_name;
                                            
                                            if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store"){
                                                sourceAnalysisPath4 = sourceAnalysisPath3+"/"+entry3;
                                                
                                                dir4 = opendir(sourceAnalysisPath4.c_str());
                                                
                                                if (dir4 != NULL){
                                                    while ((dent4 = readdir(dir4))){
                                                        entry4 = dent4 -> d_name;
                                                        
                                                        if (fileDeleteCount+5 > fileDeleteLimit){
                                                            self->fileUpdate = [[FileUpdate alloc] init];
                                                            [self->fileUpdate fileDeleteUpDate];
                                                        }
                                                        
                                                        arrayFileDelete [fileDeleteCount] = sourceAnalysisPath4+"/"+entry4, fileDeleteCount++;
                                                    }
                                                    
                                                    closedir(dir4);
                                                }
                                            }
                                        }
                                        
                                        closedir(dir3);
                                    }
                                }
                            }
                            
                            closedir(dir2);
                        }
                    }
                }
                
                closedir (dir);
                
                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                    remove (arrayFileDelete [counter1].c_str());
                }
            }
            
            dir = opendir(analysisIDPath.c_str());
            fileDeleteCount = 0;
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        sourceAnalysisPath2 = analysisIDPath+"/"+entry;
                        
                        dir2 = opendir(sourceAnalysisPath2.c_str());
                        
                        if (dir2 != NULL){
                            while ((dent2 = readdir(dir2))){
                                entry2 = dent2 -> d_name;
                                
                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                    sourceAnalysisPath3 = sourceAnalysisPath2+"/"+entry2;
                                    
                                    dir3 = opendir(sourceAnalysisPath3.c_str());
                                    
                                    if (dir3 != NULL){
                                        while ((dent3 = readdir(dir3))){
                                            entry3 = dent3 -> d_name;
                                            
                                            if (fileDeleteCount+5 > fileDeleteLimit){
                                                self->fileUpdate = [[FileUpdate alloc] init];
                                                [self->fileUpdate fileDeleteUpDate];
                                            }
                                            
                                            arrayFileDelete [fileDeleteCount] = sourceAnalysisPath3+"/"+entry3, fileDeleteCount++;
                                        }
                                        
                                        closedir(dir3);
                                    }
                                }
                            }
                            
                            closedir(dir2);
                        }
                    }
                }
                
                closedir (dir);
                
                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                    remove (arrayFileDelete [counter1].c_str());
                    rmdir (arrayFileDelete [counter1].c_str());
                }
            }
            
            dir = opendir(analysisIDPath.c_str());
            fileDeleteCount = 0;
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        sourceAnalysisPath2 = analysisIDPath+"/"+entry;
                        
                        dir2 = opendir(sourceAnalysisPath2.c_str());
                        
                        if (dir2 != NULL){
                            while ((dent2 = readdir(dir2))){
                                entry2 = dent2 -> d_name;
                                
                                if (fileDeleteCount+5 > fileDeleteLimit){
                                    self->fileUpdate = [[FileUpdate alloc] init];
                                    [self->fileUpdate fileDeleteUpDate];
                                }
                                
                                arrayFileDelete [fileDeleteCount] = sourceAnalysisPath2+"/"+entry2, fileDeleteCount++;
                            }
                            
                            closedir(dir2);
                        }
                    }
                }
                
                closedir (dir);
                
                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                    remove (arrayFileDelete [counter1].c_str());
                    rmdir (arrayFileDelete [counter1].c_str());
                }
            }
            
            fileDeleteCount = 0;
            
            dir = opendir(analysisIDPath.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (fileDeleteCount+5 > fileDeleteLimit){
                        self->fileUpdate = [[FileUpdate alloc] init];
                        [self->fileUpdate fileDeleteUpDate];
                    }
                    
                    arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                }
                
                closedir(dir);
                
                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                    sourceAnalysisPath2 = analysisIDPath+"/"+arrayFileDelete [counter1];
                    remove (sourceAnalysisPath2.c_str());
                    rmdir (sourceAnalysisPath2.c_str());
                }
                
                rmdir (sourceAnalysisPath.c_str());
            }
        }
        
        if (firstTrackStart == 2) firstTrackStart = 3;
        if (restoreDataFlag == 2) restoreDataFlag = 3;
        
        mainSavingInProgress = 0;
    });
}

@end
