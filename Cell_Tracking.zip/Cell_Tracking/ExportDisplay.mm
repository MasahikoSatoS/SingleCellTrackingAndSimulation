//
//  ExportDisplay.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2018-01-23.
//
//

#import "ExportDisplay.h"

NSString *notificationToExportDisplay = @"notificationExecutExportDisplay";

@implementation ExportDisplay

-(id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self != nil){
        exportImage = [[NSImage alloc] initWithContentsOfFile:@""];
        
        mouseDragFlag = 0;
        magnificationExport = 10;
        clickFlag = 0;
        displayModeSelect = 0;
        timingCount = 0;
        
        exportColorStatus = 0;
        imageNumberExportForDisplay = 0;
        colorNoExport = 0;
        channelNoOfExportImage = 0;
        motilityStatusHold = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToExportDisplay object:nil];
    }
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    ifstream fin;
    
    if (imageNumberTrackForDisplay > timeEndHold) imageNumberExportForDisplay = timeEndHold;
    else imageNumberExportForDisplay = imageNumberTrackForDisplay;
    
    string extension = to_string(imageNumberExportForDisplay);
    
    if (extension.length() == 1) extension = "000"+extension;
    else if (extension.length() == 2) extension = "00"+extension;
    else if (extension.length() == 3) extension = "0"+extension;
    
    string displayImageExportPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+exType;
    
    int totalSize = imageDimension*imageDimension*4;
    
    uint8_t *uploadTemp = new uint8_t [totalSize];
    fin.open(displayImageExportPath.c_str(), ios::in | ios::binary);
    
    if (fin.is_open()){
        if (exType == ".tif"){
            fin.read((char*)uploadTemp, totalSize+1);
            fin.close();
            
            int dataConversion [4];
            int endianType = 0;
            int value0 = 0;
            int value1 = 0;
            int value2 = 0;
            
            unsigned long headPosition = 0;
            
            dataConversion [0] = uploadTemp [0];
            dataConversion [1] = uploadTemp [1];
            
            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
            else endianType = 0;
            
            headPosition = 0;
            
            if (endianType == 1){
                dataConversion [0] = uploadTemp [7];
                dataConversion [1] = uploadTemp [6];
                dataConversion [2] = uploadTemp [5];
                dataConversion [3] = uploadTemp [4];
                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
            }
            else if (endianType == 0){
                dataConversion [0] = uploadTemp [4];
                dataConversion [1] = uploadTemp [5];
                dataConversion [2] = uploadTemp [6];
                dataConversion [3] = uploadTemp [7];
                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
            }
            
            if (tifImageColorGray == 0){
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                    *bitmapData++ = uploadTemp [counter1];
                }
                
                exportImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                [exportImage addRepresentation:bitmapReps];
            }
            else if (tifImageColorGray == 1){
                NSBitmapImageRep *bitmapReps = nil;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                    value0 = uploadTemp [counter1];
                    value1 = uploadTemp [counter1+1];
                    value2 = uploadTemp [counter1+2];
                    
                    *bitmapData++ = (unsigned char)value0;
                    *bitmapData++ = (unsigned char)value1;
                    *bitmapData++ = (unsigned char)value2;
                    *bitmapData++ = 0;
                }
                
                exportImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                [exportImage addRepresentation:bitmapReps];
            }
        }
        else if (exType == ".bmp"){
            fin.read((char*)uploadTemp, totalSize+1);
            fin.close();
            
            NSBitmapImageRep *bitmapReps;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
            
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                    *bitmapData++ = uploadTemp [1078+counter1*imageDimension+counter2];
                }
            }
            
            exportImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
            [exportImage addRepresentation:bitmapReps];
        }
    }
    
    delete [] uploadTemp;
    
    xPositionExport = xPositionTrack;
    yPositionExport = yPositionTrack;
    
    imageWidthExport = (int)([exportImage size].width);
    imageHeightExport = (int)([exportImage size].height);
    
    //-----Window size and Position re-adjust-----
    int vertical = 700+78;
    int horizontal = 700;
    
    windowWidthExport = imageWidthExport/(double)horizontal;
    windowHeightExport = imageHeightExport/(double)(vertical-78);
    
    motilityStatusHold = 0;
    
    [self setNeedsDisplay:YES];
    
    exportMainTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    if (timingCount == 1){
        if (startExport != 0 && endExport != 0 && startExport < endExport){
            imageNoCount = startExport;
        }
        else imageNoCount = 1;
        
        imageNoWrite = 1;
        timingCount = 2;
        timingEx = 1;
        
        if (thresholdStatusHold == 1){
            if (particleCountingDataHoldStatus == 1){
                delete [] particleCountingDataHold;
            }
            
            particleCountingDataHold = new int [imageEndHold*2+100];
            particleCountingDataHoldCount = 0;
            particleCountingDataHoldStatus = 1;
            
            for (int counter1 = 0; counter1 < imageEndHold*2+100; counter1++){
                particleCountingDataHold [counter1] = 0;
            }
        }
    }
    else if (timingCount == 2){
        timingCount = 3;
        colorNoExport = 0;
        channelNoOfExportImage = 0;
        
        if ((int)arrayFileDelete [imageNoCount-1].find("_") != -1){
            colorNoExport = atoi(arrayFileDelete [imageNoCount-1].substr(arrayFileDelete [imageNoCount-1].find("_")+1, 1).c_str());
        }
        
        int imageTime = atoi(arrayFileDelete [imageNoCount-1].substr(arrayFileDelete [imageNoCount-1].find("STimage ")+8, 4).c_str());
        
        if (ifStartHold != 0 && imageTime >= ifStartHold){
            int nextLoad = 0;
            
            for (int counter1 = 0; counter1 < 450; counter1 = counter1+15){
                if (atoi(arrayIFDataHold [counter1].c_str()) != 0 && atoi(arrayIFDataHold [counter1+14].c_str()) <= imageTime){
                    nextLoad = counter1/15+1;
                }
                else if (atoi(arrayIFDataHold [counter1].c_str()) == 0){
                    break;
                }
            }
            
            string fluorescentNameExport1 = "";
            string fluorescentNameExport2 = "";
            string fluorescentNameExport3 = "";
            string fluorescentNameExport4 = "";
            string fluorescentNameExport5 = "";
            string fluorescentNameExport6 = "";
            string fluorescentColorNoExport1 = "";
            string fluorescentColorNoExport2 = "";
            string fluorescentColorNoExport3 = "";
            string fluorescentColorNoExport4 = "";
            string fluorescentColorNoExport5 = "";
            string fluorescentColorNoExport6 = "";
            
            if (nextLoad > 0){
                nextLoad--;
                
                fluorescentColorNoExport1 = arrayIFDataHold [nextLoad*15+7];
                fluorescentNameExport1 = arrayIFDataHold [nextLoad*15+1];
                fluorescentColorNoExport2 = arrayIFDataHold [nextLoad*15+8];
                fluorescentNameExport2 = arrayIFDataHold [nextLoad*15+2];
                fluorescentColorNoExport3 = arrayIFDataHold [nextLoad*15+9];
                fluorescentNameExport3 = arrayIFDataHold [nextLoad*15+3];
                fluorescentColorNoExport4 = arrayIFDataHold [nextLoad*15+10];
                fluorescentNameExport4 = arrayIFDataHold [nextLoad*15+4];
                fluorescentColorNoExport5 = arrayIFDataHold [nextLoad*15+11];
                fluorescentNameExport5 = arrayIFDataHold [nextLoad*15+5];
                fluorescentColorNoExport6 = arrayIFDataHold [nextLoad*15+12];
                fluorescentNameExport6 = arrayIFDataHold [nextLoad*15+6];
            }
            
            if ((int)arrayFileDelete [imageNoCount-1].find (fluorescentNameExport1) != -1 && (int)arrayFileDelete [imageNoCount-1].find ("_"+fluorescentColorNoExport1+"_") != -1) channelNoOfExportImage = 1;
            else if ((int)arrayFileDelete [imageNoCount-1].find (fluorescentNameExport2) != -1 && (int)arrayFileDelete [imageNoCount-1].find ("_"+fluorescentColorNoExport2+"_") != -1) channelNoOfExportImage = 2;
            else if ((int)arrayFileDelete [imageNoCount-1].find (fluorescentNameExport3) != -1 && (int)arrayFileDelete [imageNoCount-1].find ("_"+fluorescentColorNoExport3+"_") != -1) channelNoOfExportImage = 3;
            else if ((int)arrayFileDelete [imageNoCount-1].find (fluorescentNameExport3) != -1 && (int)arrayFileDelete [imageNoCount-1].find ("_"+fluorescentColorNoExport4+"_") != -1) channelNoOfExportImage = 4;
            else if ((int)arrayFileDelete [imageNoCount-1].find (fluorescentNameExport3) != -1 && (int)arrayFileDelete [imageNoCount-1].find ("_"+fluorescentColorNoExport5+"_") != -1) channelNoOfExportImage = 5;
            else if ((int)arrayFileDelete [imageNoCount-1].find (fluorescentNameExport3) != -1 && (int)arrayFileDelete [imageNoCount-1].find ("_"+fluorescentColorNoExport6+"_") != -1) channelNoOfExportImage = 6;
        }
        else{
            
            string fluorescentNameExport1 = "";
            string fluorescentNameExport2 = "";
            string fluorescentNameExport3 = "";
            string fluorescentNameExport4 = "";
            string fluorescentNameExport5 = "";
            string fluorescentNameExport6 = "";
            string fluorescentColorNoExport1 = "";
            string fluorescentColorNoExport2 = "";
            string fluorescentColorNoExport3 = "";
            string fluorescentColorNoExport4 = "";
            string fluorescentColorNoExport5 = "";
            string fluorescentColorNoExport6 = "";
            
            fluorescentNameExport1 = fluorescentName1;
            fluorescentNameExport2 = fluorescentName2;
            fluorescentNameExport3 = fluorescentName3;
            fluorescentNameExport4 = fluorescentName4;
            fluorescentNameExport5 = fluorescentName5;
            fluorescentNameExport6 = fluorescentName6;
            
            fluorescentColorNoExport1 = to_string(fluorescentNo1);
            fluorescentColorNoExport2 = to_string(fluorescentNo2);
            fluorescentColorNoExport3 = to_string(fluorescentNo3);
            fluorescentColorNoExport4 = to_string(fluorescentNo4);
            fluorescentColorNoExport5 = to_string(fluorescentNo5);
            fluorescentColorNoExport6 = to_string(fluorescentNo6);
            
            if ((int)arrayFileDelete [imageNoCount-1].find (fluorescentNameExport1) != -1 && (int)arrayFileDelete [imageNoCount-1].find ("_"+fluorescentColorNoExport1+"_") != -1) channelNoOfExportImage = 1;
            else if ((int)arrayFileDelete [imageNoCount-1].find (fluorescentNameExport2) != -1 && (int)arrayFileDelete [imageNoCount-1].find ("_"+fluorescentColorNoExport2+"_") != -1) channelNoOfExportImage = 2;
            else if ((int)arrayFileDelete [imageNoCount-1].find (fluorescentNameExport3) != -1 && (int)arrayFileDelete [imageNoCount-1].find ("_"+fluorescentColorNoExport3+"_") != -1) channelNoOfExportImage = 3;
            else if ((int)arrayFileDelete [imageNoCount-1].find (fluorescentNameExport4) != -1 && (int)arrayFileDelete [imageNoCount-1].find ("_"+fluorescentColorNoExport4+"_") != -1) channelNoOfExportImage = 4;
            else if ((int)arrayFileDelete [imageNoCount-1].find (fluorescentNameExport5) != -1 && (int)arrayFileDelete [imageNoCount-1].find ("_"+fluorescentColorNoExport5+"_") != -1) channelNoOfExportImage = 5;
            else if ((int)arrayFileDelete [imageNoCount-1].find (fluorescentNameExport6) != -1 && (int)arrayFileDelete [imageNoCount-1].find ("_"+fluorescentColorNoExport6+"_") != -1) channelNoOfExportImage = 6;
        }
        
        displayImageLoadPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+arrayFileDelete [imageNoCount-1];
        
        string extension = to_string(imageNoCount);
        
        if (extension.length() == 1) extension = "000"+extension;
        else if (extension.length() == 2) extension = "00"+extension;
        else if (extension.length() == 3) extension = "0"+extension;
        
        pathExtension = extension;
        displayImageSavePath = displayImageAllPath+"/Export_Images-EI"+to_string(imageNoWrite)+".tif";
        
        timingCount = 4;
    }
    else if (timingCount == 4){
        [self setNeedsDisplay:YES];
        
        timingCount = 5;
    }
    else if (timingCount == 5){
        if (displayModeSelect == 8){
            imageNoCount++;
            imageNoWrite++;
            
            if (imageNoCount > fileDeleteCount || (endExport != 0 && imageNoCount > endExport)){
                if (thresholdStatusHold == 1){
                    string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
                    mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Export_Images";
                    mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    string nameString = "Export_Images-TH";
                    
                    DIR *dir;
                    struct dirent *dent;
                    
                    string entry;
                    string extractString;
                    int maxEntryNo = 0;
                    
                    dir = opendir(resultSavePath2.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(nameString) != -1){
                                extractString = entry.substr(entry.find("TH")+2);
                                
                                if ((int)extractString.find(".txt") == -1) extractString = extractString.substr(0, entry.find(".txt"));
                                
                                if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    maxEntryNo++;
                    
                    string exportCellAreaSavePath = resultSavePath2+"/"+nameString+to_string(maxEntryNo)+".txt";
                    
                    ofstream oin;
                    oin.open(exportCellAreaSavePath.c_str(), ios::out);
                    
                    int *arrayAscIIintData = new int [100];
                    int ascIIintDataCount = 0;
                    
                    ascIIconversion = [[ASCIIconversion alloc] init];
                    
                    ascIIstring = "Image No";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = "No of Particles";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(13);
                    oin.put(10);
                    
                    for (int counter1 = 0; counter1 < particleCountingDataHoldCount/2; counter1++){
                        ascIIstring = to_string(particleCountingDataHold [counter1*2]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        ascIIstring = to_string(particleCountingDataHold [counter1*2+1]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        oin.put(13);
                        oin.put(10);
                    }
                    
                    oin.close();
                    
                    delete [] arrayAscIIintData;
                }
                
                imageNoWrite = 0;
                timingCount = 0;
                displayModeSelect = 0;
                timingEx = 3;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                displayModeSelect = 7;
                timingCount = 2;
            }
        }
    }
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)mouseDown:(NSEvent *)event{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        
        double xPositionAdjustDouble = xPositionAdjustExport+xPositionExport;
        double yPositionAdjustDouble = yPositionAdjustExport+yPositionExport;
        double xCalculationValue = 1/(double)windowWidthExport*magnificationExport*0.1;
        double yCalculationValue = 1/(double)windowHeightExport*magnificationExport*0.1;
        
        int xPointMarkTemp = (int)(clickPoint.x/(double)xCalculationValue+xPositionAdjustDouble);
        int yPointMarkTemp = (int)((clickPoint.y/(double)yCalculationValue+yPositionAdjustDouble-imageHeightExport)*-1);
        
        xPositionExHold = xPointMarkTemp;
        yPositionExHold = yPointMarkTemp;
        
        xyPositionCall = 1;
        
        if (windowLockEX == 0){
            xPointDownExport = clickPoint.x;
            yPointDownExport = clickPoint.y;
        }
        else if (windowLockEX == 1){
            boxStartX = clickPoint.x;
            boxStartY = clickPoint.y;
            boxEndX = clickPoint.x;
            boxEndY = clickPoint.y;
            
            boxStartImageX = xPointMarkTemp;
            boxStartImageY = yPointMarkTemp;
            boxEndImageX = xPointMarkTemp;
            boxEndImageY = yPointMarkTemp;
        }
        
        clickFlag = 0;
        
        if (clickPoint.x > 620 && clickPoint.x < 680 && clickPoint.y > 680 && clickPoint.y < 694){
            clickFlag = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (clickPoint.x > 550 && clickPoint.x < 610 && clickPoint.y > 680 && clickPoint.y < 694){
            if (exportColorStatus == 0) exportColorStatus = 1;
            else if (exportColorStatus == 1) exportColorStatus = 2;
            else if (exportColorStatus == 2) exportColorStatus = 0;
            
            clickFlag = 2;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            [self setNeedsDisplay:YES];
        }
        
        if (clickFlag >= 1){
            if (imageNumberTrackForDisplay == 0) imageNumberExportForDisplay = 1;
            
            string extension = to_string(imageNumberExportForDisplay);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            string connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
            
            struct stat sizeOfFile;
            long sizeForCopy = 0;
            long size1 = 0;
            long size2 = 0;
            int checkFlag = 0;
            int readingError = 0;
            
            for (int counter4 = 0; counter4 < 6; counter4++){
                sizeForCopy = 0;
                
                if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter4 == 0) size1 = sizeForCopy;
                    else if (counter4 == 1) size2 = sizeForCopy;
                    else if (counter4 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter4 == 3) size1 = sizeForCopy;
                    else if (counter4 == 4) size2 = sizeForCopy;
                    else if (counter4 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            ifstream fin;
            
            if (checkFlag == 1){
                if (positionExportStatus == 1) delete [] arrayPositionExport;
                arrayPositionExport = new int [sizeForCopy+50];
                positionExportCount = 0;
                positionExportStatus = 1;
                
                if (gravityCenterExportStatus == 1) delete [] arrayGravityCenterExport;
                arrayGravityCenterExport = new int [sizeForCopy+50];
                gravityCenterExportCount = 0;
                gravityCenterExportStatus = 1;
                
                fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    int finData [17];
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--5
                                finData [13] = uploadTemp [readPosition], readPosition++; //--6
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++;
                                finData [16] = uploadTemp [readPosition], readPosition++; //--7
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                else{
                                    
                                    arrayPositionExport [positionExportCount] = finData [1], positionExportCount++;
                                    arrayPositionExport [positionExportCount] = finData [3], positionExportCount++;
                                    arrayPositionExport [positionExportCount] = finData [4], positionExportCount++;
                                    arrayPositionExport [positionExportCount] = finData [7], positionExportCount++;
                                    arrayPositionExport [positionExportCount] = finData [12], positionExportCount++;
                                    arrayPositionExport [positionExportCount] = finData [13], positionExportCount++;
                                    arrayPositionExport [positionExportCount] = finData [16], positionExportCount++;
                                }
                            }
                            else if (stepCount == 1){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                finData [9] = finData [8]*256+finData [9];
                                
                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                            }
                            else if (stepCount == 2){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                else{
                                    
                                    arrayGravityCenterExport [gravityCenterExportCount] = finData [1], gravityCenterExportCount++;
                                    arrayGravityCenterExport [gravityCenterExportCount] = finData [3], gravityCenterExportCount++;
                                    arrayGravityCenterExport [gravityCenterExportCount] = finData [6], gravityCenterExportCount++;
                                    arrayGravityCenterExport [gravityCenterExportCount] = finData [7], gravityCenterExportCount++;
                                    arrayGravityCenterExport [gravityCenterExportCount] = finData [10], gravityCenterExportCount++;
                                    arrayGravityCenterExport [gravityCenterExportCount] = finData [11], gravityCenterExportCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                }
            }
            
            if (checkFlag == 1 || readingError == 0){
                //-----Master Data Status UpLoad-----
                string connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
                
                sizeForCopy = 0;
                
                if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (timeSelectedExportStatus == 1) delete [] arrayTimeSelectedExport;
                arrayTimeSelectedExport = new int [sizeForCopy+50];
                timeSelectedExportCount = 0;
                timeSelectedExportStatus = 1;
                
                if (sizeForCopy != 0){
                    fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        int finData [19];
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                                finData [7] = uploadTemp [readPosition], readPosition++;
                                finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                                finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                                finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                                finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                                finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                                finData [13] = uploadTemp [readPosition], readPosition++;
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                                finData [16] = uploadTemp [readPosition], readPosition++;
                                finData [17] = uploadTemp [readPosition], readPosition++;
                                finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                                
                                finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [8] = finData [7]*256+finData [8];
                                finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                                finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                                
                                if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                                else{
                                    
                                    arrayTimeSelectedExport [timeSelectedExportCount] = finData [0], timeSelectedExportCount++; //-----Selected, removed, eliminated status-----
                                    arrayTimeSelectedExport [timeSelectedExportCount] = finData [3], timeSelectedExportCount++; //-----When new line is created, enter line number which creates-----
                                    arrayTimeSelectedExport [timeSelectedExportCount] = finData [6], timeSelectedExportCount++; //-----PositionRevise Start-----
                                    arrayTimeSelectedExport [timeSelectedExportCount] = finData [8], timeSelectedExportCount++; //-----
                                    arrayTimeSelectedExport [timeSelectedExportCount] = finData [9], timeSelectedExportCount++; //-----R-----
                                    arrayTimeSelectedExport [timeSelectedExportCount] = finData [10], timeSelectedExportCount++; //-----G-----
                                    arrayTimeSelectedExport [timeSelectedExportCount] = finData [11], timeSelectedExportCount++; //-----B-----
                                    arrayTimeSelectedExport [timeSelectedExportCount] = finData [12], timeSelectedExportCount++; //-----
                                    arrayTimeSelectedExport [timeSelectedExportCount] = finData [15], timeSelectedExportCount++; //-----Connect-----
                                    arrayTimeSelectedExport [timeSelectedExportCount] = finData [18], timeSelectedExportCount++; //-----Lineage-----
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                    }
                }
                
                int fluorescentColorNoHold = 0;
                int fileFindCheck = 0;
                string fluorescentPath;
                
                if (ifStartHold != 0 && imageNumberExportForDisplay >= ifStartHold){
                    int nextLoad = 0;
                    
                    for (int counter1 = 0; counter1 < 450; counter1 = counter1+15){
                        if (atoi(arrayIFDataHold [counter1].c_str()) != 0 && atoi(arrayIFDataHold [counter1+14].c_str()) <= imageNumberExportForDisplay){
                            nextLoad = counter1/15+1;
                        }
                        else if (atoi(arrayIFDataHold [counter1].c_str()) == 0){
                            break;
                        }
                    }
                    
                    string fluorescentNameExport1 = "";
                    string fluorescentNameExport2 = "";
                    string fluorescentNameExport3 = "";
                    string fluorescentNameExport4 = "";
                    string fluorescentNameExport5 = "";
                    string fluorescentNameExport6 = "";
                    string fluorescentRoundNoExport = "";
                    
                    if (nextLoad > 0){
                        nextLoad--;
                        
                        fluorescentRoundNoExport = arrayIFDataHold [nextLoad*15];
                        
                        if (channelNoExport == 1){
                            fluorescentColorNoHold = atoi(arrayIFDataHold [nextLoad*15+7].c_str());
                            fluorescentNameExport1 = arrayIFDataHold [nextLoad*15+1];
                        }
                        if (channelNoExport == 2){
                            fluorescentColorNoHold = atoi(arrayIFDataHold [nextLoad*15+8].c_str());
                            fluorescentNameExport2 = arrayIFDataHold [nextLoad*15+2];
                        }
                        if (channelNoExport == 3){
                            fluorescentColorNoHold = atoi(arrayIFDataHold [nextLoad*15+9].c_str());
                            fluorescentNameExport3 = arrayIFDataHold [nextLoad*15+3];
                        }
                        if (channelNoExport == 4){
                            fluorescentColorNoHold = atoi(arrayIFDataHold [nextLoad*15+10].c_str());
                            fluorescentNameExport4 = arrayIFDataHold [nextLoad*15+4];
                        }
                        if (channelNoExport == 5){
                            fluorescentColorNoHold = atoi(arrayIFDataHold [nextLoad*15+11].c_str());
                            fluorescentNameExport5 = arrayIFDataHold [nextLoad*15+5];
                        }
                        if (channelNoExport == 6){
                            fluorescentColorNoHold = atoi(arrayIFDataHold [nextLoad*15+12].c_str());
                            fluorescentNameExport6 = arrayIFDataHold [nextLoad*15+6];
                        }
                    }
                    
                    string extension2 = to_string(fluorescentColorNoHold);
                    
                    if (channelNoExport == 1){
                        fluorescentPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport1+exTypeIF+fluorescentRoundNoExport;
                    }
                    else if (channelNoExport == 2){
                        fluorescentPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport2+exTypeIF+fluorescentRoundNoExport;
                    }
                    else if (channelNoExport == 3){
                        fluorescentPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport3+exTypeIF+fluorescentRoundNoExport;
                    }
                    else if (channelNoExport == 4){
                        fluorescentPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport4+exTypeIF+fluorescentRoundNoExport;
                    }
                    else if (channelNoExport == 5){
                        fluorescentPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport5+exTypeIF+fluorescentRoundNoExport;
                    }
                    else if (channelNoExport == 6){
                        fluorescentPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport6+exTypeIF+fluorescentRoundNoExport;
                    }
                    else if (channelNoExport == 0){
                        fluorescentPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+exTypeIF+fluorescentRoundNoExport;
                    }
                    
                    if (stat(fluorescentPath.c_str(), &sizeOfFile) == 0){
                        fileFindCheck = 1;
                    }
                    
                    if (fileFindCheck == 0){
                        fluorescentPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+exTypeIF+fluorescentRoundNoExport;
                    }
                }
                else{
                    
                    string fluorescentNameExport1 = "";
                    string fluorescentNameExport2 = "";
                    string fluorescentNameExport3 = "";
                    string fluorescentNameExport4 = "";
                    string fluorescentNameExport5 = "";
                    string fluorescentNameExport6 = "";
                    
                    int fluorescentNoExport1 = 0;
                    int fluorescentNoExport2 = 0;
                    int fluorescentNoExport3 = 0;
                    int fluorescentNoExport4 = 0;
                    int fluorescentNoExport5 = 0;
                    int fluorescentNoExport6 = 0;
                    
                    fluorescentNameExport1 = fluorescentName1;
                    fluorescentNameExport2 = fluorescentName2;
                    fluorescentNameExport3 = fluorescentName3;
                    fluorescentNameExport4 = fluorescentName4;
                    fluorescentNameExport5 = fluorescentName5;
                    fluorescentNameExport6 = fluorescentName6;
                    
                    fluorescentNoExport1 = fluorescentNo1;
                    fluorescentNoExport2 = fluorescentNo2;
                    fluorescentNoExport3 = fluorescentNo3;
                    fluorescentNoExport4 = fluorescentNo4;
                    fluorescentNoExport5 = fluorescentNo5;
                    fluorescentNoExport6 = fluorescentNo6;
                    
                    if (channelNoExport == 1){
                        string extension2 = to_string(fluorescentNoExport1);
                        fluorescentPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport1+exType;
                    }
                    else if (channelNoExport == 2){
                        string extension2 = to_string(fluorescentNoExport2);
                        fluorescentPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport2+exType;
                    }
                    else if (channelNoExport == 3){
                        string extension2 = to_string(fluorescentNoExport3);
                        fluorescentPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport3+exType;
                    }
                    else if (channelNoExport == 4){
                        string extension2 = to_string(fluorescentNoExport4);
                        fluorescentPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport4+exType;
                    }
                    else if (channelNoExport == 5){
                        string extension2 = to_string(fluorescentNoExport5);
                        fluorescentPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport5+exType;
                    }
                    else if (channelNoExport == 6){
                        string extension2 = to_string(fluorescentNoExport6);
                        fluorescentPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport6+exType;
                    }
                    else if (channelNoExport == 0){
                        string extension2 = to_string(fluorescentNoExport3);
                        fluorescentPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+exType;
                    }
                    
                    if (stat(fluorescentPath.c_str(), &sizeOfFile) == 0){
                        fileFindCheck = 1;
                    }
                    
                    if (fileFindCheck == 0){
                        fluorescentPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+exType;
                    }
                }
                
                int totalSize = imageDimension*imageDimension*4;
                
                if (channelNoExport == 0 || fileFindCheck == 0){
                    uint8_t *uploadTemp = new uint8_t [totalSize+1];
                    fin.open(fluorescentPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        if (exType == ".tif" || exTypeIF == ".TIF"){
                            fin.read((char*)uploadTemp, totalSize+1);
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            
                            unsigned long headPosition = 0;
                            
                            dataConversion [0] = uploadTemp [0];
                            dataConversion [1] = uploadTemp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTemp [7];
                                dataConversion [1] = uploadTemp [6];
                                dataConversion [2] = uploadTemp [5];
                                dataConversion [3] = uploadTemp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTemp [4];
                                dataConversion [1] = uploadTemp [5];
                                dataConversion [2] = uploadTemp [6];
                                dataConversion [3] = uploadTemp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (tifImageColorGray == 0){
                                NSBitmapImageRep *bitmapReps;
                                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                                
                                unsigned char *bitmapData = [bitmapReps bitmapData];
                                
                                for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                    *bitmapData++ = uploadTemp [counter1];
                                }
                                
                                exportImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                [exportImage addRepresentation:bitmapReps];
                            }
                            else if (tifImageColorGray == 1){
                                NSBitmapImageRep *bitmapReps = nil;
                                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                                
                                unsigned char *bitmapData = [bitmapReps bitmapData];
                                
                                for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                    value0 = uploadTemp [counter1];
                                    value1 = uploadTemp [counter1+1];
                                    value2 = uploadTemp [counter1+2];
                                    
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = (unsigned char)value1;
                                    *bitmapData++ = (unsigned char)value2;
                                    *bitmapData++ = 0;
                                }
                                
                                exportImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                [exportImage addRepresentation:bitmapReps];
                            }
                        }
                        else if (exType == ".bmp" || exTypeIF == ".BMP"){
                            fin.read((char*)uploadTemp, totalSize+1);
                            fin.close();
                            
                            NSBitmapImageRep *bitmapReps;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                    *bitmapData++ = uploadTemp [1078+counter1*imageDimension+counter2];
                                }
                            }
                            
                            exportImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [exportImage addRepresentation:bitmapReps];
                        }
                    }
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    int fluorescentCutOffExport1 = 150;
                    int fluorescentCutOffExport2 = 150;
                    int fluorescentCutOffExport3 = 150;
                    int fluorescentCutOffExport4 = 150;
                    int fluorescentCutOffExport5 = 150;
                    int fluorescentCutOffExport6 = 150;
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                        if (arrayFluorescentCutOff [counter1*7] == imageNumberExportForDisplay){
                            fluorescentCutOffExport1 = arrayFluorescentCutOff [counter1*7+1];
                            fluorescentCutOffExport2 = arrayFluorescentCutOff [counter1*7+2];
                            fluorescentCutOffExport3 = arrayFluorescentCutOff [counter1*7+3];
                            fluorescentCutOffExport4 = arrayFluorescentCutOff [counter1*7+4];
                            fluorescentCutOffExport5 = arrayFluorescentCutOff [counter1*7+5];
                            fluorescentCutOffExport6 = arrayFluorescentCutOff [counter1*7+6];
                            break;
                        }
                    }
                    
                    uint8_t *uploadTemp = new uint8_t [totalSize+1];
                    fin.open(fluorescentPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        if (exType == ".tif" || exTypeIF == ".TIF"){
                            fin.read((char*)uploadTemp, totalSize+1);
                            fin.close();
                            
                            int dataConversion [4];
                            int endianType = 0;
                            int value0 = 0;
                            int value1 = 0;
                            int value2 = 0;
                            
                            unsigned long headPosition = 0;
                            
                            dataConversion [0] = uploadTemp [0];
                            dataConversion [1] = uploadTemp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTemp [7];
                                dataConversion [1] = uploadTemp [6];
                                dataConversion [2] = uploadTemp [5];
                                dataConversion [3] = uploadTemp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTemp [4];
                                dataConversion [1] = uploadTemp [5];
                                dataConversion [2] = uploadTemp [6];
                                dataConversion [3] = uploadTemp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (tifImageColorGray == 0){
                                NSBitmapImageRep *bitmapReps = nil;
                                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                                
                                unsigned char *bitmapData = [bitmapReps bitmapData];
                                
                                int readDataTemp = 0;
                                
                                for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                    readDataTemp = uploadTemp [counter1];
                                    
                                    if (channelNoExport == 1 && readDataTemp < fluorescentCutOffExport1) readDataTemp = 0;
                                    else if (channelNoExport == 2 && readDataTemp < fluorescentCutOffExport2) readDataTemp = 0;
                                    else if (channelNoExport == 3 && readDataTemp < fluorescentCutOffExport3) readDataTemp = 0;
                                    else if (channelNoExport == 4 && readDataTemp < fluorescentCutOffExport4) readDataTemp = 0;
                                    else if (channelNoExport == 5 && readDataTemp < fluorescentCutOffExport5) readDataTemp = 0;
                                    else if (channelNoExport == 6 && readDataTemp < fluorescentCutOffExport6) readDataTemp = 0;
                                    
                                    if (fluorescentColorNoHold == 1){
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 2){
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 3){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 4){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 5){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 6){
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 7){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.674));
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 8){
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.627));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.125));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.941));
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 9){
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.529));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.808));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.922));
                                        *bitmapData++ = 0;
                                    }
                                }
                                
                                exportImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                [exportImage addRepresentation:bitmapReps];
                            }
                            else if (tifImageColorGray == 1){
                                NSBitmapImageRep *bitmapReps = nil;
                                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                                
                                unsigned char *bitmapData = [bitmapReps bitmapData];
                                
                                for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                    value0 = uploadTemp [counter1];
                                    value1 = uploadTemp [counter1+1];
                                    value2 = uploadTemp [counter1+2];
                                    
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = (unsigned char)value1;
                                    *bitmapData++ = (unsigned char)value2;
                                    *bitmapData++ = 0;
                                }
                                
                                exportImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                                [exportImage addRepresentation:bitmapReps];
                            }
                        }
                        else if (exType == ".bmp" || exTypeIF == ".BMP"){
                            fin.read((char*)uploadTemp, totalSize+1);
                            fin.close();
                            
                            NSBitmapImageRep *bitmapReps = nil;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            int readDataTemp = 0;
                            
                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                    readDataTemp = uploadTemp [1078+counter1*imageDimension+counter2];
                                    
                                    if (channelNoExport == 1 && readDataTemp < fluorescentCutOffExport1) readDataTemp = 0;
                                    else if (channelNoExport == 2 && readDataTemp < fluorescentCutOffExport2) readDataTemp = 0;
                                    else if (channelNoExport == 3 && readDataTemp < fluorescentCutOffExport3) readDataTemp = 0;
                                    else if (channelNoExport == 4 && readDataTemp < fluorescentCutOffExport4) readDataTemp = 0;
                                    else if (channelNoExport == 5 && readDataTemp < fluorescentCutOffExport5) readDataTemp = 0;
                                    else if (channelNoExport == 6 && readDataTemp < fluorescentCutOffExport6) readDataTemp = 0;
                                    
                                    if (fluorescentColorNoHold == 1){
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 2){
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 3){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 4){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 5){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 6){
                                        *bitmapData++ = 0;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 7){
                                        *bitmapData++ = (unsigned char)readDataTemp;
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.674));
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 8){
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.627));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.125));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.941));
                                        *bitmapData++ = 0;
                                    }
                                    else if (fluorescentColorNoHold == 9){
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.529));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.808));
                                        *bitmapData++ = (unsigned char)((int)(readDataTemp*(double)0.922));
                                        *bitmapData++ = 0;
                                    }
                                }
                            }
                            
                            exportImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [exportImage addRepresentation:bitmapReps];
                        }
                    }
                    
                    delete [] uploadTemp;
                }
                
                if (exportColorStatus == 1 && clickFlag == 2){
                    srand(time(NULL));
                    
                    int maxLineageNoExport = 0;
                    
                    for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                        if (maxLineageNoExport < arrayLineageStartEnd [counter1*8]) maxLineageNoExport = arrayLineageStartEnd [counter1*8];
                    }
                    
                    if (colorListStatus == 1){
                        delete [] colorList;
                        delete [] cellNoHoldExport;
                    }
                    
                    colorList = new CGFloat [(maxLineageNoExport+5)*4];
                    cellNoHoldExport = new double [maxLineageNoExport+5];
                    colorListStatus = 1;
                    
                    for (int counter1 = 0; counter1 < (maxLineageNoExport+5)*4; counter1++) colorList [counter1] = 0;
                    
                    for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                        colorList [arrayLineageStartEnd [counter1*8]*4] = 1;
                    }
                    
                    for (int counter1 = 1; counter1 <= maxLineageNoExport; counter1++){
                        if (colorList [counter1*4] == 1){
                            colorList [counter1*4+1] = (rand()%255)/(double)255;
                            colorList [counter1*4+2] = (rand()%255)/(double)255;
                            colorList [counter1*4+3] = (rand()%255)/(double)255;
                        }
                    }
                }
                else if (exportColorStatus == 2 && clickFlag == 2){
                    srand(time(NULL));
                    
                    int maxLineageNoExport = 0;
                    
                    for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                        if (maxLineageNoExport < arrayLineageStartEnd [counter1*8]) maxLineageNoExport = arrayLineageStartEnd [counter1*8];
                    }
                    
                    if (colorListStatus == 1){
                        delete [] colorList;
                        delete [] cellNoHoldExport;
                    }
                    
                    colorList = new CGFloat [(lineageStartEndCount/8+5)*4];
                    cellNoHoldExport = new double [lineageStartEndCount/8+5];
                    colorListStatus = 1;
                    colorListCount = 0;
                    
                    for (int counter1 = 0; counter1 < (lineageStartEndCount/8+5)*4; counter1++) colorList [counter1] = 0;
                    for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++) cellNoHoldExport [counter1] = -1;
                    
                    int findFlag = 0;
                    
                    for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                        findFlag = 0;
                        
                        for (int counter2 = 0; counter2 < colorListCount; counter2++){
                            if (cellNoHoldExport [counter2] == arrayLineageStartEnd [counter1*8+1]){
                                findFlag = 1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            colorList [colorListCount*4+1] = (rand()%255)/(double)255;
                            colorList [colorListCount*4+2] = (rand()%255)/(double)255;
                            colorList [colorListCount*4+3] = (rand()%255)/(double)255;
                            
                            cellNoHoldExport [colorListCount] = arrayLineageStartEnd [counter1*8+1], colorListCount++;
                        }
                    }
                }
                
                [self setNeedsDisplay:YES];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Data Read Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if (lineTraceOnOff == 1 && (lineTraceActive == 1 || lineTraceActive == 2)){
            lineTraceActive = 2;
            
            lineTraceStartX = xPointMarkTemp;
            lineTraceStartY = yPointMarkTemp;
            lineTraceStartTimePoint = imageNumberExportForDisplay;
        }
        else if (lineTraceOnOff == 1 && lineTraceActive == 3){
            lineTraceEndX = xPointMarkTemp;
            lineTraceEndY = yPointMarkTemp;
            lineTraceEndTimePoint = imageNumberExportForDisplay;
        }
        
        if (lineTraceDeleteOn == 1){
            int lineDeleteFind = 0;
            
            for (int counter1 = 0; counter1 < lineTraceCount/8; counter1++){
                if (treatmentNameHold == arrayLineTrace [counter1*8+6]){
                    if (atoi(arrayLineTrace [counter1*8].c_str()) >= xPointMarkTemp-10 && atoi(arrayLineTrace [counter1*8].c_str()) <= xPointMarkTemp+10 && atoi(arrayLineTrace [counter1*8+1].c_str()) >= yPointMarkTemp-10 && atoi(arrayLineTrace [counter1*8+1].c_str()) <= yPointMarkTemp+10){
                        arrayLineTrace [counter1*8+7] = "d";
                        lineDeleteFind = 1;
                        break;
                    }
                    else if (atoi(arrayLineTrace [counter1*8+3].c_str()) >= xPointMarkTemp-10 && atoi(arrayLineTrace [counter1*8+3].c_str()) <= xPointMarkTemp+10 && atoi(arrayLineTrace [counter1*8+4].c_str()) >= yPointMarkTemp-10 && atoi(arrayLineTrace [counter1*8+4].c_str()) <= yPointMarkTemp+10){
                        arrayLineTrace [counter1*8+7] = "d";
                        lineDeleteFind = 1;
                        break;
                    }
                }
            }
            
            if (lineDeleteFind == 0){
                for (int counter1 = 0; counter1 < lineTraceCount/8; counter1++){
                    if (arrayLineTrace [counter1*8+7] == "d") arrayLineTrace [counter1*8+7] = "s";
                }
            }
        }
    }
}

-(void)mouseUp:(NSEvent *)event{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        if (windowLockEX == 0){
            xPositionExport = xPositionExport+xPositionMoveExport;
            yPositionExport = yPositionExport+yPositionMoveExport;
            xPositionMoveExport = 0;
            yPositionMoveExport = 0;
            mouseDragFlag = 0;
            clickFlag = 0;
            [self setNeedsDisplay:YES];
        }
        else if (windowLockEX == 1){
            NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
            boxEndX = clickPoint.x;
            boxEndY = clickPoint.y;
            
            double xPositionAdjustDouble = xPositionAdjustExport+xPositionExport;
            double yPositionAdjustDouble = yPositionAdjustExport+yPositionExport;
            double xCalculationValue = 1/(double)windowWidthExport*magnificationExport*0.1;
            double yCalculationValue = 1/(double)windowHeightExport*magnificationExport*0.1;
            
            int xPointMarkTemp = (int)(clickPoint.x/(double)xCalculationValue+xPositionAdjustDouble);
            int yPointMarkTemp = (int)((clickPoint.y/(double)yCalculationValue+yPositionAdjustDouble-imageHeightExport)*-1);
            
            boxEndImageX = xPointMarkTemp;
            boxEndImageY = yPointMarkTemp;
            
            [self setNeedsDisplay:YES];
        }
    }
}

- (void)mouseDragged:(NSEvent *)event{
    if (mainSavingInProgress == 0 && cleaningProgress == 0 && clickFlag == 0){
        if (windowLockEX == 0){
            NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
            xPointDragExport = clickPoint.x;
            yPointDragExport = clickPoint.y;
            xPositionMoveExport = (xPointDownExport-xPointDragExport)*windowWidthExport/(double)(magnificationExport*0.1);
            yPositionMoveExport = (yPointDownExport-yPointDragExport)*windowHeightExport/(double)(magnificationExport*0.1);
            mouseDragFlag = 1;
            [self setNeedsDisplay:YES];
        }
        else if (windowLockEX == 1){
            NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
            boxEndX = clickPoint.x;
            boxEndY = clickPoint.y;
            
            double xPositionAdjustDouble = xPositionAdjustExport+xPositionExport;
            double yPositionAdjustDouble = yPositionAdjustExport+yPositionExport;
            double xCalculationValue = 1/(double)windowWidthExport*magnificationExport*0.1;
            double yCalculationValue = 1/(double)windowHeightExport*magnificationExport*0.1;
            
            int xPointMarkTemp = (int)(clickPoint.x/(double)xCalculationValue+xPositionAdjustDouble);
            int yPointMarkTemp = (int)((clickPoint.y/(double)yCalculationValue+yPositionAdjustDouble-imageHeightExport)*-1);
            
            boxEndImageX = xPointMarkTemp;
            boxEndImageY = yPointMarkTemp;
            
            [self setNeedsDisplay:YES];
        }
    }
}

-(void)keyDown:(NSEvent *)event{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        int keyCode = [event keyCode];
        int proceedFlag = 0;
        struct stat sizeOfFile;
        
        //-----Snap-----
        if (keyCode == 1){
            displayModeSelect = 1;
            colorNoExport = 0;
            
            if (mainSavingInProgress == 0 && cleaningProgress == 0){
                string extension = to_string(imageNumberExportForDisplay);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                pathExtension = extension;
                
                string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
                mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Export_Images";
                mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                string nameString = "Export_Images-EI";
                
                DIR *dir;
                struct dirent *dent;
                
                string entry;
                string extractString;
                int maxEntryNo = 0;
                
                dir = opendir(resultSavePath2.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(nameString) != -1){
                            extractString = entry.substr(entry.find("EI")+2);
                            
                            if ((int)extractString.find(".tif") == -1) extractString = extractString.substr(0, entry.find(".tif"));
                            if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                        }
                    }
                    
                    closedir(dir);
                }
                
                maxEntryNo++;
                
                int fileFindCheck = 0;
                
                if (ifStartHold != 0 && imageNumberExportForDisplay >= ifStartHold){
                    int nextLoad = 0;
                    
                    for (int counter1 = 0; counter1 < 450; counter1 = counter1+15){
                        if (atoi(arrayIFDataHold [counter1].c_str()) != 0 && atoi(arrayIFDataHold [counter1+14].c_str()) <= imageNumberExportForDisplay){
                            nextLoad = counter1/15+1;
                        }
                        else if (atoi(arrayIFDataHold [counter1].c_str()) == 0){
                            break;
                        }
                    }
                    
                    string fluorescentNameExport1 = "";
                    string fluorescentNameExport2 = "";
                    string fluorescentNameExport3 = "";
                    string fluorescentNameExport4 = "";
                    string fluorescentNameExport5 = "";
                    string fluorescentNameExport6 = "";
                    
                    string fluorescentRoundNoExport = "";
                    
                    if (nextLoad > 0){
                        nextLoad--;
                        
                        fluorescentRoundNoExport = arrayIFDataHold [nextLoad*15];
                        
                        if (channelNoExport == 1){
                            colorNoExport = atoi(arrayIFDataHold [nextLoad*15+7].c_str());
                            fluorescentNameExport1 = arrayIFDataHold [nextLoad*15+1];
                        }
                        if (channelNoExport == 2){
                            colorNoExport = atoi(arrayIFDataHold [nextLoad*15+8].c_str());
                            fluorescentNameExport2 = arrayIFDataHold [nextLoad*15+2];
                        }
                        if (channelNoExport == 3){
                            colorNoExport = atoi(arrayIFDataHold [nextLoad*15+9].c_str());
                            fluorescentNameExport3 = arrayIFDataHold [nextLoad*15+3];
                        }
                        if (channelNoExport == 4){
                            colorNoExport = atoi(arrayIFDataHold [nextLoad*15+10].c_str());
                            fluorescentNameExport4 = arrayIFDataHold [nextLoad*15+4];
                        }
                        if (channelNoExport == 5){
                            colorNoExport = atoi(arrayIFDataHold [nextLoad*15+11].c_str());
                            fluorescentNameExport5 = arrayIFDataHold [nextLoad*15+5];
                        }
                        if (channelNoExport == 6){
                            colorNoExport = atoi(arrayIFDataHold [nextLoad*15+12].c_str());
                            fluorescentNameExport6 = arrayIFDataHold [nextLoad*15+6];
                        }
                    }
                    
                    string extension2 = to_string(colorNoExport);
                   
                    if (channelNoExport == 1){
                        displayImageLoadPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport1+exTypeIF+fluorescentRoundNoExport;
                    }
                    else if (channelNoExport == 2){
                        displayImageLoadPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport2+exTypeIF+fluorescentRoundNoExport;
                    }
                    else if (channelNoExport == 3){
                        displayImageLoadPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport3+exTypeIF+fluorescentRoundNoExport;
                    }
                    else if (channelNoExport == 4){
                        displayImageLoadPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport4+exTypeIF+fluorescentRoundNoExport;
                    }
                    else if (channelNoExport == 5){
                        displayImageLoadPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport6+exTypeIF+fluorescentRoundNoExport;
                    }
                    else if (channelNoExport == 6){
                        displayImageLoadPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport3+exTypeIF+fluorescentRoundNoExport;
                    }
                    else if (channelNoExport == 0){
                        displayImageLoadPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+exTypeIF+fluorescentRoundNoExport;
                    }
                    
                    if (stat(displayImageLoadPath.c_str(), &sizeOfFile) == 0){
                        fileFindCheck = 1;
                    }
                    
                    if (fileFindCheck == 0){
                        displayImageLoadPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+exTypeIF+fluorescentRoundNoExport;
                        colorNoExport = 0;
                    }
                }
                else{
                    
                    string fluorescentNameExport1 = "";
                    string fluorescentNameExport2 = "";
                    string fluorescentNameExport3 = "";
                    string fluorescentNameExport4 = "";
                    string fluorescentNameExport5 = "";
                    string fluorescentNameExport6 = "";
                    
                    int fluorescentNoExport1 = 0;
                    int fluorescentNoExport2 = 0;
                    int fluorescentNoExport3 = 0;
                    int fluorescentNoExport4 = 0;
                    int fluorescentNoExport5 = 0;
                    int fluorescentNoExport6 = 0;
                    
                    fluorescentNameExport1 = fluorescentName1;
                    fluorescentNameExport2 = fluorescentName2;
                    fluorescentNameExport3 = fluorescentName3;
                    fluorescentNameExport4 = fluorescentName4;
                    fluorescentNameExport5 = fluorescentName5;
                    fluorescentNameExport6 = fluorescentName6;
                    
                    fluorescentNoExport1 = fluorescentNo1;
                    fluorescentNoExport2 = fluorescentNo2;
                    fluorescentNoExport3 = fluorescentNo3;
                    fluorescentNoExport4 = fluorescentNo4;
                    fluorescentNoExport5 = fluorescentNo5;
                    fluorescentNoExport6 = fluorescentNo6;
                    
                    if (channelNoExport == 1){
                        string extension2 = to_string(fluorescentNoExport1);
                        displayImageLoadPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport1+exType;
                        
                        colorNoExport = fluorescentNoExport1;
                    }
                    else if (channelNoExport == 2){
                        string extension2 = to_string(fluorescentNoExport2);
                        displayImageLoadPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport2+exType;
                        
                        colorNoExport = fluorescentNoExport2;
                    }
                    else if (channelNoExport == 3){
                        string extension2 = to_string(fluorescentNoExport3);
                        displayImageLoadPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport3+exType;
                        
                        colorNoExport = fluorescentNoExport3;
                    }
                    else if (channelNoExport == 4){
                        string extension2 = to_string(fluorescentNoExport4);
                        displayImageLoadPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport4+exType;
                        
                        colorNoExport = fluorescentNoExport4;
                    }
                    else if (channelNoExport == 5){
                        string extension2 = to_string(fluorescentNoExport5);
                        displayImageLoadPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport5+exType;
                        
                        colorNoExport = fluorescentNoExport5;
                    }
                    else if (channelNoExport == 6){
                        string extension2 = to_string(fluorescentNoExport6);
                        displayImageLoadPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameExport6+exType;
                        
                        colorNoExport = fluorescentNoExport6;
                    }
                    else if (channelNoExport == 0){
                        string extension2 = to_string(fluorescentNoExport3);
                        displayImageLoadPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+exType;
                        
                        colorNoExport = 0;
                    }
                    
                    if (stat(displayImageLoadPath.c_str(), &sizeOfFile) == 0){
                        fileFindCheck = 1;
                    }
                    
                    if (fileFindCheck == 0){
                        displayImageLoadPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+exType;
                        
                        colorNoExport = 0;
                    }
                }
                
                if (densityModeHold == 1 || motilityStatusHold == 1){
                    if (circleAreaHoldStatus == 1){
                        for (int counter1 = 0; counter1 < densityDiameterHold+2; counter1++) delete [] circleAreaHold [counter1];
                        delete [] circleAreaHold;
                    }
                    
                    circleAreaHold = new int *[densityDiameterHold+2];
                    
                    for (int counter1 = 0; counter1 < densityDiameterHold+2; counter1++){
                        circleAreaHold [counter1] = new int [densityDiameterHold+2];
                    }
                    
                    circleAreaHoldStatus = 1;
                    
                    for (int counter1 = 0; counter1 < densityDiameterHold+2; counter1++){
                        for (int counter2 = 0; counter2 <densityDiameterHold+2; counter2++){
                            circleAreaHold [counter1][counter2] = 0;
                        }
                    }
                    
                    int center = (densityDiameterHold/2)+1;
                    double radius = densityDiameterHold/(double)2;
                    double diameterCal = 0;
                    
                    for (int counter1 = 0; counter1 < densityDiameterHold+2; counter1++){
                        for (int counter2 = 0; counter2 <densityDiameterHold+2; counter2++){
                            diameterCal = (counter1-center)*(counter1-center)+(counter2-center)*(counter2-center);
                            
                            if (sqrt(diameterCal) <= radius) circleAreaHold [counter1][counter2] = 1;
                        }
                    }
                }
                
                displayModeSelect = 1;
                
                if (noOfCellsInAreaStatus == 1){
                    delete [] noOfCellsInArea;
                }
                
                noOfCellsInArea = new int [100];
                noOfCellsInAreaStatus = 1;
                
                displayImageSavePath = resultSavePath2+"/"+nameString+to_string(maxEntryNo)+".tif";
                
                if (thresholdStatusHold == 1){
                    if (particleCountingDataHoldStatus == 1){
                        delete [] particleCountingDataHold;
                    }
                    
                    particleCountingDataHold = new int [imageEndHold*2+100];
                    particleCountingDataHoldCount = 0;
                    particleCountingDataHoldStatus = 1;
                    
                    for (int counter1 = 0; counter1 < imageEndHold*2+100; counter1++){
                        particleCountingDataHold [counter1] = 0;
                    }
                }
                
                proceedFlag = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        //-----All export-----
        if (keyCode == 0){
            displayModeSelect = 7;
            
            if (mainSavingInProgress == 0 && cleaningProgress == 0){
                string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
                mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Export_Images";
                mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                string nameString = "Export_Images-EI";
                
                DIR *dir;
                struct dirent *dent;
                
                string entry;
                string extractString;
                int maxEntryNo = 0;
                
                dir = opendir(resultSavePath2.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(nameString) != -1){
                            extractString = entry.substr(entry.find("EI")+2);
                            
                            if ((int)extractString.find(".tif") == -1) extractString = extractString.substr(0, entry.find(".tif"));
                            
                            if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                        }
                    }
                    
                    closedir(dir);
                }
                
                maxEntryNo++;
                
                displayImageAllPath = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Export_Images/"+nameString+to_string(maxEntryNo);
                mkdir(displayImageAllPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                string displayImageTimePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/";
                
                dir = opendir(displayImageTimePath.c_str());
                fileDeleteCount = 0;
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("STimage") != -1){
                            if (fileDeleteCount+5 > fileDeleteLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate fileDeleteUpDate];
                            }
                            
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                    }
                    
                    closedir(dir);
                }
                
                //-----Directory Sort-----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                    [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                }
                
                if (noOfCellsInAreaStatus == 1){
                    delete [] noOfCellsInArea;
                }
                
                noOfCellsInArea = new int [fileDeleteCount*4+20];
                noOfCellsInAreaStatus = 1;
                
                if (densityModeHold == 1 || motilityStatusHold == 1){
                    if (circleAreaHoldStatus == 1){
                        for (int counter1 = 0; counter1 < densityDiameterHold+2; counter1++) delete [] circleAreaHold [counter1];
                        delete [] circleAreaHold;
                    }
                    
                    circleAreaHold = new int *[densityDiameterHold+2];
                    
                    for (int counter1 = 0; counter1 < densityDiameterHold+2; counter1++){
                        circleAreaHold [counter1] = new int [densityDiameterHold+2];
                    }
                    
                    circleAreaHoldStatus = 1;
                    
                    for (int counter1 = 0; counter1 < densityDiameterHold+2; counter1++){
                        for (int counter2 = 0; counter2 <densityDiameterHold+2; counter2++){
                            circleAreaHold [counter1][counter2] = 0;
                        }
                    }
                    
                    int center = (densityDiameterHold/2)+1;
                    double radius = densityDiameterHold/(double)2;
                    double diameterCal = 0;
                    
                    for (int counter1 = 0; counter1 < densityDiameterHold+2; counter1++){
                        for (int counter2 = 0; counter2 <densityDiameterHold+2; counter2++){
                            diameterCal = (counter1-center)*(counter1-center)+(counter2-center)*(counter2-center);
                            
                            if (sqrt(diameterCal) <= radius) circleAreaHold [counter1][counter2] = 1;
                        }
                    }
                }
                
                timingCount = 1;
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if (keyCode == 17){
            if (timingCount != 0){
                timingCount = 0;
                displayModeSelect = 0;
                timingEx = 3;
            }
        }
        
        //----- Density Mode-----
        if (keyCode == 2){
            if (timingCount == 0){
                if (densityModeHold == 0){
                    if (densityDiameterHold != 0 && densityValueMaxHold != 0){
                        densityModeHold = 1;
                        motilityStatusHold = 0;
                        thresholdStatusHold = 0;
                        proceedFlag = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (densityModeHold == 1){
                    densityModeHold = 0;
                    proceedFlag = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
        }
        
        //-----Motility Mode-----
        if (keyCode == 46){
            if (timingCount == 0){
                if (motilityStatusHold == 0){
                    if (densityDiameterHold != 0 && densityValueMaxHold != 0){
                        int xPositionMotility = 0;
                        int yPositionMotility = 0;
                        int lingNoHoldMotility = 0;
                        int cellNoHoldMotility = 0;
                        int dataSetStart = 0;
                        int maxLineageNo = 0;
                        int numberOfCellEntry = 0;
                        int averageHold = 0;
                        int entryNoHold = 0;
                        string percentString;
                        
                        if (motilityBasicInfoStatus == 1){
                            delete [] arrayMotilityBasicInfo;
                        }
                        
                        motilityBasicInfoStatus = 1;
                        motilityBasicInfoCount = 0;
                        
                        arrayMotilityBasicInfo = new int [(lineageDataCount/8)*7+100];
                        
                        for (int counter3 = 0; counter3 < (lineageDataCount/8)*7+100; counter3++){
                            arrayMotilityBasicInfo [counter3] = 0;
                        }
                        
                        for (int counter3 = 0; counter3 < lineageDataCount/8; counter3++){
                            if (maxLineageNo < arrayLineageData [counter3*8+6]) maxLineageNo = arrayLineageData [counter3*8+6];
                        }
                        
                        for (int counter3 = 0; counter3 < lineageDataCount/8; counter3++){
                            if (dataSetStart == 0){
                                xPositionMotility = arrayLineageData [counter3*8];
                                yPositionMotility = arrayLineageData [counter3*8+1];
                                
                                lingNoHoldMotility = arrayLineageData [counter3*8+6];
                                cellNoHoldMotility = arrayLineageData [counter3*8+5];
                                
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8+6], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8+5], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8+1], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8+2], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = 0, motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8+3], motilityBasicInfoCount++;
                                
                                averageHold = 0;
                                entryNoHold = 0;
                                
                                dataSetStart = 1;
                                numberOfCellEntry++;
                            }
                            else if (lingNoHoldMotility == arrayLineageData [counter3*8+6] && cellNoHoldMotility == arrayLineageData [counter3*8+5] && dataSetStart == 1){
                                entryNoHold++;
                                averageHold = averageHold+(int)(sqrt((xPositionMotility-arrayLineageData [counter3*8])*(xPositionMotility-arrayLineageData [counter3*8])+(yPositionMotility-arrayLineageData [counter3*8+1])*(yPositionMotility-arrayLineageData [counter3*8+1]))*10);
                                
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8+6], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8+5], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8+1], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8+2], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = (int)(averageHold/(double)entryNoHold), motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8+3], motilityBasicInfoCount++;
                                
                                xPositionMotility = arrayLineageData [counter3*8];
                                yPositionMotility = arrayLineageData [counter3*8+1];
                            }
                            else if (counter3 == lineageDataCount/8-1){
                                entryNoHold++;
                                averageHold = averageHold+(int)(sqrt((xPositionMotility-arrayLineageData [counter3*8])*(xPositionMotility-arrayLineageData [counter3*8])+(yPositionMotility-arrayLineageData [counter3*8+1])*(yPositionMotility-arrayLineageData [counter3*8+1]))*10);
                                
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8+6], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8+5], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8+1], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8+2], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = (int)(averageHold/(double)entryNoHold), motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8+3], motilityBasicInfoCount++;
                                
                                xPositionMotility = arrayLineageData [counter3*8];
                                yPositionMotility = arrayLineageData [counter3*8+1];
                            }
                            else if ((lingNoHoldMotility != arrayLineageData [counter3*8+6] || cellNoHoldMotility != arrayLineageData [counter3*8+5]) && dataSetStart == 1){
                                xPositionMotility = arrayLineageData [counter3*8];
                                yPositionMotility = arrayLineageData [counter3*8+1];
                                
                                lingNoHoldMotility = arrayLineageData [counter3*8+6];
                                cellNoHoldMotility = arrayLineageData [counter3*8+5];
                                
                                averageHold = 0;
                                entryNoHold = 0;
                                
                                numberOfCellEntry++;
                                
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8+6], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8+5], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8+1], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8+2], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = 0, motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter3*8+3], motilityBasicInfoCount++;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < motilityBasicInfoCount/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<< arrayMotilityBasicInfo [counterA*6+counterB];
                        //    cout<<"  arrayMotilityBasicInfo "<<counterA<<endl;
                        //}
                        
                        for (int counter1 = 0; counter1 < motilityBasicInfoCount/7; counter1++){
                            if (arrayMotilityBasicInfo [counter1*7+6] == 1 || arrayMotilityBasicInfo [counter1*7+6] == 31 || arrayMotilityBasicInfo [counter1*7+6] == 41 || arrayMotilityBasicInfo [counter1*7+6] == 51){
                                for (int counter2 = 0; counter2 < motilityBasicInfoCount/7; counter2++){
                                    if (arrayMotilityBasicInfo [counter1*7] == arrayMotilityBasicInfo [counter2*7] && arrayMotilityBasicInfo [counter1*7+1] == arrayMotilityBasicInfo [counter2*7+1] && arrayMotilityBasicInfo [counter2*7+4] == arrayMotilityBasicInfo [counter1*7+4]+1){
                                        arrayMotilityBasicInfo [counter1*7+5] = arrayMotilityBasicInfo [counter2*7+5];
                                        break;
                                    }
                                }
                            }
                        }
                        
                        motilityStatusHold = 1;
                        densityModeHold = 0;
                        thresholdStatusHold = 0;
                        proceedFlag = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (motilityStatusHold == 1){
                    motilityStatusHold = 0;
                    proceedFlag = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
        }
        
        //----- TH Mode-----
        if (keyCode == 11){
            if (timingCount == 0){
                if (thresholdStatusHold == 0){
                    if (thresholdCutHold >= 0 && areaSizeMinHold != 0 && areaSizeMaxHold != 0 && areaSizeMaxHold > areaSizeMinHold+10 && colorNoExport == 0){
                        thresholdStatusHold = 1;
                        motilityStatusHold = 0;
                        densityModeHold = 0;
                        proceedFlag = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (thresholdStatusHold == 1){
                    thresholdStatusHold = 0;
                    proceedFlag = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
        }
        
        //-----Window lock-----
        if (keyCode == 13){
            if (timingCount == 0){
                boxStartX = 0;
                boxStartY = 0;
                boxEndX = 0;
                boxEndY = 0;
                
                boxStartImageX = 0;
                boxStartImageY = 0;
                boxEndImageX = 0;
                boxEndImageY = 0;
                
                if (windowLockEX == 0) windowLockEX = 1;
                else if (windowLockEX == 1){
                    windowLockEX = 0;
                }
                
                proceedFlag = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        
        //-----Line Trace Start----
        if (keyCode == 18){
            if (lineTraceOnOff == 1 && lineTraceDeleteOn == 0){
                lineTraceActive = 1;
                proceedFlag = 1;
            }
        }
        
        //-----Line Trace End----
        if (keyCode == 19){
            if (lineTraceOnOff == 1 && lineTraceDeleteOn == 0){
                if (lineTraceActive == 2) lineTraceActive = 3;
                
                proceedFlag = 1;
            }
        }
        
        //-----Line Trace Set----
        if (keyCode == 20){
            if (lineTraceOnOff == 1){
                if (lineTraceActive == 3 && lineTraceDeleteOn == 0){
                    if (lineTraceCount+70 > lineTraceLimit){
                        string *arrayUpDate = new string [lineTraceCount+10];
                        
                        for (int counter1 = 0; counter1 < lineTraceCount; counter1++) arrayUpDate [counter1] = arrayLineTrace [counter1];
                        
                        delete [] arrayLineTrace;
                        arrayLineTrace = new string [lineTraceLimit+7000];
                        lineTraceLimit = lineTraceLimit+7000;
                        
                        for (int counter1 = 0; counter1 < lineTraceCount; counter1++) arrayLineTrace [counter1] = arrayUpDate [counter1];
                        delete [] arrayUpDate;
                    }
                    
                    arrayLineTrace [lineTraceCount] = to_string(lineTraceStartX), lineTraceCount++;
                    arrayLineTrace [lineTraceCount] = to_string(lineTraceStartY), lineTraceCount++;
                    arrayLineTrace [lineTraceCount] = to_string(lineTraceStartTimePoint), lineTraceCount++;
                    arrayLineTrace [lineTraceCount] = to_string(lineTraceEndX), lineTraceCount++;
                    arrayLineTrace [lineTraceCount] = to_string(lineTraceEndY), lineTraceCount++;
                    arrayLineTrace [lineTraceCount] = to_string(lineTraceEndTimePoint), lineTraceCount++;
                    arrayLineTrace [lineTraceCount] = treatmentNameHold, lineTraceCount++;
                    arrayLineTrace [lineTraceCount] = "s", lineTraceCount++;
                    
                    string treatmentNameTemp = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+"*LineTrace.dat";
                    
                    ofstream oin;
                    
                    oin.open(treatmentNameTemp.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < lineTraceCount; counter1++){
                        oin<<arrayLineTrace [counter1]<<endl;
                    }
                    
                    oin<<"End"<<endl;
                    
                    oin.close();
                    
                    lineTraceStatus = 1;
                    
                    lineTraceStartX = -1;
                    lineTraceStartY = -1;
                    lineTraceStartTimePoint = -1;
                    lineTraceEndX = -1;
                    lineTraceEndY = -1;
                    lineTraceEndTimePoint = -1;
                    lineTraceActive = 0;
                    
                    proceedFlag = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (lineTraceActive == 0 && lineTraceDeleteOn == 1){
                    int entryCount = 0;
                    
                    for (int counter1 = 0; counter1 < lineTraceCount/8; counter1++){
                        if (arrayLineTrace [counter1*8+7] != "d"){
                            arrayLineTrace [entryCount] = arrayLineTrace [counter1*8], entryCount++;
                            arrayLineTrace [entryCount] = arrayLineTrace [counter1*8+1], entryCount++;
                            arrayLineTrace [entryCount] = arrayLineTrace [counter1*8+2], entryCount++;
                            arrayLineTrace [entryCount] = arrayLineTrace [counter1*8+3], entryCount++;
                            arrayLineTrace [entryCount] = arrayLineTrace [counter1*8+4], entryCount++;
                            arrayLineTrace [entryCount] = arrayLineTrace [counter1*8+5], entryCount++;
                            arrayLineTrace [entryCount] = arrayLineTrace [counter1*8+6], entryCount++;
                            arrayLineTrace [entryCount] = arrayLineTrace [counter1*8+7], entryCount++;
                        }
                    }
                    
                    lineTraceCount = entryCount;
                    
                    string treatmentNameTemp = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+"*LineTrace.dat";
                    
                    ofstream oin;
                    
                    oin.open(treatmentNameTemp.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < lineTraceCount; counter1++){
                        oin<<arrayLineTrace [counter1]<<endl;
                    }
                    
                    oin<<"End"<<endl;
                    
                    oin.close();
                    
                    lineTraceStatus = 1;
                    
                    lineTraceStartX = -1;
                    lineTraceStartY = -1;
                    lineTraceStartTimePoint = -1;
                    lineTraceEndX = -1;
                    lineTraceEndY = -1;
                    lineTraceEndTimePoint = -1;
                    lineTraceActive = 0;
                    lineTraceDeleteOn = 0;
                    
                    proceedFlag = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
        }
        
        //-----Line Trace Delete----
        if (keyCode == 12){
            if (lineTraceOnOff == 1){
                if (lineTraceDeleteOn == 0){
                    lineTraceStartX = -1;
                    lineTraceStartY = -1;
                    lineTraceStartTimePoint = -1;
                    lineTraceEndX = -1;
                    lineTraceEndY = -1;
                    lineTraceEndTimePoint = -1;
                    lineTraceActive = 0;
                    
                    lineTraceDeleteOn = 1;
                }
            }
        }
        
        //-----Line Trace Clear----
        if (keyCode == 8){
            if (lineTraceActive != 0){
                lineTraceStartX = -1;
                lineTraceStartY = -1;
                lineTraceStartTimePoint = -1;
                lineTraceEndX = -1;
                lineTraceEndY = -1;
                lineTraceEndTimePoint = -1;
                lineTraceActive = 0;
                lineTraceDeleteOn = 0;
                
                for (int counter1 = 0; counter1 < lineTraceCount/8; counter1++){
                    if (arrayLineTrace [counter1*8+7] == "d") arrayLineTrace [counter1*8+7] = "s";
                }
                
                proceedFlag = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        
        //-----Line Trace All clear-----
        if (keyCode == 15){
            if (lineTraceOnOff == 1){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert addButtonWithTitle:@"Cancel"];
                [alert setMessageText:@"Delete all data?"];
                [alert setAlertStyle:NSAlertStyleWarning];
                
                if ([alert runModal] == NSAlertFirstButtonReturn){
                    lineTraceStartX = -1;
                    lineTraceStartY = -1;
                    lineTraceStartTimePoint = -1;
                    lineTraceEndX = -1;
                    lineTraceEndY = -1;
                    lineTraceEndTimePoint = -1;
                    lineTraceActive = 0;
                    lineTraceDeleteOn = 0;
                    
                    int entryCount = 0;
                    
                    for (int counter1 = 0; counter1 < lineTraceCount/8; counter1++){
                        if (arrayLineTrace [counter1*8+6] != treatmentNameHold){
                            arrayLineTrace [entryCount] = arrayLineTrace [counter1*8], entryCount++;
                            arrayLineTrace [entryCount] = arrayLineTrace [counter1*8+1], entryCount++;
                            arrayLineTrace [entryCount] = arrayLineTrace [counter1*8+2], entryCount++;
                            arrayLineTrace [entryCount] = arrayLineTrace [counter1*8+3], entryCount++;
                            arrayLineTrace [entryCount] = arrayLineTrace [counter1*8+4], entryCount++;
                            arrayLineTrace [entryCount] = arrayLineTrace [counter1*8+5], entryCount++;
                            arrayLineTrace [entryCount] = arrayLineTrace [counter1*8+6], entryCount++;
                            arrayLineTrace [entryCount] = arrayLineTrace [counter1*8+7], entryCount++;
                        }
                    }
                    
                    lineTraceCount = entryCount;
                    
                    string treatmentNameTemp = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+"*LineTrace.dat";
                    
                    ofstream oin;
                    
                    oin.open(treatmentNameTemp.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < lineTraceCount; counter1++){
                        oin<<arrayLineTrace [counter1]<<endl;
                    }
                    
                    oin<<"End"<<endl;
                    
                    oin.close();
                    
                    proceedFlag = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
        }
        
        //-----Original size-----
        if (keyCode == 6){
            proceedFlag = 1;
            xPositionExport = 0;
            yPositionExport = 0;
            xPositionAdjustExport = 0;
            yPositionAdjustExport = 0;
            magnificationExport = 10;
        }
        
        //-----Magnification Magnify-----
        if (keyCode == 125){
            if (magnificationExport >= 12 && magnificationExport <= 500){
                if (magnificationExport-10 < 12) magnificationExport = 10;
                else magnificationExport = magnificationExport-10;
                
                proceedFlag = 1;
                xPositionAdjustExport = -1*(imageWidthExport/(double)(magnificationExport*0.1)-imageWidthExport)/(double)2;
                yPositionAdjustExport = -1*(imageHeightExport/(double)(magnificationExport*0.1)-imageHeightExport)/(double)2;
            }
        }
        
        //-----Magnification Reduction-----
        if (keyCode == 126){
            if (magnificationExport >= 10 && magnificationExport <= 498){
                if (magnificationExport+10 > 498) magnificationExport = 498;
                else magnificationExport = magnificationExport+10;
                
                proceedFlag = 1;
                xPositionAdjustExport = (imageWidthExport-imageWidthExport/(double)(magnificationExport*0.1))/(double)2;
                yPositionAdjustExport = (imageHeightExport-imageHeightExport/(double)(magnificationExport*0.1))/(double)2;
            }
        }
        
        //-----Magnification space bar-----
        if (keyCode == 49){
            proceedFlag = 1;
            
            magnificationExport = (int)(200/((double)(50/(double)imageWidthExport)*700)*10);
            xPositionAdjustExport = (imageWidthExport-imageWidthExport/(double)(magnificationExport*0.1))/(double)2;
            yPositionAdjustExport = (imageHeightExport-imageHeightExport/(double)(magnificationExport*0.1))/(double)2;
        }
        
        //-----Jump TimeOne "J"-----
        if (keyCode == 38) imageNumberExportForDisplay = timeOneHold;
        
        //-----Jump TimeEnd "L"-----
        if (keyCode == 37) imageNumberExportForDisplay = timeEndHold;
        
        //-----Image Back-----
        if (keyCode == 123){
            if (imageNumberExportForDisplay > 1 & imageNumberExportForDisplay <= imageEndHold){
                if (imageNumberExportForDisplay-1 < 1) imageNumberExportForDisplay = 1;
                else imageNumberExportForDisplay = imageNumberExportForDisplay-1;
            }
        }
        
        //-----Image Forward-----
        if (keyCode == 124){
            if (imageNumberExportForDisplay >= 1 && imageNumberExportForDisplay < imageEndHold){
                if (imageNumberExportForDisplay+1 > imageEndHold) imageNumberExportForDisplay = imageEndHold;
                else imageNumberExportForDisplay = imageNumberExportForDisplay+1;
            }
        }
        
        if (keyCode == 123 || keyCode == 124 || keyCode == 38 || keyCode == 37 || keyCode == 9 || keyCode == 49 || keyCode == 126){
            proceedFlag = 1;
            
            string extension = to_string(imageNumberExportForDisplay);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            string connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
            
            long sizeForCopy = 0;
            long size1 = 0;
            long size2 = 0;
            int checkFlag = 0;
            int readingError = 0;
            
            for (int counter4 = 0; counter4 < 6; counter4++){
                sizeForCopy = 0;
                
                if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter4 == 0) size1 = sizeForCopy;
                    else if (counter4 == 1) size2 = sizeForCopy;
                    else if (counter4 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter4 == 3) size1 = sizeForCopy;
                    else if (counter4 == 4) size2 = sizeForCopy;
                    else if (counter4 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            ifstream fin;
            
            if (checkFlag == 1){
                if (positionExportStatus == 1) delete [] arrayPositionExport;
                arrayPositionExport = new int [sizeForCopy+50];
                positionExportCount = 0;
                positionExportStatus = 1;
                
                if (gravityCenterExportStatus == 1) delete [] arrayGravityCenterExport;
                arrayGravityCenterExport = new int [sizeForCopy+50];
                gravityCenterExportCount = 0;
                gravityCenterExportStatus = 1;
                
                fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    int finData [17];
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--5
                                finData [13] = uploadTemp [readPosition], readPosition++; //--6
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++;
                                finData [16] = uploadTemp [readPosition], readPosition++; //--7
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                else{
                                    
                                    arrayPositionExport [positionExportCount] = finData [1], positionExportCount++;
                                    arrayPositionExport [positionExportCount] = finData [3], positionExportCount++;
                                    arrayPositionExport [positionExportCount] = finData [4], positionExportCount++;
                                    arrayPositionExport [positionExportCount] = finData [7], positionExportCount++;
                                    arrayPositionExport [positionExportCount] = finData [12], positionExportCount++;
                                    arrayPositionExport [positionExportCount] = finData [13], positionExportCount++;
                                    arrayPositionExport [positionExportCount] = finData [16], positionExportCount++;
                                }
                            }
                            else if (stepCount == 1){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                finData [9] = finData [8]*256+finData [9];
                                
                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                            }
                            else if (stepCount == 2){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                else{
                                    
                                    arrayGravityCenterExport [gravityCenterExportCount] = finData [1], gravityCenterExportCount++;
                                    arrayGravityCenterExport [gravityCenterExportCount] = finData [3], gravityCenterExportCount++;
                                    arrayGravityCenterExport [gravityCenterExportCount] = finData [6], gravityCenterExportCount++;
                                    arrayGravityCenterExport [gravityCenterExportCount] = finData [7], gravityCenterExportCount++;
                                    arrayGravityCenterExport [gravityCenterExportCount] = finData [10], gravityCenterExportCount++;
                                    arrayGravityCenterExport [gravityCenterExportCount] = finData [11], gravityCenterExportCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                }
            }
            
            if (checkFlag == 1 || readingError == 0){
                //-----Master Data Status UpLoad-----
                string connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
                
                sizeForCopy = 0;
                
                if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (timeSelectedExportStatus == 1) delete [] arrayTimeSelectedExport;
                arrayTimeSelectedExport = new int [sizeForCopy+50];
                timeSelectedExportCount = 0;
                timeSelectedExportStatus = 1;
                
                if (sizeForCopy != 0){
                    fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        int finData [19];
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                                finData [7] = uploadTemp [readPosition], readPosition++;
                                finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                                finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                                finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                                finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                                finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                                finData [13] = uploadTemp [readPosition], readPosition++;
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                                finData [16] = uploadTemp [readPosition], readPosition++;
                                finData [17] = uploadTemp [readPosition], readPosition++;
                                finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                                
                                finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [8] = finData [7]*256+finData [8];
                                finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                                finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                                
                                if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                                else{
                                    
                                    arrayTimeSelectedExport [timeSelectedExportCount] = finData [0], timeSelectedExportCount++; //-----Selected, removed, eliminated status-----
                                    arrayTimeSelectedExport [timeSelectedExportCount] = finData [3], timeSelectedExportCount++; //-----When new line is created, enter line number which creates-----
                                    arrayTimeSelectedExport [timeSelectedExportCount] = finData [6], timeSelectedExportCount++; //-----PositionRevise Start-----
                                    arrayTimeSelectedExport [timeSelectedExportCount] = finData [8], timeSelectedExportCount++; //-----
                                    arrayTimeSelectedExport [timeSelectedExportCount] = finData [9], timeSelectedExportCount++; //-----R-----
                                    arrayTimeSelectedExport [timeSelectedExportCount] = finData [10], timeSelectedExportCount++; //-----G-----
                                    arrayTimeSelectedExport [timeSelectedExportCount] = finData [11], timeSelectedExportCount++; //-----B-----
                                    arrayTimeSelectedExport [timeSelectedExportCount] = finData [12], timeSelectedExportCount++; //-----
                                    arrayTimeSelectedExport [timeSelectedExportCount] = finData [15], timeSelectedExportCount++; //-----Connect-----
                                    arrayTimeSelectedExport [timeSelectedExportCount] = finData [18], timeSelectedExportCount++; //-----Lineage-----
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                    }
                }
                
                string displayImageExportPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+exType;
                
                int totalSize = imageDimension*imageDimension*4;
                
                uint8_t *uploadTemp = new uint8_t [totalSize];
                fin.open(displayImageExportPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    if (exType == ".tif"){
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        int dataConversion [4];
                        int endianType = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        
                        unsigned long headPosition = 0;
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        if (tifImageColorGray == 0){
                            NSBitmapImageRep *bitmapReps;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                                *bitmapData++ = uploadTemp [counter1];
                            }
                            
                            exportImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [exportImage addRepresentation:bitmapReps];
                        }
                        else if (tifImageColorGray == 1){
                            NSBitmapImageRep *bitmapReps = nil;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageDimension*4 bitsPerPixel:32];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                                value0 = uploadTemp [counter1];
                                value1 = uploadTemp [counter1+1];
                                value2 = uploadTemp [counter1+2];
                                
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value1;
                                *bitmapData++ = (unsigned char)value2;
                                *bitmapData++ = 0;
                            }
                            
                            exportImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                            [exportImage addRepresentation:bitmapReps];
                        }
                    }
                    else if (exType == ".bmp"){
                        fin.read((char*)uploadTemp, totalSize+1);
                        fin.close();
                        
                        NSBitmapImageRep *bitmapReps;
                        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageDimension pixelsHigh:imageDimension bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageDimension bitsPerPixel:8];
                        
                        unsigned char *bitmapData = [bitmapReps bitmapData];
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                *bitmapData++ = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                        }
                        
                        exportImage = [[NSImage alloc] initWithSize:NSMakeSize(imageDimension, imageDimension)];
                        [exportImage addRepresentation:bitmapReps];
                    }
                }
                
                delete [] uploadTemp;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Data Read Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
            }
        }
        
        if (proceedFlag == 1) [self setNeedsDisplay:YES];
    }
}

-(void)drawRect:(NSRect)rect{
    [[NSColor blackColor] set];
    
    NSBezierPath *path;
    path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 700, 700)];
    [path fill];
    
    NSRect srcRect;
    srcRect.origin.x = xPositionExport+xPositionAdjustExport+xPositionMoveExport;
    srcRect.origin.y = yPositionExport+yPositionAdjustExport+yPositionMoveExport;
    srcRect.size.width = imageWidthExport/(double)(magnificationExport*0.1);
    srcRect.size.height = imageHeightExport/(double)(magnificationExport*0.1);
    
    [exportImage drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
    
    NSPoint pointA;
    NSAttributedString *attrStrA;
    NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
    
    if (mouseDragFlag == 0 && imageEndHold != 0){
        double xPositionAdjustDouble = xPositionAdjustExport+xPositionExport;
        double yPositionAdjustDouble = yPositionAdjustExport+yPositionExport;
        double xCalculationValue = 1/(double)windowWidthExport*magnificationExport*0.1;
        double yCalculationValue = 1/(double)windowHeightExport*magnificationExport*0.1;
        double magnificationDisplay2 = magnificationExport*0.1*0.4*lineWidth;
        double magnificationLine = magnificationExport*0.1*2.0;
        double magnificationFont = magnificationExport*0.08*3.5*displayTargetFontSizeSet;
        
        // for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
        //     for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
        //    cout<<" arrayTimeSelected "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
        //      for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
        //     cout<<" arrayGravityCenterRev "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
        //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
        //    cout<<" arrayPositionRevise "<<counterA<<endl;
        //}
        
        double displayFrequencyTemp = (2-xPositionAdjustDouble)*xCalculationValue-(1-xPositionAdjustDouble)*xCalculationValue;
        int displayFrequency = (int)displayFrequencyTemp;
        
        if (lineTypeSet == 1){
            if (displayFrequencyTemp <= 0.3 && displayFrequencyTemp != 0) displayFrequency = (int)(9/(double)displayFrequencyTemp);
            else if (displayFrequencyTemp <= 0.5 && displayFrequencyTemp > 0.3) displayFrequency = (int)(7/(double)displayFrequencyTemp);
            else if (displayFrequencyTemp <= 1 && displayFrequencyTemp > 0.5) displayFrequency = (int)(5/(double)displayFrequencyTemp);
            else if (displayFrequencyTemp <= 2 && displayFrequencyTemp > 1) displayFrequency = 4;
            else if (displayFrequencyTemp <= 3 && displayFrequencyTemp > 2) displayFrequency = 3;
            else if (displayFrequencyTemp <= 4 && displayFrequencyTemp > 3) displayFrequency = 2;
            else if (displayFrequencyTemp > 4) displayFrequency = 1;
        }
        else{
            
            if (displayFrequencyTemp <= 0.3 && displayFrequencyTemp != 0) displayFrequency = (int)(8/(double)displayFrequencyTemp);
            else if (displayFrequencyTemp <= 0.5 && displayFrequencyTemp > 0.3) displayFrequency = (int)(6/(double)displayFrequencyTemp);
            else if (displayFrequencyTemp <= 1 && displayFrequencyTemp > 0.5) displayFrequency = (int)(4/(double)displayFrequencyTemp);
            else if (displayFrequencyTemp <= 2 && displayFrequencyTemp > 1) displayFrequency = 2;
            else if (displayFrequencyTemp <= 3 && displayFrequencyTemp > 2) displayFrequency = 1;
            else if (displayFrequencyTemp <= 4 && displayFrequencyTemp > 3) displayFrequency = 1;
            else if (displayFrequencyTemp > 4) displayFrequency = 1;
        }
        
        CGFloat sizeCalculation = 512*xCalculationValue;
        sizeCalculation = (sizeCalculation/(double)700)*0.5;
        
        if (sizeCalculation >= 3) sizeCalculation = 3;
        
        NSBezierPath *path3;
        
        NSPoint positionAA;
        NSPoint positionBB;
        NSPoint positionCC;
        NSPoint positionDD;
        
        //-----Whole line data, TrackingOn = 1, or TrackingOn = 3, outside of range-----
        [NSBezierPath setDefaultLineWidth:sizeCalculation];
        [attributesA setObject:[NSFont systemFontOfSize:magnificationFont] forKey:NSFontAttributeName];
        [attributesA removeObjectForKey:NSBackgroundColorAttributeName];
        
        int startPoint = 0;
        int endPoint = 0;
        int xPointMarkTemp = 0;
        int yPointMarkTemp = 0;
        int xPointMarkTemp2 = 0;
        int yPointMarkTemp2 = 0;
        int lineageNoExport = 0;
        double cellNoExport = 0;
        
        //for (int counterA = 0; counterA < positionExportCount/7; counterA++){
        //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionExport [counterA*7+counterB];
        //    cout<<" arrayPositionExport "<<counterA<<endl;
        //}
        
        if (displayOutlineSet == 1){
            for (int counter1 = 0; counter1 < timeSelectedExportCount/10; counter1++){
                if (arrayTimeSelectedExport [counter1*10] == 0 || arrayTimeSelectedExport [counter1*10] == 1 || arrayTimeSelectedExport [counter1*10] == 7){
                    startPoint = arrayTimeSelectedExport [counter1*10+2];
                    
                    if (counter1+1 < timeSelectedExportCount/10) endPoint = arrayTimeSelectedExport [(counter1+1)*10+2]-1;
                    else endPoint = timeSelectedExportCount/7-1;
                    
                    lineageNoExport = arrayTimeSelectedExport [counter1*10+9];
                    cellNoExport = arrayPositionExport [startPoint*7+4];
                    
                    for (int counter2 = startPoint; counter2 <= endPoint; counter2 = counter2+displayFrequency){
                        xPointMarkTemp = (int)((arrayPositionExport [counter2*7]-xPositionAdjustDouble)*(double)xCalculationValue);
                        yPointMarkTemp = (int)(((imageHeightExport-arrayPositionExport [counter2*7+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                        
                        if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                            if (exportColorStatus == 0 || lineageNoExport == 0){
                                [[NSColor greenColor] set];
                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                [path3 fill];
                            }
                            else{
                                
                                if (exportColorStatus == 1){
                                    [[NSColor colorWithCalibratedRed:colorList [lineageNoExport*4+1] green:colorList [lineageNoExport*4+2] blue:colorList [lineageNoExport*4+3] alpha:1] set];
                                    
                                    path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                    [path3 fill];
                                }
                                else if (exportColorStatus == 2){
                                    for (int counter3 = 0; counter3 < colorListCount; counter3++){
                                        if (cellNoHoldExport [counter3] == cellNoExport){
                                            [[NSColor colorWithCalibratedRed:colorList [counter3*4+1] green:colorList [counter3*4+2] blue:colorList [counter3*4+3] alpha:1] set];
                                            
                                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2, magnificationDisplay2)];
                                            [path3 fill];
                                            
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < masterLineGravityCenterCount/6; counterA++){
        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayMasterLineGravityCenter [counterA*6+counterB];
        //    cout<<" arrayMasterLineGravityCenter "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < associateDataCount/6; counterA++){
        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayAssociateData [counterA*6+counterB];
        //    cout<<" arrayAssociateData "<<counterA<<endl;
        //}
        
        NSString *vectorNumberDisplay;
        
        [[NSColor blackColor] set];
        [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        
        if (displayNonTargetSet == 1){
            for (int counter1 = 0; counter1 < timeSelectedExportCount/10; counter1++){
                if (arrayTimeSelectedExport [counter1*10] == 0 || arrayTimeSelectedExport [counter1*10] == 1 || arrayTimeSelectedExport [counter1*10] == 7){
                    if (arrayPositionExport [arrayTimeSelectedExport [counter1*10+2]*7+6] == 0){
                        xPointMarkTemp = (int)((arrayGravityCenterExport [counter1*6]-xPositionAdjustDouble)*(double)xCalculationValue);
                        yPointMarkTemp = (int)(((imageHeightExport-arrayGravityCenterExport [counter1*6+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                        
                        if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                            positionAA.x = xPointMarkTemp-magnificationLine;
                            positionAA.y = yPointMarkTemp;
                            positionBB.x = xPointMarkTemp+magnificationLine;
                            positionBB.y = yPointMarkTemp;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            
                            positionCC.x = xPointMarkTemp;
                            positionCC.y = yPointMarkTemp-magnificationLine;
                            positionDD.x = xPointMarkTemp;
                            positionDD.y = yPointMarkTemp+magnificationLine;
                            [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                            
                            vectorNumberDisplay = [NSString stringWithFormat:@"%d", arrayGravityCenterExport [counter1*6+4]];
                            
                            attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                            
                            pointA.x = xPointMarkTemp+magnificationLine*0.3;
                            pointA.y = yPointMarkTemp+magnificationLine*0.3;
                            [attrStrA drawAtPoint:pointA];
                        }
                    }
                }
            }
        }
        
        string extension2 = "";
        string eventString = "";
        
        if (timeSelectedExportCount != 0){
            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                if (imageNumberExportForDisplay >= arrayLineageStartEnd [counter1*8+5] && imageNumberExportForDisplay <= arrayLineageStartEnd [counter1*8+7]){
                    for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                        xPointMarkTemp = (int)((arrayLineageData [counter2*8]-xPositionAdjustDouble)*(double)xCalculationValue);
                        yPointMarkTemp = (int)(((imageHeightExport-arrayLineageData [counter2*8+1])-yPositionAdjustDouble)*(double)yCalculationValue);
                        
                        if (xPointMarkTemp >= 0 && xPointMarkTemp <= 700 && yPointMarkTemp >= 0 && yPointMarkTemp <= 700){
                            //-----Event type 1: I, 2: P, DStart:31, DEnd: 32, 33, 34, TStart:41, TEnd: 42, 43, 44, HStart: 51, HEnd: 52, 53, 54, 55, M: 6, CD: 7, OF: 8, FUEnd: 91, FUCont: 92-----
                            //-----FMark: 10, MD: 11, EF: 12, NE: 13 (in the event that cell enter image, create Dummy entry mark in Time One)-----
                            
                            if (arrayLineageData [counter2*8+2] == imageNumberExportForDisplay && arrayLineageData [counter2*8+3] != 13){
                                extension2 = to_string(arrayLineageData [counter2*8+6]);
                                
                                if (extension2.length() == 1) extension2 = "L0000"+extension2+eventString;
                                else if (extension2.length() == 2) extension2 = "L000"+extension2+eventString;
                                else if (extension2.length() == 3) extension2 = "L00"+extension2+eventString;
                                else if (extension2.length() == 4) extension2 = "L0"+extension2+eventString;
                                else if (extension2.length() == 5) extension2 = "L"+extension2+eventString;
                                
                                vectorNumberDisplay = @(extension2.c_str());
                                
                                if (exportColorStatus == 0){
                                    [[NSColor orangeColor] set];
                                    [attributesA setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                                    
                                    positionAA.x = xPointMarkTemp-magnificationLine;
                                    positionAA.y = yPointMarkTemp;
                                    positionBB.x = xPointMarkTemp+magnificationLine;
                                    positionBB.y = yPointMarkTemp;
                                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                    
                                    positionCC.x = xPointMarkTemp;
                                    positionCC.y = yPointMarkTemp-magnificationLine;
                                    positionDD.x = xPointMarkTemp;
                                    positionDD.y = yPointMarkTemp+magnificationLine;
                                    [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                                }
                                else{
                                    
                                    if (exportColorStatus == 1){
                                        [[NSColor colorWithCalibratedRed:colorList [arrayLineageData [counter2*8+6]*4+1] green:colorList [arrayLineageData [counter2*8+6]*4+2] blue:colorList [arrayLineageData [counter2*8+6]*4+3] alpha:1] set];
                                        [attributesA setObject:[NSColor colorWithCalibratedRed:colorList [arrayLineageData [counter2*8+6]*4+1] green:colorList [arrayLineageData [counter2*8+6]*4+2] blue:colorList [arrayLineageData [counter2*8+6]*4+3] alpha:1] forKey: NSForegroundColorAttributeName];
                                        
                                        positionAA.x = xPointMarkTemp-magnificationLine;
                                        positionAA.y = yPointMarkTemp;
                                        positionBB.x = xPointMarkTemp+magnificationLine;
                                        positionBB.y = yPointMarkTemp;
                                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                        
                                        positionCC.x = xPointMarkTemp;
                                        positionCC.y = yPointMarkTemp-magnificationLine;
                                        positionDD.x = xPointMarkTemp;
                                        positionDD.y = yPointMarkTemp+magnificationLine;
                                        [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                                    }
                                    else if (exportColorStatus == 2){
                                        for (int counter3 = 0; counter3 < colorListCount; counter3++){
                                            if (cellNoHoldExport [counter3] == arrayLineageData [counter2*8+5]){
                                                [[NSColor colorWithCalibratedRed:colorList [counter3*4+1] green:colorList [counter3*4+2] blue:colorList [counter3*4+3] alpha:1] set];
                                                [attributesA setObject:[NSColor colorWithCalibratedRed:colorList [counter3*4+1] green:colorList [counter3*4+2] blue:colorList [counter3*4+3] alpha:1] forKey: NSForegroundColorAttributeName];
                                                
                                                positionAA.x = xPointMarkTemp-magnificationLine;
                                                positionAA.y = yPointMarkTemp;
                                                positionBB.x = xPointMarkTemp+magnificationLine;
                                                positionBB.y = yPointMarkTemp;
                                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                                
                                                positionCC.x = xPointMarkTemp;
                                                positionCC.y = yPointMarkTemp-magnificationLine;
                                                positionDD.x = xPointMarkTemp;
                                                positionDD.y = yPointMarkTemp+magnificationLine;
                                                [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                                                
                                                break;
                                            }
                                        }
                                    }
                                }
                                
                                attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                                pointA.x = xPointMarkTemp+magnificationLine*0.3;
                                pointA.y = yPointMarkTemp+magnificationLine*0.3;
                                [attrStrA drawAtPoint:pointA];
                            }
                        }
                    }
                }
            }
        }
        
        if (lineTraceOnOff == 1){
            for (int counter1 = 0; counter1 < lineTraceCount/8; counter1++){
                if (treatmentNameHold == arrayLineTrace [counter1*8+6]){
                    if (arrayLineTrace [counter1*8+7] == "s"){
                        [[NSColor blueColor] set];
                    }
                    else [[NSColor redColor] set];
                    
                    [NSBezierPath setDefaultLineWidth:2];
                    
                    xPointMarkTemp = (int)((atoi(arrayLineTrace [counter1*8].c_str())-xPositionAdjustDouble)*(double)xCalculationValue);
                    yPointMarkTemp = (int)(((imageHeightExport-atoi(arrayLineTrace [counter1*8+1].c_str()))-yPositionAdjustDouble)*(double)yCalculationValue);
                    
                    xPointMarkTemp2 = (int)((atoi(arrayLineTrace [counter1*8+3].c_str())-xPositionAdjustDouble)*(double)xCalculationValue);
                    yPointMarkTemp2 = (int)(((imageHeightExport-atoi(arrayLineTrace [counter1*8+4].c_str()))-yPositionAdjustDouble)*(double)yCalculationValue);
                    
                    positionAA.x = xPointMarkTemp;
                    positionAA.y = yPointMarkTemp;
                    positionBB.x = xPointMarkTemp2;
                    positionBB.y = yPointMarkTemp2;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
            }
        }
       
        //-----Info writing-----
        [attributesA setObject:[NSFont boldSystemFontOfSize:12] forKey:NSFontAttributeName];
        [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
        
        string ifString;
        
        [[NSColor blackColor] set];
        [NSBezierPath setDefaultLineWidth:1];
        
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(620, 680, 60, 14)];
        [path fill];
        
        [[NSColor greenColor] set];
        [NSBezierPath setDefaultLineWidth:1];
        
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(620, 680, 60, 14)];
        [path stroke];
        
        ifString = "Reload";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
        pointA.x = 630;
        pointA.y = 680;
        [attrStrA drawAtPoint:pointA];
        
        [[NSColor blackColor] set];
        [NSBezierPath setDefaultLineWidth:1];
        
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(550, 680, 60, 14)];
        [path fill];
        
        [[NSColor greenColor] set];
        [NSBezierPath setDefaultLineWidth:1];
        
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(550, 680, 60, 14)];
        [path stroke];
        
        if (exportColorStatus == 0){
            ifString = "Single";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 563;
            pointA.y = 680;
            [attrStrA drawAtPoint:pointA];
        }
        else if (exportColorStatus == 1){
            ifString = "LColor";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 563;
            pointA.y = 680;
            [attrStrA drawAtPoint:pointA];
        }
        else if (exportColorStatus == 2){
            ifString = "CColor";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 563;
            pointA.y = 680;
            [attrStrA drawAtPoint:pointA];
        }
        
        [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
        
        if (channelNoExport == 0) ifString = "Ch: DIC";
        else if (channelNoExport == 1) ifString = "Ch: 1";
        else if (channelNoExport == 2) ifString = "Ch: 2";
        else if (channelNoExport == 3) ifString = "Ch: 3";
        else if (channelNoExport == 4) ifString = "Ch: 4";
        else if (channelNoExport == 5) ifString = "Ch: 5";
        else if (channelNoExport == 6) ifString = "Ch: 6";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
        pointA.x = 250;
        pointA.y = 685;
        [attrStrA drawAtPoint:pointA];
        [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
        
        if (windowLockEX == 1){
            ifString = "Lock";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 320;
            pointA.y = 685;
            [attrStrA drawAtPoint:pointA];
            [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
        }
        
        if (densityModeHold == 1){
            ifString = "Density";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 390;
            pointA.y = 685;
            [attrStrA drawAtPoint:pointA];
            [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
        }
        else if (motilityStatusHold == 1){
            ifString = "Motility";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 390;
            pointA.y = 685;
            [attrStrA drawAtPoint:pointA];
            [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
        }
        else if (thresholdStatusHold == 1){
            ifString = "TH image";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 390;
            pointA.y = 685;
            [attrStrA drawAtPoint:pointA];
            [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
        }
        
        string infoDisplayString = "Time: "+to_string(imageNumberExportForDisplay);
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 10;
        pointA.y = 685;
        [attrStrA drawAtPoint:pointA];
        
        infoDisplayString = "Treatment: "+treatmentNameHold;
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
        pointA.x = 80;
        pointA.y = 685;
        [attrStrA drawAtPoint:pointA];
        
        if (windowLockEX == 1){
            NSBezierPath *path2;
            path2 = [NSBezierPath bezierPathWithRect: NSMakeRect(boxStartX, boxStartY, boxEndX-boxStartX, boxEndY-boxStartY)];
            [path2 stroke];
        }
        
        if (lineTraceOnOff == 1){
             if (lineTraceActive >= 1){
                
                if (lineTraceActive == 1 || lineTraceActive == 2){
                    [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                    
                    ifString = "Click Start Position";
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
                    pointA.x = 10;
                    pointA.y = 10;
                    [attrStrA drawAtPoint:pointA];
                }
                
                if (lineTraceStartX != -1){
                    [[NSColor redColor] set];
                    
                    xPointMarkTemp = (int)((lineTraceStartX-xPositionAdjustDouble)*(double)xCalculationValue);
                    yPointMarkTemp = (int)(((imageHeightExport-lineTraceStartY)-yPositionAdjustDouble)*(double)yCalculationValue);
                    
                    path = [NSBezierPath bezierPathWithOvalInRect: NSMakeRect(xPointMarkTemp, yPointMarkTemp, magnificationDisplay2*10, magnificationDisplay2*10)];
                    [path fill];
                }
            }
            
            if (lineTraceActive == 3){
                [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                
                ifString = "Click End Position";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
                pointA.x = 10;
                pointA.y = 10;
                [attrStrA drawAtPoint:pointA];
                
                if (lineTraceEndX != -1){
                    xPointMarkTemp = (int)((lineTraceStartX-xPositionAdjustDouble)*(double)xCalculationValue);
                    yPointMarkTemp = (int)(((imageHeightExport-lineTraceStartY)-yPositionAdjustDouble)*(double)yCalculationValue);
                    
                    xPointMarkTemp2 = (int)((lineTraceEndX-xPositionAdjustDouble)*(double)xCalculationValue);
                    yPointMarkTemp2 = (int)(((imageHeightExport-lineTraceEndY)-yPositionAdjustDouble)*(double)yCalculationValue);
                    
                    [[NSColor greenColor] set];
                    
                    path = [NSBezierPath bezierPathWithOvalInRect: NSMakeRect(xPointMarkTemp2, yPointMarkTemp2, magnificationDisplay2*10, magnificationDisplay2*10)];
                    [path fill];
                    
                    positionAA.x = xPointMarkTemp;
                    positionAA.y = yPointMarkTemp;
                    positionBB.x = xPointMarkTemp2;
                    positionBB.y = yPointMarkTemp2;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
            }
            
            if (lineTraceDeleteOn == 1){
                [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                
                ifString = "Delete: Click Start or End Position";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
                pointA.x = 10;
                pointA.y = 10;
                [attrStrA drawAtPoint:pointA];
            }
        }
    }
   
    if (displayModeSelect != 0){
        int imageNoEx = atoi(displayImageLoadPath.substr(displayImageLoadPath.find("STimage ")+8, 4).c_str());
        int imageDimensionReadCount = 0;
        int xImageStart = -1;
        int yImageStart = -1;
        int xImageEnd = -1;
        int yImageEnd = -1;
        int xImageSizeEX = 0;
        int yImageSizeEX = 0;
        int yImageStartFr = -1;
        int yImageEndFr = -1;
        int xImageEndTH = -1;
        
        if (windowLockEX == 1){
            if (boxStartImageX > boxEndImageX && boxStartImageX-boxEndImageX > 50){
                xImageStart = (int)boxEndImageX;
                xImageEnd = (int)boxStartImageX;
                xImageSizeEX = (int)(boxStartImageX-boxEndImageX);
            }
            else if (boxStartImageX <= boxEndImageX && boxEndImageX-boxStartImageX > 50){
                xImageStart = (int)boxStartImageX;
                xImageEnd = (int)boxEndImageX;
                xImageSizeEX = (int)(boxEndImageX-boxStartImageX);
            }
            
            if (boxStartImageY > boxEndImageY && boxStartImageY-boxEndImageY > 50){
                yImageEnd = (int)(imageDimension-boxEndImageY);
                yImageStart = (int)(imageDimension-boxStartImageY);
                yImageSizeEX = (int)(boxStartImageY-boxEndImageY);
                
                yImageStartFr = (int)boxEndImageY;
                yImageEndFr = (int)boxStartImageY;
            }
            else if (boxStartImageY <= boxEndImageY && boxEndImageY-boxStartImageY > 50){
                yImageEnd = (int)(imageDimension-boxStartImageY);
                yImageStart = (int)(imageDimension-boxEndImageY);
                yImageSizeEX = (int)(boxEndImageY-boxStartImageY);
                
                yImageStartFr = (int)boxStartImageY;
                yImageEndFr = (int)boxEndImageY;
            }
        }
        
        if (thresholdStatusHold == 1 && xImageSizeEX <= 1000 && yImageSizeEX <= 1000){
            xImageEndTH = xImageSizeEX*2;
        }
        else xImageEndTH = xImageSizeEX;
        
        //cout<<xImageStart<<" "<<yImageStart<<" "<<xImageEnd<<" "<<yImageEnd<<" "<<xImageEndTH<<" dim"<<endl;
        
        if (xImageStart == -1 || yImageStart == -1 || xImageEnd == -1 || yImageEnd == -1){
            xImageStart = 0;
            yImageStart = 0;
            xImageEnd = imageDimension;
            yImageEnd = imageDimension;
            xImageSizeEX = imageDimension;
            yImageSizeEX = imageDimension;
            yImageStartFr = 0;
            yImageEndFr = imageDimension;
            xImageEndTH = xImageSizeEX;
        }
        
        int **densityMapHold = new int *[yImageSizeEX+1];
        
        for (int counter1 = 0; counter1 < yImageSizeEX+1; counter1++){
            densityMapHold [counter1] = new int [xImageSizeEX+1];
        }
        
        for (int counter1 = 0; counter1 < yImageSizeEX+1; counter1++){
            for (int counter2 = 0; counter2 < xImageSizeEX+1; counter2++){
                densityMapHold [counter1][counter2] = 0;
            }
        }
        
        ifstream fin;
        struct stat sizeOfFile;
        
        long sizeForCopy = 0;
        
        NSBitmapImageRep *bitmapReps;
        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:xImageEndTH pixelsHigh:yImageSizeEX bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:xImageEndTH*4 bitsPerPixel:32];
        
        unsigned char *bitmapData = [bitmapReps bitmapData];
        
        if (colorNoExport == 0){
            if (stat(displayImageLoadPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                if (exType == ".tif" || exTypeIF == ".TIF"){
                    int dataConversion [4];
                    int endianType = 0;
                    int imageWidthEntry = 0;
                    unsigned long headPosition = 0;
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(displayImageLoadPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        imageDimensionReadCount = 0;
                        imageWidthEntry = 0;
                    
                        for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                            if (imageDimensionReadCount >= yImageStart && imageDimensionReadCount < yImageEnd){
                                if (imageWidthEntry >= xImageStart && imageWidthEntry < xImageEnd){
                                    *bitmapData++ = uploadTemp [counter3];
                                    *bitmapData++ = uploadTemp [counter3];
                                    *bitmapData++ = uploadTemp [counter3];
                                    *bitmapData++ = 0;
                                }
                                
                                if (xImageEndTH > xImageSizeEX){
                                    for (int counter2 = xImageStart; counter2 < xImageEnd; counter2++){
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                        *bitmapData++ = 0;
                                        
                                        densityMapHold [imageDimensionReadCount-yImageStart][imageWidthEntry-xImageStart] = uploadTemp [counter3];
                                    }
                                }
                            }
                            
                            imageWidthEntry++;
                           
                            if (imageWidthEntry == imageDimension){
                                imageWidthEntry = 0;
                                imageDimensionReadCount++;
                            }
                        }
                    }
                    
                    delete [] uploadTemp;
                }
                else if (exType == ".bmp" || exTypeIF == ".BMP"){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(displayImageLoadPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        for (int counter1 = yImageEnd-1; counter1 >= yImageStart; counter1--){
                            for (int counter2 = xImageStart; counter2 < xImageEnd; counter2++){
                                *bitmapData++ = uploadTemp [1078+counter1*imageDimension+counter2];
                                *bitmapData++ = uploadTemp [1078+counter1*imageDimension+counter2];
                                *bitmapData++ = uploadTemp [1078+counter1*imageDimension+counter2];
                                *bitmapData++ = 0;
                            }
                            
                            if (xImageEndTH > xImageSizeEX){
                                for (int counter2 = xImageStart; counter2 < xImageEnd; counter2++){
                                    *bitmapData++ = 0;
                                    *bitmapData++ = 0;
                                    *bitmapData++ = 0;
                                    *bitmapData++ = 0;
                                    
                                    densityMapHold [counter1-yImageStart][counter2-xImageStart] = uploadTemp [1078+counter1*imageDimension+counter2];
                                }
                            }
                            
                            imageDimensionReadCount++;
                        }
                    }
                    
                    delete [] uploadTemp;
                }
            }
        }
        else if (colorNoExport >= 1 && colorNoExport <= 12){
            int **connectMapTemp = new int *[imageDimension+1];
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) connectMapTemp [counter1] = new int [imageDimension+1];
            
            sizeForCopy = 0;
            
            if (stat(displayImageLoadPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (sizeForCopy != 0){
                if (exType == ".tif" || exTypeIF == ".TIF"){
                    int dataConversion [4];
                    int endianType = 0;
                    int imageWidthEntry = 0;
                    unsigned long headPosition = 0;
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(displayImageLoadPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        imageDimensionReadCount = 0;
                        imageWidthEntry = 0;
                        
                        for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                            connectMapTemp [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                            
                            if (imageWidthEntry == imageDimension){
                                imageWidthEntry = 0;
                                imageDimensionReadCount++;
                            }
                        }
                    }
                    
                    delete [] uploadTemp;
                }
                else if (exType == ".bmp" || exTypeIF == ".BMP"){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(displayImageLoadPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        imageDimensionReadCount = 0;
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                connectMapTemp [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                            
                            imageDimensionReadCount++;
                        }
                    }
                    
                    delete [] uploadTemp;
                }
            }
            
            int fluorescentCutOffExport1 = 150;
            int fluorescentCutOffExport2 = 150;
            int fluorescentCutOffExport3 = 150;
            int fluorescentCutOffExport4 = 150;
            int fluorescentCutOffExport5 = 150;
            int fluorescentCutOffExport6 = 150;
            
            for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                if (arrayFluorescentCutOff [counter1*7] == imageNoEx){
                    fluorescentCutOffExport1 = arrayFluorescentCutOff [counter1*7+1];
                    fluorescentCutOffExport2 = arrayFluorescentCutOff [counter1*7+2];
                    fluorescentCutOffExport3 = arrayFluorescentCutOff [counter1*7+3];
                    fluorescentCutOffExport4 = arrayFluorescentCutOff [counter1*7+4];
                    fluorescentCutOffExport5 = arrayFluorescentCutOff [counter1*7+5];
                    fluorescentCutOffExport6 = arrayFluorescentCutOff [counter1*7+6];
                    break;
                }
            }
            
            NSUInteger zColorrArray [3];
            
            int inc1 = 0;
            int inc2 = 0;
            int readDataTemp = 0;
            
            if (displayModeSelect == 1) channelNoOfExportImage = channelNoExport;
            
            if (colorNoExport == 1){
                for (int counterY = yImageStartFr; counterY < yImageEndFr; counterY++){
                    for (int counterX = xImageStart; counterX < xImageEnd; counterX++){
                        readDataTemp = connectMapTemp [counterY][counterX];
                        
                        if (channelNoOfExportImage == 1 && readDataTemp < fluorescentCutOffExport1) readDataTemp = 0;
                        else if (channelNoOfExportImage == 2 && readDataTemp < fluorescentCutOffExport2) readDataTemp = 0;
                        else if (channelNoOfExportImage == 3 && readDataTemp < fluorescentCutOffExport3) readDataTemp = 0;
                        else if (channelNoOfExportImage == 4 && readDataTemp < fluorescentCutOffExport4) readDataTemp = 0;
                        else if (channelNoOfExportImage == 5 && readDataTemp < fluorescentCutOffExport5) readDataTemp = 0;
                        else if (channelNoOfExportImage == 6 && readDataTemp < fluorescentCutOffExport6) readDataTemp = 0;
                        
                        zColorrArray [0] = 0;
                        zColorrArray [1] = 0;
                        zColorrArray [2] = (NSUInteger)readDataTemp;
                        
                        [bitmapReps setPixel:zColorrArray atX:inc1 y:inc2];
                        
                        inc1++;
                    }
                    
                    inc1 = 0;
                    inc2++;
                }
            }
            else if (colorNoExport == 2){
                for (int counterY = yImageStartFr; counterY < yImageEndFr; counterY++){
                    for (int counterX = xImageStart; counterX < xImageEnd; counterX++){
                        readDataTemp = connectMapTemp [counterY][counterX];
                        
                        if (channelNoOfExportImage == 1 && readDataTemp < fluorescentCutOffExport1) readDataTemp = 0;
                        else if (channelNoOfExportImage == 2 && readDataTemp < fluorescentCutOffExport2) readDataTemp = 0;
                        else if (channelNoOfExportImage == 3 && readDataTemp < fluorescentCutOffExport3) readDataTemp = 0;
                        else if (channelNoOfExportImage == 4 && readDataTemp < fluorescentCutOffExport4) readDataTemp = 0;
                        else if (channelNoOfExportImage == 5 && readDataTemp < fluorescentCutOffExport5) readDataTemp = 0;
                        else if (channelNoOfExportImage == 6 && readDataTemp < fluorescentCutOffExport6) readDataTemp = 0;
                        
                        zColorrArray [0] = 0;
                        zColorrArray [1] = (NSUInteger)readDataTemp;
                        zColorrArray [2] = 0;
                        
                        [bitmapReps setPixel:zColorrArray atX:inc1 y:inc2];
                        
                        inc1++;
                    }
                    
                    inc1 = 0;
                    inc2++;
                }
            }
            else if (colorNoExport == 3){
                for (int counterY = yImageStartFr; counterY < yImageEndFr; counterY++){
                    for (int counterX = xImageStart; counterX < xImageEnd; counterX++){
                        readDataTemp = connectMapTemp [counterY][counterX];
                        
                        if (channelNoOfExportImage == 1 && readDataTemp < fluorescentCutOffExport1) readDataTemp = 0;
                        else if (channelNoOfExportImage == 2 && readDataTemp < fluorescentCutOffExport2) readDataTemp = 0;
                        else if (channelNoOfExportImage == 3 && readDataTemp < fluorescentCutOffExport3) readDataTemp = 0;
                        else if (channelNoOfExportImage == 4 && readDataTemp < fluorescentCutOffExport4) readDataTemp = 0;
                        else if (channelNoOfExportImage == 5 && readDataTemp < fluorescentCutOffExport5) readDataTemp = 0;
                        else if (channelNoOfExportImage == 6 && readDataTemp < fluorescentCutOffExport6) readDataTemp = 0;
                        
                        zColorrArray [0] = (NSUInteger)readDataTemp;
                        zColorrArray [1] = (NSUInteger)readDataTemp;
                        zColorrArray [2] = 0;
                        
                        [bitmapReps setPixel:zColorrArray atX:inc1 y:inc2];
                        
                        inc1++;
                    }
                    
                    inc1 = 0;
                    inc2++;
                }
            }
            else if (colorNoExport == 4){
                for (int counterY = yImageStartFr; counterY < yImageEndFr; counterY++){
                    for (int counterX = xImageStart; counterX < xImageEnd; counterX++){
                        readDataTemp = connectMapTemp [counterY][counterX];
                        
                        if (channelNoOfExportImage == 1 && readDataTemp < fluorescentCutOffExport1) readDataTemp = 0;
                        else if (channelNoOfExportImage == 2 && readDataTemp < fluorescentCutOffExport2) readDataTemp = 0;
                        else if (channelNoOfExportImage == 3 && readDataTemp < fluorescentCutOffExport3) readDataTemp = 0;
                        else if (channelNoOfExportImage == 4 && readDataTemp < fluorescentCutOffExport4) readDataTemp = 0;
                        else if (channelNoOfExportImage == 5 && readDataTemp < fluorescentCutOffExport5) readDataTemp = 0;
                        else if (channelNoOfExportImage == 6 && readDataTemp < fluorescentCutOffExport6) readDataTemp = 0;
                        
                        zColorrArray [0] = (NSUInteger)readDataTemp;
                        zColorrArray [1] = 0;
                        zColorrArray [2] = 0;
                        
                        [bitmapReps setPixel:zColorrArray atX:inc1 y:inc2];
                        
                        inc1++;
                    }
                    
                    inc1 = 0;
                    inc2++;
                }
            }
            else if (colorNoExport == 5){
                for (int counterY = yImageStartFr; counterY < yImageEndFr; counterY++){
                    for (int counterX = xImageStart; counterX < xImageEnd; counterX++){
                        readDataTemp = connectMapTemp [counterY][counterX];
                        
                        if (channelNoOfExportImage == 1 && readDataTemp < fluorescentCutOffExport1) readDataTemp = 0;
                        else if (channelNoOfExportImage == 2 && readDataTemp < fluorescentCutOffExport2) readDataTemp = 0;
                        else if (channelNoOfExportImage == 3 && readDataTemp < fluorescentCutOffExport3) readDataTemp = 0;
                        else if (channelNoOfExportImage == 4 && readDataTemp < fluorescentCutOffExport4) readDataTemp = 0;
                        else if (channelNoOfExportImage == 5 && readDataTemp < fluorescentCutOffExport5) readDataTemp = 0;
                        else if (channelNoOfExportImage == 6 && readDataTemp < fluorescentCutOffExport6) readDataTemp = 0;
                        
                        zColorrArray [0] = (NSUInteger)readDataTemp;
                        zColorrArray [1] = 0;
                        zColorrArray [2] = (NSUInteger)readDataTemp;
                        
                        [bitmapReps setPixel:zColorrArray atX:inc1 y:inc2];
                        
                        inc1++;
                    }
                    
                    inc1 = 0;
                    inc2++;
                }
            }
            else if (colorNoExport == 6){
                for (int counterY = yImageStartFr; counterY < yImageEndFr; counterY++){
                    for (int counterX = xImageStart; counterX < xImageEnd; counterX++){
                        readDataTemp = connectMapTemp [counterY][counterX];
                        
                        if (channelNoOfExportImage == 1 && readDataTemp < fluorescentCutOffExport1) readDataTemp = 0;
                        else if (channelNoOfExportImage == 2 && readDataTemp < fluorescentCutOffExport2) readDataTemp = 0;
                        else if (channelNoOfExportImage == 3 && readDataTemp < fluorescentCutOffExport3) readDataTemp = 0;
                        else if (channelNoOfExportImage == 4 && readDataTemp < fluorescentCutOffExport4) readDataTemp = 0;
                        else if (channelNoOfExportImage == 5 && readDataTemp < fluorescentCutOffExport5) readDataTemp = 0;
                        else if (channelNoOfExportImage == 6 && readDataTemp < fluorescentCutOffExport6) readDataTemp = 0;
                        
                        zColorrArray [0] = 0;
                        zColorrArray [1] = (NSUInteger)readDataTemp;
                        zColorrArray [2] = (NSUInteger)readDataTemp;
                        
                        [bitmapReps setPixel:zColorrArray atX:inc1 y:inc2];
                        
                        inc1++;
                    }
                    
                    inc1 = 0;
                    inc2++;
                }
            }
            else if (colorNoExport == 7){
                for (int counterY = yImageStartFr; counterY < yImageEndFr; counterY++){
                    for (int counterX = xImageStart; counterX < xImageEnd; counterX++){
                        readDataTemp = connectMapTemp [counterY][counterX];
                        
                        if (channelNoOfExportImage == 1 && readDataTemp < fluorescentCutOffExport1) readDataTemp = 0;
                        else if (channelNoOfExportImage == 2 && readDataTemp < fluorescentCutOffExport2) readDataTemp = 0;
                        else if (channelNoOfExportImage == 3 && readDataTemp < fluorescentCutOffExport3) readDataTemp = 0;
                        else if (channelNoOfExportImage == 4 && readDataTemp < fluorescentCutOffExport4) readDataTemp = 0;
                        else if (channelNoOfExportImage == 5 && readDataTemp < fluorescentCutOffExport5) readDataTemp = 0;
                        else if (channelNoOfExportImage == 6 && readDataTemp < fluorescentCutOffExport6) readDataTemp = 0;
                        
                        zColorrArray [0] = (NSUInteger)readDataTemp;
                        zColorrArray [1] = (NSUInteger)(readDataTemp*(double)0.674);
                        zColorrArray [2] = 0;
                        
                        [bitmapReps setPixel:zColorrArray atX:inc1 y:inc2];
                        
                        inc1++;
                    }
                    
                    inc1 = 0;
                    inc2++;
                }
            }
            else if (colorNoExport == 8){
                for (int counterY = yImageStartFr; counterY < yImageEndFr; counterY++){
                    for (int counterX = xImageStart; counterX < xImageEnd; counterX++){
                        readDataTemp = connectMapTemp [counterY][counterX];
                        
                        if (channelNoOfExportImage == 1 && readDataTemp < fluorescentCutOffExport1) readDataTemp = 0;
                        else if (channelNoOfExportImage == 2 && readDataTemp < fluorescentCutOffExport2) readDataTemp = 0;
                        else if (channelNoOfExportImage == 3 && readDataTemp < fluorescentCutOffExport3) readDataTemp = 0;
                        else if (channelNoOfExportImage == 4 && readDataTemp < fluorescentCutOffExport4) readDataTemp = 0;
                        else if (channelNoOfExportImage == 5 && readDataTemp < fluorescentCutOffExport5) readDataTemp = 0;
                        else if (channelNoOfExportImage == 6 && readDataTemp < fluorescentCutOffExport6) readDataTemp = 0;
                        
                        zColorrArray [0] = (NSUInteger)(readDataTemp*(double)0.627);
                        zColorrArray [1] = (NSUInteger)(readDataTemp*(double)0.125);
                        zColorrArray [2] = (NSUInteger)(readDataTemp*(double)0.941);
                        
                        [bitmapReps setPixel:zColorrArray atX:inc1 y:inc2];
                        
                        inc1++;
                    }
                    
                    inc1 = 0;
                    inc2++;
                }
            }
            else if (colorNoExport == 9){
                for (int counterY = yImageStartFr; counterY < yImageEndFr; counterY++){
                    for (int counterX = xImageStart; counterX < xImageEnd; counterX++){
                        readDataTemp = connectMapTemp [counterY][counterX];
                        
                        if (channelNoOfExportImage == 1 && readDataTemp < fluorescentCutOffExport1) readDataTemp = 0;
                        else if (channelNoOfExportImage == 2 && readDataTemp < fluorescentCutOffExport2) readDataTemp = 0;
                        else if (channelNoOfExportImage == 3 && readDataTemp < fluorescentCutOffExport3) readDataTemp = 0;
                        else if (channelNoOfExportImage == 4 && readDataTemp < fluorescentCutOffExport4) readDataTemp = 0;
                        else if (channelNoOfExportImage == 5 && readDataTemp < fluorescentCutOffExport5) readDataTemp = 0;
                        else if (channelNoOfExportImage == 6 && readDataTemp < fluorescentCutOffExport6) readDataTemp = 0;
                        
                        zColorrArray [0] = (NSUInteger)(readDataTemp*(double)0.529);
                        zColorrArray [1] = (NSUInteger)(readDataTemp*(double)0.808);
                        zColorrArray [2] = (NSUInteger)(readDataTemp*(double)0.922);
                        
                        [bitmapReps setPixel:zColorrArray atX:inc1 y:inc2];
                        
                        inc1++;
                    }
                    
                    inc1 = 0;
                    inc2++;
                }
            }
            
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] connectMapTemp [counter1];
            delete [] connectMapTemp;
        }
        
        int center = (densityDiameterHold/2)+1;
        
        string connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+pathExtension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
        
        long size1 = 0;
        long size2 = 0;
        int checkFlag = 0;
        int readingError = 0;
        
        for (int counter4 = 0; counter4 < 6; counter4++){
            sizeForCopy = 0;
            
            if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (sizeForCopy != 0){
                if (counter4 == 0) size1 = sizeForCopy;
                else if (counter4 == 1) size2 = sizeForCopy;
                else if (counter4 == 2){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                        break;
                    }
                    else{
                        
                        size1 = 0;
                        size2 = 0;
                        usleep (50000);
                    }
                }
                else if (counter4 == 3) size1 = sizeForCopy;
                else if (counter4 == 4) size2 = sizeForCopy;
                else if (counter4 == 5){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                    }
                }
            }
        }
        
        int finData [20];
        
        int *arrayPositionExportTemp = new int [sizeForCopy+50];
        int positionExportTempCount = 0;
        
        int *arrayGravityCenterExportTemp = new int [sizeForCopy+50];
        int gravityCenterExportTempCount = 0;
        
        if (checkFlag == 1){
            fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            readingError = 1;
                        }
                    }
                }
                
                fin.close();
                
                if (readingError == 0){
                    int readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++;
                            finData [11] = uploadTemp [readPosition], readPosition++;
                            finData [12] = uploadTemp [readPosition], readPosition++; //--5
                            finData [13] = uploadTemp [readPosition], readPosition++; //--6
                            finData [14] = uploadTemp [readPosition], readPosition++;
                            finData [15] = uploadTemp [readPosition], readPosition++;
                            finData [16] = uploadTemp [readPosition], readPosition++; //--7
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            
                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                            
                            finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                            else{
                                
                                arrayPositionExportTemp [positionExportTempCount] = finData [1], positionExportTempCount++;
                                arrayPositionExportTemp [positionExportTempCount] = finData [3], positionExportTempCount++;
                                arrayPositionExportTemp [positionExportTempCount] = finData [4], positionExportTempCount++;
                                arrayPositionExportTemp [positionExportTempCount] = finData [7], positionExportTempCount++;
                                arrayPositionExportTemp [positionExportTempCount] = finData [12], positionExportTempCount++;
                                arrayPositionExportTemp [positionExportTempCount] = finData [13], positionExportTempCount++;
                                arrayPositionExportTemp [positionExportTempCount] = finData [16], positionExportTempCount++;
                            }
                        }
                        else if (stepCount == 1){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++;
                            finData [9] = uploadTemp [readPosition], readPosition++; //--5
                            finData [10] = uploadTemp [readPosition], readPosition++; //--6
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            finData [9] = finData [8]*256+finData [9];
                            
                            if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                        }
                        else if (stepCount == 2){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++; //--3
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++;
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++; //--5
                            finData [11] = uploadTemp [readPosition], readPosition++; //--6
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                            else{
                                
                                arrayGravityCenterExportTemp [gravityCenterExportTempCount] = finData [1], gravityCenterExportTempCount++;
                                arrayGravityCenterExportTemp [gravityCenterExportTempCount] = finData [3], gravityCenterExportTempCount++;
                                arrayGravityCenterExportTemp [gravityCenterExportTempCount] = finData [6], gravityCenterExportTempCount++;
                                arrayGravityCenterExportTemp [gravityCenterExportTempCount] = finData [7], gravityCenterExportTempCount++;
                                arrayGravityCenterExportTemp [gravityCenterExportTempCount] = finData [10], gravityCenterExportTempCount++;
                                arrayGravityCenterExportTemp [gravityCenterExportTempCount] = finData [11], gravityCenterExportTempCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                }
                
                delete [] uploadTemp;
            }
        }
        
        //-----Master Data Status UpLoad-----
        string connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+pathExtension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
        
        sizeForCopy = 0;
        
        if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        int *arrayTimeSelectedExportTemp = new int [sizeForCopy+50];
        int timeSelectedExportTempCount = 0;
        
        if (sizeForCopy != 0){
            fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                fin.close();
                
                int readPosition = 0;
                int stepCount = 0;
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                        finData [1] = uploadTemp [readPosition], readPosition++;
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                        finData [7] = uploadTemp [readPosition], readPosition++;
                        finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                        finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                        finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                        finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                        finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                        finData [13] = uploadTemp [readPosition], readPosition++;
                        finData [14] = uploadTemp [readPosition], readPosition++;
                        finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                        finData [16] = uploadTemp [readPosition], readPosition++;
                        finData [17] = uploadTemp [readPosition], readPosition++;
                        finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                        
                        finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                        finData [8] = finData [7]*256+finData [8];
                        finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                        finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                        
                        if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                        else{
                            
                            arrayTimeSelectedExportTemp [timeSelectedExportTempCount] = finData [0], timeSelectedExportTempCount++; //-----Selected, removed, eliminated status-----
                            arrayTimeSelectedExportTemp [timeSelectedExportTempCount] = finData [3], timeSelectedExportTempCount++; //-----When new line is created, enter line number which creates-----
                            arrayTimeSelectedExportTemp [timeSelectedExportTempCount] = finData [6], timeSelectedExportTempCount++; //-----PositionRevise Start-----
                            arrayTimeSelectedExportTemp [timeSelectedExportTempCount] = finData [8], timeSelectedExportTempCount++; //-----
                            arrayTimeSelectedExportTemp [timeSelectedExportTempCount] = finData [9], timeSelectedExportTempCount++; //-----R-----
                            arrayTimeSelectedExportTemp [timeSelectedExportTempCount] = finData [10], timeSelectedExportTempCount++; //-----G-----
                            arrayTimeSelectedExportTemp [timeSelectedExportTempCount] = finData [11], timeSelectedExportTempCount++; //-----B-----
                            arrayTimeSelectedExportTemp [timeSelectedExportTempCount] = finData [12], timeSelectedExportTempCount++; //-----
                            arrayTimeSelectedExportTemp [timeSelectedExportTempCount] = finData [15], timeSelectedExportTempCount++; //-----Connect-----
                            arrayTimeSelectedExportTemp [timeSelectedExportTempCount] = finData [18], timeSelectedExportTempCount++; //-----Lineage-----
                        }
                    }
                    
                } while (stepCount != 3);
                
                delete [] uploadTemp;
            }
        }
        
        [NSGraphicsContext saveGraphicsState];
        [NSGraphicsContext setCurrentContext:[NSGraphicsContext graphicsContextWithBitmapImageRep:bitmapReps]];
        
        // for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
        //     for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
        //    cout<<" arrayTimeSelected "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
        //      for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
        //     cout<<" arrayGravityCenterRev "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
        //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
        //    cout<<" arrayPositionRevise "<<counterA<<endl;
        //}
        
        NSBezierPath *path3;
        
        NSPoint positionAA;
        NSPoint positionBB;
        NSPoint positionCC;
        NSPoint positionDD;
        
        //-----Whole line data, TrackingOn = 1, or TrackingOn = 3, outside of range-----
        [attributesA setObject:[NSFont systemFontOfSize:12] forKey:NSFontAttributeName];
        [attributesA removeObjectForKey:NSBackgroundColorAttributeName];
        
        int startPoint = 0;
        int endPoint = 0;
        int xPointMarkTemp = 0;
        int yPointMarkTemp = 0;
        int lineageNoExport = 0;
        double cellNoExport = 0;
        double outlineWidth = 0;
        
        if (outlineWidthExport == 1) outlineWidth = 1;
        else if (outlineWidthExport == 2) outlineWidth = 2;
        else if (outlineWidthExport == 3) outlineWidth = 3;
        else if (outlineWidthExport == 4) outlineWidth = 4;
        else if (outlineWidthExport == 5) outlineWidth = 6;
        else if (outlineWidthExport == 6) outlineWidth = 8;
        else if (outlineWidthExport == 7) outlineWidth = 10;
        else if (outlineWidthExport == 8) outlineWidth = 15;
        else if (outlineWidthExport == 9) outlineWidth = 0;
        else if (outlineWidthExport == 10) outlineWidth = 0.5;
        
        for (int counter1 = 0; counter1 < timeSelectedExportTempCount/10; counter1++){
            if (arrayTimeSelectedExportTemp [counter1*10] == 0 || arrayTimeSelectedExportTemp [counter1*10] == 1 || arrayTimeSelectedExportTemp [counter1*10] == 7){
                startPoint = arrayTimeSelectedExportTemp [counter1*10+2];
                
                if (counter1+1 < timeSelectedExportTempCount/10) endPoint = arrayTimeSelectedExportTemp [(counter1+1)*10+2]-1;
                else endPoint = timeSelectedExportTempCount/7-1;
                
                lineageNoExport = arrayTimeSelectedExportTemp [counter1*10+9];
                cellNoExport = arrayPositionExportTemp [startPoint*7+4];
                
                for (int counter2 = startPoint; counter2 <= endPoint; counter2++){
                    if (outlineWidth != 0){
                        if (exportColorStatus == 0 || lineageNoExport == 0){
                            [[NSColor greenColor] set];
                            path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(arrayPositionExportTemp [counter2*7]-xImageStart, imageHeightExport-(arrayPositionExportTemp [counter2*7+1]+yImageStart), outlineWidth, outlineWidth)];
                            [path3 fill];
                        }
                        else{
                            
                            if (exportColorStatus == 1){
                                [[NSColor colorWithCalibratedRed:colorList [lineageNoExport*4+1] green:colorList [lineageNoExport*4+2] blue:colorList [lineageNoExport*4+3] alpha:1] set];
                                
                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(arrayPositionExportTemp [counter2*7]-xImageStart, imageHeightExport-(arrayPositionExportTemp [counter2*7+1]+yImageStart), outlineWidth, outlineWidth)];
                                [path3 fill];
                            }
                            else if (exportColorStatus == 2){
                                for (int counter3 = 0; counter3 < colorListCount; counter3++){
                                    if (cellNoHoldExport [counter3] == cellNoExport){
                                        [[NSColor colorWithCalibratedRed:colorList [counter3*4+1] green:colorList [counter3*4+2] blue:colorList [counter3*4+3] alpha:1] set];
                                        
                                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(arrayPositionExportTemp [counter2*7]-xImageStart, imageHeightExport-(arrayPositionExportTemp [counter2*7+1]+yImageStart), outlineWidth, outlineWidth)];
                                        [path3 fill];
                                        
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < masterLineGravityCenterCount/6; counterA++){
        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayMasterLineGravityCenter [counterA*6+counterB];
        //    cout<<" arrayMasterLineGravityCenter "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < associateDataCount/6; counterA++){
        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayAssociateData [counterA*6+counterB];
        //    cout<<" arrayAssociateData "<<counterA<<endl;
        //}
        
        double nonTargetWidth = 0;
        
        if (nonTargetWidthExport == 1) nonTargetWidth = 0.1;
        else if (nonTargetWidthExport == 2) nonTargetWidth = 0.5;
        else if (nonTargetWidthExport == 3) nonTargetWidth = 1;
        else if (nonTargetWidthExport == 4) nonTargetWidth = 1.5;
        else if (nonTargetWidthExport == 5) nonTargetWidth = 2.0;
        else if (nonTargetWidthExport == 6) nonTargetWidth = 4.0;
        else if (nonTargetWidthExport == 7) nonTargetWidth = 6.0;
        else if (nonTargetWidthExport == 8) nonTargetWidth = 8.0;
        else if (nonTargetWidthExport == 9) nonTargetWidth = 0;
        
        double nonTargetLength = 0;
        
        if (nonTargetLengthExport == 1) nonTargetLength = 5;
        else if (nonTargetLengthExport == 2) nonTargetLength = 10;
        else if (nonTargetLengthExport == 3) nonTargetLength = 20;
        else if (nonTargetLengthExport == 4) nonTargetLength = 30;
        else if (nonTargetLengthExport == 5) nonTargetLength = 40;
        else if (nonTargetLengthExport == 6) nonTargetLength = 50;
        else if (nonTargetLengthExport == 7) nonTargetLength = 70;
        else if (nonTargetLengthExport == 8) nonTargetLength = 100;
        else if (nonTargetLengthExport == 9) nonTargetLength = 0;
        
        double nonTargetFont = 0;
        
        if (nonTargetFontExport == 1) nonTargetFont = 6;
        else if (nonTargetFontExport == 2) nonTargetFont = 12;
        else if (nonTargetFontExport == 3) nonTargetFont = 18;
        else if (nonTargetFontExport == 4) nonTargetFont = 24;
        else if (nonTargetFontExport == 5) nonTargetFont = 30;
        else if (nonTargetFontExport == 6) nonTargetFont = 40;
        else if (nonTargetFontExport == 7) nonTargetFont = 50;
        else if (nonTargetFontExport == 8) nonTargetFont = 60;
        else if (nonTargetFontExport == 9) nonTargetFont = 0;
        
        NSString *vectorNumberDisplay;
        
        [[NSColor blackColor] set];
        [NSBezierPath setDefaultLineWidth:nonTargetWidth];
        [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        [attributesA setObject:[NSFont systemFontOfSize:nonTargetFont] forKey:NSFontAttributeName];
        [attributesA removeObjectForKey:NSBackgroundColorAttributeName];
        
        for (int counter1 = 0; counter1 < timeSelectedExportTempCount/10; counter1++){
            if (arrayTimeSelectedExportTemp [counter1*10] == 0 || arrayTimeSelectedExportTemp [counter1*10] == 1 || arrayTimeSelectedExportTemp [counter1*10] == 7){
                if (arrayPositionExportTemp [arrayTimeSelectedExportTemp [counter1*10+2]*7+6] == 0){
                    if (nonTargetWidth != 0 && nonTargetLength != 0){
                        positionAA.x = (arrayGravityCenterExportTemp [counter1*6]-xImageStart)-nonTargetLength;
                        positionAA.y = imageHeightExport-((int)arrayGravityCenterExportTemp [counter1*6+1]+yImageStart);
                        positionBB.x = (arrayGravityCenterExportTemp [counter1*6]-xImageStart)+nonTargetLength;
                        positionBB.y = imageHeightExport-((int)arrayGravityCenterExportTemp [counter1*6+1]+yImageStart);
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        positionCC.x = arrayGravityCenterExportTemp [counter1*6]-xImageStart;
                        positionCC.y = (imageHeightExport-((int)arrayGravityCenterExportTemp [counter1*6+1]+yImageStart))-nonTargetLength;
                        positionDD.x = arrayGravityCenterExportTemp [counter1*6]-xImageStart;
                        positionDD.y = (imageHeightExport-((int)arrayGravityCenterExportTemp [counter1*6+1]+yImageStart))+nonTargetLength;
                        [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                    }
                    
                    if (nonTargetFont != 0){
                        vectorNumberDisplay = [NSString stringWithFormat:@"%d", arrayGravityCenterExportTemp [counter1*6+4]];
                        
                        attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                        pointA.x = arrayGravityCenterExportTemp [counter1*6]-xImageStart;
                        pointA.y = imageHeightExport-((int)arrayGravityCenterExportTemp [counter1*6+1]+yImageStart);
                        [attrStrA drawAtPoint:pointA];
                    }
                }
            }
        }
        
        string extension2 = "";
        string eventString = "";
        
        if (timeSelectedExportCount != 0){
            double targetWidth = 0;
            
            if (targetWidthExport == 1) targetWidth = 0.1;
            else if (targetWidthExport == 2) targetWidth = 0.5;
            else if (targetWidthExport == 3) targetWidth = 1;
            else if (targetWidthExport == 4) targetWidth = 1.5;
            else if (targetWidthExport == 5) targetWidth = 2.0;
            else if (targetWidthExport == 6) targetWidth = 4.0;
            else if (targetWidthExport == 7) targetWidth = 6.0;
            else if (targetWidthExport == 8) targetWidth = 8.0;
            else if (targetWidthExport == 9) targetWidth = 0;
            
            double targetLength = 0;
            
            if (targetLengthExport == 1) targetLength = 5;
            else if (targetLengthExport == 2) targetLength = 10;
            else if (targetLengthExport == 3) targetLength = 20;
            else if (targetLengthExport == 4) targetLength = 30;
            else if (targetLengthExport == 5) targetLength = 40;
            else if (targetLengthExport == 6) targetLength = 50;
            else if (targetLengthExport == 7) targetLength = 70;
            else if (targetLengthExport == 8) targetLength = 100;
            else if (targetLengthExport == 9) targetLength = 0;
            
            double targetFont = 0;
            
            if (targetFontExport == 1) targetFont = 6;
            else if (targetFontExport == 2) targetFont = 12;
            else if (targetFontExport == 3) targetFont = 18;
            else if (targetFontExport == 4) targetFont = 24;
            else if (targetFontExport == 5) targetFont = 30;
            else if (targetFontExport == 6) targetFont = 40;
            else if (targetFontExport == 7) targetFont = 50;
            else if (targetFontExport == 8) targetFont = 60;
            else if (targetFontExport == 9) targetFont = 0;
            
            [NSBezierPath setDefaultLineWidth:targetWidth];
            [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            [attributesA setObject:[NSFont systemFontOfSize:targetFont] forKey:NSFontAttributeName];
            [attributesA removeObjectForKey:NSBackgroundColorAttributeName];
            
            int numberOfCellInAreaFind = 0;
            int setValue = 0;
            
            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                if (imageNoEx >= arrayLineageStartEnd [counter1*8+5] && imageNoEx <= arrayLineageStartEnd [counter1*8+7]){
                    for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                        xPointMarkTemp = arrayLineageData [counter2*8]-xImageStart;
                        yPointMarkTemp = imageHeightExport-(arrayLineageData [counter2*8+1]+yImageStart);
                        
                        //-----Event type 1: I, 2: P, DStart:31, DEnd: 32, 33, 34, TStart:41, TEnd: 42, 43, 44, HStart: 51, HEnd: 52, 53, 54, 55, M: 6, CD: 7, OF: 8, FUEnd: 91, FUCont: 92-----
                        //-----FMark: 10, MD: 11, EF: 12, NE: 13 (in the event that cell enter image, create Dummy entry mark in Time One)-----
                        
                        if (arrayLineageData [counter2*8+2] == imageNoEx && arrayLineageData [counter2*8+3] != 13){
                            if (densityModeHold == 1){
                                for (int counter3 = 1; counter3 <= densityDiameterHold; counter3++){
                                    for (int counter4 = 1; counter4 <= densityDiameterHold; counter4++){
                                        if (xPointMarkTemp-center+counter4 >= 0 && xPointMarkTemp-center+counter4 < xImageSizeEX && yPointMarkTemp-center+counter3 >= 0 && yPointMarkTemp-center+counter3 < yImageSizeEX && circleAreaHold [counter3][counter4] == 1){
                                            densityMapHold [yPointMarkTemp-center+counter3][xPointMarkTemp-center+counter4]++;
                                        }
                                    }
                                }
                            }
                            else if (motilityStatusHold == 1){
                                setValue = 0;
                                
                                for (int counter3 = 0; counter3 < motilityBasicInfoCount/7; counter3++){
                                    if (arrayMotilityBasicInfo [counter3*6] == arrayLineageData [counter2*8+6] && arrayMotilityBasicInfo [counter3*7+1] == arrayLineageData [counter2*8+5] && arrayMotilityBasicInfo [counter3*7+4] == arrayLineageData [counter2*8+2]){
                                        setValue = arrayMotilityBasicInfo [counter3*7+5];
                                        break;
                                    }
                                }
                                
                                if (setValue == 0) setValue = 1;
                                
                                for (int counter3 = 1; counter3 <= densityDiameterHold; counter3++){
                                    for (int counter4 = 1; counter4 <= densityDiameterHold; counter4++){
                                        if (xPointMarkTemp-center+counter4 >= 0 && xPointMarkTemp-center+counter4 < xImageSizeEX && yPointMarkTemp-center+counter3 >= 0 && yPointMarkTemp-center+counter3 < yImageSizeEX && circleAreaHold [counter3][counter4] == 1){
                                            densityMapHold [yPointMarkTemp-center+counter3][xPointMarkTemp-center+counter4] = setValue;
                                        }
                                    }
                                }
                            }
                            
                            break;
                        }
                    }
                }
            }
            
            // for (int counterA = 0; counterA < yImageSizeEX; counterA++){
            //     for (int counterB = 0; counterB < xImageSizeEX; counterB++) cout<<" "<<densityMapHold [counterA][counterB];
            //     cout<<" densityMapHold "<<counterA<<endl;
            //}
            
            if (densityModeHold == 1 || motilityStatusHold == 1){
                double valueRange = densityValueMaxHold/(double)25;
                int eachRange = 0;
                
                for (int counter1 = 0; counter1 < yImageSizeEX+1; counter1++){
                    for (int counter2 = 0; counter2 < xImageSizeEX+1; counter2++){
                        if (densityMapHold [counter1][counter2] > 0){
                            eachRange = (int)(densityMapHold [counter1][counter2]/(double)valueRange);
                            if (eachRange >= 24){
                                [[NSColor colorWithCalibratedRed:arrayColorRange [24*3] green:arrayColorRange [24*3+1] blue:arrayColorRange [24*3+2] alpha:1] set];
                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(counter2, counter1, 10, 10)];
                                [path3 fill];
                            }
                            else{
                                
                                [[NSColor colorWithCalibratedRed:arrayColorRange [eachRange*3] green:arrayColorRange [eachRange*3+1] blue:arrayColorRange [eachRange*3+2] alpha:1] set];
                                path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(counter2, counter1, 10, 10)];
                                [path3 fill];
                            }
                        }
                    }
                }
            }
            
            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                if (imageNoEx >= arrayLineageStartEnd [counter1*8+5] && imageNoEx <= arrayLineageStartEnd [counter1*8+7]){
                    for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                        xPointMarkTemp = arrayLineageData [counter2*8]-xImageStart;
                        yPointMarkTemp = imageHeightExport-(arrayLineageData [counter2*8+1]+yImageStart);
                        
                        //-----Event type 1: I, 2: P, DStart:31, DEnd: 32, 33, 34, TStart:41, TEnd: 42, 43, 44, HStart: 51, HEnd: 52, 53, 54, 55, M: 6, CD: 7, OF: 8, FUEnd: 91, FUCont: 92-----
                        //-----FMark: 10, MD: 11, EF: 12, NE: 13 (in the event that cell enter image, create Dummy entry mark in Time One)-----
                        
                        if (arrayLineageData [counter2*8+2] == imageNoEx && arrayLineageData [counter2*8+3] != 13){
                            if ((densityModeHold == 0 && motilityStatusHold == 0) || ((densityModeHold == 1 || motilityStatusHold == 1) && lineageLimitHold == 0) || ((densityModeHold == 1 || motilityStatusHold == 1) && lineageLimitHold > 0 && arrayLineageData [counter2*8+6] <= lineageLimitHold)){
                                extension2 = to_string(arrayLineageData [counter2*8+6]);
                                
                                if (extension2.length() == 1) extension2 = "L0000"+extension2+eventString;
                                else if (extension2.length() == 2) extension2 = "L000"+extension2+eventString;
                                else if (extension2.length() == 3) extension2 = "L00"+extension2+eventString;
                                else if (extension2.length() == 4) extension2 = "L0"+extension2+eventString;
                                else if (extension2.length() == 5) extension2 = "L"+extension2+eventString;
                                
                                vectorNumberDisplay = @(extension2.c_str());
                                
                                if (targetWidth != 0 && targetLength != 0){
                                    if (exportColorStatus == 0){
                                        if (lineageFontColorExport == 0)[[NSColor orangeColor] set];
                                        else if (lineageFontColorExport== 1)[[NSColor whiteColor] set];
                                        else if (lineageFontColorExport == 2)[[NSColor yellowColor] set];
                                        else if (lineageFontColorExport == 3)[[NSColor blueColor] set];
                                        else if (lineageFontColorExport == 4)[[NSColor blackColor] set];
                                        else if (lineageFontColorExport == 5)[[NSColor redColor] set];
                                        
                                        positionAA.x = xPointMarkTemp-targetLength;
                                        positionAA.y = yPointMarkTemp;
                                        positionBB.x = xPointMarkTemp+targetLength;
                                        positionBB.y = yPointMarkTemp;
                                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                        
                                        positionCC.x = xPointMarkTemp;
                                        positionCC.y = yPointMarkTemp-targetLength;
                                        positionDD.x = xPointMarkTemp;
                                        positionDD.y = yPointMarkTemp+targetLength;
                                        [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                                    }
                                    else{
                                        
                                        if (exportColorStatus == 1){
                                            [[NSColor colorWithCalibratedRed:colorList [arrayLineageData [counter2*8+6]*4+1] green:colorList [arrayLineageData [counter2*8+6]*4+2] blue:colorList [arrayLineageData [counter2*8+6]*4+3] alpha:1] set];
                                            [attributesA setObject:[NSColor colorWithCalibratedRed:colorList [arrayLineageData [counter2*8+6]*4+1] green:colorList [arrayLineageData [counter2*8+6]*4+2] blue:colorList [arrayLineageData [counter2*8+6]*4+3] alpha:1] forKey: NSForegroundColorAttributeName];
                                            
                                            positionAA.x = xPointMarkTemp-targetLength;
                                            positionAA.y = yPointMarkTemp;
                                            positionBB.x = xPointMarkTemp+targetLength;
                                            positionBB.y = yPointMarkTemp;
                                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                            
                                            positionCC.x = xPointMarkTemp;
                                            positionCC.y = yPointMarkTemp-targetLength;
                                            positionDD.x = xPointMarkTemp;
                                            positionDD.y = yPointMarkTemp+targetLength;
                                            [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                                        }
                                        else if (exportColorStatus == 2){
                                            for (int counter3 = 0; counter3 < colorListCount; counter3++){
                                                if (cellNoHoldExport [counter3] == arrayLineageData [counter2*8+5]){
                                                    [[NSColor colorWithCalibratedRed:colorList [counter3*4+1] green:colorList [counter3*4+2] blue:colorList [counter3*4+3] alpha:1] set];
                                                    [attributesA setObject:[NSColor colorWithCalibratedRed:colorList [counter3*4+1] green:colorList [counter3*4+2] blue:colorList [counter3*4+3] alpha:1] forKey: NSForegroundColorAttributeName];
                                                    
                                                    positionAA.x = xPointMarkTemp-targetLength;
                                                    positionAA.y = yPointMarkTemp;
                                                    positionBB.x = xPointMarkTemp+targetLength;
                                                    positionBB.y = yPointMarkTemp;
                                                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                                    
                                                    positionCC.x = xPointMarkTemp;
                                                    positionCC.y = yPointMarkTemp-targetLength;
                                                    positionDD.x = xPointMarkTemp;
                                                    positionDD.y = yPointMarkTemp+targetLength;
                                                    [NSBezierPath strokeLineFromPoint:positionCC toPoint:positionDD];
                                                    
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                if (targetFont != 0){
                                    attrStrA = [[NSAttributedString alloc] initWithString:vectorNumberDisplay attributes:attributesA];
                                    pointA.x = xPointMarkTemp;
                                    pointA.y = yPointMarkTemp;
                                    [attrStrA drawAtPoint:pointA];
                                }
                                
                                if (arrayLineageData [counter2*8] > xImageStart && arrayLineageData [counter2*8] < xImageStart+xImageSizeEX && imageHeightExport-arrayLineageData [counter2*8+1] > yImageStart && imageHeightExport-arrayLineageData [counter2*8+1] < yImageStart+yImageSizeEX){
                                    numberOfCellInAreaFind++;
                                }
                            }
                        }
                    }
                }
            }
            
            CGFloat tempValue = 0;
            
            if (thresholdStatusHold == 1 && xImageEndTH > xImageSizeEX){
                for (int counter1 = 0; counter1 < yImageSizeEX; counter1++){
                    for (int counter2 = 0; counter2 < xImageSizeEX; counter2++){
                        if (densityMapHold [counter1][counter2] >= thresholdCutHold){
                            densityMapHold [counter1][counter2] = -150;
                        }
                        else densityMapHold [counter1][counter2] = 0;
                    }
                }
                
                int *connectAnalysisX = new int [xImageSizeEX*4];
                int *connectAnalysisY = new int [yImageSizeEX*4];
                int *connectAnalysisTempX = new int [xImageSizeEX*4];
                int *connectAnalysisTempY = new int [yImageSizeEX*4];
                
                int connectivityNumber = 0;
                int connectAnalysisCount = 0;
                int terminationFlag = 0;
                int connectAnalysisTempCount = 0;
                int xSource = 0;
                int ySource = 0;
                
                for (int counterY = 0; counterY < yImageSizeEX; counterY++){
                    for (int counterX = 0; counterX < xImageSizeEX; counterX++){
                        if (densityMapHold [counterY][counterX] == -150){
                            connectivityNumber++;
                            densityMapHold [counterY][counterX] = connectivityNumber;
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && counterX-1 >= 0 && densityMapHold [counterY-1][counterX-1] == -150){
                                densityMapHold [counterY-1][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && densityMapHold [counterY-1][counterX] == -150){
                                densityMapHold [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && counterX+1 < xImageSizeEX && densityMapHold [counterY-1][counterX+1] == -150){
                                densityMapHold [counterY-1][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < xImageSizeEX && densityMapHold [counterY][counterX+1] == -150){
                                densityMapHold [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < yImageSizeEX && counterX+1 < xImageSizeEX && densityMapHold [counterY+1][counterX+1] == -150){
                                densityMapHold [counterY+1][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < yImageSizeEX && densityMapHold [counterY+1][counterX] == -150){
                                densityMapHold [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < yImageSizeEX && counterX-1 >= 0 && densityMapHold [counterY+1][counterX-1] == -150){
                                densityMapHold [counterY+1][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && densityMapHold [counterY][counterX-1] == -150){
                                densityMapHold [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                        xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                        
                                        if (ySource-1 >= 0 && xSource-1 >= 0 && densityMapHold [ySource-1][xSource-1] == -150){
                                            densityMapHold [ySource-1][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && densityMapHold [ySource-1][xSource] == -150){
                                            densityMapHold [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && xSource+1 < xImageSizeEX && densityMapHold [ySource-1][xSource+1] == -150){
                                            densityMapHold [ySource-1][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < xImageSizeEX && densityMapHold [ySource][xSource+1] == -150){
                                            densityMapHold [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 > yImageSizeEX && xSource+1 < xImageSizeEX && densityMapHold [ySource+1][xSource+1] == -150){
                                            densityMapHold [ySource+1][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < yImageSizeEX && densityMapHold [ySource+1][xSource] == -150){
                                            densityMapHold [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < yImageSizeEX && xSource-1 >= 0 && densityMapHold [ySource+1][xSource-1] == -150){
                                            densityMapHold [ySource+1][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && densityMapHold [ySource][xSource-1] == -150){
                                            densityMapHold [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                        connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                delete [] connectAnalysisX;
                delete [] connectAnalysisY;
                delete [] connectAnalysisTempX;
                delete [] connectAnalysisTempY;
                
                //-----Determine number of pixels-----
                int *connectedPix = new int [connectivityNumber+50];
                
                for (int counter1 = 0; counter1 <= connectivityNumber; counter1++) connectedPix [counter1] = 0;
                
                for (int counter1 = 0; counter1 < yImageSizeEX; counter1++){
                    for (int counter2 = 0; counter2 < xImageSizeEX; counter2++){
                        if (densityMapHold [counter1][counter2] != 0) connectedPix [densityMapHold [counter1][counter2]]++;
                    }
                }
                
                //-----Map up-date-----
                int connectTemp = 1;
                
                for (int counter1 = 1; counter1 <= connectivityNumber; counter1++){
                    if (connectedPix [counter1] < areaSizeMinHold || connectedPix [counter1] > areaSizeMaxHold) connectedPix [counter1] = 0;
                    else{
                        
                        connectedPix [counter1] = connectTemp;
                        connectTemp++;
                    }
                }
                
                for (int counter1 = 0; counter1 < yImageSizeEX; counter1++){
                    for (int counter2 = 0; counter2 < xImageSizeEX; counter2++){
                        if (connectedPix [densityMapHold [counter1][counter2]] == 0) densityMapHold [counter1][counter2] = 0;
                        else densityMapHold [counter1][counter2] = 200;
                    }
                }
                
                delete [] connectedPix;
                
                //for (int counterA = 0; counterA < 100; counterA++){
                //    for (int counterB = 0; counterB < 100; counterB++)  cout<<" "<<densityMapHold [counterA][counterB];
                //    cout<<" densityMapHold "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < yImageSizeEX; counter1++){
                    for (int counter2 = 0; counter2 < xImageSizeEX; counter2++){
                        tempValue = densityMapHold [counter1][counter2]/(double)255;
                        
                        [[NSColor colorWithCalibratedRed:tempValue green:tempValue blue:tempValue alpha:1] set];
                        path3 = [NSBezierPath bezierPathWithRect: NSMakeRect(counter2+xImageSizeEX, counter1, 1, 1)];
                        [path3 fill];
                    }
                }
                
                particleCountingDataHold [particleCountingDataHoldCount] = imageNoWrite, particleCountingDataHoldCount++;
                particleCountingDataHold [particleCountingDataHoldCount] = connectTemp-1, particleCountingDataHoldCount++;
            }
            
            noOfCellsInArea [noOfCellsInAreaCount] = imageNoCount, noOfCellsInAreaCount++;
            noOfCellsInArea [noOfCellsInAreaCount] = xImageEnd-xImageStart, noOfCellsInAreaCount++;
            noOfCellsInArea [noOfCellsInAreaCount] = yImageEnd-yImageStart, noOfCellsInAreaCount++;
            noOfCellsInArea [noOfCellsInAreaCount] = numberOfCellInAreaFind, noOfCellsInAreaCount++;
        }
        
        //-----Trace line writing-----
        if (lineTraceOnOff == 1){
            int xPointMarkTemp2 = 0;
            int yPointMarkTemp2 = 0;
            
            for (int counter1 = 0; counter1 < lineTraceCount/8; counter1++){
                if (treatmentNameHold == arrayLineTrace [counter1*8+6] && arrayLineTrace [counter1*8+7] == "s"){
                    [[NSColor colorWithCalibratedRed:arrayColorRange [lineExportColor] green:arrayColorRange [lineExportColor+1] blue:arrayColorRange [lineExportColor+2] alpha:1] set];
                    
                    [NSBezierPath setDefaultLineWidth:lineExportWidth];
                    
                    xPointMarkTemp = (int)(atoi(arrayLineTrace [counter1*8].c_str())-xImageStart);
                    yPointMarkTemp = (int)((imageHeightExport-atoi(arrayLineTrace [counter1*8+1].c_str()))+yImageStart);
                    
                    xPointMarkTemp2 = (int)(atoi(arrayLineTrace [counter1*8+3].c_str())-xImageStart);
                    yPointMarkTemp2 = (int)((imageHeightExport-atoi(arrayLineTrace [counter1*8+4].c_str()))+yImageStart);
                    
                    positionAA.x = xPointMarkTemp;
                    positionAA.y = yPointMarkTemp;
                    positionBB.x = xPointMarkTemp2;
                    positionBB.y = yPointMarkTemp2;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
            }
        }
        
        //-----Info writing-----
        double titleFont = 0;
        
        if (titleFontExport == 1) titleFont = 12;
        else if (titleFontExport == 2) titleFont = 18;
        else if (titleFontExport == 3) titleFont = 24;
        else if (titleFontExport == 4) titleFont = 30;
        else if (titleFontExport == 5) titleFont = 40;
        else if (titleFontExport == 6) titleFont = 50;
        else if (titleFontExport == 7) titleFont = 60;
        else if (titleFontExport == 8) titleFont = 80;
        else if (titleFontExport == 9) titleFont = 0;
        else if (titleFontExport == 10) titleFont = 6;
        else if (titleFontExport == 11) titleFont = 8;
        
        [attributesA setObject:[NSFont boldSystemFontOfSize:titleFont] forKey:NSFontAttributeName];
        [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
        [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
        
        if (imageNoWrite == 0) imageNoWrite = imageNumberExportForDisplay;
        
        string infoDisplayString = "Time: "+to_string(imageNoWrite);
        string infoCountString = "Time: 0000";
        
        NSFont *font = [NSFont boldSystemFontOfSize:titleFont];
        
        NSString *timeNSString2 = @(infoCountString.c_str());
        NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
        NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSString2 attributes:attributes2];
        CGFloat size2A = [attrStrS2 size].width;
        CGFloat size3 = [attrStrS2 size].height;
        
        if (titleFont != 0){
            attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
            pointA.x = 10;
            pointA.y = yImageSizeEX-size3-5;
            [attrStrA drawAtPoint:pointA];
        }
        
        if (titleNameExport == 0){
            if (titleNameExportHold != "") infoDisplayString = "Treatment: "+titleNameExportHold;
            else infoDisplayString = "Treatment: "+treatmentNameHold;
            
            if (titleFont != 0){
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 10+size2A+size2A*0.25;
                pointA.y = yImageSizeEX-size3-5;
                [attrStrA drawAtPoint:pointA];
            }
        }
        
        [NSGraphicsContext restoreGraphicsState];
        
        NSData *imageExportData;
        imageExportData = [bitmapReps TIFFRepresentation];
        
        [imageExportData writeToFile:@(displayImageSavePath.c_str()) atomically:YES];
        
        if (displayModeSelect == 1) displayModeSelect = 0;
        else if (displayModeSelect == 7) displayModeSelect = 8;
        
        delete [] arrayTimeSelectedExportTemp;
        delete [] arrayPositionExportTemp;
        delete [] arrayGravityCenterExportTemp;
        
        for (int counter1 = 0; counter1 < yImageSizeEX+1; counter1++){
            delete [] densityMapHold [counter1];
        }
        
        delete [] densityMapHold;
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToExportDisplay object:nil];
}

@end
