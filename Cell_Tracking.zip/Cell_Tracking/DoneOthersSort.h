//
//  DoneOthersSort.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-03-31.
//

#ifndef DONEOTHERSSORT_H
#define DONEOTHERSSORT_H
#import "Controller.h"
#endif

@interface DoneOthersSort : NSObject{
    IBOutlet NSTextField *doneOptionCheck;
    IBOutlet NSTextField *returnOptionCheck;
    IBOutlet NSTextField *autoExpandLineDisplay;
    
    id dataSaveRead;
}

-(IBAction)organizeList:(id)sender;
-(IBAction)organizeList2:(id)sender;
-(IBAction)organizeListCK:(id)sender;
-(IBAction)doneDisplayAll:(id)sender;
-(IBAction)doneDisplayTreatment:(id)sender;
-(IBAction)doneDisplayCheck:(id)sender;
-(IBAction)doneDisplayOK:(id)sender;
-(IBAction)organizeListAutoCheck:(id)sender;
-(IBAction)returnPositionCheck:(id)sender;
-(IBAction)returnPositionLast:(id)sender;
-(IBAction)autoExpandLineSet:(id)sender;

@end
