//
//  DatabaseLineListTable.m
//  Cell_Tracking
//
//  Created by Imaging on 2019-06-13.
//

#import "DatabaseLineListTable.h"

NSString *notificationToDatabaseListTable = @"notificationExecuteDatabaseListTable";

@implementation DatabaseLineListTable

-(id)init{
    self = [super init];
    
    if (self != nil){
        repairListTableCount = 0;
        rowRepairListTable = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToDatabaseListTable object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [tableViewDatabaseList setDataSource:self];
    [tableViewDatabaseList reloadData];
    
    databaseListDisplayTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    //-----Table View for search-----
    if (repairListTableCount == 1){
        repairListTableCount = 0;
        rowRepairListTable = repairListTableCurrentRow;
    }
    
    if (repairListTableCount > 1) repairListTableCount = 0;
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = 0;
    tableViewContent = listStringCount;
    
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
    
    string entryNumber1 = arrayListString [rowIndex];
    entryNumber1 = entryNumber1.substr(0, entryNumber1.find("~~"));
    
    if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber1.c_str()) attributes:attributes];
    }
    else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    repairListTableCount++;
    repairListTableCurrentRow = rowIndex;
    
    if (repairListTableCount == 2){
        repairListTableCurrentRow = rowRepairListTable;
        secondLineDisplayCall = 1;
        secondLineDisplayRemoveCall = 1;
    }
    else{
        
        repairListTableCurrentRow = rowIndex;
        secondLineDisplayCall = 1;
        secondLineDisplayRemoveCall = 1;
    }
    
    return YES;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToDatabaseListTable object:nil];
}

@end
