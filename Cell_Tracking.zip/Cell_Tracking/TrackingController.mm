//
// TrackingController.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 13/08/09.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "TrackingController.h"

NSString *notificationToTrackingController = @"notificationExecuteCellTrackingController";

@implementation TrackingController

-(id)init{
    self = [super init];
    
    if (self != nil){
        listLoadingStart = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToTrackingController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    listViewWindControllerTC = [[NSWindowController alloc] initWithWindowNibName:@"ListView"];
    [listViewWindControllerTC showWindow:self];
    
    displayWindControllerTC = [[NSWindowController alloc] initWithWindowNibName:@"Display"];
    [displayWindControllerTC showWindow:self];
    
    imageEditWindControllerTC = [[NSWindowController alloc] initWithWindowNibName:@"ImageEdit"];
    [imageEditWindControllerTC showWindow:self];
    
    listCrickMonitor = 1;
    
    trackControlTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(statusMonitor) userInfo:nil repeats:YES];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDisplayController object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat xLength = screenRect.size.width;
    CGFloat yLength = screenRect.size.height;
    
    int mainControllerX = 867;
    
    NSRect windowSize = [trackingControllerWindow frame];
    CGFloat windowWidth = windowSize.size.width;
    CGFloat windowHeight = windowSize.size.height;
    
    NSRect windowSize2 = [listViewControllerWindow frame];
    CGFloat windowWidth2 = windowSize2.size.width;
    CGFloat windowHeight2 = windowSize2.size.height;
    
    NSRect windowSize3 = [displayControllerWindow frame];
    CGFloat windowWidth3 = windowSize3.size.width;
    CGFloat windowHeight3 = windowSize3.size.height;
    
    if (80+mainControllerX+5+windowWidth+5+80 > xLength || 80+mainControllerX+5+windowWidth2+5+80 > xLength || 80+mainControllerX+5+windowWidth3+5+80 > xLength) displayPositionType = 1;
    
    int displayX;
    
    if (displayPositionType == 1) displayX = 550;
    else displayX = 80+mainControllerX+5;
    
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0){
        [trackingControllerWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    }
    
    if (displayPositionType == 1) displayX = 550;
    else displayX = 80+mainControllerX+5;
    
    displayY = yLength+yOrigin-20-windowHeight2-157;
    if (windowHeight2 != 0){
        [listViewControllerWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    }
    
    if (displayPositionType == 1) displayX = 870;
    else displayX = 80+mainControllerX+5+100;
    
    displayY = yLength+yOrigin-20-windowHeight3;
    
    if (windowHeight3 != 0){
        [displayControllerWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    }
    
    [stepperValueDisplay setDelegate:self];
    [stepperLimit setMinValue:cutLimitValueHold];
    [stepperValueDisplay setIntValue:cutLimitValueHold];
    
    trackControlTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(statusMonitor2) userInfo:nil repeats:YES];
}

-(void)statusMonitor{
    if (listCrickMonitor == 1){
        listCrickMonitor = 0;
        connectLineListLocalCount = 0;
        xyPositionListCount = 0;
        
        if (treatmentNameHold != "" && treatmentNameHold != treatmentNameKeep){
            string cutOffDataPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/OutlineSetting";
            string getString;
            
            ifstream fin;
            fin.open(cutOffDataPath.c_str(), ios::in);
            
            if (fin.is_open()){
                getline(fin, getString);
                getline(fin, getString);
                getline(fin, getString);
                
                if (getString == "nil") cutOff4 = atoi(getString.c_str());
                
                getline(fin, getString);
                
                if (getString == "nil") cutOff5 = atoi(getString.c_str());
                
                getline(fin, getString);
                
                if (getString == "nil") cutOff6 = atoi(getString.c_str());
                
                getline(fin, getString);
                
                if (getString == "nil") cutOff7 = atoi(getString.c_str());
                
                fin.close();
            }
            
            int cutOffHigherRange = (int)((250-cutOff4)/(double)4);
            
            cutOff1 = cutOff4+cutOffHigherRange*3;
            cutOff2 = cutOff4+cutOffHigherRange*2;
            cutOff3 = cutOff4+cutOffHigherRange;
            
            cutOffDataPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/OutlineSettingStatus";
            
            fin.open(cutOffDataPath.c_str(), ios::in);
            
            if (fin.is_open()){
                getline(fin, getString);
                
                if (getString == "nil") cutStatusDic = 30;
                else cutStatusDic = atoi(getString.c_str());
                
                getline(fin, getString);
                
                if (getString == "nil") cutStatusFluorescent = 30;
                else cutStatusFluorescent = atoi(getString.c_str());
                
                fin.close();
            }
            else{
                
                cutStatusDic = 30;
                cutStatusFluorescent = 30;
            }
            
            //for (int counterA = 0; counterA < treatmentStatusCount/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayTreatmentStatus [counterA*9+counterB];
            //    cout<<" arrayTreatmentStatus "<<counterA<<endl;
            //}
            
            string maxPointString;
            string timeOneString;
            string timeEndString;
            string ifStartString;
            string imageEndString;
            string imageEndString2;
            
            timePointListMax = 0;
            
            for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
                if (arrayTreatmentStatus [counter1*9] == treatmentNameHold){
                    maxPointString = arrayTreatmentStatus [counter1*9+6];
                    timeOneString = arrayTreatmentStatus [counter1*9+4];
                    timeEndString = arrayTreatmentStatus [counter1*9+5];
                    ifStartString = arrayTreatmentStatus [counter1*9+7];
                    imageEndString = arrayTreatmentStatus [counter1*9+8];
                    
                    if (maxPointString == "nil") maxTimePoint = 0;
                    else maxTimePoint = atoi(maxPointString.c_str());
                    
                    if (timeOneString == "nil") timeOneHold = 0;
                    else timeOneHold = atoi(timeOneString.c_str());
                    
                    if (timeEndString == "nil") timeEndHold = 0;
                    else timeEndHold = atoi(timeEndString.c_str());
                    
                    if (ifStartString == "nil") ifStartHold = 0;
                    else ifStartHold = atoi(ifStartString.c_str());
                    
                    if (imageEndString == "nil") imageEndHold = 0;
                    else imageEndHold = atoi(imageEndString.c_str());
                }
                
                imageEndString2 = arrayTreatmentStatus [counter1*9+8];
                
                if (timePointListMax < atoi(imageEndString2.c_str())){
                    timePointListMax = atoi(imageEndString2.c_str());
                }
            }
            
            if (timePointListSaveStatus == 1) delete [] arrayTimePointSaveList;
            arrayTimePointSaveList = new int [timePointListMax+50];
            timePointListSaveStatus = 1;
            
            for (int counter1 = 0; counter1 < timePointListMax+50; counter1++) arrayTimePointSaveList [counter1] = 0;
            
            if (ifEntry == 1){
                ifEntry = 0;
                fluorescentNo1 = fluorescentNoHold1;
                fluorescentNo2 = fluorescentNoHold2;
                fluorescentNo3 = fluorescentNoHold3;
                fluorescentNo4 = fluorescentNoHold4;
                fluorescentNo5 = fluorescentNoHold5;
                fluorescentNo6 = fluorescentNoHold6;
                fluorescentEntryCount = fluorescentEntryCountHold;
                fluorescentName1 = fluorescentNameHold1;
                fluorescentName2 = fluorescentNameHold2;
                fluorescentName3 = fluorescentNameHold3;
                fluorescentName4 = fluorescentNameHold4;
                fluorescentName5 = fluorescentNameHold5;
                fluorescentName6 = fluorescentNameHold6;
            }
            
            string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
            
            struct stat sizeOfFile;
            
            if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                if (fluorescentCutOffStatus == 0) arrayFluorescentCutOff = new int [imageEndHold*7];
                fluorescentCutOffStatus = 1;
                
                fluorescentCutOffCount = 0;
                
                fin.open (cutOffPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    for (int counter1 = 0; counter1 < imageEndHold; counter1++){
                        getline(fin, getString);
                        
                        if (getString != "End"){
                            arrayFluorescentCutOff [fluorescentCutOffCount] = atoi(getString.c_str()), fluorescentCutOffCount++;
                            getline(fin, getString);
                            arrayFluorescentCutOff [fluorescentCutOffCount] = atoi(getString.c_str()), fluorescentCutOffCount++;
                            getline(fin, getString);
                            arrayFluorescentCutOff [fluorescentCutOffCount] = atoi(getString.c_str()), fluorescentCutOffCount++;
                            getline(fin, getString);
                            arrayFluorescentCutOff [fluorescentCutOffCount] = atoi(getString.c_str()), fluorescentCutOffCount++;
                            getline(fin, getString);
                            arrayFluorescentCutOff [fluorescentCutOffCount] = atoi(getString.c_str()), fluorescentCutOffCount++;
                            getline(fin, getString);
                            arrayFluorescentCutOff [fluorescentCutOffCount] = atoi(getString.c_str()), fluorescentCutOffCount++;
                            getline(fin, getString);
                            arrayFluorescentCutOff [fluorescentCutOffCount] = atoi(getString.c_str()), fluorescentCutOffCount++;
                        }
                        else{
                            
                            break;
                        }
                    }
                    
                    fin.close();
                }
                
                //for (int counterA = 0; counterA < fluorescentCutOffCount/7; counterA++){
                // 	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayFluorescentCutOff [counterA*7+counterB];
                // 	cout<<" arrayFluorescentCutOff "<<counterA<<endl;
                //}
            }
            else{
                
                if (fluorescentNo1 == 0){
                    if (fluorescentCutOffStatus == 1){
                        delete [] arrayFluorescentCutOff;
                        fluorescentCutOffCount = 0;
                        fluorescentCutOffStatus = 0;
                    }
                }
                else{
                    
                    string extension = to_string (timeOneHold);
                    
                    if (extension.length() == 1) extension = "000"+extension;
                    else if (extension.length() == 2) extension = "00"+extension;
                    else if (extension.length() == 3) extension = "0"+extension;
                    
                    string extension2;
                    
                    if (fluorescentNo1 == 1) extension2 = "1";
                    else if (fluorescentNo1 == 2) extension2 = "2";
                    else if (fluorescentNo1 == 3) extension2 = "3";
                    else if (fluorescentNo1 == 4) extension2 = "4";
                    else if (fluorescentNo1 == 5) extension2 = "5";
                    else if (fluorescentNo1 == 6) extension2 = "6";
                    else if (fluorescentNo1 == 7) extension2 = "7";
                    else if (fluorescentNo1 == 8) extension2 = "8";
                    else if (fluorescentNo1 == 9) extension2 = "9";
                    
                    string firstColorImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+exType;
                    
                    if (stat(firstColorImagePath.c_str(), &sizeOfFile) == 0){
                        fluorescentCutOff1 = 150;
                        fluorescentCutOff2 = 150;
                        fluorescentCutOff3 = 150;
                        fluorescentCutOff4 = 150;
                        fluorescentCutOff5 = 150;
                        fluorescentCutOff6 = 150;
                        
                        if (fluorescentCutOffStatus == 0){
                            arrayFluorescentCutOff = new int [imageEndHold*7];
                            fluorescentCutOffStatus = 1;
                        }
                        
                        fluorescentCutOffCount = 0;
                        
                        arrayFluorescentCutOff [fluorescentCutOffCount] = timeOneHold, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        
                        ofstream oin;
                        oin.open(cutOffPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                        
                        oin<<"End"<<endl;
                        oin.close();
                    }
                    else if (fluorescentCutOffStatus == 1){
                        delete [] arrayFluorescentCutOff;
                        fluorescentCutOffCount = 0;
                        fluorescentCutOffStatus = 0;
                    }
                }
            }
            
            displaySetDICFlag = 1;
            displaySetFluorescentFlag = 1;
            displaySetCutFlag1 = 1;
            displaySetCutFlag2 = 1;
            displaySetCutFlag3 = 1;
            displaySetCutFlag4 = 1;
            displaySetCutFlag5 = 1;
            displaySetCutFlag6 = 1;
            displaySetCutFlag7 = 1;
            setStatus5 = 5;
        }
        
        for (int counter1 = 0; counter1 < imageSizeListCount/2; counter1++){
            if (arrayImageSizeList [counter1*2] == treatmentNameHold){
                imageDimension = atoi(arrayImageSizeList [counter1*2+1].c_str());
                break;
            }
        }
        
        if (cellNoHold != ""){
            int imageNumberTemp = 0;
            
            cellLineageInfoListCreationCall = 5;
            cellNumberInfoListCreationCall = 5;
            
            string cellLineageExtract = cellLineageNoHold.substr(1);
            string cellNoExtract = cellNoHold.substr(1);
            int lineageAmendTemp = atoi(cellLineageExtract.c_str());
            int cellAmendTemp = atoi(cellNoExtract.c_str());
            
            //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
            //	cout<<" arrayLineageData "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < treatmentStatusCount/9; counterA++){
            //  for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayTreatmentStatus [counterA*9+counterB];
            //   cout<<" arrayTreatmentStatus "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
            // 	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
            // 	cout<<" arrayConnectLineageRel "<<counterA<<endl;
            //}
            
            int lineageEntryStart = 10000;
            int lineageEntryEnd = 0;
            int lineageEntryStartHold = 10000;
            int lineageEntryEndHold = 0;
            
            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp && arrayLineageStartEnd [counter1*8+1] == cellAmendTemp){
                    for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                        if (arrayLineageData [counter2*8+2] > lineageEntryEndHold) lineageEntryEndHold = arrayLineageData [counter2*8+2], lineageEntryEnd = counter2;
                        if (arrayLineageData [counter2*8+2] < lineageEntryStartHold) lineageEntryStartHold = arrayLineageData [counter2*8+2], lineageEntryStart = counter2;
                    }
                    
                    break;
                }
            }
            
            if (lineageEntryEnd >= lineageEntryStart){
                if (xyPositionListStatus == 1) delete [] arrayXYPositionList;
                arrayXYPositionList = new int [(lineageEntryEnd-lineageEntryStart+1)*10+50];
                xyPositionListCount = 0;
                xyPositionListStatus = 1;
                
                //cout<<imageReturnPositionSet<<" "<<quickLineageConnect<<" "<<cellJumpFirstLast<<" "<<setStatus7<<" status"<<endl;
                
                for (int counter1 = lineageEntryStart; counter1 <= lineageEntryEnd; counter1++){
                    if (quickLineageConnect == 0 && cellJumpFirstLast == 0 && setStatus7 == 0 && imageReturnPositionSet == 0){
                        xCellPosition = arrayLineageData [counter1*8];
                        yCellPosition = arrayLineageData [counter1*8+1];
                        imageNumber = arrayLineageData [counter1*8+2];
                        
                        imageNumberTemp = arrayLineageData [counter1*8+2];
                        
                        if (counter1 == lineageEntryEnd) [self imageNoSet:imageNumberTemp];
                    }
                    else if (quickLineageConnect == 0 && cellJumpFirstLast != 0 && setStatus7 == 0 && imageReturnPositionSet == 0){
                        if (arrayLineageData [counter1*8+2] == imageNumberTrackForDisplay){
                            xCellPosition = arrayLineageData [counter1*8];
                            yCellPosition = arrayLineageData [counter1*8+1];
                        }
                        
                        imageNumberTemp = imageNumber;
                        
                        if (counter1 == lineageEntryEnd) [self imageNoSet:imageNumberTemp];
                    }
                    else if (quickLineageConnect == 0 && cellJumpFirstLast == 0 && setStatus7 == 0 && imageReturnPositionSet != 0){
                        if (arrayLineageData [counter1*8+2] == imageNumber){
                            xCellPosition = arrayLineageData [counter1*8];
                            yCellPosition = arrayLineageData [counter1*8+1];
                        }
                        
                        imageNumberTemp = imageNumber;
                        
                        if (counter1 == lineageEntryEnd) [self imageNoSet:imageNumberTemp];
                    }
                    else if (quickLineageConnect != 0 && cellJumpFirstLast == 0 && setStatus7 == 0){
                        if (arrayLineageData [counter1*8+2] == imageNumberTrackForDisplay){
                            xCellPosition = arrayLineageData [counter1*8];
                            yCellPosition = arrayLineageData [counter1*8+1];
                        }
                    }
                    
                    arrayXYPositionList [xyPositionListCount] = arrayLineageData [counter1*8+2], xyPositionListCount++; //-----Image Number-----
                    arrayXYPositionList [xyPositionListCount] = 0, xyPositionListCount++; //-----Connect Number-----
                    arrayXYPositionList [xyPositionListCount] = arrayLineageData [counter1*8], xyPositionListCount++; //-----X Position-----
                    arrayXYPositionList [xyPositionListCount] = arrayLineageData [counter1*8+1], xyPositionListCount++; //-----Y Position-----
                    arrayXYPositionList [xyPositionListCount] = 1, xyPositionListCount++; //-----Target-----
                    
                    if (imageReturnPositionSet != 0 && seqOpenFlag == 1 && seqImageClick == 0){
                        if (seqImageFirst == 0) seqImageFirst = arrayLineageData [counter1*8+2];
                        if (arrayLineageData [counter1*8+3] == 6) seqImageMitosis = arrayLineageData [counter1*8+2];
                        if (arrayLineageData [counter1*8+3] == 10) seqImageFusionMark = arrayLineageData [counter1*8+2];
                    }
                }
                
                if (imageReturnPositionSet != 0 && seqOpenFlag == 1 && imageSeqOperation == 1 && seqImageClick == 0){
                    seqImageNoSet1 = 0;
                    seqImageNoSet2 = 0;
                    seqImageNoSet3 = 0;
                    seqImageNoSet4 = 0;
                    seqImageNoSet5 = 0;
                    seqImageNoSet6 = 0;
                    seqImageNoSet7 = 0;
                    seqImageNoSet8 = 0;
                    seqImageNoSet9 = 0;
                    seqImageNoSet10 = 0;
                    
                    seqImageNoSet1 = seqImageCheck;
                    if (timeEndHold >= seqImageCheck+1) seqImageNoSet2 = seqImageCheck+1;
                    if (timeEndHold >= seqImageCheck+2) seqImageNoSet3 = seqImageCheck+2;
                    if (timeEndHold >= seqImageCheck+3) seqImageNoSet4 = seqImageCheck+3;
                    if (timeEndHold >= seqImageCheck+4) seqImageNoSet5 = seqImageCheck+4;
                    if (timeEndHold >= seqImageCheck+5) seqImageNoSet6 = seqImageCheck+5;
                    if (timeEndHold >= seqImageCheck+6) seqImageNoSet7 = seqImageCheck+6;
                    if (timeEndHold >= seqImageCheck+7 && noOfSeqDisplay == 1) seqImageNoSet8 = seqImageCheck+7;
                    if (timeEndHold >= seqImageCheck+8 && noOfSeqDisplay == 1) seqImageNoSet9 = seqImageCheck+8;
                    if (timeEndHold >= seqImageCheck+9 && noOfSeqDisplay == 1) seqImageNoSet10 = seqImageCheck+9;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay1 object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay2 object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay3 object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay4 object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay5 object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay6 object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay7 object:self];
                    
                    if (noOfSeqDisplay == 1){
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay8 object:self];
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay9 object:self];
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay10 object:self];
                    }
                }
                
                seqImageClick = 0;
                
                if (imageNumberTrackForDisplay == 0) imageNumberTrackForDisplay = imageNumber;
                
                quickLineageConnect = 0;
                cellJumpFirstLast = 7;
                setStatus7 = 0;
                imageReturnPositionSet = 0;
                
                //for (int counterA = 0; counterA < xyPositionListCount/5; counterA++){
                // 	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayXYPositionList [counterA*5+counterB];
                //	cout<<" arrayXYPositionList "<<counterA<<endl;
                //}
                
                string cellFusionPartnerPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_FusionPartner";
                
                struct stat sizeOfFile;
                long sizeForCopy = 0;
                
                if (stat(cellFusionPartnerPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    if (lineagePartnerInfoStatus == 1) delete [] arrayLineagePartnerInfo;
                    arrayLineagePartnerInfo = new string [sizeForCopy+50];
                    lineagePartnerInfoCount = 0;
                    lineagePartnerInfoStatus = 1;
                    
                    ifstream fin;
                    fin.open(cellFusionPartnerPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        string treatmentNameGet;
                        string lineageNoGet;
                        string cellNoGet;
                        string imageNoGet;
                        string partnerLingNoGet;
                        string partnerCellNoGet;
                        
                        int terminationFlag = 0;
                        
                        do{
                            
                            terminationFlag = 1;
                            getline(fin, treatmentNameGet);
                            
                            if (treatmentNameGet == "") terminationFlag = 0;
                            else{
                                
                                getline(fin, lineageNoGet);
                                getline(fin, cellNoGet);
                                getline(fin, imageNoGet);
                                getline(fin, partnerLingNoGet);
                                getline(fin, partnerCellNoGet);
                                
                                if (treatmentNameGet == treatmentNameHold && lineageAmendTemp == atoi(lineageNoGet.c_str()) && cellAmendTemp == atoi(cellNoGet.c_str())){
                                    arrayLineagePartnerInfo [lineagePartnerInfoCount] = treatmentNameGet, lineagePartnerInfoCount++;
                                    arrayLineagePartnerInfo [lineagePartnerInfoCount] = lineageNoGet, lineagePartnerInfoCount++;
                                    arrayLineagePartnerInfo [lineagePartnerInfoCount] = cellNoGet, lineagePartnerInfoCount++;
                                    arrayLineagePartnerInfo [lineagePartnerInfoCount] = imageNoGet, lineagePartnerInfoCount++;
                                    arrayLineagePartnerInfo [lineagePartnerInfoCount] = partnerLingNoGet, lineagePartnerInfoCount++;
                                    arrayLineagePartnerInfo [lineagePartnerInfoCount] = partnerCellNoGet, lineagePartnerInfoCount++;
                                }
                            }
                            
                        } while (terminationFlag == 1);
                        
                        fin.close();
                    }
                }
                else if (lineagePartnerInfoStatus == 1){
                    delete [] arrayLineagePartnerInfo;
                    lineagePartnerInfoCount = 0;
                    lineagePartnerInfoStatus = 0;
                }
                
                //for (int counterA = 0; counterA < lineagePartnerInfoCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayLineagePartnerInfo [counterA*6+counterB];
                //	cout<<" arrayLineagePartnerInfo "<<counterA<<endl;
                //}
                
                string trackingTablePath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+analysisID+"_"+cellLineageNoHold+"_lineDataAmend";
                
                if (stat(trackingTablePath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    if (connectLineListLocalStatus == 1) delete [] arrayConnectLineListLocal;
                    arrayConnectLineListLocal = new int [sizeForCopy+50];
                    connectLineListLocalCount = 0;
                    connectLineListLocalLimit = (int)sizeForCopy+50;
                    connectLineListLocalStatus = 1;
                    
                    ifstream fin;
                    fin.open(trackingTablePath.c_str(), ios::in | ios::binary);
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    int finData [13];
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++; //--3
                            finData [6] = uploadTemp [readPosition], readPosition++; //--4
                            finData [7] = uploadTemp [readPosition], readPosition++;
                            finData [8] = uploadTemp [readPosition], readPosition++;
                            finData [9] = uploadTemp [readPosition], readPosition++; //--5
                            finData [10] = uploadTemp [readPosition], readPosition++;
                            finData [11] = uploadTemp [readPosition], readPosition++;
                            finData [12] = uploadTemp [readPosition], readPosition++; //--6
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [5] = finData [4]*256+finData [5];
                            finData [9] = finData [7]*65536+finData [8]*256+finData [9];
                            finData [12] = finData [10]*65536+finData [11]*256+finData [12];
                            
                            if (finData [1] == 0 && finData [3] == 0) stepCount = 3;
                            else{
                                
                                if (connectLineListLocalCount+10 > connectLineListLocalLimit){
                                    int *arrayUpDate = new int [connectLineListLocalCount+10];
                                    
                                    for (int counter1 = 0; counter1 < connectLineListLocalCount; counter1++) arrayUpDate [counter1] = arrayConnectLineListLocal [counter1];
                                    
                                    delete [] arrayConnectLineListLocal;
                                    arrayConnectLineListLocal = new int [connectLineListLocalLimit+500];
                                    connectLineListLocalLimit = connectLineListLocalLimit+500;
                                    
                                    for (int counter1 = 0; counter1 < connectLineListLocalCount; counter1++) arrayConnectLineListLocal [counter1] = arrayUpDate [counter1];
                                    delete [] arrayUpDate;
                                }
                                
                                arrayConnectLineListLocal [connectLineListLocalCount] = finData [3], connectLineListLocalCount++; //-----X Position-----
                                arrayConnectLineListLocal [connectLineListLocalCount] = finData [5], connectLineListLocalCount++; //-----Y Position-----
                                arrayConnectLineListLocal [connectLineListLocalCount] = finData [6], connectLineListLocalCount++; //-----Event Type-----
                                arrayConnectLineListLocal [connectLineListLocalCount] = finData [9], connectLineListLocalCount++; //-----Connect No-----
                                arrayConnectLineListLocal [connectLineListLocalCount] = finData [12], connectLineListLocalCount++; //-----Lineage No-----
                                arrayConnectLineListLocal [connectLineListLocalCount] = finData [1], connectLineListLocalCount++; //-----Image no-----
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
                
                //for (int counterA = 0; counterA < connectLineListLocalCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineListLocal [counterA*6+counterB];
                //	cout<<" arrayConnectLineListLocal "<<counterA<<endl;
                //}
                
                int lineSetError = 0;
                lineSet = [[LineSet alloc] init];
                lineSetError = [lineSet dataRead:imageNumber];
                
                if (lineSetError == 0){
                    if (dataEntryStatus == 1){
                        do{
                            
                            if (masterLineForTrackingStatus == 1 && masterLineForDisplayStatus == 1 && masterLineGravityCenterStatus == 1 && masterLineGCDisplayStatus == 1){
                                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
                                
                                if (imageNumberDisplayForDisplay == 0){
                                    verificationPositionCall = 0;
                                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
                                }
                            }
                            
                        } while (masterLineForTrackingStatus == 0 || masterLineForDisplayStatus == 0 || masterLineGravityCenterStatus == 0 || masterLineGCDisplayStatus == 0);
                    }
                    else [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
                    
                    if (listLingNoHold != cellLineageNoHold || listCellNoHold != cellNoHold){
                        listLingNoHold = cellLineageNoHold;
                        listCellNoHold = cellNoHold;
                        listLingRecent = cellLineageNoHold;
                        listCellRecent = cellNoHold;
                        
                        if (listLoadingStart == 0) listLoadingStart = 1;
                    }
                }
            }
            else cellNoHold = "";
        }
        
        if (cellLineageNoHold != "" && cellNoHold == ""){
            int imageNumberTemp = 0;
            
            cellLineageInfoListCreationCall = 5;
            cellNumberInfoListCreationCall = 6;
            
            //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
            //	cout<<" arrayLineageData "<<counterA<<endl;
            //}
            
            string cellLineageExtract = cellLineageNoHold.substr(1);
            int lineageAmendTemp = atoi(cellLineageExtract.c_str());
            
            xCellPosition = -1;
            yCellPosition = -1;
            
            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp){
                    for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                        if (arrayLineageData [counter2*8+3] == 1 && arrayLineageData [counter2*8+5] == 0){
                            xCellPosition = arrayLineageData [counter2*8];
                            yCellPosition = arrayLineageData [counter2*8+1];
                            imageNumber = arrayLineageData [counter2*8+2];
                            imageNumberTemp = arrayLineageData [counter2*8+2];
                            
                            [self imageNoSet:(int)imageNumberTemp];
                            
                            break;
                        }
                    }
                }
            }
            
            if (xyPositionListStatus == 1) delete [] arrayXYPositionList;
            arrayXYPositionList = new int [50];
            xyPositionListCount = 0;
            xyPositionListStatus = 1;
            
            arrayXYPositionList [xyPositionListCount] = imageNumber, xyPositionListCount++; //-----Image Number-----
            arrayXYPositionList [xyPositionListCount] = 0, xyPositionListCount++; //-----Connect Number-----
            arrayXYPositionList [xyPositionListCount] = xCellPosition, xyPositionListCount++; //-----X Position-----
            arrayXYPositionList [xyPositionListCount] = yCellPosition, xyPositionListCount++; //-----Y Position-----
            arrayXYPositionList [xyPositionListCount] = 1, xyPositionListCount++; //-----Target-----
            
            //for (int counterA = 0; counterA < xyPositionListCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayXYPositionList [counterA*5+counterB];
            //    cout<<" arrayXYPositionList "<<counterA<<endl;
            //}
            
            int lineSetError = 0;
            
            lineSet = [[LineSet alloc] init];
            lineSetError =[lineSet dataRead:imageNumber];
            
            if (lineSetError == 0){
                if (dataEntryStatus == 1){
                    do{
                        
                        if (masterLineForTrackingStatus == 1 && masterLineForDisplayStatus == 1 && masterLineGravityCenterStatus == 1 && masterLineGCDisplayStatus == 1){
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
                            
                            if (imageNumberDisplayForDisplay == 0){
                                verificationPositionCall = 0;
                                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
                            }
                            
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToListWindow object:self];
                        }
                        
                    } while (masterLineForTrackingStatus == 0 || masterLineForDisplayStatus == 0 || masterLineGravityCenterStatus == 0 || masterLineGCDisplayStatus == 0);
                }
                else{
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
                    
                    if (imageNumberDisplayForDisplay == 0){
                        verificationPositionCall = 0;
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
                    }
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToListWindow object:self];
                }
            }
        }
        
        if (treatmentNameHold != "" && cellLineageNoHold == ""){
            cellLineageInfoListCreationCall = 6;
            cellNumberInfoListCreationCall = 6;
            
            if (addDelInsert == 0){
                xCellPosition = -1;
                yCellPosition = -1;
                imageNumber = timeOneHold;
            }
            
            int lineSetError = 0;
            
            lineSet = [[LineSet alloc] init];
            lineSetError = [lineSet dataRead:imageNumber];
            
            if (lineSetError == 0){
                if (dataEntryStatus == 1){
                    do{
                        
                        if (masterLineForTrackingStatus == 1 && masterLineForDisplayStatus == 1 && masterLineGravityCenterStatus == 1 && masterLineGCDisplayStatus == 1){
                            verificationPositionCall = 0;
                            
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToListWindow object:self];
                        }
                        
                    } while (masterLineForTrackingStatus == 0 || masterLineForDisplayStatus == 0 || masterLineGravityCenterStatus == 0 || masterLineGCDisplayStatus == 0);
                }
                else{
                    
                    verificationPositionCall = 0;
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToListWindow object:self];
                }
            }
        }
        
        //**********Start/End assay*********
        //1. Lineage no;
        //2. Cell no;
        //3. X position;
        //4. Y position;
        //5. Start;
        //6. Image start;
        //7. End;
        //8. Image end
        
        if (lineageStartEndCount != 0){
            if (cellEndHoldStatus == 0){
                cellEndHold = new int [10000];
                cellEndHoldCount = 0;
                cellEndHoldLimit = 10000;
                cellEndHoldStatus = 1;
            }
            else cellEndHoldCount = 0;
            
            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                if (arrayLineageStartEnd [counter1*8+7] == imageNumberTrackForDisplay){
                    if (cellEndHoldLimit < cellEndHoldCount+10){
                        int *arrayUpDate = new int [cellEndHoldCount+10];
                        
                        for (int counter2 = 0; counter2 < cellEndHoldCount; counter2++) arrayUpDate [counter2] = cellEndHold [counter2];
                        
                        delete [] cellEndHold;
                        cellEndHold = new int [cellEndHoldLimit+10000];
                        cellEndHoldLimit = cellEndHoldLimit+10000;
                        
                        for (int counter2 = 0; counter2 < cellEndHoldCount; counter2++) cellEndHold [counter2] = arrayUpDate [counter2];
                        delete [] arrayUpDate;
                    }
                    
                    if (arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 2 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 1 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 6 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 31 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 41 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 51 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 92 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 10 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 11){
                        cellEndHold [cellEndHoldCount] = arrayLineageStartEnd [counter1*8], cellEndHoldCount++;
                        cellEndHold [cellEndHoldCount] = arrayLineageStartEnd [counter1*8+1], cellEndHoldCount++;
                    }
                }
            }
        }
        
        if (setStatus7 == 7) setStatus7 = 0;
    }
    
    if (quickLineSetCall == 1){
        quickLineSetCall = 0;
        lineSetErrorFlag = 0;
        gravityCenterNotRecorded = "nil";
        
        [self lineSelectProcess];
        
        if (lineSetErrorFlag == 0){
            string cellLineageExtract = cellLineageNoHold.substr(1);
            string cellNoExtract = cellNoHold.substr(1);
            int cellLineageTempInt = atoi(cellLineageExtract.c_str());
            int cellNumberTempInt = atoi(cellNoExtract.c_str());
            int connectExpandTemp = 0;
            
            referenceLineCount = 0;
            
            for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt){
                    connectExpandTemp = arrayConnectLineageRel [counter1*6+1];
                    break;
                }
            }
            
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                if (arrayTimeSelected [counter1*10+8] == connectExpandTemp){
                    for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                        if (arrayPositionRevise [counter2*7+3] == connectExpandTemp){
                            if (referenceLineCount+4 > referenceLineLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate referenceLineCountUpDate];
                            }
                            
                            arrayReferenceLine [referenceLineCount] = arrayPositionRevise [counter2*7], referenceLineCount++;
                            arrayReferenceLine [referenceLineCount] = arrayPositionRevise [counter2*7+1], referenceLineCount++;
                        }
                        else{
                            
                            break;
                        }
                    }
                }
            }
            
            int processType = 2;
            lineSet = [[LineSet alloc] init];
            [lineSet lineSetProcess:processType];
        }
    }
    
    if (quickLineSetCall == 2){
        quickLineSetCall = 0;
        
        if (lineDraw == 0){
            areaSelectStatus = 0;
            lineDraw = 1;
            windowLock = 1;
        }
        else if (lineDraw == 1){
            lineDraw = 0;
            windowLock = 0;
        }
        
        lineAreaCall = 1;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
    }
    
    if (saveShortCutNumber == 1){
        saveShortCutNumber = 0;
        [self saveDataMain];
    }
    
    if (saveShortCutNumber == 2){
        saveShortCutNumber = 0;
        int processType = 1;
        lineSet = [[LineSet alloc] init];
        [lineSet lineSetProcess:processType];
    }
    
    if (saveShortCutNumber == 3){
        saveShortCutNumber = 0;
        [self deleteProgeniesMain];
    }
    
    if (saveShortCutNumber == 4){
        saveShortCutNumber = 0;
        [self checkOKMain];
    }
    
    if (saveShortCutNumber == 5){
        saveShortCutNumber = 0;
        forceSetStatus = 1;
        int processType = 1;
        
        lineSet = [[LineSet alloc] init];
        [lineSet lineSetProcess:processType];
    }
    
    if (saveShortCutNumber == 6){
        saveShortCutNumber = 0;
        forceSetStatus = 0;
        int processType = 1;
        
        lineSet = [[LineSet alloc] init];
        [lineSet lineSetProcess:processType];
    }
    
    if (listLoadingStart == 1){
        listLoadingStart = 2;
        
        listLingCurrent = listLingRecent;
        listCellCurrent = listCellRecent;
        
        listLingRecent = "";
        listCellRecent = "";
        
        [self listDataUploading];
    }
    else if (listLoadingStart == 3){
        if (listLingRecent != "" && listCellRecent != ""){
            listLoadingStart = 1;
        }
        else{
            
            listLoadingStart = 0;
            listLingCurrent = "";
            listCellCurrent = "";
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToListWindow object:self];
        }
    }
    
    if (dicAllStartFlag == 1){
        dicAllStartFlag = 2;
        dicAllStartFlag = 3;
    }
    else if (dicAllStartFlag >= 3 && dicAllStartFlag < 20){
        dicAllStartFlag++;
    }
    else if (dicAllStartFlag == 20){
        dicAllStartFlag = 21;
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDicExpand object:self];
    }
    else if (dicAllStartFlag == 22){
        dicAllStartFlag = 0;
    }
    
    if (progressTiming == 9){
        [backSave startAnimation:self];
        
        if (backSave) progressTiming = 10;
    }
    else if (progressTiming == 11){
        [backSave stopAnimation:self];
        
        if (backSave) progressTiming = 0;
    }
}

-(void)statusMonitor2{
    if (trackForwardControl == 1){
        [trackingControllerWindow makeKeyAndOrderFront:self];
        
        NSWindow *keyWindow = [[NSApplication sharedApplication] keyWindow];
        NSString *title = [keyWindow title];
        
        if ([title isEqualToString:@"Tracking"]) trackForwardControl = 0;
    }
    
    if (inputNumberCall == 1){
        int inputNumberInt = inputNumber;
        
        [inputData setIntegerValue:inputNumberInt];
        [jumpDisplay setIntegerValue:inputNumberInt];
        
        if ([inputData integerValue] == inputNumber) inputNumberCall = 0;
    }
}

-(void)imageNoSet:(int)setNumber{
    //cout<<setNumber<<" "<<imageNumberTrackForDisplay<<" "<<ifEntry<<" "<<ifStartHold<<"  "<<imageNumber<<" InfoImage"<<endl;
    
    if (setNumber <= imageNumberTrackForDisplay && ifEntry == 1){
        if (ifStartHold != 0 && setNumber < ifStartHold){
            ifEntry = 0;
            fluorescentNo1 = fluorescentNoHold1;
            fluorescentNo2 = fluorescentNoHold2;
            fluorescentNo3 = fluorescentNoHold3;
            fluorescentNo4 = fluorescentNoHold4;
            fluorescentNo5 = fluorescentNoHold5;
            fluorescentNo6 = fluorescentNoHold6;
            fluorescentEntryCount = fluorescentEntryCountHold;
            fluorescentName1 = fluorescentNameHold1;
            fluorescentName2 = fluorescentNameHold2;
            fluorescentName3 = fluorescentNameHold3;
            fluorescentName4 = fluorescentNameHold4;
            fluorescentName5 = fluorescentNameHold5;
            fluorescentName6 = fluorescentNameHold6;
            
            string extension = to_string(setNumber);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            string extension2 = to_string(fluorescentNo1);
            string fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+exType;
            
            struct stat sizeOfFile;
            
            if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0){
                int matchFind = 0;
                
                for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                    if (arrayFluorescentCutOff [counter1*7] == setNumber){
                        fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                        fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                        fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                        fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                        fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                        fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                        matchFind = 1;
                        break;
                    }
                }
                
                if (matchFind == 0){
                    string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
                    
                    if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                        int nearestCount = 0;
                        
                        for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                            if (arrayFluorescentCutOff [counter1*7] < setNumber){
                                if (nearestCount < arrayFluorescentCutOff [counter1*7]){
                                    nearestCount = arrayFluorescentCutOff [counter1*7];
                                    fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                    fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                    fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                    fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                                    fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                                    fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                                }
                            }
                        }
                        
                        if (fluorescentCutOffStatus == 0){
                            arrayFluorescentCutOff = new int [imageEndHold*7];
                            fluorescentCutOffCount = 0;
                            fluorescentCutOffStatus = 1;
                        }
                        
                        if (nearestCount != 0){
                            arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
                        }
                        else{
                            
                            arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        }
                        
                        ofstream oin;
                        oin.open(cutOffPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                        
                        oin<<"End"<<endl;
                        oin.close();
                    }
                    else{
                        
                        fluorescentCutOff1 = 150;
                        fluorescentCutOff2 = 150;
                        fluorescentCutOff3 = 150;
                        fluorescentCutOff4 = 150;
                        fluorescentCutOff5 = 150;
                        fluorescentCutOff6 = 150;
                        
                        if (fluorescentCutOffStatus == 0){
                            arrayFluorescentCutOff = new int [imageEndHold*7];
                            fluorescentCutOffCount = 0;
                            fluorescentCutOffStatus = 1;
                        }
                        
                        arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        
                        ofstream oin;
                        oin.open(cutOffPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                        
                        oin<<"End"<<endl;
                        oin.close();
                    }
                }
            }
        }
        else if (ifStartHold != 0 && setNumber >= ifStartHold){
            int nextLoad = 0;
            
            for (int counter1 = 0; counter1 < 450; counter1 = counter1+15){
                if (atoi(arrayIFDataHold [counter1].c_str()) != 0 && atoi(arrayIFDataHold [counter1+14].c_str()) <= setNumber){
                    nextLoad = counter1/15+1;
                }
                else if (atoi(arrayIFDataHold [counter1].c_str()) == 0){
                    break;
                }
            }
            
            if (nextLoad > 0){
                nextLoad--;
                
                fluorescentNo1 = 0;
                fluorescentNo2 = 0;
                fluorescentNo3 = 0;
                fluorescentNo4 = 0;
                fluorescentNo5 = 0;
                fluorescentNo6 = 0;
                fluorescentEntryCount = 0;
                fluorescentName1 = "";
                fluorescentName2 = "";
                fluorescentName3 = "";
                fluorescentName4 = "";
                fluorescentName5 = "";
                fluorescentName6 = "";
                
                fluorescentEntryCount = atoi(arrayIFDataHold [nextLoad*15+13].c_str());
                fluorescentRoundNo = arrayIFDataHold [nextLoad*15];
                
                if (fluorescentEntryCount >= 1){
                    fluorescentNo1 = atoi(arrayIFDataHold [nextLoad*15+7].c_str());
                    fluorescentName1 = arrayIFDataHold [nextLoad*15+1];
                }
                if (fluorescentEntryCount >= 2){
                    fluorescentNo2 = atoi(arrayIFDataHold [nextLoad*15+8].c_str());
                    fluorescentName2 = arrayIFDataHold [nextLoad*15+2];
                }
                if (fluorescentEntryCount >= 3){
                    fluorescentNo3 = atoi(arrayIFDataHold [nextLoad*15+9].c_str());
                    fluorescentName3 = arrayIFDataHold [nextLoad*15+3];
                }
                if (fluorescentEntryCount >= 4){
                    fluorescentNo4 = atoi(arrayIFDataHold [nextLoad*15+10].c_str());
                    fluorescentName4 = arrayIFDataHold [nextLoad*15+4];
                }
                if (fluorescentEntryCount >= 5){
                    fluorescentNo5 = atoi(arrayIFDataHold [nextLoad*15+11].c_str());
                    fluorescentName5 = arrayIFDataHold [nextLoad*15+5];
                }
                if (fluorescentEntryCount >= 6){
                    fluorescentNo6 = atoi(arrayIFDataHold [nextLoad*15+12].c_str());
                    fluorescentName6 = arrayIFDataHold [nextLoad*15+6];
                }
            }
            
            string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
            
            struct stat sizeOfFile;
            
            if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                int matchFind = 0;
                
                for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                    if (arrayFluorescentCutOff [counter1*7] == setNumber){
                        fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                        fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                        fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                        fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                        fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                        fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                        matchFind = 1;
                        
                        break;
                    }
                }
                
                if (matchFind == 0){
                    int nearestCount = 0;
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                        if (arrayFluorescentCutOff [counter1*7] < setNumber){
                            if (nearestCount < arrayFluorescentCutOff [counter1*7]){
                                nearestCount = arrayFluorescentCutOff [counter1*7];
                                fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                                fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                                fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                            }
                        }
                    }
                    
                    if (fluorescentCutOffStatus == 0){
                        arrayFluorescentCutOff = new int [imageEndHold*7];
                        fluorescentCutOffCount = 0;
                        fluorescentCutOffStatus = 1;
                    }
                    
                    if (nearestCount != 0){
                        arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
                    }
                    else{
                        
                        arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    }
                    
                    ofstream oin;
                    oin.open(cutOffPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                    
                    oin<<"End"<<endl;
                    oin.close();
                }
            }
            else{
                
                fluorescentCutOff1 = 150;
                fluorescentCutOff2 = 150;
                fluorescentCutOff3 = 150;
                fluorescentCutOff4 = 150;
                fluorescentCutOff5 = 150;
                fluorescentCutOff6 = 150;
                
                if (fluorescentCutOffStatus == 0){
                    arrayFluorescentCutOff = new int [imageEndHold*7];
                    fluorescentCutOffCount = 0;
                    fluorescentCutOffStatus = 1;
                }
                
                arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                
                ofstream oin;
                oin.open(cutOffPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                
                oin<<"End"<<endl;
                oin.close();
            }
        }
        
        imageNumberTrackForDisplay = setNumber;
        fluorescentValueDisplayControl = 1;
        setStatus4 = 4;
    }
    else if (setNumber <= imageNumberTrackForDisplay && ifEntry == 0) imageNumberTrackForDisplay = setNumber;
    else if (setNumber >= imageNumberTrackForDisplay && ifEntry == 0){
        if (ifStartHold != 0 && setNumber >= ifStartHold){
            ifEntry = 1;
            fluorescentNoHold1 = fluorescentNo1;
            fluorescentNoHold2 = fluorescentNo2;
            fluorescentNoHold3 = fluorescentNo3;
            fluorescentNoHold4 = fluorescentNo4;
            fluorescentNoHold5 = fluorescentNo5;
            fluorescentNoHold6 = fluorescentNo6;
            fluorescentEntryCountHold = fluorescentEntryCount;
            fluorescentNameHold1 = fluorescentName1;
            fluorescentNameHold2 = fluorescentName2;
            fluorescentNameHold3 = fluorescentName3;
            fluorescentNameHold4 = fluorescentName4;
            fluorescentNameHold5 = fluorescentName5;
            fluorescentNameHold6 = fluorescentName6;
            
            int nextLoad = 0;
            
            for (int counter1 = 0; counter1 < 450; counter1 = counter1+15){
                if (atoi(arrayIFDataHold [counter1].c_str()) != 0 && atoi(arrayIFDataHold [counter1+14].c_str()) <= setNumber){
                    nextLoad = counter1/15+1;
                }
                else if (atoi(arrayIFDataHold [counter1].c_str()) == 0){
                    break;
                }
            }
            
            if (nextLoad > 0){
                nextLoad--;
                
                fluorescentNo1 = 0;
                fluorescentNo2 = 0;
                fluorescentNo3 = 0;
                fluorescentNo4 = 0;
                fluorescentNo5 = 0;
                fluorescentNo6 = 0;
                fluorescentEntryCount = 0;
                fluorescentName1 = "";
                fluorescentName2 = "";
                fluorescentName3 = "";
                fluorescentName4 = "";
                fluorescentName5 = "";
                fluorescentName6 = "";
                
                fluorescentEntryCount = atoi(arrayIFDataHold [nextLoad*15+13].c_str());
                fluorescentRoundNo = arrayIFDataHold [nextLoad*15];
                
                if (fluorescentEntryCount >= 1){
                    fluorescentNo1 = atoi(arrayIFDataHold [nextLoad*15+7].c_str());
                    fluorescentName1 = arrayIFDataHold [nextLoad*15+1];
                }
                if (fluorescentEntryCount >= 2){
                    fluorescentNo2 = atoi(arrayIFDataHold [nextLoad*15+8].c_str());
                    fluorescentName2 = arrayIFDataHold [nextLoad*15+2];
                }
                if (fluorescentEntryCount >= 3){
                    fluorescentNo3 = atoi(arrayIFDataHold [nextLoad*15+9].c_str());
                    fluorescentName3 = arrayIFDataHold [nextLoad*15+3];
                }
                if (fluorescentEntryCount >= 4){
                    fluorescentNo4 = atoi(arrayIFDataHold [nextLoad*5+10].c_str());
                    fluorescentName4 = arrayIFDataHold [nextLoad*15+4];
                }
                if (fluorescentEntryCount >= 5){
                    fluorescentNo5 = atoi(arrayIFDataHold [nextLoad*15+11].c_str());
                    fluorescentName5 = arrayIFDataHold [nextLoad*15+5];
                }
                if (fluorescentEntryCount >= 6){
                    fluorescentNo6 = atoi(arrayIFDataHold [nextLoad*15+12].c_str());
                    fluorescentName6 = arrayIFDataHold [nextLoad*15+6];
                }
                if (lineModificationFlag == 1 && trackingUpperLimit < setNumber){
                    trackingUpperLimit = setNumber;
                    trackingOnInfoDisplay = 1;
                }
            }
            
            if (lineModificationFlag == 1 && trackingUpperLimit < setNumber){
                trackingUpperLimit = setNumber;
                trackingOnInfoDisplay = 1;
            }
            
            string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
            
            struct stat sizeOfFile;
            
            if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                int matchFind = 0;
                
                for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                    if (arrayFluorescentCutOff [counter1*7] == setNumber){
                        fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                        fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                        fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                        fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                        fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                        fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                        matchFind = 1;
                        
                        break;
                    }
                }
                
                if (matchFind == 0){
                    int nearestCount = 0;
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                        if (arrayFluorescentCutOff [counter1*7] < setNumber){
                            if (nearestCount < arrayFluorescentCutOff [counter1*7]){
                                nearestCount = arrayFluorescentCutOff [counter1*7];
                                fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                                fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                                fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                            }
                        }
                    }
                    
                    if (fluorescentCutOffStatus == 0){
                        arrayFluorescentCutOff = new int [imageEndHold*7];
                        fluorescentCutOffCount = 0;
                        fluorescentCutOffStatus = 1;
                    }
                    
                    if (nearestCount != 0){
                        arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
                    }
                    else{
                        
                        arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    }
                    
                    ofstream oin;
                    oin.open(cutOffPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                    
                    oin<<"End"<<endl;
                    oin.close();
                }
            }
            else{
                
                fluorescentCutOff1 = 150;
                fluorescentCutOff2 = 150;
                fluorescentCutOff3 = 150;
                fluorescentCutOff4 = 150;
                fluorescentCutOff5 = 150;
                fluorescentCutOff6 = 150;
                
                if (fluorescentCutOffStatus == 0){
                    arrayFluorescentCutOff = new int [imageEndHold*7];
                    fluorescentCutOffCount = 0;
                    fluorescentCutOffStatus = 1;
                }
                
                arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                
                ofstream oin;
                oin.open(cutOffPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                
                oin<<"End"<<endl;
                oin.close();
            }
            
            imageNumberTrackForDisplay = setNumber;
            fluorescentValueDisplayControl = 1;
            setStatus4 = 4;
        }
        else if (ifStartHold == 0 || setNumber < ifStartHold) imageNumberTrackForDisplay = setNumber;
    }
    else if (setNumber >= imageNumberTrackForDisplay && ifEntry == 1){
        int nextLoad = 0;
        
        for (int counter1 = 0; counter1 < 450; counter1 = counter1+15){
            if (atoi(arrayIFDataHold [counter1].c_str()) != 0 && atoi(arrayIFDataHold [counter1+14].c_str()) <= setNumber){
                nextLoad = counter1/15+1;
            }
            else if (atoi(arrayIFDataHold [counter1].c_str()) == 0){
                break;
            }
        }
        
        if (nextLoad > 0){
            nextLoad--;
            
            fluorescentNo1 = 0;
            fluorescentNo2 = 0;
            fluorescentNo3 = 0;
            fluorescentNo4 = 0;
            fluorescentNo5 = 0;
            fluorescentNo6 = 0;
            fluorescentEntryCount = 0;
            fluorescentName1 = "";
            fluorescentName2 = "";
            fluorescentName3 = "";
            fluorescentName4 = "";
            fluorescentName5 = "";
            fluorescentName6 = "";
            
            fluorescentEntryCount = atoi(arrayIFDataHold [nextLoad*15+13].c_str());
            fluorescentRoundNo = arrayIFDataHold [nextLoad*15];
            
            if (fluorescentEntryCount >= 1){
                fluorescentNo1 = atoi(arrayIFDataHold [nextLoad*15+7].c_str());
                fluorescentName1 = arrayIFDataHold [nextLoad*15+1];
            }
            if (fluorescentEntryCount >= 2){
                fluorescentNo2 = atoi(arrayIFDataHold [nextLoad*15+8].c_str());
                fluorescentName2 = arrayIFDataHold [nextLoad*15+2];
            }
            if (fluorescentEntryCount >= 3){
                fluorescentNo3 = atoi(arrayIFDataHold [nextLoad*15+9].c_str());
                fluorescentName3 = arrayIFDataHold [nextLoad*15+3];
            }
            if (fluorescentEntryCount >= 4){
                fluorescentNo4 = atoi(arrayIFDataHold [nextLoad*15+10].c_str());
                fluorescentName4 = arrayIFDataHold [nextLoad*15+4];
            }
            if (fluorescentEntryCount >= 5){
                fluorescentNo5 = atoi(arrayIFDataHold [nextLoad*15+11].c_str());
                fluorescentName5 = arrayIFDataHold [nextLoad*15+5];
            }
            if (fluorescentEntryCount >= 6){
                fluorescentNo6 = atoi(arrayIFDataHold [nextLoad*15+12].c_str());
                fluorescentName6 = arrayIFDataHold [nextLoad*15+6];
            }
            if (lineModificationFlag == 1 && trackingUpperLimit < setNumber){
                trackingUpperLimit = setNumber;
                trackingOnInfoDisplay = 1;
            }
        }
        
        string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
        
        struct stat sizeOfFile;
        
        if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
            int matchFind = 0;
            
            for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                if (arrayFluorescentCutOff [counter1*7] == setNumber){
                    fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                    fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                    fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                    fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                    fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                    fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                    matchFind = 1;
                    
                    break;
                }
            }
            
            if (matchFind == 0){
                int nearestCount = 0;
                
                for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                    if (arrayFluorescentCutOff [counter1*7] < setNumber){
                        if (nearestCount < arrayFluorescentCutOff [counter1*7]){
                            nearestCount = arrayFluorescentCutOff [counter1*7];
                            fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                            fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                            fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                            fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                            fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                            fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                        }
                    }
                }
                
                if (fluorescentCutOffStatus == 0){
                    arrayFluorescentCutOff = new int [imageEndHold*7];
                    fluorescentCutOffCount = 0;
                    fluorescentCutOffStatus = 1;
                }
                
                if (nearestCount != 0){
                    arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
                }
                else{
                    
                    arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                }
                
                ofstream oin;
                oin.open(cutOffPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                
                oin<<"End"<<endl;
                oin.close();
            }
        }
        else{
            
            fluorescentCutOff1 = 150;
            fluorescentCutOff2 = 150;
            fluorescentCutOff3 = 150;
            fluorescentCutOff4 = 150;
            fluorescentCutOff5 = 150;
            fluorescentCutOff6 = 150;
            
            if (fluorescentCutOffStatus == 0){
                arrayFluorescentCutOff = new int [imageEndHold*7];
                fluorescentCutOffCount = 0;
                fluorescentCutOffStatus = 1;
            }
            
            arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
            
            ofstream oin;
            oin.open(cutOffPath.c_str(), ios::out);
            
            for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
            
            oin<<"End"<<endl;
            oin.close();
        }
        
        if (lineModificationFlag == 1 && trackingUpperLimit < setNumber){
            trackingUpperLimit = setNumber;
            trackingOnInfoDisplay = 1;
        }
        
        imageNumberTrackForDisplay = setNumber;
        fluorescentValueDisplayControl = 1;
        setStatus4 = 4;
    }
    
    if (ifEntry == 0) fluorescentDisplayNo = 0;
}

-(BOOL)validateToolbarItem:(NSToolbarItem *)theItem {
    BOOL returnResult = YES;
    
    if (timeOneStatus == 0 && divisionTypeHold == 0){
        if ([theItem tag] == -10 || [theItem tag] == -15) returnResult = NO;
        else returnResult = YES;
    }
    else if (timeOneStatus == 0 && (divisionTypeHold != 0 || fusionOperation != 0)){
        if ([theItem tag] == -10 || [theItem tag] == -15 || [theItem tag] == -16) returnResult = NO;
        else returnResult = YES;
    }
    
    if (timeOneStatus == 2){
        if ([theItem tag] == -27) returnResult = NO;
        else returnResult = YES;
    }
    
    if (queueHoldingStatus == 1){
        if ([theItem tag] == -11) returnResult = NO;
        else returnResult = YES;
    }
    
    return returnResult;
}

-(IBAction)closeWindowTracking:(id)sender{
    trackingTableOperation = 2;
    [trackingControllerWindow orderOut:self];
    trackWindowTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayTrackingWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayTrackingWindow{
    if (trackingTableOperation == 3){
        [trackingControllerWindow makeKeyAndOrderFront:self];
        trackingTableOperation = 1;
        [trackWindowTimer invalidate];
    }
}

-(IBAction)closeWindowNavigation:(id)sender{
    navigationOperation = 2;
    [displayControllerWindow orderOut:self];
    navigationWindowTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayNavigationWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayNavigationWindow{
    if (navigationOperation == 3){
        navigationOperation = 1;
        [displayControllerWindow makeKeyAndOrderFront:self];
        [navigationWindowTimer invalidate];
    }
}

-(IBAction)closeWindowList:(id)sender{
    listWindowOperation = 2;
    [listViewControllerWindow orderOut:self];
    listWindowTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayListWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayListWindow{
    if (listWindowOperation == 3){
        listWindowOperation = 1;
        [listViewControllerWindow makeKeyAndOrderFront:self];
        [listWindowTimer invalidate];
    }
}

-(IBAction)saveData:(id)sender{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        [self saveDataMain];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)saveDataMain{
    if (timeOneStatus == 0 && fluorescentDivisionStatus == 1 && fluorescentDivisionTime == imageNumberTrackForDisplay && fluorescentDivisionCh == fluorescentDisplayNo && trackingOn == 1){
        if (fluorescentLevelDataCount != 0 && fluorescentSaveCount != 0){
            fluorescentSaveCount = 0;
            
            int readBit [3];
            int dataTemp = 0;
            unsigned long indexCount = 0;
            
            char *writingArray = new char [fluorescentLevelDataCount*2+20];
            
            for (int counter1 = 0; counter1 < fluorescentLevelDataCount/4; counter1++){
                dataTemp = fluorescentLevelDataHold [counter1*4];
                
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                
                writingArray [indexCount] = (char)fluorescentLevelDataHold [counter1*4+1], indexCount++;
                writingArray [indexCount] = (char)fluorescentLevelDataHold [counter1*4+2], indexCount++;
                
                dataTemp = fluorescentLevelDataHold [counter1*4+3];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
            }
            
            for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
            
            ofstream outfile2 (fluorescentSavePath.c_str(), ofstream::binary);
            outfile2.write ((char*)writingArray, indexCount);
            outfile2.close();
            
            delete [] writingArray;
        }
    }
    else if (timeOneStatus == 0 && trackingOn == 3 && firstModificationPoint != 10000){
        progressTiming = 9;
        
        int recordType = 1;
        trackRecord = [[TrackRecord alloc] init];
        int returnResults = [trackRecord trackDataSaveMain:recordType];
        
        if (returnResults == 1){
            setStatus7 = 77;
            
            dataSaveRead = [[DataSaveRead alloc] init];
            [dataSaveRead reviseLineClear];
            
            setStatus7 = 7;
            setStatus8 = 1;
            
            if (searchWindowOperation != 0){
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSearchOperations object:self];
            }
        }
        
        progressTiming = 11;
    }
    else if (timeOneStatus == 2){
        progressTiming = 9;
        
        string extensionNumber = to_string(timeOneHold);
        
        if (extensionNumber.length() == 1) extensionNumber = "000"+extensionNumber;
        else if (extensionNumber.length() == 2) extensionNumber = "00"+extensionNumber;
        else if (extensionNumber.length() == 3) extensionNumber = "0"+extensionNumber;
        
        string connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+analysisID+"_"+treatmentNameHold+"_LineageData";
        
        struct stat sizeOfFile;
        
        if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //	cout<<" arrayTimeSelected "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < timeSelectedHoldCount/10; counterA++){
            //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelectedHold [counterA*10+counterB];
            //	cout<<" arrayTimeSelectedHold "<<counterA<<endl;
            //}
            
            // for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
            //	cout<<" arrayLineageData "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
            //	cout<<" arrayGravityCenterRev "<<counterA<<endl;
            //}
            
            int maxLineageNoFind = 0;
            
            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                if (maxLineageNoFind < arrayLineageStartEnd [counter1*8]) maxLineageNoFind = arrayLineageStartEnd [counter1*8];
            }
            
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                if (maxLineageNoFind != 0){
                    if (arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7){
                        if (arrayTimeSelected [counter1*10+9] == 0){
                            maxLineageNoFind++;
                            arrayTimeSelected [counter1*10+9] = maxLineageNoFind; //-----Lineage no-----
                        }
                    }
                }
                else if (arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7){
                    if (arrayTimeSelected [counter1*10+9] == 0) arrayTimeSelected [counter1*10+9] = arrayTimeSelected [counter1*10+8]; //-----Lineage no-----
                }
                
                if (arrayTimeSelected [counter1*10] != 1 && arrayTimeSelected [counter1*10] != 7) arrayTimeSelected [counter1*10+9] = 0;
            }
            
            int entrySize = timeSelectedCount/10+5;
            lineageProcessList = new int [entrySize];
            
            for (int counter1 = 0; counter1 < entrySize; counter1++) lineageProcessList [counter1] = 0;
            
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                if (counter1 < timeSelectedHoldCount/10){
                    if (arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7){
                        if (arrayTimeSelected [counter1*10+9] != 0) lineageProcessList [counter1] = arrayTimeSelected [counter1*10+9]; //-----Lineage no-----
                    }
                    
                    if (arrayTimeSelected [counter1*10] != 1 && arrayTimeSelected [counter1*10] != 7){
                        if (arrayTimeSelectedHold [counter1*10] == 1 || arrayTimeSelectedHold [counter1*10] == 7) lineageProcessList [counter1] = arrayTimeSelectedHold [counter1*10+9]*-1;
                    }
                }
                
                if (counter1 >= timeSelectedHoldCount/10){
                    if (arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7) lineageProcessList [counter1] = arrayTimeSelected [counter1*10+9];
                }
            }
            
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //    cout<<" arrayTimeSelected "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < timeSelectedHoldCount/10; counterA++){
            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelectedHold [counterA*10+counterB];
            //    cout<<" arrayTimeSelectedHolde "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < entrySize; counterA++){
            //	cout<<" "<<lineageProcessList [counterA]<<" lineageProcessLists "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
            //    cout<<" arrayLineageData "<<counterA<<endl;
            //}
            
            int processType = 0;
            int lineageDelTemp = 0;
            int counterMax = 0;
            int dummy2 = 0;
            int deleteStatusCheck = 1;
            int deleteFail = 1;
            
            for (int counter1 = 0; counter1 < entrySize; counter1++){
                if (lineageProcessList [counter1] < 0){
                    processType = 5;
                    lineageDelTemp = 0;
                    counterMax = timeSelectedCount/10;
                    dummy2 = 0;
                    
                    addDelete = [[AddDelete alloc] init];
                    deleteStatusCheck = [addDelete delLineageMain:lineageDelTemp:processType:counterMax:dummy2]; //----Process All < files-----
                    
                    if (deleteStatusCheck == 0){
                        usleep (50000);
                        
                        addDelete = [[AddDelete alloc] init];
                        deleteStatusCheck = [addDelete delLineageMain:lineageDelTemp:processType:counterMax:dummy2]; //----Process All < files-----
                        
                        if (deleteStatusCheck == 0){
                            usleep (50000);
                            
                            addDelete = [[AddDelete alloc] init];
                            deleteStatusCheck = [addDelete delLineageMain:lineageDelTemp:processType:counterMax:dummy2]; //----Process All < files-----
                            
                            if (deleteStatusCheck == 0){
                                deleteFail = 0;
                                break;
                            }
                        }
                        else{
                            
                            break;
                        }
                    }
                    else{
                        
                        break;
                    }
                }
            }
            
            if (deleteFail == 1){
                for (int counter1 = 0; counter1 < entrySize; counter1++){
                    if (lineageProcessList [counter1] < 0) lineageProcessList [counter1] = 0;
                }
                
                int *insertLineageList = new int [entrySize];
                int insertLineageListCount = 0;
                
                for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                    for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                        if (arrayLineageData [counter2*8+3] == 13){
                            insertLineageList [insertLineageListCount] = arrayLineageData [counter2*8+6], insertLineageListCount++;
                            break;
                        }
                    }
                }
                
                int *arrayLineageDataTemp = new int [lineageDataCount+timeSelectedCount+50];
                int lineageDataTempCount = 0;
                
                for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                    for (int counter2 = 0; counter2 < insertLineageListCount; counter2++){
                        if (insertLineageList [counter2] == arrayLineageStartEnd [counter1*8]){
                            for (int counter3 = arrayLineageStartEnd [counter1*8+4]; counter3 <= arrayLineageStartEnd [counter1*8+6]; counter3++){
                                arrayLineageDataTemp [lineageDataTempCount] = arrayLineageData [counter3*8], lineageDataTempCount++;
                                arrayLineageDataTemp [lineageDataTempCount] = arrayLineageData [counter3*8+1], lineageDataTempCount++;
                                arrayLineageDataTemp [lineageDataTempCount] = arrayLineageData [counter3*8+2], lineageDataTempCount++;
                                arrayLineageDataTemp [lineageDataTempCount] = arrayLineageData [counter3*8+3], lineageDataTempCount++;
                                arrayLineageDataTemp [lineageDataTempCount] = arrayLineageData [counter3*8+4], lineageDataTempCount++;
                                arrayLineageDataTemp [lineageDataTempCount] = arrayLineageData [counter3*8+5], lineageDataTempCount++;
                                arrayLineageDataTemp [lineageDataTempCount] = arrayLineageData [counter3*8+6], lineageDataTempCount++;
                                arrayLineageDataTemp [lineageDataTempCount] = arrayLineageData [counter3*8+7], lineageDataTempCount++;
                            }
                            
                            break;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < lineageDataTempCount/8; counterA++){
                //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageDataTemp [counterA*8+counterB];
                //    cout<<" arrayLineageDataTemp "<<counterA<<endl;
                //}
                
                int lineageFindFlag = 0;
                
                for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                    if (lineageProcessList [counter1] > 0){
                        lineageFindFlag = 0;
                        
                        for (int counter2 = 0; counter2 < lineageStartEndCount/8; counter2++){
                            if (lineageProcessList [counter1] == arrayLineageStartEnd [counter2*8]) lineageFindFlag = 1;
                        }
                        
                        if (lineageFindFlag == 1){
                            for (int counter2 = 0; counter2 < lineageStartEndCount/8; counter2++){
                                if (lineageProcessList [counter1] == arrayLineageStartEnd [counter2*8]){
                                    for (int counter3 = arrayLineageStartEnd [counter2*8+4]; counter3 <= arrayLineageStartEnd [counter2*8+6]; counter3++){
                                        arrayLineageDataTemp [lineageDataTempCount] = arrayLineageData [counter3*8], lineageDataTempCount++;
                                        arrayLineageDataTemp [lineageDataTempCount] = arrayLineageData [counter3*8+1], lineageDataTempCount++;
                                        arrayLineageDataTemp [lineageDataTempCount] = arrayLineageData [counter3*8+2], lineageDataTempCount++;
                                        arrayLineageDataTemp [lineageDataTempCount] = arrayLineageData [counter3*8+3], lineageDataTempCount++;
                                        arrayLineageDataTemp [lineageDataTempCount] = arrayLineageData [counter3*8+4], lineageDataTempCount++;
                                        arrayLineageDataTemp [lineageDataTempCount] = arrayLineageData [counter3*8+5], lineageDataTempCount++;
                                        arrayLineageDataTemp [lineageDataTempCount] = arrayLineageData [counter3*8+6], lineageDataTempCount++;
                                        arrayLineageDataTemp [lineageDataTempCount] = arrayLineageData [counter3*8+7], lineageDataTempCount++;
                                    }
                                }
                            }
                        }
                        else{
                            
                            arrayLineageDataTemp [lineageDataTempCount] = arrayGravityCenterRev [counter1*6], lineageDataTempCount++;
                            arrayLineageDataTemp [lineageDataTempCount] = arrayGravityCenterRev [counter1*6+1], lineageDataTempCount++;
                            arrayLineageDataTemp [lineageDataTempCount] = timeOneHold, lineageDataTempCount++;
                            arrayLineageDataTemp [lineageDataTempCount] = 1, lineageDataTempCount++;
                            arrayLineageDataTemp [lineageDataTempCount] = 0, lineageDataTempCount++;
                            arrayLineageDataTemp [lineageDataTempCount] = 0, lineageDataTempCount++;
                            arrayLineageDataTemp [lineageDataTempCount] = lineageProcessList [counter1], lineageDataTempCount++;
                            arrayLineageDataTemp [lineageDataTempCount] = 0, lineageDataTempCount++;
                        }
                    }
                }
                
                if (lineageDataCount+lineageDataTempCount+10 > lineageDataLimit){
                    lineageDataAddition = lineageDataTempCount+10;
                    
                    int *arrayUpDate = new int [lineageDataCount+10];
                    
                    for (int counter1 = 0; counter1 < lineageDataCount; counter1++) arrayUpDate [counter1] = arrayLineageData [counter1];
                    
                    delete [] arrayLineageData;
                    arrayLineageData = new int [lineageDataLimit+lineageDataAddition+5000];
                    lineageDataLimit = lineageDataLimit+lineageDataAddition+5000;
                    
                    for (int counter1 = 0; counter1 < lineageDataCount; counter1++) arrayLineageData [counter1] = arrayUpDate [counter1];
                    delete [] arrayUpDate;
                }
                
                lineageDataCount = 0;
                
                for (int counter1 = 0; counter1 < lineageDataTempCount; counter1++) arrayLineageData [lineageDataCount] = arrayLineageDataTemp [counter1], lineageDataCount++;
                
                delete [] arrayLineageDataTemp;
                delete [] insertLineageList;
            }
            
            delete [] lineageProcessList;
            
            if (deleteFail == 0){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Data Deletion Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //	cout<<" arrayTimeSelected "<<counterA<<endl;
            //}
            
            //-----If no saved Data is found-----
            if (lineageDataStatus == 1) delete [] arrayLineageData;
            arrayLineageData = new int [timeSelectedCount/10*8+5000];
            lineageDataCount = 0;
            lineageDataLimit = timeSelectedCount/10*8+5000;
            lineageDataStatus = 1;
            
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                if (arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7){
                    arrayLineageData [lineageDataCount] = arrayGravityCenterRev [counter1*6], lineageDataCount++;
                    arrayLineageData [lineageDataCount] = arrayGravityCenterRev [counter1*6+1], lineageDataCount++;
                    arrayLineageData [lineageDataCount] = timeOneHold, lineageDataCount++;
                    arrayLineageData [lineageDataCount] = 1, lineageDataCount++;
                    arrayLineageData [lineageDataCount] = 0, lineageDataCount++;
                    arrayLineageData [lineageDataCount] = 0, lineageDataCount++;
                    arrayLineageData [lineageDataCount] = counter1+1, lineageDataCount++;
                    arrayLineageData [lineageDataCount] = 0, lineageDataCount++;
                }
            }
            
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                if (arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7){
                    arrayTimeSelected [counter1*10+9] = arrayTimeSelected [counter1*10+8];
                }
                else if (arrayTimeSelected [counter1*10] != 1 && arrayTimeSelected [counter1*10] != 7) arrayTimeSelected [counter1*10+9] = 0;
            }
        }
        
        //-----Save New Lineage Data-----
        //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
        //	cout<<" arrayLineageData "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
        //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
        //	cout<<" arrayTimeSelected "<<counterA<<endl;
        //}
        
        if (lineageDataCount != 0){
            lineageWritingCheck = 1;
            
            char *writingArray = new char [lineageDataCount/8*25+25];
            
            unsigned long indexCount = 0;
            int readBit [4];
            int dataTemp = 0;
            
            for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                if (arrayLineageData [counter1*8] < 0){
                    writingArray [indexCount] = 1, indexCount++;
                    dataTemp = arrayLineageData [counter1*8]*-1;
                }
                else{
                    
                    writingArray [indexCount] = 0, indexCount++;
                    dataTemp = arrayLineageData [counter1*8];
                }
                
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                if (arrayLineageData [counter1*8+1] < 0){
                    writingArray [indexCount] = 1, indexCount++;
                    dataTemp = arrayLineageData [counter1*8+1]*-1;
                }
                else{
                    
                    writingArray [indexCount] = 0, indexCount++;
                    dataTemp = arrayLineageData [counter1*8+1];
                }
                
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                dataTemp = arrayLineageData [counter1*8+2];
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                writingArray [indexCount] = (char)arrayLineageData [counter1*8+3], indexCount++;
                
                if (arrayLineageData [counter1*8+4] < 0){
                    writingArray [indexCount] = 1, indexCount++;
                    dataTemp = arrayLineageData [counter1*8+4]*-1;
                }
                else{
                    
                    writingArray [indexCount] = 0, indexCount++;
                    dataTemp = arrayLineageData [counter1*8+4];
                }
                
                readBit [0] = dataTemp/16777216;
                dataTemp = dataTemp%16777216;
                readBit [1] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [2] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [3] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                writingArray [indexCount] = (char)readBit [3], indexCount++;
                
                if (arrayLineageData [counter1*8+5] < 0){
                    writingArray [indexCount] = 1, indexCount++;
                    dataTemp = arrayLineageData [counter1*8+5]*-1;
                }
                else{
                    
                    writingArray [indexCount] = 0, indexCount++;
                    dataTemp = arrayLineageData [counter1*8+5];
                }
                
                readBit [0] = dataTemp/16777216;
                dataTemp = dataTemp%16777216;
                readBit [1] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [2] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [3] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                writingArray [indexCount] = (char)readBit [3], indexCount++;
                
                dataTemp = arrayLineageData [counter1*8+6];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                
                dataTemp = arrayLineageData [counter1*8+7];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
            }
            
            for (int counter1 = 0; counter1 < 25; counter1++) writingArray [indexCount] = 0, indexCount++;
            
            ofstream outfile (connectDataPath.c_str(), ofstream::binary);
            outfile.write ((char*) writingArray, indexCount);
            outfile.close();
            
            delete [] writingArray;
            
            ifstream fin;
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                fin.open(connectDataPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    fin.close();
                    lineageWritingCheck = 0;
                    terminationFlag = 0;
                }
                
            } while (terminationFlag == 1);
        }
        
        //-----Lineage Start/End List-----
        //==========1. lineage no, 2. cell no, 3. X position, 4. Y position, 5. start, 6. image start, 7. end, 8. image end==========
        if (lineageStartEndStatus == 0){
            arrayLineageStartEnd = new int [5000];
            lineageStartEndCount = 0;
            lineageStartEndLimit = 5000;
            lineageStartEndStatus = 1;
        }
        
        string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStartEnd";
        
        lineageStartEndCount = 0;
        
        int cellNumberStart = -1;
        int lineageNumberStart = 0;
        int firstEntryFind = 0;
        
        for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
            if ((arrayLineageData [counter1*8+6] != lineageNumberStart || arrayLineageData [counter1*8+5] != cellNumberStart) && firstEntryFind == 0){
                lineageNumberStart = arrayLineageData [counter1*8+6];
                cellNumberStart = arrayLineageData [counter1*8+5];
                
                arrayLineageStartEnd [lineageStartEndCount] = lineageNumberStart, lineageStartEndCount++;
                arrayLineageStartEnd [lineageStartEndCount] = cellNumberStart, lineageStartEndCount++;
                arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8], lineageStartEndCount++;
                arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+1], lineageStartEndCount++;
                arrayLineageStartEnd [lineageStartEndCount] = counter1, lineageStartEndCount++;
                arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+2], lineageStartEndCount++;
                
                firstEntryFind = 1;
            }
            else if ((arrayLineageData [counter1*8+6] != lineageNumberStart || arrayLineageData [counter1*8+5] != cellNumberStart) && firstEntryFind == 1){
                lineageNumberStart = arrayLineageData [counter1*8+6];
                cellNumberStart = arrayLineageData [counter1*8+5];
                
                arrayLineageStartEnd [lineageStartEndCount] = counter1-1, lineageStartEndCount++;
                arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [(counter1-1)*8+2], lineageStartEndCount++;
                arrayLineageStartEnd [lineageStartEndCount] = lineageNumberStart, lineageStartEndCount++;
                arrayLineageStartEnd [lineageStartEndCount] = cellNumberStart, lineageStartEndCount++;
                arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8], lineageStartEndCount++;
                arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+1], lineageStartEndCount++;
                arrayLineageStartEnd [lineageStartEndCount] = counter1, lineageStartEndCount++;
                arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+2], lineageStartEndCount++;
            }
            
            if (counter1 == lineageDataCount/8-1){
                arrayLineageStartEnd [lineageStartEndCount] = counter1, lineageStartEndCount++;
                arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+2], lineageStartEndCount++;
            }
            
            if (lineageStartEndCount+24 > lineageStartEndLimit){
                fileUpdate = [[FileUpdate alloc] init];
                [fileUpdate lineageStartEndUpDate];
            }
        }
        
        //for (int counterA = 0; counterA < lineageStartEndCount/8; counterA++){
        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageStartEnd [counterA*8 +counterB];
        //	cout<<" arrayLineageStartEnd "<<counterA<<endl;
        //}
        
        string extension;
        
        if (lineageStartEndCount != 0){
            char *mainDataEntry = new char [lineageStartEndCount*7+10];
            int totalEntryCount = 0;
            
            for (int counter1 = 0; counter1 < lineageStartEndCount; counter1++){
                extension = to_string(arrayLineageStartEnd [counter1]);
                
                for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
            }
            
            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
            
            ofstream outfile5 (connectStartEndPath.c_str(), ofstream::binary);
            outfile5.write (mainDataEntry, totalEntryCount);
            outfile5.close();
            
            delete [] mainDataEntry;
        }
        
        //-----Save Master Data Revise-----
        masterDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extensionNumber+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
        
        //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
        //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
        //	cout<<" arrayTimeSelected "<<counterA<<endl;
        //}
        
        for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
            if (arrayPositionRevise [counter1*7+5] == 1 && arrayTimeSelected [(arrayPositionRevise [counter1*7+3]-1)*10+9] != 0 && arrayPositionRevise [counter1*7+6] != arrayTimeSelected [(arrayPositionRevise [counter1*7+3]-1)*10+9]){
                arrayPositionRevise [counter1*7+6] = arrayTimeSelected [(arrayPositionRevise [counter1*7+3]-1)*10+9];
            }
            else if (arrayPositionRevise [counter1*7+5] == 1 && (arrayTimeSelected [(arrayPositionRevise [counter1*7+3]-1)*10] == 0 || arrayTimeSelected [(arrayPositionRevise [counter1*7+3]-1)*10] == 5 || arrayTimeSelected [(arrayPositionRevise [counter1*7+3]-1)*10] == 6)){
                arrayPositionRevise [counter1*7+5] = 0;
                arrayPositionRevise [counter1*7+6] = 0;
            }
            else if (arrayPositionRevise [counter1*7+5] != 1) arrayPositionRevise [counter1*7+6] = 0;
        }
        
        //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
        //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
        //	cout<<" arrayTimeSelected "<<counterA<<endl;
        //}
        
        int dataTemp = 0;
        unsigned long indexCount = 0;
        int readBit [4];
        
        char *writingArray = new char [(positionReviseCount/7+associateDataCount/6+gravityCenterRevCount/6)*17+50];
        
        for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
            dataTemp = arrayPositionRevise [counter1*7];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            dataTemp = arrayPositionRevise [counter1*7+1];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            writingArray [indexCount] = (char)arrayPositionRevise [counter1*7+2], indexCount++;
            
            dataTemp = arrayPositionRevise [counter1*7+3];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayPositionRevise [counter1*7+4];
            
            if (dataTemp < 0) dataTemp = dataTemp*-1, writingArray [indexCount] = 1, indexCount++;
            else writingArray [indexCount] = 0, indexCount++;
            
            readBit [0] = dataTemp/16777216;
            dataTemp = dataTemp%16777216;
            readBit [1] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [2] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [3] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            writingArray [indexCount] = (char)readBit [3], indexCount++;
            
            writingArray [indexCount] = (char)arrayPositionRevise [counter1*7+5], indexCount++;
            
            dataTemp = arrayPositionRevise [counter1*7+6];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
        }
        
        for (int counter1 = 0; counter1 < 17; counter1++) writingArray [indexCount] = 0, indexCount++;
        
        for (int counter1 = 0; counter1 < associateDataCount/6; counter1++){
            dataTemp = arrayAssociateData [counter1*6];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)arrayAssociateData [counter1*6+1], indexCount++;
            
            writingArray [indexCount] = (char)arrayAssociateData [counter1*6+2], indexCount++;
            
            dataTemp = arrayAssociateData [counter1*6+3];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayAssociateData [counter1*6+4];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            writingArray [indexCount] = (char)arrayAssociateData [counter1*6+5], indexCount++;
        }
        
        for (int counter1 = 0; counter1 < 11; counter1++) writingArray [indexCount] = 0, indexCount++;
        
        for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
            dataTemp = arrayGravityCenterRev [counter1*6];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            dataTemp = arrayGravityCenterRev [counter1*6+1];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            dataTemp = arrayGravityCenterRev [counter1*6+2];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)arrayGravityCenterRev [counter1*6+3], indexCount++;
            
            dataTemp = arrayGravityCenterRev [counter1*6+4];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)arrayGravityCenterRev [counter1*6+5], indexCount++;
        }
        
        for (int counter1 = 0; counter1 < 11; counter1++) writingArray [indexCount] = 0, indexCount++;
        
        ofstream outfile3 (masterDataRevPath.c_str(), ofstream::binary);
        outfile3.write ((char*)writingArray, indexCount);
        outfile3.close();
        
        delete [] writingArray;
        
        //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
        //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
        //	cout<<" arrayPositionRevise "<<counterA<<endl;
        //}
        
        //-----Save Cut Line Data and Status-----
        targetHoldCount = 0;
        targetHoldInfoCount = 0;
        
        //-----Save Lineage Line data status-----
        string connectStatusDatePath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extensionNumber+"_"+analysisID+"_"+treatmentNameHold+"_Status";
        
        writingArray = new char [timeSelectedCount/10*19+20];
        
        indexCount = 0;
        
        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
            if (arrayTimeSelected [counter1*10] == 0 || arrayTimeSelected [counter1*10] == 5 || arrayTimeSelected [counter1*10] == 6){
                writingArray [indexCount] = 0, indexCount++;
            }
            else writingArray [indexCount] = (char)arrayTimeSelected [counter1*10], indexCount++;
            
            writingArray [indexCount] = 0, indexCount++;
            writingArray [indexCount] = 0, indexCount++;
            writingArray [indexCount] = 0, indexCount++;
            
            dataTemp = arrayTimeSelected [counter1*10+2];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = 0, indexCount++;
            writingArray [indexCount] = 0, indexCount++;
            
            writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+4], indexCount++;
            writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+5], indexCount++;
            writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+6], indexCount++;
            writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+7], indexCount++;
            
            dataTemp = arrayTimeSelected [counter1*10+8];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayTimeSelected [counter1*10+9];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
        }
        
        for (int counter1 = 0; counter1 < 19; counter1++) writingArray [indexCount] = 0, indexCount++;
        
        ofstream outfile2 (connectStatusDatePath.c_str(), ofstream::binary);
        outfile2.write ((char*) writingArray, indexCount);
        outfile2.close();
        
        delete [] writingArray;
        
        delete [] arrayTimeSelectedHold;
        arrayTimeSelectedHold = new int [timeSelectedCount+500];
        
        timeSelectedHoldCount = 0;
        for (int counter1 = 0; counter1 < timeSelectedCount; counter1++) arrayTimeSelectedHold [counter1] = arrayTimeSelected [counter1], timeSelectedHoldCount++;
        
        for (int counter1 = 0; counter1 < timeSelectedHoldCount/10; counter1++){
            arrayTimeSelectedHold [counter1*10+1] = 0;
            arrayTimeSelectedHold [counter1*10+3] = 0;
        }
        
        //for (int counterA = 0; counterA < timeSelectedHoldCount/10; counterA++){
        //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelectedHold [counterA*10+counterB];
        //	cout<<" arrayTimeSelectedHold "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
        //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
        //	cout<<" arrayTimeSelected "<<counterA<<endl;
        //}
        
        //-----Connect lineage relation table save-----
        //=========1. Lineage No, 2. connect No, 3. image number, 4. cell no, 5. target (0: non-target, 1: target), 6. reserve=========
        string connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extensionNumber+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
        
        writingArray = new char [timeSelectedCount/10*16+16];
        
        indexCount = 0;
        
        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
            if (arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7){
                dataTemp = arrayPositionRevise [arrayTimeSelected [counter1*10+2]*7+6];
                
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                
                dataTemp = counter1+1;
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                
                dataTemp = 1;
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                if (arrayPositionRevise [arrayTimeSelected [counter1*10+2]*7+4] < 0){
                    writingArray [indexCount] = 1, indexCount++;
                    dataTemp = arrayPositionRevise [arrayTimeSelected [counter1*10+2]*7+4]*-1;
                }
                else{
                    
                    writingArray [indexCount] = 0, indexCount++;
                    dataTemp = arrayPositionRevise [arrayTimeSelected [counter1*10+2]*7+4];
                }
                
                readBit [0] = dataTemp/16777216;
                dataTemp = dataTemp%16777216;
                readBit [1] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [2] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [3] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                writingArray [indexCount] = (char)readBit [3], indexCount++;
                
                writingArray [indexCount] = 0, indexCount++;
                writingArray [indexCount] = 0, indexCount++;
            }
        }
        
        for (int counter1 = 0; counter1 < 15; counter1++) writingArray [indexCount] = 0, indexCount++;
        
        ofstream outfile5 (connectRelationPath.c_str(), ofstream::binary);
        outfile5.write ((char*) writingArray, indexCount);
        outfile5.close();
        
        delete [] writingArray;
        
        //-----Save Revised Map-----
        string revisedMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extensionNumber+"_"+analysisID+"_"+treatmentNameHold+"_RevisedMap";
        
        for (int counter1 = 0; counter1 < imageDimension; counter1++){
            for (int counter2 = 0; counter2 < imageDimension; counter2++) revisedMap [counter1][counter2] = revisedWorkingMap [counter1][counter2];
        }
        
        char *dataHold = new char [imageDimension*imageDimension*4];
        
        indexCount = 0;
        int dataTemp2 = 0;
        int entryCount = 0;
        
        for (int counter1 = 0; counter1 < imageDimension; counter1++){
            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                dataTemp = revisedWorkingMap [counter1][counter2];
                
                if (counter2 == 0) dataTemp2 = dataTemp, entryCount++;
                else if (dataTemp != dataTemp2 || entryCount == 254 || counter2 == imageDimension-1){
                    readBit [0] = dataTemp2/65536;
                    dataTemp2 = dataTemp2%65536;
                    readBit [1] = dataTemp2/256;
                    dataTemp2 = dataTemp2%256;
                    readBit [2] = dataTemp2;
                    
                    if (counter2 == imageDimension-1){
                        if (dataTemp != dataTemp2){
                            dataHold [indexCount] = (char)readBit [0], indexCount++;
                            dataHold [indexCount] = (char)readBit [1], indexCount++;
                            dataHold [indexCount] = (char)readBit [2], indexCount++;
                            dataHold [indexCount] = (char)entryCount, indexCount++;
                            
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            entryCount = 1;
                            
                            dataHold [indexCount] = (char)readBit [0], indexCount++;
                            dataHold [indexCount] = (char)readBit [1], indexCount++;
                            dataHold [indexCount] = (char)readBit [2], indexCount++;
                            dataHold [indexCount] = (char)entryCount, indexCount++;
                        }
                        else{
                            
                            entryCount++;
                            
                            dataHold [indexCount] = (char)readBit [0], indexCount++;
                            dataHold [indexCount] = (char)readBit [1], indexCount++;
                            dataHold [indexCount] = (char)readBit [2], indexCount++;
                            dataHold [indexCount] = (char)entryCount, indexCount++;
                        }
                    }
                    else{
                        
                        dataHold [indexCount] = (char)readBit [0], indexCount++;
                        dataHold [indexCount] = (char)readBit [1], indexCount++;
                        dataHold [indexCount] = (char)readBit [2], indexCount++;
                        dataHold [indexCount] = (char)entryCount, indexCount++;
                    }
                    
                    if (counter2 == imageDimension-1) entryCount = 0;
                    else{
                        
                        entryCount = 1;
                        dataTemp2 = dataTemp;
                    }
                }
                else entryCount++;
            }
        }
        
        ofstream outfile6 (revisedMapPath.c_str(), ofstream::binary);
        outfile6.write(dataHold, indexCount);
        outfile6.close();
        
        delete [] dataHold;
        
        //-----Create or remove Lineage Folders-----
        string lineageFolderPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat";
        
        int largestLingNoFolder = 0;
        
        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
            if (largestLingNoFolder < arrayTimeSelected [counter1*10+9]) largestLingNoFolder = arrayTimeSelected [counter1*10+9];
        }
        
        if (largestLingNoFolder < timeSelectedCount/10) largestLingNoFolder = timeSelectedCount/10;
        
        int *newLineageList = new int [largestLingNoFolder+10];
        
        for (int counter1 = 1; counter1 < largestLingNoFolder+10; counter1++) newLineageList [counter1] = 0;
        
        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
            if (arrayTimeSelected [counter1*10+9] != 0) newLineageList [arrayTimeSelected [counter1*10+9]] = 1;
        }
        
        for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
            if (arrayLineageData [counter1*8+3] == 13) newLineageList [arrayLineageData [counter1*8+6]] = 1;
        }
        
        string lineageFolderPath2;
        string lineageFolderPath3;
        string lineageFolderPath4;
        string entry;
        string entry2;
        
        int folderExist = 0;
        
        for (int counter1 = 1; counter1 < largestLingNoFolder+1; counter1++){
            extension = to_string(counter1);
            
            if (extension.length() == 1) extensionNumber = "0000"+extension;
            else if (extension.length() == 2) extensionNumber = "000"+extension;
            else if (extension.length() == 3) extensionNumber = "00"+extension;
            else if (extension.length() == 4) extensionNumber = "0"+extension;
            else if (extension.length() == 5) extensionNumber = extension;
            
            lineageFolderPath2 = lineageFolderPath+"/L"+extensionNumber;
            
            if (newLineageList [counter1] == 1){
                folderExist = 0;
                
                DIR *dir;
                
                dir = opendir(lineageFolderPath2.c_str());
                
                if (dir != NULL){
                    folderExist = 1;
                    closedir(dir);
                }
                
                if (folderExist == 0){
                    mkdir(lineageFolderPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                }
            }
        }
        
        delete [] newLineageList;
        
        //=========Cell Status list Creation=========
        [self cellListCreation];
        
        string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
        
        for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
            if (arrayQueueList [counter1*6] == treatmentNameHold) arrayQueueList [counter1*6] = "R";
        }
        
        //for (int counterA = 0; counterA < queueListCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
        //	cout<<" arrayQueueList "<<counterA<<endl;
        //}
        
        if (lineageStartEndCount != 0){
            string extension2;
            string extension3;
            
            int endFind = 0;
            int markFind = 0;
            int cellNoTemp = 0;
            int lineageNoTemp = 0;
            int imageNoTemp = 0;
            
            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                endFind = 0;
                markFind = 0;
                cellNoTemp = arrayLineageStartEnd [counter1*8+1];
                lineageNoTemp = arrayLineageStartEnd [counter1*8];
                imageNoTemp = 0;
                
                for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                    if (arrayLineageData [counter2*8+3] == 32 || arrayLineageData [counter2*8+3] == 42 || arrayLineageData [counter2*8+3] == 52 || arrayLineageData [counter2*8+3] == 7 || arrayLineageData [counter2*8+3] == 8 || arrayLineageData [counter2*8+3] == 91 || arrayLineageData [counter2*8+3] == 13){
                        endFind = 1;
                    }
                    
                    if (imageNoTemp < arrayLineageData [counter2*8+2]) imageNoTemp = arrayLineageData [counter2*8+2];
                    if (arrayLineageData [counter2*8+3] == 10) markFind = 1;
                }
                
                if (endFind == 0){
                    extension = to_string(lineageNoTemp);
                    
                    if (extension.length() == 1) extension = "L0000"+extension;
                    else if (extension.length() == 2) extension = "L000"+extension;
                    else if (extension.length() == 3) extension = "L00"+extension;
                    else if (extension.length() == 4) extension = "L0"+extension;
                    else if (extension.length() == 5) extension = "L"+extension;
                    
                    extension2 = to_string(cellNoTemp);
                    
                    if (cellNoTemp >= 0){
                        if (extension2.length() == 1) extension2 = "C00000000"+extension2;
                        else if (extension2.length() == 2) extension2 = "C0000000"+extension2;
                        else if (extension2.length() == 3) extension2 = "C000000"+extension2;
                        else if (extension2.length() == 4) extension2 = "C00000"+extension2;
                        else if (extension2.length() == 5) extension2 = "C0000"+extension2;
                        else if (extension2.length() == 6) extension2 = "C000"+extension2;
                        else if (extension2.length() == 7) extension2 = "C00"+extension2;
                        else if (extension2.length() == 8) extension2 = "C0"+extension2;
                        else if (extension2.length() == 9) extension2 = "C"+extension2;
                    }
                    if (cellNoTemp < 0){
                        extension2 = extension2.substr(1);
                        if (extension2.length() == 1) extension2 = "C-00000000"+extension2;
                        else if (extension2.length() == 2) extension2 = "C-0000000"+extension2;
                        else if (extension2.length() == 3) extension2 = "C-000000"+extension2;
                        else if (extension2.length() == 4) extension2 = "C-00000"+extension2;
                        else if (extension2.length() == 5) extension2 = "C-0000"+extension2;
                        else if (extension2.length() == 6) extension2 = "C-000"+extension2;
                        else if (extension2.length() == 7) extension2 = "C-00"+extension2;
                        else if (extension2.length() == 8) extension2 = "C-0"+extension2;
                        else if (extension2.length() == 9) extension2 = "C-"+extension2;
                    }
                    
                    extension3 = to_string(imageNoTemp);
                    
                    if (queueListCount+12 > queueListLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate queueListUpDate];
                    }
                    
                    arrayQueueList [queueListCount] = treatmentNameHold, queueListCount++;
                    arrayQueueList [queueListCount] = extension, queueListCount++;
                    arrayQueueList [queueListCount] = extension2, queueListCount++;
                    arrayQueueList [queueListCount] = extension3+":"+extension3, queueListCount++;
                    
                    if (markFind == 0) arrayQueueList [queueListCount] = "0", queueListCount++;
                    else arrayQueueList [queueListCount] = "/m", queueListCount++;
                    
                    arrayQueueList [queueListCount] = "Wait", queueListCount++;
                }
            }
        }
        else{
            
            string extension3 = to_string(timeOneHold);
            
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                if (arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7){
                    extension = to_string(arrayTimeSelected [counter1*10+9]);
                    
                    if (extension.length() == 1) extension = "L0000"+extension;
                    else if (extension.length() == 2) extension = "L000"+extension;
                    else if (extension.length() == 3) extension = "L00"+extension;
                    else if (extension.length() == 4) extension = "L0"+extension;
                    else if (extension.length() == 5) extension = "L"+extension;
                    
                    if (queueListCount+12 > queueListLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate queueListUpDate];
                    }
                    
                    arrayQueueList [queueListCount] = treatmentNameHold, queueListCount++;
                    arrayQueueList [queueListCount] = extension, queueListCount++;
                    arrayQueueList [queueListCount] = "C000000000", queueListCount++;
                    arrayQueueList [queueListCount] = extension3+":"+extension3, queueListCount++;
                    arrayQueueList [queueListCount] = "0", queueListCount++;
                    arrayQueueList [queueListCount] = "Wait", queueListCount++;
                }
            }
        }
        
        string *arrayQueueListTemp = new string [queueListCount+50];
        int queueListTempCount = 0;
        string *arrayQueueListTemp2 = new string [queueListCount+50];
        int queueListTempCount2 = 0;
        string *arrayQueueListTemp3 = new string [queueListCount+50];
        int queueListTempCount3 = 0;
        string *arrayQueueListTemp4 = new string [queueListCount+50];
        int queueListTempCount4 = 0;
        int *arrayAreaSize = new int [queueListCount+50];
        
        int areaSizeCount = 0;
        
        string timeOneString = to_string(timeOneHold);
        string imageNoCommTemp;
        
        for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
            imageNoCommTemp = arrayQueueList [counter1*6+3];
            if ((int)imageNoCommTemp.find(":") != -1) imageNoCommTemp = imageNoCommTemp.substr(0, imageNoCommTemp.find(":"));
            
            if (arrayQueueList [counter1*6] != treatmentNameHold || arrayQueueList [counter1*6+2] != "C000000000" || imageNoCommTemp != timeOneString){
                arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6], queueListTempCount++;
                arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6+1], queueListTempCount++;
                arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6+2], queueListTempCount++;
                arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6+3], queueListTempCount++;
                arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6+4], queueListTempCount++;
                arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6+5], queueListTempCount++;
            }
            else{
                
                arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter1*6], queueListTempCount2++;
                arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter1*6+1], queueListTempCount2++;
                arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter1*6+2], queueListTempCount2++;
                arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter1*6+3], queueListTempCount2++;
                arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter1*6+4], queueListTempCount2++;
                arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter1*6+5], queueListTempCount2++;
            }
        }
        
        //for (int counterA = 0; counterA < queueListTempCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueListTemp [counterA*6+counterB];
        //	cout<<" arrayQueueListTemp "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < queueListTempCount2/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueListTemp2 [counterA*6+counterB];
        //	cout<<" arrayQueueListTemp2 "<<counterA<<endl;
        //}
        
        string lineageNoTemp;
        string cellNoTemp;
        
        int lineageRevInt = 0;
        int cellNoRevInt = 0;
        int cellStatusTemp = 0;
        int connectNoTemp = 0;
        int findInList = 0;
        int listPosition = 0;
        
        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
            if (arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7){
                lineageRevInt = arrayPositionRevise [arrayTimeSelected [counter1*10+2]*7+6];
                cellNoRevInt = arrayPositionRevise [arrayTimeSelected [counter1*10+2]*7+4];
                cellStatusTemp = arrayTimeSelected [counter1*10];
                connectNoTemp = arrayPositionRevise [arrayTimeSelected [counter1*10+2]*7+3];
                findInList = 0;
                listPosition = 0;
                
                for (int counter2 = 0; counter2 < queueListTempCount2/6; counter2++){
                    lineageNoTemp = arrayQueueListTemp2 [counter2*6+1];
                    lineageNoTemp = lineageNoTemp.substr(1);
                    cellNoTemp = arrayQueueListTemp2 [counter2*6+2];
                    cellNoTemp = cellNoTemp.substr(1);
                    
                    if (lineageRevInt == atoi(lineageNoTemp.c_str()) && cellNoRevInt == atoi(cellNoTemp.c_str())){
                        findInList = 1;
                        listPosition = counter2;
                        break;
                    }
                }
                
                if (findInList == 1){
                    if (cellStatusTemp == 7){
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp2 [listPosition*6], queueListTempCount3++;
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp2 [listPosition*6+1], queueListTempCount3++;
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp2 [listPosition*6+2], queueListTempCount3++;
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp2 [listPosition*6+3], queueListTempCount3++;
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp2 [listPosition*6+4], queueListTempCount3++;
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp2 [listPosition*6+5], queueListTempCount3++;
                    }
                    else{
                        
                        arrayQueueListTemp4 [queueListTempCount4] = arrayQueueListTemp2 [listPosition*6], queueListTempCount4++;
                        arrayQueueListTemp4 [queueListTempCount4] = arrayQueueListTemp2 [listPosition*6+1], queueListTempCount4++;
                        arrayQueueListTemp4 [queueListTempCount4] = arrayQueueListTemp2 [listPosition*6+2], queueListTempCount4++;
                        arrayQueueListTemp4 [queueListTempCount4] = arrayQueueListTemp2 [listPosition*6+3], queueListTempCount4++;
                        arrayQueueListTemp4 [queueListTempCount4] = arrayQueueListTemp2 [listPosition*6+4], queueListTempCount4++;
                        arrayQueueListTemp4 [queueListTempCount4] = arrayQueueListTemp2 [listPosition*6+5], queueListTempCount4++;
                        
                        arrayAreaSize [areaSizeCount] = arrayGravityCenterRev [(connectNoTemp-1)*6+2], areaSizeCount++;
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < queueListTempCount3/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueListTemp3 [counterA*6+counterB];
        //	cout<<" arrayQueueListTemp3 "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < queueListTempCount4/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueListTemp4 [counterA*6+counterB];
        //	cout<<" arrayQueueListTemp4 "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
        //	cout<<" arrayGravityCenterRev "<<counterA<<endl;
        //}
        
        int terminationFlag = 0;
        int largestArea = 0;
        int largestConnectNo = 0;
        
        do{
            
            largestArea = 0;
            largestConnectNo = 0;
            
            for (int counter1 = 0; counter1 < areaSizeCount; counter1++){
                if (arrayAreaSize [counter1] > largestArea){
                    largestArea = arrayAreaSize [counter1];
                    largestConnectNo = counter1;
                }
            }
            
            if (largestArea == 0) terminationFlag = 1;
            else{
                
                arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp4 [largestConnectNo*6], queueListTempCount3++;
                arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp4 [largestConnectNo*6+1], queueListTempCount3++;
                arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp4 [largestConnectNo*6+2], queueListTempCount3++;
                arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp4 [largestConnectNo*6+3], queueListTempCount3++;
                arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp4 [largestConnectNo*6+4], queueListTempCount3++;
                arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp4 [largestConnectNo*6+5], queueListTempCount3++;
                
                arrayAreaSize [largestConnectNo] = 0;
            }
            
        } while (terminationFlag == 0);
        
        queueListCount = 0;
        
        for (int counter1 = 0; counter1 < queueListTempCount3; counter1++) arrayQueueList [queueListCount] = arrayQueueListTemp3 [counter1], queueListCount++;
        for (int counter1 = 0; counter1 < queueListTempCount; counter1++) arrayQueueList [queueListCount] = arrayQueueListTemp [counter1], queueListCount++;
        
        delete [] arrayQueueListTemp;
        delete [] arrayQueueListTemp2;
        delete [] arrayQueueListTemp3;
        delete [] arrayQueueListTemp4;
        delete [] arrayAreaSize;
        
        //for (int counterA = 0; counterA < queueListCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
        //	cout<<" arrayQueueList "<<counterA<<endl;
        //}
        
        if (queueListCount != 0){
            string *arrayUpDate = new string [queueListCount+10];
            int upDateCount = 0;
            
            for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                if (arrayQueueList [counter1*6] != "R"){
                    arrayUpDate [upDateCount] = arrayQueueList [counter1*6], upDateCount++;
                    arrayUpDate [upDateCount] = arrayQueueList [counter1*6+1], upDateCount++;
                    arrayUpDate [upDateCount] = arrayQueueList [counter1*6+2], upDateCount++;
                    arrayUpDate [upDateCount] = arrayQueueList [counter1*6+3], upDateCount++;
                    arrayUpDate [upDateCount] = arrayQueueList [counter1*6+4], upDateCount++;
                    arrayUpDate [upDateCount] = arrayQueueList [counter1*6+5], upDateCount++;
                }
            }
            
            queueListCount = 0;
            for (int counter1 = 0; counter1 < upDateCount; counter1++) arrayQueueList [queueListCount] = arrayUpDate [counter1], queueListCount++;
            delete [] arrayUpDate;
        }
        
        //for (int counterA = 0; counterA < queueListCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
        //	cout<<" arrayQueueList "<<counterA<<endl;
        //}
        
        if (queueListCount != 0){
            char *mainDataEntry = new char [queueListCount*12+10];
            int totalEntryCount = 0;
            
            for (int counter1 = 0; counter1 < queueListCount; counter1++){
                extension = arrayQueueList [counter1];
                
                for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
            }
            
            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
            
            ofstream outfile10 (queueListPath.c_str(), ofstream::binary);
            outfile10.write (mainDataEntry, totalEntryCount);
            outfile10.close();
            
            delete [] mainDataEntry;
        }
        
        //=========Done List UpDate==========
        string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
        int correctionFind = 0;
        
        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
            if (arrayTimeSelected [counter1*10] != 1 && arrayTimeSelected [counter1*10] != 7){
                extension = to_string(counter1+1);
                
                if (extension.length() == 1) extension = "L0000"+extension;
                else if (extension.length() == 2) extension = "L000"+extension;
                else if (extension.length() == 3) extension = "L00"+extension;
                else if (extension.length() == 4) extension = "L0"+extension;
                else if (extension.length() == 5) extension = "L"+extension;
                
                for (int counter2 = 0; counter2 < doneListCount/5; counter2++){
                    if (arrayTimeSelected [counter1*10] != 1 && arrayDoneList [counter2*5] == treatmentNameHold && arrayDoneList [counter2*5+1] == extension){
                        arrayDoneList [counter2*5] = "";
                        correctionFind = 1;
                    }
                }
            }
        }
        
        if (correctionFind == 1){
            string *arrayUpDate = new string [doneListCount+10];
            int upDateCount = 0;
            
            for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                if (arrayDoneList [counter1*5] != ""){
                    arrayUpDate [upDateCount] = arrayDoneList [counter1*5], upDateCount++;
                    arrayUpDate [upDateCount] = arrayDoneList [counter1*5+1], upDateCount++;
                    arrayUpDate [upDateCount] = arrayDoneList [counter1*5+2], upDateCount++;
                    arrayUpDate [upDateCount] = arrayDoneList [counter1*5+3], upDateCount++;
                    arrayUpDate [upDateCount] = arrayDoneList [counter1*5+4], upDateCount++;
                }
            }
            
            doneListCount = 0;
            for (int counter1 = 0; counter1 < upDateCount; counter1++) arrayDoneList [counter1] = arrayUpDate [counter1], doneListCount++;
            delete [] arrayUpDate;
            
            if (doneListCount != 0){
                char *mainDataEntry = new char [doneListCount*10];
                int totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < doneListCount; counter1++){
                    extension = arrayDoneList [counter1];
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile7 (doneListPath.c_str(), ofstream::binary);
                outfile7.write (mainDataEntry, totalEntryCount);
                outfile7.close();
                
                delete [] mainDataEntry;
            }
        }
        
        //-----Cell Lineage status List Creation-----
        [self lineageListCreation];
        
        //for (int counterA = 0; counterA < treatmentStatusCount/4; counterA++){
        //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayTreatmentStatus [counterA*4+counterB];
        //	cout<<" arrayTreatmentStatus "<<counterA<<endl;
        //}
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            if (treatmentNameHold == arrayTreatmentStatus [counter1*9]){
                arrayTreatmentStatus [counter1*9+1] = "1";
                arrayTreatmentStatus [counter1*9+2] = "1";
            }
        }
        
        tableDataSetDone = 1;
        trackingTableSetDone = 0;
        tableTrackingProcessing = 0;
        
        int lineSetError = 0;
        
        lineSet = [[LineSet alloc] init];
        lineSetError = [lineSet dataRead:imageNumber];
        
        if (lineSetError == 0){
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            progressTiming = 11;
            
            do{
                
                if (masterLineForTrackingStatus == 1 && masterLineForDisplayStatus == 1 && masterLineGravityCenterStatus == 1 && masterLineGCDisplayStatus == 1){
                    verificationPositionCall = 0;
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
                }
                
            } while (masterLineForTrackingStatus == 0 || masterLineForDisplayStatus == 0 || masterLineGravityCenterStatus == 0 || masterLineGCDisplayStatus == 0);
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Saved Data"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)cellListCreation{
    string connectDataStatus = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat";
    string lineageFolderPath2;
    
    ifstream fin;
    ofstream oin;
    
    //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
    //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
    //	cout<<" arrayTimeSelected "<<counterA<<endl;
    //}
    
    int expandFirstTime = 0;
    if (expandFluorescentOutlineStatus == 1) expandFirstTime = 1;
    
    int *fluorescentDataTemp = new int [timeSelectedCount/10+50];
    int *fluorescentDataTemp2 = new int [timeSelectedCount/10+50];
    int *fluorescentDataTemp3 = new int [timeSelectedCount/10+50];
    int *fluorescentDataTemp4 = new int [timeSelectedCount/10+50];
    int *fluorescentDataTemp5 = new int [timeSelectedCount/10+50];
    int *fluorescentDataTemp6 = new int [timeSelectedCount/10+50];
    
    for (int counter1 = 0; counter1 < timeSelectedCount/10+50; counter1++){
        fluorescentDataTemp [counter1] = 0;
        fluorescentDataTemp2 [counter1] = 0;
        fluorescentDataTemp3 [counter1] = 0;
        fluorescentDataTemp4 [counter1] = 0;
        fluorescentDataTemp5 [counter1] = 0;
        fluorescentDataTemp6 [counter1] = 0;
    }
    
    for (int counterY = 0; counterY < imageDimension; counterY++){
        for (int counterX = 0; counterX < imageDimension; counterX++){
            if (revisedWorkingMap [counterY][counterX] != 0){
                if (fluorescentEntryCount >= 1){
                    if (fluorescentCutOff1 >= fluorescentMap1 [counterY][counterX]) fluorescentDataTemp [revisedWorkingMap [counterY][counterX]] = fluorescentDataTemp [revisedWorkingMap [counterY][counterX]]+fluorescentMap1 [counterY][counterX];
                }
                if (fluorescentEntryCount >= 2){
                    if (fluorescentCutOff2 >= fluorescentMap2 [counterY][counterX]) fluorescentDataTemp2 [revisedWorkingMap [counterY][counterX]] = fluorescentDataTemp2 [revisedWorkingMap [counterY][counterX]]+fluorescentMap2 [counterY][counterX];
                }
                if (fluorescentEntryCount >= 3){
                    if (fluorescentCutOff3 >= fluorescentMap3 [counterY][counterX]) fluorescentDataTemp3 [revisedWorkingMap [counterY][counterX]] = fluorescentDataTemp3 [revisedWorkingMap [counterY][counterX]]+fluorescentMap3 [counterY][counterX];
                }
                if (fluorescentEntryCount >= 4){
                    if (fluorescentCutOff4 >= fluorescentMap4 [counterY][counterX]) fluorescentDataTemp4 [revisedWorkingMap [counterY][counterX]] = fluorescentDataTemp4 [revisedWorkingMap [counterY][counterX]]+fluorescentMap4 [counterY][counterX];
                }
                if (fluorescentEntryCount >= 5){
                    if (fluorescentCutOff5 >= fluorescentMap5 [counterY][counterX]) fluorescentDataTemp5 [revisedWorkingMap [counterY][counterX]] = fluorescentDataTemp5 [revisedWorkingMap [counterY][counterX]]+fluorescentMap5 [counterY][counterX];
                }
                if (fluorescentEntryCount >= 6){
                    if (fluorescentCutOff6 >= fluorescentMap6 [counterY][counterX]) fluorescentDataTemp6 [revisedWorkingMap [counterY][counterX]] = fluorescentDataTemp6 [revisedWorkingMap [counterY][counterX]]+fluorescentMap6 [counterY][counterX];
                }
            }
        }
    }
    
    //for (int counterA = 0; counterA < expandFluorescentOutlineCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentOutline [counterA*4+counterB];
    //    cout<<" expandFluorescentOutline "<<counterA<<endl;
    //}
    
    //for (int counterA = 0; counterA < expandFluorescentDataCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentData [counterA*4+counterB];
    //    cout<<" expandFluorescentData "<<counterA<<endl;
    //}
    
    int *expandFluorescentOutlineHold;
    int expandFluorescentOutlineHoldCount = 0;
    int expandFluorescentOutlineSet = 0;
    int *expandFluorescentDataHold;
    int expandFluorescentDataHoldCount = 0;
    int expandFluorescentDataSet = 0;
    
    if (expandFluorescentOutlineStatus == 1){
        expandFluorescentOutlineHold = new int [expandFluorescentOutlineCount+50];
        
        for (int counter1 = 0; counter1 < expandFluorescentOutlineCount; counter1++) expandFluorescentOutlineHold [expandFluorescentOutlineHoldCount] = expandFluorescentOutline [counter1], expandFluorescentOutlineHoldCount++;
        
        expandFluorescentOutlineCount = 0;
        expandFluorescentOutlineSet = 1;
    }
    
    if (expandFluorescentDataStatus == 1){
        expandFluorescentDataHold = new int [expandFluorescentDataCount+50];
        
        for (int counter1 = 0; counter1 < expandFluorescentDataCount; counter1++) expandFluorescentDataHold [expandFluorescentDataHoldCount] = expandFluorescentData [counter1], expandFluorescentDataHoldCount++;
        
        expandFluorescentDataCount = 0;
        expandFluorescentDataSet = 1;
    }
    
    string extensionNumber;
    int areaFluorescent = 0;
    int entryCount = 0;
    int modifyStartFlag = 0;
    int readBit [3];
    int dataTemp = 0;
    int modifyPosition = 0;
    int averageValue = 0;
    int expandFluorescentOutlineTempCount = 0;
    int expandFluorescentDataTempCount = 0;
    int matchFind = 0;
    
    unsigned long indexCount = 0;
    
    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
        areaFluorescent = 0;
        
        for (int counter2 = 0; counter2 < gravityCenterRevCount/6; counter2++){
            if (arrayGravityCenterRev [counter2*6+4] == arrayTimeSelected [counter1*10+8]) areaFluorescent = arrayGravityCenterRev [counter2*6+2];
        }
        
        extensionNumber = to_string(arrayTimeSelected [counter1*10+9]);
        
        if (extensionNumber.length() == 1) extensionNumber = "L0000"+extensionNumber;
        else if (extensionNumber.length() == 2) extensionNumber = "L000"+extensionNumber;
        else if (extensionNumber.length() == 3) extensionNumber = "L00"+extensionNumber;
        else if (extensionNumber.length() == 4) extensionNumber = "L0"+extensionNumber;
        else if (extensionNumber.length() == 5) extensionNumber = "L"+extensionNumber;
        
        if (arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7){
            //========Cell Status Set=========
            lineageFolderPath2 = connectDataStatus+"/"+extensionNumber+"/"+analysisID+"_"+extensionNumber+"_CellStatus";
            
            fin.open(lineageFolderPath2.c_str(), ios::in);
            
            if (fin.is_open()) fin.close();
            else{
                
                oin.open(lineageFolderPath2.c_str(), ios::out);
                oin<<0<<endl;
                oin<<timeOneHold<<endl;
                oin<<-1<<endl;
                oin<<1<<endl;
                oin<<0<<endl;
                oin<<0<<endl;
                oin<<arrayTimeSelected [counter1*10+9]<<endl;
                oin<<"End"<<endl;
                oin.close();
            }
            
            //========Amend Line Set=========
            lineageFolderPath2 = connectDataStatus+"/"+extensionNumber+"/C000000000";
            mkdir(lineageFolderPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            lineageFolderPath2 = connectDataStatus+"/"+extensionNumber+"/C000000000"+"/"+analysisID+"_"+extensionNumber+"_lineDataAmend";
            
            fin.open(lineageFolderPath2.c_str(), ios::in);
            
            if (fin.is_open()) fin.close();
            else{
                
                entryCount = 0;
                modifyStartFlag = 0;
                
                for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                    if (arrayPositionRevise [counter2*7+3] == arrayTimeSelected [counter1*10+8] && modifyStartFlag == 0){
                        entryCount++;
                        modifyStartFlag = 1;
                    }
                    else if (arrayPositionRevise [counter2*7+3] == arrayTimeSelected [counter1*10+8] && modifyStartFlag == 1) entryCount++;
                    else if (arrayPositionRevise [counter2*7+3] != arrayTimeSelected [counter1*10+8] && modifyStartFlag == 1){
                        break;
                    }
                }
                
                //-----1. Image No, 2, X position, 3 Y position, 4. Event, 5. Connect No, 6. Lineage NO-----
                if (entryCount != 0){
                    indexCount = 0;
                    
                    char *writingArray = new char [entryCount*13+20];
                    
                    for (int counter2 = 0; counter2 < positionReviseCount/7; counter2++){
                        if (arrayPositionRevise [counter2*7+3] == counter1+1){
                            dataTemp = imageNumber;
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            dataTemp = arrayPositionRevise [counter2*7];
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            dataTemp = arrayPositionRevise [counter2*7+1];
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            writingArray [indexCount] = 1, indexCount++;
                            
                            dataTemp = arrayPositionRevise [counter2*7+3];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            dataTemp = arrayPositionRevise [counter2*7+6];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < 13; counter2++) writingArray [indexCount] = 0, indexCount++;
                    
                    ofstream outfile (lineageFolderPath2.c_str(), ofstream::binary);
                    outfile.write ((char*)writingArray, indexCount);
                    outfile.close();
                    
                    delete [] writingArray;
                }
            }
            
            //========Fluorescent Quantitation Data Set=========
            //========Non Auto Expand mode, if no previous data exist, Use data in positionRevise and Set Data=======
            //========Non auto Expand mode, if previous data is found, Copy previous data, but if new areas are found, new data will be set=======
            //========Auto Expansion Mode, See next========
            
            if (fluorescentDetection == 1){
                if (autoExpand == 0){
                    if (expandFirstTime == 0){
                        if (expandFluorescentOutlineStatus == 0){
                            expandFluorescentOutline = new int [10000];
                            expandFluorescentOutlineCount = 0;
                            expandFluorescentOutlineLimit = 10000;
                            expandFluorescentOutlineStatus = 1;
                        }
                        
                        int *expandFluorescentOutlineTemp = new int [positionReviseCount*4+50];
                        expandFluorescentOutlineTempCount = 0;
                        
                        modifyPosition = 0;
                        
                        for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                            if (arrayPositionRevise [counter2*7+3] == arrayTimeSelected [counter1*10+8] && modifyPosition == 0){
                                if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate expandFluorescentOutlineUpDate];
                                }
                                
                                if (expandFluorescentOutlineCount+30 > expandFluorescentOutlineLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate fileDeleteUpDate];
                                }
                                
                                expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter2*7], expandFluorescentOutlineTempCount++;
                                expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter2*7+1], expandFluorescentOutlineTempCount++;
                                expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter2*7+3], expandFluorescentOutlineTempCount++;
                                expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = 1, expandFluorescentOutlineTempCount++;
                                
                                expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter2*7], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter2*7+1], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter2*7+3], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = 1, expandFluorescentOutlineCount++;
                                
                                modifyPosition = 1;
                            }
                            else if (arrayPositionRevise [counter2*7+3] == arrayTimeSelected [counter1*10+8] && modifyPosition == 1){
                                if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate expandFluorescentOutlineUpDate];
                                }
                                
                                expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter2*7], expandFluorescentOutlineTempCount++;
                                expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter2*7+1], expandFluorescentOutlineTempCount++;
                                expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter2*7+3], expandFluorescentOutlineTempCount++;
                                expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = 1, expandFluorescentOutlineTempCount++;
                                
                                expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter2*7], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter2*7+1], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter2*7+3], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = 1, expandFluorescentOutlineCount++;
                            }
                            else if (arrayPositionRevise [counter2*7+3] != arrayTimeSelected [counter1*10+8] && modifyPosition == 1){
                                break;
                            }
                        }
                        
                        if (fluorescentEntryCount >= 2){
                            for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount/4; counter2++){
                                if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate expandFluorescentOutlineUpDate];
                                }
                                
                                expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4+1], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4+2], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = 2, expandFluorescentOutlineCount++;
                            }
                        }
                        
                        if (fluorescentEntryCount >= 3){
                            for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount/4; counter2++){
                                if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate expandFluorescentOutlineUpDate];
                                }
                                
                                expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4+1], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4+2], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = 3, expandFluorescentOutlineCount++;
                            }
                        }
                        
                        if (fluorescentEntryCount >= 4){
                            for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount/4; counter2++){
                                if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate expandFluorescentOutlineUpDate];
                                }
                                
                                expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4+1], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4+2], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = 4, expandFluorescentOutlineCount++;
                            }
                        }
                        
                        if (fluorescentEntryCount >= 5){
                            for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount/4; counter2++){
                                if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate expandFluorescentOutlineUpDate];
                                }
                                
                                expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4+1], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4+2], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = 5, expandFluorescentOutlineCount++;
                            }
                        }
                        
                        if (fluorescentEntryCount >= 6){
                            for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount/4; counter2++){
                                if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate expandFluorescentOutlineUpDate];
                                }
                                
                                expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4+1], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4+2], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = 6, expandFluorescentOutlineCount++;
                            }
                        }
                        
                        delete [] expandFluorescentOutlineTemp;
                        
                        if (expandFluorescentDataStatus == 0){
                            expandFluorescentData = new int [10000];
                            expandFluorescentDataCount = 0;
                            expandFluorescentDataLimit = 10000;
                            expandFluorescentDataStatus = 1;
                        }
                        
                        averageValue = (int)(fluorescentDataTemp [arrayTimeSelected [counter1*10+8]]/(double)areaFluorescent);
                        
                        if (expandFluorescentDataCount+20 > expandFluorescentDataLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate expandFluorescentDataUpDate];
                        }
                        
                        expandFluorescentData [expandFluorescentDataCount] = arrayTimeSelected [counter1*10+8], expandFluorescentDataCount++;
                        expandFluorescentData [expandFluorescentDataCount] = 1, expandFluorescentDataCount++;
                        expandFluorescentData [expandFluorescentDataCount] = averageValue, expandFluorescentDataCount++;
                        expandFluorescentData [expandFluorescentDataCount] = areaFluorescent, expandFluorescentDataCount++;
                        
                        if (fluorescentEntryCount >= 2){
                            averageValue = (int)(fluorescentDataTemp2 [arrayTimeSelected [counter1*10+8]]/(double)areaFluorescent);
                            
                            expandFluorescentData [expandFluorescentDataCount] = arrayTimeSelected [counter1*10+8], expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = 2, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = averageValue, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = areaFluorescent, expandFluorescentDataCount++;
                        }
                        
                        if (fluorescentEntryCount >= 3){
                            averageValue = (int)(fluorescentDataTemp3 [arrayTimeSelected [counter1*10+8]]/(double)areaFluorescent);
                            
                            expandFluorescentData [expandFluorescentDataCount] = arrayTimeSelected [counter1*10+8], expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = 3, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = averageValue, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = areaFluorescent, expandFluorescentDataCount++;
                        }
                        
                        if (fluorescentEntryCount >= 4){
                            averageValue = (int)(fluorescentDataTemp4 [arrayTimeSelected [counter1*10+8]]/(double)areaFluorescent);
                            
                            expandFluorescentData [expandFluorescentDataCount] = arrayTimeSelected [counter1*10+8], expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = 4, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = averageValue, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = areaFluorescent, expandFluorescentDataCount++;
                        }
                        
                        if (fluorescentEntryCount >= 3){
                            averageValue = (int)(fluorescentDataTemp5 [arrayTimeSelected [counter1*10+8]]/(double)areaFluorescent);
                            
                            expandFluorescentData [expandFluorescentDataCount] = arrayTimeSelected [counter1*10+8], expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = 5, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = averageValue, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = areaFluorescent, expandFluorescentDataCount++;
                        }
                        
                        if (fluorescentEntryCount >= 3){
                            averageValue = (int)(fluorescentDataTemp6 [arrayTimeSelected [counter1*10+8]]/(double)areaFluorescent);
                            
                            expandFluorescentData [expandFluorescentDataCount] = arrayTimeSelected [counter1*10+8], expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = 6, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = averageValue, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = areaFluorescent, expandFluorescentDataCount++;
                        }
                    }
                    else{
                        
                        int dataSize = 0;
                        
                        if (positionReviseCount > expandFluorescentOutlineHoldCount) dataSize = positionReviseCount;
                        else dataSize = expandFluorescentOutlineHoldCount;
                        
                        int dataSize2 = 0;
                        
                        if (timeSelectedCount > expandFluorescentDataHoldCount) dataSize2 = timeSelectedCount;
                        else dataSize2 = expandFluorescentDataHoldCount;
                        
                        int *expandFluorescentOutlineTemp = new int [dataSize+50];
                        expandFluorescentOutlineTempCount = 0;
                        int *expandFluorescentDataTemp = new int [dataSize2+50];
                        expandFluorescentDataTempCount = 0;
                        
                        matchFind = 0;
                        
                        for (int counter2 = 0; counter2 < expandFluorescentOutlineHoldCount/4; counter2++){
                            if (expandFluorescentOutlineHold [counter2*4+2] == arrayTimeSelected [counter1*10+8]){
                                matchFind = 1;
                                break;
                            }
                        }
                        
                        if (matchFind == 1){
                            for (int counter2 = 0; counter2 < expandFluorescentOutlineHoldCount/4; counter2++){
                                if (expandFluorescentOutlineHold [counter2*4+2] == arrayTimeSelected [counter1*10+8]){
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineHold [counter2*4], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineHold [counter2*4+1], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineHold [counter2*4+2], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineHold [counter2*4+3], expandFluorescentOutlineTempCount++;
                                }
                            }
                            
                            for (int counter2 = 0; counter2 < expandFluorescentDataHoldCount/4; counter2++){
                                if (expandFluorescentDataHold [counter2*4] == arrayTimeSelected [counter1*10+8]){
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = expandFluorescentDataHold [counter2*4], expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = expandFluorescentDataHold [counter2*4+1], expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = expandFluorescentDataHold [counter2*4+2], expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = expandFluorescentDataHold [counter2*4+3], expandFluorescentDataTempCount++;
                                }
                            }
                        }
                        else{
                            
                            modifyPosition = 0;
                            
                            for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                                if (arrayPositionRevise [counter2*7+3] == arrayTimeSelected [counter1*10+8] && modifyPosition == 0){
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter2*7], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter2*7+1], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter2*7+3], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = 1, expandFluorescentOutlineTempCount++;
                                    
                                    modifyPosition = 1;
                                }
                                else if (arrayPositionRevise [counter2*7+3] == arrayTimeSelected [counter1*10+8] && modifyPosition == 1){
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter2*7], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter2*7+1], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter2*7+3], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = 1, expandFluorescentOutlineTempCount++;
                                }
                                else if (arrayPositionRevise [counter2*7+3] != arrayTimeSelected [counter1*10+8] && modifyPosition == 1){
                                    break;
                                }
                            }
                            
                            averageValue = (int)(fluorescentDataTemp [arrayTimeSelected [counter1*10+8]]/(double)areaFluorescent);
                            
                            expandFluorescentDataTemp [expandFluorescentDataTempCount] = arrayTimeSelected [counter1*10+8], expandFluorescentDataTempCount++;
                            expandFluorescentDataTemp [expandFluorescentDataTempCount] = 1, expandFluorescentDataTempCount++;
                            expandFluorescentDataTemp [expandFluorescentDataTempCount] = averageValue, expandFluorescentDataTempCount++;
                            expandFluorescentDataTemp [expandFluorescentDataTempCount] = areaFluorescent, expandFluorescentDataTempCount++;
                            
                            if (fluorescentEntryCount >= 2){
                                int *expandFluorescentOutlineTemp2 = new int [expandFluorescentOutlineTempCount+50];
                                int expandFluorescentOutlineTempCount2 = 0;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount; counter2++) expandFluorescentOutlineTemp2 [expandFluorescentOutlineTempCount2] = expandFluorescentOutlineTemp [counter2], expandFluorescentOutlineTempCount2++;
                                
                                delete [] expandFluorescentOutlineTemp;
                                expandFluorescentOutlineTemp = new int [expandFluorescentOutlineTempCount2*2+50];
                                expandFluorescentOutlineTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount2; counter2++) expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2], expandFluorescentOutlineTempCount++;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount2/4; counter2++){
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4+1], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4+2], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = 2, expandFluorescentOutlineTempCount++;
                                }
                                
                                delete [] expandFluorescentOutlineTemp2;
                                
                                averageValue = (int)(fluorescentDataTemp2 [arrayTimeSelected [counter1*10+8]]/(double)areaFluorescent);
                                
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = arrayTimeSelected [counter1*10+8], expandFluorescentDataTempCount++;
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = 2, expandFluorescentDataTempCount++;
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = averageValue, expandFluorescentDataTempCount++;
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = areaFluorescent, expandFluorescentDataTempCount++;
                            }
                            
                            if (fluorescentEntryCount >= 3){
                                int *expandFluorescentOutlineTemp2 = new int [expandFluorescentOutlineTempCount+50];
                                int expandFluorescentOutlineTempCount2 = 0;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount; counter2++) expandFluorescentOutlineTemp2 [expandFluorescentOutlineTempCount2] = expandFluorescentOutlineTemp [counter2], expandFluorescentOutlineTempCount2++;
                                
                                delete [] expandFluorescentOutlineTemp;
                                expandFluorescentOutlineTemp = new int [expandFluorescentOutlineTempCount2*2+50];
                                expandFluorescentOutlineTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount2; counter2++) expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2], expandFluorescentOutlineTempCount++;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount2/4; counter2++){
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4+1], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4+2], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = 3, expandFluorescentOutlineTempCount++;
                                }
                                
                                delete [] expandFluorescentOutlineTemp2;
                                
                                averageValue = (int)(fluorescentDataTemp3 [arrayTimeSelected [counter1*10+8]]/(double)areaFluorescent);
                                
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = arrayTimeSelected [counter1*10+8], expandFluorescentDataTempCount++;
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = 3, expandFluorescentDataTempCount++;
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = averageValue, expandFluorescentDataTempCount++;
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = areaFluorescent, expandFluorescentDataTempCount++;
                            }
                            
                            if (fluorescentEntryCount >= 4){
                                int *expandFluorescentOutlineTemp2 = new int [expandFluorescentOutlineTempCount+50];
                                int expandFluorescentOutlineTempCount2 = 0;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount; counter2++) expandFluorescentOutlineTemp2 [expandFluorescentOutlineTempCount2] = expandFluorescentOutlineTemp [counter2], expandFluorescentOutlineTempCount2++;
                                
                                delete [] expandFluorescentOutlineTemp;
                                expandFluorescentOutlineTemp = new int [expandFluorescentOutlineTempCount2*2+50];
                                expandFluorescentOutlineTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount2; counter2++) expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2], expandFluorescentOutlineTempCount++;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount2/4; counter2++){
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4+1], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4+2], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = 4, expandFluorescentOutlineTempCount++;
                                }
                                
                                delete [] expandFluorescentOutlineTemp2;
                                
                                averageValue = (int)(fluorescentDataTemp3 [arrayTimeSelected [counter1*10+8]]/(double)areaFluorescent);
                                
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = arrayTimeSelected [counter1*10+8], expandFluorescentDataTempCount++;
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = 4, expandFluorescentDataTempCount++;
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = averageValue, expandFluorescentDataTempCount++;
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = areaFluorescent, expandFluorescentDataTempCount++;
                            }
                            
                            if (fluorescentEntryCount >= 5){
                                int *expandFluorescentOutlineTemp2 = new int [expandFluorescentOutlineTempCount+50];
                                int expandFluorescentOutlineTempCount2 = 0;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount; counter2++) expandFluorescentOutlineTemp2 [expandFluorescentOutlineTempCount2] = expandFluorescentOutlineTemp [counter2], expandFluorescentOutlineTempCount2++;
                                
                                delete [] expandFluorescentOutlineTemp;
                                expandFluorescentOutlineTemp = new int [expandFluorescentOutlineTempCount2*2+50];
                                expandFluorescentOutlineTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount2; counter2++) expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2], expandFluorescentOutlineTempCount++;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount2/4; counter2++){
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4+1], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4+2], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = 5, expandFluorescentOutlineTempCount++;
                                }
                                
                                delete [] expandFluorescentOutlineTemp2;
                                
                                averageValue = (int)(fluorescentDataTemp3 [arrayTimeSelected [counter1*10+8]]/(double)areaFluorescent);
                                
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = arrayTimeSelected [counter1*10+8], expandFluorescentDataTempCount++;
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = 5, expandFluorescentDataTempCount++;
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = averageValue, expandFluorescentDataTempCount++;
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = areaFluorescent, expandFluorescentDataTempCount++;
                            }
                            
                            if (fluorescentEntryCount >= 6){
                                int *expandFluorescentOutlineTemp2 = new int [expandFluorescentOutlineTempCount+50];
                                int expandFluorescentOutlineTempCount2 = 0;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount; counter2++) expandFluorescentOutlineTemp2 [expandFluorescentOutlineTempCount2] = expandFluorescentOutlineTemp [counter2], expandFluorescentOutlineTempCount2++;
                                
                                delete [] expandFluorescentOutlineTemp;
                                expandFluorescentOutlineTemp = new int [expandFluorescentOutlineTempCount2*2+50];
                                expandFluorescentOutlineTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount2; counter2++) expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2], expandFluorescentOutlineTempCount++;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount2/4; counter2++){
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4+1], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4+2], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = 6, expandFluorescentOutlineTempCount++;
                                }
                                
                                delete [] expandFluorescentOutlineTemp2;
                                
                                averageValue = (int)(fluorescentDataTemp3 [arrayTimeSelected [counter1*10+8]]/(double)areaFluorescent);
                                
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = arrayTimeSelected [counter1*10+8], expandFluorescentDataTempCount++;
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = 6, expandFluorescentDataTempCount++;
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = averageValue, expandFluorescentDataTempCount++;
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = areaFluorescent, expandFluorescentDataTempCount++;
                            }
                        }
                        
                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate expandFluorescentOutlineUpDate];
                        }
                        
                        for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount/4; counter2++){
                            expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4], expandFluorescentOutlineCount++;
                            expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4+1], expandFluorescentOutlineCount++;
                            expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4+2], expandFluorescentOutlineCount++;
                            expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4+3], expandFluorescentOutlineCount++;
                        }
                        
                        if (expandFluorescentDataCount+20 > expandFluorescentDataLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate expandFluorescentDataUpDate];
                        }
                        
                        for (int counter2 = 0; counter2 < expandFluorescentDataTempCount/4; counter2++){
                            expandFluorescentData [expandFluorescentDataCount] = expandFluorescentDataTemp [counter2*4], expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = expandFluorescentDataTemp [counter2*4+1], expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = expandFluorescentDataTemp [counter2*4+2], expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = expandFluorescentDataTemp [counter2*4+3], expandFluorescentDataCount++;
                        }
                        
                        delete [] expandFluorescentOutlineTemp;
                        delete [] expandFluorescentDataTemp;
                    }
                }
            }
        }
    }
    
    //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
    //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
    //	cout<<" arrayTimeSelected "<<counterA+1<<" "<<endl;
    //}
    
    if (fluorescentDetection == 1){
        //========Auto Expansion Mode========
        if (fluorescentDetection == 1 && autoExpand == 1){
            if (expandFluorescentOutlineStatus == 0){
                expandFluorescentOutline = new int [10000];
                expandFluorescentOutlineCount = 0;
                expandFluorescentOutlineLimit = 10000;
                expandFluorescentOutlineStatus = 1;
            }
            else expandFluorescentOutlineCount = 0;
            
            if (expandFluorescentDataStatus == 0){
                expandFluorescentData = new int [10000];
                expandFluorescentDataCount = 0;
                expandFluorescentDataLimit = 10000;
                expandFluorescentDataStatus = 1;
            }
            else expandFluorescentDataCount = 0;
            
            int maxConnect = 0;
            
            for (int counterY = 0; counterY < imageDimension; counterY++){
                for (int counterX = 0; counterX < imageDimension; counterX++){
                    if (revisedWorkingMap [counterY][counterX] > maxConnect) maxConnect = revisedWorkingMap [counterY][counterX];
                }
            }
            
            connectDataExchange = new int [maxConnect+5];
            connectDataExchangeStatus = 1;
            
            for (int counter1 = 1; counter1 < maxConnect+5; counter1++) connectDataExchange [counter1] = 0;
            
            int connectNo = 0;
            
            for (int counterY = 0; counterY < imageDimension; counterY++){
                for (int counterX = 0; counterX < imageDimension; counterX++){
                    if (revisedWorkingMap [counterY][counterX] != 0){
                        connectNo = revisedWorkingMap [counterY][counterX];
                        connectDataExchange [connectNo]++;
                    }
                }
            }
            
            //for (int counterA = 1; counterA < maxConnect+1; counterA++){
            //  cout<<counterA<<" "<<connectDataExchange [counterA]<<" connectDataExchange"<<endl;
            //}
            
            int connectStatus = 0;
            int startPosition = 0;
            int statusReturn = 0;
            
            for (int counter1 = 1; counter1 < maxConnect+1; counter1++){
                if (connectDataExchange [counter1] != 0){
                    connectStatus = 0;
                    startPosition = 0;
                    
                    for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                        if (arrayTimeSelected [counter2*10+8] == counter1){
                            connectStatus = arrayTimeSelected [counter2*10];
                            startPosition = arrayTimeSelected [counter2*10+2];
                            break;
                        }
                    }
                    
                    if (connectStatus == 1 || connectStatus == 7){
                        statusReturn = [self lineExtend:counter1];
                        
                        if (statusReturn == 1){
                            areaFluorescent = 0;
                            
                            for (int counter2 = 0; counter2 < gravityCenterRevCount/6; counter2++){
                                if (arrayGravityCenterRev [counter2*6+4] == counter1) areaFluorescent = arrayGravityCenterRev [counter2*6+2];
                            }
                            
                            int dataSize = 0;
                            
                            if (positionReviseCount > expandFluorescentOutlineHoldCount) dataSize = positionReviseCount;
                            else dataSize = expandFluorescentOutlineHoldCount;
                            
                            int dataSize2 = 0;
                            
                            if (timeSelectedCount > expandFluorescentDataHoldCount) dataSize2 = timeSelectedCount;
                            else dataSize2 = expandFluorescentDataHoldCount;
                            
                            int *expandFluorescentOutlineTemp = new int [dataSize+50];
                            expandFluorescentOutlineTempCount = 0;
                            int *expandFluorescentDataTemp = new int [dataSize2+50];
                            expandFluorescentDataTempCount = 0;
                            
                            matchFind = 0;
                            
                            for (int counter2 = 0; counter2 < expandFluorescentOutlineHoldCount/4; counter2++){
                                if (expandFluorescentOutlineHold [counter2*4+2] == counter1){
                                    matchFind = 1;
                                    break;
                                }
                            }
                            
                            if (matchFind == 1){
                                for (int counter2 = 0; counter2 < expandFluorescentOutlineHoldCount/4; counter2++){
                                    if (expandFluorescentOutlineHold [counter2*4+2] == counter1){
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineHold [counter2*4], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineHold [counter2*4+1], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineHold [counter2*4+2], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineHold [counter2*4+3], expandFluorescentOutlineTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < expandFluorescentDataHoldCount/4; counter2++){
                                    if (expandFluorescentDataHold [counter2*4] == counter1){
                                        expandFluorescentDataTemp [expandFluorescentDataTempCount] = expandFluorescentDataHold [counter2*4], expandFluorescentDataTempCount++;
                                        expandFluorescentDataTemp [expandFluorescentDataTempCount] = expandFluorescentDataHold [counter2*4+1], expandFluorescentDataTempCount++;
                                        expandFluorescentDataTemp [expandFluorescentDataTempCount] = expandFluorescentDataHold [counter2*4+2], expandFluorescentDataTempCount++;
                                        expandFluorescentDataTemp [expandFluorescentDataTempCount] = expandFluorescentDataHold [counter2*4+3], expandFluorescentDataTempCount++;
                                    }
                                }
                            }
                            else{
                                
                                modifyPosition = 0;
                                
                                for (int counter2 = startPosition; counter2 < positionReviseCount/7; counter2++){
                                    if (arrayPositionRevise [counter2*7+3] == counter1 && modifyPosition == 0){
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter2*7], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter2*7+1], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter2*7+3], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = 1, expandFluorescentOutlineTempCount++;
                                        
                                        modifyPosition = 1;
                                    }
                                    else if (arrayPositionRevise [counter2*7+3] == counter1 && modifyPosition == 1){
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter2*7], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter2*7+1], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = arrayPositionRevise [counter2*7+3], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = 1, expandFluorescentOutlineTempCount++;
                                    }
                                    else if (arrayPositionRevise [counter2*7+3] != counter1 && modifyPosition == 1){
                                        break;
                                    }
                                }
                                
                                averageValue = (int)(fluorescentDataTemp [counter1]/(double)areaFluorescent);
                                
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = counter1, expandFluorescentDataTempCount++;
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = 1, expandFluorescentDataTempCount++;
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = averageValue, expandFluorescentDataTempCount++;
                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = areaFluorescent, expandFluorescentDataTempCount++;
                                
                                if (fluorescentEntryCount >= 2){
                                    int *expandFluorescentOutlineTemp2 = new int [expandFluorescentOutlineTempCount+50];
                                    int expandFluorescentOutlineTempCount2 = 0;
                                    
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount; counter2++) expandFluorescentOutlineTemp2 [expandFluorescentOutlineTempCount2] = expandFluorescentOutlineTemp [counter2], expandFluorescentOutlineTempCount2++;
                                    
                                    delete [] expandFluorescentOutlineTemp;
                                    expandFluorescentOutlineTemp = new int [expandFluorescentOutlineTempCount2*2+50];
                                    expandFluorescentOutlineTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount2; counter2++) expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2], expandFluorescentOutlineTempCount++;
                                    
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount2/4; counter2++){
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4+1], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4+2], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = 2, expandFluorescentOutlineTempCount++;
                                    }
                                    
                                    delete [] expandFluorescentOutlineTemp2;
                                    
                                    averageValue = (int)(fluorescentDataTemp2 [counter1]/(double)areaFluorescent);
                                    
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = counter1, expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = 2, expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = averageValue, expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = areaFluorescent, expandFluorescentDataTempCount++;
                                }
                                
                                if (fluorescentEntryCount >= 3){
                                    int *expandFluorescentOutlineTemp2 = new int [expandFluorescentOutlineTempCount+50];
                                    int expandFluorescentOutlineTempCount2 = 0;
                                    
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount; counter2++) expandFluorescentOutlineTemp2 [expandFluorescentOutlineTempCount2] = expandFluorescentOutlineTemp [counter2], expandFluorescentOutlineTempCount2++;
                                    
                                    delete [] expandFluorescentOutlineTemp;
                                    expandFluorescentOutlineTemp = new int [expandFluorescentOutlineTempCount2*2+50];
                                    expandFluorescentOutlineTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount2; counter2++) expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2], expandFluorescentOutlineTempCount++;
                                    
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount2/4; counter2++){
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4+1], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4+2], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = 3, expandFluorescentOutlineTempCount++;
                                    }
                                    
                                    delete [] expandFluorescentOutlineTemp2;
                                    
                                    averageValue = (int)(fluorescentDataTemp3 [counter1]/(double)areaFluorescent);
                                    
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = counter1, expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = 3, expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = averageValue, expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = areaFluorescent, expandFluorescentDataTempCount++;
                                }
                                
                                if (fluorescentEntryCount >= 4){
                                    int *expandFluorescentOutlineTemp2 = new int [expandFluorescentOutlineTempCount+50];
                                    int expandFluorescentOutlineTempCount2 = 0;
                                    
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount; counter2++) expandFluorescentOutlineTemp2 [expandFluorescentOutlineTempCount2] = expandFluorescentOutlineTemp [counter2], expandFluorescentOutlineTempCount2++;
                                    
                                    delete [] expandFluorescentOutlineTemp;
                                    expandFluorescentOutlineTemp = new int [expandFluorescentOutlineTempCount2*2+50];
                                    expandFluorescentOutlineTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount2; counter2++) expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2], expandFluorescentOutlineTempCount++;
                                    
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount2/4; counter2++){
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4+1], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4+2], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = 4, expandFluorescentOutlineTempCount++;
                                    }
                                    
                                    delete [] expandFluorescentOutlineTemp2;
                                    
                                    averageValue = (int)(fluorescentDataTemp3 [counter1]/(double)areaFluorescent);
                                    
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = counter1, expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = 4, expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = averageValue, expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = areaFluorescent, expandFluorescentDataTempCount++;
                                }
                                
                                if (fluorescentEntryCount >= 5){
                                    int *expandFluorescentOutlineTemp2 = new int [expandFluorescentOutlineTempCount+50];
                                    int expandFluorescentOutlineTempCount2 = 0;
                                    
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount; counter2++) expandFluorescentOutlineTemp2 [expandFluorescentOutlineTempCount2] = expandFluorescentOutlineTemp [counter2], expandFluorescentOutlineTempCount2++;
                                    
                                    delete [] expandFluorescentOutlineTemp;
                                    expandFluorescentOutlineTemp = new int [expandFluorescentOutlineTempCount2*2+50];
                                    expandFluorescentOutlineTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount2; counter2++) expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2], expandFluorescentOutlineTempCount++;
                                    
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount2/4; counter2++){
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4+1], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4+2], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = 5, expandFluorescentOutlineTempCount++;
                                    }
                                    
                                    delete [] expandFluorescentOutlineTemp2;
                                    
                                    averageValue = (int)(fluorescentDataTemp3 [counter1]/(double)areaFluorescent);
                                    
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = counter1, expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = 5, expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = averageValue, expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = areaFluorescent, expandFluorescentDataTempCount++;
                                }
                                
                                if (fluorescentEntryCount >= 6){
                                    int *expandFluorescentOutlineTemp2 = new int [expandFluorescentOutlineTempCount+50];
                                    int expandFluorescentOutlineTempCount2 = 0;
                                    
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount; counter2++) expandFluorescentOutlineTemp2 [expandFluorescentOutlineTempCount2] = expandFluorescentOutlineTemp [counter2], expandFluorescentOutlineTempCount2++;
                                    
                                    delete [] expandFluorescentOutlineTemp;
                                    expandFluorescentOutlineTemp = new int [expandFluorescentOutlineTempCount2*2+50];
                                    expandFluorescentOutlineTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount2; counter2++) expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2], expandFluorescentOutlineTempCount++;
                                    
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount2/4; counter2++){
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4+1], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutlineTemp2 [counter2*4+2], expandFluorescentOutlineTempCount++;
                                        expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = 6, expandFluorescentOutlineTempCount++;
                                    }
                                    
                                    delete [] expandFluorescentOutlineTemp2;
                                    
                                    averageValue = (int)(fluorescentDataTemp3 [counter1]/(double)areaFluorescent);
                                    
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = counter1, expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = 6, expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = averageValue, expandFluorescentDataTempCount++;
                                    expandFluorescentDataTemp [expandFluorescentDataTempCount] = areaFluorescent, expandFluorescentDataTempCount++;
                                }
                            }
                            
                            if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate expandFluorescentOutlineUpDate];
                            }
                            
                            for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount/4; counter2++){
                                expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4+1], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4+2], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2*4+3], expandFluorescentOutlineCount++;
                            }
                            
                            if (expandFluorescentDataCount+20 > expandFluorescentDataLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate expandFluorescentDataUpDate];
                            }
                            
                            for (int counter2 = 0; counter2 < expandFluorescentDataTempCount/4; counter2++){
                                expandFluorescentData [expandFluorescentDataCount] = expandFluorescentDataTemp [counter2*4], expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = expandFluorescentDataTemp [counter2*4+1], expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = expandFluorescentDataTemp [counter2*4+2], expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = expandFluorescentDataTemp [counter2*4+3], expandFluorescentDataCount++;
                            }
                            
                            delete [] expandFluorescentOutlineTemp;
                            delete [] expandFluorescentDataTemp;
                        }
                    }
                }
            }
            
            delete [] connectDataExchange;
            connectDataExchangeStatus = 0;
        }
        
        //for (int counterA = 0; counterA < expandFluorescentOutlineCount/4; counterA++){
        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentOutline [counterA*4+counterB];
        //    cout<<" expandFluorescentOutline "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < expandFluorescentDataCount/4; counterA++){
        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentData [counterA*4+counterB];
        //    cout<<" expandFluorescentData "<<counterA<<endl;
        //}
        
        string lineageNoExtension = to_string(timeOneHold);
        
        if (lineageNoExtension.length() == 1) lineageNoExtension = "000"+lineageNoExtension;
        else if (lineageNoExtension.length() == 2) lineageNoExtension = "00"+lineageNoExtension;
        else if (lineageNoExtension.length() == 3) lineageNoExtension = "0"+lineageNoExtension;
        
        string fluorescentExpandPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+lineageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendLineData";
        
        indexCount = 0;
        
        char *writingArray = new char [expandFluorescentOutlineCount*2+200];
        
        for (int counter1 = 0; counter1 < expandFluorescentOutlineCount/4; counter1++){
            dataTemp = expandFluorescentOutline [counter1*4];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            dataTemp = expandFluorescentOutline [counter1*4+1];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            dataTemp = expandFluorescentOutline [counter1*4+2];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)expandFluorescentOutline [counter1*4+3], indexCount++;
        }
        
        for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
        
        ofstream outfile (fluorescentExpandPath.c_str(), ofstream::binary);
        outfile.write ((char*)writingArray, indexCount);
        outfile.close();
        
        delete [] writingArray;
        
        fluorescentExpandPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+lineageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
        
        indexCount = 0;
        
        writingArray = new char [expandFluorescentDataCount*2+20];
        
        for (int counter1 = 0; counter1 < expandFluorescentDataCount/4; counter1++){
            dataTemp = expandFluorescentData [counter1*4];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)expandFluorescentData [counter1*4+1], indexCount++;
            writingArray [indexCount] = (char)expandFluorescentData [counter1*4+2], indexCount++;
            
            dataTemp = expandFluorescentData [counter1*4+3];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
        }
        
        for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
        
        ofstream outfile2 (fluorescentExpandPath.c_str(), ofstream::binary);
        outfile2.write ((char*)writingArray, indexCount);
        outfile2.close();
        
        delete [] writingArray;
    }
    
    if (expandFluorescentOutlineSet == 1) delete [] expandFluorescentOutlineHold;
    if (expandFluorescentDataSet == 1) delete [] expandFluorescentDataHold;
    
    delete [] fluorescentDataTemp;
    delete [] fluorescentDataTemp2;
    delete [] fluorescentDataTemp3;
    delete [] fluorescentDataTemp4;
    delete [] fluorescentDataTemp5;
    delete [] fluorescentDataTemp6;
}

-(void)lineageListCreation{
    //==========Cell Lineage List: 1. Cell Lineage NO, 2. Status, 1: Done, 0: Open, 3. Number of cells in the lineage==========
    
    if (lineageDataCount != 0){
        if (cellLineageInfoStatus == 1){
            delete [] arrayCellLineageInfo;
            cellLineageInfoStatus = 0;
        }
        
        arrayCellLineageInfo = new int [2000];
        cellLineageInfoCount = 0;
        cellLineageInfoLimit = 2000;
        cellLineageInfoStatus = 1;
        
        string lineageFolderPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat";
        string entry;
        string lineageFolderPath2;
        string getString;
        string endTimeQueueTemp;
        string endStatusQueueTemp;
        
        ifstream fin;
        
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(lineageFolderPath.c_str());
        
        if (dir != NULL){
            int lineageStatusTemp = 0;
            int cellNumberCount = 0;
            
            fileDeleteCount = 0;
            
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if (fileDeleteCount+5 > fileDeleteLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate fileDeleteUpDate];
                    }
                    
                    arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                }
            }
            
            closedir(dir);
            
            //-----Directory Sort-----
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
            }
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                if ((int)arrayFileDelete [counter1].find("L") != -1){
                    lineageFolderPath2 = lineageFolderPath+"/"+arrayFileDelete [counter1]+"/"+analysisID+"_"+arrayFileDelete [counter1]+"_CellStatus";
                    
                    fin.open(lineageFolderPath2.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        lineageStatusTemp = 1;
                        cellNumberCount = 0;
                        
                        do{
                            
                            getline(fin, getString);
                            
                            if (getString != "End"){
                                getline(fin, getString);
                                getline(fin, getString), endTimeQueueTemp = getString;
                                getline(fin, getString);
                                getline(fin, getString), endStatusQueueTemp = getString;
                                getline(fin, getString);
                                getline(fin, getString);
                                
                                if (endTimeQueueTemp == "-1" && endStatusQueueTemp == "0") lineageStatusTemp = 0;
                                
                                cellNumberCount++;
                            }
                            
                        } while (getString != "End");
                        
                        fin.close();
                        
                        if (cellLineageInfoCount+3 > cellLineageInfoLimit){
                            int *arrayUpDate = new int [cellLineageInfoCount+10];
                            
                            for (int counter2 = 0; counter2 < cellLineageInfoCount; counter2++) arrayUpDate [counter2] = arrayCellLineageInfo [counter2];
                            
                            delete [] arrayCellLineageInfo;
                            arrayCellLineageInfo = new int [cellLineageInfoLimit+2000];
                            cellLineageInfoLimit = cellLineageInfoLimit+2000;
                            
                            for (int counter2 = 0; counter2 < cellLineageInfoCount; counter2++) arrayCellLineageInfo [counter2] = arrayUpDate [counter2];
                            delete [] arrayUpDate;
                        }
                        
                        arrayCellLineageInfo [cellLineageInfoCount] = atoi((arrayFileDelete [counter1].substr(1)).c_str()), cellLineageInfoCount++;
                        arrayCellLineageInfo [cellLineageInfoCount] = lineageStatusTemp, cellLineageInfoCount++;
                        arrayCellLineageInfo [cellLineageInfoCount] = cellNumberCount, cellLineageInfoCount++;
                    }
                }
            }
        }
        
        string lineageStatusSavePath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStatus";
        
        string extension;
        
        char *mainDataEntry = new char [cellLineageInfoCount*6+10];
        int totalEntryCount = 0;
        
        for (int counter1 = 0; counter1 < cellLineageInfoCount; counter1++){
            extension = to_string(arrayCellLineageInfo [counter1]);
            
            for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
            }
            
            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
        }
        
        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
        
        ofstream outfile3 (lineageStatusSavePath.c_str(), ofstream::binary);
        outfile3.write (mainDataEntry, totalEntryCount);
        outfile3.close();
        
        delete [] mainDataEntry;
    }
}

-(IBAction)areaSelect:(id)sender{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        if (timeOneStatus == 2){
            if (areaSelectStatus == 0){
                areaSelectStatus = 1;
                lineDraw = 0;
                windowLock = 1;
            }
            else if (areaSelectStatus == 1){
                areaSelectStatus = 0;
                windowLock = 0;
            }
            
            lineAreaCall = 1;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lineSelect:(id)sender{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        [self lineSelectProcess];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)lineSelectProcess{
    if (timeOneStatus == 0 && cellNoHold != "" && trackingOn == 1){
        if (queueHoldingStatus == 0){
            if (fluorescentDisplayNo == 0){
                if (lineDraw == 0){
                    firstModificationPoint = 10000,
                    trackingLowerLimit = 0;
                    trackingUpperLimit = 10000;
                    doubleClick = 0;
                    doubleClickStatusHold = 0;
                    
                    ifstream fin;
                    
                    string extension;
                    
                    //-----Map Limit Set-----
                    upperLimitMap = imageEndHold;
                    
                    string mapLimitPath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed";
                    string mapLimitPath2;
                    
                    for (int counter1 = 1; counter1 <= imageEndHold; counter1++){
                        extension = to_string(counter1);
                        
                        if (extension.length() == 1) extension = "000"+extension;
                        else if (extension.length() == 2) extension = "00"+extension;
                        else if (extension.length() == 3) extension = "0"+extension;
                        
                        mapLimitPath2 = mapLimitPath+"/"+extension+"_"+analysisImageName+"_"+treatmentNameHold+"_Map";
                        
                        fin.open(mapLimitPath2.c_str(), ios::in);
                        
                        if (fin.is_open()) fin.close();
                        else if (counter1 != imageEndHold){
                            upperLimitMap = counter1-1;
                            break;
                        }
                        else if (counter1 != imageEndHold) upperLimitMap = counter1;
                    }
                    
                    int upperLimitCell = 0; //-----Cell end image position-----
                    int lowerLimitCell = 0; //-----Cell end image position-----
                    
                    //-----Cell Limit Set Upper-----
                    string cellLineageExtract = cellLineageNoHold.substr(1);
                    string cellNoExtract = cellNoHold.substr(1);
                    int lineageAmendTemp = atoi(cellLineageExtract.c_str());
                    int cellAmendTemp = atoi(cellNoExtract.c_str());
                    int lineageEndPosition = 0;
                    
                    for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                        if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp && arrayLineageStartEnd [counter1*8+1] == cellAmendTemp){
                            lowerLimitCell = arrayLineageStartEnd [counter1*8+5];
                            upperLimitCell = arrayLineageStartEnd [counter1*8+7];
                            lineageEndPosition = arrayLineageStartEnd [counter1*8+6];
                            break;
                        }
                    }
                    
                    int lastEventType = arrayLineageData [lineageEndPosition*8+3];
                    
                    if (lastEventType == 32 || lastEventType == 42 || lastEventType == 52 || lastEventType == 7 || lastEventType == 8 || lastEventType == 91) trackingUpperLimit = upperLimitCell;
                    else if (ifEntry == 0) trackingUpperLimit = upperLimitMap;
                    else if (ifEntry == 1) trackingUpperLimit = upperLimitCell;
                    
                    //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
                    //    cout<<" arrayLineageData "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < connectLineListLocalCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineListLocal [counterA*6+counterB];
                    //	cout<<" arrayConnectLineListLocal "<<counterA<<endl;
                    //}
                    
                    //-----Cell Limit Set Lower-----
                    trackingLowerLimit = lowerLimitCell;
                    
                    //cout<<trackingUpperLimit<<" "<<trackingLowerLimit<<" "<<imageNumberTrackForDisplay<<" Limit "<<upperLimitMap<<endl;
                    
                    if (trackingLowerLimit != 0 && trackingUpperLimit != 0 && trackingLowerLimit <= trackingUpperLimit && trackingLowerLimit <= imageNumberTrackForDisplay && trackingUpperLimit >= imageNumberTrackForDisplay){
                        lineModificationRecord = 0;
                        
                        int totalEventNumber = (lineageDataCount/8+connectLineListLocalCount/6)*4;
                        
                        arrayEventSequence = new int [totalEventNumber+200];
                        eventSequenceCount = 0;
                        eventSequenceLimit = totalEventNumber+50;
                        arrayEventSequenceHold = new int [50];
                        eventSequenceHoldCount = 0;
                        arrayLineageGravityCenterCurrentHold = new int [50];
                        lineageGravityCenterCurrentHoldCount = 0;
                        
                        string connectClearPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold;
                        string entry;
                        string removeFilePath;
                        
                        fileDeleteCount = 0;
                        
                        DIR *dir;
                        struct dirent *dent;
                        
                        dir = opendir(connectClearPath.c_str());
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (fileDeleteCount+5 > fileDeleteLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate fileDeleteUpDate];
                                }
                                
                                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                            }
                            
                            closedir(dir);
                            
                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                entry = arrayFileDelete [counter1];
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    int findFile1 = (int)entry.find("ConnectLineageRelTemp");
                                    int findFile2 = (int)entry.find("CutTemp");
                                    int findFile3 = (int)entry.find("GCCurrentTemp");
                                    int findFile4 = (int)entry.find("MasterDataTemp");
                                    int findFile5 = (int)entry.find("RevisedTempMap");
                                    int findFile6 = (int)entry.find("StatusTemp");
                                    int findFile7 = (int)entry.find("LinkDataTemp");
                                    int findFile8 = (int)entry.find("ExtendAreaDataTemp");
                                    int findFile9 = (int)entry.find("ExtendLineDataTemp");
                                    int findFile10 = (int)entry.find("EventTemp");
                                    int findFile11 = (int)entry.find("MitosisDataTemp");
                                    int findFile12 = (int)entry.find("GCCenterInfo");
                                    
                                    if (findFile1 != -1 || findFile2 != -1 || findFile3 != -1 || findFile4 != -1 || findFile5 != -1 || findFile6 != -1 || findFile7 != -1 || findFile8 != -1 || findFile9 != -1 || findFile10 != -1 || findFile11 != -1 || findFile12 != -1){
                                        removeFilePath = connectClearPath+"/"+entry;
                                        remove (removeFilePath.c_str());
                                    }
                                }
                            }
                        }
                        
                        string copyPath1;
                        
                        for (int counter1 = trackingLowerLimit; counter1 <= upperLimitCell; counter1++){
                            extension = to_string(counter1);
                            
                            if (extension.length() == 1) extension = "000"+extension;
                            else if (extension.length() == 2) extension = "00"+extension;
                            else if (extension.length() == 3) extension = "0"+extension;
                            
                            copyPath1 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_MasterDataTempD";
                            
                            ofstream oin;
                            oin.open(copyPath1.c_str(), ios::out);
                            oin<<"nil"<<endl;
                            oin.close();
                            
                            copyPath1 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_StatusTempD";
                            
                            oin.open(copyPath1.c_str(), ios::out);
                            oin<<"nil"<<endl;
                            oin.close();
                            
                            copyPath1 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ConnectLineageRelTempD";
                            
                            oin.open(copyPath1.c_str(), ios::out);
                            oin<<"nil"<<endl;
                            oin.close();
                            
                            copyPath1 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_RevisedTempMapD";
                            
                            oin.open(copyPath1.c_str(), ios::out);
                            oin<<"nil"<<endl;
                            oin.close();
                            
                            copyPath1 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ExtendLineDataTempD";
                            
                            oin.open(copyPath1.c_str(), ios::out);
                            oin<<"nil"<<endl;
                            oin.close();
                            
                            copyPath1 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ExtendAreaDataTempD";
                            
                            oin.open(copyPath1.c_str(), ios::out);
                            oin<<"nil"<<endl;
                            oin.close();
                            
                            copyPath1 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ExtendAreaDataTempD";
                            
                            oin.open(copyPath1.c_str(), ios::out);
                            oin<<"nil"<<endl;
                            oin.close();
                            
                            copyPath1 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_GCCenterInfoD";
                            
                            oin.open(copyPath1.c_str(), ios::out);
                            oin<<"nil"<<endl;
                            oin.close();
                        }
                        
                        arrayTarget = new int [1000];
                        targetCount = 0;
                        targetLimit = 1000;
                        targetStatus = 1;
                        arrayReferenceLine = new int [5000];
                        referenceLineCount = 0;
                        referenceLineLimit = 5000;
                        
                        if (targetPrevHoldStatus == 0){
                            arrayTargetPrevHold = new int [1000];
                            targetPrevHoldCount = 0;
                            targetPrevHoldLimit = 1000;
                            targetPrevHoldStatus = 1;
                        }
                        
                        //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
                        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
                        //	cout<<" arrayGravityCenterRev "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
                        //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
                        //	cout<<" arrayEventSequence "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
                        //	cout<<" arrayLineageData "<<counterA<<endl;
                        //}
                        
                        //==========EventSequence: 1. ImageNo, 2. EventType, 3. LineageNO, 4. CellNo==========
                        eventSequenceCount = 0;
                        
                        for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                            if (arrayLineageData [counter1*8+6] == lineageAmendTemp && arrayLineageData [counter1*8+5] == cellAmendTemp){
                                arrayEventSequence [eventSequenceCount] = arrayLineageData [counter1*8+2], eventSequenceCount++;
                                arrayEventSequence [eventSequenceCount] = arrayLineageData [counter1*8+3], eventSequenceCount++;
                                arrayEventSequence [eventSequenceCount] = lineageAmendTemp, eventSequenceCount++;
                                arrayEventSequence [eventSequenceCount] = cellAmendTemp, eventSequenceCount++;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
                        //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
                        //	cout<<" arrayEventSequence "<<counterA<<endl;
                        //}
                        
                        int duplicateFind = 0;
                        
                        for (int counter1 = 0; counter1 < connectLineListLocalCount/6; counter1++){
                            duplicateFind = 0;
                            
                            for (int counter2 = 0; counter2 < eventSequenceCount/4; counter2++){
                                if (arrayEventSequence [counter2*4] == arrayConnectLineListLocal [counter1*6+5]) duplicateFind = 1;
                            }
                            
                            if (duplicateFind == 0){
                                if (arrayConnectLineListLocal [counter1*6+5] != 1){
                                    arrayEventSequence [eventSequenceCount] = arrayConnectLineListLocal [counter1*6+5], eventSequenceCount++;
                                    arrayEventSequence [eventSequenceCount] = arrayConnectLineListLocal [counter1*6+2], eventSequenceCount++;
                                    arrayEventSequence [eventSequenceCount] = lineageAmendTemp, eventSequenceCount++;
                                    arrayEventSequence [eventSequenceCount] = cellAmendTemp, eventSequenceCount++;
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
                        //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
                        //	cout<<" arrayEventSequence "<<counterA<<endl;
                        //}
                        
                        lastEventType = 0;
                        int largestTimePoint = 0;
                        
                        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                            if (arrayEventSequence [counter1*4] > largestTimePoint){
                                largestTimePoint = arrayEventSequence [counter1*4];
                                lastEventType = arrayEventSequence [counter1*4+1];
                            }
                        }
                        
                        if (lastEventType == 1 || lastEventType == 2 || lastEventType == 6 || lastEventType == 92 || lastEventType == 10 || lastEventType == 11 || lastEventType == 31 || lastEventType == 41 || lastEventType == 51) autoRefStatus = 1;
                        else autoRefStatus = 0;
                        
                        //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
                        // 	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
                        //	cout<<" arrayEventSequence "<<counterA<<endl;
                        //}
                        
                        eventSequenceHoldCount = 0;
                        
                        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                            if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                                arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4], eventSequenceHoldCount++;
                                arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+1], eventSequenceHoldCount++;
                                arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+2], eventSequenceHoldCount++;
                                arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+3], eventSequenceHoldCount++;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < connectLineListLocalCount/6; counterA++){
                        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineListLocal [counterA*6+counterB];
                        //	cout<<" arrayConnectLineListLocal "<<counterA<<endl;
                        //}
                        
                        int results = 0;
                        int processType = 2;
                        
                        if (ifEntry == 0){
                            processType = 2;
                            trackingSet = [[TrackingSet alloc] init];
                            results = [trackingSet trackingSetMain:processType];
                        }
                        else{
                            
                            processType = 7;
                            trackingSet = [[TrackingSet alloc] init];
                            results = [trackingSet trackingSetMain:processType];
                        }
                        
                        trackingOnInfoDisplay = 1;
                        trackingOn = 3;
                        mergeSelectCount = 0;
                        
                        //==========LineageGRCurrent: 1. ImageNo, 2. X Position GR, 3. Y Position GR, 4. CellNo==========
                        arrayLineageGRCurrent = new int [eventSequenceCount+5000];
                        lineageGRCurrentCount = 0;
                        lineageGRCurrentLimit = eventSequenceCount+5000;
                        lineageGravityCenterCurrentHoldCount = 0;
                        
                        for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                            if (arrayLineageData [counter1*8+6] == lineageAmendTemp && arrayLineageData [counter1*8+5] == cellAmendTemp){
                                arrayLineageGRCurrent [lineageGRCurrentCount] = arrayLineageData [counter1*8+2], lineageGRCurrentCount++;
                                arrayLineageGRCurrent [lineageGRCurrentCount] = arrayLineageData [counter1*8], lineageGRCurrentCount++;
                                arrayLineageGRCurrent [lineageGRCurrentCount] = arrayLineageData [counter1*8+1], lineageGRCurrentCount++;
                                arrayLineageGRCurrent [lineageGRCurrentCount] = cellAmendTemp, lineageGRCurrentCount++;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < lineageGRCurrentCount/4; counter1++){
                            if (arrayLineageGRCurrent [counter1*4] == imageNumberTrackForDisplay){
                                arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter1*4], lineageGravityCenterCurrentHoldCount++;
                                arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter1*4+1], lineageGravityCenterCurrentHoldCount++;
                                arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter1*4+2], lineageGravityCenterCurrentHoldCount++;
                                arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter1*4+3], lineageGravityCenterCurrentHoldCount++;
                            }
                        }
                        
                        if (results == 0){
                            lineDraw = 1;
                            windowLock = 1;
                            doubleClickStatusHold = 0;
                            trackingImageLock = 1;
                            tableTrackingProcessing = 1;
                            listSwitchCall = 1;
                            trackingTableSetDone = 0;
                            tableDataSetDone = 0;
                            ifConnectNoUpDate = 0;
                            ifConnectNoCurrent = 0;
                        }
                        else{
                            
                            trackingLowerLimit = 0;
                            upperLimitMap = 0;
                            trackingUpperLimit = 0;
                            lineDraw = 0;
                            windowLock = 0;
                            doubleClickStatusHold = 0;
                            trackingImageLock = 0;
                            trackingOn = 7;
                            trackingPermit = 0;
                            tableTrackingProcessing = 0;
                            listSwitchCall = 1;
                            tableDataSetDone = 0;
                            trackingTableSetDone = 1;
                            tableListSwitch = 1;
                            lineageCellSwitch = 1;
                            mergeSelectCount = 0;
                            lineSetErrorFlag = 1;
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Data Read Error"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        lineSetErrorFlag = 1;
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Image Position: Outside of Range"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    lineSetErrorFlag = 1;
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Line Set Already ON"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                lineSetErrorFlag = 1;
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Image: change to DIC"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            lineSetErrorFlag = 1;
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto Processing On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else if (timeOneStatus == 2){
        if (lineDraw == 0){
            areaSelectStatus = 0;
            lineDraw = 1;
            windowLock = 1;
        }
        else if (lineDraw == 1){
            lineDraw = 0;
            windowLock = 0;
        }
        
        lineAreaCall = 1;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
    }
    else lineSetErrorFlag = 1;
}

-(IBAction)lineSet:(id)sender{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        int processType = 1;
        lineSet = [[LineSet alloc] init];
        [lineSet lineSetProcess:processType];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)listDisplay:(id)sender{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        if (timeOneStatus == 2 && listSwitchCall == 1){
            listSwitchCall = 2;
            listSwitchCallStatus = 1;
        }
        else if (timeOneStatus == 2 && listSwitchCall == 2){
            listSwitchCall = 1;
            listSwitchCallStatus = 1;
        }
        
        if (timeOneStatus == 0 && listSwitchCall == 1 && trackingOn == 3){
            listSwitchCall = 2;
            listSwitchCallStatus = 1;
        }
        else if (timeOneStatus == 0 && listSwitchCall == 2 && trackingOn == 3){
            listSwitchCall = 1;
            listSwitchCallStatus = 1;
            listOnOffFlag = 0;
        }
        
        if (timeOneStatus == 0 && tableListSwitch == 1 && trackingOn == 1){
            tableListSwitch = 2;
            listSwitchCallStatus = 1;
            listOnOffFlag = 0;
            listCrickMonitor = 1;
        }
        else if (timeOneStatus == 0 && tableListSwitch == 2){
            tableListSwitch = 3;
            listSwitchCallStatus = 1;
            listOnOffFlag = 0;
            listCrickMonitor = 1;
        }
        else if (timeOneStatus == 0 && tableListSwitch == 3){
            tableListSwitch = 1;
            listSwitchCallStatus = 1;
            listOnOffFlag = 0;
            listCrickMonitor = 1;
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)listRemove:(id)sender{
    if (((timeOneStatus == 2 && listSwitchCall == 2) || (trackingOn == 3 && listSwitchCall == 2 && tableRowHold > 0)) && divisionTypeHold == 0){
        if (mainSavingInProgress == 0 && cleaningProgress == 0){
            int *arrayOriginalConnectNumbers = new int [timeSelectedCount+50];
            int originalConnectNumbersCount = 0;
            
            int *timeSelectedLineNext = new int [timeSelectedCount/10+2];
            int *timeSelectedLineNextTemp = new int [timeSelectedCount/10+2];
            
            for (int counter1 = 0; counter1 < targetHoldInfoCount/4+1; counter1++){
                timeSelectedLineNext [counter1] = 0;
                timeSelectedLineNextTemp [counter1] = 0;
            }
            
            int *timeOneRemoveConnectNext = new int [timeSelectedCount/10+2];
            int *timeOneRemoveConnectNextTemp = new int [timeSelectedCount/10+2];
            
            for (int counter1 = 0; counter1 < timeSelectedCount/10+1; counter1++){
                timeOneRemoveConnectNext [counter1] = 0;
                timeOneRemoveConnectNextTemp [counter1] = 0;
            }
            
            timeSelectedLineNextTemp [tableRowHold+1] = 1;
            int terminationFlag = 0;
            int newNumberFindTemp = 0;
            
            //for (int counterA = 0; counterA < counterMax+1; counterA++){
            //	cout<<" "<<timeSelectedLineNextTemp [counterA]<<" timeSelectedLineNextTemp "<<counterA+1<<endl;
            //}
            
            do{
                
                terminationFlag = 1;
                newNumberFindTemp = 0;
                
                for (int counter1 = 1; counter1 < targetHoldInfoCount/4+1; counter1++){
                    if (timeSelectedLineNextTemp [counter1] == 1){
                        for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                            if (arrayTimeSelected [counter2*10+1] == counter1){
                                timeOneRemoveConnectNextTemp [counter2+1] = 1;
                                
                                if (arrayTimeSelected [counter2*10+3] != 0){
                                    timeSelectedLineNextTemp [arrayTimeSelected [counter2*10+3]] = 2;
                                    newNumberFindTemp++;
                                }
                            }
                        }
                    }
                }
                
                if (newNumberFindTemp == 0){
                    for (int counter1 = 1; counter1 < targetHoldInfoCount/4+1; counter1++){
                        if (timeSelectedLineNextTemp [counter1] == 1) timeSelectedLineNext [counter1] = 1;
                    }
                    
                    for (int counter1 = 1; counter1 < timeSelectedCount/10+1; counter1++){
                        if (timeOneRemoveConnectNextTemp [counter1] == 1) timeOneRemoveConnectNext [counter1] = 1;
                    }
                    
                    terminationFlag = 0;
                }
                else{
                    
                    for (int counter1 = 1; counter1 < targetHoldInfoCount/4+1; counter1++){
                        if (timeSelectedLineNextTemp [counter1] == 2){
                            timeSelectedLineNext [counter1] = 1;
                            timeSelectedLineNextTemp [counter1] = 1;
                        }
                        else if (timeSelectedLineNextTemp [counter1] == 1){
                            timeSelectedLineNext [counter1] = 1;
                            timeSelectedLineNextTemp [counter1] = 0;
                        }
                    }
                    
                    for (int counter1 = 1; counter1 < timeSelectedCount/10+1; counter1++){
                        if (timeOneRemoveConnectNextTemp [counter1] == 1){
                            timeOneRemoveConnectNext [counter1] = 1;
                            timeOneRemoveConnectNextTemp [counter1] = 0;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < counterMax+1; counterA++){
                    //     cout<<" "<<timeSelectedLineNextTemp [counterA]<<" timeSelectedLineNextTemp "<<counterA+1<<endl;
                    // }
                    
                    // for (int counterA = 0; counterA < counterMax+1; counterA++){
                    //     cout<<" "<<timeSelectedLineNext [counterA]<<" timeSelectedLineNext "<<counterA+1<<endl;
                    // }
                    
                    // for (int counterA = 0; counterA < counterMax2+1; counterA++){
                    //     cout<<" "<<timeOneRemoveConnectNext [counterA]<<" timeOneRemoveConnectNext "<<counterA+1<<endl;
                    // }
                    
                    // for (int counterA = 0; counterA < counterMax2+1; counterA++){
                    //     cout<<" "<<timeOneRemoveConnectNextTemp [counterA]<<" timeOneRemoveConnectNextTemp "<<counterA+1<<endl;
                    // }
                }
                
            } while (terminationFlag == 1);
            
            delete [] timeSelectedLineNextTemp;
            delete [] timeOneRemoveConnectNextTemp;
            
            int *arrayRemoveLines = new int [targetHoldInfoCount/4+50];
            int removeLinesCount = 0;
            
            for (int counter1 = 1; counter1 < targetHoldInfoCount/4+1; counter1++){
                if (timeSelectedLineNext [counter1] == 1) arrayRemoveLines [removeLinesCount] = counter1, removeLinesCount++;
            }
            
            delete [] timeSelectedLineNext;
            
            int secondMatchFlag = 0;
            
            for (int counter1 = 0; counter1 < removeLinesCount; counter1++){
                for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                    if (arrayTimeSelected [counter2*10+3] == arrayRemoveLines [counter1]){
                        secondMatchFlag = 0;
                        
                        for (int counter3 = 0; counter3 < removeLinesCount; counter3++){
                            if (arrayTimeSelected [counter2*10+1] == arrayRemoveLines [counter3]) secondMatchFlag = 1;
                        }
                        
                        if (secondMatchFlag != 1 || arrayTimeSelected [counter2*10+1] == 0){
                            arrayOriginalConnectNumbers [originalConnectNumbersCount] = arrayTimeSelected [counter2*10+8], originalConnectNumbersCount++;
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < originalConnectNumbersCount; counterA++){
            //	cout<<" "<<arrayOriginalConnectNumbers [counterA]<<" arrayOriginalConnectNumbers "<<counterA+1<<endl;
            // }
            
            int *arrayRemoveConnectNumbers = new int [timeSelectedCount/10+50];
            int removeConnectNumbersCount = 0;
            
            for (int counter1 = 1; counter1 < timeSelectedCount/10+1; counter1++){
                if (timeOneRemoveConnectNext [counter1] == 1) arrayRemoveConnectNumbers [removeConnectNumbersCount] = counter1, removeConnectNumbersCount++;
            }
            
            delete [] timeOneRemoveConnectNext;
            
            //for (int counterA = 0; counterA < removeLinesCount; counterA++){
            //	for (int counterB = 0; counterB < 1; counterB++) cout<<" "<<arrayRemoveLines [counterA+counterB];
            //	cout<<" arrayRemoveLines "<<counterA+1<<endl;
            // }
            
            //for (int counterA = 0; counterA < removeConnectNumbersCount; counterA++){
            //	for (int counterB = 0; counterB < 1; counterB++) cout<<" "<<arrayRemoveConnectNumbers [counterA*1+counterB];
            //	cout<<" arrayRemoveConnectNumbers "<<counterA+1<<endl;
            //}
            
            //-----Cut Line Data-----
            int *arrayTargetHoldTemp = new int [targetHoldCount+100];
            int targetHoldTempCount = 0;
            
            int matchFind = 0;
            
            for (int counter1 = 0; counter1 < targetHoldCount/3; counter1++){
                matchFind = 0;
                
                for (int counter2 = 0; counter2 < removeLinesCount; counter2++){
                    if (arrayRemoveLines [counter2] == arrayTargetHold [counter1*3+2]){
                        matchFind = 1;
                        break;
                    }
                }
                
                if (matchFind == 0 && tableRowHold+1 == arrayTargetHold [counter1*3+2]) matchFind = 1;
                if (matchFind == 0){
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTargetHold [counter1*3], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTargetHold [counter1*3+1], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTargetHold [counter1*3+2], targetHoldTempCount++;
                }
            }
            
            targetHoldCount = 0;
            for (int counter1 = 0; counter1 < targetHoldTempCount; counter1++) arrayTargetHold [targetHoldCount] = arrayTargetHoldTemp [counter1], targetHoldCount++;
            delete [] arrayTargetHoldTemp;
            
            //for (int counterA = 0; counterA < targetHoldCount/3; counterA++){
            //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayTargetHold [counterA*3+counterB];
            //	cout<<" arrayTargetHold "<<counterA+1<<endl;
            //}
            
            int lineNumberNew = 0;
            int lineNumberTemp = 0;
            
            arrayTargetHoldTemp = new int [targetHoldCount+100];
            targetHoldTempCount = 0;
            
            int *arrayMissMatchLine = new int [targetHoldCount+100];
            int missMatchLineCount = 0;
            
            for (int counter1 = 0; counter1 < targetHoldCount/3; counter1++){
                if (arrayTargetHold [counter1*3+2] != lineNumberTemp){
                    lineNumberTemp = arrayTargetHold [counter1*3+2], lineNumberNew++;
                    
                    if (lineNumberTemp != lineNumberNew){
                        arrayMissMatchLine [missMatchLineCount] = lineNumberTemp, missMatchLineCount++;
                        arrayMissMatchLine [missMatchLineCount] = lineNumberNew, missMatchLineCount++;
                    }
                }
                
                arrayTargetHoldTemp [targetHoldTempCount] = arrayTargetHold [counter1*3], targetHoldTempCount++;
                arrayTargetHoldTemp [targetHoldTempCount] = arrayTargetHold [counter1*3+1], targetHoldTempCount++;
                arrayTargetHoldTemp [targetHoldTempCount] = lineNumberNew, targetHoldTempCount++;
            }
            
            targetHoldCount = 0;
            for (int counter1 = 0; counter1 < targetHoldTempCount; counter1++) arrayTargetHold [targetHoldCount] = arrayTargetHoldTemp [counter1], targetHoldCount++;
            delete [] arrayTargetHoldTemp;
            
            //for (int counterA = 0; counterA < targetHoldCount/3; counterA++){
            //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayTargetHold [counterA*3+counterB];
            //	cout<<" arrayTargetHold "<<counterA+1<<endl;
            // }
            
            // for (int counterA = 0; counterA < missMatchLineCount/2; counterA++){
            // 	for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<arrayMissMatchLine [counterA*2+counterB];
            // 	cout<<" arrayMissMatchLine "<<counterA+1<<endl;
            // }
            
            // for (int counterA = 0; counterA < targetHoldInfoCount/4; counterA++){
            // 	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayTargetHoldInfo [counterA*4+counterB];
            // 	cout<<" arrayTargetHoldInfo "<<counterA+1<<endl;
            // }
            
            lineNumberNew = 1;
            
            arrayTargetHoldTemp = new int [targetHoldInfoCount+100], targetHoldTempCount = 0;
            
            for (int counter1 = 0; counter1 < targetHoldInfoCount/4; counter1++){
                matchFind = 0;
                
                for (int counter2 = 0; counter2 < removeLinesCount; counter2++){
                    if (arrayRemoveLines [counter2] == arrayTargetHoldInfo [counter1*4+3]){
                        matchFind = 1;
                        break;
                    }
                }
                
                if (matchFind == 0 && tableRowHold+1 == arrayTargetHoldInfo [counter1*4+3]) matchFind = 1;
                if (matchFind == 0){
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTargetHoldInfo [counter1*4], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTargetHoldInfo [counter1*4+1], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTargetHoldInfo [counter1*4+2], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = lineNumberNew, targetHoldTempCount++;
                    lineNumberNew++;
                }
            }
            
            targetHoldInfoCount = 0;
            for (int counter1 = 0; counter1 < targetHoldTempCount; counter1++) arrayTargetHoldInfo [targetHoldInfoCount] = arrayTargetHoldTemp [counter1], targetHoldInfoCount++;
            delete [] arrayTargetHoldTemp;
            
            delete [] arrayRemoveLines;
            
            //-----Connect Line Data-----
            //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
            //	cout<<" arrayPositionRevise "<<counterA+1<<endl;
            //}
            
            arrayTargetHoldTemp = new int [positionReviseCount+100];
            targetHoldTempCount = 0;
            
            int matchFind2 = 0;
            
            for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                matchFind = 0;
                matchFind2 = 0;
                
                for (int counter2 = 0; counter2 < removeConnectNumbersCount; counter2++){
                    if (arrayRemoveConnectNumbers [counter2] == arrayPositionRevise [counter1*7+3]){
                        matchFind = 1;
                        break;
                    }
                }
                
                for (int counter2 = 0; counter2 < originalConnectNumbersCount; counter2++){
                    if (arrayOriginalConnectNumbers [counter2] == arrayPositionRevise [counter1*7+3]){
                        matchFind2 = 1;
                        break;
                    }
                }
                
                if (matchFind == 0 && matchFind2 == 0){
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayPositionRevise [counter1*7], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayPositionRevise [counter1*7+1], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayPositionRevise [counter1*7+2], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayPositionRevise [counter1*7+3], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayPositionRevise [counter1*7+4], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayPositionRevise [counter1*7+5], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayPositionRevise [counter1*7+6], targetHoldTempCount++;
                }
                if (matchFind == 0 && matchFind2 == 1){
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayPositionRevise [counter1*7], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayPositionRevise [counter1*7+1], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayPositionRevise [counter1*7+2], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayPositionRevise [counter1*7+3], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayPositionRevise [counter1*7+4], targetHoldTempCount++;
                    
                    if (arrayPositionRevise [counter1*7+5] == 2) arrayTargetHoldTemp [targetHoldTempCount] = 0, targetHoldTempCount++;
                    else if (arrayPositionRevise [counter1*7+5] == 3) arrayTargetHoldTemp [targetHoldTempCount] = 1, targetHoldTempCount++;
                    
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayPositionRevise [counter1*7+6], targetHoldTempCount++;
                }
                if (matchFind == 1 && matchFind2 == 0){
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayPositionRevise [counter1*7], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayPositionRevise [counter1*7+1], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayPositionRevise [counter1*7+2], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayPositionRevise [counter1*7+3], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = 0, targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = 2, targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = 0, targetHoldTempCount++;
                }
            }
            
            positionReviseCount = 0;
            
            for (int counter1 = 0; counter1 < targetHoldTempCount; counter1++) arrayPositionRevise [positionReviseCount] = arrayTargetHoldTemp [counter1], positionReviseCount++;
            delete [] arrayTargetHoldTemp;
            
            //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
            //	cout<<" arrayPositionRevise "<<counterA+1<<endl;
            //}
            
            //-----Connect Line Status-----
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //	cout<<" arrayTimeSelected "<<counterA+1<<endl;
            // }
            
            arrayTargetHoldTemp = new int [timeSelectedCount+100];
            targetHoldTempCount = 0;
            
            int findFlag = 0;
            
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                matchFind = 0;
                matchFind2 = 0;
                
                for (int counter2 = 0; counter2 < removeConnectNumbersCount; counter2++){
                    if (arrayRemoveConnectNumbers [counter2] == counter1+1){
                        matchFind = 1;
                        break;
                    }
                }
                
                for (int counter2 = 0; counter2 < originalConnectNumbersCount; counter2++){
                    if (arrayOriginalConnectNumbers [counter2] == counter1+1){
                        matchFind2 = 1;
                        break;
                    }
                }
                
                if (matchFind == 0 && matchFind2 == 0){
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10], targetHoldTempCount++;
                    
                    if (arrayTimeSelected [counter1*10+1] != 0){
                        findFlag = 0;
                        
                        for (int counter2 = 0; counter2 < missMatchLineCount/2; counter2++){
                            if (arrayTimeSelected [counter1*10+1] == arrayMissMatchLine [counter2*2]){
                                arrayTargetHoldTemp [targetHoldTempCount] = arrayMissMatchLine [counter2*2+1], targetHoldTempCount++;
                                findFlag = 1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0) arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+1], targetHoldTempCount++;
                    }
                    else arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+1], targetHoldTempCount++;
                    
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+2], targetHoldTempCount++;
                    
                    if (arrayTimeSelected [counter1*10+3] != 0){
                        findFlag = 0;
                        
                        for (int counter2 = 0; counter2 < missMatchLineCount/2; counter2++){
                            if (arrayTimeSelected [counter1*10+3] == arrayMissMatchLine [counter2*2]){
                                arrayTargetHoldTemp [targetHoldTempCount] = arrayMissMatchLine [counter2*2+1], targetHoldTempCount++;
                                findFlag = 1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0) arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+3], targetHoldTempCount++;
                    }
                    else arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+3], targetHoldTempCount++;
                    
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+4], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+5], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+6], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+7], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+8], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+9], targetHoldTempCount++;
                }
                
                if (matchFind == 0 && matchFind2 == 1){
                    if (arrayTimeSelected [counter1*10] == 3) arrayTargetHoldTemp [targetHoldTempCount] = 0, targetHoldTempCount++;
                    else if (arrayTimeSelected [counter1*10] == 4) arrayTargetHoldTemp [targetHoldTempCount] = 1, targetHoldTempCount++;
                    
                    if (arrayTimeSelected [counter1*10+1] != 0){
                        findFlag = 0;
                        
                        for (int counter2 = 0; counter2 < missMatchLineCount/2; counter2++){
                            if (arrayTimeSelected [counter1*10+1] == arrayMissMatchLine [counter2*2]){
                                arrayTargetHoldTemp [targetHoldTempCount] = arrayMissMatchLine [counter2*2+1], targetHoldTempCount++;
                                findFlag = 1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0) arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+1], targetHoldTempCount++;
                    }
                    else arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+1], targetHoldTempCount++;
                    
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+2], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = 0, targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+4], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+5], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+6], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+7], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+8], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+9], targetHoldTempCount++;
                }
                
                if (matchFind == 1 && matchFind2 == 0){
                    arrayTargetHoldTemp [targetHoldTempCount] = 3, targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = 0, targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+2], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = 0, targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+4], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+5], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+6], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+7], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+8], targetHoldTempCount++;
                    arrayTargetHoldTemp [targetHoldTempCount] = arrayTimeSelected [counter1*10+9], targetHoldTempCount++;
                }
            }
            
            timeSelectedCount = 0;
            for (int counter1 = 0; counter1 < targetHoldTempCount; counter1++) arrayTimeSelected [timeSelectedCount] = arrayTargetHoldTemp [counter1], timeSelectedCount++;
            delete [] arrayTargetHoldTemp;
            
            delete [] arrayMissMatchLine;
            
            //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
            //	cout<<" arrayPositionRevise "<<counterA+1<<endl;
            //}
            
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //    cout<<" arrayTimeSelected "<<counterA+1<<endl;
            //}
            
            if (trackingOn == 3){
                string cellLineageExtract = cellLineageNoHold.substr(1);
                string cellNumberExtract = cellNoHold.substr(1);
                int cellLineageExtractInt = atoi(cellLineageExtract.c_str());
                int cellNumberExtractInt = atoi(cellNumberExtract.c_str());
                
                for (int counter1 = 0; counter1 < originalConnectNumbersCount; counter1++){
                    for (int counter2 = arrayTimeSelected [(arrayOriginalConnectNumbers [counter1]-1)*10+2]; counter2 < positionReviseCount/7; counter2++){
                        if (arrayPositionRevise [counter2*7+3] == arrayOriginalConnectNumbers [counter1]){
                            arrayPositionRevise [counter2*7+4] = cellNumberExtractInt;
                            arrayPositionRevise [counter2*7+6] = cellLineageExtractInt;
                        }
                        else{
                            
                            break;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
                    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
                    //	cout<<" arrayPositionRevise "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
                    //    cout<<" arrayConnectLineageRel "<<counterA+1<<" "<<counter1<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < connectLineageRelCount/6; counter2++){
                        if (arrayConnectLineageRel [counter2*6] == cellLineageExtractInt && arrayConnectLineageRel [counter2*6+3] == cellNumberExtractInt) arrayConnectLineageRel [counter2*6+1] = arrayOriginalConnectNumbers [counter1];
                    }
                }
                
                for (int counter1 = 0; counter1 < removeConnectNumbersCount; counter1++){
                    for (int counter2 = arrayTimeSelected [(arrayRemoveConnectNumbers [counter1]-1)*10+2]; counter2 < positionReviseCount/7; counter2++){
                        if (arrayPositionRevise [counter2*7+3] == arrayTimeSelected [(arrayRemoveConnectNumbers [counter1]-1)*10+2]){
                            arrayPositionRevise [counter2*7+4] = 0;
                            arrayPositionRevise [counter2*7+6] = 0;
                        }
                        else{
                            
                            break;
                        }
                    }
                }
                
                if (targetHoldCount != 0 || (targetHoldCount == 0 && cutBase == 1)){
                    //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
                    //	cout<<" arrayGravityCenterRev "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < lineageGRCurrentCount/4; counterA++){
                    //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrent [counterA*4+counterB];
                    //	cout<<" arrayLineageGRCurrent "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < lineageGRCurrentCount/4; counter1++){
                        if (arrayLineageGRCurrent [counter1*4] == imageNumberTrackForDisplay) arrayLineageGRCurrent [counter1*4] = 0;
                    }
                    
                    int vectorNumber4 = arrayOriginalConnectNumbers [originalConnectNumbersCount-1];
                    
                    arrayLineageGRCurrent [lineageGRCurrentCount] = imageNumberTrackForDisplay, lineageGRCurrentCount++;
                    arrayLineageGRCurrent [lineageGRCurrentCount] = arrayGravityCenterRev [(vectorNumber4-1)*6], lineageGRCurrentCount++;
                    arrayLineageGRCurrent [lineageGRCurrentCount] = arrayGravityCenterRev [(vectorNumber4-1)*6+1], lineageGRCurrentCount++;
                    arrayLineageGRCurrent [lineageGRCurrentCount] = cellNumberExtractInt, lineageGRCurrentCount++;
                    
                    //for (int counterA = 0; counterA < lineageGRCurrentCount/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrent [counterA*4+counterB];
                    //    cout<<" arrayLineageGRCurrent "<<counterA<<endl;
                    //}
                    
                    gravityCenterXHold1 = arrayGravityCenterRev [(vectorNumber4-1)*6];
                    gravityCenterYHold1 = arrayGravityCenterRev [(vectorNumber4-1)*6+1];
                    gravityAverageHold1 = arrayGravityCenterRev [(vectorNumber4-1)*6+3];
                    gravityCellNo1 = 0;
                    gravityCenterXHold2 = 0;
                    gravityCenterYHold2 = 0;
                    gravityAverageHold2 = 0;
                    gravityCellNo2 = 0;
                    gravityCenterXHold3 = 0;
                    gravityCenterYHold3 = 0;
                    gravityAverageHold3 = 0;
                    gravityCellNo3 = 0;
                    gravityCenterXHold4 = 0;
                    gravityCenterYHold4 = 0;
                    gravityAverageHold4 = 0;
                    gravityCellNo4 = 0;
                }
                
                if (targetHoldCount == 0 && cutBase == 0){
                    //for (int counterA = 0; counterA < lineageGRCurrentCount/4; counterA++){
                    //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrent [counterA*4+counterB];
                    //	cout<<" arrayLineageGRCurrent "<<counterA<<endl;
                    //}
                    
                    int *arrayLineageGRCurrentTemp = new int [lineageGRCurrentCount+50];
                    int lineageGRCurrentTemp = 0;
                    
                    for (int counter1 = 0; counter1 < lineageGRCurrentCount/4; counter1++){
                        if (arrayLineageGRCurrent [counter1*4] != imageNumberTrackForDisplay){
                            arrayLineageGRCurrentTemp [lineageGRCurrentTemp] = arrayLineageGRCurrent [counter1*4], lineageGRCurrentTemp++;
                            arrayLineageGRCurrentTemp [lineageGRCurrentTemp] = arrayLineageGRCurrent [counter1*4+1], lineageGRCurrentTemp++;
                            arrayLineageGRCurrentTemp [lineageGRCurrentTemp] = arrayLineageGRCurrent [counter1*4+2], lineageGRCurrentTemp++;
                            arrayLineageGRCurrentTemp [lineageGRCurrentTemp] = arrayLineageGRCurrent [counter1*4+3], lineageGRCurrentTemp++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageGRCurrentTemp/4; counterA++){
                    //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrentTemp [counterA*4+counterB];
                    //	cout<<" arrayLineageGRCurrentTemp "<<counterA<<endl;
                    //}
                    
                    lineageGRCurrentCount = 0;
                    
                    for (int counter1 = 0; counter1 < lineageGRCurrentTemp; counter1++) arrayLineageGRCurrent [lineageGRCurrentCount] = arrayLineageGRCurrentTemp [counter1], lineageGRCurrentCount++;
                    
                    //for (int counterA = 0; counterA < lineageGRCurrentCount/4; counterA++){
                    //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrent [counterA*4+counterB];
                    //	cout<<" arrayLineageGRCurrent "<<counterA<<endl;
                    //}
                    
                    delete [] arrayLineageGRCurrentTemp;
                    
                    string extension = to_string(imageNumberTrackForDisplay);
                    
                    if (extension.length() == 1) extension = "000"+extension;
                    else if (extension.length() == 2) extension = "00"+extension;
                    else if (extension.length() == 3) extension = "0"+extension;
                    
                    string connectStatusTempPath1 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ConnectLineageRelTemp";
                    string connectStatusTempPath3 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_MasterDataTemp";
                    string connectStatusTempPath4 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_RevisedTempMap";
                    string connectStatusTempPath5 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_StatusTemp";
                    string connectStatusTempPath6 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_GCCenterInfo";
                    
                    remove (connectStatusTempPath1.c_str());
                    remove (connectStatusTempPath3.c_str());
                    remove (connectStatusTempPath4.c_str());
                    remove (connectStatusTempPath5.c_str());
                    remove (connectStatusTempPath6.c_str());
                }
            }
            
            //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
            //	cout<<" arrayPositionRevise "<<counterA+1<<endl;
            //}
            
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //	cout<<" arrayTimeSelected "<<counterA+1<<endl;
            //}
            
            //-----Map UpDate-----
            for (int counterY = 0; counterY < imageDimension; counterY++){
                for (int counterX = 0; counterX < imageDimension; counterX++){
                    if (revisedWorkingMap [counterY][counterX] != 0){
                        for (int counter1 = 0; counter1 < removeConnectNumbersCount; counter1++){
                            if (revisedWorkingMap [counterY][counterX] == arrayRemoveConnectNumbers [counter1]) revisedWorkingMap [counterY][counterX] = 0;
                        }
                    }
                }
            }
            
            delete [] arrayRemoveConnectNumbers;
            
            int maxPointDimX = 0;
            int maxPointDimY = 0;
            int minPointDimX = 1000000;
            int minPointDimY = 1000000;
            int connectLineDataCount = 0;
            int horizontalLength = 0;
            int verticalLength = 0;
            int dimension = 0;
            int horizontalStart = 0;
            int verticalStart = 0;
            int connectivityNumber = 0;
            int connectAnalysisCount = 0;
            int connectAnalysisTempCount = 0;
            int xSource = 0;
            int ySource = 0;
            
            for (int counter1 = 0; counter1 < originalConnectNumbersCount; counter1++){
                int *connectLineData = new int [positionReviseCount+50];
                connectLineDataCount = 0;
                
                for (int counter2 = 0; counter2 < positionReviseCount/7; counter2++){
                    if (arrayPositionRevise [counter2*7+3] == arrayOriginalConnectNumbers [counter1]){
                        connectLineData [connectLineDataCount] = arrayPositionRevise [counter2*7], connectLineDataCount++;
                        connectLineData [connectLineDataCount] = arrayPositionRevise [counter2*7+1], connectLineDataCount++;
                        connectLineData [connectLineDataCount] = arrayPositionRevise [counter2*7+2], connectLineDataCount++;
                        connectLineData [connectLineDataCount] = arrayPositionRevise [counter2*7+3], connectLineDataCount++;
                        connectLineData [connectLineDataCount] = arrayPositionRevise [counter2*7+4], connectLineDataCount++;
                        connectLineData [connectLineDataCount] = arrayPositionRevise [counter2*7+5], connectLineDataCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < connectLineDataCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<connectLineData [counterA*6+counterB];
                //	cout<<" connectLineData "<<counterA<<endl;
                //}
                
                maxPointDimX = 0;
                maxPointDimY = 0;
                minPointDimX = 1000000;
                minPointDimY = 1000000;
                
                for (int counter2 = 0; counter2 < connectLineDataCount/6; counter2++){
                    if (maxPointDimX < connectLineData [counter2*6]) maxPointDimX = connectLineData [counter2*6];
                    if (minPointDimX > connectLineData [counter2*6]) minPointDimX = connectLineData [counter2*6];
                    if (maxPointDimY < connectLineData [counter2*6+1]) maxPointDimY = connectLineData [counter2*6+1];
                    if (minPointDimY > connectLineData [counter2*6+1]) minPointDimY = connectLineData [counter2*6+1];
                }
                
                //-----Determine the dimension of cell-----
                horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                verticalLength = (maxPointDimY-minPointDimY)/2*2;
                dimension = 0;
                
                if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
                if (horizontalLength < verticalLength) dimension = verticalLength+30;
                
                dimension = (dimension/2)*2;
                
                horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
                verticalStart = minPointDimY-(dimension-verticalLength)/2;
                
                //cout<<horizontalStart<<" "<<verticalStart<<" "<<dimension<<" hol-ver-dim"<<endl;
                
                int **connectivityMapTemp = new int *[dimension+1];
                for (int counter2 = 0; counter2 < dimension+1; counter2++) connectivityMapTemp [counter2] = new int [dimension+1];
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = 0;
                }
                
                for (int counter2 = 0; counter2 < connectLineDataCount/6; counter2++){
                    connectivityMapTemp [connectLineData [counter2*6+1]-verticalStart][connectLineData [counter2*6]-horizontalStart] = 1;
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
                //	cout<<" connectivityMapTemp "<<counterA<<endl;
                //}
                
                delete [] connectLineData;
                
                //-----Fill inside-----
                int *connectAnalysisX = new int [dimension*4];
                int *connectAnalysisY = new int [dimension*4];
                int *connectAnalysisTempX = new int [dimension*4];
                int *connectAnalysisTempY = new int [dimension*4];
                
                connectivityNumber = -3;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapTemp [counterY][counterX] == 0){
                            connectivityNumber = connectivityNumber+2;
                            connectAnalysisCount = 0;
                            
                            if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMapTemp [counterY][counterX] = connectivityNumber;
                            
                            if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == 0){
                                connectivityMapTemp [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == 0){
                                connectivityMapTemp [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == 0){
                                connectivityMapTemp [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == 0){
                                connectivityMapTemp [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                        
                                        if (ySource-1 >= 0 && connectivityMapTemp [ySource-1][xSource] == 0){
                                            connectivityMapTemp [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension && connectivityMapTemp [ySource][xSource+1] == 0){
                                            connectivityMapTemp [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && connectivityMapTemp [ySource+1][xSource] == 0){
                                            connectivityMapTemp [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && connectivityMapTemp [ySource][xSource-1] == 0){
                                            connectivityMapTemp [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                delete [] connectAnalysisX;
                delete [] connectAnalysisY;
                delete [] connectAnalysisTempX;
                delete [] connectAnalysisTempY;
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
                //	cout<<" connectivityMapTemp "<<counterA<<endl;
                //}
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapTemp [counterY][counterX] == -1) connectivityMapTemp [counterY][counterX] = 0;
                    }
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMapTemp [counterY][counterX] != 0) revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] = arrayOriginalConnectNumbers [counter1];
                    }
                }
                
                //for (int counterA = 0; counterA < imageDimension; counterA++){
                //	for (int counterB = 0; counterB < 150; counterB++) cout<<" "<<revisedWorkingMap [counterA][counterB];
                //	cout<<" revisedWorkingMap "<<counterA<<endl;
                //}
                
                for (int counter2 = 0; counter2 < dimension+1; counter2++) delete [] connectivityMapTemp [counter2];
                delete [] connectivityMapTemp;
            }
            
            delete [] arrayOriginalConnectNumbers;
            
            if (trackingOn == 2){
                tableDataSetDone = 1;
                trackingTableSetDone = 0;
                tableTrackingProcessing = 0;
            }
            if (trackingOn == 3){
                tableTrackingProcessing = 1;
                tableDataSetDone = 0;
                trackingTableSetDone = 0;
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            verificationPositionCall = 0;
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (trackingOn == 3 && listSwitchCall == 2 && tableRowHold == 0){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Base Line Removal Denied"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)displaySynchro:(id)sender{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        if (trackingOn != 0 || timeOneStatus == 2){
            synchroOn = 1;
            verificationPositionCall = 0;
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)reviseLineDone:(id)sender{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        dataSaveRead = [[DataSaveRead alloc] init];
        [dataSaveRead reviseLineClear];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)displayListSwitch:(id)sender{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        if (listDisplaySelection == 0){
            listDisplaySelection = 1;
            [patternTypeDisplay setStringValue: @"Mitosis"];
        }
        else if (listDisplaySelection == 1){
            listDisplaySelection = 2;
            [patternTypeDisplay setStringValue: @"Lineage"];
        }
        else if (listDisplaySelection == 2){
            listDisplaySelection = 0;
            [patternTypeDisplay setStringValue: @"Cell"];
        }
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToListWindow object:self];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)shotTake:(id)sender{
    int saveType = 0;
    int saveImageNo = 0;
    int saveLingNo = 0;
    int saveCellNo = 0;
    
    snapShot = [[SnapShot alloc] init];
    [snapShot snapShotMain:saveType:saveImageNo:saveLingNo:saveCellNo];
}

-(IBAction)shotDelete:(id)sender{
    if (listDisplaySelection == 1){
        string mitosisPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/"+"Mitosis.dat";
        long sizeForCopy = 0;
        
        struct stat sizeOfFile;
        
        if (stat(mitosisPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            ifstream fin;
            
            int *arrayCellListDisplayTemp = new int [sizeForCopy+50];
            int cellListDisplayTempCount = 0;
            
            fin.open(mitosisPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                fin.close();
                
                unsigned long readPosition = 0;
                int stepCount = 0;
                int finData [8];
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++;
                        finData [1] = uploadTemp [readPosition], readPosition++; //--2. Entry No
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--5. X Position
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++; //--8. Y Position
                        finData [6] = uploadTemp [readPosition], readPosition++;
                        finData [7] = uploadTemp [readPosition], readPosition++; //--10. Area
                        
                        finData [1] = finData [0]*256+finData [1];
                        finData [3] = finData [2]*256+finData [3];
                        finData [5] = finData [4]*256+finData [5];
                        finData [7] = finData [6]*256+finData [7];
                        
                        if (finData [1] == 0 && finData [3] == 0) stepCount = 3;
                        else{
                            
                            arrayCellListDisplayTemp [cellListDisplayTempCount] = finData [1], cellListDisplayTempCount++;
                            arrayCellListDisplayTemp [cellListDisplayTempCount] = finData [3], cellListDisplayTempCount++;
                            arrayCellListDisplayTemp [cellListDisplayTempCount] = finData [5], cellListDisplayTempCount++;
                            arrayCellListDisplayTemp [cellListDisplayTempCount] = finData [7], cellListDisplayTempCount++;
                        }
                    }
                    
                } while (stepCount != 3);
                
                delete [] uploadTemp;
            }
            
            int maxEntry = 0;
            
            for (int counter1 = 0; counter1 < cellListDisplayTempCount/4; counter1++){
                if (arrayCellListDisplayTemp [counter1*4] > maxEntry){
                    maxEntry = arrayCellListDisplayTemp [counter1*4];
                    
                    if (maxEntry >= 2){
                        break;
                    }
                }
            }
            
            if (maxEntry >= 2){
                int *arrayCellListDisplayTemp2 = new int [cellListDisplayTempCount+50];
                int cellListDisplayTempCount2 = 0;
                
                int sequentialNumber = 0;
                int sequentialPosition = 0;
                
                for (int counter1 = 0; counter1 < cellListDisplayTempCount/4; counter1++){
                    if (arrayCellListDisplayTemp [counter1*4] != boxImageNumber){
                        if (sequentialNumber != arrayCellListDisplayTemp [counter1*4]){
                            sequentialNumber = arrayCellListDisplayTemp [counter1*4];
                            sequentialPosition++;
                        }
                        
                        arrayCellListDisplayTemp2 [cellListDisplayTempCount2] = sequentialPosition, cellListDisplayTempCount2++;
                        arrayCellListDisplayTemp2 [cellListDisplayTempCount2] = arrayCellListDisplayTemp [counter1*4+1], cellListDisplayTempCount2++;
                        arrayCellListDisplayTemp2 [cellListDisplayTempCount2] = arrayCellListDisplayTemp [counter1*4+2], cellListDisplayTempCount2++;
                        arrayCellListDisplayTemp2 [cellListDisplayTempCount2] = arrayCellListDisplayTemp [counter1*4+3], cellListDisplayTempCount2++;
                    }
                }
                
                char *writingArray = new char [cellListDisplayTempCount2*2+20];
                
                unsigned long indexCount = 0;
                int readBit [3];
                int dataTemp = 0;
                
                for (int counter1 = 0; counter1 < cellListDisplayTempCount2/4; counter1++){
                    dataTemp = arrayCellListDisplayTemp2 [counter1*4];
                    readBit [0] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [1] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    
                    dataTemp = arrayCellListDisplayTemp2 [counter1*4+1];
                    readBit [0] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [1] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    
                    dataTemp = arrayCellListDisplayTemp2 [counter1*4+2];
                    readBit [0] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [1] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    
                    dataTemp = arrayCellListDisplayTemp2 [counter1*4+3];
                    readBit [0] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [1] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                }
                
                for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                
                ofstream outfile2 (mitosisPath.c_str(), ofstream::binary);
                outfile2.write ((char*) writingArray, indexCount);
                outfile2.close();
                
                delete [] writingArray;
                delete [] arrayCellListDisplayTemp2;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToListWindow object:self];
            }
            
            delete [] arrayCellListDisplayTemp;
            
            //for (int counterA = 0; counterA < cellListDisplayTempCount/3; counterA++){
            //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayCellListDisplayTemp [counterA*3+counterB];
            //	cout<<" arrayCellListDisplayTemp "<<counterA<<endl;
            //}
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"File Read Error"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)characterDisplaySet:(id)sender{
    if (trackingOn != 0){
        if (characterDisplayFlag == 0 || characterDisplayFlag == 1){
            characterDisplayFlag = 2;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (characterDisplayFlag == 2){
            characterDisplayFlag = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)characterDisplayNavSet:(id)sender{
    if (trackingOn != 0){
        if (characterDisplayNavFlag == 0 || characterDisplayNavFlag == 1){
            characterDisplayNavFlag = 2;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (characterDisplayNavFlag == 2){
            characterDisplayNavFlag = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)deleteProgenies:(id)sender{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        progressTiming = 9;
        
        [self deleteProgeniesMain];
        
        progressTiming = 11;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)deleteProgeniesMain{
    if (timeOneStatus == 0 && trackingOn == 3 && firstModificationPoint != 10000){
        string cellLineageExtract = cellLineageNoHold.substr(1);
        string cellNoExtract = cellNoHold.substr(1);
        int lineageAmendTemp = atoi(cellLineageExtract.c_str());
        int cellAmendTemp = atoi(cellNoExtract.c_str());
        int lastEventTypeDiv = 0;
        int lastEventTypeOther = 0;
        int imagePositionEvent = 0;
        int imagePositionDivEvent = 0;
        
        //for (int counterA = 0; counterA < cellNumberInfoCount/7; counterA++){
        //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayCellNumberInfo [counterA*7+counterB];
        //    cout<<" arrayCellNumberInfo "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
        //    cout<<" arrayLineageData "<<counterA<<endl;
        //}
        
        for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
            if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp && arrayLineageStartEnd [counter1*8+1] == cellAmendTemp){
                for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                    if (arrayLineageData [counter2*8+3] == 32 || arrayLineageData [counter2*8+3] == 42 || arrayLineageData [counter2*8+3] == 52){
                        lastEventTypeDiv = 1;
                    }
                    
                    if (arrayLineageData [counter2*8+3] == 91 || arrayLineageData [counter2*8+3] == 7 || arrayLineageData [counter2*8+3] == 8){
                        lastEventTypeOther = 1;
                    }
                    
                    if (arrayLineageData [counter2*8+2] == imageNumberTrackForDisplay){
                        imagePositionEvent = arrayLineageData [counter2*8+3];
                    }
                    
                    if (arrayLineageData [counter2*8+2] == imageNumberTrackForDisplay-1){
                        imagePositionDivEvent = arrayLineageData [counter2*8+3];
                    }
                }
            }
        }
        
        if (imagePositionEvent == 1 || imagePositionEvent == 31 || imagePositionEvent == 32 || imagePositionEvent == 41 || imagePositionEvent == 42 || imagePositionEvent == 51 || imagePositionEvent == 52 || imagePositionEvent == 91){
            lastEventTypeOther = 0;
        }
        
        if (imagePositionDivEvent == 32 || imagePositionDivEvent == 42 || imagePositionDivEvent == 52){
            lastEventTypeDiv = 0;
        }
        
        int recordType = 2;
        trackRecord = [[TrackRecord alloc] init];
        int returnResults = [trackRecord trackDataSaveMain:recordType];
        
        //cout<<lastEventTypeOther<<" "<<returnResults <<" "<<imagePositionEvent <<" "<<imageNumberTrackForDisplay<<" "<<imagePositionDivEvent<<" Info"<<endl;
        
        if (returnResults == 1 || returnResults == 20 || (returnResults == 30 && (lastEventTypeOther == 1 || lastEventTypeDiv == 1))){
            int deleteFail = 1;
            
            if (lastEventTypeDiv == 1){
                arrayLineageExtraction = new int [10000];
                lineageExtractionCount = 0;
                lineageExtractionLimit = 10000;
                
                //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
                //    cout<<" arrayLineageData "<<counterA<<endl;
                //}
                
                int numberOfFirstPoint = 0;
                
                for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                    if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp){
                        for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                            if (lineageExtractionCount+8 > lineageExtractionLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate lineageExtractionUpDate];
                            }
                            
                            arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8], lineageExtractionCount++;
                            arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+1], lineageExtractionCount++;
                            arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+2], lineageExtractionCount++;
                            arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+3], lineageExtractionCount++;
                            arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+4], lineageExtractionCount++;
                            arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+5], lineageExtractionCount++;
                            arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+6], lineageExtractionCount++;
                            arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+7], lineageExtractionCount++;
                            
                            if (arrayLineageData [counter2*8+3] == 1 || arrayLineageData [counter2*8+3] == 31 || arrayLineageData [counter2*8+3] == 41 || arrayLineageData [counter2*8+3] == 51) numberOfFirstPoint++;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < lineageExtractionCount/8; counterA++){
                //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtraction [counterA*8+counterB];
                //    cout<<" arrayLineageExtraction "<<counterA<<endl;
                //}
                
                if (returnResults == 20){
                    for (int counter1 = 0; counter1 < lineageExtractionCount/8; counter1++){
                        if (arrayLineageExtraction [counter1*8+4] == cellAmendTemp && arrayLineageExtraction [counter1*8+3] == 6){
                            arrayLineageExtraction [counter1*8+3] = 2;
                        }
                    }
                }
                
                int *cellNumberDeleteHold = new int [numberOfFirstPoint+50];
                int cellNumberDeleteHoldCount = 0;
                int lineageLimitCheck = 0;
                
                for (int counter1 = 0; counter1 < lineageExtractionCount/8; counter1++){
                    if (arrayLineageExtraction [counter1*8+4] == cellAmendTemp && (arrayLineageExtraction [counter1*8+3] == 31 || arrayLineageExtraction [counter1*8+3] == 41 || arrayLineageExtraction [counter1*8+3] == 51)){
                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = arrayLineageExtraction [counter1*8+5], cellNumberDeleteHoldCount++;
                        
                        if (arrayLineageExtraction [counter1*8+5] == 0 && arrayLineageExtraction [counter1*8+4] != 0) lineageLimitCheck = 1;
                    }
                }
                
                if (cellNumberDeleteHoldCount != 0 && lineageLimitCheck == 0){
                    int terminationFlag = 0;
                    int deleteCellNo = 0;
                    int processType = 0;
                    int dummy = 0;
                    
                    do {
                        
                        terminationFlag = 0;
                        
                        if (cellNumberDeleteHoldCount != 0){
                            deleteCellNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-1];
                            cellNumberDeleteHold [cellNumberDeleteHoldCount-1] = 0;
                            cellNumberDeleteHoldCount = cellNumberDeleteHoldCount-1;
                            
                            for (int counter1 = 0; counter1 < lineageExtractionCount/8; counter1++){
                                if (arrayLineageExtraction [counter1*8+4] == deleteCellNo && (arrayLineageExtraction [counter1*8+3] == 31 || arrayLineageExtraction [counter1*8+3] == 41 || arrayLineageExtraction [counter1*8+3] == 51)){
                                    cellNumberDeleteHold [cellNumberDeleteHoldCount] = arrayLineageExtraction [counter1*8+5], cellNumberDeleteHoldCount++;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < cellNumberDeleteHoldCount; counterA++){
                            //    for (int counterB = 0; counterB < 1; counterB++) cout<<" "<<cellNumberDeleteHold [counterA*1+counterB];
                            //    cout<<" cellNumberDeleteHold "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < lineageExtractionCount/8; counterA++){
                            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtraction [counterA*8+counterB];
                            //    cout<<" arrayLineageExtraction "<<counterA<<endl;
                            //}
                            
                            processType = 2;
                            dummy = 0;
                            
                            addDelete = [[AddDelete alloc] init];
                            deleteFail = [addDelete delLineageMain:lineageAmendTemp:processType:deleteCellNo:dummy];
                            
                            if (deleteFail == 0){
                                usleep (50000);
                                
                                addDelete = [[AddDelete alloc] init];
                                deleteFail = [addDelete delLineageMain:lineageAmendTemp:processType:deleteCellNo:dummy];
                                
                                if (deleteFail == 0){
                                    usleep (50000);
                                    
                                    addDelete = [[AddDelete alloc] init];
                                    deleteFail = [addDelete delLineageMain:lineageAmendTemp:processType:deleteCellNo:dummy];
                                }
                            }
                            
                            //for (int counterA = 0; counterA < lineageExtractionCount/8; counterA++){
                            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtraction [counterA*8+counterB];
                            //    cout<<" arrayLineageExtraction "<<counterA<<endl;
                            //}
                        }
                        else terminationFlag = 1;
                        
                    } while (terminationFlag == 0);
                }
                else{ //-----for deletion of BD after cell number reaching max-----
                    
                    int *arrayLineageExtraction3 = new int [lineageExtractionCount+50];
                    int lineageExtractionCount3 = 0;
                    
                    for (int counter1 = 0; counter1 < lineageExtractionCount/8; counter1++){
                        if (arrayLineageExtraction [counter1*8+4] != cellAmendTemp){
                            arrayLineageExtraction3 [lineageExtractionCount3] = arrayLineageExtraction [counter1*8], lineageExtractionCount3++;
                            arrayLineageExtraction3 [lineageExtractionCount3] = arrayLineageExtraction [counter1*8+1], lineageExtractionCount3++;
                            arrayLineageExtraction3 [lineageExtractionCount3] = arrayLineageExtraction [counter1*8+2], lineageExtractionCount3++;
                            arrayLineageExtraction3 [lineageExtractionCount3] = arrayLineageExtraction [counter1*8+3], lineageExtractionCount3++;
                            arrayLineageExtraction3 [lineageExtractionCount3] = arrayLineageExtraction [counter1*8+4], lineageExtractionCount3++;
                            arrayLineageExtraction3 [lineageExtractionCount3] = arrayLineageExtraction [counter1*8+5], lineageExtractionCount3++;
                            arrayLineageExtraction3 [lineageExtractionCount3] = arrayLineageExtraction [counter1*8+6], lineageExtractionCount3++;
                            arrayLineageExtraction3 [lineageExtractionCount3] = arrayLineageExtraction [counter1*8+7], lineageExtractionCount3++;
                        }
                    }
                    
                    lineageExtractionCount = 0;
                    
                    for (int counter1 = 0; counter1 < lineageExtractionCount3; counter1++) arrayLineageExtraction [lineageExtractionCount] = arrayLineageExtraction3 [counter1], lineageExtractionCount++;
                    
                    delete [] arrayLineageExtraction3;
                }
                
                delete [] cellNumberDeleteHold;
                
                //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
                //    cout<<" arrayLineageData "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < cellNumberInfoCount/7; counterA++){
                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayCellNumberInfo [counterA*7+counterB];
                //    cout<<" arrayCellNumberInfo "<<counterA<<endl;
                //}
                
                if (deleteFail == 1){
                    //-----Lineage Data Reorganize, One cell form one block-----
                    int *arrayLineageExtraction2 = new int [lineageDataCount+50];
                    int lineageExtractionCount2 = 0;
                    
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] != lineageAmendTemp){
                            arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8], lineageExtractionCount2++;
                            arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+1], lineageExtractionCount2++;
                            arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+2], lineageExtractionCount2++;
                            arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+3], lineageExtractionCount2++;
                            arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+4], lineageExtractionCount2++;
                            arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+5], lineageExtractionCount2++;
                            arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+6], lineageExtractionCount2++;
                            arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+7], lineageExtractionCount2++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageExtractionCount/8; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtraction [counterA*8+counterB];
                    //    cout<<" arrayLineageExtraction "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < lineageExtractionCount/8; counter1++){
                        arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageExtraction [counter1*8], lineageExtractionCount2++;
                        arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageExtraction [counter1*8+1], lineageExtractionCount2++;
                        arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageExtraction [counter1*8+2], lineageExtractionCount2++;
                        arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageExtraction [counter1*8+3], lineageExtractionCount2++;
                        arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageExtraction [counter1*8+4], lineageExtractionCount2++;
                        arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageExtraction [counter1*8+5], lineageExtractionCount2++;
                        arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageExtraction [counter1*8+6], lineageExtractionCount2++;
                        arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageExtraction [counter1*8+7], lineageExtractionCount2++;
                    }
                    
                    if (lineageDataStatus == 1) delete [] arrayLineageData;
                    arrayLineageData = new int [lineageExtractionCount2+500];
                    lineageDataCount = 0;
                    lineageDataLimit = lineageExtractionCount2+500;
                    lineageDataStatus = 1;
                    
                    for (int counter1 = 0; counter1 < lineageExtractionCount2; counter1++) arrayLineageData [lineageDataCount] = arrayLineageExtraction2 [counter1], lineageDataCount++;
                    
                    delete [] arrayLineageExtraction2;
                    
                    //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
                    //    cout<<" arrayLineageData "<<counterA<<endl;
                    //}
                    
                    lineageStartEndCount = 0;
                    int cellNumberStart = -1;
                    int lineageNumberStart = 0;
                    int firstEntryFind = 0;
                    
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if ((arrayLineageData [counter1*8+6] != lineageNumberStart || arrayLineageData [counter1*8+5] != cellNumberStart) && firstEntryFind == 0){
                            lineageNumberStart = arrayLineageData [counter1*8+6];
                            cellNumberStart = arrayLineageData [counter1*8+5];
                            
                            arrayLineageStartEnd [lineageStartEndCount] = lineageNumberStart, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = cellNumberStart, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8], lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+1], lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = counter1, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+2], lineageStartEndCount++;
                            
                            firstEntryFind = 1;
                        }
                        else if ((arrayLineageData [counter1*8+6] != lineageNumberStart || arrayLineageData [counter1*8+5] != cellNumberStart) && firstEntryFind == 1){
                            lineageNumberStart = arrayLineageData [counter1*8+6];
                            cellNumberStart = arrayLineageData [counter1*8+5];
                            
                            arrayLineageStartEnd [lineageStartEndCount] = counter1-1, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [(counter1-1)*8+2], lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = lineageNumberStart, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = cellNumberStart, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8], lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+1], lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = counter1, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+2], lineageStartEndCount++;
                        }
                        
                        if (counter1 == lineageDataCount/8-1){
                            arrayLineageStartEnd [lineageStartEndCount] = counter1, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+2], lineageStartEndCount++;
                        }
                        
                        if (lineageStartEndCount+24 > lineageStartEndLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate lineageStartEndUpDate];
                        }
                    }
                }
                
                delete [] arrayLineageExtraction;
            }
            
            //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
            //    cout<<" arrayLineageData "<<counterA<<endl;
            //}
            
            if (deleteFail == 1){
                int lineageEntryStart = 10000;
                int lineageEntryEnd = 0;
                int lineageEntryType = 0;
                int imagePositionMoveFlag = 0;
                
                for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                    if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp && arrayLineageStartEnd [counter1*8+1] == cellAmendTemp){
                        for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                            if (arrayLineageData [counter2*8+2] == imageNumberTrackForDisplay && (arrayLineageData [counter2*8+3] == 1 || arrayLineageData [counter2*8+3] == 31 || arrayLineageData [counter2*8+3] == 41 || arrayLineageData [counter2*8+3] == 51)){
                                imagePositionMoveFlag = 1;
                            }
                            
                            if (arrayLineageData [counter2*8+2] >= lineageEntryEnd){
                                lineageEntryEnd = arrayLineageData [counter2*8+2];
                                lineageEntryType = arrayLineageData [counter2*8+3];
                            }
                            
                            if (arrayLineageData [counter2*8+2] <= lineageEntryStart) lineageEntryStart = arrayLineageData [counter2*8+2];
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
                //    cout<<" arrayLineageData "<<counterA<<endl;
                //}
                
                int proceedingFlag = 0;
                int cutStartImage = 0;
                
                if (lineageEntryStart < lineageEntryEnd && lineageEntryEnd >= imageNumberTrackForDisplay){
                    if (imagePositionMoveFlag == 1){
                        if (lineageEntryEnd-lineageEntryStart == 1){
                            cutStartImage = lineageEntryEnd;
                            proceedingFlag = 1;
                        }
                        else if (lineageEntryEnd-lineageEntryStart >= 2){
                            cutStartImage = imageNumberTrackForDisplay+1;
                            proceedingFlag = 1;
                        }
                    }
                    else{
                        
                        if (lineageEntryEnd-lineageEntryStart == 1){
                            if (lineageEntryType != 91) cutStartImage = lineageEntryEnd+1;
                            else{
                                
                                cutStartImage = imageNumberTrackForDisplay;
                                proceedingFlag = 1;
                            }
                        }
                        else if (lineageEntryEnd-lineageEntryStart == 2){
                            if (lineageEntryStart+1 == imageNumberTrackForDisplay){
                                cutStartImage = imageNumberTrackForDisplay+1;
                                proceedingFlag = 1;
                            }
                            else if (lineageEntryStart+2 == imageNumberTrackForDisplay){
                                if (lineageEntryType == 91 || lineageEntryType == 32 || lineageEntryType == 42 || lineageEntryType == 52){
                                    cutStartImage = imageNumberTrackForDisplay;
                                    proceedingFlag = 1;
                                }
                                else cutStartImage = imageNumberTrackForDisplay+1;
                            }
                        }
                        else if (lineageEntryEnd-lineageEntryStart >= 3){
                            if (lineageEntryEnd != imageNumberTrackForDisplay+1 && lineageEntryEnd != imageNumberTrackForDisplay){
                                cutStartImage = imageNumberTrackForDisplay+1;
                                proceedingFlag = 1;
                            }
                            else if (lineageEntryEnd == imageNumberTrackForDisplay+1){
                                cutStartImage = imageNumberTrackForDisplay+1;
                                proceedingFlag = 1;
                            }
                            else if (lineageEntryEnd == imageNumberTrackForDisplay){
                                if (lineageEntryType == 91 || lineageEntryType == 32 || lineageEntryType == 42 || lineageEntryType == 52){
                                    cutStartImage = imageNumberTrackForDisplay;
                                    proceedingFlag = 1;
                                }
                                else cutStartImage = imageNumberTrackForDisplay+1;
                            }
                        }
                    }
                }
                else if (lineageEntryEnd < imageNumberTrackForDisplay) cutStartImage = lineageEntryEnd+1;
                else cutStartImage = lineageEntryStart+1;
                
                //cout<<cutStartImage<<" "<<proceedingFlag<<" CutTime"<<endl;
                
                if (proceedingFlag == 1){
                    arrayLineageExtraction = new int [10000];
                    lineageExtractionCount = 0;
                    lineageExtractionLimit = 10000;
                    
                    for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                        if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp){
                            for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                                if (lineageExtractionCount+8 > lineageExtractionLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate lineageExtractionUpDate];
                                }
                                
                                arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8], lineageExtractionCount++;
                                arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+1], lineageExtractionCount++;
                                arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+2], lineageExtractionCount++;
                                arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+3], lineageExtractionCount++;
                                arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+4], lineageExtractionCount++;
                                arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+5], lineageExtractionCount++;
                                arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+6], lineageExtractionCount++;
                                arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+7], lineageExtractionCount++;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageExtractionCount/8; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtraction [counterA*8+counterB];
                    //    cout<<" arrayLineageExtraction "<<counterA<<endl;
                    //}
                    
                    int processType = 3;
                    addDelete = [[AddDelete alloc] init];
                    deleteFail = [addDelete delLineageMain:lineageAmendTemp:processType:cellAmendTemp:cutStartImage];
                    
                    if (deleteFail == 0){
                        usleep (50000);
                        
                        addDelete = [[AddDelete alloc] init];
                        deleteFail = [addDelete delLineageMain:lineageAmendTemp:processType:cellAmendTemp:cutStartImage];
                        
                        if (deleteFail == 0){
                            usleep (50000);
                            
                            addDelete = [[AddDelete alloc] init];
                            deleteFail = [addDelete delLineageMain:lineageAmendTemp:processType:cellAmendTemp:cutStartImage];
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageExtractionCount/8; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtraction [counterA*8+counterB];
                    //    cout<<" arrayLineageExtraction "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < lineageExtractionTempCount/8; counterA++){
                    //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageExtractionTemp [counterA*8+counterB];
                    //	cout<<" lineageExtractionTemp "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
                    //    cout<<" arrayLineageData "<<counterA<<endl;
                    //}
                    
                    if (deleteFail == 1){
                        int *arrayLineageExtraction2 = new int [lineageExtractionCount+lineageDataCount+10000];
                        int lineageExtractionCount2 = 0;
                        
                        for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                            if (arrayLineageData [counter1*8+6] != lineageAmendTemp){
                                arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+1], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+2], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+3], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+4], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+5], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+6], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+7], lineageExtractionCount2++;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < lineageExtractionCount; counter1++) arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageExtraction [counter1], lineageExtractionCount2++;
                        
                        //for (int counterA = 0; counterA < lineageExtractionCount2/8; counterA++){
                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtraction2 [counterA*8+counterB];
                        //    cout<<" arrayLineageExtraction2 "<<counterA<<endl;
                        //}
                        
                        if (lineageDataStatus == 1) delete [] arrayLineageData;
                        arrayLineageData = new int [lineageExtractionCount2+500];
                        lineageDataCount = 0;
                        lineageDataLimit = lineageExtractionCount2+500;
                        lineageDataStatus = 1;
                        
                        for (int counter1 = 0; counter1 < lineageExtractionCount2; counter1++) arrayLineageData [lineageDataCount] = arrayLineageExtraction2 [counter1], lineageDataCount++;
                        delete [] arrayLineageExtraction2;
                    }
                    
                    delete [] arrayLineageExtraction;
                }
                
                //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
                //    cout<<" arrayLineageData "<<counterA<<endl;
                //}
                
                if (deleteFail == 1){
                    //-----Lineage Data Save-----
                    string connectDataLineagePath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+analysisID+"_"+treatmentNameHold+"_LineageData";
                    
                    char *writingArray = new char [lineageDataCount/8*25+25];
                    
                    unsigned long indexCount = 0;
                    int readBit [4];
                    int dataTemp = 0;
                    
                    lineageWritingCheck = 1;
                    
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = arrayLineageData [counter1*8]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = arrayLineageData [counter1*8];
                        }
                        
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        if (arrayLineageData [counter1*8+1] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = arrayLineageData [counter1*8+1]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = arrayLineageData [counter1*8+1];
                        }
                        
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        dataTemp = arrayLineageData [counter1*8+2];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        writingArray [indexCount] = (char)arrayLineageData [counter1*8+3], indexCount++;
                        
                        if (arrayLineageData [counter1*8+4] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = arrayLineageData [counter1*8+4]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = arrayLineageData [counter1*8+4];
                        }
                        
                        readBit [0] = dataTemp/16777216;
                        dataTemp = dataTemp%16777216;
                        readBit [1] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [2] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [3] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                        
                        if (arrayLineageData [counter1*8+5] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = arrayLineageData [counter1*8+5]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = arrayLineageData [counter1*8+5];
                        }
                        
                        readBit [0] = dataTemp/16777216;
                        dataTemp = dataTemp%16777216;
                        readBit [1] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [2] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [3] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                        
                        dataTemp = arrayLineageData [counter1*8+6];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = arrayLineageData [counter1*8+7];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                    }
                    
                    for (int counter1 = 0; counter1 < 25; counter1++) writingArray [indexCount] = 0, indexCount++;
                    
                    ofstream outfile (connectDataLineagePath.c_str(), ofstream::binary);
                    outfile.write ((char*) writingArray, indexCount);
                    outfile.close();
                    
                    delete [] writingArray;
                    
                    ifstream fin;
                    int terminationFlag = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        fin.open(connectDataLineagePath.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            lineageWritingCheck = 0;
                            terminationFlag = 0;
                        }
                        
                    } while (terminationFlag == 1);
                    
                    //-----Lineage Start/End List-----
                    //==========1. lineage no, 2. cell no, 3. X position, 4. Y position, 5. start, 6. image start, 7. end, 8. image end==========
                    string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStartEnd";
                    
                    lineageStartEndCount = 0;
                    int cellNumberStart = -1;
                    int lineageNumberStart = 0;
                    int firstEntryFind = 0;
                    
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if ((arrayLineageData [counter1*8+6] != lineageNumberStart || arrayLineageData [counter1*8+5] != cellNumberStart) && firstEntryFind == 0){
                            lineageNumberStart = arrayLineageData [counter1*8+6];
                            cellNumberStart = arrayLineageData [counter1*8+5];
                            
                            arrayLineageStartEnd [lineageStartEndCount] = lineageNumberStart, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = cellNumberStart, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8], lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+1], lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = counter1, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+2], lineageStartEndCount++;
                            
                            firstEntryFind = 1;
                        }
                        else if ((arrayLineageData [counter1*8+6] != lineageNumberStart || arrayLineageData [counter1*8+5] != cellNumberStart) && firstEntryFind == 1){
                            lineageNumberStart = arrayLineageData [counter1*8+6];
                            cellNumberStart = arrayLineageData [counter1*8+5];
                            
                            arrayLineageStartEnd [lineageStartEndCount] = counter1-1, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [(counter1-1)*8+2], lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = lineageNumberStart, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = cellNumberStart, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8], lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+1], lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = counter1, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+2], lineageStartEndCount++;
                        }
                        
                        if (counter1 == lineageDataCount/8-1){
                            arrayLineageStartEnd [lineageStartEndCount] = counter1, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+2], lineageStartEndCount++;
                        }
                        
                        if (lineageStartEndCount+24 > lineageStartEndLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate lineageStartEndUpDate];
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageStartEndCount/8; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageStartEnd [counterA*8 +counterB];
                    //    cout<<" arrayLineageStartEnd "<<counterA<<endl;
                    //}
                    
                    string extension;
                    
                    if (lineageStartEndCount != 0){
                        char *mainDataEntry = new char [lineageStartEndCount*7+10];
                        int totalEntryCount = 0;
                        
                        for (int counter1 = 0; counter1 < lineageStartEndCount; counter1++){
                            extension = to_string(arrayLineageStartEnd [counter1]);
                            
                            for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        
                        ofstream outfile2 (connectStartEndPath.c_str(), ofstream::binary);
                        outfile2.write (mainDataEntry, totalEntryCount);
                        outfile2.close();
                        
                        delete [] mainDataEntry;
                    }
                    
                    int fusionMarkTemp = 0;
                    int lastEventType = 0;
                    
                    for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                        if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp && arrayLineageStartEnd [counter1*8+1] == cellAmendTemp){
                            for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                                if (arrayLineageData [counter2*8+3] == 10) fusionMarkTemp = 1;
                                lastEventType = arrayLineageData [counter2*8+3];
                            }
                        }
                    }
                    
                    //==========XY Position List update==========
                    if (xyPositionListStatus == 1) delete [] arrayXYPositionList;
                    arrayXYPositionList = new int [lineageExtractionCount+500];
                    xyPositionListCount = 0;
                    xyPositionListStatus = 1;
                    int lineageExtractionLimitXY = lineageExtractionCount+500;
                    
                    for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                        if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp){
                            for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                                if (lineageExtractionLimitXY < xyPositionListCount+10){
                                    
                                    int *arrayUpDate = new int [xyPositionListCount+10];
                                    
                                    for (int counter3 = 0; counter3 < xyPositionListCount; counter3++) arrayUpDate [counter3] = arrayXYPositionList [counter3];
                                    
                                    delete [] arrayXYPositionList;
                                    arrayXYPositionList = new int [lineageExtractionLimitXY+5000];
                                    lineageExtractionLimitXY = lineageExtractionLimitXY+5000;
                                    
                                    for (int counter3 = 0; counter3 < xyPositionListCount; counter3++) arrayXYPositionList [counter3] = arrayUpDate [counter3];
                                    delete [] arrayUpDate;
                                }
                                
                                arrayXYPositionList [xyPositionListCount] = arrayLineageData [counter2*8+2], xyPositionListCount++; //-----Image Number-----
                                arrayXYPositionList [xyPositionListCount] = 0, xyPositionListCount++; //-----Connect Number-----
                                arrayXYPositionList [xyPositionListCount] = arrayLineageData [counter2*8], xyPositionListCount++; //-----X Position-----
                                arrayXYPositionList [xyPositionListCount] = arrayLineageData [counter2*8+1], xyPositionListCount++; //-----Y Position-----
                                
                                if (cellAmendTemp == arrayLineageData [counter2*8+5]) arrayXYPositionList [xyPositionListCount] = 1, xyPositionListCount++; //-----Target-----
                                else arrayXYPositionList [xyPositionListCount] = 0, xyPositionListCount++;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < xyPositionListCount/5; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayXYPositionList [counterA*5+counterB];
                    //    cout<<" arrayXYPositionList "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
                    //    cout<<" arrayLineageData "<<counterA<<endl;
                    //}
                    
                    extension = to_string(cutStartImage-1);
                    
                    if (extension.length() == 1) extension = "000"+extension;
                    else if (extension.length() == 2) extension = "00"+extension;
                    else if (extension.length() == 3) extension = "0"+extension;
                    
                    string connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                    
                    struct stat sizeOfFile;
                    
                    long sizeForCopy = 0;
                    
                    long size1 = 0;
                    long size2 = 0;
                    int checkFlag = 0;
                    
                    for (int counter3 = 0; counter3 < 6; counter3++){
                        sizeForCopy = 0;
                        
                        if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter3 == 0) size1 = sizeForCopy;
                            else if (counter3 == 1) size2 = sizeForCopy;
                            else if (counter3 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter3 == 3) size1 = sizeForCopy;
                            else if (counter3 == 4) size2 = sizeForCopy;
                            else if (counter3 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    int *masterReadForAmend = new int [sizeForCopy+50];
                    int masterReadForAmendCount = 0;
                    
                    int readingError = 0;
                    
                    if (checkFlag == 1){
                        int finData [17];
                        
                        fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                        
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                    readingError = 1;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        if (readingError == 0){
                            unsigned long readPosition = 0;
                            int stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                    finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                    finData [9] = uploadTemp [readPosition], readPosition++;
                                    finData [10] = uploadTemp [readPosition], readPosition++;
                                    finData [11] = uploadTemp [readPosition], readPosition++;
                                    finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                    finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                    finData [14] = uploadTemp [readPosition], readPosition++;
                                    finData [15] = uploadTemp [readPosition], readPosition++;
                                    finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                    
                                    if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                    else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                    
                                    finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                    else{
                                        
                                        masterReadForAmend [masterReadForAmendCount] = finData [1], masterReadForAmendCount++;
                                        masterReadForAmend [masterReadForAmendCount] = finData [3], masterReadForAmendCount++;
                                        masterReadForAmend [masterReadForAmendCount] = finData [4], masterReadForAmendCount++;
                                        masterReadForAmend [masterReadForAmendCount] = finData [7], masterReadForAmendCount++;
                                        masterReadForAmend [masterReadForAmendCount] = finData [12], masterReadForAmendCount++;
                                        masterReadForAmend [masterReadForAmendCount] = finData [13], masterReadForAmendCount++;
                                        masterReadForAmend [masterReadForAmendCount] = finData [16], masterReadForAmendCount++;
                                    }
                                }
                                
                            } while (stepCount != 3);
                        }
                        
                        delete [] uploadTemp;
                    }
                    
                    //for (int counterA = 0; counterA < masterReadForAmendCount/7; counterA++){
                    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForAmend [counterA*7+counterB];
                    //	cout<<" masterReadForAmend "<<counterA<<endl;
                    //}
                    
                    string connectAmendPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+analysisID+"_"+cellLineageNoHold+"_lineDataAmend";
                    
                    int entryCount = 0;
                    
                    for (int counter1 = 0; counter1 < masterReadForAmendCount/7; counter1++){
                        if (masterReadForAmend [counter1*7+4] == cellAmendTemp && masterReadForAmend [counter1*7+6] == lineageAmendTemp) entryCount++;
                    }
                    
                    indexCount = 0;
                    
                    writingArray = new char [entryCount*13+20];
                    
                    //-----1. Image No, 2, X position, 3 Y position, 4. Event, 5. Connect No, 6. Lineage NO-----
                    for (int counter1 = 0; counter1 < masterReadForAmendCount/7; counter1++){
                        if (masterReadForAmend [counter1*7+4] == cellAmendTemp && masterReadForAmend [counter1*7+6] == lineageAmendTemp){
                            dataTemp = cutStartImage-1;
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            dataTemp = masterReadForAmend [counter1*7];
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            dataTemp = masterReadForAmend [counter1*7+1];
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            writingArray [indexCount] = (char)lastEventType, indexCount++;
                            
                            dataTemp = masterReadForAmend [counter1*7+3];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            dataTemp = masterReadForAmend [counter1*7+6];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < 13; counter1++) writingArray [indexCount] = 0, indexCount++;
                    
                    ofstream outfile3 (connectAmendPath.c_str(), ofstream::binary);
                    outfile3.write ((char*)writingArray, indexCount);
                    outfile3.close();
                    
                    delete [] writingArray;
                    delete [] masterReadForAmend;
                    
                    if (stat(connectAmendPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        if (connectLineListLocalStatus == 1) delete [] arrayConnectLineListLocal;
                        arrayConnectLineListLocal = new int [sizeForCopy+50];
                        connectLineListLocalCount = 0;
                        connectLineListLocalLimit = (int)sizeForCopy+50;
                        connectLineListLocalStatus = 1;
                        
                        fin.open(connectAmendPath.c_str(), ios::in | ios::binary);
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        int finData [13];
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++; //--3
                                finData [6] = uploadTemp [readPosition], readPosition++; //--4
                                finData [7] = uploadTemp [readPosition], readPosition++;
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [5] = finData [4]*256+finData [5];
                                finData [9] = finData [7]*65536+finData [8]*256+finData [9];
                                finData [12] = finData [10]*65536+finData [11]*256+finData [12];
                                
                                if (finData [1] == 0 && finData [3] == 0) stepCount = 3;
                                else{
                                    
                                    if (connectLineListLocalCount+10 > connectLineListLocalLimit){
                                        int *arrayUpDate = new int [connectLineListLocalCount+10];
                                        
                                        for (int counter1 = 0; counter1 < connectLineListLocalCount; counter1++) arrayUpDate [counter1] = arrayConnectLineListLocal [counter1];
                                        
                                        delete [] arrayConnectLineListLocal;
                                        arrayConnectLineListLocal = new int [connectLineListLocalLimit+500];
                                        connectLineListLocalLimit = connectLineListLocalLimit+500;
                                        
                                        for (int counter1 = 0; counter1 < connectLineListLocalCount; counter1++) arrayConnectLineListLocal [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    arrayConnectLineListLocal [connectLineListLocalCount] = finData [3], connectLineListLocalCount++; //-----X Position-----
                                    arrayConnectLineListLocal [connectLineListLocalCount] = finData [5], connectLineListLocalCount++; //-----Y Position-----
                                    arrayConnectLineListLocal [connectLineListLocalCount] = finData [6], connectLineListLocalCount++; //-----Event Type-----
                                    arrayConnectLineListLocal [connectLineListLocalCount] = finData [9], connectLineListLocalCount++; //-----Connect No-----
                                    arrayConnectLineListLocal [connectLineListLocalCount] = finData [12], connectLineListLocalCount++; //-----Lineage No-----
                                    arrayConnectLineListLocal [connectLineListLocalCount] = finData [1], connectLineListLocalCount++; //-----Image no-----
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                    }
                    
                    string *queueListUpdateTemp = new string [queueListCount+50];
                    int queueListUpdateTempCount = 0;
                    
                    //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                    //	cout<<" arrayQueueList "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                        if (arrayQueueList [counter1*6] != treatmentNameHold || arrayQueueList [counter1*6+1] != cellLineageNoHold || arrayQueueList [counter1*6+2] != cellNoHold){
                            queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6], queueListUpdateTempCount++;
                            queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+1], queueListUpdateTempCount++;
                            queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+2], queueListUpdateTempCount++;
                            queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+3], queueListUpdateTempCount++;
                            queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+4], queueListUpdateTempCount++;
                            queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+5], queueListUpdateTempCount++;
                        }
                    }
                    
                    if (lastEventType == 2 || lastEventType == 6 || lastEventType == 92 || lastEventType == 10 || lastEventType == 11){
                        string endCheckTemp;
                        
                        for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                            if (arrayQueueList [counter1*6] == treatmentNameHold && arrayQueueList [counter1*6+1] == cellLineageNoHold && arrayQueueList [counter1*6+2] == cellNoHold){
                                endCheckTemp = arrayQueueList [counter1*6+4];
                                break;
                            }
                        }
                        
                        int findString = (int)endCheckTemp.find("/m");
                        if (findString != -1) endCheckTemp = endCheckTemp.substr(0, (unsigned long)findString);
                        
                        if (atoi(endCheckTemp.c_str()) <= cutStartImage-1) endCheckTemp = "0";
                        
                        int ifSetFlag = 0;
                        
                        if (ifStartHold != 0 && ifStartHold <= cutStartImage-1) ifSetFlag = 1;
                        
                        extension = to_string(cutStartImage-1);
                        
                        queueListUpdateTemp [queueListUpdateTempCount] = treatmentNameHold, queueListUpdateTempCount++;
                        queueListUpdateTemp [queueListUpdateTempCount] = cellLineageNoHold, queueListUpdateTempCount++;
                        queueListUpdateTemp [queueListUpdateTempCount] = cellNoHold, queueListUpdateTempCount++;
                        queueListUpdateTemp [queueListUpdateTempCount] = extension+":"+extension, queueListUpdateTempCount++;
                        
                        if (fusionMarkTemp == 0 && ifSetFlag == 0) queueListUpdateTemp [queueListUpdateTempCount] = endCheckTemp, queueListUpdateTempCount++;
                        else if (fusionMarkTemp == 1 && ifSetFlag == 0) queueListUpdateTemp [queueListUpdateTempCount] = endCheckTemp+"/m", queueListUpdateTempCount++;
                        else if (fusionMarkTemp == 0 && ifSetFlag == 1) queueListUpdateTemp [queueListUpdateTempCount] = "IF", queueListUpdateTempCount++;
                        else if (fusionMarkTemp == 1 && ifSetFlag == 1) queueListUpdateTemp [queueListUpdateTempCount] = "IF/m", queueListUpdateTempCount++;
                        
                        queueListUpdateTemp [queueListUpdateTempCount] = "Wait", queueListUpdateTempCount++;
                        
                        if (queueListLimit < queueListUpdateTempCount){
                            delete [] arrayQueueList;
                            arrayQueueList = new string [queueListUpdateTempCount+5000];
                            queueListLimit = queueListUpdateTempCount+5000;
                        }
                        
                        queueListCount = 0;
                        
                        for (int counter1 = 0; counter1 < queueListUpdateTempCount; counter1++) arrayQueueList [queueListCount] = queueListUpdateTemp [counter1], queueListCount++;
                        
                        //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                        //    cout<<" arrayQueueList "<<counterA<<endl;
                        //}
                        
                        delete [] queueListUpdateTemp;
                        
                        string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                        
                        if (queueListCount != 0){
                            char *mainDataEntry = new char [queueListCount*12+10];
                            int totalEntryCount = 0;
                            
                            for (int counter1 = 0; counter1 < queueListCount; counter1++){
                                extension = arrayQueueList [counter1];
                                
                                for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            
                            ofstream outfile4 (queueListPath.c_str(), ofstream::binary);
                            outfile4.write (mainDataEntry, totalEntryCount);
                            outfile4.close();
                            
                            delete [] mainDataEntry;
                        }
                    }
                    
                    if (proceedingFlag == 1 && lastEventTypeDiv == 1){
                        int timePointTemp = 0;
                        int parentCellNoTemp = 0;
                        int findFlag = 0;
                        int orphanDetect = 0;
                        
                        for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                            if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp){
                                timePointTemp = arrayLineageStartEnd [counter1*8+5];
                                
                                for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                                    if (arrayLineageData [counter2*8+3] == 31 || arrayLineageData [counter2*8+3] == 41 || arrayLineageData [counter2*8+3] == 51){
                                        parentCellNoTemp = arrayLineageData [counter2*8+4];
                                        
                                        findFlag = 0;
                                        
                                        for (int counter3 = 0; counter3 < lineageDataCount/8; counter3++){
                                            if (arrayLineageData [counter3*8+6] == lineageAmendTemp && arrayLineageData [counter3*8+2] == timePointTemp-1 && arrayLineageData [counter3*8+5] == parentCellNoTemp){
                                                
                                                findFlag = 1;
                                                break;
                                            }
                                        }
                                        
                                        if (findFlag == 0) orphanDetect = 1;
                                        
                                        break;
                                    }
                                }
                            }
                        }
                        
                        if (orphanDetect == 1){
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Some Progeny Failed to Delete/Use List Search-Orphan Delete to Fix"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    
                    //for (int counterA = 0; counterA < cellNumberInfoCount/7; counterA++){
                    //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayCellNumberInfo [counterA*7+counterB];
                    //    cout<<" arrayCellNumberInfo "<<counterA<<endl;
                    //}
                    
                    setStatus7 = 77;
                    
                    dataSaveRead = [[DataSaveRead alloc] init];
                    [dataSaveRead reviseLineClear];
                    
                    cellLineageInfoListCreationCall = 5;
                    cellNumberInfoListCreationCall = 5;
                    setStatus7 = 7;
                    setStatus8 = 1;
                    
                    if (searchWindowOperation != 0){
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSearchOperations object:self];
                    }
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Deletion Error: Fix Database"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Deletion Error: Fix Database"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            setStatus7 = 77;
            
            dataSaveRead = [[DataSaveRead alloc] init];
            [dataSaveRead reviseLineClear];
            
            cellLineageInfoListCreationCall = 5;
            cellNumberInfoListCreationCall = 5;
            setStatus7 = 7;
            setStatus8 = 1;
            
            if (searchWindowOperation != 0){
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSearchOperations object:self];
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Saved Data"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageJump:(id)sender{
    if (timeOneStatus == 0){
        if (trackingOn == 1){
            if (mainSavingInProgress == 0 && cleaningProgress == 0){
                inputNumber = [inputData integerValue];
                
                if (inputNumber >= timeOneHold && inputNumber <= timeEndHold){
                    imageNumberTrackForDisplay = (int)inputNumber;
                    [jumpDisplay setIntegerValue:imageNumberTrackForDisplay];
                    
                    if (ifEntry == 1 && imageNumberTrackForDisplay < ifStartHold){
                        ifEntry = 0;
                        fluorescentNo1 = fluorescentNoHold1;
                        fluorescentNo2 = fluorescentNoHold2;
                        fluorescentNo3 = fluorescentNoHold3;
                        fluorescentNo4 = fluorescentNoHold4;
                        fluorescentNo5 = fluorescentNoHold5;
                        fluorescentNo6 = fluorescentNoHold6;
                        fluorescentEntryCount = fluorescentEntryCountHold;
                        fluorescentName1 = fluorescentNameHold1;
                        fluorescentName2 = fluorescentNameHold2;
                        fluorescentName3 = fluorescentNameHold3;
                        fluorescentName4 = fluorescentNameHold4;
                        fluorescentName5 = fluorescentNameHold5;
                        fluorescentName6 = fluorescentNameHold6;
                        
                        string extension = to_string(imageNumberTrackForDisplay);
                        
                        if (extension.length() == 1) extension = "000"+extension;
                        else if (extension.length() == 2) extension = "00"+extension;
                        else if (extension.length() == 3) extension = "0"+extension;
                        
                        string extension2 = to_string(fluorescentNo1);
                        
                        string fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+exType;
                        
                        struct stat sizeOfFile;
                        
                        if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0){
                            int matchFind = 0;
                            
                            for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                                if (arrayFluorescentCutOff [counter1*7] == imageNumberTrackForDisplay){
                                    fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                    fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                    fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                    fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                                    fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                                    fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                                    matchFind = 1;
                                    break;
                                }
                            }
                            
                            if (matchFind == 0){
                                string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
                                
                                if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                                    int nearestCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                                        if (arrayFluorescentCutOff [counter1*7] < imageNumberTrackForDisplay){
                                            if (nearestCount < arrayFluorescentCutOff [counter1*7]){
                                                nearestCount = arrayFluorescentCutOff [counter1*7];
                                                fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                                fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                                fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                                fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                                                fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                                                fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                                            }
                                        }
                                    }
                                    
                                    if (fluorescentCutOffStatus == 0){
                                        arrayFluorescentCutOff = new int [imageEndHold*7];
                                        fluorescentCutOffCount = 0;
                                        fluorescentCutOffStatus = 1;
                                    }
                                    
                                    if (nearestCount != 0){
                                        arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
                                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
                                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
                                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
                                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
                                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
                                    }
                                    else{
                                        
                                        arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                    }
                                    
                                    ofstream oin;
                                    oin.open(cutOffPath.c_str(), ios::out);
                                    
                                    for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                                    
                                    oin<<"End"<<endl;
                                    oin.close();
                                }
                                else{
                                    
                                    fluorescentCutOff1 = 150;
                                    fluorescentCutOff2 = 150;
                                    fluorescentCutOff3 = 150;
                                    fluorescentCutOff4 = 150;
                                    fluorescentCutOff5 = 150;
                                    fluorescentCutOff6 = 150;
                                    
                                    if (fluorescentCutOffStatus == 0){
                                        arrayFluorescentCutOff = new int [imageEndHold*7];
                                        fluorescentCutOffCount = 0;
                                        fluorescentCutOffStatus = 1;
                                    }
                                    
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                                    
                                    ofstream oin;
                                    oin.open(cutOffPath.c_str(), ios::out);
                                    
                                    for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                                    
                                    oin<<"End"<<endl;
                                    oin.close();
                                }
                            }
                        }
                    }
                    
                    int lineSetError = 0;
                    
                    lineSet = [[LineSet alloc] init];
                    lineSetError = [lineSet dataRead:imageNumberTrackForDisplay];
                    
                    if (lineSetError == 0){
                        trackJump = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
                    }
                }
                else{
                    
                    [inputData setStringValue:@""];
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Range Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Other Processes On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [inputData setStringValue:@""];
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        [inputData setStringValue:@""];
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Time One On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageDisplayJump:(id)sender{
    if (timeOneStatus == 0){
        if (mainSavingInProgress == 0 && cleaningProgress == 0){
            inputNumber = [inputDisplayData integerValue];
            
            if (inputNumber >= timeOneHold && inputNumber <= timeEndHold){
                imageNumberDisplayForDisplay = (int)inputNumber;
                [jumpImageDisplay setIntegerValue:imageNumberDisplayForDisplay];
                
                int dataLoadingCheck = 0;
                int processType = 5;
                trackingSet = [[TrackingSet alloc] init];
                dataLoadingCheck = [trackingSet trackingSetMain:processType];
                
                if (dataLoadingCheck == 0){
                    displayJump = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    verificationPositionCall = 0;
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Data Read Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                [inputDisplayData setStringValue:@""];
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Range Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        [inputDisplayData setStringValue:@""];
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Time One On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)areaLimit:(id)sender{
    if (timeOneStatus == 2){
        long int inputNumber2 = [inputData integerValue];
        [inputData setStringValue:@""];
        
        if (inputNumber2 >= 40 && inputNumber2 <= 2000){
            [areaLimitDisplay setIntegerValue:inputNumber2];
            
            int removeConnectNo = 0;
            
            for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                removeConnectNo = 0;
                
                if (arrayGravityCenterRev [counter1*6+2] <= inputNumber2){
                    removeConnectNo = arrayGravityCenterRev [counter1*6+4];
                }
                
                if (removeConnectNo != 0) arrayTimeSelected [counter1*10] = 2;
                else if (arrayTimeSelected [counter1*10] == 2) arrayTimeSelected [counter1*10] = 0;
            }
            
            int status = 0;
            
            for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                status = arrayTimeSelected [(arrayPositionRevise [counter1*7+3]-1)*10];
                
                if (status == 0 || status == 5 || status == 6 || status == 2) arrayPositionRevise [counter1*7+5] = 0;
                else if (status == 1 || status == 7) arrayPositionRevise [counter1*7+5] = 1;
                else if (status == 3) arrayPositionRevise [counter1*7+5] = 2;
                else if (status == 4) arrayPositionRevise [counter1*7+5] = 3;
            }
            
            trackJump = 1;
            displayJump = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            verificationPositionCall = 0;
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
        }
    }
    else{
        
        [inputData setStringValue:@""];
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Time One Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)areaDelete:(id)sender{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        if (timeOneStatus == 2){
            removeAll = 1;
            
            int processType = 1;
            lineSet = [[LineSet alloc] init];
            [lineSet lineSetProcess:processType];
            
            removeAll = 0;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            [inputData setStringValue:@""];
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time One Mode Off"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cutSetDIC1:(id)sender{
    if (trackingOn != 0){
        cutDisplayValueHold = cutOff1;
        cutDisplay = 1;
        
        displaySetCutFlag1 = 1;
        displaySetCutFlag2 = 1;
        displaySetCutFlag3 = 1;
        displaySetCutFlag4 = 1;
        displaySetCutFlag5 = 1;
        displaySetCutFlag6 = 1;
        displaySetCutFlag7 = 1;
        
        verificationPositionCall = 0;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cutSetDIC2:(id)sender{
    if (trackingOn != 0){
        cutDisplayValueHold = cutOff2;
        cutDisplay = 2;
        
        displaySetCutFlag1 = 1;
        displaySetCutFlag2 = 1;
        displaySetCutFlag3 = 1;
        displaySetCutFlag4 = 1;
        displaySetCutFlag5 = 1;
        displaySetCutFlag6 = 1;
        displaySetCutFlag7 = 1;
        
        verificationPositionCall = 0;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cutSetDIC3:(id)sender{
    if (trackingOn != 0){
        cutDisplayValueHold = cutOff3;
        cutDisplay = 3;
        
        displaySetCutFlag1 = 1;
        displaySetCutFlag2 = 1;
        displaySetCutFlag3 = 1;
        displaySetCutFlag4 = 1;
        displaySetCutFlag5 = 1;
        displaySetCutFlag6 = 1;
        displaySetCutFlag7 = 1;
        
        verificationPositionCall = 0;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cutSetDIC4:(id)sender{
    if (trackingOn != 0){
        cutDisplayValueHold = cutOff4;
        cutDisplay = 4;
        
        displaySetCutFlag1 = 1;
        displaySetCutFlag2 = 1;
        displaySetCutFlag3 = 1;
        displaySetCutFlag4 = 1;
        displaySetCutFlag5 = 1;
        displaySetCutFlag6 = 1;
        displaySetCutFlag7 = 1;
        
        verificationPositionCall = 0;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cutSetDIC5:(id)sender{
    if (trackingOn != 0){
        cutDisplayValueHold = cutOff5;
        cutDisplay = 5;
        
        displaySetCutFlag1 = 1;
        displaySetCutFlag2 = 1;
        displaySetCutFlag3 = 1;
        displaySetCutFlag4 = 1;
        displaySetCutFlag5 = 1;
        displaySetCutFlag6 = 1;
        displaySetCutFlag7 = 1;
        
        verificationPositionCall = 0;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cutSetDIC6:(id)sender{
    if (trackingOn != 0){
        cutDisplayValueHold = cutOff6;
        cutDisplay = 6;
        
        displaySetCutFlag1 = 1;
        displaySetCutFlag2 = 1;
        displaySetCutFlag3 = 1;
        displaySetCutFlag4 = 1;
        displaySetCutFlag5 = 1;
        displaySetCutFlag6 = 1;
        displaySetCutFlag7 = 1;
        
        verificationPositionCall = 0;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cutSetDIC7:(id)sender{
    if (trackingOn != 0){
        cutDisplayValueHold = cutOff7;
        cutDisplay = 7;
        
        displaySetCutFlag1 = 1;
        displaySetCutFlag2 = 1;
        displaySetCutFlag3 = 1;
        displaySetCutFlag4 = 1;
        displaySetCutFlag5 = 1;
        displaySetCutFlag6 = 1;
        displaySetCutFlag7 = 1;
        
        verificationPositionCall = 0;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cutChangeDIC:(id)sender{
    if (trackingOn != 0){
        cutStatusDic = cutLimitValueHold;
        cutDisplayValueHold = cutLimitValueHold;
        
        displaySetDICFlag = 1;
        
        string cutOffDataPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/OutlineSettingStatus";
        
        ofstream oin;
        oin.open(cutOffDataPath.c_str(), ios::out);
        
        oin<<cutStatusDic<<endl;
        oin<<cutStatusFluorescent<<endl;
        oin.close();
        
        verificationPositionCall = 0;
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cutChangeFLU:(id)sender{
    if (trackingOn != 0){
        cutStatusFluorescent = cutLimitValueHold;
        cutDisplayValueHold = cutLimitValueHold;
        
        displaySetFluorescentFlag = 1;
        
        string cutOffDataPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/OutlineSettingStatus";
        
        ofstream oin;
        oin.open(cutOffDataPath.c_str(), ios::out);
        
        oin<<cutStatusDic<<endl;
        oin<<cutStatusFluorescent<<endl;
        oin.close();
        
        verificationPositionCall = 0;
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)backForwardSet:(id)sender{
    if (timeOneStatus == 2){
        if (backForwardMode == 3){
            backForwardMode = 0;
            [backForwardDisplay setStringValue:@"SXYB(Sq.)"];
        }
        else if (backForwardMode == 0){
            backForwardMode = 1;
            [backForwardDisplay setStringValue:@"SXY(Sq.)"];
        }
        else if (backForwardMode == 1){
            backForwardMode = 2;
            [backForwardDisplay setStringValue:@"SXY(Rv.)"];
        }
        else if (backForwardMode == 2){
            backForwardMode = 3;
            [backForwardDisplay setStringValue:@"SX(Rv.)"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Time One Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)checkOK:(id)sender{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        [self checkOKMain];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)checkOKMain{
    if (trackingOn == 1){
        if (timeOneStatus == 0){
            if (queueHoldingStatus == 0){
                if (tableListSwitch == 1 && doneListCount > 0){
                    string treatmentNameStringTemp = "";
                    string cellLineageStringTemp = "";
                    string cellNumberStringTemp = "";
                    string checkStatusTemp = "";
                    
                    for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                        if (arrayDoneList [counter1*5] == treatmentNameHold && arrayDoneList [counter1*5+1] == cellLineageNoHold && arrayDoneList [counter1*5+2] == cellNoHold){
                            treatmentNameStringTemp = arrayDoneList [counter1*5];
                            cellLineageStringTemp = arrayDoneList [counter1*5+1];
                            cellNumberStringTemp = arrayDoneList [counter1*5+2];
                            checkStatusTemp = arrayDoneList [counter1*5+4];
                            break;
                        }
                    }
                    
                    int checkStatusNumber = 0;
                    
                    if (checkStatusTemp == "TD") checkStatusNumber = 42;
                    else if (checkStatusTemp == "HD") checkStatusNumber = 52;
                    else if (checkStatusTemp == "CD") checkStatusNumber = 7;
                    else if (checkStatusTemp == "OF") checkStatusNumber = 8;
                    else if (checkStatusTemp == "FC") checkStatusNumber = 91;
                    else if (checkStatusTemp == "OK") checkStatusNumber = 100;
                    
                    if (checkStatusNumber != 0){
                        string lineageExtract = cellLineageStringTemp.substr(1);
                        string cellNoExtract = cellNumberStringTemp.substr(1);
                        
                        string lineageCommPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+analysisID+"_"+treatmentNameStringTemp+"_LineageData";
                        string startEndCommPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+analysisID+"_"+treatmentNameStringTemp+"_LineageStartEnd";
                        
                        struct stat sizeOfFile;
                        long sizeForCopy = 0;
                        long size1 = 0;
                        long size2 = 0;
                        int checkFlag = 0;
                        int readingError = 0;
                        
                        for (int counter3 = 0; counter3 < 6; counter3++){
                            sizeForCopy = 0;
                            
                            if (stat(lineageCommPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            if (sizeForCopy != 0){
                                if (counter3 == 0) size1 = sizeForCopy;
                                else if (counter3 == 1) size2 = sizeForCopy;
                                else if (counter3 == 2){
                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                        checkFlag = 1;
                                        break;
                                    }
                                    else{
                                        
                                        size1 = 0;
                                        size2 = 0;
                                        usleep (50000);
                                    }
                                }
                                else if (counter3 == 3) size1 = sizeForCopy;
                                else if (counter3 == 4) size2 = sizeForCopy;
                                else if (counter3 == 5){
                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                        checkFlag = 1;
                                    }
                                }
                            }
                        }
                        
                        ifstream fin;
                        
                        int *lineageCommTemp = new int [sizeForCopy+50];
                        int lineageCommTempCount = 0;
                        
                        if (checkFlag == 1){
                            int finData [25];
                            
                            fin.open(lineageCommPath.c_str(), ios::in | ios::binary);
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                        readingError = 1;
                                    }
                                }
                            }
                            
                            fin.close();
                            
                            if (readingError == 0){
                                unsigned long readPosition = 0;
                                int stepCount = 0;
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                                        finData [1] = uploadTemp [readPosition], readPosition++;
                                        finData [2] = uploadTemp [readPosition], readPosition++; //--2 X Position
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--3 +-
                                        finData [4] = uploadTemp [readPosition], readPosition++;
                                        finData [5] = uploadTemp [readPosition], readPosition++; //--4 Y Position
                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--5 Time point
                                        finData [8] = uploadTemp [readPosition], readPosition++; //--6 Event type
                                        finData [9] = uploadTemp [readPosition], readPosition++; //--7 +-
                                        finData [10] = uploadTemp [readPosition], readPosition++;
                                        finData [11] = uploadTemp [readPosition], readPosition++;
                                        finData [12] = uploadTemp [readPosition], readPosition++;
                                        finData [13] = uploadTemp [readPosition], readPosition++; //--8 Next cell/fuse no
                                        finData [14] = uploadTemp [readPosition], readPosition++; //--9 +-
                                        finData [15] = uploadTemp [readPosition], readPosition++;
                                        finData [16] = uploadTemp [readPosition], readPosition++;
                                        finData [17] = uploadTemp [readPosition], readPosition++;
                                        finData [18] = uploadTemp [readPosition], readPosition++; //--10 Cell no
                                        finData [19] = uploadTemp [readPosition], readPosition++;
                                        finData [20] = uploadTemp [readPosition], readPosition++;
                                        finData [21] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                                        finData [22] = uploadTemp [readPosition], readPosition++;
                                        finData [23] = uploadTemp [readPosition], readPosition++;
                                        finData [24] = uploadTemp [readPosition], readPosition++; //--12 Lineage no Fuse
                                        
                                        if (finData [0] == 1) finData [2] = (finData [1]*256+finData [2])*-1;
                                        else finData [2] = finData [1]*256+finData [2];
                                        
                                        if (finData [3] == 1) finData [5] = (finData [4]*256+finData [5])*-1;
                                        else finData [5] = finData [4]*256+finData [5];
                                        
                                        finData [7] = finData [6]*256+finData [7];
                                        
                                        if (finData [9] == 1) finData [13] = (finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13])*-1;
                                        else finData [13] = finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13];
                                        
                                        if (finData [14] == 1) finData [18] = (finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18])*-1;
                                        else finData [18] = finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18];
                                        
                                        finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                                        finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                                        
                                        if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                        else{
                                            
                                            lineageCommTemp [lineageCommTempCount] = finData [2], lineageCommTempCount++;
                                            lineageCommTemp [lineageCommTempCount] = finData [5], lineageCommTempCount++;
                                            lineageCommTemp [lineageCommTempCount] = finData [7], lineageCommTempCount++;
                                            lineageCommTemp [lineageCommTempCount] = finData [8], lineageCommTempCount++;
                                            lineageCommTemp [lineageCommTempCount] = finData [13], lineageCommTempCount++;
                                            lineageCommTemp [lineageCommTempCount] = finData [18], lineageCommTempCount++;
                                            lineageCommTemp [lineageCommTempCount] = finData [21], lineageCommTempCount++;
                                            lineageCommTemp [lineageCommTempCount] = finData [24], lineageCommTempCount++;
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                            }
                            
                            delete [] uploadTemp;
                        }
                        
                        //for (int counterA = 0; counterA < lineageCommTempCount/8; counterA++){
                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageCommTemp [counterA*8+counterB];
                        //	cout<<" lineageCommTemp "<<counterA<<endl;
                        //}
                        
                        if (checkFlag == 1 && readingError == 0){
                            sizeForCopy = 0;
                            
                            if (stat(startEndCommPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            int *startEndCommTemp = new int [sizeForCopy+50];
                            int startEndCommCount = 0;
                            
                            if (sizeForCopy != 0){
                                fin.open(startEndCommPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    char *uploadTemp = new char [sizeForCopy+50];
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    fin.close();
                                    
                                    string dataString = "";
                                    int readPosition = 0;
                                    
                                    do{
                                        
                                        if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                        else if (dataString != "End"){
                                            startEndCommTemp [startEndCommCount] = atoi(dataString.c_str()), startEndCommCount++;
                                            dataString = "";
                                        }
                                        
                                        readPosition++;
                                        
                                    } while (dataString != "End");
                                    
                                    delete [] uploadTemp;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < startEndCommCount/8; counterA++){
                            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<startEndCommTemp [counterA*8+counterB];
                            //	cout<<" startEndCommTemp "<<counterA<<endl;
                            //}
                            
                            int endStatus = 0;
                            int endImageNo = 0;
                            int mitosisCheckFind = 0;
                            
                            for (int counter1 = 0; counter1 < startEndCommCount/8; counter1++){
                                if (startEndCommTemp [counter1*8] == atoi(lineageExtract.c_str()) && startEndCommTemp [counter1*8+1] == atoi(cellNoExtract.c_str())){
                                    for (int counter2 = startEndCommTemp [counter1*8+4]; counter2 <= startEndCommTemp [counter1*8+6]; counter2++){
                                        endStatus = lineageCommTemp [counter2*8+3];
                                        endImageNo = lineageCommTemp [counter2*8+2];
                                        
                                        if (lineageCommTemp [counter2*8+3] == 10) mitosisCheckFind = 1;
                                    }
                                    
                                    break;
                                }
                            }
                            
                            if (endStatus != 0){
                                int statusConfirm = 0;
                                
                                if (checkStatusTemp == "TD" || checkStatusTemp == "HD" || checkStatusTemp == "SC" || checkStatusTemp == "OF" || checkStatusTemp == "FC" || checkStatusTemp == "CD"){
                                    if (endStatus == checkStatusNumber) statusConfirm = 1;
                                }
                                else if (checkStatusTemp == "IP" || checkStatusTemp == "RC"){
                                    if (endStatus == 1 || endStatus == 2 || endStatus == 31 || endStatus == 41 || endStatus == 51 || endStatus == 92 || endStatus == 10 || endStatus == 11 || endStatus == 6){
                                        statusConfirm = 2;
                                    }
                                    else statusConfirm = 1;
                                }
                                else if (checkStatusTemp == "DB"){
                                    if (endStatus == 7) statusConfirm = 1;
                                    else if (endStatus == 2) statusConfirm = 2;
                                }
                                else if (checkStatusTemp == "OK" || checkStatusTemp == "OK/m" || checkStatusTemp == "OKe" || checkStatusTemp == "OK/me"){
                                    statusConfirm = 3;
                                }
                                
                                if (statusConfirm == 1){
                                    string *doneListUpdateTemp = new string [doneListCount+50];
                                    int doneListUpdateTempCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                                        if (arrayDoneList [counter1*5] != treatmentNameStringTemp || arrayDoneList [counter1*5+1] != cellLineageStringTemp || arrayDoneList [counter1*5+2] != cellNumberStringTemp){
                                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5], doneListUpdateTempCount++;
                                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+1], doneListUpdateTempCount++;
                                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+2], doneListUpdateTempCount++;
                                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+3], doneListUpdateTempCount++;
                                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+4], doneListUpdateTempCount++;
                                        }
                                    }
                                    
                                    doneListCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < doneListUpdateTempCount; counter1++) arrayDoneList [doneListCount] = doneListUpdateTemp [counter1], doneListCount++;
                                    
                                    delete [] doneListUpdateTemp;
                                    
                                    string extension = to_string(endImageNo);
                                    
                                    arrayDoneList [doneListCount] = treatmentNameStringTemp, doneListCount++;
                                    arrayDoneList [doneListCount] = cellLineageStringTemp, doneListCount++;
                                    arrayDoneList [doneListCount] = cellNumberStringTemp, doneListCount++;
                                    arrayDoneList [doneListCount] = extension+":"+extension, doneListCount++;
                                    arrayDoneList [doneListCount] = checkStatusTemp, doneListCount++;
                                    
                                    string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
                                    
                                    if (doneListCount != 0){
                                        char *mainDataEntry = new char [doneListCount*10+10];
                                        int totalEntryCount = 0;
                                        
                                        for (int counter1 = 0; counter1 < doneListCount; counter1++){
                                            extension = arrayDoneList [counter1];
                                            
                                            for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                                            }
                                            
                                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                        
                                        ofstream outfile2 (doneListPath.c_str(), ofstream::binary);
                                        outfile2.write (mainDataEntry, totalEntryCount);
                                        outfile2.close();
                                        
                                        delete [] mainDataEntry;
                                    }
                                    
                                    string lineageFolderPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Treat/"+cellLineageStringTemp+"/"+analysisID+"_"+cellLineageStringTemp+"_CellStatus";
                                    
                                    sizeForCopy = 0;
                                    
                                    if (stat(lineageFolderPath2.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                    }
                                    
                                    int *masterReadForCellInfo = new int [sizeForCopy+50];
                                    int masterReadForCellInfoCount = 0;
                                    
                                    if (sizeForCopy != 0){
                                        fin.open(lineageFolderPath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            char *uploadTemp = new char [sizeForCopy+50];
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            string dataString = "";
                                            int readPosition = 0;
                                            
                                            do{
                                                
                                                if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                                else if (dataString != "End"){
                                                    masterReadForCellInfo [masterReadForCellInfoCount] = atoi(dataString.c_str()), masterReadForCellInfoCount++;
                                                    dataString = "";
                                                }
                                                
                                                readPosition++;
                                                
                                            } while (dataString != "End");
                                            
                                            delete [] uploadTemp;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < masterReadForCellInfoCount/7; counterA++){
                                    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForCellInfo [counterA*7+counterB];
                                    //	cout<<"masterReadForCellInfo "<<counterA<<endl;
                                    //}
                                    
                                    int lineageOpenStatus = 0;
                                    
                                    for (int counter1 = 0; counter1 < masterReadForCellInfoCount/7; counter1++){
                                        if (masterReadForCellInfo [counter1*7] == atoi(cellNoExtract.c_str()) && masterReadForCellInfo [counter1*7+6] == atoi(lineageExtract.c_str())){
                                            masterReadForCellInfo [counter1*7+2] = endImageNo;
                                            
                                            if (endStatus == 32) masterReadForCellInfo [counter1*7+4] = 3;
                                            else if (endStatus == 42) masterReadForCellInfo [counter1*7+4] = 4;
                                            else if (endStatus == 52) masterReadForCellInfo [counter1*7+4] = 5;
                                            else if (endStatus == 7) masterReadForCellInfo [counter1*7+4] = 6;
                                            else if (endStatus == 8) masterReadForCellInfo [counter1*7+4] = 9;
                                            else if (endStatus == 91) masterReadForCellInfo [counter1*7+4] = 7;
                                            
                                            if (mitosisCheckFind == 1) masterReadForCellInfo [counter1*7+5] = 77;
                                            else masterReadForCellInfo [counter1*7+5] = 0;
                                        }
                                        
                                        if (masterReadForCellInfo [counter1*7+6] == atoi(lineageExtract.c_str()) && masterReadForCellInfo [counter1*7+2] == -1){
                                            lineageOpenStatus = 1;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < masterReadForCellInfoCount/7; counterA++){
                                    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForCellInfo [counterA*7+counterB];
                                    //	cout<<"masterReadForCellInfo "<<counterA<<endl;
                                    //}
                                    
                                    char *mainDataEntry = new char [masterReadForCellInfoCount*7+10];
                                    int totalEntryCount = 0;
                                    
                                    for (int counter1= 0; counter1 < masterReadForCellInfoCount; counter1++){
                                        extension = to_string(masterReadForCellInfo [counter1]);
                                        
                                        for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                            mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    
                                    ofstream outfile5 (lineageFolderPath2.c_str(), ofstream::binary);
                                    outfile5.write (mainDataEntry, totalEntryCount);
                                    outfile5.close();
                                    
                                    delete [] mainDataEntry;
                                    delete [] masterReadForCellInfo;
                                    
                                    //==========Cell Lineage List: 1. Cell Lineage NO, 2. Status, 1: Done, 0: Open, 3. Number of cells in the lineage==========
                                    int numberOfEntry = 0;
                                    
                                    for (int counter1 = 0; counter1 < startEndCommCount/8; counter1++){
                                        if (startEndCommTemp [counter1*8] == atoi(lineageExtract.c_str())) numberOfEntry++;
                                    }
                                    
                                    string connectDataInfoPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageStatus";
                                    
                                    sizeForCopy = 0;
                                    
                                    if (stat(connectDataInfoPath.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                    }
                                    
                                    int *masterReadForLineageInfo = new int [sizeForCopy+50];
                                    int masterReadForLineageInfoCount = 0;
                                    
                                    if (sizeForCopy != 0){
                                        fin.open(connectDataInfoPath.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            char *uploadTemp = new char [sizeForCopy+50];
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            string dataString = "";
                                            int readPosition = 0;
                                            
                                            do{
                                                
                                                if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                                else if (dataString != "End"){
                                                    masterReadForLineageInfo [masterReadForLineageInfoCount] = atoi(dataString.c_str()), masterReadForLineageInfoCount++;
                                                    dataString = "";
                                                }
                                                
                                                readPosition++;
                                                
                                            } while (dataString != "End");
                                            
                                            delete [] uploadTemp;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < masterReadForLineageInfoCount/3; counter1++){
                                        if (masterReadForLineageInfo [counter1*3] == atoi(lineageExtract.c_str())){
                                            if (lineageOpenStatus == 1) masterReadForLineageInfo [counter1*3+1] = 0;
                                            else masterReadForLineageInfo [counter1*3+1] = 1;
                                            
                                            masterReadForLineageInfo [counter1*3+2] = numberOfEntry;
                                            break;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < masterReadForLineageInfoCount/3; counterA++){
                                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<masterReadForLineageInfo [counterA*3+counterB];
                                    //	cout<<" masterReadForLineageInfo "<<counterA<<endl;
                                    //}
                                    
                                    mainDataEntry = new char [masterReadForLineageInfoCount*6+10];
                                    totalEntryCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < masterReadForLineageInfoCount; counter1++){
                                        extension = to_string(masterReadForLineageInfo [counter1]);
                                        
                                        for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                            mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    
                                    ofstream outfile3 (connectDataInfoPath.c_str(), ofstream::binary);
                                    outfile3.write (mainDataEntry, totalEntryCount);
                                    outfile3.close();
                                    
                                    delete [] mainDataEntry;
                                    delete [] masterReadForLineageInfo;
                                    
                                    trackingTableSetDone = 1;
                                    listCrickMonitor = 1;
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                }
                                else if (statusConfirm == 2){
                                    string extension = to_string(endImageNo-1);
                                    string extension2 = to_string(endImageNo-1);
                                    
                                    if (queueListCount+12 > queueListLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate queueListUpDate];
                                    }
                                    
                                    arrayQueueList [queueListCount] = treatmentNameStringTemp, queueListCount++;
                                    arrayQueueList [queueListCount] = cellLineageStringTemp, queueListCount++;
                                    arrayQueueList [queueListCount] = cellNumberStringTemp, queueListCount++;
                                    arrayQueueList [queueListCount] = extension+":"+extension2, queueListCount++;
                                    
                                    if (mitosisCheckFind == 0) arrayQueueList [queueListCount] = "0", queueListCount++;
                                    else arrayQueueList [queueListCount] = "/m", queueListCount++;
                                    
                                    arrayQueueList [queueListCount] = "Wait", queueListCount++;
                                    
                                    string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                                    
                                    if (queueListCount != 0){
                                        char *mainDataEntry = new char [queueListCount*12+10];
                                        int totalEntryCount = 0;
                                        
                                        for (int counter1 = 0; counter1 < queueListCount; counter1++){
                                            extension = arrayQueueList [counter1];
                                            
                                            for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                                            }
                                            
                                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                        
                                        ofstream outfile (queueListPath.c_str(), ofstream::binary);
                                        outfile.write (mainDataEntry, totalEntryCount);
                                        outfile.close();
                                        
                                        delete [] mainDataEntry;
                                    }
                                    
                                    string *doneListUpdateTemp = new string [doneListCount+50];
                                    int doneListUpdateTempCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                                        if (arrayDoneList [counter1*5] != treatmentNameStringTemp || arrayDoneList [counter1*5+1] != cellLineageStringTemp || arrayDoneList [counter1*5+2] != cellNumberStringTemp){
                                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5], doneListUpdateTempCount++;
                                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+1], doneListUpdateTempCount++;
                                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+2], doneListUpdateTempCount++;
                                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+3], doneListUpdateTempCount++;
                                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+4], doneListUpdateTempCount++;
                                        }
                                    }
                                    
                                    doneListCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < doneListUpdateTempCount; counter1++) arrayDoneList [doneListCount] = doneListUpdateTemp [counter1], doneListCount++;
                                    
                                    string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
                                    
                                    if (doneListCount != 0){
                                        char *mainDataEntry = new char [doneListCount*10+10];
                                        int totalEntryCount = 0;
                                        
                                        for (int counter1 = 0; counter1 < doneListCount; counter1++){
                                            extension = arrayDoneList [counter1];
                                            
                                            for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                                            }
                                            
                                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                        
                                        ofstream outfile2 (doneListPath.c_str(), ofstream::binary);
                                        outfile2.write (mainDataEntry, totalEntryCount);
                                        outfile2.close();
                                        
                                        delete [] mainDataEntry;
                                    }
                                    
                                    delete [] doneListUpdateTemp;
                                    
                                    trackingTableSetDone = 1;
                                    listCrickMonitor = 1;
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                }
                                else if (statusConfirm == 3){
                                    string *doneListUpdateTemp = new string [doneListCount+50];
                                    int doneListUpdateTempCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                                        if (arrayDoneList [counter1*5] != treatmentNameStringTemp || arrayDoneList [counter1*5+1] != cellLineageStringTemp || arrayDoneList [counter1*5+2] != cellNumberStringTemp){
                                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5], doneListUpdateTempCount++;
                                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+1], doneListUpdateTempCount++;
                                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+2], doneListUpdateTempCount++;
                                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+3], doneListUpdateTempCount++;
                                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+4], doneListUpdateTempCount++;
                                        }
                                    }
                                    
                                    doneListCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < doneListUpdateTempCount; counter1++) arrayDoneList [doneListCount] = doneListUpdateTemp [counter1], doneListCount++;
                                    
                                    delete [] doneListUpdateTemp;
                                    
                                    string extension = to_string(endImageNo);
                                    
                                    arrayDoneList [doneListCount] = treatmentNameStringTemp, doneListCount++;
                                    arrayDoneList [doneListCount] = cellLineageStringTemp, doneListCount++;
                                    arrayDoneList [doneListCount] = cellNumberStringTemp, doneListCount++;
                                    arrayDoneList [doneListCount] = extension+":"+extension, doneListCount++;
                                    arrayDoneList [doneListCount] = checkStatusTemp, doneListCount++;
                                    
                                    string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
                                    
                                    if (doneListCount != 0){
                                        char *mainDataEntry = new char [doneListCount*10+10];
                                        int totalEntryCount = 0;
                                        
                                        for (int counter1 = 0; counter1 < doneListCount; counter1++){
                                            extension = arrayDoneList [counter1];
                                            
                                            for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                                            }
                                            
                                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                        
                                        ofstream outfile2 (doneListPath.c_str(), ofstream::binary);
                                        outfile2.write (mainDataEntry, totalEntryCount);
                                        outfile2.close();
                                        
                                        delete [] mainDataEntry;
                                    }
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                    
                                    trackingTableSetDone = 1;
                                    listCrickMonitor = 1;
                                }
                                else{
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"Perform Verification"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                            }
                            else{
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"List-Lineage Mismatch: Check Lineage or Delete Entry"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                            
                            delete [] startEndCommTemp;
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Lineage Read Error"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                        
                        delete [] lineageCommTemp;
                    }
                }
                else if (tableListSwitch == 2 && queueListCount > 0){
                    string lineageExtract = cellLineageNoHold.substr(1);
                    int lineageNoCommInt = atoi(lineageExtract.c_str());
                    string cellNoExtract = cellNoHold.substr(1);
                    int cellNoCommInt = atoi(cellNoExtract.c_str());
                    
                    int endStatus = 0;
                    int endImageNo = 0;
                    int mitosisCheckFind = 0;
                    
                    for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                        if (arrayLineageStartEnd [counter1*8] == lineageNoCommInt && arrayLineageStartEnd [counter1*8+1] == cellNoCommInt){
                            for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                                endStatus = arrayLineageData [counter2*8+3];
                                endImageNo = arrayLineageData [counter2*8+2];
                                
                                if (arrayLineageData [counter2*8+3] == 10) mitosisCheckFind = 1;
                            }
                            
                            break;
                        }
                    }
                    
                    if (endStatus != 0){
                        string *modifyDataStringTemp = new string [queueListCount+50];
                        int modifyDataStringTempCount = 0;
                        
                        string endCheckTemp = "";
                        
                        for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                            if (arrayQueueList [counter1*6] != treatmentNameHold || arrayQueueList [counter1*6+1] != cellLineageNoHold || arrayQueueList [counter1*6+2] != cellNoHold){
                                modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6], modifyDataStringTempCount++;
                                modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6+1], modifyDataStringTempCount++;
                                modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6+2], modifyDataStringTempCount++;
                                modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6+3], modifyDataStringTempCount++;
                                modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6+4], modifyDataStringTempCount++;
                                modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6+5], modifyDataStringTempCount++;
                            }
                            else endCheckTemp = arrayQueueList [counter1*6+4];
                        }
                        
                        queueListCount = 0;
                        for (int counter1 = 0; counter1 < modifyDataStringTempCount; counter1++) arrayQueueList [queueListCount] = modifyDataStringTemp [counter1], queueListCount++;
                        
                        delete [] modifyDataStringTemp;
                        
                        //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                        //    cout<<" arrayQueueList "<<counterA<<endl;
                        //}
                        
                        string extension = to_string(endImageNo);
                        string extension2 = to_string(endImageNo-1);
                        
                        if (queueListCount+12 > queueListLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate queueListUpDate];
                        }
                        
                        arrayQueueList [queueListCount] = treatmentNameHold, queueListCount++;
                        arrayQueueList [queueListCount] = cellLineageNoHold, queueListCount++;
                        arrayQueueList [queueListCount] = cellNoHold, queueListCount++;
                        arrayQueueList [queueListCount] = extension+":"+extension2, queueListCount++;
                        
                        if (mitosisCheckFind == 0 && (int)endCheckTemp.find("IF") == -1) arrayQueueList [queueListCount] = "0", queueListCount++;
                        else if (mitosisCheckFind == 1 && (int)endCheckTemp.find("IF") == -1) arrayQueueList [queueListCount] = "/m", queueListCount++;
                        else if (mitosisCheckFind == 0 && (int)endCheckTemp.find("IF") != -1) arrayQueueList [queueListCount] = "IF", queueListCount++;
                        else if (mitosisCheckFind == 1 && (int)endCheckTemp.find("IF") != -1) arrayQueueList [queueListCount] = "IF/m", queueListCount++;
                        
                        arrayQueueList [queueListCount] = "Wait", queueListCount++;
                        
                        string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                        
                        //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                        //    cout<<" arrayQueueList "<<counterA<<endl;
                        //}
                        
                        if (queueListCount != 0){
                            char *mainDataEntry = new char [queueListCount*12+10];
                            int totalEntryCount = 0;
                            
                            for (int counter1 = 0; counter1 < queueListCount; counter1++){
                                extension = arrayQueueList [counter1];
                                
                                for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            
                            ofstream outfile (queueListPath.c_str(), ofstream::binary);
                            outfile.write (mainDataEntry, totalEntryCount);
                            outfile.close();
                            
                            delete [] mainDataEntry;
                        }
                        
                        trackingTableSetDone = 1;
                        listCrickMonitor = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"List-Lineage Mismatch: Check Lineage or Delete Entry"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    if (tableListSwitch != 1 && tableListSwitch != 2){
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"No Check List/Queue Mode"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Auto Processing On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time One On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(int)lineExtend:(int)groupNoMerge{
    //=========Expand for Time One, Expand Selected connect==========
    
    int processResults = 0;
    int maxPointDimX = 0;
    int maxPointDimY = 0;
    int minPointDimX = 1000000;
    int minPointDimY = 1000000;
    
    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
        if (arrayTimeSelected [counter1*10+8] == groupNoMerge){
            for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                if (arrayPositionRevise [counter2*7+3] == groupNoMerge){
                    if (maxPointDimX < arrayPositionRevise [counter2*7]) maxPointDimX = arrayPositionRevise [counter2*7];
                    if (minPointDimX > arrayPositionRevise [counter2*7]) minPointDimX = arrayPositionRevise [counter2*7];
                    if (maxPointDimY < arrayPositionRevise [counter2*7+1]) maxPointDimY = arrayPositionRevise [counter2*7+1];
                    if (minPointDimY > arrayPositionRevise [counter2*7+1]) minPointDimY = arrayPositionRevise [counter2*7+1];
                }
                else{
                    
                    break;
                }
            }
        }
    }
    
    //=========A
    int horizontalLength2 = (maxPointDimX-minPointDimX)/2*2;
    int verticalLength2 = (maxPointDimY-minPointDimY)/2*2;
    int dimension2 = 0;
    int dimension2A = 0;
    int dimension2B = 0;
    
    if (horizontalLength2 >= verticalLength2) dimension2 = horizontalLength2+10;
    if (horizontalLength2 < verticalLength2) dimension2 = verticalLength2+10;
    
    dimension2A = (dimension2/2)*6;
    dimension2B = ((dimension2+20)/2)*6;
    
    int horizontalStart2A = minPointDimX-(dimension2A-horizontalLength2)/2;
    int verticalStart2A = minPointDimY-(dimension2A-verticalLength2)/2;
    int horizontalStart2B = minPointDimX-(dimension2B-horizontalLength2)/2;
    int verticalStart2B = minPointDimY-(dimension2B-verticalLength2)/2;
    //==========A
    
    int startY = 0;
    int endY = 0;
    int startX = 0;
    int endX = 0;
    
    //=========B
    int *findReviseConnect = new int [1000];
    for (int counter2 = 0; counter2 < 1000; counter2++) findReviseConnect [counter2] = 0;
    
    int **rangeMatrixA = new int *[dimension2A+4];
    
    for (int counter2 = 0; counter2 < dimension2A+4; counter2++){
        rangeMatrixA [counter2] = new int [dimension2A+4];
    }
    
    int **rangeMatrixB = new int *[dimension2B+4];
    
    for (int counter2 = 0; counter2 < dimension2B+4; counter2++){
        rangeMatrixB [counter2] = new int [dimension2B+4];
    }
    
    int *connectAnalysisXA = new int [dimension2A*4];
    int *connectAnalysisYA = new int [dimension2A*4];
    int *connectAnalysisTempXA = new int [dimension2A*4];
    int *connectAnalysisTempYA = new int [dimension2A*4];
    
    int *connectAnalysisXB = new int [dimension2B*4];
    int *connectAnalysisYB = new int [dimension2B*4];
    int *connectAnalysisTempXB = new int [dimension2B*4];
    int *connectAnalysisTempYB = new int [dimension2B*4];
    
    int freePixelFind = 0;
    int processConnectPosition = 0;
    int processConnectPosition2 = 0;
    int maxConnectRevise = 0;
    int findReviseConnectLimit = 1000;
    int connectivityNumberA = 0;
    int connectivityNumberB = 0;
    int connectAnalysisCount = 0;
    int terminationFlag = 0;
    int connectAnalysisTempCount = 0;
    int xSource = 0;
    int ySource = 0;
    int connectTemp = 0;
    int maxConnect = 0;
    int processConnectNo = 0;
    int findFlag = 0;
    int cutOffFinal = 0;
    
    for (int counter2 = cutStatusFluorescent; counter2 < 240; counter2 = counter2+10){ //====FLU
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                    if (sourceImage [counterY+verticalStart2A][counterX+horizontalStart2A] == 100) rangeMatrixA [counterY][counterX] = 0;
                    else if (sourceImage [counterY+verticalStart2A][counterX+horizontalStart2A] < counter2) rangeMatrixA [counterY][counterX] = 0;
                    else rangeMatrixA [counterY][counterX] = -150;
                }
                else rangeMatrixA [counterY][counterX] = 0;
            }
        }
        
        for (int counterY = 0; counterY < dimension2B; counterY++){
            for (int counterX = 0; counterX < dimension2B; counterX++){
                if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                    if (sourceImage [counterY+verticalStart2B][counterX+horizontalStart2B] == 100) rangeMatrixB [counterY][counterX] = 0;
                    else if (sourceImage [counterY+verticalStart2B][counterX+horizontalStart2B] < counter2) rangeMatrixB [counterY][counterX] = 0;
                    else rangeMatrixB [counterY][counterX] = -150;
                }
                else rangeMatrixB [counterY][counterX] = 0;
            }
        }
        
        //for (int counterA = 0; counterA < dimension2A; counterA++){
        //    for (int counterB = 0; counterB < dimension2A; counterB++) cout<<" "<<rangeMatrixA [counterA][counterB];
        //    cout<<" rangeMatrixA "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < dimension2B; counterA++){
        //    for (int counterB = 0; counterB < dimension2B; counterB++) cout<<" "<<rangeMatrixB  [counterA][counterB];
        //    cout<<" rangeMatrixB "<<counterA<<endl;
        //}
        
        //-----MapA-----
        connectivityNumberA = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (rangeMatrixA [counterY][counterX] == -150){
                    connectivityNumberA++;
                    rangeMatrixA [counterY][counterX] = connectivityNumberA;
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixA [counterY-1][counterX-1] == -150){
                        rangeMatrixA [counterY-1][counterX-1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && rangeMatrixA [counterY-1][counterX] == -150){
                        rangeMatrixA [counterY-1][counterX] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && counterX+1 < dimension2A && rangeMatrixA [counterY-1][counterX+1] == -150){
                        rangeMatrixA [counterY-1][counterX+1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension2A && rangeMatrixA [counterY][counterX+1] == -150){
                        rangeMatrixA [counterY][counterX+1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2A && counterX+1 < dimension2A && rangeMatrixA [counterY+1][counterX+1] == -150){
                        rangeMatrixA [counterY+1][counterX+1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2A && rangeMatrixA [counterY+1][counterX] == -150){
                        rangeMatrixA [counterY+1][counterX] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2A && counterX-1 >= 0 && rangeMatrixA [counterY+1][counterX-1] == -150){
                        rangeMatrixA [counterY+1][counterX-1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && rangeMatrixA [counterY][counterX-1] == -150){
                        rangeMatrixA [counterY][counterX-1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                xSource = connectAnalysisXA [counter3], ySource = connectAnalysisYA [counter3];
                                
                                if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrixA [ySource-1][xSource-1] == -150){
                                    rangeMatrixA [ySource-1][xSource-1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && rangeMatrixA [ySource-1][xSource] == -150){
                                    rangeMatrixA [ySource-1][xSource] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && xSource+1 < dimension2A && rangeMatrixA [ySource-1][xSource+1] == -150){
                                    rangeMatrixA [ySource-1][xSource+1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension2A && rangeMatrixA [ySource][xSource+1] == -150){
                                    rangeMatrixA [ySource][xSource+1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 > dimension2A && xSource+1 < dimension2A && rangeMatrixA [ySource+1][xSource+1] == -150){
                                    rangeMatrixA [ySource+1][xSource+1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension2A && rangeMatrixA [ySource+1][xSource] == -150){
                                    rangeMatrixA [ySource+1][xSource] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension2A && xSource-1 >= 0 && rangeMatrixA [ySource+1][xSource-1] == -150){
                                    rangeMatrixA [ySource+1][xSource-1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && rangeMatrixA [ySource][xSource-1] == -150){
                                    rangeMatrixA [ySource][xSource-1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                connectAnalysisXA [counter3] = connectAnalysisTempXA [counter3], connectAnalysisYA [counter3] = connectAnalysisTempYA [counter3];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //-----Determine number of pixels-----
        int *connectedPix = new int [connectivityNumberA+50];
        
        for (int counter3 = 0; counter3 <= connectivityNumberA; counter3++) connectedPix [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (rangeMatrixA [counterY][counterX] != 0) connectedPix [rangeMatrixA [counterY][counterX]]++;
            }
        }
        
        //-----Map up-date-----
        connectTemp = 1;
        
        for (int counter3 = 1; counter3 <= connectivityNumberA; counter3++){
            if (connectedPix [counter3] < 10) connectedPix [counter3] = 0;
            else{
                
                connectedPix [counter3] = connectTemp;
                connectTemp++;
            }
        }
        
        maxConnect = 0;
        maxConnectRevise = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A];
                    
                    if ((connectTemp = rangeMatrixA [counterY][counterX]) != 0) rangeMatrixA [counterY][counterX] = connectedPix [connectTemp];
                    else rangeMatrixA [counterY][counterX] = 0;
                    
                    if (rangeMatrixA [counterY][counterX] > maxConnect) maxConnect = rangeMatrixA [counterY][counterX];
                }
            }
        }
        
        delete [] connectedPix;
        
        int *findConnectNo = new int [maxConnect+5];
        for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo [counter3] = 0;
        
        if (maxConnectRevise+10 > findReviseConnectLimit){
            delete [] findReviseConnect;
            findReviseConnect = new int [maxConnectRevise+50];
            findReviseConnectLimit = maxConnectRevise+50;
        }
        
        for (int counter3 = 0; counter3 < maxConnectRevise+5; counter3++) findReviseConnect [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] == groupNoMerge){
                        if (rangeMatrixA [counterY][counterX] != 0) findConnectNo [rangeMatrixA [counterY][counterX]]++;
                    }
                }
            }
        }
        
        processConnectNo = 0;
        processConnectPosition = 0;
        
        for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
            if (findConnectNo [counter3] > processConnectNo){
                processConnectNo = findConnectNo [counter3];
                processConnectPosition = counter3;
            }
        }
        
        if (processConnectPosition != 0){
            freePixelFind = 0;
            
            for (int counterY = 0; counterY < dimension2A; counterY++){
                for (int counterX = 0; counterX < dimension2A; counterX++){
                    if (rangeMatrixA [counterY][counterX] == processConnectPosition){
                        if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                            if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] != 0){
                                findReviseConnect [revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A]]++;
                            }
                            
                            if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] == 0) freePixelFind = 1;
                        }
                    }
                }
            }
            
            //-----MapB-----
            connectivityNumberB = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (rangeMatrixB [counterY][counterX] == -150){
                        connectivityNumberB++;
                        rangeMatrixB [counterY][counterX] = connectivityNumberB;
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixB [counterY-1][counterX-1] == -150){
                            rangeMatrixB [counterY-1][counterX-1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && rangeMatrixB [counterY-1][counterX] == -150){
                            rangeMatrixB [counterY-1][counterX] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && counterX+1 < dimension2B && rangeMatrixB [counterY-1][counterX+1] == -150){
                            rangeMatrixB [counterY-1][counterX+1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension2B && rangeMatrixB [counterY][counterX+1] == -150){
                            rangeMatrixB [counterY][counterX+1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2B && counterX+1 < dimension2B && rangeMatrixB [counterY+1][counterX+1] == -150){
                            rangeMatrixB [counterY+1][counterX+1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2B && rangeMatrixB [counterY+1][counterX] == -150){
                            rangeMatrixB [counterY+1][counterX] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2B && counterX-1 >= 0 && rangeMatrixB [counterY+1][counterX-1] == -150){
                            rangeMatrixB [counterY+1][counterX-1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && rangeMatrixB [counterY][counterX-1] == -150){
                            rangeMatrixB [counterY][counterX-1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                    xSource = connectAnalysisXB [counter3], ySource = connectAnalysisYB [counter3];
                                    
                                    if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrixB [ySource-1][xSource-1] == -150){
                                        rangeMatrixB [ySource-1][xSource-1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && rangeMatrixB [ySource-1][xSource] == -150){
                                        rangeMatrixB [ySource-1][xSource] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && xSource+1 < dimension2B && rangeMatrixB [ySource-1][xSource+1] == -150){
                                        rangeMatrixB [ySource-1][xSource+1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension2B && rangeMatrixB [ySource][xSource+1] == -150){
                                        rangeMatrixB [ySource][xSource+1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 > dimension2B && xSource+1 < dimension2B && rangeMatrixB [ySource+1][xSource+1] == -150){
                                        rangeMatrixB [ySource+1][xSource+1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension2B && rangeMatrixB [ySource+1][xSource] == -150){
                                        rangeMatrixB [ySource+1][xSource] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension2B && xSource-1 >= 0 && rangeMatrixB [ySource+1][xSource-1] == -150){
                                        rangeMatrixB [ySource+1][xSource-1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && rangeMatrixB [ySource][xSource-1] == -150){
                                        rangeMatrixB [ySource][xSource-1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                    connectAnalysisXB [counter3] = connectAnalysisTempXB [counter3], connectAnalysisYB [counter3] = connectAnalysisTempYB [counter3];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //-----Determine number of pixels-----
            connectedPix = new int [connectivityNumberB+50];
            
            for (int counter3 = 0; counter3 <= connectivityNumberB; counter3++) connectedPix [counter3] = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (rangeMatrixB [counterY][counterX] != 0) connectedPix [rangeMatrixB [counterY][counterX]]++;
                }
            }
            
            //-----Map up-date-----
            connectTemp = 1;
            
            for (int counter3 = 1; counter3 <= connectivityNumberB; counter3++){
                if (connectedPix [counter3] < 10) connectedPix [counter3] = 0;
                else{
                    
                    connectedPix [counter3] = connectTemp;
                    connectTemp++;
                }
            }
            
            maxConnect = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                        if ((connectTemp = rangeMatrixB [counterY][counterX]) != 0) rangeMatrixB [counterY][counterX] = connectedPix [connectTemp];
                        else rangeMatrixB [counterY][counterX] = 0;
                        
                        if (rangeMatrixB [counterY][counterX] > maxConnect) maxConnect = rangeMatrixB [counterY][counterX];
                    }
                }
            }
            
            delete [] connectedPix;
            
            int *findConnectNo2 = new int [maxConnect+5];
            for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo2 [counter3] = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                        if (revisedWorkingMap [counterY+verticalStart2B][counterX+horizontalStart2B] == groupNoMerge){
                            if (rangeMatrixB [counterY][counterX] != 0) findConnectNo2 [rangeMatrixB [counterY][counterX]]++;
                        }
                    }
                }
            }
            
            processConnectNo = 0;
            processConnectPosition2 = 0;
            
            for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
                if (findConnectNo2 [counter3] > processConnectNo){
                    processConnectNo = findConnectNo2 [counter3];
                    processConnectPosition2 = counter3;
                }
            }
            
            if (processConnectPosition2 != 0){
                for (int counterY = 0; counterY < dimension2A; counterY++){
                    for (int counterX = 0; counterX < dimension2A; counterX++){
                        if ((counterY+verticalStart2A)-verticalStart2B >= 0 && (counterY+verticalStart2A)-verticalStart2B < dimension2B && (counterX+horizontalStart2A)-horizontalStart2B >= 0 && (counterX+horizontalStart2A)-horizontalStart2B < dimension2B){
                            rangeMatrixB [(counterY+verticalStart2A)-verticalStart2B][(counterX+horizontalStart2A)-horizontalStart2B] = 0;
                        }
                    }
                }
                
                findFlag = 0;
                
                for (int counterY = 0; counterY < dimension2B; counterY++){
                    for (int counterX = 0; counterX < dimension2B; counterX++){
                        if (rangeMatrixB [counterY][counterX] == processConnectPosition2){
                            findFlag = 1;
                            break;
                        }
                    }
                }
                
                if (findFlag == 0){
                    cutOffFinal = counter2;
                    
                    delete [] findConnectNo2;
                    delete [] findConnectNo;
                    break;
                }
            }
            else{
                
                if (counter2 != 20) cutOffFinal = counter2-10;
                else cutOffFinal = 0;
                
                delete [] findConnectNo2;
                delete [] findConnectNo;
                break;
            }
            
            delete [] findConnectNo2;
        }
        else{
            
            if (counter2 != 20) cutOffFinal = counter2-10;
            else cutOffFinal = 0;
            
            delete [] findConnectNo;
            break;
        }
        
        delete [] findConnectNo;
    }
    
    delete [] connectAnalysisXA;
    delete [] connectAnalysisYA;
    delete [] connectAnalysisTempXA;
    delete [] connectAnalysisTempYA;
    
    delete [] connectAnalysisXB;
    delete [] connectAnalysisYB;
    delete [] connectAnalysisTempXB;
    delete [] connectAnalysisTempYB;
    
    for (int counter2 = 0; counter2 < dimension2A+4; counter2++){
        delete [] rangeMatrixA [counter2];
    }
    
    delete [] rangeMatrixA;
    
    for (int counter2 = 0; counter2 < dimension2B+4; counter2++){
        delete [] rangeMatrixB [counter2];
    }
    
    delete [] rangeMatrixB;
    //-----BB
    
    if (cutOffFinal != 0 && freePixelFind == 1){
        int extendConnectCount = 0;
        
        for (int counter1 = 1; counter1 < maxConnectRevise+1; counter1++){
            if (findReviseConnect [counter1] != 0) extendConnectCount++;
        }
        
        int *extendConnectList = new int [extendConnectCount*2+1];
        extendConnectCount = 0;
        
        for (int counter1 = 1; counter1 < maxConnectRevise+1; counter1++){
            if (findReviseConnect [counter1] != 0){
                extendConnectList [extendConnectCount] = counter1, extendConnectCount++;
                extendConnectList [extendConnectCount] = 0, extendConnectCount++;
            }
        }
        
        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
            int connectFind = 0;
            
            for (int counter2 = 0; counter2 < extendConnectCount/2; counter2++){
                if (extendConnectList [counter2*2] == arrayTimeSelected [counter1*10+8]){
                    connectFind = 1;
                    break;
                }
            }
            
            if (connectFind == 1){
                int startPosition = arrayTimeSelected [counter1*10+2];
                
                for (int counter2 = startPosition; counter2 < positionReviseCount/7; counter2++){
                    if (arrayPositionRevise [counter2*7+3] == arrayTimeSelected [counter1*10+8]){
                        if (maxPointDimX < arrayPositionRevise [counter2*7]) maxPointDimX = arrayPositionRevise [counter2*7];
                        if (minPointDimX > arrayPositionRevise [counter2*7]) minPointDimX = arrayPositionRevise [counter2*7];
                        if (maxPointDimY < arrayPositionRevise [counter2*7+1]) maxPointDimY = arrayPositionRevise [counter2*7+1];
                        if (minPointDimY > arrayPositionRevise [counter2*7+1]) minPointDimY = arrayPositionRevise [counter2*7+1];
                    }
                    else{
                        
                        break;
                    }
                }
            }
        }
        
        int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
        int verticalLength = (maxPointDimY-minPointDimY)/2*2;
        int dimension = 0;
        
        if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
        if (horizontalLength < verticalLength) dimension = verticalLength+30;
        
        dimension = (dimension/2)*2;
        
        int horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
        int verticalStart = minPointDimY-(dimension-verticalLength)/2;
        
        //=======CC
        int **rangeMatrix = new int *[dimension+4];
        
        for (int counter2 = 0; counter2 < dimension+4; counter2++){
            rangeMatrix [counter2] = new int [dimension+4];
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                    if (sourceImage [counterY+verticalStart][counterX+horizontalStart] == 100) rangeMatrix [counterY][counterX] = 0;
                    else if (sourceImage [counterY+verticalStart][counterX+horizontalStart] < cutOffFinal) rangeMatrix [counterY][counterX] = 0;
                    else rangeMatrix [counterY][counterX] = -150;
                }
                else rangeMatrix [counterY][counterX] = 0;
            }
        }
        
        int *connectAnalysisX = new int [dimension*4];
        int *connectAnalysisY = new int [dimension*4];
        int *connectAnalysisTempX = new int [dimension*4];
        int *connectAnalysisTempY = new int [dimension*4];
        
        int connectivityNumber = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (rangeMatrix [counterY][counterX] == -150){
                    connectivityNumber++;
                    rangeMatrix [counterY][counterX] = connectivityNumber;
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrix [counterY-1][counterX-1] == -150){
                        rangeMatrix [counterY-1][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && rangeMatrix [counterY-1][counterX] == -150){
                        rangeMatrix [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && counterX+1 < dimension && rangeMatrix [counterY-1][counterX+1] == -150){
                        rangeMatrix [counterY-1][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension && rangeMatrix [counterY][counterX+1] == -150){
                        rangeMatrix [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && counterX+1 < dimension && rangeMatrix [counterY+1][counterX+1] == -150){
                        rangeMatrix [counterY+1][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && rangeMatrix [counterY+1][counterX] == -150){
                        rangeMatrix [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && counterX-1 >= 0 && rangeMatrix [counterY+1][counterX-1] == -150){
                        rangeMatrix [counterY+1][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && rangeMatrix [counterY][counterX-1] == -150){
                        rangeMatrix [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                
                                if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrix [ySource-1][xSource-1] == -150){
                                    rangeMatrix [ySource-1][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && rangeMatrix [ySource-1][xSource] == -150){
                                    rangeMatrix [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && xSource+1 < dimension && rangeMatrix [ySource-1][xSource+1] == -150){
                                    rangeMatrix [ySource-1][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension && rangeMatrix [ySource][xSource+1] == -150){
                                    rangeMatrix [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 > dimension && xSource+1 < dimension && rangeMatrix [ySource+1][xSource+1] == -150){
                                    rangeMatrix [ySource+1][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && rangeMatrix [ySource+1][xSource] == -150){
                                    rangeMatrix [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && xSource-1 >= 0 && rangeMatrix [ySource+1][xSource-1] == -150){
                                    rangeMatrix [ySource+1][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && rangeMatrix [ySource][xSource-1] == -150){
                                    rangeMatrix [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //-----Determine number of pixels-----
        int *connectedPix = new int [connectivityNumber+50];
        
        for (int counter3 = 0; counter3 <= connectivityNumber; counter3++) connectedPix [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (rangeMatrix [counterY][counterX] != 0) connectedPix [rangeMatrix [counterY][counterX]]++;
            }
        }
        
        //-----Map up-date-----
        connectTemp = 1;
        
        for (int counter3 = 1; counter3 <= connectivityNumber; counter3++){
            if (connectedPix [counter3] < 10) connectedPix [counter3] = 0;
            else{
                
                connectedPix [counter3] = connectTemp;
                connectTemp++;
            }
        }
        
        maxConnect = 0;
        maxConnectRevise = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart];
                    
                    if ((connectTemp = rangeMatrix [counterY][counterX]) != 0) rangeMatrix [counterY][counterX] = connectedPix [connectTemp];
                    else rangeMatrix [counterY][counterX] = 0;
                    
                    if (rangeMatrix [counterY][counterX] > maxConnect) maxConnect = rangeMatrix [counterY][counterX];
                }
            }
        }
        
        delete [] connectedPix;
        
        int *findConnectNo = new int [maxConnect+5];
        for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo [counter3] = 0;
        
        if (maxConnectRevise+10 > findReviseConnectLimit){
            delete [] findReviseConnect;
            findReviseConnect = new int [maxConnectRevise+50];
        }
        
        for (int counter3 = 0; counter3 < maxConnectRevise+5; counter3++) findReviseConnect [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] == groupNoMerge){
                        if (rangeMatrix [counterY][counterX] != 0) findConnectNo [rangeMatrix [counterY][counterX]]++;
                    }
                }
            }
        }
        
        processConnectNo = 0;
        processConnectPosition = 0;
        
        for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
            if (findConnectNo [counter3] > processConnectNo){
                processConnectNo = findConnectNo [counter3];
                processConnectPosition = counter3;
            }
        }
        //========CC
        
        int **connectivityMapTemp = new int *[dimension+1];
        int **connectivityMapTemp2 = new int *[dimension+1];
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            connectivityMapTemp [counter1] = new int [dimension+1];
            connectivityMapTemp2 [counter1] = new int [dimension+1];
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = 0;
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (rangeMatrix [counterY][counterX] == processConnectPosition) connectivityMapTemp [counterY][counterX] = -1;
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
        //	cout<<" connectivityMapTemp "<<counterA<<endl;
        //}
        
        if (minPointDimY-30 >= 0) startY = minPointDimY-30;
        else startY = 0;
        
        if (maxPointDimY+30 < imageDimension) endY = maxPointDimY+31;
        else endY = imageDimension;
        
        if (minPointDimX-30 >= 0) startX = minPointDimX-30;
        else startX = 0;
        
        if (maxPointDimX+30 < imageDimension) endX = maxPointDimX+31;
        else endX = imageDimension;
        
        int connectFind = 0;
        
        for (int counterY = startY; counterY < endY; counterY++){
            for (int counterX = startX; counterX < endX; counterX++){
                connectFind = 0;
                
                for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                    if (extendConnectList [counter1*2] == revisedWorkingMap [counterY][counterX]){
                        connectFind = 1;
                        break;
                    }
                }
                
                if (connectFind == 1){
                    if (counterY-verticalStart > 0 && counterY-verticalStart < dimension && counterX-horizontalStart > 0 && counterX-horizontalStart < dimension) connectivityMapTemp [counterY-verticalStart][counterX-horizontalStart] = revisedWorkingMap [counterY][counterX];
                }
            }
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp2 [counterY][counterX] = connectivityMapTemp [counterY][counterX];
        }
        
        terminationFlag = 0;
        int startOrder = 0;
        int findFreePoint = 0;
        int connectNo = 0;
        int remainingCheck = 0;
        
        do{
            
            for (int counter1 = startOrder; counter1 < extendConnectCount/2; counter1++){
                connectNo = extendConnectList [counter1*2];
                
                if (extendConnectList [counter1*2+1] == 0){
                    findFreePoint = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp [counterY][counterX] == connectNo){
                                if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMapTemp [counterY-1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX+1 < dimension && connectivityMapTemp [counterY+1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                }
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                    }
                    
                    if (findFreePoint == 0) extendConnectList [counter1*2+1] = 1;
                }
            }
            
            for (int counter1 = 0; counter1 < startOrder; counter1++){
                connectNo = extendConnectList [counter1*2];
                
                if (extendConnectList [counter1*2+1] == 0){
                    findFreePoint = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp [counterY][counterX] == connectNo){
                                if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMapTemp [counterY-1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX+1 < dimension && connectivityMapTemp [counterY+1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                }
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                    }
                    
                    if (findFreePoint == 0) extendConnectList [counter1*2+1] = 1;
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
            //    cout<<" connectivityMapTemp "<<counterA<<endl;
            //}
            
            remainingCheck = 0;
            
            for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                if (extendConnectList [counter1*2+1] == 0) remainingCheck = 1;
            }
            
            if (remainingCheck == 0) terminationFlag = 1;
            
            startOrder++;
            
            if (startOrder == extendConnectCount/2) startOrder = 0;
            
        } while (terminationFlag == 0);
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
        //    cout<<" connectivityMapTemp "<<counterA<<endl;
        //}
        
        int connectStatus = 0;
        int largestConnect = 0;
        int largestConnectNo = 0;
        int xPositionTempStart = 0;
        int yPositionTempStart = 0;
        int lineSize = 0;
        int constructedLineCount = 0;
        int pixelValueTemp = 0;
        int pixelAreaTemp = 0;
        int pixelValueTemp2 = 0;
        int pixelAreaTemp2 = 0;
        int pixelValueTemp3 = 0;
        int pixelAreaTemp3 = 0;
        int pixelValueTemp4 = 0;
        int pixelAreaTemp4 = 0;
        int pixelValueTemp5 = 0;
        int pixelAreaTemp5 = 0;
        int pixelValueTemp6 = 0;
        int pixelAreaTemp6 = 0;
        double averageArea = 0;
        
        for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
            connectDataExchange [extendConnectList [counter1*2]] = 0;
            connectStatus = 0;
            
            for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                if (arrayTimeSelected [counter2*10+8] == extendConnectList [counter1*2]){
                    connectStatus = arrayTimeSelected [counter2*10];
                    break;
                }
            }
            
            if (connectStatus == 1 || connectStatus == 7){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapTemp [counterY][counterX] == extendConnectList [counter1*2]) connectivityMapTemp2 [counterY][counterX] = 1;
                        else connectivityMapTemp2 [counterY][counterX] = 0;
                    }
                }
                
                //-----Zero Fill-----
                int **connectivityUpdate5 = new int *[dimension+4];
                
                for (int counter2 = 0; counter2 < dimension+4; counter2++){
                    connectivityUpdate5 [counter2] = new int [dimension+4];
                }
                
                for (int counterX = 0; counterX < dimension+4; counterX++){
                    for (int counterY = 0; counterY < dimension+4; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = connectivityMapTemp2 [counterY][counterX];
                }
                
                connectivityNumber = 0;
                
                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                        if (connectivityUpdate5 [counterY2][counterX2] == 0){
                            connectivityNumber--;
                            connectAnalysisCount = 0;
                            
                            connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                            
                            if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                                connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                            }
                            if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                            }
                            if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                            }
                            if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                        
                                        if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                            connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                            connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                            connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                            connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < dimension+2; counterA++){
                //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                //	cout<<" connectivityUpdate5 "<<counterA<<endl;
                //}
                
                int connectTemp2 = 0;
                
                if (connectivityNumber < -1){
                    int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                    
                    for (int counter2 = 0; counter2 < connectivityNumber*-1*2+5; counter2++) connectCheckArray [counter2] = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                            connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                            
                            if (connectTemp2 < -1){
                                connectTemp2 = connectTemp2*-1;
                                
                                if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                                if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                    if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                    else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                }
                            }
                        }
                    }
                    
                    int zeroFillFlag = 0;
                    
                    for (int counter2 = 2; counter2 <= connectivityNumber*-1; counter2++){
                        if (connectCheckArray [counter2*2] != 0 && connectCheckArray [counter2*2+1] == 0) zeroFillFlag = 1;
                    }
                    
                    //for (int counter3 = 1; counter3 <= connectivityNumber*-1; counter3++){
                    //    cout<<counter3<<" "<<connectCheckArray [counter3*2]<<" "<<connectCheckArray [counter3*2+1]<<" connectCheckArray"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < dimension+2; counterA++){
                    //    for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                    //    cout<<" connectivityUpdate5 "<<counterA<<endl;
                    //}
                    
                    if (zeroFillFlag == 1){
                        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                                
                                if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                            }
                        }
                        
                        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                if (connectivityUpdate5 [counterY2][counterX2] > 0) connectivityMapTemp2 [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                            }
                        }
                    }
                    
                    delete [] connectCheckArray;
                }
                
                for (int counter2 = 0; counter2 < dimension+4; counter2++) delete [] connectivityUpdate5 [counter2];
                
                delete [] connectivityUpdate5;
                //-----
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
                //    cout<<" connectivityMapTemp2 "<<counterA<<endl;
                //}
                
                //-----Connectivity analysis, For Zero-----
                connectivityNumber = -3;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapTemp2 [counterY][counterX] == 0){
                            connectivityNumber = connectivityNumber+2;
                            connectivityMapTemp2 [counterY][counterX] = connectivityNumber;
                            
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0){
                                connectivityMapTemp2 [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0){
                                connectivityMapTemp2 [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0){
                                connectivityMapTemp2 [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0){
                                connectivityMapTemp2 [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                        
                                        if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                            connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                            connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                            connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                            connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //-----Remove connectivity groups, which attach edge, extract inner part of Linked Line-----
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapTemp2 [counterY][counterX] == -1) connectivityMapTemp2 [counterY][counterX] = 0;
                    }
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapTemp2 [counterY][counterX] != 0){
                            if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                            else if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                            else if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                            else if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                        }
                    }
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapTemp2 [counterY][counterX] > 0) connectivityMapTemp2 [counterY][counterX] = 0;
                        if (connectivityMapTemp2 [counterY][counterX] < 0) connectivityMapTemp2 [counterY][counterX] = 1;
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
                //	cout<<" connectivityMapTemp2 "<<counterA<<endl;
                //}
                
                connectivityNumber = 0;
                
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                        if (connectivityMapTemp2 [counterY2][counterX2] == 0){
                            connectivityNumber--;
                            connectAnalysisCount = 0;
                            
                            connectivityMapTemp2 [counterY2][counterX2] = connectivityNumber;
                            
                            if (counterY2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2] == 0){
                                connectivityMapTemp2 [counterY2-1][counterX2] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                            }
                            if (counterX2+1 < dimension && connectivityMapTemp2 [counterY2][counterX2+1] == 0){
                                connectivityMapTemp2 [counterY2][counterX2+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                            }
                            if (counterY2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2] == 0){
                                connectivityMapTemp2 [counterY2+1][counterX2] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                            }
                            if (counterX2-1 >= 0 && connectivityMapTemp2 [counterY2][counterX2-1] == 0){
                                connectivityMapTemp2 [counterY2][counterX2-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                        
                                        if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                            connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                            connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                            connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                            connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
                //	cout<<" connectivityMapTemp2 "<<counterA<<endl;
                //}
                
                //-----Determine number of pixels-----
                connectivityNumber = connectivityNumber*-1;
                
                connectedPix = new int [connectivityNumber+50];
                for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPix [counter2] = 0;
                
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                        if (connectivityMapTemp2 [counterY2][counterX2] < -1){
                            connectedPix [connectivityMapTemp2 [counterY2][counterX2]*-1]++;
                        }
                    }
                }
                
                int **newConnectivityMapTemp = new int *[dimension+4];
                for (int counter2 = 0; counter2 < dimension+4; counter2++) newConnectivityMapTemp [counter2] = new int [dimension+4];
                
                for (int counterY = 0; counterY < dimension+4; counterY++){
                    for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
                }
                
                largestConnect = 0;
                largestConnectNo = 0;
                
                for (int counter2 = 2; counter2 <= connectivityNumber; counter2++){
                    if (connectedPix [counter2] > largestConnect){
                        largestConnect = connectedPix [counter2];
                        largestConnectNo = counter2;
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
                //	cout<<" connectivityMapTemp2 "<<counterA<<endl;
                //}
                
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                        if (connectivityMapTemp2 [counterY2][counterX2] == largestConnectNo*-1){
                            if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                                connectivityMapTemp2 [counterY2-1][counterX2-1] = 0;
                            }
                            if (counterY2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                                connectivityMapTemp2 [counterY2-1][counterX2] = 0;
                            }
                            if (counterY2-1 >= 0 && counterX2+1 < dimension && connectivityMapTemp2 [counterY2-1][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                                connectivityMapTemp2 [counterY2-1][counterX2+1] = 0;
                            }
                            if (counterX2+1 < dimension && connectivityMapTemp2 [counterY2][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                                connectivityMapTemp2 [counterY2][counterX2+1] = 0;
                            }
                            if (counterY2+1 < dimension && counterX2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                                connectivityMapTemp2 [counterY2+1][counterX2+1] = 0;
                            }
                            if (counterY2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                                connectivityMapTemp2 [counterY2+1][counterX2] = 0;
                            }
                            if (counterY2+1 < dimension && counterX2-1 >= 0 && connectivityMapTemp2 [counterY2+1][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                                connectivityMapTemp2 [counterY2+1][counterX2-1] = 0;
                            }
                            if (counterX2-1 >= 0 && connectivityMapTemp2 [counterY2][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                                connectivityMapTemp2 [counterY2][counterX2-1] = 0;
                            }
                        }
                    }
                }
                
                delete [] connectedPix;
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<newConnectivityMapTemp [counterA][counterB];
                //	cout<<" newConnectivityMapTemp "<<counterA<<endl;
                //}
                
                xPositionTempStart = 0;
                yPositionTempStart = 0;
                lineSize = 0;
                
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                        if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                            connectivityMapTemp2 [counterY2][counterX2] = 1;
                            
                            xPositionTempStart = counterX2;
                            yPositionTempStart = counterY2;
                            lineSize++;
                        }
                        else connectivityMapTemp2 [counterY2][counterX2] = 0;
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
                //	cout<<" connectivityMapTemp2 "<<counterA<<endl;
                //}
                
                for (int counter2 = 0; counter2 < dimension+4; counter2++) delete [] newConnectivityMapTemp [counter2];
                delete [] newConnectivityMapTemp;
                
                constructedLineCount = 0;
                
                int *arrayNewLines = new int [lineSize*2+50];
                
                connectivityMapTemp2 [yPositionTempStart][xPositionTempStart] = -1;
                arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                
                do{
                    
                    findFlag = 0;
                    terminationFlag = 0;
                    
                    if (xPositionTempStart+1 < dimension){
                        if (connectivityMapTemp2 [yPositionTempStart][xPositionTempStart+1] == 1){
                            connectivityMapTemp2 [yPositionTempStart][xPositionTempStart+1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                        if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                            connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    if (yPositionTempStart+1 < dimension && findFlag == 0){
                        if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart] == 1){
                            connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                            yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                        if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                            connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    if (xPositionTempStart-1 >= 0 && findFlag == 0){
                        if (connectivityMapTemp2 [yPositionTempStart][xPositionTempStart-1] == 1){
                            connectivityMapTemp2 [yPositionTempStart][xPositionTempStart-1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                        if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                            connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    if (yPositionTempStart-1 >= 0 && findFlag == 0){
                        if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart] == 1){
                            connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                            yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                        }
                    }
                    if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                        if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                            connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                        }
                    }
                    
                } while (terminationFlag == 1);
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapTemp2 [counterY][counterX] == -1) connectivityMapTemp2 [counterY][counterX] = 1;
                    }
                }
                
                connectivityNumber = -3;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapTemp2 [counterY][counterX] == 0){
                            connectivityNumber = connectivityNumber+2;
                            connectivityMapTemp2 [counterY][counterX] = connectivityNumber;
                            
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0){
                                connectivityMapTemp2 [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0){
                                connectivityMapTemp2 [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0){
                                connectivityMapTemp2 [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0){
                                connectivityMapTemp2 [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                        
                                        if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                            connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                            connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                            connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                            connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapTemp2 [counterY][counterX] == -1) connectivityMapTemp2 [counterY][counterX] = 0;
                    }
                }
                
                for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                    if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate expandFluorescentOutlineUpDate];
                    }
                    
                    expandFluorescentOutline [expandFluorescentOutlineCount] = arrayNewLines [counter2*2], expandFluorescentOutlineCount++;
                    expandFluorescentOutline [expandFluorescentOutlineCount] = arrayNewLines [counter2*2+1], expandFluorescentOutlineCount++;
                    expandFluorescentOutline [expandFluorescentOutlineCount] = extendConnectList [counter1*2], expandFluorescentOutlineCount++;
                    expandFluorescentOutline [expandFluorescentOutlineCount] = 1, expandFluorescentOutlineCount++;
                }
                
                if (fluorescentEntryCount >= 2){
                    for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate expandFluorescentOutlineUpDate];
                        }
                        
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayNewLines [counter2*2], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayNewLines [counter2*2+1], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = extendConnectList [counter1*2], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = 2, expandFluorescentOutlineCount++;
                    }
                }
                
                if (fluorescentEntryCount >= 3){
                    for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate expandFluorescentOutlineUpDate];
                        }
                        
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayNewLines [counter2*2], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayNewLines [counter2*2+1], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = extendConnectList [counter1*2], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = 3, expandFluorescentOutlineCount++;
                    }
                }
                
                if (fluorescentEntryCount >= 4){
                    for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate expandFluorescentOutlineUpDate];
                        }
                        
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayNewLines [counter2*2], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayNewLines [counter2*2+1], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = extendConnectList [counter1*2], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = 4, expandFluorescentOutlineCount++;
                    }
                }
                
                if (fluorescentEntryCount >= 5){
                    for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate expandFluorescentOutlineUpDate];
                        }
                        
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayNewLines [counter2*2], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayNewLines [counter2*2+1], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = extendConnectList [counter1*2], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = 5, expandFluorescentOutlineCount++;
                    }
                }
                
                if (fluorescentEntryCount >= 6){
                    for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate expandFluorescentOutlineUpDate];
                        }
                        
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayNewLines [counter2*2], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayNewLines [counter2*2+1], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = extendConnectList [counter1*2], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = 6, expandFluorescentOutlineCount++;
                    }
                }
                
                delete [] arrayNewLines;
                
                pixelValueTemp = 0;
                pixelAreaTemp = 0;
                pixelValueTemp2 = 0;
                pixelAreaTemp2 = 0;
                pixelValueTemp3 = 0;
                pixelAreaTemp3 = 0;
                pixelValueTemp4 = 0;
                pixelAreaTemp4 = 0;
                pixelValueTemp5 = 0;
                pixelAreaTemp5 = 0;
                pixelValueTemp6 = 0;
                pixelAreaTemp6 = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapTemp2 [counterY][counterX] != 0){
                            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                if (fluorescentEntryCount >= 1){
                                    if (fluorescentCutOff1 >= fluorescentMap1 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap1 [counterX+horizontalStart][counterX+horizontalStart];
                                    pixelAreaTemp++;
                                }
                                if (fluorescentEntryCount >= 2){
                                    if (fluorescentCutOff2 >= fluorescentMap2 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp2 = pixelValueTemp2+fluorescentMap2 [counterX+horizontalStart][counterX+horizontalStart];
                                    pixelAreaTemp2++;
                                }
                                if (fluorescentEntryCount >= 3){
                                    if (fluorescentCutOff3 >= fluorescentMap3 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp3 = pixelValueTemp3+fluorescentMap3 [counterX+horizontalStart][counterX+horizontalStart];
                                    pixelAreaTemp3++;
                                }
                                if (fluorescentEntryCount >= 4){
                                    if (fluorescentCutOff4 >= fluorescentMap4 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp4 = pixelValueTemp3+fluorescentMap4 [counterX+horizontalStart][counterX+horizontalStart];
                                    pixelAreaTemp4++;
                                }
                                if (fluorescentEntryCount >= 5){
                                    if (fluorescentCutOff5 >= fluorescentMap5 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp5 = pixelValueTemp3+fluorescentMap5 [counterX+horizontalStart][counterX+horizontalStart];
                                    pixelAreaTemp5++;
                                }
                                if (fluorescentEntryCount >= 6){
                                    if (fluorescentCutOff6 >= fluorescentMap6 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp6 = pixelValueTemp3+fluorescentMap6 [counterX+horizontalStart][counterX+horizontalStart];
                                    pixelAreaTemp6++;
                                }
                            }
                        }
                    }
                }
                
                averageArea = pixelValueTemp/(double)pixelAreaTemp;
                
                if (expandFluorescentDataCount+20 > expandFluorescentDataLimit){
                    fileUpdate = [[FileUpdate alloc] init];
                    [fileUpdate expandFluorescentDataUpDate];
                }
                
                expandFluorescentData [expandFluorescentDataCount] = extendConnectList [counter1*2], expandFluorescentDataCount++;
                expandFluorescentData [expandFluorescentDataCount] = 1, expandFluorescentDataCount++;
                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp, expandFluorescentDataCount++;
                
                if (fluorescentEntryCount >= 2){
                    averageArea = pixelValueTemp2/(double)pixelAreaTemp2;
                    
                    expandFluorescentData [expandFluorescentDataCount] = extendConnectList [counter1*2], expandFluorescentDataCount++;
                    expandFluorescentData [expandFluorescentDataCount] = 2, expandFluorescentDataCount++;
                    expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                    expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp2, expandFluorescentDataCount++;
                }
                
                if (fluorescentEntryCount >= 3){
                    averageArea = pixelValueTemp3/(double)pixelAreaTemp3;
                    
                    expandFluorescentData [expandFluorescentDataCount] = extendConnectList [counter1*2], expandFluorescentDataCount++;
                    expandFluorescentData [expandFluorescentDataCount] = 3, expandFluorescentDataCount++;
                    expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                    expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp3, expandFluorescentDataCount++;
                }
                
                if (fluorescentEntryCount >= 4){
                    averageArea = pixelValueTemp4/(double)pixelAreaTemp4;
                    
                    expandFluorescentData [expandFluorescentDataCount] = extendConnectList [counter1*2], expandFluorescentDataCount++;
                    expandFluorescentData [expandFluorescentDataCount] = 4, expandFluorescentDataCount++;
                    expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                    expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp4, expandFluorescentDataCount++;
                }
                
                if (fluorescentEntryCount >= 5){
                    averageArea = pixelValueTemp5/(double)pixelAreaTemp5;
                    
                    expandFluorescentData [expandFluorescentDataCount] = extendConnectList [counter1*2], expandFluorescentDataCount++;
                    expandFluorescentData [expandFluorescentDataCount] = 5, expandFluorescentDataCount++;
                    expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                    expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp5, expandFluorescentDataCount++;
                }
                
                if (fluorescentEntryCount >= 6){
                    averageArea = pixelValueTemp6/(double)pixelAreaTemp6;
                    
                    expandFluorescentData [expandFluorescentDataCount] = extendConnectList [counter1*2], expandFluorescentDataCount++;
                    expandFluorescentData [expandFluorescentDataCount] = 6, expandFluorescentDataCount++;
                    expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                    expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp6, expandFluorescentDataCount++;
                }
            }
        }
        
        delete [] extendConnectList;
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            delete [] connectivityMapTemp [counter1];
            delete [] connectivityMapTemp2 [counter1];
        }
        
        delete [] connectivityMapTemp;
        delete [] connectivityMapTemp2;
        
        delete [] connectAnalysisX;
        delete [] connectAnalysisY;
        delete [] connectAnalysisTempX;
        delete [] connectAnalysisTempY;
        
        for (int counter2 = 0; counter2 < dimension+4; counter2++){
            delete [] rangeMatrix [counter2];
        }
        
        delete [] rangeMatrix;
        
        delete [] findConnectNo;
    }
    else processResults = 1;
    
    delete [] findReviseConnect;
    
    return processResults;
}

-(IBAction)listOnOff:(id)sender{
    if (trackingOn == 1 || trackingOn == 3){
        if (timeOneStatus == 0){
            if (queueHoldingStatus == 0){
                if (tableListSwitch == 1 && doneListCount > 0 && listOnOffFlag == 0){
                    if (listOnOffFlag == 0){
                        listOnOffFlag = 1;
                    }
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    listCrickMonitor = 1;
                }
                else if (tableListSwitch == 2 && queueListCount > 0 && listOnOffFlag == 0){
                    if (listOnOffFlag == 0){
                        listOnOffFlag = 1;
                    }
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    listCrickMonitor = 1;
                }
                else if (listOnOffFlag == 1){
                    listOnOffFlag = 0;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    listCrickMonitor = 1;
                }
                else{
                    
                    if (tableListSwitch != 1 && tableListSwitch != 2){
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"No Check List/Queue Mode"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Auto Processing On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time One On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)listDataUploading{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        listLoadingProcessing = 1;
        
        string cellLineageExtract = listLingCurrent.substr(1);
        string cellNoExtract = listCellCurrent.substr(1);
        int lineageAmendTemp = atoi(cellLineageExtract.c_str());
        int cellAmendTemp = atoi(cellNoExtract.c_str());
        int lineageEntryStart = 0;
        int lineageEntryEnd = 0;
        
        for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
            if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp && arrayLineageStartEnd [counter1*8+1] == cellAmendTemp){
                lineageEntryStart = arrayLineageStartEnd [counter1*8+4];
                lineageEntryEnd = arrayLineageStartEnd [counter1*8+6];
                break;
            }
        }
        
        //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
        //	cout<<" arrayLineageData "<<counterA<<endl;
        //}
        
        int *cellExtractedInfo = new int [imageEndHold*8+50], cellExtractedInfoCount = 0;
        
        for (int counter1 = lineageEntryStart; counter1 <= lineageEntryEnd; counter1++){
            cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8], cellExtractedInfoCount++;
            cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+1], cellExtractedInfoCount++;
            cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+2], cellExtractedInfoCount++;
            cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+3], cellExtractedInfoCount++;
            cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+4], cellExtractedInfoCount++;
            cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+5], cellExtractedInfoCount++;
            cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+6], cellExtractedInfoCount++;
            cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+7], cellExtractedInfoCount++;
        }
        
        int *listDisplayDataTarget = new int [10000];
        int listDisplayDataTargetCount = 0;
        int listDisplayDataTargetLimit = 10000;
        
        int entryCount = 0;
        int imagePositionData = 0;
        int connectNo = 0;
        int targetCenterX = 0;
        int targetCenterY = 0;
        int listDisplayDataCount = 0;
        int listDisplayGCCount = 0;
        int stepCount = 0;
        int targetDiffX = 0;
        int targetDiffY = 0;
        int finData [17];
        int checkFlag = 0;
        int readingError = 0;
        
        long sizeForCopy = 0;
        long size1 = 0;
        long size2 = 0;
        
        unsigned long readPosition = 0;
        
        string imagePositionString;
        string connectDataPath;
        
        struct stat sizeOfFile;
        
        ifstream fin;
        
        for (int counter1 = 0; counter1 < cellExtractedInfoCount/8; counter1++){
            imagePositionData = cellExtractedInfo [counter1*8+2];
            
            connectNo = 0;
            targetCenterX = 0;
            targetCenterY = 0;
            entryCount++;
            
            if (imagePositionData != 0){
                imagePositionString = to_string(imagePositionData);
                
                if (imagePositionString.length() == 1) imagePositionString = "000"+imagePositionString;
                else if (imagePositionString.length() == 2) imagePositionString = "00"+imagePositionString;
                else if (imagePositionString.length() == 3) imagePositionString = "0"+imagePositionString;
                
                connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+imagePositionString+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                
                size1 = 0;
                size2 = 0;
                checkFlag = 0;
                readingError = 0;
                
                for (int counter3 = 0; counter3 < 6; counter3++){
                    sizeForCopy = 0;
                    
                    if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter3 == 0) size1 = sizeForCopy;
                        else if (counter3 == 1) size2 = sizeForCopy;
                        else if (counter3 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter3 == 3) size1 = sizeForCopy;
                        else if (counter3 == 4) size2 = sizeForCopy;
                        else if (counter3 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                int *listDisplayData = new int [sizeForCopy+50];
                listDisplayDataCount = 0;
                int *listDisplayGC = new int [sizeForCopy+50];
                listDisplayGCCount = 0;
                
                if (checkFlag == 1){
                    fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                    readingError = 1;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        if (readingError == 0){
                            readPosition = 0;
                            stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                    finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                    finData [9] = uploadTemp [readPosition], readPosition++;
                                    finData [10] = uploadTemp [readPosition], readPosition++;
                                    finData [11] = uploadTemp [readPosition], readPosition++;
                                    finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                    finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                    finData [14] = uploadTemp [readPosition], readPosition++;
                                    finData [15] = uploadTemp [readPosition], readPosition++;
                                    finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                    
                                    if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                    else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                    
                                    finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                    else{
                                        
                                        listDisplayData [listDisplayDataCount] = finData [1], listDisplayDataCount++;
                                        listDisplayData [listDisplayDataCount] = finData [3], listDisplayDataCount++;
                                        listDisplayData [listDisplayDataCount] = finData [4], listDisplayDataCount++;
                                        listDisplayData [listDisplayDataCount] = finData [7], listDisplayDataCount++;
                                        listDisplayData [listDisplayDataCount] = finData [12], listDisplayDataCount++;
                                        listDisplayData [listDisplayDataCount] = finData [13], listDisplayDataCount++;
                                        listDisplayData [listDisplayDataCount] = finData [16], listDisplayDataCount++;
                                    }
                                }
                                else if (stepCount == 1){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++;
                                    finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                    finData [8] = uploadTemp [readPosition], readPosition++;
                                    finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                    finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                    
                                    finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                    finData [9] = finData [8]*256+finData [9];
                                    
                                    if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                }
                                else if (stepCount == 2){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [4] = uploadTemp [readPosition], readPosition++;
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                    finData [8] = uploadTemp [readPosition], readPosition++;
                                    finData [9] = uploadTemp [readPosition], readPosition++;
                                    finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                    finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                    finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                    else{
                                        
                                        listDisplayGC [listDisplayGCCount] = finData [1], listDisplayGCCount++;
                                        listDisplayGC [listDisplayGCCount] = finData [3], listDisplayGCCount++;
                                        listDisplayGC [listDisplayGCCount] = finData [6], listDisplayGCCount++;
                                        listDisplayGC [listDisplayGCCount] = finData [7], listDisplayGCCount++;
                                        listDisplayGC [listDisplayGCCount] = finData [10], listDisplayGCCount++;
                                        listDisplayGC [listDisplayGCCount] = finData [11], listDisplayGCCount++;
                                    }
                                }
                                
                            } while (stepCount != 3);
                        }
                        
                        delete [] uploadTemp;
                    }
                }
                
                //for (int counterA = 0; counterA < listDisplayGCCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<listDisplayGC [counterA*6+counterB];
                //	cout<<" listDisplayGC "<<counterA<<endl;
                //}
                
                if (checkFlag == 1 && readingError == 0){
                    for (int counter2 = 0; counter2 < listDisplayDataCount/7; counter2++){
                        if (listDisplayData [counter2*7+6] == lineageAmendTemp && listDisplayData [counter2*7+4] == cellAmendTemp){
                            if (listDisplayDataTargetCount+6 > listDisplayDataTargetLimit){
                                int *arrayUpDate = new int [listDisplayDataTargetCount+10];
                                
                                for (int counter3 = 0; counter3 < listDisplayDataTargetCount; counter3++) arrayUpDate [counter3] = listDisplayDataTarget [counter3];
                                
                                delete [] listDisplayDataTarget;
                                listDisplayDataTarget = new int [listDisplayDataTargetLimit+10000];
                                listDisplayDataTargetLimit = listDisplayDataTargetLimit+10000;
                                
                                for (int counter3 = 0; counter3 < listDisplayDataTargetCount; counter3++) listDisplayDataTarget [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            listDisplayDataTarget [listDisplayDataTargetCount] = listDisplayData [counter2*7], listDisplayDataTargetCount++;
                            listDisplayDataTarget [listDisplayDataTargetCount] = listDisplayData [counter2*7+1], listDisplayDataTargetCount++;
                            listDisplayDataTarget [listDisplayDataTargetCount] = imagePositionData, listDisplayDataTargetCount++;
                            listDisplayDataTarget [listDisplayDataTargetCount] = entryCount, listDisplayDataTargetCount++;
                            listDisplayDataTarget [listDisplayDataTargetCount] = cellExtractedInfo [counter1*8+3], listDisplayDataTargetCount++;
                            
                            connectNo = listDisplayData [counter2*7+3];
                        }
                    }
                    
                    //for (int counterA = 0; counterA < listDisplayDataTargetCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<listDisplayDataTarget [counterA*3+counterB];
                    //	cout<<" listDisplayDataTarget "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < listDisplayDataTargetCount/4; counterA++){
                    //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<listDisplayDataTarget [counterA*4+counterB];
                    //	cout<<" listDisplayDataTarget "<<counterA<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < listDisplayGCCount/6; counter2++){
                        if (listDisplayGC [counter2*6+4] == connectNo){
                            targetCenterX = listDisplayGC [counter2*6];
                            targetCenterY = listDisplayGC [counter2*6+1];
                            break;
                        }
                    }
                    
                    targetDiffX = 50-targetCenterX;
                    targetDiffY = 50-targetCenterY;
                    
                    for (int counter2 = 0; counter2 < listDisplayDataTargetCount/5; counter2++){
                        if (imagePositionData == listDisplayDataTarget [counter2*5+2]){
                            listDisplayDataTarget [counter2*5] = targetCenterX+(listDisplayDataTarget [counter2*5]-targetCenterX)+targetDiffX;
                            listDisplayDataTarget [counter2*5+1] = targetCenterY+(listDisplayDataTarget [counter2*5+1]-targetCenterY)+targetDiffY;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < listDisplayDataTargetCount/4; counterA++){
                    //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<listDisplayDataTarget [counterA*4+counterB];
                    //	cout<<" listDisplayDataTarget "<<counterA<<endl;
                    //}
                }
                
                delete [] listDisplayData;
                delete [] listDisplayGC;
                
                if (checkFlag == 0 || readingError == 1){
                    break;
                }
            }
        }
        
        double maxRatio = 1;
        double ratio = 1;
        double longestLine = 0;
        double referenceLine = 0;
        double constTempA = 0;
        double constTempB = 0;
        double longestX = 0;
        double longestY = 0;
        
        int dataTempX = 0;
        int dataTempY = 0;
        
        for (int counter1 = 0; counter1 < listDisplayDataTargetCount/5; counter1++){
            dataTempX = listDisplayDataTarget [counter1*5];
            dataTempY = listDisplayDataTarget [counter1*5+1];
            
            if (dataTempX < 2 || dataTempX > 98 || dataTempY < 2 || dataTempY > 98){
                longestLine = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                
                if (dataTempX < 0 && dataTempY == 50){
                    referenceLine = 48;
                    ratio = longestLine/(double)referenceLine;
                }
                else if (dataTempX < 0 && dataTempY > 0 && dataTempY < 50){
                    constTempA = (50-dataTempY)/(double)(50-dataTempX);
                    constTempB = 50-constTempA*50;
                    longestX = 2;
                    longestY = constTempA*2+constTempB;
                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                    ratio = longestLine/(double)referenceLine;
                }
                else if (dataTempX < 0 && dataTempY < 0){
                    longestX = 2;
                    longestY = 2;
                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                    ratio = longestLine/(double)referenceLine;
                }
                else if (dataTempX > 0 && dataTempX < 50 && dataTempY < 0){
                    constTempA = (50-dataTempY)/(double)(50-dataTempX);
                    constTempB = 50-constTempA*50;
                    longestX = (2-constTempB)/(double)constTempA;
                    longestY = 2;
                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                    ratio = longestLine/(double)referenceLine;
                }
                else if (dataTempX == 50 && dataTempY < 0){
                    referenceLine = 48;
                    ratio = longestLine/(double)referenceLine;
                }
                else if (dataTempX > 50 && dataTempX < 100 && dataTempY < 0){
                    constTempA = (50-dataTempY)/(double)(50-dataTempX);
                    constTempB = 50-constTempA*50;
                    longestX = (2-constTempB)/(double)constTempA;
                    longestY = 2;
                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                    ratio = longestLine/(double)referenceLine;
                }
                else if (dataTempX > 100 && dataTempY < 0){
                    longestX = 98;
                    longestY = 2;
                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                    ratio = longestLine/(double)referenceLine;
                }
                else if (dataTempX > 100 && dataTempY > 0 && dataTempY < 50){
                    constTempA = (50-dataTempY)/(double)(50-dataTempX);
                    constTempB = 50-constTempA*50;
                    longestX = 98;
                    longestY = constTempA*98+constTempB;
                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                    ratio = longestLine/(double)referenceLine;
                }
                else if (dataTempX == 50 && dataTempY > 100){
                    referenceLine = 48;
                    ratio = longestLine/(double)referenceLine;
                }
                else if (dataTempX > 100 && dataTempY > 50 && dataTempY < 100){
                    constTempA = (50-dataTempY)/(double)(50-dataTempX);
                    constTempB = 50-constTempA*50;
                    longestX = 98;
                    longestY = constTempA*98+constTempB;
                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                    ratio = longestLine/(double)referenceLine;
                }
                else if (dataTempX > 100 && dataTempY > 100){
                    longestX = 98;
                    longestY = 98;
                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                    ratio = longestLine/(double)referenceLine;
                }
                else if (dataTempX > 50 && dataTempX < 100 && dataTempY > 100){
                    constTempA = (50-dataTempY)/(double)(50-dataTempX);
                    constTempB = 50-constTempA*50;
                    longestX = (98-constTempB)/(double)constTempA;
                    longestY = 98;
                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                    ratio = longestLine/(double)referenceLine;
                }
                else if (dataTempX == 50 && dataTempY > 100){
                    referenceLine = 48;
                    ratio = longestLine/(double)referenceLine;
                }
                else if (dataTempX > 0 && dataTempX < 50 && dataTempY > 100){
                    constTempA = (50-dataTempY)/(double)(50-dataTempX);
                    constTempB = 50-constTempA*50;
                    longestX = (98-constTempB)/(double)constTempA;
                    longestY = 98;
                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                    ratio = longestLine/(double)referenceLine;
                }
                else if (dataTempX < 0 && dataTempY > 100){
                    referenceLine = 48;
                    ratio = longestLine/(double)referenceLine;
                }
                else if (dataTempX < 0 && dataTempY > 50 && dataTempY < 100){
                    constTempA = (50-dataTempY)/(double)(50-dataTempX);
                    constTempB = 50-constTempA*50;
                    longestX = 2;
                    longestY = 2*constTempA+constTempB;
                    referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                    ratio = longestLine/(double)referenceLine;
                }
                
                //cout<<counter1<<" "<<referenceLine<<" "<<longestLine<<" "<<ratio<<" LineInfo"<<endl;
                
                if (maxRatio < ratio) maxRatio = ratio;
            }
        }
        
        //cout<<maxRatio<<" MaxRatio"<<endl;
        
        if (checkFlag == 1 && readingError == 0){
            if (listPatternStatus == 1) delete [] arrayListPattern;
            arrayListPattern = new int [listDisplayDataTargetCount+100];
            listPatternCount = 0;
            listPatternStatus = 1;
            
            if (maxRatio > 1){
                for (int counter1 = 0; counter1 < listDisplayDataTargetCount/5; counter1++){
                    dataTempX = listDisplayDataTarget [counter1*5];
                    dataTempY = listDisplayDataTarget [counter1*5+1];
                    
                    if (dataTempX < 50 && dataTempY == 50){
                        dataTempX = 50-(int)((50-dataTempX)/(double)maxRatio);
                        dataTempY = 50;
                    }
                    
                    if (dataTempX < 50 && dataTempY < 50){
                        dataTempX = 50-(int)((50-dataTempX)/(double)maxRatio);
                        dataTempY = 50-(int)((50-dataTempY)/(double)maxRatio);
                    }
                    
                    if (dataTempX == 50 && dataTempY < 50){
                        dataTempX = 50;
                        dataTempY = 50-(int)((50-dataTempY)/(double)maxRatio);
                    }
                    
                    if (dataTempX > 50 && dataTempY < 50){
                        dataTempX = 50+(int)((dataTempX-50)/(double)maxRatio);
                        dataTempY = 50-(int)((50-dataTempY)/(double)maxRatio);
                    }
                    
                    if (dataTempX == 50 && dataTempY > 50){
                        dataTempX = 50+(int)((dataTempX-50)/(double)maxRatio);
                        dataTempY = 50;
                    }
                    
                    if (dataTempX > 50 && dataTempY > 50){
                        dataTempX = 50+(int)((dataTempX-50)/(double)maxRatio);
                        dataTempY = 50+(int)((dataTempY-50)/(double)maxRatio);
                    }
                    
                    if (dataTempX > 50 && dataTempY == 50){
                        dataTempX = 50;
                        dataTempY = 50+(int)((dataTempY-50)/(double)maxRatio);
                    }
                    
                    if (dataTempX < 50 && dataTempY > 50){
                        dataTempX = 50-(int)((50-dataTempX)/(double)maxRatio);
                        dataTempY = 50+(int)((dataTempY-50)/(double)maxRatio);
                    }
                    
                    arrayListPattern [listPatternCount] = dataTempX, listPatternCount++;
                    arrayListPattern [listPatternCount] = dataTempY, listPatternCount++;
                    arrayListPattern [listPatternCount] = listDisplayDataTarget [counter1*5+2], listPatternCount++;
                    arrayListPattern [listPatternCount] = listDisplayDataTarget [counter1*5+3], listPatternCount++;
                    arrayListPattern [listPatternCount] = listDisplayDataTarget [counter1*5+4], listPatternCount++;
                }
            }
            else{
                
                for (int counter1 = 0; counter1 < listDisplayDataTargetCount/5; counter1++){
                    arrayListPattern [listPatternCount] = listDisplayDataTarget [counter1*5], listPatternCount++;
                    arrayListPattern [listPatternCount] = listDisplayDataTarget [counter1*5+1], listPatternCount++;
                    arrayListPattern [listPatternCount] = listDisplayDataTarget [counter1*5+2], listPatternCount++;
                    arrayListPattern [listPatternCount] = listDisplayDataTarget [counter1*5+3], listPatternCount++;
                    arrayListPattern [listPatternCount] = listDisplayDataTarget [counter1*5+4], listPatternCount++;
                }
            }
            
            //for (int counterA = 0; counterA < cellListCount/4; counterA++){
            //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayCellListDisplay [counterA*4+counterB];
            //	cout<<" arrayCellListDisplay "<<counterA<<endl;
            //}
            
            self->listLoadingStart = 3;
            listLoadingProcessing = 0;
        }
        
        delete [] cellExtractedInfo;
        delete [] listDisplayDataTarget;
    });
}

-(IBAction)stepperAction:(id)sender{
    if (trackingOn != 0){
        if ([stepperLimit intValue] >= 20 && [stepperLimit intValue] <= 240){
            [stepperValueDisplay setIntValue:[stepperLimit intValue]];
            cutLimitValueHold = [stepperLimit intValue];
            
            cutDisplayValueHold = cutLimitValueHold;
            verificationPositionCall = 0;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)controlTextDidChange:(NSNotification *)aNotification {
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]) {
        if ([aNotification object] == stepperValueDisplay){
            if ([stepperValueDisplay intValue] >= 20 && [stepperValueDisplay intValue] <= 240){
                [stepperLimit setIntValue:[stepperValueDisplay intValue]];
                cutLimitValueHold = [stepperValueDisplay intValue];
                
                cutDisplayValueHold = cutLimitValueHold;
                verificationPositionCall = 0;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
            }
        }
    }
}

-(IBAction)forceAreaSet:(id)sender{
    if (timeOneStatus == 0 && trackingOn == 3 && firstModificationPoint != 10000 && divisionTypeHold == 0 && fusionOperation == 0){
        if (mainSavingInProgress == 0 && cleaningProgress == 0){
            forceSetStatus = 1;
            int processType = 1;
            
            lineSet = [[LineSet alloc] init];
            [lineSet lineSetProcess:processType];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking Mode Off or Div-Fusion Setting On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageSeqStart:(id)sender{
    if (trackingOn == 1 || trackingOn == 3){
        if (timeOneStatus == 0){
            if (queueHoldingStatus == 0){
                if (imageSeqOperation == 0){
                    imageSeqOperation = 1;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageSequenceDisplayController object:self];
                }
                if (imageSeqOperation == 2) imageSeqOperation = 3;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Auto Processing On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time One On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)fluorescentDisplayMode:(id)sender{
    if (trackingOn == 1 || trackingOn == 3){
        if (timeOneStatus == 0){
            if (queueHoldingStatus == 0){
                if (fluorescentDisplayMode == 0){
                    fluorescentDisplayMode = 1;
                    [fluorescentModeDisplay setStringValue:@"Range"];
                    
                    fluorescentDisplayMax = [fluorescentMaxDisplay integerValue];
                    
                    if (fluorescentDisplayMax > 255 || fluorescentDisplayMax < 50){
                        fluorescentDisplayMax = 255;
                        [fluorescentMaxDisplay setStringValue:@"255"];
                    }
                }
                else{
                    
                    fluorescentDisplayMode = 0;
                    [fluorescentModeDisplay setStringValue:@"Row"];
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Auto Processing On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time One On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)fluorescentDisplayStep:(id)sender{
    if (fluorescentDisplayRange == 2){
        fluorescentDisplayRange = 3;
        [fluorescentRangeDiv setStringValue:@"3"];
    }
    else if (fluorescentDisplayRange == 3){
        fluorescentDisplayRange = 4;
        [fluorescentRangeDiv setStringValue:@"4"];
    }
    else if (fluorescentDisplayRange == 4){
        fluorescentDisplayRange = 2;
        [fluorescentRangeDiv setStringValue:@"2"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(void)dealloc{
    if (trackControlTimer) [trackControlTimer invalidate];
    if (trackWindowTimer) [trackWindowTimer invalidate];
    if (navigationWindowTimer) [navigationWindowTimer invalidate];
    if (listWindowTimer) [listWindowTimer invalidate];
    if (trackControlTimer2) [trackControlTimer2 invalidate];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToTrackingController object:nil];
}

@end
