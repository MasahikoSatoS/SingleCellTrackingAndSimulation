//
//  DoneOthersSort.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-03-31.
//

#import "DoneOthersSort.h"

@implementation DoneOthersSort

-(IBAction)organizeList:(id)sender{
    //==========Organize order treatment (from largest), Status (Check/OK), Lineage NO, Cell no==========
    
    if (tableListSwitch == 1 && trackingOn == 1 && mainSavingInProgress == 0 && cleaningProgress == 0){
        if (doneListCount/5 != 0){
            string *newDoneList = new string [doneListCount+10];
            int newDoneListCount = 0;
            string *currentDoneList = new string [doneListCount+10];
            int currentDoneListCount = 0;
            string *treatmentDone = new string [doneListCount*2+10];
            int treatmentDoneCount = 0;
            string *statusDone = new string [doneListCount+10];
            int statusDoneCount = 0;
            string *lineageDone = new string [doneListCount+10];
            int lineageDoneCount = 0;
            int *entryNumberList = new int [100];
            
            for (int counter1 = 0; counter1 < doneListCount; counter1++) currentDoneList [currentDoneListCount] = arrayDoneList [counter1], currentDoneListCount++;
            
            //for (int counterA = 0; counterA < doneListCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
            //    cout<<" arrayDoneList "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < currentDoneListCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<currentDoneList [counterA*5+counterB];
            //    cout<<" currentDoneList "<<counterA<<endl;
            //}
            
            string treatmentEntry;
            string entryString;
            int entryCount = 0;
            int terminationFlag = 0;
            int entryNumber = 0;
            int findFlag = 0;
            
            do{
                
                terminationFlag = 0;
                entryNumber = 0;
                findFlag = 0;
                treatmentEntry = "";
                
                for (int counter1 = 0; counter1 < currentDoneListCount/5; counter1++){
                    if (currentDoneList [counter1*5] != "" && findFlag == 0){
                        treatmentEntry = currentDoneList [counter1*5];
                        findFlag = 1;
                        entryCount++;
                        entryNumber++;
                        
                        entryString = to_string(entryCount);
                        
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+1], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+2], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+3], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+4], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = entryString, treatmentDoneCount++;
                        
                        currentDoneList [counter1*5] = "";
                    }
                    else if (currentDoneList [counter1*5] != "" && findFlag == 1 && currentDoneList [counter1*5] == treatmentEntry){
                        entryNumber++;
                        
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+1], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+2], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+3], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+4], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = entryString, treatmentDoneCount++;
                        
                        currentDoneList [counter1*5] = "";
                    }
                }
                
                if (findFlag == 0) terminationFlag = 1;
                else entryNumberList [entryCount] = entryNumber;
                
            } while (terminationFlag == 0);
            
            //for (int counterA = 0; counterA < currentDoneListCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<currentDoneList [counterA*5+counterB];
            //    cout<<" currentDoneList "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < treatmentDoneCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<treatmentDone [counterA*6+counterB];
            //    cout<<" treatmentDone "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < entryCount; counterA++){
            //    cout<<counterA<<" "<<entryNumberList [counterA]<<" List"<<endl;
            //}
            
            string treatmentNo;
            int largestEntryNumber = 0;
            int largestEntryPosition = 0;
            int findFlag2 = 0;
            int roundCount = 0;
            int terminationFlag2 = 0;
            int smallestLineageNo = 0;
            int terminationFlag3 = 0;
            int smallestCellNo = 0;
            
            do{
                
                terminationFlag = 0;
                largestEntryNumber = 0;
                largestEntryPosition = 0;
                
                for (int counter1 = 1; counter1 <= entryCount; counter1++){
                    if (largestEntryNumber < entryNumberList [counter1]){
                        largestEntryNumber = entryNumberList [counter1];
                        largestEntryPosition = counter1;
                    }
                }
                
                if (largestEntryPosition == 0) terminationFlag = 1;
                else{
                    
                    entryNumberList [largestEntryPosition] = 0;
                    findFlag2 = 0;
                    roundCount = 0;
                    
                    do {
                        
                        statusDoneCount = 0;
                        
                        for (int counter1 = 0; counter1 < treatmentDoneCount/6; counter1++){
                            treatmentNo = treatmentDone [counter1*6+5];
                            
                            if ((roundCount == 0 && atoi(treatmentNo.c_str()) == largestEntryPosition && treatmentDone [counter1*6+4] != "OK") || (roundCount == 1 && atoi(treatmentNo.c_str()) == largestEntryPosition && treatmentDone [counter1*6+4] == "OK")){
                                findFlag2 = 1;
                                statusDone [statusDoneCount] = treatmentDone [counter1*6], statusDoneCount++;
                                statusDone [statusDoneCount] = treatmentDone [counter1*6+1], statusDoneCount++;
                                statusDone [statusDoneCount] = treatmentDone [counter1*6+2], statusDoneCount++;
                                statusDone [statusDoneCount] = treatmentDone [counter1*6+3], statusDoneCount++;
                                statusDone [statusDoneCount] = treatmentDone [counter1*6+4], statusDoneCount++;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < statusDoneCount/5; counterA++){
                        //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<statusDone [counterA*5+counterB];
                        //    cout<<" statusDone "<<counterA<<endl;
                        //}
                        
                        if (findFlag2 == 1){
                            do{
                                
                                terminationFlag2 = 0;
                                smallestLineageNo = 100000;
                                
                                for (int counter1 = 0; counter1 < statusDoneCount/5; counter1++){
                                    treatmentNo = statusDone [counter1*5+1];
                                    treatmentNo = treatmentNo.substr(1);
                                    
                                    if (atoi(treatmentNo.c_str()) != 0 && atoi(treatmentNo.c_str()) < smallestLineageNo) smallestLineageNo = atoi(treatmentNo.c_str());
                                }
                                
                                if (smallestLineageNo == 100000) terminationFlag2 = 1;
                                else{
                                    
                                    lineageDoneCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < statusDoneCount/5; counter1++){
                                        treatmentNo = statusDone [counter1*5+1];
                                        treatmentNo = treatmentNo.substr(1);
                                        
                                        if (atoi(treatmentNo.c_str()) == smallestLineageNo){
                                            lineageDone [lineageDoneCount] = statusDone [counter1*5], lineageDoneCount++;
                                            lineageDone [lineageDoneCount] = statusDone [counter1*5+1], lineageDoneCount++;
                                            lineageDone [lineageDoneCount] = statusDone [counter1*5+2], lineageDoneCount++;
                                            lineageDone [lineageDoneCount] = statusDone [counter1*5+3], lineageDoneCount++;
                                            lineageDone [lineageDoneCount] = statusDone [counter1*5+4], lineageDoneCount++;
                                            statusDone [counter1*5+1] = "L00000";
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < statusDoneCount/5; counterA++){
                                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<statusDone [counterA*5+counterB];
                                    //    cout<<" statusDone "<<counterA<<endl;
                                    //}
                                    
                                    //for (int counterA = 0; counterA < lineageDoneCount/5; counterA++){
                                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<lineageDone [counterA*5+counterB];
                                    //    cout<<" lineageDone "<<counterA<<endl;
                                    //}
                                    
                                    do {
                                        
                                        terminationFlag3 = 0;
                                        smallestCellNo = 999999999;
                                        
                                        for (int counter1 = 0; counter1 < lineageDoneCount/5; counter1++){
                                            treatmentNo = lineageDone [counter1*5+2];
                                            treatmentNo = treatmentNo.substr(1);
                                            
                                            if (atoi(treatmentNo.c_str()) != -1 && atoi(treatmentNo.c_str()) < smallestCellNo) smallestCellNo = atoi(treatmentNo.c_str());
                                        }
                                        
                                        //for (int counterA = 0; counterA < lineageDoneCount/5; counterA++){
                                        //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<lineageDone [counterA*5+counterB];
                                        //    cout<<" lineageDone "<<counterA<<endl;
                                        //}
                                        
                                        if (smallestCellNo == 999999999) terminationFlag3 = 1;
                                        else{
                                            
                                            for (int counter1 = 0; counter1 < lineageDoneCount/5; counter1++){
                                                treatmentNo = lineageDone [counter1*5+2];
                                                treatmentNo = treatmentNo.substr(1);
                                                
                                                if (atoi(treatmentNo.c_str()) == smallestCellNo){
                                                    newDoneList [newDoneListCount] = lineageDone [counter1*5], newDoneListCount++;
                                                    newDoneList [newDoneListCount] = lineageDone [counter1*5+1], newDoneListCount++;
                                                    newDoneList [newDoneListCount] = lineageDone [counter1*5+2], newDoneListCount++;
                                                    newDoneList [newDoneListCount] = lineageDone [counter1*5+3], newDoneListCount++;
                                                    newDoneList [newDoneListCount] = lineageDone [counter1*5+4], newDoneListCount++;
                                                    lineageDone [counter1*5+2] = "C-1";
                                                }
                                            }
                                            
                                            //for (int counterA = 0; counterA < lineageDoneCount/5; counterA++){
                                            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<lineageDone [counterA*5+counterB];
                                            //    cout<<" lineageDone "<<counterA<<endl;
                                            //}
                                            
                                            //for (int counterA = 0; counterA < newDoneListCount/5; counterA++){
                                            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<newDoneList [counterA*5+counterB];
                                            //    cout<<" newDoneList "<<counterA<<endl;
                                            //}
                                        }
                                        
                                    } while (terminationFlag3 == 0);
                                }
                                
                            } while (terminationFlag2 == 0);
                        }
                        
                        roundCount++;
                        
                    } while (roundCount < 2);
                }
                
            } while (terminationFlag == 0);
            
            delete [] currentDoneList;
            delete [] treatmentDone;
            delete [] statusDone;
            delete [] lineageDone;
            delete [] entryNumberList;
            
            string *doneListUpdateTemp = new string [newDoneListCount+50];
            int doneListUpdateTempCount = 0;
            
            for (int counter1 = 0; counter1 < newDoneListCount/5; counter1++){
                if (newDoneList [counter1*5] == treatmentNameHold){
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+1], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+2], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+3], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+4], doneListUpdateTempCount++;
                }
            }
            
            for (int counter1 = 0; counter1 < newDoneListCount/5; counter1++){
                if (newDoneList [counter1*5] != treatmentNameHold){
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+1], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+2], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+3], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+4], doneListUpdateTempCount++;
                }
            }
            
            doneListCount = 0;
            for (int counter1 = 0; counter1 < doneListUpdateTempCount; counter1++) arrayDoneList [doneListCount] = doneListUpdateTemp [counter1], doneListCount++;
            delete [] newDoneList;
            delete [] doneListUpdateTemp;
            
            string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
            
            if (doneListCount != 0){
                string extension;
                
                char *mainDataEntry = new char [doneListCount*10+10];
                int totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < doneListCount; counter1++){
                    extension = arrayDoneList [counter1];
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile (doneListPath.c_str(), ofstream::binary);
                outfile.write (mainDataEntry, totalEntryCount);
                outfile.close();
                
                delete [] mainDataEntry;
            }
            
            trackingTableSetDone = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select List"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (tableListSwitch != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Done List Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking/Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)organizeList2:(id)sender{
    //==========Organize order treatment (from largest), Status (Check/OK), Lineage NO, Cell no==========
    
    if (tableListSwitch == 1 && trackingOn == 1 && mainSavingInProgress == 0 && cleaningProgress == 0){
        if (doneListCount/5 != 0){
            string *newDoneList = new string [doneListCount+10];
            int newDoneListCount = 0;
            string *currentDoneList = new string [doneListCount+10];
            int currentDoneListCount = 0;
            string *treatmentDone = new string [doneListCount*2+10];
            int treatmentDoneCount = 0;
            string *statusDone = new string [doneListCount+10];
            int statusDoneCount = 0;
            int *entryNumberList = new int [100];
            
            for (int counter1 = 0; counter1 < doneListCount; counter1++) currentDoneList [currentDoneListCount] = arrayDoneList [counter1], currentDoneListCount++;
            
            //for (int counterA = 0; counterA < doneListCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
            //    cout<<" arrayDoneList "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < currentDoneListCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<currentDoneList [counterA*5+counterB];
            //    cout<<" currentDoneList "<<counterA<<endl;
            //}
            
            string treatmentEntry;
            string entryString;
            int entryCount = 0;
            int terminationFlag = 0;
            int entryNumber = 0;
            int findFlag = 0;
            
            do{
                
                terminationFlag = 0;
                entryNumber = 0;
                findFlag = 0;
                treatmentEntry = "";
                
                for (int counter1 = 0; counter1 < currentDoneListCount/5; counter1++){
                    if (currentDoneList [counter1*5] != "" && findFlag == 0){
                        treatmentEntry = currentDoneList [counter1*5];
                        findFlag = 1;
                        entryCount++;
                        entryNumber++;
                        
                        entryString = to_string(entryCount);
                        
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+1], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+2], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+3], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+4], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = entryString, treatmentDoneCount++;
                        
                        currentDoneList [counter1*5] = "";
                    }
                    else if (currentDoneList [counter1*5] != "" && findFlag == 1 && currentDoneList [counter1*5] == treatmentEntry){
                        entryNumber++;
                        
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+1], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+2], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+3], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+4], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = entryString, treatmentDoneCount++;
                        
                        currentDoneList [counter1*5] = "";
                    }
                }
                
                if (findFlag == 0) terminationFlag = 1;
                else{
                    
                    entryNumberList [entryCount] = entryNumber;
                }
                
            } while (terminationFlag == 0);
            
            //for (int counterA = 0; counterA < currentDoneListCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<currentDoneList [counterA*5+counterB];
            //    cout<<" currentDoneList "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < treatmentDoneCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<treatmentDone [counterA*6+counterB];
            //    cout<<" treatmentDone "<<counterA<<endl;
            //}
            
            //for (int counterA = 1; counterA <= entryCount; counterA++){
            //    cout<<counterA<<" "<<entryNumberList [counterA]<<" List"<<endl;
            //}
            
            string treatmentNo;
            string endTimeNo;
            int largestEntryNumber = 0;
            int largestEntryPosition = 0;
            int findFlag2 = 0;
            int roundCount = 0;
            int terminationFlag2 = 0;
            int smallestLineageNo = 0;
            
            do{
                
                terminationFlag = 0;
                largestEntryNumber = 0;
                largestEntryPosition = 0;
                
                for (int counter1 = 1; counter1 <= entryCount; counter1++){
                    if (largestEntryNumber < entryNumberList [counter1]){
                        largestEntryNumber = entryNumberList [counter1];
                        largestEntryPosition = counter1;
                    }
                }
                
                if (largestEntryPosition == 0) terminationFlag = 1;
                else{
                    
                    entryNumberList [largestEntryPosition] = 0;
                    findFlag2 = 0;
                    roundCount = 0;
                    
                    do{
                        
                        statusDoneCount = 0;
                        
                        for (int counter1 = 0; counter1 < treatmentDoneCount/6; counter1++){
                            treatmentNo = treatmentDone [counter1*6+5];
                            
                            if ((roundCount == 0 && atoi(treatmentNo.c_str()) == largestEntryPosition && treatmentDone [counter1*6+4] != "OK") || (roundCount == 1 && atoi(treatmentNo.c_str()) == largestEntryPosition && treatmentDone [counter1*6+4] == "OK")){
                                findFlag2 = 1;
                                statusDone [statusDoneCount] = treatmentDone [counter1*6], statusDoneCount++;
                                statusDone [statusDoneCount] = treatmentDone [counter1*6+1], statusDoneCount++;
                                statusDone [statusDoneCount] = treatmentDone [counter1*6+2], statusDoneCount++;
                                statusDone [statusDoneCount] = treatmentDone [counter1*6+3], statusDoneCount++;
                                statusDone [statusDoneCount] = treatmentDone [counter1*6+4], statusDoneCount++;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < statusDoneCount/5; counterA++){
                        //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<statusDone [counterA*5+counterB];
                        //    cout<<" statusDone "<<counterA<<endl;
                        //}
                        
                        if (findFlag2 == 1){
                            do{
                                
                                terminationFlag2 = 0;
                                smallestLineageNo = 100000;
                                
                                for (int counter1 = 0; counter1 < statusDoneCount/5; counter1++){
                                    endTimeNo = statusDone [counter1*5+3].substr(0, statusDone [counter1*5+3].find(":"));
                                    treatmentNo = statusDone [counter1*5+1].substr(1);
                                    
                                    if (atoi(treatmentNo.c_str()) != 0 && atoi(endTimeNo.c_str()) < smallestLineageNo) smallestLineageNo = atoi(endTimeNo.c_str());
                                }
                                
                                if (smallestLineageNo == 100000) terminationFlag2 = 1;
                                else{
                                    
                                    for (int counter1 = 0; counter1 < statusDoneCount/5; counter1++){
                                        endTimeNo = statusDone [counter1*5+3].substr(0, statusDone [counter1*5+3].find(":"));
                                        
                                        if (atoi(endTimeNo.c_str()) == smallestLineageNo){
                                            newDoneList [newDoneListCount] = statusDone [counter1*5], newDoneListCount++;
                                            newDoneList [newDoneListCount] = statusDone [counter1*5+1], newDoneListCount++;
                                            newDoneList [newDoneListCount] = statusDone [counter1*5+2], newDoneListCount++;
                                            newDoneList [newDoneListCount] = statusDone [counter1*5+3], newDoneListCount++;
                                            newDoneList [newDoneListCount] = statusDone [counter1*5+4], newDoneListCount++;
                                            statusDone [counter1*5+1] = "0";
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < newDoneListCount/5; counterA++){
                                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<newDoneList [counterA*5+counterB];
                                    //    cout<<" newDoneList "<<counterA<<endl;
                                    //}
                                    
                                    //for (int counterA = 0; counterA < statusDoneCount/5; counterA++){
                                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<statusDone [counterA*5+counterB];
                                    //    cout<<" statusDone "<<counterA<<endl;
                                    //}
                                    
                                    //for (int counterA = 0; counterA < lineageDoneCount/5; counterA++){
                                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<lineageDone [counterA*5+counterB];
                                    //    cout<<" lineageDone "<<counterA<<endl;
                                    //}
                                }
                                
                            } while (terminationFlag2 == 0);
                        }
                        
                        roundCount++;
                        
                    } while (roundCount < 2);
                }
                
            } while (terminationFlag == 0);
            
            delete [] currentDoneList;
            delete [] treatmentDone;
            delete [] statusDone;
            delete [] entryNumberList;
            
            string *doneListUpdateTemp = new string [newDoneListCount+50];
            int doneListUpdateTempCount = 0;
            
            for (int counter1 = 0; counter1 < newDoneListCount/5; counter1++){
                if (newDoneList [counter1*5] == treatmentNameHold){
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+1], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+2], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+3], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+4], doneListUpdateTempCount++;
                }
            }
            
            for (int counter1 = 0; counter1 < newDoneListCount/5; counter1++){
                if (newDoneList [counter1*5] != treatmentNameHold){
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+1], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+2], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+3], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+4], doneListUpdateTempCount++;
                }
            }
            
            doneListCount = 0;
            for (int counter1 = 0; counter1 < doneListUpdateTempCount; counter1++) arrayDoneList [doneListCount] = doneListUpdateTemp [counter1], doneListCount++;
            delete [] newDoneList;
            delete [] doneListUpdateTemp;
            
            string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
            
            if (doneListCount != 0){
                string extension;
                
                char *mainDataEntry = new char [doneListCount*10+10];
                int totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < doneListCount; counter1++){
                    extension = arrayDoneList [counter1];
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile (doneListPath.c_str(), ofstream::binary);
                outfile.write (mainDataEntry, totalEntryCount);
                outfile.close();
                
                delete [] mainDataEntry;
            }
            
            trackingTableSetDone = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select List"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (tableListSwitch != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Done List Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking/Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)organizeListCK:(id)sender{
    if (tableListSwitch == 1 && trackingOn == 1 && mainSavingInProgress == 0 && cleaningProgress == 0){
        if (doneListCount/5 != 0){
            string *newDoneList = new string [doneListCount+10];
            int newDoneListCount = 0;
            string *currentDoneList = new string [doneListCount+10];
            int currentDoneListCount = 0;
            string *treatmentDone = new string [doneListCount*2+10];
            int treatmentDoneCount = 0;
            string *statusDone = new string [doneListCount+10];
            int statusDoneCount = 0;
            int *entryNumberList = new int [100];
            
            for (int counter1 = 0; counter1 < doneListCount; counter1++) currentDoneList [currentDoneListCount] = arrayDoneList [counter1], currentDoneListCount++;
            
            //for (int counterA = 0; counterA < doneListCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
            //    cout<<" arrayDoneList "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < currentDoneListCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<currentDoneList [counterA*5+counterB];
            //    cout<<" currentDoneList "<<counterA<<endl;
            //}
            
            string treatmentEntry;
            string entryString;
            int entryCount = 0;
            int terminationFlag = 0;
            int entryNumber = 0;
            int findFlag = 0;
            
            do{
                
                terminationFlag = 0;
                entryNumber = 0;
                findFlag = 0;
                treatmentEntry = "";
                
                for (int counter1 = 0; counter1 < currentDoneListCount/5; counter1++){
                    if (currentDoneList [counter1*5] != "" && findFlag == 0){
                        treatmentEntry = currentDoneList [counter1*5];
                        findFlag = 1;
                        entryCount++;
                        entryNumber++;
                        
                        entryString = to_string(entryCount);
                        
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+1], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+2], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+3], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+4], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = entryString, treatmentDoneCount++;
                        
                        currentDoneList [counter1*5] = "";
                    }
                    else if (currentDoneList [counter1*5] != "" && findFlag == 1 && currentDoneList [counter1*5] == treatmentEntry){
                        entryNumber++;
                        
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+1], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+2], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+3], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = currentDoneList [counter1*5+4], treatmentDoneCount++;
                        treatmentDone [treatmentDoneCount] = entryString, treatmentDoneCount++;
                        
                        currentDoneList [counter1*5] = "";
                    }
                }
                
                if (findFlag == 0) terminationFlag = 1;
                else{
                    
                    entryNumberList [entryCount] = entryNumber;
                }
                
            } while (terminationFlag == 0);
            
            //for (int counterA = 0; counterA < currentDoneListCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<currentDoneList [counterA*5+counterB];
            //    cout<<" currentDoneLis "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < treatmentDoneCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<treatmentDone [counterA*6+counterB];
            //    cout<<" treatmentDone "<<counterA<<endl;
            //}
            
            //for (int counterA = 1; counterA <= entryCount; counterA++){
            //    cout<<counterA<<" "<<entryNumberList [counterA]<<" List"<<endl;
            //}
            
            string treatmentNo;
            string endTimeNo;
            string checkTimeNo;
            int largestEntryNumber = 0;
            int largestEntryPosition = 0;
            int findFlag2 = 0;
            int roundCount = 0;
            int terminationFlag2 = 0;
            int smallestLineageNo = 0;
            
            do{
                
                terminationFlag = 0;
                largestEntryNumber = 0;
                largestEntryPosition = 0;
                
                for (int counter1 = 1; counter1 <= entryCount; counter1++){
                    if (largestEntryNumber < entryNumberList [counter1]){
                        largestEntryNumber = entryNumberList [counter1];
                        largestEntryPosition = counter1;
                    }
                }
                
                if (largestEntryPosition == 0) terminationFlag = 1;
                else{
                    
                    entryNumberList [largestEntryPosition] = 0;
                    findFlag2 = 0;
                    roundCount = 0;
                    
                    do {
                        
                        statusDoneCount = 0;
                        
                        for (int counter1 = 0; counter1 < treatmentDoneCount/6; counter1++){
                            treatmentNo = treatmentDone [counter1*6+5];
                            endTimeNo = treatmentDone [counter1*6+3].substr(0, treatmentDone [counter1*6+3].find(":"));
                            checkTimeNo = treatmentDone [counter1*6+3].substr(treatmentDone [counter1*6+3].find(":")+1);
                            
                            if ((roundCount == 0 && atoi(treatmentNo.c_str()) == largestEntryPosition && treatmentDone [counter1*6+4] != "OK") || (roundCount == 0 && atoi(treatmentNo.c_str()) == largestEntryPosition && treatmentDone [counter1*6+4] == "OK" && endTimeNo != checkTimeNo) || (roundCount == 1 && atoi(treatmentNo.c_str()) == largestEntryPosition && treatmentDone [counter1*6+4] == "OK" && endTimeNo == checkTimeNo)){
                                findFlag2 = 1;
                                statusDone [statusDoneCount] = treatmentDone [counter1*6], statusDoneCount++;
                                statusDone [statusDoneCount] = treatmentDone [counter1*6+1], statusDoneCount++;
                                statusDone [statusDoneCount] = treatmentDone [counter1*6+2], statusDoneCount++;
                                statusDone [statusDoneCount] = treatmentDone [counter1*6+3], statusDoneCount++;
                                statusDone [statusDoneCount] = treatmentDone [counter1*6+4], statusDoneCount++;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < statusDoneCount/5; counterA++){
                        //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<statusDone [counterA*5+counterB];
                        //    cout<<" statusDone "<<counterA<<endl;
                        //}
                        
                        if (findFlag2 == 1){
                            do{
                                
                                terminationFlag2 = 0;
                                smallestLineageNo = 100000;
                                
                                for (int counter1 = 0; counter1 < statusDoneCount/5; counter1++){
                                    checkTimeNo = statusDone [counter1*5+3].substr(statusDone [counter1*5+3].find(":")+1);
                                    treatmentNo = statusDone [counter1*5+1].substr(1);
                                    
                                    if (atoi(treatmentNo.c_str()) != 0 && atoi(checkTimeNo.c_str()) < smallestLineageNo) smallestLineageNo = atoi(checkTimeNo.c_str());
                                }
                                
                                if (smallestLineageNo == 100000) terminationFlag2 = 1;
                                else{
                                    
                                    for (int counter1 = 0; counter1 < statusDoneCount/5; counter1++){
                                        checkTimeNo = statusDone [counter1*5+3].substr(statusDone [counter1*5+3].find(":")+1);
                                        
                                        if (atoi(checkTimeNo.c_str()) == smallestLineageNo){
                                            newDoneList [newDoneListCount] = statusDone [counter1*5], newDoneListCount++;
                                            newDoneList [newDoneListCount] = statusDone [counter1*5+1], newDoneListCount++;
                                            newDoneList [newDoneListCount] = statusDone [counter1*5+2], newDoneListCount++;
                                            newDoneList [newDoneListCount] = statusDone [counter1*5+3], newDoneListCount++;
                                            newDoneList [newDoneListCount] = statusDone [counter1*5+4], newDoneListCount++;
                                            statusDone [counter1*5+1] = "0";
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < newDoneListCount/5; counterA++){
                                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<newDoneList [counterA*5+counterB];
                                    //    cout<<" newDoneList "<<counterA<<endl;
                                    //}
                                    
                                    //for (int counterA = 0; counterA < statusDoneCount/5; counterA++){
                                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<statusDone [counterA*5+counterB];
                                    //    cout<<" statusDone "<<counterA<<endl;
                                    //}
                                    
                                    //for (int counterA = 0; counterA < lineageDoneCount/5; counterA++){
                                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<lineageDone [counterA*5+counterB];
                                    //    cout<<" lineageDone "<<counterA<<endl;
                                    //}
                                }
                                
                            } while (terminationFlag2 == 0);
                        }
                        
                        roundCount++;
                        
                    } while (roundCount < 2);
                }
                
            } while (terminationFlag == 0);
            
            delete [] currentDoneList;
            delete [] treatmentDone;
            delete [] statusDone;
            delete [] entryNumberList;
            
            string *doneListUpdateTemp = new string [newDoneListCount+50];
            int doneListUpdateTempCount = 0;
            
            for (int counter1 = 0; counter1 < newDoneListCount/5; counter1++){
                if (newDoneList [counter1*5] == treatmentNameHold){
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+1], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+2], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+3], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+4], doneListUpdateTempCount++;
                }
            }
            
            for (int counter1 = 0; counter1 < newDoneListCount/5; counter1++){
                if (newDoneList [counter1*5] != treatmentNameHold){
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+1], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+2], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+3], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = newDoneList [counter1*5+4], doneListUpdateTempCount++;
                }
            }
            
            doneListCount = 0;
            for (int counter1 = 0; counter1 < doneListUpdateTempCount; counter1++) arrayDoneList [doneListCount] = doneListUpdateTemp [counter1], doneListCount++;
            
            delete [] newDoneList;
            delete [] doneListUpdateTemp;
            
            string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
            
            if (doneListCount != 0){
                string extension;
                
                char *mainDataEntry = new char [doneListCount*10+10];
                int totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < doneListCount; counter1++){
                    extension = arrayDoneList [counter1];
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile (doneListPath.c_str(), ofstream::binary);
                outfile.write (mainDataEntry, totalEntryCount);
                outfile.close();
                
                delete [] mainDataEntry;
            }
            
            trackingTableSetDone = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select List"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (tableListSwitch != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Done List Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking/Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)doneDisplayAll:(id)sender{
    if (tableListSwitch == 1 && trackingOn == 1 && queueHoldingStatus == 0 && doneListCount != 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        doneDisplayOptions = 0;
        
        [doneOptionCheck setStringValue:@"AL"];
        
        dataSaveRead = [[DataSaveRead alloc] init];
        [dataSaveRead saveTrackingCurrent];
        
        trackingTableSetDone = 1;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (tableListSwitch != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Done List Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (queueHoldingStatus != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto Processing On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Done List Entry or Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)doneDisplayTreatment:(id)sender{
    if (tableListSwitch == 1 && trackingOn == 1 && queueHoldingStatus == 0 && doneListCount != 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        doneDisplayOptions = 1;
        
        [doneOptionCheck setStringValue:@"TR"];
        
        dataSaveRead = [[DataSaveRead alloc] init];
        [dataSaveRead saveTrackingCurrent];
        
        trackingTableSetDone = 1;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (tableListSwitch != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Done List Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (queueHoldingStatus != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto Processing On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Done List Entry or Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)doneDisplayCheck:(id)sender{
    if (tableListSwitch == 1 && trackingOn == 1 && queueHoldingStatus == 0 && doneListCount != 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        doneDisplayOptions = 2;
        
        [doneOptionCheck setStringValue:@"CK"];
        
        dataSaveRead = [[DataSaveRead alloc] init];
        [dataSaveRead saveTrackingCurrent];
        
        trackingTableSetDone = 1;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (tableListSwitch != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Done List Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (queueHoldingStatus != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto Processing On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Done List Entry or Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)doneDisplayOK:(id)sender{
    if (tableListSwitch == 1 && trackingOn == 1 && queueHoldingStatus == 0 && doneListCount != 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        doneDisplayOptions = 3;
        
        [doneOptionCheck setStringValue:@"OK"];
        
        dataSaveRead = [[DataSaveRead alloc] init];
        [dataSaveRead saveTrackingCurrent];
        
        trackingTableSetDone = 1;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (tableListSwitch != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Done List Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (queueHoldingStatus != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto Processing On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Done List Entry or Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)organizeListAutoCheck:(id)sender{
    if (tableListSwitch == 1 && trackingOn == 1 && queueHoldingStatus == 0 && doneListCount != 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        doneDisplayOptions = 4;
        autoCheckFlag = 0;
        
        [doneOptionCheck setStringValue:@"AU"];
        
        dataSaveRead = [[DataSaveRead alloc] init];
        [dataSaveRead saveTrackingCurrent];
        
        trackingTableSetDone = 1;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (tableListSwitch != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Done List Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (queueHoldingStatus != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto Processing On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Done List Entry or Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)returnPositionCheck:(id)sender{
    if (trackingOn == 1 && queueHoldingStatus == 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        imageReturnPosition = 1;
        
        [returnOptionCheck setStringValue:@"CK"];
        
        dataSaveRead = [[DataSaveRead alloc] init];
        [dataSaveRead saveTrackingCurrent];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (trackingOn != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (queueHoldingStatus != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto Processing On or Other Processes Running"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)returnPositionLast:(id)sender{
    if (trackingOn == 1 && queueHoldingStatus == 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        imageReturnPosition = 0;
        
        [returnOptionCheck setStringValue:@"LT"];
        
        dataSaveRead = [[DataSaveRead alloc] init];
        [dataSaveRead saveTrackingCurrent];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (trackingOn != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (queueHoldingStatus != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto Processing On or Other Processes Running"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)autoExpandLineSet:(id)sender{
    if (trackingOn != 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Toggle DIC Expansion?"];
        [alert setInformativeText:@"Quantitation status of DIC images will be changed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            if (autoExpandLine == 1){
                autoExpandLine = 0;
                [autoExpandLineDisplay setStringValue:@"Off"];
            }
            else if (autoExpandLine == 0){
                autoExpandLine = 1;
                [autoExpandLineDisplay setStringValue:@"On"];
            }
            
            dataSaveRead = [[DataSaveRead alloc] init];
            [dataSaveRead saveTrackingCurrent];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One Mode Off or Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

@end
