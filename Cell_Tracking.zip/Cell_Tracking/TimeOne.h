//
// TimeOne.h
// Cell_Tracking
//
// Created by Masahiko Sato on 13/08/15.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef TIMEONE_H
#define TIMEONE_H
#import "Controller.h"
#endif

@interface TimeOne : NSObject {
    id targetFind;
    id targetFind2;
    id fileUpdate;
}

-(id)init;
-(void)dealloc;

@end
