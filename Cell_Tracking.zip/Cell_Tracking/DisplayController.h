//
//  DisplayController.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2015-01-06.
//
//

#ifndef DISPLAYCONTROLLER_H
#define DISPLAYCONTROLLER_H
#import "Controller.h" 
#endif

@interface DisplayController : NSObject {
    IBOutlet NSTextField *cutDisplay1;
    IBOutlet NSTextField *cutDisplay2;
    IBOutlet NSTextField *cutDisplay3;
    IBOutlet NSTextField *cutDisplay4;
    IBOutlet NSTextField *cutDisplay5;
    IBOutlet NSTextField *cutDisplay6;
    IBOutlet NSTextField *cutDisplay7;
    IBOutlet NSTextField *cutDisplayDic;
    IBOutlet NSTextField *cutDisplayFluorescent;
    
    NSTimer *displayControlTimer;
}

-(id)init;
-(void)dealloc;
-(void)statusMonitor;

@end
