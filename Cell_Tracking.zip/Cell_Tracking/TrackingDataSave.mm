//
// TrackingDataSave.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 13/10/02.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "TrackingDataSave.h"

@implementation TrackingDataSave

-(int)trackingDataSaveTemp:(int)saveTypeDef :(int)fluorescentStatus :(int)gravityCenterCheckMode{
    int resultReturn = 0;
    
    string extension = "";
    string extensionLineage;
    
    if (saveTypeDef == 1) extensionLineage = to_string(imageNumberTrackForDisplay-1);
    else if (saveTypeDef == 2) extensionLineage = to_string(imageNumberTrackForDisplay);
    else if (saveTypeDef == 3) extensionLineage = to_string(imageNumberTrackForDisplay+1);
    
    if (extensionLineage.length() == 1) extensionLineage = "000"+extensionLineage;
    else if (extensionLineage.length() == 2) extensionLineage = "00"+extensionLineage;
    else if (extensionLineage.length() == 3) extensionLineage = "0"+extensionLineage;
    
    struct stat sizeOfFile;
    
    string gravityCenterDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_GCCenterInfo";
    string gravityCenterDataPathDummy = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_GCCenterInfoD";
    
    ofstream oin;
    
    int gravityCenterTempX = 0;
    int gravityCenterTempY = 0;
    
    if (gravityCenterXHold1 != 0 || gravityCenterYHold1 != 0){
        if (stat(gravityCenterDataPathDummy.c_str(), &sizeOfFile) == 0){
            remove(gravityCenterDataPathDummy.c_str());
        }
        
        oin.open(gravityCenterDataPath.c_str(), ios::out);
        oin<<gravityCenterXHold1<<endl;
        oin<<gravityCenterYHold1<<endl;
        oin<<gravityAverageHold1<<endl;
        oin<<gravityCellNo1<<endl;
        oin<<gravityCenterXHold2<<endl;
        oin<<gravityCenterYHold2<<endl;
        oin<<gravityAverageHold2<<endl;
        oin<<gravityCellNo2<<endl;
        oin<<gravityCenterXHold3<<endl;
        oin<<gravityCenterYHold3<<endl;
        oin<<gravityAverageHold3<<endl;
        oin<<gravityCellNo3<<endl;
        oin<<gravityCenterXHold4<<endl;
        oin<<gravityCenterYHold4<<endl;
        oin<<gravityAverageHold4<<endl;
        oin<<gravityCellNo4<<endl;
        oin.close();
    }
    else{
        
        if (stat(gravityCenterDataPathDummy.c_str(), &sizeOfFile) == 0){
            string cellLineageExtract = cellLineageNoHold.substr(1);
            string cellNoExtract = cellNoHold.substr(1);
            int lineageAmendTemp = atoi(cellLineageExtract.c_str());
            int cellAmendTemp = atoi(cellNoExtract.c_str());
            
            //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
            //    cout<<" arrayConnectLineageRel "<<counterA<<endl;
            //}
            
            int connectNoTemp = 0;
            
            for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                if (arrayConnectLineageRel [counter1*6] == lineageAmendTemp && arrayConnectLineageRel [counter1*6+3] == cellAmendTemp){
                    connectNoTemp = arrayConnectLineageRel [counter1*6+1];
                    break;
                }
            }
            
            int averageTemp = 0;
            
            for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                if (arrayGravityCenterRev [counter1*6+4] == connectNoTemp){
                    gravityCenterTempX = arrayGravityCenterRev [counter1*6];
                    gravityCenterTempY = arrayGravityCenterRev [counter1*6+1];
                    averageTemp = arrayGravityCenterRev [counter1*6+3];
                    break;
                }
            }
            
            oin.open(gravityCenterDataPath.c_str(), ios::out);
            oin<<gravityCenterTempX<<endl;
            oin<<gravityCenterTempY<<endl;
            oin<<averageTemp<<endl;
            oin<<cellAmendTemp<<endl;
            oin<<0<<endl;
            oin<<0<<endl;
            oin<<0<<endl;
            oin<<0<<endl;
            oin<<0<<endl;
            oin<<0<<endl;
            oin<<0<<endl;
            oin<<0<<endl;
            oin<<0<<endl;
            oin<<0<<endl;
            oin<<0<<endl;
            oin<<0<<endl;
            oin.close();
            
            remove(gravityCenterDataPathDummy.c_str());
        }
    }
    
    if (((gravityCenterXHold1 != 0 || gravityCenterYHold1 != 0 || gravityCenterTempX != 0 || gravityCenterTempY != 0) && ifEntry == 0) || ifEntry == 1 || gravityCenterCheckMode == 0){
        if (gravityCenterCheckMode == 0){
            if (gravityCenterXHold1 == 0 && gravityCenterYHold1 == 0 && gravityCenterTempX == 0 && gravityCenterTempY == 0){
                if (gravityCenterNotRecorded == "nil") gravityCenterNotRecorded = extensionLineage;
                else gravityCenterNotRecorded = gravityCenterNotRecorded+"/"+extensionLineage;
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            else{
                
                if (gravityCenterNotRecorded != "nil"){
                    string imageNoExtract = gravityCenterNotRecorded;
                    string imageNoExtract2 = "nil";
                    string imageNoExtract3 = "nil";
                    
                    do{
                        
                        if ((int)imageNoExtract.find("/") == -1){
                            imageNoExtract2 = imageNoExtract;
                            imageNoExtract = "nil";
                        }
                        else{
                            
                            imageNoExtract2 = imageNoExtract.substr(0, imageNoExtract.find("/"));
                            imageNoExtract = imageNoExtract.substr(imageNoExtract.find("/")+1);
                        }
                        
                        if (atoi(imageNoExtract2.c_str()) != atoi(extensionLineage.c_str())){
                            if (imageNoExtract3 == "nil") imageNoExtract3 = imageNoExtract2;
                            else imageNoExtract3 = imageNoExtract3+"/"+imageNoExtract2;
                        }
                        
                    } while (imageNoExtract != "nil");
                    
                    gravityCenterNotRecorded = imageNoExtract3;
                }
            }
        }
        
        string connectDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_MasterDataTemp";
        string connectDataTempPathDummy = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_MasterDataTempD";
        
        if (stat(connectDataTempPathDummy.c_str(), &sizeOfFile) == 0){
            remove(connectDataTempPathDummy.c_str());
        }
        
        //for (int counterA = 0; counterA < lineageGravityCenterCurrentHoldCount/4; counterA++){
        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGravityCenterCurrentHold [counterA*4+counterB];
        //    cout<<" arrayLineageGravityCenterCurrentHold "<<counterA<<endl;
        //}
        
        int dataTemp = 0;
        
        if (positionReviseCount != 0){
            int readBit [4];
            unsigned long indexCount = 0;
            
            char *writingArray = new char [(positionReviseCount/7+associateDataCount/6+gravityCenterRevCount/6)*17+50];
            
            for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                dataTemp = arrayPositionRevise [counter1*7];
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                dataTemp = arrayPositionRevise [counter1*7+1];
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                writingArray [indexCount] = (char)arrayPositionRevise [counter1*7+2], indexCount++;
                
                dataTemp = arrayPositionRevise [counter1*7+3];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                
                dataTemp = arrayPositionRevise [counter1*7+4];
                
                if (dataTemp < 0) dataTemp = dataTemp*-1, writingArray [indexCount] = 1, indexCount++;
                else writingArray [indexCount] = 0, indexCount++;
                
                readBit [0] = dataTemp/16777216;
                dataTemp = dataTemp%16777216;
                readBit [1] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [2] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [3] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                writingArray [indexCount] = (char)readBit [3], indexCount++;
                
                writingArray [indexCount] = (char)arrayPositionRevise [counter1*7+5], indexCount++;
                
                dataTemp = arrayPositionRevise [counter1*7+6];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
            }
            
            for (int counter1 = 0; counter1 < 17; counter1++) writingArray [indexCount] = 0, indexCount++;
            
            for (int counter1 = 0; counter1 < associateDataCount/6; counter1++){
                dataTemp = arrayAssociateData [counter1*6];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                
                writingArray [indexCount] = (char)arrayAssociateData [counter1*6+1], indexCount++;
                
                writingArray [indexCount] = (char)arrayAssociateData [counter1*6+2], indexCount++;
                
                dataTemp = arrayAssociateData [counter1*6+3];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                
                dataTemp = arrayAssociateData [counter1*6+4];
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                writingArray [indexCount] = (char)arrayAssociateData [counter1*6+5], indexCount++;
            }
            
            for (int counter1 = 0; counter1 < 11; counter1++) writingArray [indexCount] = 0, indexCount++;
            
            for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                dataTemp = arrayGravityCenterRev [counter1*6];
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                dataTemp = arrayGravityCenterRev [counter1*6+1];
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                dataTemp = arrayGravityCenterRev [counter1*6+2];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                
                writingArray [indexCount] = (char)arrayGravityCenterRev [counter1*6+3], indexCount++;
                
                dataTemp = arrayGravityCenterRev [counter1*6+4];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                
                writingArray [indexCount] = (char)arrayGravityCenterRev [counter1*6+5], indexCount++;
            }
            
            for (int counter1 = 0; counter1 < 11; counter1++) writingArray [indexCount] = 0, indexCount++;
            
            ofstream outfile (connectDataTempPath.c_str(), ofstream::binary);
            outfile.write ((char*)writingArray, indexCount);
            outfile.close();
            
            delete [] writingArray;
        }
        
        //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
        //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
        //	cout<<" arrayPositionRevise "<<counterA<<endl;
        //}
        
        string connectStatusTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_StatusTemp";
        string connectStatusTempPathDummy = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_StatusTempD";
        
        if (stat(connectStatusTempPathDummy.c_str(), &sizeOfFile) == 0){
            remove(connectStatusTempPathDummy.c_str());
        }
        
        //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
        //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
        //	cout<<" arrayTimeSelected "<<counterA+1<<endl;
        //}
        
        if (timeSelectedCount != 0){
            char *writingArray = new char [timeSelectedCount/10*19+20];
            
            unsigned long indexCount = 0;
            int readBit [3];
            int connectNumberTemp = 0;
            
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                writingArray [indexCount] = (char)arrayTimeSelected [counter1*10], indexCount++;
                writingArray [indexCount] = 0, indexCount++;
                writingArray [indexCount] = 0, indexCount++;
                writingArray [indexCount] = 0, indexCount++;
                
                dataTemp = arrayTimeSelected [counter1*10+2];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                
                writingArray [indexCount] = 0, indexCount++;
                writingArray [indexCount] = 0, indexCount++;
                
                writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+4], indexCount++;
                writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+5], indexCount++;
                writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+6], indexCount++;
                writingArray [indexCount] = (char)arrayTimeSelected [counter1*10+7], indexCount++;
                
                dataTemp = arrayTimeSelected [counter1*10+8];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                
                if (arrayTimeSelected [counter1*10] == 3 || arrayTimeSelected [counter1*10] == 4) connectNumberTemp = 0;
                else connectNumberTemp = arrayTimeSelected [counter1*10+9];
                
                dataTemp = connectNumberTemp;
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
            }
            
            for (int counter1 = 0; counter1 < 19; counter1++) writingArray [indexCount] = 0, indexCount++;
            
            ofstream outfile2 (connectStatusTempPath.c_str(), ofstream::binary);
            outfile2.write ((char*) writingArray, indexCount);
            outfile2.close();
            
            delete [] writingArray;
        }
        
        //-----Connect lineage relation table save-----
        string connectRelationTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_ConnectLineageRelTemp";
        string connectRelationTempPathDummy = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_ConnectLineageRelTempD";
        
        if (stat(connectRelationTempPathDummy.c_str(), &sizeOfFile) == 0){
            remove(connectRelationTempPathDummy.c_str());
        }
        
        //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
        //	cout<<" arrayConnectLineageRel "<<counterA<<endl;
        //}
        
        if (connectLineageRelCount != 0){
            char *writingArray = new char [connectLineageRelCount/6*16+16];
            
            unsigned long indexCount = 0;
            int readBit [4];
            
            for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                dataTemp = arrayConnectLineageRel [counter1*6];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                
                dataTemp = arrayConnectLineageRel [counter1*6+1];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                
                dataTemp = arrayConnectLineageRel [counter1*6+2];
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                if (arrayConnectLineageRel [counter1*6+3] < 0){
                    writingArray [indexCount] = 1, indexCount++;
                    dataTemp = arrayConnectLineageRel [counter1*6+3]*-1;
                }
                else{
                    
                    writingArray [indexCount] = 0, indexCount++;
                    dataTemp = arrayConnectLineageRel [counter1*6+3];
                }
                
                readBit [0] = dataTemp/16777216;
                dataTemp = dataTemp%16777216;
                readBit [1] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [2] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [3] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                writingArray [indexCount] = (char)readBit [3], indexCount++;
                
                writingArray [indexCount] = 0, indexCount++;
                
                writingArray [indexCount] = (char)arrayConnectLineageRel [counter1*6+5], indexCount++;
            }
            
            for (int counter1 = 0; counter1 < 15; counter1++) writingArray [indexCount] = 0, indexCount++;
            
            ofstream outfile2 (connectRelationTempPath.c_str(), ofstream::binary);
            outfile2.write ((char*) writingArray, indexCount);
            outfile2.close();
            
            delete [] writingArray;
        }
        
        //-----Save Revised Map-----
        string revisedTempMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_RevisedTempMap";
        string revisedTempMapPathDummy = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_RevisedTempMapD";
        
        if (stat(revisedTempMapPathDummy.c_str(), &sizeOfFile) == 0){
            remove(revisedTempMapPathDummy.c_str());
        }
        
        if (imageDimension != 0){
            int totalMapSizeTemp = imageDimension*imageDimension*4+1;
            
            char *dataHold = new char [totalMapSizeTemp];
            int indexCount = 0;
            int dataTemp2 = 0;
            int entryCount = 0;
            int readBit [4];
            
            for (int counterX = 0; counterX < imageDimension; counterX++){
                for (int counterY = 0; counterY < imageDimension; counterY++){
                    dataTemp = revisedWorkingMap [counterX][counterY];
                    
                    if (counterY == 0) dataTemp2 = dataTemp, entryCount++;
                    else if (dataTemp != dataTemp2 || entryCount == 254 || counterY == imageDimension-1){
                        readBit [0] = dataTemp2/65536;
                        dataTemp2 = dataTemp2%65536;
                        readBit [1] = dataTemp2/256;
                        dataTemp2 = dataTemp2%256;
                        readBit [2] = dataTemp2;
                        
                        if (counterY == imageDimension-1){
                            if (dataTemp != dataTemp2){
                                dataHold [indexCount] = (char)readBit [0], indexCount++;
                                dataHold [indexCount] = (char)readBit [1], indexCount++;
                                dataHold [indexCount] = (char)readBit [2], indexCount++;
                                dataHold [indexCount] = (char)entryCount, indexCount++;
                                
                                readBit [0] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [1] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [2] = dataTemp;
                                
                                entryCount = 1;
                                
                                dataHold [indexCount] = (char)readBit [0], indexCount++;
                                dataHold [indexCount] = (char)readBit [1], indexCount++;
                                dataHold [indexCount] = (char)readBit [2], indexCount++;
                                dataHold [indexCount] = (char)entryCount, indexCount++;
                            }
                            else{
                                
                                entryCount++;
                                
                                dataHold [indexCount] = (char)readBit [0], indexCount++;
                                dataHold [indexCount] = (char)readBit [1], indexCount++;
                                dataHold [indexCount] = (char)readBit [2], indexCount++;
                                dataHold [indexCount] = (char)entryCount, indexCount++;
                            }
                        }
                        else{
                            
                            dataHold [indexCount] = (char)readBit [0], indexCount++;
                            dataHold [indexCount] = (char)readBit [1], indexCount++;
                            dataHold [indexCount] = (char)readBit [2], indexCount++;
                            dataHold [indexCount] = (char)entryCount, indexCount++;
                        }
                        
                        if (counterY == imageDimension-1) entryCount = 0;
                        else entryCount = 1, dataTemp2 = dataTemp;
                    }
                    else entryCount++;
                }
            }
            
            ofstream outfile2 (revisedTempMapPath.c_str(), ofstream::binary);
            outfile2.write(dataHold, indexCount);
            outfile2.close();
            
            delete [] dataHold;
        }
        
        //-----Link Data Save-----
        if (divisionTypeHold == 2){
            cellDivisionSetCount = 0;
            divisionTypeHold = 0;
            
            string linkDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_LinkDataTemp";
            
            oin.open(linkDataPath.c_str(), ios::out);
            oin<<"BD"<<endl;
            oin<<cellNoHoldDiv1<<endl;
            oin<<cellNoHoldDiv2<<endl;
            oin<<"nil"<<endl;
            oin<<"nil"<<endl;
            oin.close();
            
            cellNoHoldDiv1 = "";
            cellNoHoldDiv2 = "";
        }
        
        if (divisionTypeHold == 3){
            cellDivisionSetCount = 0;
            divisionTypeHold = 0;
            
            string linkDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_LinkDataTemp";
            
            oin.open(linkDataPath.c_str(), ios::out);
            oin<<"TD"<<endl;
            oin<<cellNoHoldDiv1<<endl;
            oin<<cellNoHoldDiv2<<endl;
            oin<<cellNoHoldDiv3<<endl;
            oin<<"nil"<<endl;
            oin.close();
            
            cellNoHoldDiv1 = "";
            cellNoHoldDiv2 = "";
            cellNoHoldDiv3 = "";
        }
        
        if (divisionTypeHold == 4){
            cellDivisionSetCount = 0;
            divisionTypeHold = 0;
            
            string linkDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_LinkDataTemp";
            
            oin.open(linkDataPath.c_str(), ios::out);
            oin<<"HD"<<endl;
            oin<<cellNoHoldDiv1<<endl;
            oin<<cellNoHoldDiv2<<endl;
            oin<<cellNoHoldDiv3<<endl;
            oin<<cellNoHoldDiv4<<endl;
            oin.close();
            
            cellNoHoldDiv1 = "";
            cellNoHoldDiv2 = "";
            cellNoHoldDiv3 = "";
            cellNoHoldDiv4 = "";
        }
        
        if (fusionOperation == 1){
            fusionOperation = 0;
            string linkDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_LinkDataTemp";
            
            oin.open(linkDataPath.c_str(), ios::out);
            oin<<"FU"<<endl;
            oin<<fusionPartnerLin<<endl;
            oin<<fusionPartnerCellNo<<endl;
            oin<<fusionMarkImage<<endl;
            oin<<"nil"<<endl;
            oin.close();
            
            fusionPartnerLin = 0;
            fusionPartnerCellNo = -1;
            fusionStatusFollow = 0;
        }
        
        if (fluorescentStatus == 1){
            string fluorescentExpandPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_ExtendLineDataTemp";
            string fluorescentExpandPathDummy = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_ExtendLineDataTempD";
            
            if (stat(fluorescentExpandPathDummy.c_str(), &sizeOfFile) == 0){
                remove(fluorescentExpandPathDummy.c_str());
            }
            
            if (expandFluorescentOutlineCount != 0){
                int readBit [3];
                unsigned long indexCount = 0;
                char *writingArray = new char [expandFluorescentOutlineCount*2+200];
                
                for (int counter1 = 0; counter1 < expandFluorescentOutlineCount/4; counter1++){
                    dataTemp = expandFluorescentOutline [counter1*4];
                    readBit [0] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [1] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    
                    dataTemp = expandFluorescentOutline [counter1*4+1];
                    readBit [0] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [1] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    
                    dataTemp = expandFluorescentOutline [counter1*4+2];
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                    
                    writingArray [indexCount] = (char)expandFluorescentOutline [counter1*4+3], indexCount++;
                }
                
                for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                
                ofstream outfile (fluorescentExpandPath.c_str(), ofstream::binary);
                outfile.write ((char*)writingArray, indexCount);
                outfile.close();
                
                delete [] writingArray;
                
                //for (int counterA = 0; counterA < expandFluorescentOutlineCount/4; counterA++){
                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentOutline [counterA*4+counterB];
                //    cout<<" expandFluorescentOutline "<<counterA<<endl;
                //}
            }
            
            string fluorescentExpandPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_ExtendAreaDataTemp";
            string fluorescentExpandPathDummy2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extensionLineage+"_ExtendAreaDataTempD";
            
            if (stat(fluorescentExpandPathDummy2.c_str(), &sizeOfFile) == 0){
                remove(fluorescentExpandPathDummy2.c_str());
            }
            
            //for (int counterA = 0; counterA < expandFluorescentDataCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentData [counterA*4+counterB];
            //    cout<<" expandFluorescentData "<<counterA<<endl;
            //}
            
            if (expandFluorescentDataCount != 0){
                int readBit [3];
                unsigned long indexCount = 0;
                char *writingArray = new char [expandFluorescentDataCount*2+20];
                
                for (int counter1 = 0; counter1 < expandFluorescentDataCount/4; counter1++){
                    dataTemp = expandFluorescentData [counter1*4];
                    
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                    
                    writingArray [indexCount] = (char)expandFluorescentData [counter1*4+1], indexCount++;
                    writingArray [indexCount] = (char)expandFluorescentData [counter1*4+2], indexCount++;
                    
                    dataTemp = expandFluorescentData [counter1*4+3];
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                }
                
                for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                
                ofstream outfile2 (fluorescentExpandPath2.c_str(), ofstream::binary);
                outfile2.write ((char*)writingArray, indexCount);
                outfile2.close();
                
                delete [] writingArray;
            }
        }
        
        //for (int counterA = 0; counterA < expandFluorescentOutlineCount/4; counterA++){
        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentOutline [counterA*4+counterB];
        //    cout<<" expandFluorescentOutline "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
        //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
        //	cout<<" arrayEventSequence "<<counterA<<endl;
        //}
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"GC Set Error"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
        
        dataSaveRead = [[DataSaveRead alloc] init];
        [dataSaveRead reviseLineClear];
        
        resultReturn = 1;
    }
    
    return resultReturn;
}

@end
