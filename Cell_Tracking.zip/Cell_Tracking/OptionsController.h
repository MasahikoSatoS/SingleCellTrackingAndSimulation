//
//  OptionsController.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2015-12-03.
//
//

#ifndef OPTIONCONTROLLER_H
#define OPTIONCONTROLLER_H
#import "Controller.h" 
#endif

@interface OptionsController : NSObject {
    IBOutlet NSWindow *optionWindow;
    
    NSTimer *optionTimer;
    
    NSWindowController *optionWindowController;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;
-(IBAction)closeWindow:(id)sender;

@end
