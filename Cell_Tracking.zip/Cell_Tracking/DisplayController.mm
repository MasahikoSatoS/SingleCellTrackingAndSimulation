//
//  DisplayController.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2015-01-06.
//
//

#import "DisplayController.h"

NSString *notificationToDisplayController = @"notificationExecuteDisplayController";

@implementation DisplayController

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToDisplayController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    displayControlTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(statusMonitor) userInfo:nil repeats:YES];
}

-(void)statusMonitor{
    if (displaySetFluorescentFlag == 1){
        if (cutStatusFluorescent != 0){
            [cutDisplayFluorescent setIntegerValue:cutStatusFluorescent];
            
            NSString *treatNSString = [cutDisplayFluorescent stringValue];
            
            if (treatNSString != NULL){
                string treatString = [treatNSString UTF8String];
                
                if (to_string(cutStatusFluorescent) == treatString) displaySetFluorescentFlag = 0;
            }
        }
        else{
            
            [cutDisplayFluorescent setStringValue:@"nil"];
            
            NSString *treatNSString = [cutDisplayFluorescent stringValue];
            
            if (treatNSString != NULL){
                string treatString = [treatNSString UTF8String];
                
                if ("nil" == treatString) displaySetFluorescentFlag = 0;
            }
        }
    }
    
    if (displaySetDICFlag == 1){
        if (cutStatusDic != 0){
            [cutDisplayDic setIntegerValue:cutStatusDic];
            
            NSString *treatNSString = [cutDisplayDic stringValue];
            
            if (treatNSString != NULL){
                string treatString = [treatNSString UTF8String];
                
                if (to_string(cutStatusDic) == treatString) displaySetDICFlag = 0;
            }
        }
        else{
            
            [cutDisplayDic setStringValue:@"nil"];
            
            NSString *treatNSString = [cutDisplayDic stringValue];
            
            if (treatNSString != NULL){
                string treatString = [treatNSString UTF8String];
                
                if ("nil" == treatString) displaySetDICFlag = 0;
            }
        }
    }
    
    if (displaySetCutFlag1 == 1){
        string cutString = "Cut "+to_string(cutOff1);
        
        if (cutDisplay == 1){
            [cutDisplay1 setTextColor:[NSColor redColor]];
            [cutDisplay1 setStringValue:@(cutString.c_str())];
        }
        else{
            
            [cutDisplay1 setTextColor:[NSColor blueColor]];
            [cutDisplay1 setStringValue:@(cutString.c_str())];
        }
        
        NSString *treatNSString = [cutDisplay1 stringValue];
        
        if (treatNSString != NULL){
            string treatString = [treatNSString UTF8String];
            
            if (cutString == treatString) displaySetCutFlag1 = 0;
        }
    }
    
    if (displaySetCutFlag2 == 1){
        string cutString = "Cut "+to_string(cutOff2);
        
        if (cutDisplay == 2){
            [cutDisplay2 setTextColor:[NSColor redColor]];
            [cutDisplay2 setStringValue:@(cutString.c_str())];
        }
        else{
            
            [cutDisplay2 setTextColor:[NSColor blueColor]];
            [cutDisplay2 setStringValue:@(cutString.c_str())];
        }
        
        NSString *treatNSString = [cutDisplay2 stringValue];
        
        if (treatNSString != NULL){
            string treatString = [treatNSString UTF8String];
            
            if (cutString == treatString) displaySetCutFlag2 = 0;
        }
    }
    
    if (displaySetCutFlag3 == 1){
        string cutString = "Cut "+to_string(cutOff3);
        
        if (cutDisplay == 3){
            [cutDisplay3 setTextColor:[NSColor redColor]];
            [cutDisplay3 setStringValue:@(cutString.c_str())];
        }
        else{
            
            [cutDisplay3 setTextColor:[NSColor blueColor]];
            [cutDisplay3 setStringValue:@(cutString.c_str())];
        }
        
        NSString *treatNSString = [cutDisplay3 stringValue];
        
        if (treatNSString != NULL){
            string treatString = [treatNSString UTF8String];
            
            if (cutString == treatString) displaySetCutFlag3 = 0;
        }
    }
    
    if (displaySetCutFlag4 == 1){
        string cutString = "Cut "+to_string(cutOff4);
        
        if (cutDisplay == 4){
            [cutDisplay4 setTextColor:[NSColor redColor]];
            [cutDisplay4 setStringValue:@(cutString.c_str())];
        }
        else{
            
            [cutDisplay4 setTextColor:[NSColor blueColor]];
            [cutDisplay4 setStringValue:@(cutString.c_str())];
        }
        
        NSString *treatNSString = [cutDisplay4 stringValue];
        
        if (treatNSString != NULL){
            string treatString = [treatNSString UTF8String];
            
            if (cutString == treatString) displaySetCutFlag4 = 0;
        }
    }
    
    if (displaySetCutFlag5 == 1){
        string cutString = "Cut "+to_string(cutOff5);
        
        if (cutDisplay == 5){
            [cutDisplay5 setTextColor:[NSColor redColor]];
            [cutDisplay5 setStringValue:@(cutString.c_str())];
        }
        else{
            
            [cutDisplay5 setTextColor:[NSColor blueColor]];
            [cutDisplay5 setStringValue:@(cutString.c_str())];
        }
        
        NSString *treatNSString = [cutDisplay5 stringValue];
        
        if (treatNSString != NULL){
            string treatString = [treatNSString UTF8String];
            
            if (cutString == treatString) displaySetCutFlag5 = 0;
        }
    }
    
    if (displaySetCutFlag6 == 1){
        string cutString = "Cut "+to_string(cutOff6);
        
        if (cutDisplay == 6){
            [cutDisplay6 setTextColor:[NSColor redColor]];
            [cutDisplay6 setStringValue:@(cutString.c_str())];
        }
        else{
            
            [cutDisplay6 setTextColor:[NSColor blueColor]];
            [cutDisplay6 setStringValue:@(cutString.c_str())];
        }
        
        NSString *treatNSString = [cutDisplay6 stringValue];
        
        if (treatNSString != NULL){
            string treatString = [treatNSString UTF8String];
            
            if (cutString == treatString) displaySetCutFlag6 = 0;
        }
    }
    
    if (displaySetCutFlag7 == 1){
        string cutString = "Cut "+to_string(cutOff7);
        
        if (cutDisplay == 7){
            [cutDisplay7 setTextColor:[NSColor redColor]];
            [cutDisplay7 setStringValue:@(cutString.c_str())];
        }
        else{
            
            [cutDisplay7 setTextColor:[NSColor blueColor]];
            [cutDisplay7 setStringValue:@(cutString.c_str())];
        }
        
        NSString *treatNSString = [cutDisplay7 stringValue];
        
        if (treatNSString != NULL){
            string treatString = [treatNSString UTF8String];
            
            if (cutString == treatString) displaySetCutFlag7 = 0;
        }
    }
}

-(void)dealloc{
    if (displayControlTimer) [displayControlTimer invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToDisplayController object:nil];
}

@end
