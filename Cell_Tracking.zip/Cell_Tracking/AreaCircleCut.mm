//
// AreaCircleCut.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 02/09/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "AreaCircleCut.h"

@implementation AreaCircleCut

-(int)circleCut:(int) processSet{
    //-----First circle process-----
    int maxPointDimX = 0;
    int maxPointDimY = 0;
    int minPointDimX = 1000000;
    int minPointDimY = 1000000;
    
    for (int counter1 = 0; counter1 < lineDataProcessingCount/2; counter1++){
        if (maxPointDimX < arrayLineDataProcessing [counter1*2]) maxPointDimX = arrayLineDataProcessing [counter1*2];
        if (minPointDimX > arrayLineDataProcessing [counter1*2]) minPointDimX = arrayLineDataProcessing [counter1*2];
        if (maxPointDimY < arrayLineDataProcessing [counter1*2+1]) maxPointDimY = arrayLineDataProcessing [counter1*2+1];
        if (minPointDimY > arrayLineDataProcessing [counter1*2+1]) minPointDimY = arrayLineDataProcessing [counter1*2+1];
    }
    
    //-----Determine the dimension of cell-----
    int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
    int verticalLength = (maxPointDimY-minPointDimY)/2*2;
    int dimension = 0;
    
    if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
    if (horizontalLength < verticalLength) dimension = verticalLength+30;
    
    dimension = (dimension/2)*2;
    
    int horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
    int verticalStart = minPointDimY-(dimension-verticalLength)/2;
    int connectivityNumber = 0;
    int connectAnalysisCount = 0;
    int terminationFlag = 0;
    int connectAnalysisTempCount = 0;
    int xSource = 0;
    int ySource = 0;
    
    //cout<<horizontalStart<<" "<<verticalStart<<" "<<dimension<<" hol-ver-dim"<<endl;
    
    connectivityMap = new int *[dimension+1];
    for (int counter1 = 0; counter1 < dimension+1; counter1++) connectivityMap [counter1] = new int [dimension+1];
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++) connectivityMap [counterY][counterX] = 0;
    }
    
    for (int counter1 = 0; counter1 < lineDataProcessingCount/2; counter1++){
        connectivityMap [arrayLineDataProcessing [counter1*2+1]-verticalStart][arrayLineDataProcessing [counter1*2]-horizontalStart] = 1;
    }
    
    //for (int counterA = 0; counterA < dimension; counterA++){
    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
    //	cout<<" connectivityMap "<<counterA<<endl;
    //}
    
    //-----Fill inside-----
    int *connectAnalysisX = new int [dimension*4];
    int *connectAnalysisY = new int [dimension*4];
    int *connectAnalysisTempX = new int [dimension*4];
    int *connectAnalysisTempY = new int [dimension*4];
    
    connectivityNumber = -3;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMap [counterY][counterX] == 0){
                connectivityNumber = connectivityNumber+2;
                connectAnalysisCount = 0;
                
                if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMap [counterY][counterX] = connectivityNumber;
                
                if (counterY-1 >= 0 && connectivityMap [counterY-1][counterX] == 0){
                    connectivityMap [counterY-1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterX+1 < dimension && connectivityMap [counterY][counterX+1] == 0){
                    connectivityMap [counterY][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && connectivityMap [counterY+1][counterX] == 0){
                    connectivityMap [counterY+1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterX-1 >= 0 && connectivityMap [counterY][counterX-1] == 0){
                    connectivityMap [counterY][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                
                if (connectAnalysisCount != 0){
                    do{
                        
                        terminationFlag = 1;
                        connectAnalysisTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                            
                            if (ySource-1 >= 0 && connectivityMap [ySource-1][xSource] == 0){
                                connectivityMap [ySource-1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (xSource+1 < dimension && connectivityMap [ySource][xSource+1] == 0){
                                connectivityMap [ySource][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < dimension && connectivityMap [ySource+1][xSource] == 0){
                                connectivityMap [ySource+1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (xSource-1 >= 0 && connectivityMap [ySource][xSource-1] == 0){
                                connectivityMap [ySource][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                        }
                        
                        connectAnalysisCount = connectAnalysisTempCount;
                        
                        if (connectAnalysisCount == 0) terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                }
            }
        }
    }
    
    //for (int counterA = 0; counterA < dimension; counterA++){
    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
    //    cout<<" connectivityMap "<<counterA<<endl;
    //}
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMap [counterY][counterX] == -1) connectivityMap [counterY][counterX] = 0;
            else connectivityMap [counterY][counterX] = 1;
        }
    }
    
    int maxConnectNumberList = timeSelectedCount/10;
    
    int *overLapListTemp = new int [maxConnectNumberList+2];
    
    for (int counter1 = 0; counter1 <= maxConnectNumberList; counter1++) overLapListTemp [counter1] = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] != 0){
                if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0) overLapListTemp [revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart]]++;
            }
        }
    }
    
    for (int counter1 = 0; counter1 < dimension+1; counter1++) delete [] connectivityMap [counter1];
    
    delete [] connectivityMap;
    
    for (int counter1 = 1; counter1 <= maxConnectNumberList; counter1++){
        if (overLapListTemp [counter1] != 0){
            if (arrayTimeSelected [(counter1-1)*10] != 3 && arrayTimeSelected [(counter1-1)*10] != 4){
                for (int counter2 = arrayTimeSelected [(counter1-1)*10+2]; counter2 < positionReviseCount/7; counter2++){
                    if (arrayPositionRevise [counter2*7+3] == counter1){
                        if (maxPointDimX < arrayPositionRevise [counter2*7]) maxPointDimX = arrayPositionRevise [counter2*7];
                        if (minPointDimX > arrayPositionRevise [counter2*7]) minPointDimX = arrayPositionRevise [counter2*7];
                        if (maxPointDimY < arrayPositionRevise [counter2*7+1]) maxPointDimY = arrayPositionRevise [counter2*7+1];
                        if (minPointDimY > arrayPositionRevise [counter2*7+1]) minPointDimY = arrayPositionRevise [counter2*7+1];
                    }
                    else{
                        
                        break;
                    }
                }
            }
        }
    }
    
    delete [] overLapListTemp;
    
    horizontalLength = (maxPointDimX-minPointDimX)/2*2;
    verticalLength = (maxPointDimY-minPointDimY)/2*2;
    dimension = 0;
    
    if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
    if (horizontalLength < verticalLength) dimension = verticalLength+30;
    
    dimension = (dimension/2)*2;
    
    horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
    verticalStart = minPointDimY-(dimension-verticalLength)/2;
    
    targetMap = new int *[dimension+1];
    connectivityMap = new int *[dimension+1];
    
    for (int counter1 = 0; counter1 < dimension+1; counter1++){
        connectivityMap [counter1] = new int [dimension+1];
        targetMap [counter1] = new int [dimension+1];
    }
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++) connectivityMap [counterY][counterX] = 0;
    }
    
    for (int counter1 = 0; counter1 < lineDataProcessingCount/2; counter1++){
        connectivityMap [arrayLineDataProcessing [counter1*2+1]-verticalStart][arrayLineDataProcessing [counter1*2]-horizontalStart] = 1;
    }
    
    delete [] connectAnalysisX;
    delete [] connectAnalysisY;
    delete [] connectAnalysisTempX;
    delete [] connectAnalysisTempY;
    
    //for (int counterA = 0; counterA < dimension; counterA++){
    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
    //    cout<<" connectivityMap "<<counterA<<endl;
    //}
    
    //-----Fill inside-----
    connectAnalysisX = new int [(dimension+2)*4];
    connectAnalysisY = new int [(dimension+2)*4];
    connectAnalysisTempX = new int [(dimension+2)*4];
    connectAnalysisTempY = new int [(dimension+2)*4];
    
    connectivityNumber = -3;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMap [counterY][counterX] == 0){
                connectivityNumber = connectivityNumber+2;
                connectAnalysisCount = 0;
                
                if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMap [counterY][counterX] = connectivityNumber;
                
                if (counterY-1 >= 0 && connectivityMap [counterY-1][counterX] == 0){
                    connectivityMap [counterY-1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterX+1 < dimension && connectivityMap [counterY][counterX+1] == 0){
                    connectivityMap [counterY][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && connectivityMap [counterY+1][counterX] == 0){
                    connectivityMap [counterY+1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterX-1 >= 0 && connectivityMap [counterY][counterX-1] == 0){
                    connectivityMap [counterY][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                
                if (connectAnalysisCount != 0){
                    do{
                        
                        terminationFlag = 1;
                        connectAnalysisTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                            
                            if (ySource-1 >= 0 && connectivityMap [ySource-1][xSource] == 0){
                                connectivityMap [ySource-1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (xSource+1 < dimension && connectivityMap [ySource][xSource+1] == 0){
                                connectivityMap [ySource][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < dimension && connectivityMap [ySource+1][xSource] == 0){
                                connectivityMap [ySource+1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (xSource-1 >= 0 && connectivityMap [ySource][xSource-1] == 0){
                                connectivityMap [ySource][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                        }
                        
                        connectAnalysisCount = connectAnalysisTempCount;
                        
                        if (connectAnalysisCount == 0) terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                }
            }
        }
    }
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMap [counterY][counterX] == -1) connectivityMap [counterY][counterX] = 0;
            else connectivityMap [counterY][counterX] = -1;
        }
    }
    
    //-----Background image set-----
    int **rangeMatrix = new int *[dimension+4];
    
    for (int counter1 = 0; counter1 < dimension+4; counter1++){
        rangeMatrix [counter1] = new int [dimension+4];
    }
    
    connectivityNumber = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                if (sourceImage [counterY+verticalStart][counterX+horizontalStart] == 100) rangeMatrix [counterY][counterX] = 0;
                else if (sourceImage [counterY+verticalStart][counterX+horizontalStart] < cutStatusDic) rangeMatrix [counterY][counterX] = 0;
                else rangeMatrix [counterY][counterX] = -150;
            }
            else rangeMatrix [counterY][counterX] = 0;
        }
    }
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (rangeMatrix [counterY][counterX] == -150){
                connectivityNumber++;
                rangeMatrix [counterY][counterX] = connectivityNumber;
                connectAnalysisCount = 0;
                
                if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrix [counterY-1][counterX-1] == -150){
                    rangeMatrix [counterY-1][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterY-1 >= 0 && rangeMatrix [counterY-1][counterX] == -150){
                    rangeMatrix [counterY-1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterY-1 >= 0 && counterX+1 < dimension && rangeMatrix [counterY-1][counterX+1] == -150){
                    rangeMatrix [counterY-1][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterX+1 < dimension && rangeMatrix [counterY][counterX+1] == -150){
                    rangeMatrix [counterY][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && counterX+1 < dimension && rangeMatrix [counterY+1][counterX+1] == -150){
                    rangeMatrix [counterY+1][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && rangeMatrix [counterY+1][counterX] == -150){
                    rangeMatrix [counterY+1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && counterX-1 >= 0 && rangeMatrix [counterY+1][counterX-1] == -150){
                    rangeMatrix [counterY+1][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterX-1 >= 0 && rangeMatrix [counterY][counterX-1] == -150){
                    rangeMatrix [counterY][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                
                if (connectAnalysisCount != 0){
                    do{
                        
                        terminationFlag = 1;
                        connectAnalysisTempCount = 0;
                        
                        for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                            xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                            
                            if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrix [ySource-1][xSource-1] == -150){
                                rangeMatrix [ySource-1][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (ySource-1 >= 0 && rangeMatrix [ySource-1][xSource] == -150){
                                rangeMatrix [ySource-1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (ySource-1 >= 0 && xSource+1 < dimension && rangeMatrix [ySource-1][xSource+1] == -150){
                                rangeMatrix [ySource-1][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (xSource+1 < dimension && rangeMatrix [ySource][xSource+1] == -150){
                                rangeMatrix [ySource][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                            if (ySource+1 > dimension && xSource+1 < dimension && rangeMatrix [ySource+1][xSource+1] == -150){
                                rangeMatrix [ySource+1][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < dimension && rangeMatrix [ySource+1][xSource] == -150){
                                rangeMatrix [ySource+1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < dimension && xSource-1 >= 0 && rangeMatrix [ySource+1][xSource-1] == -150){
                                rangeMatrix [ySource+1][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (xSource-1 >= 0 && rangeMatrix [ySource][xSource-1] == -150){
                                rangeMatrix [ySource][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                            connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                        }
                        
                        connectAnalysisCount = connectAnalysisTempCount;
                        
                        if (connectAnalysisCount == 0) terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                }
            }
        }
    }
    
    //-----Determine number of pixels-----
    int *connectedPix = new int [connectivityNumber+50];
    
    for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPix [counter2] = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (rangeMatrix [counterY][counterX] != 0) connectedPix [rangeMatrix [counterY][counterX]]++;
        }
    }
    
    //-----Map up-date-----
    int connectTemp = 1;
    
    for (int counter2 = 1; counter2 <= connectivityNumber; counter2++){
        if (connectedPix [counter2] < 10) connectedPix [counter2] = 0;
        else{
            
            connectedPix [counter2] = connectTemp;
            connectTemp++;
        }
    }
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if ((connectTemp = rangeMatrix [counterY][counterX]) != 0) rangeMatrix [counterY][counterX] = connectedPix [connectTemp];
            else rangeMatrix [counterY][counterX] = 0;
        }
    }
    
    delete [] connectedPix;
    
    //for (int counterA = 0; counterA < dimension; counterA++){
    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<rangeMatrix [counterA][counterB];
    //	cout<<" rangeMatrix "<<counterA<<endl;
    //}
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && rangeMatrix [counterY][counterX] == 0) connectivityMap [counterY][counterX] = 0;
        }
    }
    
    connectivityNumber = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMap [counterY][counterX] == -1){
                connectivityNumber++;
                connectAnalysisCount = 0;
                
                if (connectivityNumber >= 1) connectivityMap [counterY][counterX] = connectivityNumber;
                
                if (counterY-1 >= 0 && connectivityMap [counterY-1][counterX] == -1){
                    connectivityMap [counterY-1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterX+1 < dimension && connectivityMap [counterY][counterX+1] == -1){
                    connectivityMap [counterY][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && connectivityMap [counterY+1][counterX] == -1){
                    connectivityMap [counterY+1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterX-1 >= 0 && connectivityMap [counterY][counterX-1] == -1){
                    connectivityMap [counterY][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                
                if (connectAnalysisCount != 0){
                    do{
                        
                        terminationFlag = 1;
                        connectAnalysisTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                            
                            if (ySource-1 >= 0 && connectivityMap [ySource-1][xSource] == -1){
                                connectivityMap [ySource-1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (xSource+1 < dimension && connectivityMap [ySource][xSource+1] == -1){
                                connectivityMap [ySource][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < dimension && connectivityMap [ySource+1][xSource] == -1){
                                connectivityMap [ySource+1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (xSource-1 >= 0 && connectivityMap [ySource][xSource-1] == -1){
                                connectivityMap [ySource][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                        }
                        
                        connectAnalysisCount = connectAnalysisTempCount;
                        
                        if (connectAnalysisCount == 0) terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                }
            }
        }
    }
    
    int *mainConnectFindList = new int [connectivityNumber+2];
    
    for (int counter1 = 0; counter1 < connectivityNumber+2; counter1++) mainConnectFindList [counter1] = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            mainConnectFindList [connectivityMap [counterY][counterX]]++;
        }
    }
    
    //for (int counterA = 1; counterA <= connectivityNumber; counterA++) cout<<counterA<<" "<<mainConnectFindList [counterA]<<"  List"<<endl;
    
    int largestConnect = 0;
    int refConnectNo = 0;
    
    for (int counter1 = 1; counter1 < connectivityNumber+1; counter1++){
        if (mainConnectFindList [counter1] > largestConnect){
            largestConnect = mainConnectFindList [counter1];
            refConnectNo = counter1;
        }
    }
    
    delete [] mainConnectFindList;
    
    int cancelFlag = 0;
    
    if (refConnectNo != 0){
        int connectivityMapArea = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMap [counterY][counterX] != 0 && connectivityMap [counterY][counterX] != refConnectNo) connectivityMap [counterY][counterX] = 0;
                else if (connectivityMap [counterY][counterX] != 0){
                    connectivityMap [counterY][counterX] = 1;
                    connectivityMapArea++;
                }
            }
        }
        
        int **connectivityUpdate5 = new int *[dimension+4];
        
        for (int counter1 = 0; counter1 < dimension+4; counter1++) connectivityUpdate5 [counter1] = new int [dimension+4];
        
        //-----Zero Fill-----
        for (int counterX = 0; counterX < dimension+2; counterX++){
            for (int counterY = 0; counterY < dimension+2; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = connectivityMap [counterY][counterX];
        }
        
        connectivityNumber = 0;
        
        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                if (connectivityUpdate5 [counterY2][counterX2] == 0){
                    connectivityNumber--;
                    connectAnalysisCount = 0;
                    
                    connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                    
                    if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                        connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                    }
                    if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                        connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                        connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                    }
                    if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                        connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                    connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                    connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                    connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                    connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < dimension+2; counterA++){
        //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
        //	cout<<" connectivityUpdate5 "<<counterA<<endl;
        //}
        
        int connectTemp2 = 0;
        
        if (connectivityNumber < -1){
            int *connectCheckArray = new int [connectivityNumber*-1*2+5];
            
            for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
            
            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                    connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                    
                    if (connectTemp2 < -1){
                        connectTemp2 = connectTemp2*-1;
                        
                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                    }
                }
            }
            
            int zeroFillFlag = 0;
            
            for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
            }
            
            //for (int counterA = 0; counterA < dimension+2; counterA++){
            //    for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
            //    cout<<" connectivityUpdate5 "<<counterA<<endl;
            //}
            
            if (zeroFillFlag == 1){
                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                        connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                        
                        if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                    }
                }
                
                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                        if (connectivityUpdate5 [counterY2][counterX2] > 0) connectivityMap [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                    }
                }
            }
            
            delete [] connectCheckArray;
        }
        
        for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] connectivityUpdate5 [counter1];
        
        delete [] connectivityUpdate5;
    }
    else cancelFlag = 1;
    
    for (int counter1 = 0; counter1 < targetHoldCount/3; counter1++){
        if (arrayTargetHoldInfo [(arrayTargetHold [counter1*3+2]-1)*4+2] == 0){
            if (arrayTargetHold [counter1*3]-horizontalStart >= 0 && arrayTargetHold [counter1*3]-horizontalStart < dimension && arrayTargetHold [counter1*3+1]-verticalStart >= 0 && arrayTargetHold [counter1*3+1]-verticalStart < dimension) connectivityMap [arrayTargetHold [counter1*3+1]-verticalStart][arrayTargetHold [counter1*3]-horizontalStart] = 0;
        }
    }
    
    //for (int counterA = 0; counterA < dimension; counterA++){
    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
    //	cout<<" connectivityMap "<<counterA<<endl;
    //}
    
    int results = 0;
    
    if (cancelFlag == 1){
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            delete [] connectivityMap [counter1];
            delete [] targetMap [counter1];
        }
        
        delete [] connectivityMap;
        delete [] targetMap;
    }
    else{
        
        internalZeroMap = new int *[dimension+1];
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++) internalZeroMap [counter1] = new int [dimension+1];
        
        for (int counterY = 0; counterY < dimension+1; counterY++){
            for (int counterX = 0; counterX < dimension+1; counterX++) internalZeroMap [counterY][counterX] = 0;
        }
        
        //======internal zero check======
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++) internalZeroMap [counterY][counterX] = connectivityMap [counterY][counterX];
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<internalZeroMap [counterA][counterB];
        //    cout<<" internalZeroMap "<<counterA<<endl;
        //}
        
        connectivityNumber = 0;
        
        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                if (internalZeroMap [counterY2][counterX2] == 0){
                    connectivityNumber--;
                    connectAnalysisCount = 0;
                    
                    internalZeroMap [counterY2][counterX2] = connectivityNumber;
                    
                    if (counterY2-1 >= 0 && internalZeroMap [counterY2-1][counterX2] == 0){
                        internalZeroMap [counterY2-1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                    }
                    if (counterX2+1 < dimension && internalZeroMap [counterY2][counterX2+1] == 0){
                        internalZeroMap [counterY2][counterX2+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    if (counterY2+1 < dimension && internalZeroMap [counterY2+1][counterX2] == 0){
                        internalZeroMap [counterY2+1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                    }
                    if (counterX2-1 >= 0 && internalZeroMap [counterY2][counterX2-1] == 0){
                        internalZeroMap [counterY2][counterX2-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && internalZeroMap [ySource-1][xSource] == 0){
                                    internalZeroMap [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension && internalZeroMap [ySource][xSource+1] == 0){
                                    internalZeroMap [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && internalZeroMap [ySource+1][xSource] == 0){
                                    internalZeroMap [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && internalZeroMap [ySource][xSource-1] == 0){
                                    internalZeroMap [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<internalZeroMap [counterA][counterB];
        //    cout<<" internalZeroMap "<<counterA<<endl;
        //}
        
        //=====internal zero map========
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (internalZeroMap [counterY][counterX] >= -1) internalZeroMap [counterY][counterX] = 0;
            }
        }
        
        //for (int counterA = 1; counterA < maxConnectNumberList+1; counterA++) cout<<counterA<<" "<< overlapList [counterA] <<" OverLap"<<endl;
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
        //    cout<<" connectivityMap "<<counterA<<endl;
        //}
        
        int type = 1;
        int valueTemp = 1;
        
        results = [self areaProcess:type:dimension:valueTemp:horizontalStart:verticalStart:processSet];
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++) delete [] internalZeroMap [counter1];
        delete [] internalZeroMap;
        
        int *connectNumber = new int [dimension*dimension+50];
        int connectNumberCount = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] != 0 && revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0) connectNumber [connectNumberCount] = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart], connectNumberCount++;
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
        //    cout<<" connectivityMap "<<counterA<<endl;
        //}
        
        //==========
        //int **sourceImageAAAA = new int *[dimension+1];
        
        //for (int counterA = 0; counterA < dimension+1; counterA++){
        //    sourceImageAAAA [counterA] = new int [dimension+1];
        //}
        
        //for (int counterY = 0; counterY < dimension; counterY++){
        //    for (int counterX = 0; counterX < dimension; counterX++){
        //        sourceImageAAAA [counterY][counterX] = 0;
        //    }
        //}
        
        //for (int counterY = 0; counterY < imageDimension; counterY++){
        //    for (int counterX = 0; counterX < imageDimension; counterX++){
        //        if (counterY-verticalStart >= 0 && counterY-verticalStart < dimension && counterX-horizontalStart >= 0 && counterX-horizontalStart < dimension){
        //            if (revisedWorkingMap [counterY][counterX] != 0){
        //                sourceImageAAAA [counterY-verticalStart][counterX-horizontalStart] = revisedWorkingMap [counterY][counterX];
        //            }
        //        }
        //    }
        //}
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<sourceImageAAAA [counterA][counterB];
        //    cout<<" sourceImageAAA "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < dimension+1; counterA++){
        //    delete [] sourceImageAAAA [counterA];
        //}
        
        //delete [] sourceImageAAAA;
        //==========
        
        if (results != 0){
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] != 0) revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] = connectivityMap [counterY][counterX];
                }
            }
        }
        
        if (results == 1){
            if (connectNumberCount != 0){
                int *connectSort = new int [connectNumberCount+2];
                int *connectNumberList = new int [connectNumberCount+2];
                
                int valueTemp3= 0;
                
                for (int counter1 = 0; counter1 < connectNumberCount; counter1++){
                    connectSort [counter1] = 0;
                    connectNumberList [counter1] = connectNumber [counter1];
                }
                
                for (int counter1 = 0; counter1 < connectNumberCount-1; counter1++){
                    if (connectSort [counter1] == 0) valueTemp3 = connectNumberList [counter1];
                    
                    for (int counter2 = counter1+1; counter2 < connectNumberCount; counter2++){
                        if (connectNumberList [counter2] == valueTemp3) connectSort [counter2] = 1;
                    }
                }
                
                int numberOfRemaining = 0;
                
                for (int counter1 = 0; counter1 < connectNumberCount; counter1++){
                    if (connectSort [counter1] == 0) numberOfRemaining++;
                }
                
                int *connectProcessList = new int [numberOfRemaining+10];
                
                int entryCount = 0; //-----List of connect that to be processed-----
                
                for (int counter1 = 0; counter1 < connectNumberCount; counter1++){
                    if (connectSort [counter1] == 0) connectProcessList [entryCount] = connectNumberList [counter1], entryCount++;
                }
                
                delete [] connectSort;
                delete [] connectNumberList;
                
                if (numberOfRemaining != 0){
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) targetMap [counterY][counterX] = connectivityMap [counterY][counterX];
                    }
                    
                    internalZeroMap = new int *[dimension+1];
                    
                    for (int counter1 = 0; counter1 < dimension+1; counter1++) internalZeroMap [counter1] = new int [dimension+1];
                    
                    for (int counterY = 0; counterY < dimension+1; counterY++){
                        for (int counterX = 0; counterX < dimension+1; counterX++) internalZeroMap [counterY][counterX] = 0;
                    }
                    
                    int connectTemp2 =0;
                    int zeroFillFlag = 0;
                    int maxConnectNumberList2 = 0;
                    int edgeCheck = 0;
                    int insideFind = 0;
                    
                    for (int counter1 = 0; counter1 < numberOfRemaining; counter1++){
                        valueTemp = connectProcessList [counter1];
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++) connectivityMap [counterY][counterX] = 0;
                        }
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] == valueTemp && rangeMatrix [counterY][counterX] != 0){
                                    connectivityMap [counterY][counterX] = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart];
                                }
                            }
                        }
                        
                        //========zero fill=========
                        int **connectivityUpdate5 = new int *[dimension+4];
                        
                        for (int counter2 = 0; counter2 < dimension+4; counter2++) connectivityUpdate5 [counter2] = new int [dimension+4];
                        
                        //-----Zero Fill-----
                        for (int counterX = 0; counterX < dimension+2; counterX++){
                            for (int counterY = 0; counterY < dimension+2; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
                        }
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = connectivityMap [counterY][counterX];
                        }
                        
                        connectivityNumber = 0;
                        
                        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                if (connectivityUpdate5 [counterY2][counterX2] == 0){
                                    connectivityNumber--;
                                    connectAnalysisCount = 0;
                                    
                                    connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                                    
                                    if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                                        connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                    }
                                    if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                        connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                    }
                                    if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                        connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                    }
                                    if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                        connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                    }
                                    
                                    if (connectAnalysisCount != 0){
                                        do{
                                            
                                            terminationFlag = 1;
                                            connectAnalysisTempCount = 0;
                                            
                                            for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                
                                                if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                                    connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                                    connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                                    connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                                    connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                            }
                                            
                                            for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                            }
                                            
                                            connectAnalysisCount = connectAnalysisTempCount;
                                            
                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension+2; counterA++){
                        //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                        //	cout<<" connectivityUpdate5 "<<counterA<<endl;
                        //}
                        
                        if (connectivityNumber < -1){
                            int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                            
                            for (int counter2 = 0; counter2 < connectivityNumber*-1*2+5; counter2++) connectCheckArray [counter2] = 0;
                            
                            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                    connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                                    
                                    if (connectTemp2 < -1){
                                        connectTemp2 = connectTemp2*-1;
                                        
                                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                    }
                                }
                            }
                            
                            zeroFillFlag = 0;
                            
                            for (int counter2 = 2; counter2 <= connectivityNumber*-1; counter2++){
                                if (connectCheckArray [counter2*2] != 0 && connectCheckArray [counter2*2+1] == 0) zeroFillFlag = 1;
                            }
                            
                            if (zeroFillFlag == 1){
                                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                        connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                                        
                                        if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                                    }
                                }
                                
                                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                        if (connectivityUpdate5 [counterY2][counterX2] > 0) connectivityMap [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                                    }
                                }
                            }
                            
                            delete [] connectCheckArray;
                        }
                        
                        for (int counter2 = 0; counter2 < dimension+4; counter2++) delete [] connectivityUpdate5 [counter2];
                        
                        delete [] connectivityUpdate5;
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
                        //	cout<<" connectivityMap "<<counterA<<endl;
                        //}
                        
                        //======inside check=====
                        int **insideCheckMap = new int *[dimension+1];
                        
                        for (int counter2 = 0; counter2 < dimension+1; counter2++) insideCheckMap [counter2] = new int [dimension+1];
                        
                        for (int counterY = 0; counterY < dimension+1; counterY++){
                            for (int counterX = 0; counterX < dimension+1; counterX++) insideCheckMap [counterY][counterX] = 0;
                        }
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++) insideCheckMap [counterY][counterX] = 0;
                        }
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] != 0){
                                    insideCheckMap [counterY][counterX] = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart];
                                }
                            }
                        }
                        
                        maxConnectNumberList2 = timeSelectedCount/10;
                        
                        int *insideCheck = new int [maxConnectNumberList2*2+5];
                        
                        for (int counter2 = 0; counter2 < maxConnectNumberList2*2+5; counter2++) insideCheck [counter2] = 0;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                    if (connectivityMap [counterY][counterX] != 0 && revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0){
                                        insideCheck [revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart]*2]++;
                                    }
                                    else if (connectivityMap [counterY][counterX] == 0 && revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0){
                                        insideCheck [revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart]*2+1]++;
                                    }
                                    
                                    edgeCheck = 0;
                                    
                                    if (connectivityMap [counterY][counterX] != 0){
                                        if (counterY-1 >= 0 && connectivityMap [counterY-1][counterX] == 0) edgeCheck++;
                                        if (counterX+1 < dimension && connectivityMap [counterY][counterX+1] == 0) edgeCheck++;
                                        if (counterY+1 < dimension && connectivityMap [counterY+1][counterX] == 0) edgeCheck++;
                                        if (counterX-1 >= 0 && connectivityMap [counterY][counterX-1] == 0) edgeCheck++;
                                        
                                        if (edgeCheck != 0 && revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0){
                                            insideCheck [revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart]*2+1]++;
                                        }
                                    }
                                }
                            }
                        }
                        
                        insideFind = 0;
                        
                        for (int counter2 = 1; counter2 <= maxConnectNumberList2; counter2++){
                            if (insideCheck [counter2*2] != 0 && insideCheck [counter2*2+1] == 0) insideFind = 1;
                            else if (insideCheck [counter2*2] != 0 && insideCheck [counter2*2+1] != 0) insideCheck [counter2*2] = 0;
                        }
                        
                        if (insideFind == 1){
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++) internalZeroMap [counterY][counterX] = 0;
                            }
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (insideCheckMap [counterY][counterX] != 0){
                                        for (int counter2 = 1; counter2 <= maxConnectNumberList2; counter2++){
                                            if (insideCheck [counter2*2] != 0 && insideCheckMap [counterY][counterX] == counter2){
                                                internalZeroMap [counterY][counterX] = 1;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        
                        delete [] insideCheck;
                        
                        for (int counter2 = 0; counter2 < dimension+1; counter2++) delete [] insideCheckMap [counter2];
                        
                        delete [] insideCheckMap;
                        
                        type = 2;
                        results = [self areaProcess:type:dimension:valueTemp:horizontalStart:verticalStart:processSet];
                    }
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<internalZeroMap [counterA][counterB];
                    //    cout<<" internalZeroMap "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < dimension+1; counter1++) delete [] internalZeroMap [counter1];
                    delete [] internalZeroMap;
                }
                
                delete [] connectProcessList;
            }
        }
        
        delete [] connectNumber;
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            delete [] connectivityMap [counter1];
            delete [] targetMap [counter1];
        }
        
        delete [] connectivityMap;
        delete [] targetMap;
    }
    
    delete [] connectAnalysisX;
    delete [] connectAnalysisY;
    delete [] connectAnalysisTempX;
    delete [] connectAnalysisTempY;
    
    //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
    //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
    //	cout<<" arrayTimeSelected "<<counterA+1<<endl;
    //}
    
    for (int counter1 = 0; counter1 < dimension+4; counter1++){
        delete [] rangeMatrix [counter1];
    }
    
    delete [] rangeMatrix;
    
    return results;
}

-(int)areaProcess:(int)type :(int)dimension :(int)valueTemp :(int)horizontalStart :(int)verticalStart :(int)processSet{
    int lineEntryNumber = 0;
    
    if (targetHoldCount != 0) lineEntryNumber = arrayTargetHold [(targetHoldCount/3-1)*3+2];
    else lineEntryNumber = 0;
    
    lineEntryNumber++;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMap [counterY][counterX] != 0) connectivityMap [counterY][counterX] = connectivityMap [counterY][counterX]*-1;
        }
    }
    
    int *connectAnalysisX = new int [dimension*4];
    int *connectAnalysisY = new int [dimension*4];
    int *connectAnalysisTempX = new int [dimension*4];
    int *connectAnalysisTempY = new int [dimension*4];
    
    int connectivityNumber = 0;
    int connectAnalysisCount = 0;
    int terminationFlag = 0;
    int connectAnalysisTempCount = 0;
    int xSource = 0;
    int ySource = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMap [counterY][counterX] < 0){
                connectivityNumber++;
                connectivityMap [counterY][counterX] = connectivityNumber;
                connectAnalysisCount = 0;
                
                if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMap [counterY-1][counterX-1] < 0){
                    connectivityMap [counterY-1][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterY-1 >= 0 && connectivityMap [counterY-1][counterX] < 0){
                    connectivityMap [counterY-1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMap [counterY-1][counterX+1] < 0){
                    connectivityMap [counterY-1][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterX+1 < dimension && connectivityMap [counterY][counterX+1] < 0){
                    connectivityMap [counterY][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && counterX+1 < dimension && connectivityMap [counterY+1][counterX+1] < 0){
                    connectivityMap [counterY+1][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && connectivityMap [counterY+1][counterX] < 0){
                    connectivityMap [counterY+1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMap [counterY+1][counterX-1] < 0){
                    connectivityMap [counterY+1][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterX-1 >= 0 && connectivityMap [counterY][counterX-1] < 0){
                    connectivityMap [counterY][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                
                if (connectAnalysisCount != 0){
                    do{
                        
                        terminationFlag = 1;
                        connectAnalysisTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                            
                            if (ySource-1 >= 0 && xSource-1 >= 0 && connectivityMap [ySource-1][xSource-1] < 0){
                                connectivityMap [ySource-1][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (ySource-1 >= 0 && connectivityMap [ySource-1][xSource] < 0){
                                connectivityMap [ySource-1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (ySource-1 >= 0 && xSource+1 < dimension && connectivityMap [ySource-1][xSource+1] < 0){
                                connectivityMap [ySource-1][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (xSource+1 < dimension && connectivityMap [ySource][xSource+1] < 0){
                                connectivityMap [ySource][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                            if (ySource+1 > dimension && xSource+1 < dimension && connectivityMap [ySource+1][xSource+1] < 0){
                                connectivityMap [ySource+1][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < dimension && connectivityMap [ySource+1][xSource] < 0){
                                connectivityMap [ySource+1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < dimension && xSource-1 >= 0 && connectivityMap [ySource+1][xSource-1] < 0){
                                connectivityMap [ySource+1][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (xSource-1 >= 0 && connectivityMap [ySource][xSource-1] < 0){
                                connectivityMap [ySource][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                        }
                        
                        connectAnalysisCount = connectAnalysisTempCount;
                        
                        if (connectAnalysisCount == 0) terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                }
            }
        }
    }
    
    //for (int counterA = 0; counterA < dimension; counterA++){
    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
    //	cout<<" connectivityMap "<<counterA<<endl;
    //}
    
    //-----Determine number of pixels-----
    int *connectedPix = new int [connectivityNumber+50];
    
    for (int counter1 = 0; counter1 <= connectivityNumber; counter1++) connectedPix [counter1] = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMap [counterY][counterX] != 0) connectedPix [connectivityMap [counterY][counterX]]++;
        }
    }
    
    //-----Map up-date-----
    int connectTemp = 1;
    
    for (int counter1 = 1; counter1 <= connectivityNumber; counter1++){
        if (connectedPix [counter1] < 10) connectedPix [counter1] = 0;
        else{
            
            connectedPix [counter1] = connectTemp;
            connectTemp++;
        }
    }
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if ((connectTemp = connectivityMap [counterY][counterX]) != 0) connectivityMap [counterY][counterX] = connectedPix [connectTemp];
        }
    }
    
    delete [] connectedPix;
    
    int maxConnectivityNumber = 0;
    int newConnectLineNo = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMap [counterY][counterX] > maxConnectivityNumber) maxConnectivityNumber = connectivityMap [counterY][counterX];
        }
    }
    
    int **outlineMap = new int *[dimension+1];
    int **outlineMap2 = new int *[dimension+1];
    int **outlineMap3 = new int *[dimension+1];
    
    for (int counter1 = 0; counter1 < dimension+1; counter1++){
        outlineMap [counter1] = new int [dimension+1];
        outlineMap2 [counter1] = new int [dimension+1];
        outlineMap3 [counter1] = new int [dimension+1];
    }
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++) outlineMap3 [counterY][counterX] = 0;
    }
    
    int *outlineDataSet = new int [1000];
    int outlineDataSetCount = 0;
    int outlineDataSetLimit = 1000;
    int largestConnect = 0;
    int largestConnectNo = 0;
    int xPositionTempStart = 0;
    int yPositionTempStart = 0;
    int lineSize = 0;
    int constructedLineCount = 0;
    int findFlag = 0;
    int terminationFlag2 = 0;
    
    for (int counter1 = 1; counter1 <= maxConnectivityNumber; counter1++){
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMap [counterY][counterX] == counter1) outlineMap [counterY][counterX] = 1;
                else outlineMap [counterY][counterX] = 0;
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<outlineMap [counterA][counterB];
        //    cout<<" outlineMap "<<counterA<<endl;
        //}
        
        do{
            
            terminationFlag = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (outlineMap [counterY][counterX] != 0){
                        if (counterX+1 < dimension && outlineMap [counterY][counterX+1] == 0) outlineMap [counterY][counterX] = -1;
                        else if (counterY+1 < dimension && outlineMap [counterY+1][counterX] == 0) outlineMap [counterY][counterX] = -1;
                        else if (counterX-1 >= 0 && outlineMap [counterY][counterX-1] == 0) outlineMap [counterY][counterX] = -1;
                        else if (counterY-1 >= 0 && outlineMap [counterY-1][counterX] == 0) outlineMap [counterY][counterX] = -1;
                    }
                }
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (outlineMap [counterY][counterX] > 0) outlineMap [counterY][counterX] = 0;
                    if (outlineMap [counterY][counterX] < 0) outlineMap [counterY][counterX] = 1;
                }
            }
            
            connectivityNumber = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (outlineMap [counterY2][counterX2] == 0){
                        connectivityNumber--;
                        connectAnalysisCount = 0;
                        
                        outlineMap [counterY2][counterX2] = connectivityNumber;
                        
                        if (counterY2-1 >= 0 && outlineMap [counterY2-1][counterX2] == 0){
                            outlineMap [counterY2-1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                        }
                        if (counterX2+1 < dimension && outlineMap [counterY2][counterX2+1] == 0){
                            outlineMap [counterY2][counterX2+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        if (counterY2+1 < dimension && outlineMap [counterY2+1][counterX2] == 0){
                            outlineMap [counterY2+1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                        }
                        if (counterX2-1 >= 0 && outlineMap [counterY2][counterX2-1] == 0){
                            outlineMap [counterY2][counterX2-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                    xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                    
                                    if (ySource-1 >= 0 && outlineMap [ySource-1][xSource] == 0){
                                        outlineMap [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && outlineMap [ySource][xSource+1] == 0){
                                        outlineMap [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && outlineMap [ySource+1][xSource] == 0){
                                        outlineMap [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && outlineMap [ySource][xSource-1] == 0){
                                        outlineMap [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                    connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //-----Determine number of pixels-----
            connectivityNumber = connectivityNumber*-1;
            
            int *connectedPix2 = new int [connectivityNumber+50];
            
            for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPix2 [counter2] = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (outlineMap [counterY2][counterX2] < -1) connectedPix2 [outlineMap [counterY2][counterX2]*-1]++;
                }
            }
            
            largestConnect = 0;
            largestConnectNo = 0;
            
            for (int counter2 = 2; counter2 <= connectivityNumber; counter2++){
                if (connectedPix2 [counter2] > largestConnect){
                    largestConnect = connectedPix2 [counter2];
                    largestConnectNo = counter2;
                }
            }
            
            delete [] connectedPix2;
            
            if (largestConnectNo == 0 || largestConnect < 20) terminationFlag = 1;
            else{
                
                int **newConnectivityMapTemp = new int *[dimension+4];
                for (int counter2 = 0; counter2 < dimension+4; counter2++) newConnectivityMapTemp [counter2] = new int [dimension+4];
                
                for (int counterY = 0; counterY < dimension+4; counterY++){
                    for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
                }
                
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                        if (outlineMap [counterY2][counterX2] == largestConnectNo*-1){
                            if (counterY2-1 >= 0 && counterX2-1 >= 0 && outlineMap [counterY2-1][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                                outlineMap [counterY2-1][counterX2-1] = 0;
                            }
                            if (counterY2-1 >= 0 && outlineMap [counterY2-1][counterX2] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                                outlineMap [counterY2-1][counterX2] = 0;
                            }
                            if (counterY2-1 >= 0 && counterX2+1 < dimension && outlineMap [counterY2-1][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                                outlineMap [counterY2-1][counterX2+1] = 0;
                            }
                            if (counterX2+1 < dimension && outlineMap [counterY2][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                                outlineMap [counterY2][counterX2+1] = 0;
                            }
                            if (counterY2+1 < dimension && counterX2+1 < dimension && outlineMap [counterY2+1][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                                outlineMap [counterY2+1][counterX2+1] = 0;
                            }
                            if (counterY2+1 < dimension && outlineMap [counterY2+1][counterX2] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                                outlineMap [counterY2+1][counterX2] = 0;
                            }
                            if (counterY2+1 < dimension && counterX2-1 >= 0 && outlineMap [counterY2+1][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                                outlineMap [counterY2+1][counterX2-1] = 0;
                            }
                            if (counterX2-1 >= 0 && outlineMap [counterY2][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                                outlineMap [counterY2][counterX2-1] = 0;
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<newConnectivityMapTemp [counterA][counterB];
                //    cout<<" newConnectivityMapTemp "<<counterA<<endl;
                //}
                
                xPositionTempStart = 0;
                yPositionTempStart = 0;
                lineSize = 0;
                
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++) outlineMap2 [counterY2][counterX2] = 0;
                }
                
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                        if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                            outlineMap2 [counterY2][counterX2] = 1;
                            xPositionTempStart = counterX2;
                            yPositionTempStart = counterY2;
                            lineSize++;
                        }
                    }
                }
                
                for (int counter2 = 0; counter2 < dimension+4; counter2++) delete [] newConnectivityMapTemp [counter2];
                delete [] newConnectivityMapTemp;
                
                constructedLineCount = 0;
                
                int *arrayNewLines = new int [lineSize*2+50];
                
                outlineMap2 [yPositionTempStart][xPositionTempStart] = -1;
                arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                
                do{
                    
                    findFlag = 0;
                    terminationFlag2 = 0;
                    
                    if (xPositionTempStart+1 < dimension){
                        if (outlineMap2 [yPositionTempStart][xPositionTempStart+1] == 1){
                            outlineMap2 [yPositionTempStart][xPositionTempStart+1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart+1, terminationFlag2 = 1, findFlag = 1;
                        }
                    }
                    if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                        if (outlineMap2 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                            outlineMap2 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag2 = 1, findFlag = 1;
                        }
                    }
                    if (yPositionTempStart+1 < dimension && findFlag == 0){
                        if (outlineMap2 [yPositionTempStart+1][xPositionTempStart] == 1){
                            outlineMap2 [yPositionTempStart+1][xPositionTempStart] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                            yPositionTempStart = yPositionTempStart+1, terminationFlag2 = 1, findFlag = 1;
                        }
                    }
                    if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                        if (outlineMap2 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                            outlineMap2 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag2 = 1, findFlag = 1;
                        }
                    }
                    if (xPositionTempStart-1 >= 0 && findFlag == 0){
                        if (outlineMap2 [yPositionTempStart][xPositionTempStart-1] == 1){
                            outlineMap2 [yPositionTempStart][xPositionTempStart-1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart-1, terminationFlag2 = 1, findFlag = 1;
                        }
                    }
                    if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                        if (outlineMap2 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                            outlineMap2 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag2 = 1, findFlag = 1;
                        }
                    }
                    if (yPositionTempStart-1 >= 0 && findFlag == 0){
                        if (outlineMap2 [yPositionTempStart-1][xPositionTempStart] == 1){
                            outlineMap2 [yPositionTempStart-1][xPositionTempStart] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                            yPositionTempStart = yPositionTempStart-1, terminationFlag2 = 1, findFlag = 1;
                        }
                    }
                    if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                        if (outlineMap2 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                            outlineMap2 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag2 = 1;
                        }
                    }
                    
                } while (terminationFlag2 == 1);
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<outlineMap2 [counterA][counterB];
                //    cout<<" outlineMap2 "<<counterA<<endl;
                //}
                
                newConnectLineNo++;
                
                for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                    if (outlineDataSetCount+3 > outlineDataSetLimit){
                        int *arrayUpDate = new int [outlineDataSetCount+10];
                        
                        for (int counter3 = 0; counter3 < outlineDataSetCount; counter3++) arrayUpDate [counter3] = outlineDataSet [counter3];
                        
                        delete [] outlineDataSet;
                        outlineDataSet = new int [outlineDataSetLimit+5000];
                        outlineDataSetLimit = outlineDataSetLimit+5000;
                        
                        for (int counter3 = 0; counter3 < outlineDataSetCount; counter3++) outlineDataSet [counter3] = arrayUpDate [counter3];
                        delete [] arrayUpDate;
                    }
                    
                    outlineDataSet [outlineDataSetCount] = newConnectLineNo, outlineDataSetCount++; //-----Vector no-----
                    outlineDataSet [outlineDataSetCount] = arrayNewLines [counter2*2], outlineDataSetCount++; //-----X Position-----
                    outlineDataSet [outlineDataSetCount] = arrayNewLines [counter2*2+1], outlineDataSetCount++; //-----Y Position-----
                }
                
                delete [] arrayNewLines;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (outlineMap2 [counterY][counterX] == -1) outlineMap2 [counterY][counterX] = outlineMap2 [counterY][counterX]*-1;
                    }
                }
                
                connectivityNumber = -3;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (outlineMap2 [counterY][counterX] == 0){
                            connectivityNumber = connectivityNumber+2;
                            outlineMap2 [counterY][counterX] = connectivityNumber;
                            
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && outlineMap2 [counterY-1][counterX] == 0){
                                outlineMap2 [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension && outlineMap2 [counterY][counterX+1] == 0){
                                outlineMap2 [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && outlineMap2 [counterY+1][counterX] == 0){
                                outlineMap2 [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && outlineMap2 [counterY][counterX-1] == 0){
                                outlineMap2 [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                        
                                        if (ySource-1 >= 0 && outlineMap2 [ySource-1][xSource] == 0){
                                            outlineMap2 [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension && outlineMap2 [ySource][xSource+1] == 0){
                                            outlineMap2 [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && outlineMap2 [ySource+1][xSource] == 0){
                                            outlineMap2 [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && outlineMap2 [ySource][xSource-1] == 0){
                                            outlineMap2 [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<outlineMap2 [counterA][counterB];
                //    cout<<" outlineMap2 "<<counterA<<endl;
                //}
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (outlineMap2 [counterY][counterX] == -1) outlineMap2 [counterY][counterX] = 0;
                        else outlineMap2 [counterY][counterX] = newConnectLineNo;
                    }
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (outlineMap2 [counterY][counterX] != 0){
                            outlineMap [counterY][counterX] = 0;
                            outlineMap3 [counterY][counterX] = outlineMap2 [counterY][counterX];
                        }
                        
                        if (outlineMap [counterY][counterX] != 0) outlineMap [counterY][counterX] = 0;
                    }
                }
            }
            
        } while (terminationFlag == 0);
    }
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++) connectivityMap [counterY][counterX] = outlineMap3 [counterY][counterX];
    }
    
    //for (int counterA = 0; counterA < outlineDataSetCount/3; counterA++){
    //    cout<<counterA<<" "<<outlineDataSet [counterA*3]<<" "<<outlineDataSet [counterA*3+1]<<" "<<outlineDataSet [counterA*3+2]<<" Outline "<<endl;
    //}
    
    //for (int counterA = 0; counterA < dimension; counterA++){
    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
    //	cout<<" connectivityMap "<<counterA<<endl;
    //}
    
    for (int counter1 = 0; counter1 < dimension+1; counter1++){
        delete [] outlineMap [counter1];
        delete [] outlineMap2 [counter1];
        delete [] outlineMap3 [counter1];
    }
    
    delete [] outlineMap;
    delete [] outlineMap2;
    delete [] outlineMap3;
    
    //-----Determine number of pixels-----
    connectedPix = new int [newConnectLineNo+50];
    
    for (int counter1 = 0; counter1 <= newConnectLineNo; counter1++) connectedPix [counter1] = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMap [counterY][counterX] != 0) connectedPix [connectivityMap [counterY][counterX]]++;
        }
    }
    
    int *pixNumberRef = new int [newConnectLineNo+2];
    
    for (int counter1 = 0; counter1 < newConnectLineNo+1; counter1++) pixNumberRef [counter1] = 0;
    
    delete [] connectAnalysisX;
    delete [] connectAnalysisY;
    delete [] connectAnalysisTempX;
    delete [] connectAnalysisTempY;
    
    int results = 0;
    
    if (newConnectLineNo == 0 && type == 1) results = 0;
    else{
        
        results = 1;
        
        if (newConnectLineNo == 0 && type == 2){
            int *arrayTimeOneTemp = new int [positionReviseCount+50], timeOneTempCount = 0;
            
            for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                if (arrayPositionRevise [counter1*7+3] == valueTemp){
                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+1], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+2], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+3], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+4], timeOneTempCount++;
                    
                    if (arrayPositionRevise [counter1*7+5] == 0) arrayTimeOneTemp [timeOneTempCount] = 2, timeOneTempCount++;
                    else if (arrayPositionRevise [counter1*7+5] == 1) arrayTimeOneTemp [timeOneTempCount] = 3, timeOneTempCount++;
                    else arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+5], timeOneTempCount++;
                    
                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+6], timeOneTempCount++;
                }
                else{
                    
                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+1], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+2], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+3], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+4], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+5], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+6], timeOneTempCount++;
                }
            }
            
            positionReviseCount = 0;
            for (int counter1 = 0; counter1 < timeOneTempCount; counter1++) arrayPositionRevise [positionReviseCount] = arrayTimeOneTemp [counter1], positionReviseCount++;
            
            //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
            //	cout<<" arrayPositionRevise "<<counterA<<endl;
            //}
            
            delete [] arrayTimeOneTemp;
            arrayTimeOneTemp = new int [timeSelectedCount+50];
            timeOneTempCount = 0;
            
            for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                if (counter1+1 == valueTemp && arrayTimeSelected [counter1*10] != 3 && arrayTimeSelected [counter1*10] != 4){
                    if (arrayTimeSelected [counter1*10] == 0 || arrayTimeSelected [counter1*10] == 5 || arrayTimeSelected [counter1*10] == 6) arrayTimeOneTemp [timeOneTempCount] = 3, timeOneTempCount++;
                    else if (arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7 || arrayTimeSelected [counter1*10] == 2) arrayTimeOneTemp [timeOneTempCount] = 4, timeOneTempCount++;
                    
                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+1], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+2], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = lineEntryNumber, timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+4], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+5], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+6], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+7], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+8], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+9], timeOneTempCount++;
                }
                else{
                    
                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+1], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+2], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+3], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+4], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+5], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+6], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+7], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+8], timeOneTempCount++;
                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+9], timeOneTempCount++;
                }
            }
            
            timeSelectedCount = 0;
            for (int counter1 = 0; counter1 < timeOneTempCount; counter1++) arrayTimeSelected [timeSelectedCount] = arrayTimeOneTemp [counter1],timeSelectedCount++;
            
            delete [] arrayTimeOneTemp;
            
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //	cout<<" arrayTimeSelecte "<<counterA+1<<endl;
            //}
            
            for (int counterY = 0; counterY < imageDimension; counterY++){
                for (int counterX = 0; counterX < imageDimension; counterX++){
                    if (revisedWorkingMap [counterY][counterX] == valueTemp) revisedWorkingMap [counterY][counterX] = 0;
                }
            }
        }
        
        if (newConnectLineNo > 0){
            int entryCount = 0;
            int gravityCenter1 [4];
            int maxVectorNumber = 0;
            
            if (gravityCenterRevCount != 0) maxVectorNumber = arrayGravityCenterRev [(gravityCenterRevCount/6-1)*6+4];
            
            int xGravityImageTemp = 0;
            int yGravityImageTemp = 0;
            int gravityX1 = 0;
            int gravityY1 = 0;
            int totalGRCount = 0;
            int averageIntensity = 0;
            int timeOneTempCount = 0;
            int lastConnectPosition = 0;
            
            for (int counter1 = 1; counter1 < newConnectLineNo+1; counter1++){
                if (connectedPix [counter1] != 0){
                    gravityCenter1 [0] = 0;
                    gravityCenter1 [1] = 0;
                    gravityCenter1 [2] = 0;
                    gravityCenter1 [3] = 0;
                    
                    //cout<<horizontalStart<<" "<<verticalStart<<" "<<dimension<<" hol-ver-dim"<<endl;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMap [counterY][counterX] == counter1){
                                gravityCenter1 [0] = gravityCenter1 [0]+counterX;
                                gravityCenter1 [1] = gravityCenter1 [1]+counterY;
                                gravityCenter1 [2]++;
                                
                                xGravityImageTemp = counterX+horizontalStart;
                                yGravityImageTemp = counterY+verticalStart;
                                
                                if (xGravityImageTemp > imageDimension) xGravityImageTemp = imageDimension-1;
                                if (xGravityImageTemp < 0) xGravityImageTemp = 0;
                                if (yGravityImageTemp > imageDimension) yGravityImageTemp = imageDimension-1;
                                if (yGravityImageTemp < 0) yGravityImageTemp = 0;
                                
                                gravityCenter1 [3] = gravityCenter1 [3]+sourceImage [yGravityImageTemp][xGravityImageTemp];
                            }
                        }
                    }
                    
                    //cout<<gravityCenter1 [0]<<" "<<gravityCenter1 [1]<<" "<<gravityCenter1 [2]<<" "<<gravityCenter1 [3]<<" GRData"<<endl;
                    
                    averageIntensity = (int)(gravityCenter1 [3]/(double)gravityCenter1 [2]);
                    
                    //cout<<gravityX1<<" "<<gravityY1<<" "<<averageIntensity<<" "<<entryCount<<" GRCenter"<<endl;
                    
                    //-----First Connect Get and Set required data-----
                    if (entryCount == 0){
                        entryCount = 1;
                        
                        if (type == 2){
                            int *arrayTimeOneTemp = new int [timeSelectedCount+50];
                            timeOneTempCount = 0;
                            
                            for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                                if (counter2+1 == valueTemp && arrayTimeSelected [counter2*10] != 3 && arrayTimeSelected [counter2*10] != 4){
                                    if (arrayTimeSelected [counter2*10] == 0 || arrayTimeSelected [counter2*10] == 5 || arrayTimeSelected [counter2*10] == 6) arrayTimeOneTemp [timeOneTempCount] = 3, timeOneTempCount++;
                                    else if (arrayTimeSelected [counter2*10] == 1 || arrayTimeSelected [counter2*10] == 7 || arrayTimeSelected [counter2*10] == 2) arrayTimeOneTemp [timeOneTempCount] = 4, timeOneTempCount++;
                                    
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+1], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+2], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = lineEntryNumber, timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+4], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+5], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+6], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+7], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+8], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+9], timeOneTempCount++;
                                }
                                else{
                                    
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+1], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+2], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+3], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+4], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+5], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+6], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+7], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+8], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+9], timeOneTempCount++;
                                }
                            }
                            
                            timeSelectedCount = 0;
                            for (int counter2 = 0; counter2 < timeOneTempCount; counter2++) arrayTimeSelected [timeSelectedCount] = arrayTimeOneTemp [counter2], timeSelectedCount++;
                            
                            delete [] arrayTimeOneTemp;
                            arrayTimeOneTemp = new int [positionReviseCount+50];
                            timeOneTempCount = 0;
                            
                            for (int counter2 = 0; counter2 < positionReviseCount/7; counter2++){
                                if (arrayPositionRevise [counter2*7+3] == valueTemp){
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+1], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+2], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+3], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+4], timeOneTempCount++;
                                    
                                    if (arrayPositionRevise [counter2*7+5] == 0) arrayTimeOneTemp [timeOneTempCount] = 2, timeOneTempCount++;
                                    else if (arrayPositionRevise [counter2*7+5] == 1) arrayTimeOneTemp [timeOneTempCount] = 3, timeOneTempCount++;
                                    else arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+5], timeOneTempCount++;
                                    
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+6], timeOneTempCount++;
                                }
                                else{
                                    
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+1], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+2], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+3], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+4], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+5], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+6], timeOneTempCount++;
                                }
                            }
                            
                            positionReviseCount = 0;
                            for (int counter2 = 0; counter2 < timeOneTempCount; counter2++) arrayPositionRevise [positionReviseCount] = arrayTimeOneTemp [counter2], positionReviseCount++;
                            
                            delete [] arrayTimeOneTemp;
                            
                            //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
                            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
                            //	cout<<" arrayPositionRevise "<<counterA<<endl;
                            //}
                            
                            for (int counterY = 0; counterY < imageDimension; counterY++){
                                for (int counterX = 0; counterX < imageDimension; counterX++){
                                    if (revisedWorkingMap [counterY][counterX] == valueTemp) revisedWorkingMap [counterY][counterX] = 0;
                                }
                            }
                        }
                    }
                    
                    //-----Process Connect pixels-----
                    maxVectorNumber++;
                    pixNumberRef [counter1] = maxVectorNumber;
                    
                    if (positionReviseCount+outlineDataSetCount*3 > positionReviseLimit){
                        positionReviseAddition = outlineDataSetCount*3;
                        
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate positionRevSelectedUpDate];
                    }
                    
                    lastConnectPosition = positionReviseCount/7;
                    
                    for (int counter2 = 0; counter2 < outlineDataSetCount/3; counter2++){
                        if (outlineDataSet [counter2*3] == counter1){
                            arrayPositionRevise [positionReviseCount] = outlineDataSet [counter2*3+1]+horizontalStart, positionReviseCount++;
                            arrayPositionRevise [positionReviseCount] = outlineDataSet [counter2*3+2]+verticalStart, positionReviseCount++;
                            
                            if (outlineDataSet [counter2*3+2]+verticalStart >= 0 && outlineDataSet [counter2*3+2]+verticalStart < imageDimension && outlineDataSet [counter2*3+1]+horizontalStart >= 0 && outlineDataSet [counter2*3+1]+horizontalStart < imageDimension){
                                arrayPositionRevise [positionReviseCount] = sourceImage [outlineDataSet [counter2*3+2]+verticalStart][outlineDataSet [counter2*3+1]+horizontalStart], positionReviseCount++;
                            }
                            else arrayPositionRevise [positionReviseCount] = 100, positionReviseCount++;
                            
                            arrayPositionRevise [positionReviseCount] = maxVectorNumber, positionReviseCount++;
                            arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++;
                            
                            if (type == 1 && processSet != 4){
                                arrayPositionRevise [positionReviseCount] = 1, positionReviseCount++;
                            }
                            else arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++;
                            
                            arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++;
                        }
                    }
                    
                    if (type == 2){
                        gravityX1 = 0;
                        gravityY1 = 0;
                        totalGRCount = 0;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] == counter1 && internalZeroMap [counterY][counterX] == 0){
                                    revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] = maxVectorNumber;
                                    
                                    gravityX1 = gravityX1+counterX+horizontalStart;
                                    gravityY1 = gravityY1+counterY+verticalStart;
                                    totalGRCount++;
                                }
                            }
                        }
                        
                        gravityX1 = (int)(gravityX1/(double)totalGRCount);
                        gravityY1 = (int)(gravityY1/(double)totalGRCount);
                    }
                    else{
                        
                        gravityX1 = 0;
                        gravityY1 = 0;
                        totalGRCount = 0;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] == counter1 && internalZeroMap [counterY][counterX] == 0){
                                    gravityX1 = gravityX1+counterX+horizontalStart;
                                    gravityY1 = gravityY1+counterY+verticalStart;
                                    totalGRCount++;
                                }
                            }
                        }
                        
                        gravityX1 = (int)(gravityX1/(double)totalGRCount);
                        gravityY1 = (int)(gravityY1/(double)totalGRCount);
                    }
                    
                    //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
                    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
                    //	cout<<" arrayPositionRevise "<<counterA<<endl;
                    //}
                    
                    if (gravityCenterRevCount+12 > gravityCenterRevLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate gravityCenterRevUpDate];
                    }
                    
                    arrayGravityCenterRev [gravityCenterRevCount] = gravityX1, gravityCenterRevCount++;
                    arrayGravityCenterRev [gravityCenterRevCount] = gravityY1, gravityCenterRevCount++;
                    arrayGravityCenterRev [gravityCenterRevCount] = gravityCenter1 [2], gravityCenterRevCount++;
                    arrayGravityCenterRev [gravityCenterRevCount] = averageIntensity, gravityCenterRevCount++;
                    arrayGravityCenterRev [gravityCenterRevCount] = maxVectorNumber, gravityCenterRevCount++;
                    arrayGravityCenterRev [gravityCenterRevCount] = 0, gravityCenterRevCount++;
                    
                    //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
                    //	cout<<" arrayGravityCenterRev "<<counterA<<endl;
                    //}
                    
                    if (associateDataCount+12 > associateDataLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate associateDataUpDate];
                    }
                    
                    arrayAssociateData [associateDataCount] = maxVectorNumber, associateDataCount++;
                    arrayAssociateData [associateDataCount] = 0, associateDataCount++;
                    arrayAssociateData [associateDataCount] = 0, associateDataCount++;
                    arrayAssociateData [associateDataCount] = 0, associateDataCount++;
                    arrayAssociateData [associateDataCount] = 0, associateDataCount++;
                    arrayAssociateData [associateDataCount] = 0, associateDataCount++;
                    
                    if (timeSelectedCount+10 > timeSelectedLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate timeSelectedUpDate];
                    }
                    
                    if (type == 1 && processSet != 4) arrayTimeSelected [timeSelectedCount] = 7, timeSelectedCount++;
                    else arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                    
                    arrayTimeSelected [timeSelectedCount] = lineEntryNumber, timeSelectedCount++;
                    arrayTimeSelected [timeSelectedCount] = lastConnectPosition, timeSelectedCount++;
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                    arrayTimeSelected [timeSelectedCount] = maxVectorNumber, timeSelectedCount++;
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                    
                    //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                    //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                    //	cout<<" arrayTimeSelected "<<counterA+1<<" "<<counter1<<endl;
                    //}
                }
            }
            
            if (type == 1){
                int **mapTemp = new int *[dimension+1];
                for (int counter1 = 0; counter1 < dimension+1; counter1++) mapTemp [counter1] = new int [dimension+1];
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) mapTemp [counterY][counterX] = 0;
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMap [counterY][counterX] != 0){
                            mapTemp [counterY][counterX] = pixNumberRef [connectivityMap [counterY][counterX]];
                        }
                    }
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        connectivityMap [counterY][counterX] = 0;
                        connectivityMap [counterY][counterX] = mapTemp [counterY][counterX];
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
                //	cout<<" connectivityMap "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < dimension+1; counter1++) delete [] mapTemp [counter1];
                delete [] mapTemp;
            }
        }
    }
    
    delete [] pixNumberRef;
    delete [] outlineDataSet;
    delete [] connectedPix;
    
    return results;
}

@end
