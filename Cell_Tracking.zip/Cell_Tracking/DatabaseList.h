//
//  DatabaseList.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-05-28.
//

#ifndef DATABASELIST_H
#define DATABASELIST_H
#import "Controller.h"
#endif

@interface DatabaseList : NSObject{
    IBOutlet NSTextField *lingNoSetDisplay;
    IBOutlet NSTextField *cellNoSetDisplay;
    IBOutlet NSTextField *timeSetDisplay;
    IBOutlet NSTextField *connectNoSetDisplay;
    IBOutlet NSTextField *channelNoSetDisplay;
    
    IBOutlet NSTextField *lineDataCurrentDisplay;
    IBOutlet NSTextField *dataStructureDisplay;
    
    IBOutlet NSTextField *replaceFromTextDisplay;
    IBOutlet NSTextField *replaceToTextDisplay;
    IBOutlet NSTextField *replaceLineFromDisplay;
    IBOutlet NSTextField *replaceLineToDisplay;
    IBOutlet NSTextField *removeLineFromDisplay;
    IBOutlet NSTextField *removeLineToDisplay;
    
    id dataRepairReadWrite;
}

-(void)listStringUpDate;

-(IBAction)listLing:(id)sender;
-(IBAction)listPR:(id)sender;
-(IBAction)listST:(id)sender;
-(IBAction)listGR:(id)sender;
-(IBAction)listAD:(id)sender;
-(IBAction)listRL:(id)sender;
-(IBAction)listMap:(id)sender;
-(IBAction)listFluorescentLine:(id)sender;
-(IBAction)listFluorescentArea:(id)sender;
-(IBAction)listFluorescentCut:(id)sender;
-(IBAction)listPartner:(id)sender;
-(IBAction)listMitosis:(id)sender;
-(IBAction)listClear:(id)sender;

-(IBAction)boxClear:(id)sender;
-(IBAction)lingGetSelf:(id)sender;
-(IBAction)lingGetPartner:(id)sender;
-(IBAction)lingClear:(id)sender;
-(IBAction)cellGetSelf:(id)sender;
-(IBAction)cellGetPartner:(id)sender;
-(IBAction)cellClear:(id)sender;
-(IBAction)chGetSelf:(id)sender;
-(IBAction)chClear:(id)sender;
-(IBAction)connectGetSelf:(id)sender;
-(IBAction)connectClear:(id)sender;
-(IBAction)timeClear:(id)sender;

-(IBAction)cellLingNoGet:(id)sender;
-(IBAction)xyPositionShow:(id)sender;

@end
