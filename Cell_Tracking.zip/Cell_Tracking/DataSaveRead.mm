//
//  DataSaveRead.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-04-05.
//

#import "DataSaveRead.h"

@implementation DataSaveRead

-(int)lineageDataRead{
    int errorFind = 0;
    
    lineageDataCount = 0;
    
    string connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+saveInfo+"_Connect/"+ analysisID+"_"+saveInfo+"_LineageData";
    
    struct stat sizeOfFile;
    long sizeForCopy = 0;
    long size1 = 0;
    long size2 = 0;
    int checkFlag = 0;
    
    for (int counter1 = 0; counter1 < 6; counter1++){
        sizeForCopy = 0;
        
        if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (sizeForCopy != 0){
            if (counter1 == 0) size1 = sizeForCopy;
            else if (counter1 == 1) size2 = sizeForCopy;
            else if (counter1 == 2){
                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                    checkFlag = 1;
                    break;
                }
                else{
                    
                    size1 = 0;
                    size2 = 0;
                    usleep (50000);
                }
            }
            else if (counter1 == 3) size1 = sizeForCopy;
            else if (counter1 == 4) size2 = sizeForCopy;
            else if (counter1 == 5){
                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                    checkFlag = 1;
                }
            }
        }
    }
    
    if (checkFlag == 1){
        if (lineageDataStatus == 0){
            arrayLineageData = new int [sizeForCopy+50];
            lineageDataLimit = (int)sizeForCopy+50;
            lineageDataStatus = 1;
        }
        else if (sizeForCopy > lineageDataCount){
            delete [] arrayLineageData;
            arrayLineageData = new int [sizeForCopy+50];
            lineageDataLimit = (int)sizeForCopy+50;
        }
        
        ifstream fin;
        
        int finData [25];
        
        fin.open(connectDataPath.c_str(), ios::in | ios::binary);
        
        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
        fin.read((char*)uploadTemp, sizeForCopy+50);
        
        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0){
            usleep(50000);
            fin.read((char*)uploadTemp, sizeForCopy+50);
            
            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0){
                errorFind = 1;
            }
        }
        
        fin.close();
        
        if (errorFind == 0){
            unsigned long readPosition = 0;
            int stepCount = 0;
            
            do{
                
                if (stepCount == 0){
                    finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                    finData [1] = uploadTemp [readPosition], readPosition++;
                    finData [2] = uploadTemp [readPosition], readPosition++; //--2 X Position
                    finData [3] = uploadTemp [readPosition], readPosition++; //--3 +-
                    finData [4] = uploadTemp [readPosition], readPosition++;
                    finData [5] = uploadTemp [readPosition], readPosition++; //--4 Y Position
                    finData [6] = uploadTemp [readPosition], readPosition++;
                    finData [7] = uploadTemp [readPosition], readPosition++; //--5 Time point
                    finData [8] = uploadTemp [readPosition], readPosition++; //--6 Event type
                    finData [9] = uploadTemp [readPosition], readPosition++; //--7 +-
                    finData [10] = uploadTemp [readPosition], readPosition++;
                    finData [11] = uploadTemp [readPosition], readPosition++;
                    finData [12] = uploadTemp [readPosition], readPosition++;
                    finData [13] = uploadTemp [readPosition], readPosition++; //--8 Next cell/fuse no
                    finData [14] = uploadTemp [readPosition], readPosition++; //--9 +-
                    finData [15] = uploadTemp [readPosition], readPosition++;
                    finData [16] = uploadTemp [readPosition], readPosition++;
                    finData [17] = uploadTemp [readPosition], readPosition++;
                    finData [18] = uploadTemp [readPosition], readPosition++; //--10 Cell no
                    finData [19] = uploadTemp [readPosition], readPosition++;
                    finData [20] = uploadTemp [readPosition], readPosition++;
                    finData [21] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                    finData [22] = uploadTemp [readPosition], readPosition++;
                    finData [23] = uploadTemp [readPosition], readPosition++;
                    finData [24] = uploadTemp [readPosition], readPosition++; //--12 Lineage no Fuse
                    
                    if (finData [0] == 1) finData [2] = (finData [1]*256+finData [2])*-1;
                    else finData [2] = finData [1]*256+finData [2];
                    
                    if (finData [3] == 1) finData [5] = (finData [4]*256+finData [5])*-1;
                    else finData [5] = finData [4]*256+finData [5];
                    
                    finData [7] = finData [6]*256+finData [7];
                    
                    if (finData [9] == 1) finData [13] = (finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13])*-1;
                    else finData [13] = finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13];
                    
                    if (finData [14] == 1) finData [18] = (finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18])*-1;
                    else finData [18] = finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18];
                    
                    finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                    finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                    
                    if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                    else{
                        
                        arrayLineageData [lineageDataCount] = finData [2], lineageDataCount++;
                        arrayLineageData [lineageDataCount] = finData [5], lineageDataCount++;
                        arrayLineageData [lineageDataCount] = finData [7], lineageDataCount++;
                        arrayLineageData [lineageDataCount] = finData [8], lineageDataCount++;
                        arrayLineageData [lineageDataCount] = finData [13], lineageDataCount++;
                        arrayLineageData [lineageDataCount] = finData [18], lineageDataCount++;
                        arrayLineageData [lineageDataCount] = finData [21], lineageDataCount++;
                        arrayLineageData [lineageDataCount] = finData [24], lineageDataCount++;
                    }
                }
                
            } while (stepCount != 3);
        }
        
        delete [] uploadTemp;
    }
    
    if (checkFlag == 0 || errorFind == 1){
        errorFind = 0;
        size1 = 0;
        size2 = 0;
        checkFlag = 0;
        
        for (int counter1 = 0; counter1 < 6; counter1++){
            sizeForCopy = 0;
            
            if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (sizeForCopy != 0){
                if (counter1 == 0) size1 = sizeForCopy;
                else if (counter1 == 1) size2 = sizeForCopy;
                else if (counter1 == 2){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                        break;
                    }
                    else{
                        
                        size1 = 0;
                        size2 = 0;
                        usleep (50000);
                    }
                }
                else if (counter1 == 3) size1 = sizeForCopy;
                else if (counter1 == 4) size2 = sizeForCopy;
                else if (counter1 == 5){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                    }
                }
            }
        }
        
        if (checkFlag == 1){
            if (lineageDataStatus == 0){
                arrayLineageData = new int [sizeForCopy+50];
                lineageDataLimit = (int)sizeForCopy+50;
                lineageDataStatus = 1;
            }
            else if (sizeForCopy > lineageDataCount){
                delete [] arrayLineageData;
                arrayLineageData = new int [sizeForCopy+50];
                lineageDataLimit = (int)sizeForCopy+50;
            }
            
            ifstream fin;
            
            int finData [25];
            
            fin.open(connectDataPath.c_str(), ios::in | ios::binary);
            
            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
            fin.read((char*)uploadTemp, sizeForCopy+50);
            
            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0){
                usleep(50000);
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0){
                    errorFind = 1;
                }
            }
            
            fin.close();
            
            if (errorFind == 0){
                unsigned long readPosition = 0;
                int stepCount = 0;
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                        finData [1] = uploadTemp [readPosition], readPosition++;
                        finData [2] = uploadTemp [readPosition], readPosition++; //--2 X Position
                        finData [3] = uploadTemp [readPosition], readPosition++; //--3 +-
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++; //--4 Y Position
                        finData [6] = uploadTemp [readPosition], readPosition++;
                        finData [7] = uploadTemp [readPosition], readPosition++; //--5 Time point
                        finData [8] = uploadTemp [readPosition], readPosition++; //--6 Event type
                        finData [9] = uploadTemp [readPosition], readPosition++; //--7 +-
                        finData [10] = uploadTemp [readPosition], readPosition++;
                        finData [11] = uploadTemp [readPosition], readPosition++;
                        finData [12] = uploadTemp [readPosition], readPosition++;
                        finData [13] = uploadTemp [readPosition], readPosition++; //--8 Next cell/fuse no
                        finData [14] = uploadTemp [readPosition], readPosition++; //--9 +-
                        finData [15] = uploadTemp [readPosition], readPosition++;
                        finData [16] = uploadTemp [readPosition], readPosition++;
                        finData [17] = uploadTemp [readPosition], readPosition++;
                        finData [18] = uploadTemp [readPosition], readPosition++; //--10 Cell no
                        finData [19] = uploadTemp [readPosition], readPosition++;
                        finData [20] = uploadTemp [readPosition], readPosition++;
                        finData [21] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                        finData [22] = uploadTemp [readPosition], readPosition++;
                        finData [23] = uploadTemp [readPosition], readPosition++;
                        finData [24] = uploadTemp [readPosition], readPosition++; //--12 Lineage no Fuse
                        
                        if (finData [0] == 1) finData [2] = (finData [1]*256+finData [2])*-1;
                        else finData [2] = finData [1]*256+finData [2];
                        
                        if (finData [3] == 1) finData [5] = (finData [4]*256+finData [5])*-1;
                        else finData [5] = finData [4]*256+finData [5];
                        
                        finData [7] = finData [6]*256+finData [7];
                        
                        if (finData [9] == 1) finData [13] = (finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13])*-1;
                        else finData [13] = finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13];
                        
                        if (finData [14] == 1) finData [18] = (finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18])*-1;
                        else finData [18] = finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18];
                        
                        finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                        finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                        
                        if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                        else{
                            
                            arrayLineageData [lineageDataCount] = finData [2], lineageDataCount++;
                            arrayLineageData [lineageDataCount] = finData [5], lineageDataCount++;
                            arrayLineageData [lineageDataCount] = finData [7], lineageDataCount++;
                            arrayLineageData [lineageDataCount] = finData [8], lineageDataCount++;
                            arrayLineageData [lineageDataCount] = finData [13], lineageDataCount++;
                            arrayLineageData [lineageDataCount] = finData [18], lineageDataCount++;
                            arrayLineageData [lineageDataCount] = finData [21], lineageDataCount++;
                            arrayLineageData [lineageDataCount] = finData [24], lineageDataCount++;
                        }
                    }
                    
                } while (stepCount != 3);
            }
            
            delete [] uploadTemp;
        }
    }
    
    if (checkFlag == 0 || errorFind == 1) errorFind = 1;
    
    return errorFind;
}

-(void)saveTrackingCurrent{
    string savedDataPath = trackDataFolderPath+"/*LineageTrackingCurrent.dat";
    
    ofstream oin;
    oin.open(savedDataPath.c_str(), ios::out);
    
    oin<<analysisImageName<<endl;
    oin<<analysisID<<endl;
    oin<<autoExpand<<endl;
    oin<<autoExpandLine<<endl;
    oin<<trackingCheckInterval<<endl;
    oin<<queueDisplayOptions<<endl;
    oin<<doneDisplayOptions<<endl;
    oin<<imageReturnPosition<<endl;
    
    if (ifEntry == 0){
        oin<<fluorescentEntryCount<<endl;
        oin<<fluorescentNo1<<endl;
        oin<<fluorescentNo2<<endl;
        oin<<fluorescentNo3<<endl;
        oin<<fluorescentNo4<<endl;
        oin<<fluorescentNo5<<endl;
        oin<<fluorescentNo6<<endl;
        
        if (fluorescentName1 != "") oin<<fluorescentName1<<endl;
        else oin<<"nil"<<endl;
        
        if (fluorescentName2 != "") oin<<fluorescentName2<<endl;
        else oin<<"nil"<<endl;
        
        if (fluorescentName3 != "") oin<<fluorescentName3<<endl;
        else oin<<"nil"<<endl;
        
        if (fluorescentName4 != "") oin<<fluorescentName4<<endl;
        else oin<<"nil"<<endl;
        
        if (fluorescentName5 != "") oin<<fluorescentName5<<endl;
        else oin<<"nil"<<endl;
        
        if (fluorescentName6 != "") oin<<fluorescentName6<<endl;
        else oin<<"nil"<<endl;
    }
    else{
        
        oin<<fluorescentEntryCountHold<<endl;
        oin<<fluorescentNoHold1<<endl;
        oin<<fluorescentNoHold2<<endl;
        oin<<fluorescentNoHold3<<endl;
        oin<<fluorescentNoHold4<<endl;
        oin<<fluorescentNoHold5<<endl;
        oin<<fluorescentNoHold6<<endl;
        
        if (fluorescentNameHold1 != "") oin<<fluorescentNameHold1<<endl;
        else oin<<"nil"<<endl;
        
        if (fluorescentNameHold2 != "") oin<<fluorescentNameHold2<<endl;
        else oin<<"nil"<<endl;
        
        if (fluorescentNameHold3 != "") oin<<fluorescentNameHold3<<endl;
        else oin<<"nil"<<endl;
        
        if (fluorescentNameHold4 != "") oin<<fluorescentNameHold4<<endl;
        else oin<<"nil"<<endl;
        
        if (fluorescentNameHold5 != "") oin<<fluorescentNameHold5<<endl;
        else oin<<"nil"<<endl;
        
        if (fluorescentNameHold6 != "") oin<<fluorescentNameHold6<<endl;
        else oin<<"nil"<<endl;
    }
    
    for (int counter1 = 0; counter1 < treatmentStatusCount; counter1++) oin<<arrayTreatmentStatus [counter1]<<endl;
    
    oin<<"IFDATA"<<endl;
    
    for (int counter1 = 0; counter1 < 450; counter1 = counter1+15){
        if (arrayIFDataHold [counter1] != "nil"){
            oin<<arrayIFDataHold [counter1]<<endl;
            oin<<arrayIFDataHold [counter1+1]<<endl;
            oin<<arrayIFDataHold [counter1+2]<<endl;
            oin<<arrayIFDataHold [counter1+3]<<endl;
            oin<<arrayIFDataHold [counter1+4]<<endl;
            oin<<arrayIFDataHold [counter1+5]<<endl;
            oin<<arrayIFDataHold [counter1+6]<<endl;
            oin<<arrayIFDataHold [counter1+7]<<endl;
            oin<<arrayIFDataHold [counter1+8]<<endl;
            oin<<arrayIFDataHold [counter1+9]<<endl;
            oin<<arrayIFDataHold [counter1+10]<<endl;
            oin<<arrayIFDataHold [counter1+11]<<endl;
            oin<<arrayIFDataHold [counter1+12]<<endl;
            oin<<arrayIFDataHold [counter1+13]<<endl;
            oin<<arrayIFDataHold [counter1+14]<<endl;
        }
        else{
            
            break;
        }
    }
    
    oin<<"END"<<endl;
    
    oin.close();
    
    string trackAnalysisSaveFilePath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+"*TrackingSetting.dat";
    
    oin.open(trackAnalysisSaveFilePath.c_str(), ios::out);
    oin<<analysisImageName<<endl;
    oin<<analysisID<<endl;
    oin<<autoExpand<<endl;
    oin<<autoExpandLine<<endl;
    oin<<trackingCheckInterval<<endl;
    oin<<queueDisplayOptions<<endl;
    oin<<doneDisplayOptions<<endl;
    oin<<imageReturnPosition<<endl;
    
    if (ifEntry == 0){
        oin<<fluorescentEntryCount<<endl;
        oin<<fluorescentNo1<<endl;
        oin<<fluorescentNo2<<endl;
        oin<<fluorescentNo3<<endl;
        oin<<fluorescentNo4<<endl;
        oin<<fluorescentNo5<<endl;
        oin<<fluorescentNo6<<endl;
        
        if (fluorescentName1 != "") oin<<fluorescentName1<<endl;
        else oin<<"nil"<<endl;
        
        if (fluorescentName2 != "") oin<<fluorescentName2<<endl;
        else oin<<"nil"<<endl;
        
        if (fluorescentName3 != "") oin<<fluorescentName3<<endl;
        else oin<<"nil"<<endl;
        
        if (fluorescentName4 != "") oin<<fluorescentName4<<endl;
        else oin<<"nil"<<endl;
        
        if (fluorescentName5 != "") oin<<fluorescentName5<<endl;
        else oin<<"nil"<<endl;
        
        if (fluorescentName6 != "") oin<<fluorescentName6<<endl;
        else oin<<"nil"<<endl;
    }
    else{
        
        oin<<fluorescentEntryCountHold<<endl;
        oin<<fluorescentNoHold1<<endl;
        oin<<fluorescentNoHold2<<endl;
        oin<<fluorescentNoHold3<<endl;
        oin<<fluorescentNoHold4<<endl;
        oin<<fluorescentNoHold5<<endl;
        oin<<fluorescentNoHold6<<endl;
        
        if (fluorescentNameHold1 != "") oin<<fluorescentNameHold1<<endl;
        else oin<<"nil"<<endl;
        
        if (fluorescentNameHold2 != "") oin<<fluorescentNameHold2<<endl;
        else oin<<"nil"<<endl;
        
        if (fluorescentNameHold3 != "") oin<<fluorescentNameHold3<<endl;
        else oin<<"nil"<<endl;
        
        if (fluorescentNameHold4 != "") oin<<fluorescentNameHold4<<endl;
        else oin<<"nil"<<endl;
        
        if (fluorescentNameHold5 != "") oin<<fluorescentNameHold5<<endl;
        else oin<<"nil"<<endl;
        
        if (fluorescentNameHold6 != "") oin<<fluorescentNameHold6<<endl;
        else oin<<"nil"<<endl;
    }
    
    for (int counter1 = 0; counter1 < treatmentStatusCount; counter1++) oin<<arrayTreatmentStatus [counter1]<<endl;
    
    oin<<"IFDATA"<<endl;
    
    for (int counter1 = 0; counter1 < 450; counter1 = counter1+15){
        if (arrayIFDataHold [counter1] != "nil"){
            oin<<arrayIFDataHold [counter1]<<endl;
            oin<<arrayIFDataHold [counter1+1]<<endl;
            oin<<arrayIFDataHold [counter1+2]<<endl;
            oin<<arrayIFDataHold [counter1+3]<<endl;
            oin<<arrayIFDataHold [counter1+4]<<endl;
            oin<<arrayIFDataHold [counter1+5]<<endl;
            oin<<arrayIFDataHold [counter1+6]<<endl;
            oin<<arrayIFDataHold [counter1+7]<<endl;
            oin<<arrayIFDataHold [counter1+8]<<endl;
            oin<<arrayIFDataHold [counter1+9]<<endl;
            oin<<arrayIFDataHold [counter1+10]<<endl;
            oin<<arrayIFDataHold [counter1+11]<<endl;
            oin<<arrayIFDataHold [counter1+12]<<endl;
            oin<<arrayIFDataHold [counter1+13]<<endl;
            oin<<arrayIFDataHold [counter1+14]<<endl;
        }
        else{
            
            break;
        }
    }
    
    oin<<"END"<<endl;
    
    oin.close();
}

-(void)saveParameters{
    string trackingParameterPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"TrackingParameters";
    
    ofstream oin;
    oin.open(trackingParameterPath.c_str(), ios::out);
    oin<<autoTrackingLimitHold<<endl;
    oin<<mitosisSDHold<<endl;
    oin<<mitosisValueHold<<endl;
    oin<<divisionDistanceHold<<endl;
    oin<<mitosisAreaHold<<endl;
    oin<<mitosisRelativeLowHold<<endl;
    oin<<mitosisRelativeHighHold<<endl;
    oin<<jumpAllFlag<<endl;
    oin<<connectExpandFlag<<endl;
    oin<<mapMergeStatus<<endl;
    oin<<percentOverlap<<endl;
    oin<<gravityCenterMoveLimitFlag<<endl;
    oin<<autoCheckDistanceHold<<endl;
    oin<<autoCheckAreaHold<<endl;
    oin<<autoCheckDivisionHold<<endl;
    oin<<autoCheckDistanceFoldHold<<endl;
    oin<<autoCheckIntensityHold<<endl;
    oin<<optionalShiftPercent<<endl;
    oin<<mitosisOffFlag<<endl;
    oin<<fusionMarkSetFlag<<endl;
    oin.close();
}

-(void)reviseLineClear{
    if ((trackingOn == 3 && lineDraw == 1) || (trackingOn == 3 && lineDraw == 0 && doubleClickStatusHold == 2)){
        int lineSetError = 0;
        
        if (ifEntry == 0){
            imageNumber = imageNumberTrackForDisplay;
            
            lineSet = [[LineSet alloc] init];
            lineSetError = [lineSet dataRead:imageNumber];
            
            if (lineSetError == 0) clearBack = imageNumber;
        }
        else{
            
            imageNumber = imageNumberTrackForDisplay;
            int setImageDataPosition = ifStartHold-1;
            lineSet = [[LineSet alloc] init];
            lineSetError = [lineSet dataRead:setImageDataPosition];
            clearBack = imageNumber;
        }
        
        if (lineSetError == 0){
            
            setStatus4 = 4;
            keyLockON = 0;
            lineDraw = 0;
            windowLock = 0;
            doubleClick = 0;
            doubleClickStatusHold = 0;
            trackingImageLock = 0;
            trackingOn = 7;
            trackingPermit = 0;
            tableTrackingProcessing = 0;
            listSwitchCall = 1;
            tableDataSetDone = 0;
            trackingTableSetDone = 1;
            lineModificationRecord = 0;
            lineModificationFlag = 0;
            firstModificationPoint = 10000;
            
            fluorescentDisplayNo = 0;
            
            upperLimitMap = 1;
            trackingLowerLimit = 0;
            trackingUpperLimit = 0;
            trackingOnInfoDisplay = 2;
            cellDivisionSetCount = 0;
            divisionTypeHold = 0;
            fusionOperation = 0;
            fusionPartnerLin = 0;
            fusionPartnerCellNo = -1;
            fusionMarkImage = 10000;
            fusionStatusFollow = 0;
            
            mergeSelectCount = 0;
            cellEndHoldCount = 0;
            
            cellNoHoldDiv1 = "";
            cellNoHoldDiv2 = "";
            cellNoHoldDiv3 = "";
            cellNoHoldDiv4 = "";
            divisionWarning = "";
            targetLostMark = "";
            
            string connectStatusTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold;
            
            string entry;
            string removeFilePath;
            
            fileDeleteCount = 0;
            
            DIR *dir;
            struct dirent *dent;
            
            dir = opendir(connectStatusTempPath.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (fileDeleteCount+5 > fileDeleteLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate fileDeleteUpDate];
                    }
                    
                    arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                }
                
                closedir(dir);
                
                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                    entry = arrayFileDelete [counter1];
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        int findFile1 = (int)entry.find("ConnectLineageRelTemp");
                        int findFile2 = (int)entry.find("CutTemp");
                        int findFile3 = (int)entry.find("GCCurrentTemp");
                        int findFile4 = (int)entry.find("MasterDataTemp");
                        int findFile5 = (int)entry.find("RevisedTempMap");
                        int findFile6 = (int)entry.find("StatusTemp");
                        int findFile7 = (int)entry.find("LinkDataTemp");
                        int findFile8 = (int)entry.find("ExtendAreaDataTemp");
                        int findFile9 = (int)entry.find("ExtendLineDataTemp");
                        int findFile10 = (int)entry.find("EventTemp");
                        int findFile11 = (int)entry.find("MitosisDataTemp");
                        int findFile12 = (int)entry.find("GCCenterInfo");
                        
                        if (findFile1 != -1 || findFile2 != -1 || findFile3 != -1 || findFile4 != -1 || findFile5 != -1 || findFile6 != -1 || findFile7 != -1 || findFile8 != -1 || findFile9 != -1 || findFile10 != -1 || findFile11 != -1 || findFile12 != -1){
                            removeFilePath = connectStatusTempPath+"/"+entry;
                            remove (removeFilePath.c_str());
                        }
                    }
                }
            }
        }
    }
}

@end
