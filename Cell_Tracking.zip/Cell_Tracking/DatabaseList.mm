//
//  DatabaseList.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-05-28.
//

#import "DatabaseList.h"

@implementation DatabaseList

-(IBAction)listLing:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && cleaningProgress == 0 && progressControl == 0){
        int lineageNoList = [lingNoSetDisplay integerValue];
        
        int cellNoList = [cellNoSetDisplay integerValue];
        NSString *cellNoNSString = [cellNoSetDisplay stringValue];
        
        if ([cellNoNSString isEqualToString:@""]){
            cellNoList = -1;
        }
        else{
            
            string cellNoString = [cellNoNSString UTF8String];
            
            if (cellNoString == "0") cellNoList = 0;
        }
        
        int timeList = [timeSetDisplay integerValue];
        
        if (lineageNoList >= 0){
            if (listStringStatus == 0){
                arrayListString = new string [5000];
                listStringCount = 0;
                listStringLimit = 5000;
                listStringStatus = 1;
            }
            else listStringCount = 0;
            
            [lineDataCurrentDisplay setStringValue:@"Lineage."];
            
            string lineData = "Lineage:Line No//Xposition/Yposition/Time/Event/Parent-fusion partner cell no/Cell no/Lineage. no/Fusion-partner Lineage no~~line marks";
            [dataStructureDisplay setStringValue:@(lineData.c_str())];
            
            if (checkListCount == 0 && treatmentNameHold != ""){
                nameStringRep = treatmentNameHold;
            }
            else nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
            
            lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+ analysisID+"_"+nameStringRep+"_LineageData";
            
            struct stat sizeOfFile;
            long sizeForCopy = 0;
            long size1 = 0;
            long size2 = 0;
            int checkFlag = 0;
            
            for (int counter1 = 0; counter1 < 6; counter1++){
                sizeForCopy = 0;
                
                if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter1 == 0) size1 = sizeForCopy;
                    else if (counter1 == 1) size2 = sizeForCopy;
                    else if (counter1 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter1 == 3) size1 = sizeForCopy;
                    else if (counter1 == 4) size2 = sizeForCopy;
                    else if (counter1 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            //-----Lineage data upload-----
            arrayLineageRepairData = new int [sizeForCopy+50];
            lineageDataRepairCount = 0;
            
            int returnValue2 = 0;
            
            if (checkFlag == 1){
                int processType2 = -1;
                
                dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                returnValue2 = [dataRepairReadWrite lineageDataSetList:sizeForCopy:processType2];
            }
            
            //for (int counterA = 0; counterA < lineageDataRepairCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageRepairData [counterA*8+counterB];
            //    cout<<" arrayLineageRepairData "<<counterA<<endl;
            //}
            
            if (returnValue2 == 0){
                int *arrayLineageRepairDataTemp = new int [lineageDataRepairCount/8+lineageDataRepairCount+20];
                int lineageDataRepairTempCount = 0;
                
                int *arrayLineageRepairDataTemp2 = new int [lineageDataRepairCount/8+lineageDataRepairCount+20];
                int lineageDataRepairTempCount2 = 0;
                
                for (int counter1 = 0; counter1 < lineageDataRepairCount/8; counter1++){
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayLineageRepairData [counter1*8], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayLineageRepairData [counter1*8+1], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayLineageRepairData [counter1*8+2], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayLineageRepairData [counter1*8+3], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayLineageRepairData [counter1*8+4], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayLineageRepairData [counter1*8+5], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayLineageRepairData [counter1*8+6], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayLineageRepairData [counter1*8+7], lineageDataRepairTempCount++;
                    arrayLineageRepairDataTemp [lineageDataRepairTempCount] = counter1, lineageDataRepairTempCount++;
                }
                
                if (lineageNoList > 0){
                    lineageDataRepairTempCount2 = 0;
                    
                    for (int counter1 = 0; counter1 < lineageDataRepairTempCount/9; counter1++){
                        if (arrayLineageRepairDataTemp [counter1*9+6] == lineageNoList){
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+1], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+2], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+3], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+4], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+5], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+6], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+7], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+8], lineageDataRepairTempCount2++;
                        }
                    }
                    
                    lineageDataRepairTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < lineageDataRepairTempCount2; counter1++) arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayLineageRepairDataTemp2 [counter1], lineageDataRepairTempCount++;
                }
                
                if (cellNoList != -1){
                    lineageDataRepairTempCount2 = 0;
                    
                    for (int counter1 = 0; counter1 < lineageDataRepairTempCount/9; counter1++){
                        if (arrayLineageRepairDataTemp [counter1*9+6] == lineageNoList && arrayLineageRepairDataTemp [counter1*9+5] == cellNoList){
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+1], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+2], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+3], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+4], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+5], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+6], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+7], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+8], lineageDataRepairTempCount2++;
                        }
                    }
                    
                    lineageDataRepairTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < lineageDataRepairTempCount2; counter1++) arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayLineageRepairDataTemp2 [counter1], lineageDataRepairTempCount++;
                }
                
                if (timeList > 0){
                    lineageDataRepairTempCount2 = 0;
                    
                    for (int counter1 = 0; counter1 < lineageDataRepairTempCount/9; counter1++){
                        if (arrayLineageRepairDataTemp [counter1*9+2] == timeList){
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+1], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+2], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+3], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+4], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+5], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+6], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+7], lineageDataRepairTempCount2++;
                            arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*9+8], lineageDataRepairTempCount2++;
                        }
                    }
                    
                    lineageDataRepairTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < lineageDataRepairTempCount2; counter1++) arrayLineageRepairDataTemp [lineageDataRepairTempCount] = arrayLineageRepairDataTemp2 [counter1], lineageDataRepairTempCount++;
                }
                
                lineageDataRepairTempCount2 = 0;
                
                for (int counter1 = 0; counter1 < lineageDataRepairTempCount; counter1++) arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1], lineageDataRepairTempCount2++;
                
                if (lineageDataRepairTempCount2 != 0){
                    listStringCount = 0;
                    
                    int maxXLength = 0;
                    int maxYLength = 0;
                    
                    for (int counter1 = 0; counter1 < lineageDataRepairTempCount2/9; counter1++){
                        if (maxXLength < arrayLineageRepairDataTemp2 [counter1*9]) maxXLength = arrayLineageRepairDataTemp2 [counter1*9];
                        if (maxYLength < arrayLineageRepairDataTemp2 [counter1*9+1]) maxYLength = arrayLineageRepairDataTemp2 [counter1*9+1];
                    }
                    
                    maxXLength = (int)(to_string(maxXLength).length());
                    maxYLength = (int)(to_string(maxYLength).length());
                    
                    int countLength = (int)(to_string(lineageDataRepairTempCount2/9+1).length());
                    int countLengthAdd = 0;
                    string countLengthString;
                    
                    for (int counter1 = 0; counter1 < lineageDataRepairTempCount2/9; counter1++){
                        if (listStringCount+20 > listStringLimit) [self listStringUpDate];
                        
                        //-----No-----
                        countLengthString = "";
                        countLengthAdd = countLength-(int)(to_string(counter1+1).length());
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+to_string(counter1+1);
                        arrayListString [listStringCount] = countLengthString+"//";
                        
                        //-----X-----
                        countLengthString = " ";
                        countLengthAdd = maxXLength-(int)(to_string(arrayLineageRepairDataTemp2 [counter1*9]).length());
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+to_string(arrayLineageRepairDataTemp2 [counter1*9]);
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                        
                        //-----Y-----
                        countLengthString = " ";
                        countLengthAdd = maxYLength-(int)(to_string(arrayLineageRepairDataTemp2 [counter1*9+1]).length());
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+to_string(arrayLineageRepairDataTemp2 [counter1*9+1]);
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                        
                        //-----Time-----
                        countLengthString = " ";
                        countLengthAdd = 4-(int)(to_string(arrayLineageRepairDataTemp2 [counter1*9+2]).length());
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+to_string(arrayLineageRepairDataTemp2 [counter1*9+2]);
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                        
                        //-----Event-----
                        countLengthString = " ";
                        countLengthAdd = 2-(int)(to_string(arrayLineageRepairDataTemp2 [counter1*9+3]).length());
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+to_string(arrayLineageRepairDataTemp2 [counter1*9+3]);
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                        
                        //-----Partner cell-----
                        countLengthString = " ";
                        
                        if (arrayLineageRepairDataTemp2 [counter1*9+4] == 0){
                            if (arrayLineageRepairDataTemp2 [counter1*9+3] == 31 || arrayLineageRepairDataTemp2 [counter1*9+3] == 41 || arrayLineageRepairDataTemp2 [counter1*9+3] == 51 || arrayLineageRepairDataTemp2 [counter1*9+3] == 91 || arrayLineageRepairDataTemp2 [counter1*9+3] == 92){
                                countLengthString = countLengthString+" c000000000";
                            }
                            else countLengthString = countLengthString+" c-----";
                        }
                        else if (arrayLineageRepairDataTemp2 [counter1*9+4] < 0){
                            countLengthAdd = 9-(int)(to_string(arrayLineageRepairDataTemp2 [counter1*9+4]*-1).length());
                            countLengthString = countLengthString+"c-";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayLineageRepairDataTemp2 [counter1*9+4]*-1);
                        }
                        else if (arrayLineageRepairDataTemp [counter1*9+4] > 0){
                            countLengthAdd = 9-(int)(to_string(arrayLineageRepairDataTemp2 [counter1*9+4]).length());
                            countLengthString = countLengthString+" c";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayLineageRepairDataTemp2 [counter1*9+4]);
                        }
                        
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                        
                        //-----Cell-----
                        countLengthString = " ";
                        
                        if (arrayLineageRepairDataTemp2 [counter1*9+5] == 0) countLengthString = countLengthString+" C000000000";
                        else if (arrayLineageRepairDataTemp2 [counter1*9+5] < 0){
                            countLengthAdd = 9-(int)(to_string(arrayLineageRepairDataTemp2 [counter1*9+5]*-1).length());
                            countLengthString = countLengthString+"C-";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayLineageRepairDataTemp2 [counter1*9+5]*-1);
                        }
                        else if (arrayLineageRepairDataTemp2 [counter1*9+5] > 0){
                            countLengthAdd = 9-(int)(to_string(arrayLineageRepairDataTemp2 [counter1*9+5]).length());
                            countLengthString = countLengthString+" C";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayLineageRepairDataTemp2 [counter1*9+5]);
                        }
                        
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                        
                        //-----Lineage-----
                        countLengthString = " ";
                        countLengthAdd = 5-(int)(to_string(arrayLineageRepairDataTemp2 [counter1*9+6]).length());
                        countLengthString = countLengthString+"L";
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+to_string(arrayLineageRepairDataTemp2 [counter1*9+6]);
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                        
                        //-----Lineage partner-----
                        countLengthString = " ";
                        
                        if (arrayLineageRepairDataTemp2 [counter1*9+7] == 0) countLengthString = countLengthString+"l*****";
                        else{
                            
                            countLengthAdd = 5-(int)(to_string(arrayLineageRepairDataTemp2 [counter1*9+7]).length());
                            countLengthString = countLengthString+"l";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayLineageRepairDataTemp2 [counter1*9+7]);
                        }
                        
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString;
                        
                        arrayListString [listStringCount] = arrayListString [listStringCount]+"~~"+to_string(arrayLineageRepairDataTemp2 [counter1*9+8])+"++"+nameStringRep+"^^0&&";
                        
                        listStringCount++;
                    }
                    
                    [replaceFromTextDisplay setStringValue:@""];
                    [replaceToTextDisplay setStringValue:@""];
                    [replaceLineFromDisplay setStringValue:@""];
                    [replaceLineToDisplay setStringValue:@""];
                    [removeLineFromDisplay setStringValue:@""];
                    [removeLineToDisplay setStringValue:@""];
                    
                    listArrayStatusHold = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"No Corresponding Data"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                    
                    listStringCount = 0;
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
                }
                
                delete [] arrayLineageRepairDataTemp;
                delete [] arrayLineageRepairDataTemp2;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Lineage File Read Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            
            delete [] arrayLineageRepairData;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Need Lineage No. With or Without Cell No."];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)listPR:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && cleaningProgress == 0 && progressControl == 0){
        int lineageNoList = [lingNoSetDisplay integerValue];
        
        int cellNoList = [cellNoSetDisplay integerValue];
        NSString *cellNoNSString = [cellNoSetDisplay stringValue];
        
        if ([cellNoNSString isEqualToString:@""]){
            cellNoList = -1;
        }
        else{
            
            string cellNoString = [cellNoNSString UTF8String];
            
            if (cellNoString == "0") cellNoList = 0;
        }
        
        int connectList = [connectNoSetDisplay integerValue];
        int timeList = [timeSetDisplay integerValue];
        
        if (timeList > 0){
            if (listStringStatus == 0){
                arrayListString = new string [5000];
                listStringCount = 0;
                listStringLimit = 5000;
                listStringStatus = 1;
            }
            else listStringCount = 0;
            
            [lineDataCurrentDisplay setStringValue:@"PR"];
            
            string lineData = "PR:Line No//Xposition/Yposition/Average/Connect no/Cell no/Status/Lineage. no~~Line marks";
            [dataStructureDisplay setStringValue:@(lineData.c_str())];
            
            if (checkListCount == 0 && treatmentNameHold != ""){
                nameStringRep = treatmentNameHold;
            }
            else nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
            
            string extension = to_string(timeList);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            //-----Master Data Status UpLoad-----
            masterDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_MasterDataRevise";
            
            struct stat sizeOfFile;
            long sizeForCopy = 0;
            long size1 = 0;
            long size2 = 0;
            int checkFlag = 0;
            int readingError = 0;
            
            for (int counter1 = 0; counter1 < 6; counter1++){
                sizeForCopy = 0;
                
                if (stat(masterDataRevPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter1 == 0) size1 = sizeForCopy;
                    else if (counter1 == 1) size2 = sizeForCopy;
                    else if (counter1 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter1 == 3) size1 = sizeForCopy;
                    else if (counter1 == 4) size2 = sizeForCopy;
                    else if (counter1 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            arrayPositionReviseVer = new int [sizeForCopy+50];
            positionReviseVerCount = 0;
            
            if (checkFlag == 1){
                
                ifstream fin;
                fin.open(masterDataRevPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    int finData [25];
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        int stepCount = 0;
                        unsigned long readPosition = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++;
                                finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                else{
                                    
                                    arrayPositionReviseVer [positionReviseVerCount] = finData [1], positionReviseVerCount++;
                                    arrayPositionReviseVer [positionReviseVerCount] = finData [3], positionReviseVerCount++;
                                    arrayPositionReviseVer [positionReviseVerCount] = finData [4], positionReviseVerCount++;
                                    arrayPositionReviseVer [positionReviseVerCount] = finData [7], positionReviseVerCount++;
                                    arrayPositionReviseVer [positionReviseVerCount] = finData [12], positionReviseVerCount++;
                                    arrayPositionReviseVer [positionReviseVerCount] = finData [13], positionReviseVerCount++;
                                    arrayPositionReviseVer [positionReviseVerCount] = finData [16], positionReviseVerCount++;
                                }
                            }
                            else if (stepCount == 1){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                finData [9] = finData [8]*256+finData [9];
                                
                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                            }
                            else if (stepCount == 2){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                }
                
                if (readingError == 0){
                    int *arrayPRRepairDataTemp = new int [positionReviseVerCount/7+positionReviseVerCount+500];
                    int prDataRepairTempCount = 0;
                    int *arrayPRRepairDataTemp2 = new int [positionReviseVerCount/7+positionReviseVerCount+500];
                    int prDataRepairTempCount2 = 0;
                    
                    for (int counter1 = 0; counter1 < positionReviseVerCount/7; counter1++){
                        arrayPRRepairDataTemp [prDataRepairTempCount] = arrayPositionReviseVer [counter1*7], prDataRepairTempCount++;
                        arrayPRRepairDataTemp [prDataRepairTempCount] = arrayPositionReviseVer [counter1*7+1], prDataRepairTempCount++;
                        arrayPRRepairDataTemp [prDataRepairTempCount] = arrayPositionReviseVer [counter1*7+2], prDataRepairTempCount++;
                        arrayPRRepairDataTemp [prDataRepairTempCount] = arrayPositionReviseVer [counter1*7+3], prDataRepairTempCount++;
                        arrayPRRepairDataTemp [prDataRepairTempCount] = arrayPositionReviseVer [counter1*7+4], prDataRepairTempCount++;
                        arrayPRRepairDataTemp [prDataRepairTempCount] = arrayPositionReviseVer [counter1*7+5], prDataRepairTempCount++;
                        arrayPRRepairDataTemp [prDataRepairTempCount] = arrayPositionReviseVer [counter1*7+6], prDataRepairTempCount++;
                        arrayPRRepairDataTemp [prDataRepairTempCount] = counter1, prDataRepairTempCount++;
                    }
                    
                    //for (int counterA = 0; counterA < prDataRepairTempCount/8; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayPRRepairDataTemp [counterA*8+counterB];
                    //    cout<<" arrayPRRepairDataTemp "<<counterA<<endl;
                    //}
                    
                    if (lineageNoList > 0){
                        prDataRepairTempCount2 = 0;
                        
                        for (int counter1 = 0; counter1 < prDataRepairTempCount/8; counter1++){
                            if (arrayPRRepairDataTemp [counter1*8+6] == lineageNoList){
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+1], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+2], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+3], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+4], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+5], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+6], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+7], prDataRepairTempCount2++;
                            }
                        }
                        
                        prDataRepairTempCount = 0;
                        for (int counter1 = 0; counter1 < prDataRepairTempCount2; counter1++) arrayPRRepairDataTemp [prDataRepairTempCount] = arrayPRRepairDataTemp2 [counter1], prDataRepairTempCount++;
                    }
                    
                    if (cellNoList != -1){
                        prDataRepairTempCount2 = 0;
                        
                        for (int counter1 = 0; counter1 < prDataRepairTempCount/8; counter1++){
                            if (arrayPRRepairDataTemp [counter1*8+4] == cellNoList){
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+1], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+2], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+3], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+4], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+5], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+6], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+7], prDataRepairTempCount2++;
                            }
                        }
                        
                        prDataRepairTempCount = 0;
                        for (int counter1 = 0; counter1 < prDataRepairTempCount2; counter1++) arrayPRRepairDataTemp [prDataRepairTempCount] = arrayPRRepairDataTemp2 [counter1], prDataRepairTempCount++;
                    }
                    
                    if (connectList > 0){
                        prDataRepairTempCount2 = 0;
                        
                        for (int counter1 = 0; counter1 < prDataRepairTempCount/8; counter1++){
                            if (arrayPRRepairDataTemp [counter1*8+3] == connectList){
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+1], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+2], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+3], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+4], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+5], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+6], prDataRepairTempCount2++;
                                arrayPRRepairDataTemp2 [prDataRepairTempCount2] = arrayPRRepairDataTemp [counter1*8+7], prDataRepairTempCount2++;
                            }
                        }
                        
                        prDataRepairTempCount = 0;
                        for (int counter1 = 0; counter1 < prDataRepairTempCount2; counter1++) arrayPRRepairDataTemp [prDataRepairTempCount] = arrayPRRepairDataTemp2 [counter1], prDataRepairTempCount++;
                    }
                    
                    //for (int counterA = 0; counterA < prDataRepairTempCount/8; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayPRRepairDataTemp [counterA*8+counterB];
                    //    cout<<" arrayPRRepairDataTemp "<<counterA<<endl;
                    //}
                    
                    if (prDataRepairTempCount != 0){
                        listStringCount = 0;
                        
                        int maxXLength = 0;
                        int maxYLength = 0;
                        int connectLength = 0;
                        
                        for (int counter1 = 0; counter1 < prDataRepairTempCount/8; counter1++){
                            if (maxXLength < arrayPRRepairDataTemp [counter1*8]) maxXLength = arrayPRRepairDataTemp [counter1*8];
                            if (maxYLength < arrayPRRepairDataTemp [counter1*8+1]) maxYLength = arrayPRRepairDataTemp [counter1*8+1];
                            if (connectLength < arrayPRRepairDataTemp [counter1*8+3]) connectLength = arrayPRRepairDataTemp [counter1*8+3];
                        }
                        
                        maxXLength = (int)(to_string(maxXLength).length());
                        maxYLength = (int)(to_string(maxYLength).length());
                        connectLength = (int)(to_string(connectLength).length());
                        
                        int countLength = (int)(to_string(prDataRepairTempCount/8+1).length());
                        int countLengthAdd = 0;
                        string countLengthString;
                        
                        for (int counter1 = 0; counter1 < prDataRepairTempCount/8; counter1++){
                            if (listStringCount+20 > listStringLimit) [self listStringUpDate];
                            
                            //-----No-----
                            countLengthString = "";
                            countLengthAdd = countLength-(int)(to_string(counter1+1).length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(counter1+1);
                            arrayListString [listStringCount] = countLengthString+"//";
                            
                            //-----X-----
                            countLengthString = " ";
                            countLengthAdd = maxXLength-(int)(to_string(arrayPRRepairDataTemp [counter1*8]).length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayPRRepairDataTemp [counter1*8]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                            
                            //-----Y-----
                            countLengthString = " ";
                            countLengthAdd = maxYLength-(int)(to_string(arrayPRRepairDataTemp [counter1*8+1]).length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayPRRepairDataTemp [counter1*8+1]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                            
                            //-----Average-----
                            countLengthString = " ";
                            countLengthAdd = 3-(int)(to_string(arrayPRRepairDataTemp [counter1*8+2]).length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayPRRepairDataTemp [counter1*8+2]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                            
                            //-----Connect-----
                            countLengthString = " ";
                            countLengthAdd = connectLength-(int)(to_string(arrayPRRepairDataTemp [counter1*8+3]).length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayPRRepairDataTemp [counter1*8+3]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                            
                            //-----Cell-----
                            countLengthString = " ";
                            
                            if (arrayPRRepairDataTemp [counter1*8+4] == 0 && arrayPRRepairDataTemp [counter1*8+5] == 0) countLengthString = countLengthString+" C-----";
                            else if (arrayPRRepairDataTemp [counter1*8+4] == 0 && arrayPRRepairDataTemp [counter1*8+5] == 1) countLengthString = countLengthString+" C000000000";
                            else if (arrayPRRepairDataTemp [counter1*8+4] == 0 && arrayPRRepairDataTemp [counter1*8+5] != 1 && arrayPRRepairDataTemp [counter1*8+5] != 0) countLengthString = countLengthString+" C-----";
                            else if (arrayPRRepairDataTemp [counter1*8+4] < 0){
                                countLengthAdd = 9-(int)(to_string(arrayPRRepairDataTemp [counter1*8+4]*-1).length());
                                countLengthString = countLengthString+"C-";
                                
                                for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                    countLengthString = countLengthString+"0";
                                }
                                
                                countLengthString = countLengthString+to_string(arrayPRRepairDataTemp [counter1*8+4]*-1);
                            }
                            else if (arrayPRRepairDataTemp [counter1*8+4] > 0){
                                countLengthAdd = 9-(int)(to_string(arrayPRRepairDataTemp [counter1*8+4]).length());
                                countLengthString = countLengthString+" C";
                                
                                for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                    countLengthString = countLengthString+"0";
                                }
                                
                                countLengthString = countLengthString+to_string(arrayPRRepairDataTemp [counter1*8+4]);
                            }
                            
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                            
                            //-----status-----
                            countLengthString = " ";
                            countLengthString = countLengthString+to_string(arrayPRRepairDataTemp [counter1*8+5]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                            
                            //-----Lineage-----
                            countLengthString = " ";
                            
                            if (arrayPRRepairDataTemp [counter1*8+6] == 0){
                                arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"L*****";
                            }
                            else{
                                
                                countLengthAdd = 5-(int)(to_string(arrayPRRepairDataTemp [counter1*8+6]).length());
                                countLengthString = countLengthString+"L";
                                
                                for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                    countLengthString = countLengthString+"0";
                                }
                                
                                countLengthString = countLengthString+to_string(arrayPRRepairDataTemp [counter1*8+6]);
                                arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString;
                            }
                            
                            arrayListString [listStringCount] = arrayListString [listStringCount]+"~~"+to_string(arrayPRRepairDataTemp [counter1*8+7])+"++"+nameStringRep+"^^"+extension+"&&";
                            
                            listStringCount++;
                        }
                        
                        [replaceFromTextDisplay setStringValue:@""];
                        [replaceToTextDisplay setStringValue:@""];
                        [replaceLineFromDisplay setStringValue:@""];
                        [replaceLineToDisplay setStringValue:@""];
                        [removeLineFromDisplay setStringValue:@""];
                        [removeLineToDisplay setStringValue:@""];
                        
                        listArrayStatusHold = 2;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"No Corresponding Data"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                        
                        listStringCount = 0;
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
                    }
                    
                    delete [] arrayPRRepairDataTemp;
                    delete [] arrayPRRepairDataTemp2;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Master Data Read Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Master Data Read Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            
            delete [] arrayPositionReviseVer;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time/Channel/Connect Requirement"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)listST:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && cleaningProgress == 0 && progressControl == 0){
        int timeList = [timeSetDisplay integerValue];
        
        if (timeList > 0){
            if (listStringStatus == 0){
                arrayListString = new string [5000];
                listStringCount = 0;
                listStringLimit = 5000;
                listStringStatus = 1;
            }
            else listStringCount = 0;
            
            [lineDataCurrentDisplay setStringValue:@"ST"];
            
            string lineData = "ST:Line No//Status/Zero/PR Starting/Zero/Zero/Zero/Zero/Zero/Connect no/Lineage. no~~Line marks";
            [dataStructureDisplay setStringValue:@(lineData.c_str())];
            
            if (checkListCount == 0 && treatmentNameHold != ""){
                nameStringRep = treatmentNameHold;
            }
            else nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
            
            string extension = to_string(timeList);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            //-----Master Data Status UpLoad-----
            string connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_Status";
            
            struct stat sizeOfFile;
            long sizeForCopy = 0;
            
            if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            int *arrayTimeSelectedVer = new int [(int)(sizeForCopy*1.2)+500];
            int timeSelectedVerCount = 0;
            int entryCount = 0;
            
            ifstream fin;
            
            if (sizeForCopy != 0){
                fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    int stepCount = 0;
                    int finData [25];
                    
                    unsigned long readPosition = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                            finData [7] = uploadTemp [readPosition], readPosition++;
                            finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                            finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                            finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                            finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                            finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                            finData [13] = uploadTemp [readPosition], readPosition++;
                            finData [14] = uploadTemp [readPosition], readPosition++;
                            finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                            finData [16] = uploadTemp [readPosition], readPosition++;
                            finData [17] = uploadTemp [readPosition], readPosition++;
                            finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                            
                            finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            finData [8] = finData [7]*256+finData [8];
                            finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                            finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                            
                            if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                            else{
                                
                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [0], timeSelectedVerCount++; //-----Selected, removed, eliminated status-----
                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [3], timeSelectedVerCount++; //-----When new line is created, enter line number which creates-----
                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [6], timeSelectedVerCount++; //-----PositionRevise Start-----
                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [8], timeSelectedVerCount++; //-----Cut line number-----
                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [9], timeSelectedVerCount++; //-----X Start-----
                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [10], timeSelectedVerCount++; //-----X End-----
                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [11], timeSelectedVerCount++; //-----Y Start-----
                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [12], timeSelectedVerCount++; //-----Y End-----
                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [15], timeSelectedVerCount++; //-----Connect-----
                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [18], timeSelectedVerCount++; //-----Lineage-----
                                arrayTimeSelectedVer [timeSelectedVerCount] = entryCount, timeSelectedVerCount++;
                                entryCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
            }
            
            //for (int counterA = 0; counterA < timeSelectedVerCount/10; counterA++){
            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelectedVer [counterA*10+counterB];
            //    cout<<" arrayTimeSelectedVer "<<counterA<<endl;
            //}
            
            if (timeSelectedVerCount != 0){
                listStringCount = 0;
                
                int startPositionLength = 0;
                int connectLength = 0;
                
                for (int counter1 = 0; counter1 < timeSelectedVerCount/11; counter1++){
                    if (startPositionLength < arrayTimeSelectedVer [counter1*11+2]) startPositionLength = arrayTimeSelectedVer [counter1*11+2];
                    if (connectLength < arrayTimeSelectedVer [counter1*11+8]) connectLength = arrayTimeSelectedVer [counter1*11+8];
                }
                
                startPositionLength = (int)(to_string(startPositionLength).length());
                connectLength = (int)(to_string(connectLength).length());
                
                int countLength = (int)(to_string(timeSelectedVerCount/11+1).length());
                int countLengthAdd = 0;
                string countLengthString;
                
                for (int counter1 = 0; counter1 < timeSelectedVerCount/11; counter1++){
                    if (listStringCount+20 > listStringLimit) [self listStringUpDate];
                    
                    //-----No-----
                    countLengthString = "";
                    countLengthAdd = countLength-(int)(to_string(counter1+1).length());
                    
                    for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                        countLengthString = countLengthString+"0";
                    }
                    
                    countLengthString = countLengthString+to_string(counter1+1);
                    arrayListString [listStringCount] = countLengthString+"//";
                    
                    //-----Status-----
                    countLengthString = " ";
                    countLengthString = countLengthString+to_string(arrayTimeSelectedVer [counter1*11]);
                    arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                    
                    //-----Zero-----
                    arrayListString [listStringCount] = arrayListString [listStringCount]+" "+to_string(arrayTimeSelectedVer [counter1*11+1])+"/";
                    
                    //-----Start position-----
                    countLengthString = "";
                    countLengthAdd = startPositionLength-(int)(to_string(arrayTimeSelectedVer [counter1*11+2]).length());
                    
                    for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                        countLengthString = countLengthString+"0";
                    }
                    
                    countLengthString = countLengthString+to_string(arrayTimeSelectedVer [counter1*11+2]);
                    arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                    
                    //-----Zero-----
                    arrayListString [listStringCount] = arrayListString [listStringCount]+" "+to_string(arrayTimeSelectedVer [counter1*11+3])+"/";
                    
                    //-----Zero-----
                    arrayListString [listStringCount] = arrayListString [listStringCount]+" "+to_string(arrayTimeSelectedVer [counter1*11+4])+"/";
                    
                    //-----Zero-----
                    arrayListString [listStringCount] = arrayListString [listStringCount]+" "+to_string(arrayTimeSelectedVer [counter1*11+5])+"/";
                    
                    //-----Zero-----
                    arrayListString [listStringCount] = arrayListString [listStringCount]+" "+to_string(arrayTimeSelectedVer [counter1*11+6])+"/";
                    
                    //-----Zero-----
                    arrayListString [listStringCount] = arrayListString [listStringCount]+" "+to_string(arrayTimeSelectedVer [counter1*11+7])+"/";
                    
                    //-----Connect-----
                    countLengthString = " ";
                    countLengthAdd = connectLength-(int)(to_string(arrayTimeSelectedVer [counter1*11+8]).length());
                    
                    for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                        countLengthString = countLengthString+"0";
                    }
                    
                    countLengthString = countLengthString+to_string(arrayTimeSelectedVer [counter1*11+8]);
                    arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                    
                    //-----Lineage-----
                    countLengthString = " ";
                    
                    if (arrayTimeSelectedVer [counter1*11+9] == 0){
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"L*****";
                    }
                    else{
                        
                        countLengthAdd = 5-(int)(to_string(arrayTimeSelectedVer [counter1*11+9]).length());
                        countLengthString = countLengthString+"L";
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+to_string(arrayTimeSelectedVer [counter1*11+9]);
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString;
                    }
                    
                    arrayListString [listStringCount] = arrayListString [listStringCount]+"~~"+to_string(arrayTimeSelectedVer[counter1*11+10])+"++"+nameStringRep+"^^"+extension+"&&";
                    
                    listStringCount++;
                }
                
                [replaceFromTextDisplay setStringValue:@""];
                [replaceToTextDisplay setStringValue:@""];
                [replaceLineFromDisplay setStringValue:@""];
                [replaceLineToDisplay setStringValue:@""];
                [removeLineFromDisplay setStringValue:@""];
                [removeLineToDisplay setStringValue:@""];
                
                listArrayStatusHold = 3;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Corresponding Data"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                listStringCount = 0;
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
            }
            
            delete [] arrayTimeSelectedVer;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time Requirement"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)listGR:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && cleaningProgress == 0 && progressControl == 0){
        int timeList = [timeSetDisplay integerValue];
        
        if (timeList > 0){
            if (listStringStatus == 0){
                arrayListString = new string [5000];
                listStringCount = 0;
                listStringLimit = 5000;
                listStringStatus = 1;
            }
            else listStringCount = 0;
            
            [lineDataCurrentDisplay setStringValue:@"GC"];
            
            string lineData = "GC:Line No//Xposition/Yposition/Total area/Average/Connect no/Target hit~~Line marks";
            [dataStructureDisplay setStringValue:@(lineData.c_str())];
            
            if (checkListCount == 0 && treatmentNameHold != ""){
                nameStringRep = treatmentNameHold;
            }
            else nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
            
            string extension = to_string(timeList);
            
            int stepCount = 0;
            int finData [25];
            
            unsigned long readPosition = 0;
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            //-----Master Data Status UpLoad-----
            masterDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_MasterDataRevise";
            
            struct stat sizeOfFile;
            long sizeForCopy = 0;
            long size1 = 0;
            long size2 = 0;
            int checkFlag = 0;
            int readingError = 0;
            
            for (int counter1 = 0; counter1 < 6; counter1++){
                sizeForCopy = 0;
                
                if (stat(masterDataRevPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter1 == 0) size1 = sizeForCopy;
                    else if (counter1 == 1) size2 = sizeForCopy;
                    else if (counter1 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter1 == 3) size1 = sizeForCopy;
                    else if (counter1 == 4) size2 = sizeForCopy;
                    else if (counter1 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            if (checkFlag == 1){
                arrayGravityCenterVerRev = new int [sizeForCopy+50];
                gravityCenterRevVerCount = 0;
                
                ifstream fin;
                fin.open(masterDataRevPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        readPosition = 0;
                        stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++;
                                finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                            }
                            else if (stepCount == 1){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                finData [9] = finData [8]*256+finData [9];
                                
                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                            }
                            else if (stepCount == 2){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                else{
                                    
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = finData [1], gravityCenterRevVerCount++;
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = finData [3], gravityCenterRevVerCount++;
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = finData [6], gravityCenterRevVerCount++;
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = finData [7], gravityCenterRevVerCount++;
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = finData [10], gravityCenterRevVerCount++;
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = finData [11], gravityCenterRevVerCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                }
                
                if (readingError == 0){
                    int *arrayGravityCenterVerTemp = new int [gravityCenterRevVerCount/6+gravityCenterRevVerCount+500];
                    int gravityCenterVerTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < gravityCenterRevVerCount/6; counter1++){
                        arrayGravityCenterVerTemp [gravityCenterVerTempCount] = arrayGravityCenterVerRev [counter1*6], gravityCenterVerTempCount++;
                        arrayGravityCenterVerTemp [gravityCenterVerTempCount] = arrayGravityCenterVerRev [counter1*6+1], gravityCenterVerTempCount++;
                        arrayGravityCenterVerTemp [gravityCenterVerTempCount] = arrayGravityCenterVerRev [counter1*6+2], gravityCenterVerTempCount++;
                        arrayGravityCenterVerTemp [gravityCenterVerTempCount] = arrayGravityCenterVerRev [counter1*6+3], gravityCenterVerTempCount++;
                        arrayGravityCenterVerTemp [gravityCenterVerTempCount] = arrayGravityCenterVerRev [counter1*6+4], gravityCenterVerTempCount++;
                        arrayGravityCenterVerTemp [gravityCenterVerTempCount] = arrayGravityCenterVerRev [counter1*6+5], gravityCenterVerTempCount++;
                        arrayGravityCenterVerTemp [gravityCenterVerTempCount] = counter1, gravityCenterVerTempCount++;
                    }
                    
                    //for (int counterA = 0; counterA < gravityCenterVerTempCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterVerTemp [counterA*6+counterB];
                    //    cout<<" arrayGravityCenterVerTemp "<<counterA<<endl;
                    //}
                    
                    if (gravityCenterVerTempCount != 0){
                        listStringCount = 0;
                        
                        int maxXLength = 0;
                        int maxYLength = 0;
                        int areaLength = 0;
                        int connectLength = 0;
                        
                        for (int counter1 = 0; counter1 < gravityCenterVerTempCount/7; counter1++){
                            if (maxXLength < arrayGravityCenterVerTemp [counter1*7]) maxXLength = arrayGravityCenterVerTemp [counter1*7];
                            if (maxYLength < arrayGravityCenterVerTemp [counter1*7+1]) maxYLength = arrayGravityCenterVerTemp [counter1*7+1];
                            if (areaLength < arrayGravityCenterVerTemp [counter1*7+2]) areaLength = arrayGravityCenterVerTemp [counter1*7+2];
                            if (connectLength < arrayGravityCenterVerTemp [counter1*7+4]) connectLength = arrayGravityCenterVerTemp [counter1*7+4];
                        }
                        
                        maxXLength = (int)(to_string(maxXLength).length());
                        maxYLength = (int)(to_string(maxYLength).length());
                        areaLength = (int)(to_string(areaLength).length());
                        connectLength = (int)(to_string(connectLength).length());
                        
                        int countLength = (int)(to_string(gravityCenterVerTempCount/7+1).length());
                        int countLengthAdd = 0;
                        string countLengthString;
                        
                        for (int counter1 = 0; counter1 < gravityCenterVerTempCount/7; counter1++){
                            if (listStringCount+20 > listStringLimit) [self listStringUpDate];
                            
                            //-----No-----
                            countLengthString = "";
                            countLengthAdd = countLength-(int)(to_string(counter1+1).length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(counter1+1);
                            arrayListString [listStringCount] = countLengthString+"//";
                            
                            //-----X-----
                            countLengthString = " ";
                            countLengthAdd = maxXLength-(int)(to_string(arrayGravityCenterVerTemp [counter1*7]).length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayGravityCenterVerTemp [counter1*7]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                            
                            //-----Y-----
                            countLengthString = " ";
                            countLengthAdd = maxYLength-(int)(to_string(arrayGravityCenterVerTemp [counter1*7+1]).length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayGravityCenterVerTemp [counter1*7+1]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                            
                            //-----Total area-----
                            countLengthString = " ";
                            countLengthAdd = areaLength-(int)(to_string(arrayGravityCenterVerTemp [counter1*7+2]).length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayGravityCenterVerTemp [counter1*7+2]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                            
                            //-----Average-----
                            countLengthString = " ";
                            countLengthAdd = 3-(int)(to_string(arrayGravityCenterVerTemp [counter1*7+3]).length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayGravityCenterVerTemp [counter1*7+3]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                            
                            //-----Connect-----
                            countLengthString = " ";
                            countLengthAdd = connectLength-(int)(to_string(arrayGravityCenterVerTemp [counter1*7+4]).length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayGravityCenterVerTemp [counter1*7+4]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                            
                            //-----Hit-----
                            countLengthString = " ";
                            countLengthString = countLengthString+to_string(arrayGravityCenterVerTemp [counter1*7+5]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString;
                            
                            arrayListString [listStringCount] = arrayListString [listStringCount]+"~~"+to_string(arrayGravityCenterVerTemp [counter1*7+6])+"++"+nameStringRep+"^^"+extension+"&&";
                            
                            listStringCount++;
                        }
                        
                        [replaceFromTextDisplay setStringValue:@""];
                        [replaceToTextDisplay setStringValue:@""];
                        [replaceLineFromDisplay setStringValue:@""];
                        [replaceLineToDisplay setStringValue:@""];
                        [removeLineFromDisplay setStringValue:@""];
                        [removeLineToDisplay setStringValue:@""];
                        
                        listArrayStatusHold = 4;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"No Corresponding Data"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                        
                        listStringCount = 0;
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
                    }
                    
                    delete [] arrayGravityCenterVerTemp;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Master Data Read Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                
                delete [] arrayGravityCenterVerRev;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Master Data Read Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time Requirement"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)listRL:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && cleaningProgress == 0 && progressControl == 0){
        int lineageNoList = [lingNoSetDisplay integerValue];
        
        int cellNoList = [cellNoSetDisplay integerValue];
        NSString *cellNoNSString = [cellNoSetDisplay stringValue];
        
        if ([cellNoNSString isEqualToString:@""]){
            cellNoList = -1;
        }
        else{
            
            string cellNoString = [cellNoNSString UTF8String];
            
            if (cellNoString == "0") cellNoList = 0;
        }
        
        int connectList = [connectNoSetDisplay integerValue];
        int timeList = [timeSetDisplay integerValue];
        
        if (timeList > 0){
            if (listStringStatus == 0){
                arrayListString = new string [5000];
                listStringCount = 0;
                listStringLimit = 5000;
                listStringStatus = 1;
            }
            else listStringCount = 0;
            
            [lineDataCurrentDisplay setStringValue:@"RL"];
            
            string lineData = "RL:Line No//Lineage no/Connect no/Time/Cell no/Target/Zero~~Line marks";
            [dataStructureDisplay setStringValue:@(lineData.c_str())];
            
            if (checkListCount == 0 && treatmentNameHold != ""){
                nameStringRep = treatmentNameHold;
            }
            else nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
            
            string extension = to_string(timeList);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            int stepCount = 0;
            int finData [25];
            
            unsigned long readPosition = 0;
            
            //-----Master Data Status UpLoad-----
            string connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_ConnectLineageRel";
            
            struct stat sizeOfFile;
            long sizeForCopy = 0;
            
            if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            int *arrayConnectLineageRelVer = new int [(int)(sizeForCopy*1.2)+50];
            int connectLineageRelVerCount = 0;
            int entryCount = 0;
            
            ifstream fin;
            
            if (sizeForCopy != 0){
                fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    readPosition = 0;
                    stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                            finData [3] = uploadTemp [readPosition], readPosition++;
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                            finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++;
                            finData [11] = uploadTemp [readPosition], readPosition++;
                            finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                            finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                            finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                            finData [7] = finData [6]*256+finData [7];
                            
                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                            
                            if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                            else{
                                
                                arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [2], connectLineageRelVerCount++;
                                arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [5], connectLineageRelVerCount++;
                                arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [7], connectLineageRelVerCount++;
                                arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [12], connectLineageRelVerCount++;
                                arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [13], connectLineageRelVerCount++;
                                arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [14], connectLineageRelVerCount++;
                                arrayConnectLineageRelVer [connectLineageRelVerCount] = entryCount, connectLineageRelVerCount++;
                                entryCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
            }
            
            int *arrayConnectLineageRelVerTemp = new int [connectLineageRelVerCount/7+connectLineageRelVerCount+500];
            int connectLineageRelVerTempCount = 0;
            
            if (lineageNoList > 0){
                connectLineageRelVerTempCount = 0;
                
                for (int counter1 = 0; counter1 < connectLineageRelVerCount/7; counter1++){
                    if (arrayConnectLineageRelVer [counter1*7] == lineageNoList){
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7], connectLineageRelVerTempCount++;
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7+1], connectLineageRelVerTempCount++;
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7+2], connectLineageRelVerTempCount++;
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7+3], connectLineageRelVerTempCount++;
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7+4], connectLineageRelVerTempCount++;
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7+5], connectLineageRelVerTempCount++;
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7+6], connectLineageRelVerTempCount++;
                    }
                }
                
                connectLineageRelVerCount = 0;
                for (int counter1 = 0; counter1 < connectLineageRelVerTempCount; counter1++) arrayConnectLineageRelVer [connectLineageRelVerCount] = arrayConnectLineageRelVerTemp [counter1], connectLineageRelVerCount++;
            }
            
            //**********ConnectLineageRel**********
            //1. Lineage No;
            //2. Connect No;
            //3. Image number;
            //4. Cell no;
            //5. Target (0: non-target, 1: target);
            //6. Reserve;
            
            if (cellNoList != -1){
                connectLineageRelVerTempCount = 0;
                
                for (int counter1 = 0; counter1 < connectLineageRelVerCount/7; counter1++){
                    if (arrayConnectLineageRelVer [counter1*7+3] == cellNoList){
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7], connectLineageRelVerTempCount++;
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7+1], connectLineageRelVerTempCount++;
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7+2], connectLineageRelVerTempCount++;
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7+3], connectLineageRelVerTempCount++;
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7+4], connectLineageRelVerTempCount++;
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7+5], connectLineageRelVerTempCount++;
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7+6], connectLineageRelVerTempCount++;
                    }
                }
                
                connectLineageRelVerCount = 0;
                for (int counter1 = 0; counter1 < connectLineageRelVerTempCount; counter1++) arrayConnectLineageRelVer [connectLineageRelVerCount] = arrayConnectLineageRelVerTemp [counter1], connectLineageRelVerCount++;
            }
            
            if (connectList > 0){
                connectLineageRelVerTempCount = 0;
                
                for (int counter1 = 0; counter1 < connectLineageRelVerCount/7; counter1++){
                    if (arrayConnectLineageRelVer [counter1*7+1] == connectList){
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7], connectLineageRelVerTempCount++;
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7+1], connectLineageRelVerTempCount++;
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7+2], connectLineageRelVerTempCount++;
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7+3], connectLineageRelVerTempCount++;
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7+4], connectLineageRelVerTempCount++;
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7+5], connectLineageRelVerTempCount++;
                        arrayConnectLineageRelVerTemp [connectLineageRelVerTempCount] = arrayConnectLineageRelVer [counter1*7+6], connectLineageRelVerTempCount++;
                    }
                }
                
                connectLineageRelVerCount = 0;
                for (int counter1 = 0; counter1 < connectLineageRelVerTempCount; counter1++) arrayConnectLineageRelVer [connectLineageRelVerCount] = arrayConnectLineageRelVerTemp [counter1], connectLineageRelVerCount++;
            }
            
            delete [] arrayConnectLineageRelVerTemp;
            
            if (connectLineageRelVerCount != 0){
                listStringCount = 0;
                
                int connectLength = 0;
                
                for (int counter1 = 0; counter1 < connectLineageRelVerCount/7; counter1++){
                    if (connectLength < arrayConnectLineageRelVer [counter1*7+1]) connectLength = arrayConnectLineageRelVer [counter1*7+1];
                }
                
                connectLength = (int)(to_string(connectLength).length());
                
                int countLength = (int)(to_string(connectLineageRelVerCount/7+1).length());
                int countLengthAdd = 0;
                string countLengthString;
                
                for (int counter1 = 0; counter1 < connectLineageRelVerCount/7; counter1++){
                    if (listStringCount+20 > listStringLimit) [self listStringUpDate];
                    
                    //-----No-----
                    countLengthString = "";
                    countLengthAdd = countLength-(int)(to_string(counter1+1).length());
                    
                    for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                        countLengthString = countLengthString+"0";
                    }
                    
                    countLengthString = countLengthString+to_string(counter1+1);
                    arrayListString [listStringCount] = countLengthString+"//";
                    
                    //-----Lineage-----
                    countLengthString = " ";
                    countLengthAdd = 5-(int)(to_string(arrayConnectLineageRelVer [counter1*7]).length());
                    countLengthString = countLengthString+"L";
                    
                    for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                        countLengthString = countLengthString+"0";
                    }
                    
                    countLengthString = countLengthString+to_string(arrayConnectLineageRelVer [counter1*7]);
                    arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                    
                    //-----Connect-----
                    countLengthString = " ";
                    countLengthAdd = connectLength-(int)(to_string(arrayConnectLineageRelVer [counter1*7+1]).length());
                    
                    for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                        countLengthString = countLengthString+"0";
                    }
                    
                    countLengthString = countLengthString+to_string(arrayConnectLineageRelVer [counter1*7+1]);
                    arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                    
                    //-----Time-----
                    countLengthString = " ";
                    countLengthAdd = 4-(int)(to_string(arrayConnectLineageRelVer [counter1*7+2]).length());
                    
                    for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                        countLengthString = countLengthString+"0";
                    }
                    
                    countLengthString = countLengthString+to_string(arrayConnectLineageRelVer [counter1*7+2]);
                    arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                    
                    //-----Cell-----
                    countLengthString = " ";
                    
                    if (arrayConnectLineageRelVer [counter1*7+3] == 0) countLengthString = countLengthString+" C000000000";
                    else if (arrayConnectLineageRelVer [counter1*7+3] < 0){
                        countLengthAdd = 9-(int)(to_string(arrayConnectLineageRelVer [counter1*7+3]*-1).length());
                        countLengthString = countLengthString+"C-";
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+to_string(arrayConnectLineageRelVer [counter1*7+3]*-1);
                    }
                    else if (arrayConnectLineageRelVer [counter1*7+3] > 0){
                        countLengthAdd = 9-(int)(to_string(arrayConnectLineageRelVer [counter1*7+3]).length());
                        countLengthString = countLengthString+" C";
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+to_string(arrayConnectLineageRelVer [counter1*7+3]);
                    }
                    
                    arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                    
                    //-----Status-----
                    countLengthString = " ";
                    countLengthString = countLengthString+to_string(arrayConnectLineageRelVer [counter1*7+4]);
                    arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                    
                    //-----Zero-----
                    arrayListString [listStringCount] = arrayListString [listStringCount]+" "+to_string(arrayConnectLineageRelVer [counter1*7+5]);
                    
                    arrayListString [listStringCount] = arrayListString [listStringCount]+"~~"+to_string(arrayConnectLineageRelVer [counter1*7+6])+"++"+nameStringRep+"^^"+extension+"&&";
                    
                    listStringCount++;
                }
                
                [replaceFromTextDisplay setStringValue:@""];
                [replaceToTextDisplay setStringValue:@""];
                [replaceLineFromDisplay setStringValue:@""];
                [replaceLineToDisplay setStringValue:@""];
                [removeLineFromDisplay setStringValue:@""];
                [removeLineToDisplay setStringValue:@""];
                
                listArrayStatusHold = 5;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Corresponding Data"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                listStringCount = 0;
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
            }
            
            delete [] arrayConnectLineageRelVer;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time Requirement"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)listAD:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && cleaningProgress == 0 && progressControl == 0){
        int timeList = [timeSetDisplay integerValue];
        
        if (timeList > 0){
            if (listStringStatus == 0){
                arrayListString = new string [5000];
                listStringCount = 0;
                listStringLimit = 5000;
                listStringStatus = 1;
            }
            else listStringCount = 0;
            
            [lineDataCurrentDisplay setStringValue:@"AD"];
            
            string lineData = "AD:Line No//Connect No/Process type/Cut type/Pair no/Cell dim/Zero~~Line marks";
            [dataStructureDisplay setStringValue:@(lineData.c_str())];
            
            if (checkListCount == 0 && treatmentNameHold != ""){
                nameStringRep = treatmentNameHold;
            }
            else nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
            
            string extension = to_string(timeList);
            
            int stepCount = 0;
            int finData [25];
            
            unsigned long readPosition = 0;
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            //-----Master Data Status UpLoad-----
            masterDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_MasterDataRevise";
            
            struct stat sizeOfFile;
            long sizeForCopy = 0;
            long size1 = 0;
            long size2 = 0;
            int checkFlag = 0;
            int readingError = 0;
            
            for (int counter1 = 0; counter1 < 6; counter1++){
                sizeForCopy = 0;
                
                if (stat(masterDataRevPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter1 == 0) size1 = sizeForCopy;
                    else if (counter1 == 1) size2 = sizeForCopy;
                    else if (counter1 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter1 == 3) size1 = sizeForCopy;
                    else if (counter1 == 4) size2 = sizeForCopy;
                    else if (counter1 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            if (checkFlag == 1){
                arrayRepairDataHoldVerRev = new int [(int)(sizeForCopy*1.2)+50];
                repairDataHoldVerCount = 0;
                int entryCount = 0;
                
                ifstream fin;
                fin.open(masterDataRevPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        readPosition = 0;
                        stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++;
                                finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                            }
                            else if (stepCount == 1){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                finData [9] = finData [8]*256+finData [9];
                                
                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                else{
                                    
                                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [2], repairDataHoldVerCount++;
                                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [3], repairDataHoldVerCount++;
                                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [4], repairDataHoldVerCount++;
                                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [7], repairDataHoldVerCount++;
                                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [9], repairDataHoldVerCount++;
                                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [10], repairDataHoldVerCount++;
                                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = entryCount, repairDataHoldVerCount++;
                                    entryCount++;
                                }
                            }
                            else if (stepCount == 2){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                }
                
                if (readingError == 0){
                    if (repairDataHoldVerCount != 0){
                        listStringCount = 0;
                        
                        int connectLength = 0;
                        int pairLength = 0;
                        int cellDimLength = 0;
                        
                        for (int counter1 = 0; counter1 < repairDataHoldVerCount/7; counter1++){
                            if (connectLength < arrayRepairDataHoldVerRev [counter1*7]) connectLength = arrayRepairDataHoldVerRev [counter1*7];
                            if (pairLength < arrayRepairDataHoldVerRev [counter1*7+3]) pairLength = arrayRepairDataHoldVerRev [counter1*7+3];
                            if (cellDimLength < arrayRepairDataHoldVerRev [counter1*7+4]) cellDimLength = arrayRepairDataHoldVerRev [counter1*7+4];
                        }
                        
                        connectLength = (int)(to_string(connectLength).length());
                        pairLength = (int)(to_string(pairLength).length());
                        cellDimLength = (int)(to_string(cellDimLength).length());
                        
                        int countLength = (int)(to_string(repairDataHoldVerCount/7+1).length());
                        int countLengthAdd = 0;
                        string countLengthString;
                        
                        for (int counter1 = 0; counter1 < repairDataHoldVerCount/7; counter1++){
                            if (listStringCount+20 > listStringLimit) [self listStringUpDate];
                            
                            //-----No-----
                            countLengthString = "";
                            countLengthAdd = countLength-(int)(to_string(counter1+1).length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(counter1+1);
                            arrayListString [listStringCount] = countLengthString+"//";
                            
                            //-----Connect-----
                            countLengthString = " ";
                            countLengthAdd = connectLength-(int)(to_string(arrayRepairDataHoldVerRev [counter1*7]).length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayRepairDataHoldVerRev [counter1*7]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                            
                            //-----Process type-----
                            countLengthString = " ";
                            countLengthString = countLengthString+to_string(arrayRepairDataHoldVerRev [counter1*7+1]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                            
                            //-----Cut type-----
                            countLengthString = " ";
                            countLengthString = countLengthString+to_string(arrayRepairDataHoldVerRev [counter1*7+2]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                            
                            //-----Pair no-----
                            countLengthString = " ";
                            countLengthAdd = pairLength-(int)(to_string(arrayRepairDataHoldVerRev [counter1*7+3]).length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayRepairDataHoldVerRev [counter1*7+3]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                            
                            //-----Cell dimension-----
                            countLengthString = " ";
                            countLengthAdd = cellDimLength-(int)(to_string(arrayRepairDataHoldVerRev [counter1*7+4]).length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayRepairDataHoldVerRev [counter1*7+4]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                            
                            //-----Zero-----
                            countLengthString = " ";
                            countLengthString = countLengthString+to_string(arrayRepairDataHoldVerRev [counter1*7+5]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString;
                            
                            arrayListString [listStringCount] = arrayListString [listStringCount]+"~~"+to_string(arrayRepairDataHoldVerRev [counter1*7+6])+"++"+nameStringRep+"^^"+extension+"&&";
                            
                            listStringCount++;
                        }
                        
                        [replaceFromTextDisplay setStringValue:@""];
                        [replaceToTextDisplay setStringValue:@""];
                        [replaceLineFromDisplay setStringValue:@""];
                        [replaceLineToDisplay setStringValue:@""];
                        [removeLineFromDisplay setStringValue:@""];
                        [removeLineToDisplay setStringValue:@""];
                        
                        listArrayStatusHold = 6;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"No Corresponding Data"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                        
                        listStringCount = 0;
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Master Data Read Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                
                delete [] arrayRepairDataHoldVerRev;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Master Data Read Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time Requirement"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)listMap:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && cleaningProgress == 0 && progressControl == 0){
        int timeList = [timeSetDisplay integerValue];
        
        if (timeList > 0){
            if (listStringStatus == 0){
                arrayListString = new string [5000];
                listStringCount = 0;
                listStringLimit = 5000;
                listStringStatus = 1;
            }
            else listStringCount = 0;
            
            [lineDataCurrentDisplay setStringValue:@"Map"];
            
            string lineData = "Map:Line No//Connect No/Number of Pix~~Line marks";
            [dataStructureDisplay setStringValue:@(lineData.c_str())];
            
            if (checkListCount == 0 && treatmentNameHold != ""){
                nameStringRep = treatmentNameHold;
            }
            else nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
            
            string extension = to_string(timeList);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            int imageSize = 0;
            
            for (int counter2 = 0; counter2 < imageSizeListCount/2; counter2++){
                if (arrayImageSizeList [counter2*2] == nameStringRep){
                    imageSize = atoi(arrayImageSizeList [counter2*2+1].c_str());
                    break;
                }
            }
            
            int **revisedMapVer = new int *[imageSize+1];
            for (int counter2 = 0; counter2 < imageSize+1; counter2++) revisedMapVer [counter2] = new int [imageSize+1];
            
            //-----Map read-----
            string revisedMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_RevisedMap";
            
            for (int counter3 = 0; counter3 < imageSize; counter3++){
                for (int counter4 = 0; counter4 < imageSize; counter4++){
                    revisedMapVer [counter3][counter4] = 0;
                }
            }
            
            int totalSize = imageSize*imageSize*4;
            
            ifstream fin;
            
            fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                uint8_t *upload2 = new uint8_t [totalSize+50];
                fin.read((char*)upload2, totalSize+1);
                fin.close();
                
                int yDimensionCount = 0;
                int xDimensionCount = 0;
                int pixData = 0;
                int readBit [4];
                
                for (int counter3 = 0; counter3 < totalSize; counter3 = counter3+4){
                    readBit [0] = upload2[counter3];
                    readBit [1] = upload2[counter3+1];
                    readBit [2] = upload2[counter3+2];
                    readBit [3] = upload2[counter3+3];
                    
                    pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                    
                    for (int counter4 = 0; counter4 < readBit [3]; counter4++){
                        revisedMapVer [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                    }
                    
                    if (xDimensionCount == imageSize){
                        xDimensionCount = 0;
                        yDimensionCount++;
                        
                        if (yDimensionCount == imageSize){
                            break;
                        }
                    }
                }
                
                delete [] upload2;
                
                int maxConnectNoMap = 0;
                int minConnectNoMap = 99999999;
                
                for (int counter3 = 0; counter3 < imageSize; counter3++){
                    for (int counter4 = 0; counter4 < imageSize; counter4++){
                        if (revisedMapVer [counter3][counter4] > maxConnectNoMap) maxConnectNoMap = revisedMapVer [counter3][counter4];
                        if (revisedMapVer [counter3][counter4] != 0 && revisedMapVer [counter3][counter4] < minConnectNoMap) minConnectNoMap = revisedMapVer [counter3][counter4];
                    }
                }
                
                double *connectNoMapList = new double [(maxConnectNoMap-minConnectNoMap)*2+10];
                
                for (int counter3 = 0; counter3 < (maxConnectNoMap-minConnectNoMap)*2+10; counter3++) connectNoMapList [counter3] = 0;
                
                int matchFlag = 0;
                int entryPoint = 0;
                
                for (int counter3 = 0; counter3 < imageSize; counter3++){
                    for (int counter4 = 0; counter4 < imageSize; counter4++){
                        if (revisedMapVer [counter3][counter4] != 0){
                            matchFlag = 0;
                            
                            for (int counter5 = 0; counter5 < entryPoint; counter5++){
                                if (connectNoMapList [counter5*2] == revisedMapVer [counter3][counter4]){
                                    connectNoMapList [counter5*2+1]++;
                                    matchFlag = 1;
                                    break;
                                }
                            }
                            
                            if (matchFlag == 0){
                                connectNoMapList [entryPoint*2] = revisedMapVer [counter3][counter4];
                                connectNoMapList [entryPoint*2+1]++;
                                
                                entryPoint++;
                            }
                        }
                    }
                }
                
                double *connectNoMapList2 = new double [entryPoint*2+10];
                int connectNoMapListCount2 = 0;
                
                double *connectNoMapList3 = new double [entryPoint*2+10];
                int connectNoMapListCount3 = 0;
                
                for (int counter1 = 0; counter1 < entryPoint*2; counter1++) connectNoMapList2 [connectNoMapListCount2] = connectNoMapList [counter1], connectNoMapListCount2++;
                
                int terminationFlag = 0;
                double minimalFind = 0;
                int minimalPosition = 0;
                
                do{
                    
                    terminationFlag = 1;
                    minimalPosition = -1;
                    minimalFind = maxConnectNoMap+100;
                    
                    for (int counter1 = 0; counter1 < connectNoMapListCount2/2; counter1++){
                        if (connectNoMapList2 [counter1*2] != 0 && minimalFind > connectNoMapList2 [counter1*2]){
                            minimalFind = connectNoMapList2 [counter1*2];
                            minimalPosition = counter1;
                        }
                    }
                    
                    if (minimalPosition == -1) terminationFlag = 0;
                    else{
                        
                        connectNoMapList3 [connectNoMapListCount3] = connectNoMapList2 [minimalPosition*2], connectNoMapListCount3++;
                        connectNoMapList3 [connectNoMapListCount3] = connectNoMapList2 [minimalPosition*2+1], connectNoMapListCount3++;
                        connectNoMapList2 [minimalPosition*2] = 0;
                    }
                    
                } while (terminationFlag == 1);
                
                listStringCount = 0;
                
                int pixLength = 0;
                int connectLength = 0;
                
                for (int counter1 = 0; counter1 < connectNoMapListCount3/2; counter1++){
                    if (pixLength < (int)connectNoMapList3 [counter1*2+1]) pixLength = (int)connectNoMapList3 [counter1*2+1];
                    if (connectLength < atoi(to_string((int)connectNoMapList3 [counter1*2]).c_str())) connectLength = atoi(to_string((int)connectNoMapList3 [counter1*2]).c_str());
                }
                
                connectLength = (int)(to_string(connectLength).length());
                pixLength = (int)(to_string(pixLength).length());
                
                int countLength = (int)(to_string(entryPoint).length());
                int countLengthAdd = 0;
                string countLengthString;
                
                for (int counter1 = 0; counter1 < connectNoMapListCount3/2; counter1++){
                    if (listStringCount+20 > listStringLimit) [self listStringUpDate];
                    
                    //-----No-----
                    countLengthString = "";
                    countLengthAdd = countLength-(int)(to_string(counter1+1).length());
                    
                    for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                        countLengthString = countLengthString+"0";
                    }
                    
                    countLengthString = countLengthString+to_string(counter1+1);
                    arrayListString [listStringCount] = countLengthString+"//";
                    
                    //-----Connect-----
                    countLengthString = " ";
                    countLengthAdd = connectLength-(int)(to_string((int)(connectNoMapList3 [counter1*2])).length());
                    
                    for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                        countLengthString = countLengthString+"0";
                    }
                    
                    countLengthString = countLengthString+to_string((int)(connectNoMapList3 [counter1*2]));
                    arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                    
                    //-----number of pix-----
                    countLengthString = " ";
                    countLengthAdd = pixLength-(int)(to_string((int)(connectNoMapList3 [counter1*2+1])).length());
                    
                    for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                        countLengthString = countLengthString+"0";
                    }
                    
                    countLengthString = countLengthString+to_string((int)(connectNoMapList3 [counter1*2+1]));
                    arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString;
                    
                    arrayListString [listStringCount] = arrayListString [listStringCount]+"~~"+to_string(counter1)+"++"+nameStringRep+"^^"+extension+"&&";
                    
                    listStringCount++;
                }
                
                [replaceFromTextDisplay setStringValue:@""];
                [replaceToTextDisplay setStringValue:@""];
                [replaceLineFromDisplay setStringValue:@""];
                [replaceLineToDisplay setStringValue:@""];
                [removeLineFromDisplay setStringValue:@""];
                [removeLineToDisplay setStringValue:@""];
                
                listArrayStatusHold = 7;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
                
                delete [] connectNoMapList;
                delete [] connectNoMapList2;
                delete [] connectNoMapList3;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Corresponding Data"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                listStringCount = 0;
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
            }
            
            for (int counter2 = 0; counter2 < imageSize+1; counter2++) delete [] revisedMapVer [counter2];
            delete [] revisedMapVer;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time Requirement"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)listFluorescentLine:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && cleaningProgress == 0 && progressControl == 0){
        int timeList = [timeSetDisplay integerValue];
        int chList = [channelNoSetDisplay integerValue];
        int connectList = [connectNoSetDisplay integerValue];
        
        if (timeList > 0){
            if (listStringStatus == 0){
                arrayListString = new string [5000];
                listStringCount = 0;
                listStringLimit = 5000;
                listStringStatus = 1;
            }
            else listStringCount = 0;
            
            [lineDataCurrentDisplay setStringValue:@"Fluorescent-Line"];
            
            string lineData = "Fluorescent-Line:Line No//Xposition/Yposition/connect no/CH no~~Line marks";
            [dataStructureDisplay setStringValue:@(lineData.c_str())];
            
            if (checkListCount == 0 && treatmentNameHold != ""){
                nameStringRep = treatmentNameHold;
            }
            else nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
            
            string extension = to_string(timeList);
            
            int stepCount = 0;
            int finData [25];
            
            unsigned long readPosition = 0;
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            //-----Fluorescent line data read-----
            string connectFluorescentPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_ExtendLineData";
            
            struct stat sizeOfFile;
            long sizeForCopy = 0;
            long size1 = 0;
            long size2 = 0;
            int checkFlag = 0;
            int readingError = 0;
            
            for (int counter1 = 0; counter1 < 6; counter1++){
                sizeForCopy = 0;
                
                if (stat(connectFluorescentPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter1 == 0) size1 = sizeForCopy;
                    else if (counter1 == 1) size2 = sizeForCopy;
                    else if (counter1 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter1 == 3) size1 = sizeForCopy;
                    else if (counter1 == 4) size2 = sizeForCopy;
                    else if (counter1 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            if (checkFlag == 1){
                int *arrayExpandFluorescentLineTemp = new int [(int)(sizeForCopy*1.2)+50];
                int expandFluLineTempCount = 0;
                int entryCount = 0;
                
                ifstream fin;
                
                fin.open(connectFluorescentPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        readPosition = 0;
                        stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                else{
                                    
                                    arrayExpandFluorescentLineTemp [expandFluLineTempCount] = finData [1], expandFluLineTempCount++;
                                    arrayExpandFluorescentLineTemp [expandFluLineTempCount] = finData [3], expandFluLineTempCount++;
                                    arrayExpandFluorescentLineTemp [expandFluLineTempCount] = finData [6], expandFluLineTempCount++;
                                    arrayExpandFluorescentLineTemp [expandFluLineTempCount] = finData [7], expandFluLineTempCount++;
                                    arrayExpandFluorescentLineTemp [expandFluLineTempCount] = entryCount, expandFluLineTempCount++;
                                    entryCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                }
                
                if (readingError == 0){
                    int *arrayExpandFluorescentLineTemp2 = new int [expandFluLineTempCount+10];
                    int expandFluLineTempCount2 = 0;
                    
                    if (chList >= 1 && chList <= 12){
                        for (int counter1 = 0; counter1 < expandFluLineTempCount/5; counter1++){
                            if (arrayExpandFluorescentLineTemp [counter1*5+3] == chList){
                                arrayExpandFluorescentLineTemp2 [expandFluLineTempCount2] = arrayExpandFluorescentLineTemp [counter1*5], expandFluLineTempCount2++;
                                arrayExpandFluorescentLineTemp2 [expandFluLineTempCount2] = arrayExpandFluorescentLineTemp [counter1*5+1], expandFluLineTempCount2++;
                                arrayExpandFluorescentLineTemp2 [expandFluLineTempCount2] = arrayExpandFluorescentLineTemp [counter1*5+2], expandFluLineTempCount2++;
                                arrayExpandFluorescentLineTemp2 [expandFluLineTempCount2] = arrayExpandFluorescentLineTemp [counter1*5+3], expandFluLineTempCount2++;
                                arrayExpandFluorescentLineTemp2 [expandFluLineTempCount2] = arrayExpandFluorescentLineTemp [counter1*5+4], expandFluLineTempCount2++;
                            }
                        }
                        
                        expandFluLineTempCount = 0;
                        for (int counter1 = 0; counter1 < expandFluLineTempCount2; counter1++) arrayExpandFluorescentLineTemp [expandFluLineTempCount] = arrayExpandFluorescentLineTemp2 [counter1], expandFluLineTempCount++;
                    }
                    
                    if (connectList > 0){
                        for (int counter1 = 0; counter1 < expandFluLineTempCount/5; counter1++){
                            if (arrayExpandFluorescentLineTemp [counter1*5+2] == connectList){
                                arrayExpandFluorescentLineTemp2 [expandFluLineTempCount2] = arrayExpandFluorescentLineTemp [counter1*5], expandFluLineTempCount2++;
                                arrayExpandFluorescentLineTemp2 [expandFluLineTempCount2] = arrayExpandFluorescentLineTemp [counter1*5+1], expandFluLineTempCount2++;
                                arrayExpandFluorescentLineTemp2 [expandFluLineTempCount2] = arrayExpandFluorescentLineTemp [counter1*5+2], expandFluLineTempCount2++;
                                arrayExpandFluorescentLineTemp2 [expandFluLineTempCount2] = arrayExpandFluorescentLineTemp [counter1*5+3], expandFluLineTempCount2++;
                                arrayExpandFluorescentLineTemp2 [expandFluLineTempCount2] = arrayExpandFluorescentLineTemp [counter1*5+4], expandFluLineTempCount2++;
                            }
                        }
                        
                        expandFluLineTempCount = 0;
                        for (int counter1 = 0; counter1 < expandFluLineTempCount2; counter1++) arrayExpandFluorescentLineTemp [expandFluLineTempCount] = arrayExpandFluorescentLineTemp2 [counter1], expandFluLineTempCount++;
                    }
                    
                    delete [] arrayExpandFluorescentLineTemp2;
                    
                    if (expandFluLineTempCount != 0){
                        listStringCount = 0;
                        
                        //*********Fluorescent Line**********
                        //1. X Position
                        //2. Y position
                        //3. Connect No
                        //4. Channel No (1, 2, 3 Live, 4, 5, 6 IF)
                        
                        int maxXLength = 0;
                        int maxYLength = 0;
                        int connectLength = 0;
                        
                        for (int counter1 = 0; counter1 < expandFluLineTempCount/5; counter1++){
                            if (maxXLength < arrayExpandFluorescentLineTemp [counter1*5]) maxXLength = arrayExpandFluorescentLineTemp [counter1*5];
                            if (maxYLength < arrayExpandFluorescentLineTemp [counter1*5+1]) maxYLength = arrayExpandFluorescentLineTemp [counter1*5+1];
                            if (connectLength < arrayExpandFluorescentLineTemp [counter1*5+2]) connectLength = arrayExpandFluorescentLineTemp [counter1*5+2];
                        }
                        
                        maxXLength = (int)(to_string(maxXLength).length());
                        maxYLength = (int)(to_string(maxYLength).length());
                        connectLength = (int)(to_string(connectLength).length());
                        
                        int countLength = (int)(to_string(expandFluLineTempCount/5+1).length());
                        int countLengthAdd = 0;
                        string countLengthString;
                        
                        for (int counter1 = 0; counter1 < expandFluLineTempCount/5; counter1++){
                            if (listStringCount+20 > listStringLimit) [self listStringUpDate];
                            
                            //-----No-----
                            countLengthString = "";
                            countLengthAdd = countLength-(int)(to_string(counter1+1).length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(counter1+1);
                            arrayListString [listStringCount] = countLengthString+"//";
                            
                            //-----X-----
                            countLengthString = " ";
                            countLengthAdd = maxXLength-(int)(to_string(arrayExpandFluorescentLineTemp [counter1*5]).length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayExpandFluorescentLineTemp [counter1*5]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                            
                            //-----Y-----
                            countLengthString = " ";
                            countLengthAdd = maxYLength-(int)(to_string(arrayExpandFluorescentLineTemp [counter1*5+1]).length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayExpandFluorescentLineTemp [counter1*5+1]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                            
                            //-----Connect-----
                            countLengthString = " ";
                            countLengthAdd = connectLength-(int)(to_string(arrayExpandFluorescentLineTemp [counter1*5+2]).length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayExpandFluorescentLineTemp [counter1*5+2]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                            
                            //-----Ch no-----
                            countLengthString = " ";
                            countLengthString = countLengthString+to_string(arrayExpandFluorescentLineTemp [counter1*5+3]);
                            arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString;
                            
                            arrayListString [listStringCount] = arrayListString [listStringCount]+"~~"+to_string(arrayExpandFluorescentLineTemp [counter1*5+4])+"++"+nameStringRep+"^^"+extension+"&&";
                            
                            listStringCount++;
                        }
                        
                        [replaceFromTextDisplay setStringValue:@""];
                        [replaceToTextDisplay setStringValue:@""];
                        [replaceLineFromDisplay setStringValue:@""];
                        [replaceLineToDisplay setStringValue:@""];
                        [removeLineFromDisplay setStringValue:@""];
                        [removeLineToDisplay setStringValue:@""];
                        
                        listArrayStatusHold = 8;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Fluorescent Data Missing"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                        
                        listStringCount = 0;
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Fluorescent Read Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                    
                    listStringCount = 0;
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
                }
                
                delete [] arrayExpandFluorescentLineTemp;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Fluorescent Data Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                listStringCount = 0;
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time/Channel/Connect Requirement"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)listFluorescentArea:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && cleaningProgress == 0 && progressControl == 0){
        int timeList = [timeSetDisplay integerValue];
        int chList = [channelNoSetDisplay integerValue];
        int connectList = [connectNoSetDisplay integerValue];
        
        if (timeList > 0){
            if (listStringStatus == 0){
                arrayListString = new string [5000];
                listStringCount = 0;
                listStringLimit = 5000;
                listStringStatus = 1;
            }
            else listStringCount = 0;
            
            //*********Fluorescent Data**********
            //1. Connect No
            //2. Channel No (1, 2, 3 Live, 4, 5, 6 IF)
            //3. CH Value
            //4. CH Area
            
            [lineDataCurrentDisplay setStringValue:@"Fluorescent-Area"];
            
            string lineData = "Fluorescent-Area:Line No//connect no/CH no/CH value/CH area~~Line marks";
            [dataStructureDisplay setStringValue:@(lineData.c_str())];
            
            if (checkListCount == 0 && treatmentNameHold != ""){
                nameStringRep = treatmentNameHold;
            }
            else nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
            
            string extension = to_string(timeList);
            
            int stepCount = 0;
            int finData [25];
            
            unsigned long readPosition = 0;
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            //-----Fluorescent area data read-----
            string connectFluorescentPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_ExtendAreaData";
            
            struct stat sizeOfFile;
            long sizeForCopy = 0;
            
            if (stat(connectFluorescentPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            int *arrayExpandFluorescentAreaTemp = new int [(int)(sizeForCopy*1.2)+50];
            int expandFluAreaTempCount = 0;
            int entryCount = 0;
            
            ifstream fin;
            
            fin.open(connectFluorescentPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                fin.close();
                
                readPosition = 0;
                stepCount = 0;
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++;
                        finData [1] = uploadTemp [readPosition], readPosition++;
                        finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                        finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                        finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++;
                        finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                        
                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                        
                        if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                        else{
                            
                            arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = finData [2], expandFluAreaTempCount++;
                            arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = finData [3], expandFluAreaTempCount++;
                            arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = finData [4], expandFluAreaTempCount++;
                            arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = finData [7], expandFluAreaTempCount++;
                            arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = entryCount, expandFluAreaTempCount++;
                            entryCount++;
                        }
                    }
                    
                } while (stepCount != 3);
                
                delete [] uploadTemp;
            }
            
            //for (int counterA = 0; counterA < expandFluAreaTempCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayExpandFluorescentAreaTemp [counterA*5+counterB];
            //    cout<<" arrayExpandFluorescentAreaTemp "<<counterA<<endl;
            //}
            
            if (sizeForCopy != 0){
                int *arrayExpandFluorescentAreaTemp2 = new int [expandFluAreaTempCount+10];
                int expandFluAreaTempCount2 = 0;
                
                if (chList >= 1 && chList <= 12){
                    for (int counter1 = 0; counter1 < expandFluAreaTempCount/5; counter1++){
                        if (arrayExpandFluorescentAreaTemp [counter1*5+1] == chList){
                            arrayExpandFluorescentAreaTemp2 [expandFluAreaTempCount2] = arrayExpandFluorescentAreaTemp [counter1*5], expandFluAreaTempCount2++;
                            arrayExpandFluorescentAreaTemp2 [expandFluAreaTempCount2] = arrayExpandFluorescentAreaTemp [counter1*5+1], expandFluAreaTempCount2++;
                            arrayExpandFluorescentAreaTemp2 [expandFluAreaTempCount2] = arrayExpandFluorescentAreaTemp [counter1*5+2], expandFluAreaTempCount2++;
                            arrayExpandFluorescentAreaTemp2 [expandFluAreaTempCount2] = arrayExpandFluorescentAreaTemp [counter1*5+3], expandFluAreaTempCount2++;
                            arrayExpandFluorescentAreaTemp2 [expandFluAreaTempCount2] = arrayExpandFluorescentAreaTemp [counter1*5+4], expandFluAreaTempCount2++;
                        }
                    }
                    
                    expandFluAreaTempCount = 0;
                    for (int counter1 = 0; counter1 < expandFluAreaTempCount2; counter1++) arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = arrayExpandFluorescentAreaTemp2 [counter1], expandFluAreaTempCount++;
                }
                
                if (connectList > 0){
                    for (int counter1 = 0; counter1 < expandFluAreaTempCount/5; counter1++){
                        if (arrayExpandFluorescentAreaTemp [counter1*5] == connectList){
                            arrayExpandFluorescentAreaTemp2 [expandFluAreaTempCount2] = arrayExpandFluorescentAreaTemp [counter1*5], expandFluAreaTempCount2++;
                            arrayExpandFluorescentAreaTemp2 [expandFluAreaTempCount2] = arrayExpandFluorescentAreaTemp [counter1*5+1], expandFluAreaTempCount2++;
                            arrayExpandFluorescentAreaTemp2 [expandFluAreaTempCount2] = arrayExpandFluorescentAreaTemp [counter1*5+2], expandFluAreaTempCount2++;
                            arrayExpandFluorescentAreaTemp2 [expandFluAreaTempCount2] = arrayExpandFluorescentAreaTemp [counter1*5+3], expandFluAreaTempCount2++;
                            arrayExpandFluorescentAreaTemp2 [expandFluAreaTempCount2] = arrayExpandFluorescentAreaTemp [counter1*5+4], expandFluAreaTempCount2++;
                        }
                    }
                    
                    expandFluAreaTempCount = 0;
                    for (int counter1 = 0; counter1 < expandFluAreaTempCount2; counter1++) arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = arrayExpandFluorescentAreaTemp2 [counter1], expandFluAreaTempCount++;
                }
                
                delete [] arrayExpandFluorescentAreaTemp2;
                
                if (expandFluAreaTempCount != 0){
                    listStringCount = 0;
                    
                    int connectLength = 0;
                    int chValueLength = 0;
                    int chAreaLength = 0;
                    
                    for (int counter1 = 0; counter1 < expandFluAreaTempCount/5; counter1++){
                        if (connectLength < arrayExpandFluorescentAreaTemp [counter1*5+2]) connectLength = arrayExpandFluorescentAreaTemp [counter1*5+2];
                        if (chValueLength < arrayExpandFluorescentAreaTemp [counter1*5]) chValueLength = arrayExpandFluorescentAreaTemp [counter1*5];
                        if (chAreaLength < arrayExpandFluorescentAreaTemp [counter1*5+1]) chAreaLength = arrayExpandFluorescentAreaTemp [counter1*5+1];
                    }
                    
                    chValueLength = (int)(to_string(chValueLength).length());
                    chAreaLength = (int)(to_string(chAreaLength).length());
                    connectLength = (int)(to_string(connectLength).length());
                    
                    int countLength = (int)(to_string(expandFluAreaTempCount/5+1).length());
                    int countLengthAdd = 0;
                    string countLengthString;
                    
                    for (int counter1 = 0; counter1 < expandFluAreaTempCount/5; counter1++){
                        if (listStringCount+20 > listStringLimit) [self listStringUpDate];
                        
                        //-----No-----
                        countLengthString = "";
                        countLengthAdd = countLength-(int)(to_string(counter1+1).length());
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+to_string(counter1+1);
                        arrayListString [listStringCount] = countLengthString+"//";
                        
                        //-----Connect-----
                        countLengthString = " ";
                        countLengthAdd = connectLength-(int)(to_string(arrayExpandFluorescentAreaTemp [counter1*5]).length());
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+to_string(arrayExpandFluorescentAreaTemp [counter1*5]);
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                        
                        //-----Ch no-----
                        countLengthString = " ";
                        countLengthString = countLengthString+to_string(arrayExpandFluorescentAreaTemp [counter1*5+1]);
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                        
                        //-----Ch value-----
                        countLengthString = " ";
                        countLengthAdd = chValueLength-(int)(to_string(arrayExpandFluorescentAreaTemp [counter1*5+2]).length());
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+to_string(arrayExpandFluorescentAreaTemp [counter1*5+2]);
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                        
                        //-----Ch area-----
                        countLengthString = " ";
                        countLengthAdd = chAreaLength-(int)(to_string(arrayExpandFluorescentAreaTemp [counter1*5+3]).length());
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+to_string(arrayExpandFluorescentAreaTemp [counter1*5+3]);
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString;
                        
                        arrayListString [listStringCount] = arrayListString [listStringCount]+"~~"+to_string(arrayExpandFluorescentAreaTemp [counter1*5+4])+"++"+nameStringRep+"^^"+extension+"&&";
                        
                        listStringCount++;
                    }
                    
                    [replaceFromTextDisplay setStringValue:@""];
                    [replaceToTextDisplay setStringValue:@""];
                    [replaceLineFromDisplay setStringValue:@""];
                    [replaceLineToDisplay setStringValue:@""];
                    [removeLineFromDisplay setStringValue:@""];
                    [removeLineToDisplay setStringValue:@""];
                    
                    listArrayStatusHold = 9;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Fluorescent Data Missing"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                    
                    listStringCount = 0;
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Fluorescent Data Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                listStringCount = 0;
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
            }
            
            delete [] arrayExpandFluorescentAreaTemp;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time/Channel/Connect Requirement"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)listFluorescentCut:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && cleaningProgress == 0 && progressControl == 0){
        if (listStringStatus == 0){
            arrayListString = new string [5000];
            listStringCount = 0;
            listStringLimit = 5000;
            listStringStatus = 1;
        }
        else listStringCount = 0;
        
        [lineDataCurrentDisplay setStringValue:@"Fluorescent-CutOff"];
        
        string lineData = "Fluorescent-CutOff:Line No//Time/CH1 Cut/CH2 cut/CH3 cut/CH3=4 cut/CH5 cut/CH6 cut~~Line marks";
        [dataStructureDisplay setStringValue:@(lineData.c_str())];
        
        if (checkListCount == 0 && treatmentNameHold != ""){
            nameStringRep = treatmentNameHold;
        }
        else nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
        
        string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
        
        struct stat sizeOfFile;
        long sizeForCopy = 0;
        
        if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (sizeForCopy != 0){
            int *arrayFluorescentCutOffTemp = new int [imageEndHold*8+20];
            int fluorescentCutOffCountTemp = 0;
            int entryCount = 0;
            
            string getString;
            
            ifstream fin;
            
            fin.open (cutOffPath.c_str(), ios::in);
            
            if (fin.is_open()){
                for (int counter1 = 0; counter1 < imageEndHold; counter1++){
                    getline(fin, getString);
                    
                    if (getString != "End"){
                        arrayFluorescentCutOffTemp [fluorescentCutOffCountTemp] = atoi(getString.c_str()), fluorescentCutOffCountTemp++;
                        getline(fin, getString);
                        arrayFluorescentCutOffTemp [fluorescentCutOffCountTemp] = atoi(getString.c_str()), fluorescentCutOffCountTemp++;
                        getline(fin, getString);
                        arrayFluorescentCutOffTemp [fluorescentCutOffCountTemp] = atoi(getString.c_str()), fluorescentCutOffCountTemp++;
                        getline(fin, getString);
                        arrayFluorescentCutOffTemp [fluorescentCutOffCountTemp] = atoi(getString.c_str()), fluorescentCutOffCountTemp++;
                        getline(fin, getString);
                        arrayFluorescentCutOffTemp [fluorescentCutOffCountTemp] = atoi(getString.c_str()), fluorescentCutOffCountTemp++;
                        getline(fin, getString);
                        arrayFluorescentCutOffTemp [fluorescentCutOffCountTemp] = atoi(getString.c_str()), fluorescentCutOffCountTemp++;
                        getline(fin, getString);
                        arrayFluorescentCutOffTemp [fluorescentCutOffCountTemp] = atoi(getString.c_str()), fluorescentCutOffCountTemp++;
                        arrayFluorescentCutOffTemp [fluorescentCutOffCountTemp] = entryCount, fluorescentCutOffCountTemp++;
                        entryCount++;
                    }
                    else{
                        
                        break;
                    }
                }
                
                fin.close();
            }
            
            if (fluorescentCutOffCountTemp != 1){
                listStringCount = 0;
                
                int countLength = (int)(to_string(fluorescentCutOffCountTemp/8+1).length());
                int countLengthAdd = 0;
                string countLengthString;
                
                for (int counter1 = 0; counter1 < fluorescentCutOffCountTemp/8; counter1++){
                    if (listStringCount+20 > listStringLimit) [self listStringUpDate];
                    
                    //-----No-----
                    countLengthString = "";
                    countLengthAdd = countLength-(int)(to_string(counter1+1).length());
                    
                    for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                        countLengthString = countLengthString+"0";
                    }
                    
                    countLengthString = countLengthString+to_string(counter1+1);
                    arrayListString [listStringCount] = countLengthString+"//";
                    
                    //-----Time-----
                    countLengthString = " ";
                    countLengthAdd = 4-(int)(to_string(arrayFluorescentCutOffTemp [counter1*8]).length());
                    
                    for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                        countLengthString = countLengthString+"0";
                    }
                    
                    countLengthString = countLengthString+to_string(arrayFluorescentCutOffTemp [counter1*8]);
                    arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                    
                    //-----Ch 1-----
                    countLengthString = " ";
                    countLengthAdd = 3-(int)(to_string(arrayFluorescentCutOffTemp [counter1*8+1]).length());
                    
                    for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                        countLengthString = countLengthString+"0";
                    }
                    
                    countLengthString = countLengthString+to_string(arrayFluorescentCutOffTemp [counter1*8+1]);
                    arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                    
                    //-----Ch 2-----
                    countLengthString = " ";
                    countLengthAdd = 3-(int)(to_string(arrayFluorescentCutOffTemp [counter1*8+2]).length());
                    
                    for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                        countLengthString = countLengthString+"0";
                    }
                    
                    countLengthString = countLengthString+to_string(arrayFluorescentCutOffTemp [counter1*8+2]);
                    arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                    
                    //-----Ch 3-----
                    countLengthString = " ";
                    countLengthAdd = 3-(int)(to_string(arrayFluorescentCutOffTemp [counter1*8+3]).length());
                    
                    for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                        countLengthString = countLengthString+"0";
                    }
                    
                    countLengthString = countLengthString+to_string(arrayFluorescentCutOffTemp [counter1*8+3]);
                    arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                    
                    //-----Ch 4-----
                    countLengthString = " ";
                    countLengthAdd = 3-(int)(to_string(arrayFluorescentCutOffTemp [counter1*8+4]).length());
                    
                    for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                        countLengthString = countLengthString+"0";
                    }
                    
                    countLengthString = countLengthString+to_string(arrayFluorescentCutOffTemp [counter1*8+4]);
                    arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                    
                    //-----Ch 5-----
                    countLengthString = " ";
                    countLengthAdd = 3-(int)(to_string(arrayFluorescentCutOffTemp [counter1*8+5]).length());
                    
                    for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                        countLengthString = countLengthString+"0";
                    }
                    
                    countLengthString = countLengthString+to_string(arrayFluorescentCutOffTemp [counter1*8+5]);
                    arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                    
                    //-----Ch 6-----
                    countLengthString = " ";
                    countLengthAdd = 3-(int)(to_string(arrayFluorescentCutOffTemp [counter1*8+6]).length());
                    
                    for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                        countLengthString = countLengthString+"0";
                    }
                    
                    countLengthString = countLengthString+to_string(arrayFluorescentCutOffTemp [counter1*8+6]);
                    arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString;
                    
                    arrayListString [listStringCount] = arrayListString [listStringCount]+"~~"+to_string(arrayFluorescentCutOffTemp [counter1*8+7])+"++"+nameStringRep+"^^0&&";
                    
                    listStringCount++;
                }
                
                [replaceFromTextDisplay setStringValue:@""];
                [replaceToTextDisplay setStringValue:@""];
                [replaceLineFromDisplay setStringValue:@""];
                [replaceLineToDisplay setStringValue:@""];
                [removeLineFromDisplay setStringValue:@""];
                [removeLineToDisplay setStringValue:@""];
                
                listArrayStatusHold = 10;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Fluorescent Cutt Data"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                listStringCount = 0;
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
            }
            
            delete [] arrayFluorescentCutOffTemp;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Fluorescent Cutt Data"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
            
            listStringCount = 0;
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)listPartner:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && cleaningProgress == 0 && progressControl == 0){
        if (listStringStatus == 0){
            arrayListString = new string [5000];
            listStringCount = 0;
            listStringLimit = 5000;
            listStringStatus = 1;
        }
        else listStringCount = 0;
        
        //********arrayLineagePartnerInfo*********
        //1.TreatName
        //2.Lineage No
        //3.Cell no
        //4.W-image position
        //5.Partner Lineage No
        //6.Partner Cell No
        
        [lineDataCurrentDisplay setStringValue:@"Lineage-Partner"];
        
        string lineData = "Lineage-Partner:Line No//TreatName/Lineage no/Cell no/W-Image position/Partner Lineage no/Partner cell no~~Line marks";
        [dataStructureDisplay setStringValue:@(lineData.c_str())];
        
        if (checkListCount == 0 && treatmentNameHold != ""){
            nameStringRep = treatmentNameHold;
        }
        else nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
        
        //=======Lineage partner line=======
        string cellFusionPartnerPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+analysisID+"_"+nameStringRep+"_FusionPartner";
        
        struct stat sizeOfFile;
        long sizeForCopy = 0;
        
        if (stat(cellFusionPartnerPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (sizeForCopy != 0){
            string *arrayLineagePartnerInfoTemp = new string [sizeForCopy+50];
            int lineagePartnerInfoTempCount = 0;
            
            ifstream fin;
            
            fin.open(cellFusionPartnerPath.c_str(), ios::in);
            
            if (fin.is_open()){
                string treatmentNameGet;
                string lineageNoGet;
                string cellNoGet;
                string imageNoGet;
                string partnerLingNoGet;
                string partnerCellNoGet;
                
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    getline(fin, treatmentNameGet);
                    
                    if (treatmentNameGet == "") terminationFlag = 0;
                    else{
                        
                        getline(fin, lineageNoGet);
                        getline(fin, cellNoGet);
                        getline(fin, imageNoGet);
                        getline(fin, partnerLingNoGet);
                        getline(fin, partnerCellNoGet);
                        
                        arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = treatmentNameGet, lineagePartnerInfoTempCount++;
                        arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = lineageNoGet, lineagePartnerInfoTempCount++;
                        arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = cellNoGet, lineagePartnerInfoTempCount++;
                        arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = imageNoGet, lineagePartnerInfoTempCount++;
                        arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = partnerLingNoGet, lineagePartnerInfoTempCount++;
                        arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = partnerCellNoGet, lineagePartnerInfoTempCount++;
                    }
                    
                } while (terminationFlag == 1);
                
                fin.close();
                
                if (lineagePartnerInfoTempCount != 1){
                    listStringCount = 0;
                    
                    //********arrayLineagePartnerInfo*********
                    //1.TreatName
                    //2.Lineage No
                    //3.Cell no
                    //4.W-image position
                    //5.Partner Lineage No
                    //6.Partner Cell No
                    
                    int treatLength = 0;
                    int wPositionLength = 0;
                    
                    for (int counter1 = 0; counter1 < lineagePartnerInfoTempCount/6; counter1++){
                        if (treatLength < (int)arrayLineagePartnerInfoTemp [counter1*6].length()) treatLength = (int)arrayLineagePartnerInfoTemp [counter1*6].length();
                        if (wPositionLength < (int)arrayLineagePartnerInfoTemp [counter1*6+3].length()) wPositionLength = (int)arrayLineagePartnerInfoTemp [counter1*6+3].length();
                    }
                    
                    treatLength = (int)(to_string(treatLength).length());
                    wPositionLength = (int)(to_string(wPositionLength).length());
                    
                    int countLength = (int)(to_string(lineagePartnerInfoTempCount/6+1).length());
                    int countLengthAdd = 0;
                    string countLengthString;
                    
                    for (int counter1 = 0; counter1 < lineagePartnerInfoTempCount/6; counter1++){
                        if (listStringCount+20 > listStringLimit) [self listStringUpDate];
                        
                        //-----No-----
                        countLengthString = "";
                        countLengthAdd = countLength-(int)(to_string(counter1+1).length());
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+to_string(counter1+1);
                        arrayListString [listStringCount] = countLengthString+"//";
                        
                        //-----Treat Name-----
                        countLengthString = " ";
                        countLengthAdd = treatLength-(int)(arrayLineagePartnerInfoTemp [counter1*6].length());
                        
                        countLengthString = countLengthString+arrayLineagePartnerInfoTemp [counter1*6];
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+" ";
                        }
                        
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                        
                        //-----Lineage-----
                        countLengthString = " ";
                        countLengthAdd = 5-(int)(arrayLineagePartnerInfoTemp [counter1*6+1].length());
                        countLengthString = countLengthString+"L";
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+arrayLineagePartnerInfoTemp [counter1*6+1];
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                        
                        //-----Cell-----
                        countLengthString = " ";
                        
                        if (arrayLineagePartnerInfoTemp [counter1*6+2] == "0") countLengthString = countLengthString+" C000000000";
                        else if (atoi(arrayLineagePartnerInfoTemp [counter1*6+2].c_str()) < 0){
                            countLengthAdd = 9-(int)(arrayLineagePartnerInfoTemp [counter1*6+2].length());
                            countLengthString = countLengthString+"C";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+arrayLineagePartnerInfoTemp [counter1*6+2];
                        }
                        else if (atoi(arrayLineagePartnerInfoTemp [counter1*6+2].c_str()) > 0){
                            countLengthAdd = 9-(int)(arrayLineagePartnerInfoTemp [counter1*6+2].length());
                            countLengthString = countLengthString+" C";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+arrayLineagePartnerInfoTemp [counter1*6+2];
                        }
                        
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                        
                        //-----W-Position-----
                        countLengthString = " ";
                        countLengthAdd = wPositionLength-(int)(arrayLineagePartnerInfoTemp [counter1*6+3].length());
                        
                        countLengthString = countLengthString+arrayLineagePartnerInfoTemp [counter1*6+3];
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+" ";
                        }
                        
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                        
                        //-----Partner Lineage-----
                        countLengthString = " ";
                        countLengthAdd = 5-(int)(arrayLineagePartnerInfoTemp [counter1*6+4].length());
                        countLengthString = countLengthString+"l";
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+arrayLineagePartnerInfoTemp [counter1*6+4];
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                        
                        //-----Partner Cell-----
                        countLengthString = " ";
                        
                        if (arrayLineagePartnerInfoTemp [counter1*6+5] == "0") countLengthString = countLengthString+" c000000000";
                        else if (atoi(arrayLineagePartnerInfoTemp [counter1*6+5].c_str()) < 0){
                            countLengthAdd = 9-(int)(arrayLineagePartnerInfoTemp [counter1*6+5].length());
                            countLengthString = countLengthString+"c";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+arrayLineagePartnerInfoTemp [counter1*6+5];
                        }
                        else if (atoi(arrayLineagePartnerInfoTemp [counter1*6+5].c_str()) > 0){
                            countLengthAdd = 9-(int)(arrayLineagePartnerInfoTemp [counter1*6+5].length());
                            countLengthString = countLengthString+" c";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+arrayLineagePartnerInfoTemp [counter1*6+5];
                        }
                        
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString;
                        arrayListString [listStringCount] = arrayListString [listStringCount]+"~~"+to_string(counter1)+"++"+nameStringRep+"^^0&&";
                        
                        listStringCount++;
                    }
                    
                    [replaceFromTextDisplay setStringValue:@""];
                    [replaceToTextDisplay setStringValue:@""];
                    [replaceLineFromDisplay setStringValue:@""];
                    [replaceLineToDisplay setStringValue:@""];
                    [removeLineFromDisplay setStringValue:@""];
                    [removeLineToDisplay setStringValue:@""];
                    
                    listArrayStatusHold = 11;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Partner Data Missing"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                    
                    listStringCount = 0;
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Partner Data Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                listStringCount = 0;
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
            }
            
            delete [] arrayLineagePartnerInfoTemp;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Partner Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
            
            listStringCount = 0;
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)listMitosis:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && cleaningProgress == 0 && progressControl == 0){
        if (listStringStatus == 0){
            arrayListString = new string [5000];
            listStringCount = 0;
            listStringLimit = 5000;
            listStringStatus = 1;
        }
        else listStringCount = 0;
        
        //********arrayMitosisStatus*********
        //1.Lineage No
        //2.Cell no
        //3.Image No
        //4.Status data (10: Mitosis, 1,2,6: Mitosis status, 3,4: cell death status)
        
        [lineDataCurrentDisplay setStringValue:@"Mitosis"];
        
        string lineData = "Mitosis:Line No//Lineage no/Cell no/Image no/Status~~Line marks";
        [dataStructureDisplay setStringValue:@(lineData.c_str())];
        
        if (checkListCount == 0 && treatmentNameHold != ""){
            nameStringRep = treatmentNameHold;
        }
        else nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
        
        //=======Mitosis Set array=======
        string mitosisStatusPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+ analysisID+"_"+nameStringRep+"_MitosisData";
        
        struct stat sizeOfFile;
        long sizeForCopy = 0;
        
        if (stat(mitosisStatusPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        int *arrayMitosisTemp = new int [sizeForCopy+50];
        int mitosisTempCount = 0;
        
        if (sizeForCopy != 0){
            ifstream fin;
            
            fin.open(mitosisStatusPath.c_str(), ios::in);
            
            if (fin.is_open()){
                string lineageNoGet;
                string cellNoGet;
                string imageNoGet;
                string setTypeGet;
                
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    getline(fin, lineageNoGet);
                    
                    if (lineageNoGet == "") terminationFlag = 0;
                    else{
                        
                        getline(fin, cellNoGet);
                        getline(fin, imageNoGet);
                        getline(fin, setTypeGet);
                        
                        arrayMitosisTemp [mitosisTempCount] = atoi(lineageNoGet.c_str()), mitosisTempCount++;
                        arrayMitosisTemp [mitosisTempCount] = atoi(cellNoGet.c_str()), mitosisTempCount++;
                        arrayMitosisTemp [mitosisTempCount] = atoi(imageNoGet.c_str()), mitosisTempCount++;
                        arrayMitosisTemp [mitosisTempCount] = atoi(setTypeGet.c_str()), mitosisTempCount++;
                    }
                    
                } while (terminationFlag == 1);
                
                fin.close();
                
                if (mitosisTempCount != 1){
                    listStringCount = 0;
                    
                    //********arrayMitosisStatus*********
                    //1.Lineage No
                    //2.Cell no
                    //3.Image No
                    //4.Status data (10: Mitosis, 1,2,6: Mitosis status, 3,4: cell death status)
                    
                    int countLength = (int)(to_string(mitosisTempCount/4+1).length());
                    int countLengthAdd = 0;
                    string countLengthString;
                    
                    for (int counter1 = 0; counter1 < mitosisTempCount/4; counter1++){
                        if (listStringCount+20 > listStringLimit) [self listStringUpDate];
                        
                        //-----No-----
                        countLengthString = "";
                        countLengthAdd = countLength-(int)(to_string(counter1+1).length());
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+to_string(counter1+1);
                        arrayListString [listStringCount] = countLengthString+"//";
                        
                        //-----Lineage-----
                        countLengthString = " ";
                        countLengthAdd = 5-(int)(to_string(arrayMitosisTemp [counter1*4]).length());
                        countLengthString = countLengthString+"L";
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+to_string(arrayMitosisTemp [counter1*4]);
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                        
                        //-----Cell-----
                        countLengthString = " ";
                        
                        if (arrayMitosisTemp [counter1*4+1] == 0) countLengthString = countLengthString+" C000000000";
                        else if (arrayMitosisTemp [counter1*4+1] < 0){
                            countLengthAdd = 9-(int)(to_string(arrayMitosisTemp [counter1*4+1]*-1).length());
                            countLengthString = countLengthString+"C-";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayMitosisTemp [counter1*4+1]*-1);
                        }
                        else if (arrayMitosisTemp [counter1*4+1] > 0){
                            countLengthAdd = 9-(int)(to_string(arrayMitosisTemp [counter1*4+1]).length());
                            countLengthString = countLengthString+" C";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+to_string(arrayMitosisTemp [counter1*4+1]);
                        }
                        
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                        
                        //-----Image No-----
                        countLengthString = " ";
                        countLengthAdd = 4-(int)(to_string(arrayMitosisTemp [counter1*4+2]).length());
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+to_string(arrayMitosisTemp [counter1*4+2]);
                        
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString+"/";
                        
                        //-----Status-----
                        countLengthString = " ";
                        countLengthAdd = 2-(int)(to_string(arrayMitosisTemp [counter1*4+3]).length());
                        
                        countLengthString = countLengthString+to_string(arrayMitosisTemp [counter1*4+3]);
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+to_string(arrayMitosisTemp [counter1*4+3]);
                        arrayListString [listStringCount] = arrayListString [listStringCount]+countLengthString;
                        
                        arrayListString [listStringCount] = arrayListString [listStringCount]+"~~"+to_string(counter1)+"++"+nameStringRep+"^^0&&";
                        
                        listStringCount++;
                    }
                    
                    [replaceFromTextDisplay setStringValue:@""];
                    [replaceToTextDisplay setStringValue:@""];
                    [replaceLineFromDisplay setStringValue:@""];
                    [replaceLineToDisplay setStringValue:@""];
                    [removeLineFromDisplay setStringValue:@""];
                    [removeLineToDisplay setStringValue:@""];
                    
                    listArrayStatusHold = 12;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"No Mitosis Data"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                    
                    listStringCount = 0;
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Mitosis Data"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                listStringCount = 0;
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Mitosis File Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
            
            listStringCount = 0;
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
        }
        
        delete [] arrayMitosisTemp;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)listClear:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0){
        if (listStringStatus != 0){
            if (listStringLimit > 5000){
                delete [] arrayListString;
                
                arrayListString = new string [5000];
                listStringLimit = 5000;
            }
            
            [lineDataCurrentDisplay setStringValue:@"nil"];
            [replaceFromTextDisplay setStringValue:@""];
            [replaceToTextDisplay setStringValue:@""];
            [replaceLineFromDisplay setStringValue:@""];
            [replaceLineToDisplay setStringValue:@""];
            [removeLineFromDisplay setStringValue:@""];
            [removeLineToDisplay setStringValue:@""];
            
            listStringCount = 0;
            listArrayStatusHold = 0;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)boxClear:(id)sender{
    [lingNoSetDisplay setStringValue:@""];
    [cellNoSetDisplay setStringValue:@""];
    [connectNoSetDisplay setStringValue:@""];
    [channelNoSetDisplay setStringValue:@""];
    [timeSetDisplay setStringValue:@""];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

//1:"Lineage:Line No//Xposition/Yposition/Time/Event/Parent-fusion partner cell no/Cell no/Lineage. no/Fusion-partner Lineage no";
//2:"PR:Line No//Xposition/Yposition/Average/Connect no/Cell no/Status/Lineage. no";
//3:"ST:Line No//Status/Zero/PR Starting/Zero/Zero/Zero/Zero/Zero/Connect no/Lineage. no";
//4:"GC:Line No//Xposition/Yposition/Total area/Average/Connect no/Target hit";
//5:"RL:Line No//Lineage no/Connect no/Time/Cell no/Target/Zero";
//6:"AD:Line No//Connect No/Process type/Cut type/Pair no/Cell dim/Zero";
//7:"Map:Line No//Connect No/Number of Pix";
//8:"Fluorescent-Line:Line No//Xposition/Yposition/connect no/CH no";
//9:"Fluorescent-Area:Line No//connect no/CH no/CH value/CH area";
//10:"Fluorescent-CutOff:Line No//Time/CH1 Cut/CH2 cut/CH3 cut";

-(IBAction)lingGetSelf:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (listStringStatus != 0){
            if (listArrayStatusHold == 1 || listArrayStatusHold == 2 || listArrayStatusHold == 3 || listArrayStatusHold == 5){
                if (listArrayStatusHold == 1){
                    string lineageStringExtract = arrayListString [repairListTableCurrentRow];
                    
                    for (int counter1 = 0; counter1 < 8; counter1++){
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                    }
                    
                    lineageStringExtract = lineageStringExtract.substr(2, lineageStringExtract.find("/")-2);
                    lineageStringExtract = to_string(atoi(lineageStringExtract.c_str()));
                    
                    [lingNoSetDisplay setStringValue:@(lineageStringExtract.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (listArrayStatusHold == 2){
                    string lineageStringExtract = arrayListString [repairListTableCurrentRow];
                    
                    for (int counter1 = 0; counter1 < 9; counter1++){
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                    }
                    
                    lineageStringExtract = lineageStringExtract.substr(2, lineageStringExtract.find("~~")-2);
                    lineageStringExtract = to_string(atoi(lineageStringExtract.c_str()));
                    
                    [lingNoSetDisplay setStringValue:@(lineageStringExtract.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (listArrayStatusHold == 3){
                    string lineageStringExtract = arrayListString [repairListTableCurrentRow];
                    
                    for (int counter1 = 0; counter1 < 11; counter1++){
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                    }
                    
                    lineageStringExtract = lineageStringExtract.substr(2, lineageStringExtract.find("~~")-2);
                    lineageStringExtract = to_string(atoi(lineageStringExtract.c_str()));
                    
                    [lingNoSetDisplay setStringValue:@(lineageStringExtract.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (listArrayStatusHold == 5){
                    string lineageStringExtract = arrayListString [repairListTableCurrentRow];
                    
                    for (int counter1 = 0; counter1 < 2; counter1++){
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                    }
                    
                    lineageStringExtract = lineageStringExtract.substr(2, lineageStringExtract.find("/")-2);
                    lineageStringExtract = to_string(atoi(lineageStringExtract.c_str()));
                    
                    [lingNoSetDisplay setStringValue:@(lineageStringExtract.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lingGetPartner:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (listStringStatus != 0){
            if (listArrayStatusHold == 1){
                string lineageStringExtract = arrayListString [repairListTableCurrentRow];
                
                for (int counter1 = 0; counter1 < 9; counter1++){
                    lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                }
                
                lineageStringExtract = lineageStringExtract.substr(2, lineageStringExtract.find("~~")-2);
                lineageStringExtract = to_string(atoi(lineageStringExtract.c_str()));
                
                [lingNoSetDisplay setStringValue:@(lineageStringExtract.c_str())];
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lingClear:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0){
        if (listStringStatus != 0){
            [lingNoSetDisplay setStringValue:@""];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cellGetSelf:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (listStringStatus != 0){
            if (listArrayStatusHold == 1 || listArrayStatusHold == 2 || listArrayStatusHold == 5){
                if (listArrayStatusHold == 1){
                    string lineageStringExtract = arrayListString [repairListTableCurrentRow];
                    
                    for (int counter1 = 0; counter1 < 7; counter1++){
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                    }
                    
                    lineageStringExtract = lineageStringExtract.substr(0, lineageStringExtract.find("/"));
                    lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("C")+1);
                    lineageStringExtract = to_string(atoi(lineageStringExtract.c_str()));
                    
                    [cellNoSetDisplay setStringValue:@(lineageStringExtract.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (listArrayStatusHold == 2){
                    string lineageStringExtract = arrayListString [repairListTableCurrentRow];
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                    }
                    
                    lineageStringExtract = lineageStringExtract.substr(0, lineageStringExtract.find("/"));
                    lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("C")+1);
                    lineageStringExtract = to_string(atoi(lineageStringExtract.c_str()));
                    
                    [cellNoSetDisplay setStringValue:@(lineageStringExtract.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (listArrayStatusHold == 5){
                    string lineageStringExtract = arrayListString [repairListTableCurrentRow];
                    
                    for (int counter1 = 0; counter1 < 5; counter1++){
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                    }
                    
                    lineageStringExtract = lineageStringExtract.substr(0, lineageStringExtract.find("/"));
                    lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("C")+1);
                    lineageStringExtract = to_string(atoi(lineageStringExtract.c_str()));
                    
                    [cellNoSetDisplay setStringValue:@(lineageStringExtract.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cellGetPartner:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (listStringStatus != 0){
            if (listArrayStatusHold == 1){
                string lineageStringExtract = arrayListString [repairListTableCurrentRow];
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                }
                
                lineageStringExtract = lineageStringExtract.substr(0, lineageStringExtract.find("/"));
                lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("c")+1);
                lineageStringExtract = to_string(atoi(lineageStringExtract.c_str()));
                
                [cellNoSetDisplay setStringValue:@(lineageStringExtract.c_str())];
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cellClear:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0){
        if (listStringStatus != 0){
            [cellNoSetDisplay setStringValue:@""];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)chGetSelf:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (listStringStatus != 0){
            if (listArrayStatusHold == 8 || listArrayStatusHold == 9){
                if (listArrayStatusHold == 8){
                    string lineageStringExtract = arrayListString [repairListTableCurrentRow];
                    
                    for (int counter1 = 0; counter1 < 5; counter1++){
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                    }
                    
                    lineageStringExtract = lineageStringExtract.substr(1, lineageStringExtract.find("~~")-1);
                    lineageStringExtract = to_string(atoi(lineageStringExtract.c_str()));
                    
                    [channelNoSetDisplay setStringValue:@(lineageStringExtract.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (listArrayStatusHold == 9){
                    string lineageStringExtract = arrayListString [repairListTableCurrentRow];
                    
                    for (int counter1 = 0; counter1 < 3; counter1++){
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                    }
                    
                    lineageStringExtract = lineageStringExtract.substr(1, lineageStringExtract.find("/")-1);
                    lineageStringExtract = to_string(atoi(lineageStringExtract.c_str()));
                    
                    [channelNoSetDisplay setStringValue:@(lineageStringExtract.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)chClear:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0){
        if (listStringStatus != 0){
            [channelNoSetDisplay setStringValue:@""];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)connectGetSelf:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (listStringStatus != 0){
            if (listArrayStatusHold >= 2 && listArrayStatusHold <= 9){
                if (listArrayStatusHold == 2){
                    string lineageStringExtract = arrayListString [repairListTableCurrentRow];
                    
                    for (int counter1 = 0; counter1 < 5; counter1++){
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                    }
                    
                    lineageStringExtract = lineageStringExtract.substr(1, lineageStringExtract.find("/")-1);
                    lineageStringExtract = to_string(atoi(lineageStringExtract.c_str()));
                    
                    [connectNoSetDisplay setStringValue:@(lineageStringExtract.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (listArrayStatusHold == 3){
                    string lineageStringExtract = arrayListString [repairListTableCurrentRow];
                    
                    for (int counter1 = 0; counter1 < 10; counter1++){
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                    }
                    
                    lineageStringExtract = lineageStringExtract.substr(1, lineageStringExtract.find("/")-1);
                    lineageStringExtract = to_string(atoi(lineageStringExtract.c_str()));
                    
                    [connectNoSetDisplay setStringValue:@(lineageStringExtract.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (listArrayStatusHold == 4){
                    string lineageStringExtract = arrayListString [repairListTableCurrentRow];
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                    }
                    
                    lineageStringExtract = lineageStringExtract.substr(1, lineageStringExtract.find("/")-1);
                    lineageStringExtract = to_string(atoi(lineageStringExtract.c_str()));
                    
                    [connectNoSetDisplay setStringValue:@(lineageStringExtract.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (listArrayStatusHold == 5){
                    string lineageStringExtract = arrayListString [repairListTableCurrentRow];
                    
                    for (int counter1 = 0; counter1 < 3; counter1++){
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                    }
                    
                    lineageStringExtract = lineageStringExtract.substr(1, lineageStringExtract.find("/")-1);
                    lineageStringExtract = to_string(atoi(lineageStringExtract.c_str()));
                    
                    [connectNoSetDisplay setStringValue:@(lineageStringExtract.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (listArrayStatusHold == 6){
                    string lineageStringExtract = arrayListString [repairListTableCurrentRow];
                    
                    for (int counter1 = 0; counter1 < 2; counter1++){
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                    }
                    
                    lineageStringExtract = lineageStringExtract.substr(1, lineageStringExtract.find("/")-1);
                    lineageStringExtract = to_string(atoi(lineageStringExtract.c_str()));
                    
                    [connectNoSetDisplay setStringValue:@(lineageStringExtract.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (listArrayStatusHold == 7){
                    string lineageStringExtract = arrayListString [repairListTableCurrentRow];
                    
                    for (int counter1 = 0; counter1 < 2; counter1++){
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                    }
                    
                    lineageStringExtract = lineageStringExtract.substr(1, lineageStringExtract.find("/")-1);
                    lineageStringExtract = to_string(atoi(lineageStringExtract.c_str()));
                    
                    [connectNoSetDisplay setStringValue:@(lineageStringExtract.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (listArrayStatusHold == 8){
                    string lineageStringExtract = arrayListString [repairListTableCurrentRow];
                    
                    for (int counter1 = 0; counter1 < 4; counter1++){
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                    }
                    
                    lineageStringExtract = lineageStringExtract.substr(1, lineageStringExtract.find("/")-1);
                    
                    [connectNoSetDisplay setStringValue:@(lineageStringExtract.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (listArrayStatusHold == 9){
                    string lineageStringExtract = arrayListString [repairListTableCurrentRow];
                    
                    for (int counter1 = 0; counter1 < 2; counter1++){
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                    }
                    
                    lineageStringExtract = lineageStringExtract.substr(1, lineageStringExtract.find("/")-1);
                    lineageStringExtract = to_string(atoi(lineageStringExtract.c_str()));
                    
                    [connectNoSetDisplay setStringValue:@(lineageStringExtract.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)connectClear:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (listStringStatus != 0){
            [connectNoSetDisplay setStringValue:@""];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)timeClear:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (listStringStatus != 0){
            [timeSetDisplay setStringValue:@""];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cellLingNoGet:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        int timeGet = checkList [repairOperationTableCurrentRow*8];
        int lineageNoGet = checkList [repairOperationTableCurrentRow*8+2];
        int cellNoGet = checkList [repairOperationTableCurrentRow*8+3];
        int connectNoGet = checkList [repairOperationTableCurrentRow*8+4];
        
        if (lineageNoGet > 0) [lingNoSetDisplay setIntegerValue:lineageNoGet];
        if (cellNoGet != -1) [cellNoSetDisplay setIntegerValue:cellNoGet];
        if (connectNoGet > 0) [connectNoSetDisplay setIntegerValue:connectNoGet];
        if (timeGet > 0) [timeSetDisplay setIntegerValue:timeGet];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One On/Perform Verification/Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

//1:"Lineage:Line No//Xposition/Yposition/Time/Event/Parent-fusion partner cell no/Cell no/Lineage. no/Fusion-partner Lineage no";
//2:"PR:Line No//Xposition/Yposition/Average/Connect no/Cell no/Status/Lineage. no";
//3:"ST:Line No//Status/Zero/PR Starting/Zero/Zero/Zero/Zero/Zero/Connect no/Lineage. no";
//4:"GC:Line No//Xposition/Yposition/Total area/Average/Connect no/Target hit";
//5:"RL:Line No//Lineage no/Connect no/Time/Cell no/Target/Zero";
//6:"AD:Line No//Connect No/Process type/Cut type/Pair no/Cell dim/Zero";
//7:"Map:Line No//Connect No/Number of Pix";
//8:"Fluorescent-Line:Line No//Xposition/Yposition/connect no/CH no";
//9:"Fluorescent-Area:Line No//connect no/CH no/CH value/CH area";
//10:"Fluorescent-CutOff:Line No//Time/CH1 Cut/CH2 cut/CH3 cut";

-(IBAction)xyPositionShow:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (listArrayStatusHold == 1 || listArrayStatusHold == 2 || listArrayStatusHold == 4 || listArrayStatusHold == 8){
            int timeList = [timeSetDisplay integerValue];
            int connectList = [connectNoSetDisplay integerValue];
            
            string extractString = arrayListString [repairListTableCurrentRow].substr(arrayListString [repairListTableCurrentRow].find("//")+2);
            string xPositionString = extractString.substr(1, extractString.find("/")-1);
            extractString = extractString.substr(extractString.find("/")+1);
            string yPositionString = extractString.substr(1, extractString.find("/")-1);
            nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
            
            if (treatmentNameHold == nameStringRep){
                if (timeList > 0 && timeList <= imageEndHold){
                    xPositionVer = atoi(xPositionString.c_str());
                    yPositionVer = atoi(yPositionString.c_str());
                    imageNumberTrackForDisplay = timeList;
                    
                    if (connectList > 0) connectVer = connectList;
                    else connectVer = 0;
                    
                    verificationPositionCall = 1;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Time Range Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Treatment Name Mismatch"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No XY Data"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)listStringUpDate{
    string *arrayUpDate = new string [listStringCount+10];
    
    for (int counter1 = 0; counter1 < listStringCount; counter1++) arrayUpDate [counter1] = arrayListString [counter1];
    
    delete [] arrayListString;
    arrayListString = new string [listStringLimit+5000];
    listStringLimit = listStringLimit+5000;
    
    for (int counter1 = 0; counter1 < listStringCount; counter1++) arrayListString [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

@end
