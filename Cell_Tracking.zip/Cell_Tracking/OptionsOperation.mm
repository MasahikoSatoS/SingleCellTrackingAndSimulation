//
//  OptionsOperation.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2015-12-03.
//
//

#import "OptionsOperation.h"

NSString *notificationToOptionOperations = @"notificationExecuteOptionOperations";

@implementation OptionsOperation

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToOptionOperations object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [timeViewOperation setDataSource:self];
    [timeViewOperation reloadData];
    
    selectedTreatName = "All";
    [treatSelected setStringValue:@(selectedTreatName.c_str())];
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = treatmentStatusCount/9+1;
    
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    string trackName;
    string optionStatusString;
    string removeStatusString;
    string redoStatusString;
    string processStatusString;
    int statusFlag = 0;
    
    if (rowIndex == 0){
        trackName = "Treatment";
        optionStatusString = "Options";
        removeStatusString = "Remove";
        redoStatusString = "Re-do";
        processStatusString = "Status";
        statusFlag = 1;
    }
    else if (rowIndex > 0){
        trackName = arrayTreatmentStatus [(rowIndex-1)*9];
        int optionStatus = arrayOperationData [(rowIndex-1)*4];
        int removeStatus = arrayOperationData [(rowIndex-1)*4+1];
        int redoStatus = arrayOperationData [(rowIndex-1)*4+2];
        int processStatus = arrayOperationData [(rowIndex-1)*4+3];
        
        optionStatusString = "";
        
        if (optionStatus == 0) optionStatusString = "None";
        else if (optionStatus == 1) optionStatusString = "Auto";
        else if (optionStatus == 2) optionStatusString = "TLRmv";
        
        removeStatusString = "";
        
        if (removeStatus == 0) removeStatusString = "nil";
        else if (removeStatus == 1) removeStatusString = "Not Ready";
        else if (removeStatus == 2) removeStatusString = "Ready";
        else if (removeStatus == 5) removeStatusString = "Done";
        
        redoStatusString = "";
        
        if (redoStatus == 0) redoStatusString = "nil";
        else if (redoStatus == 1) redoStatusString = "Perform";
        else if (redoStatus == 2) redoStatusString = "Not Perform";
        else if (redoStatus == 3) redoStatusString = "Cancel";
        else if (redoStatus == 4) redoStatusString = "Done";
        
        processStatusString = "";
        
        if (processStatus == 1) processStatusString = "Allow";
        else if (processStatus == 2) processStatusString = "Not Allow";
        
        if (redoStatusString == "Not Allow") statusFlag = 2; //-----black----
        else if (optionStatusString == "None" || optionStatusString == "Auto") statusFlag = 4; //-----Purple-----
        else if (optionStatusString == "TLRmv" && removeStatusString == "Not Ready") statusFlag = 1; //-----Blue-----
        else if (optionStatusString == "TLRmv" && removeStatusString == "Ready") statusFlag = 3; //-----Red-----
        else statusFlag = 2; //-----Black-----
    }
    
    NSAttributedString *attrStr;
    
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
    
    if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusFlag == 1){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(trackName.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusFlag == 2){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(trackName.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusFlag == 3){
        [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(trackName.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusFlag == 4){
        [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(trackName.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusFlag == 1){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(optionStatusString.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusFlag == 2){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(optionStatusString.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusFlag == 3){
        [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(optionStatusString.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusFlag == 4){
        [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(optionStatusString.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusFlag == 1){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(removeStatusString.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusFlag == 2){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(removeStatusString.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusFlag == 3){
        [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(removeStatusString.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusFlag == 4){
        [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(removeStatusString.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL4"] && statusFlag == 1){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(redoStatusString.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL4"] && statusFlag == 2){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(redoStatusString.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL4"] && statusFlag == 3){
        [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(redoStatusString.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL4"] && statusFlag == 4){
        [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(redoStatusString.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL5"] && statusFlag == 1){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(processStatusString.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL5"] && statusFlag == 2){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(processStatusString.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL5"] && statusFlag == 3){
        [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(processStatusString.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL5"] && statusFlag == 4){
        [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(processStatusString.c_str()) attributes:attributes];
    }
    else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    tableCallOperationCount++;
    tableNewRowHoldOperation = rowIndex;
    
    if (tableCallOperationCount == 2){
        tableRowHoldOperation = rowIndex;
        
        if (tableRowHoldOperation != 0){
            selectedTreatName = arrayTreatmentStatus [(tableRowHoldOperation-1)*9];
            [treatSelected setStringValue:@(selectedTreatName.c_str())];
        }
        else [treatSelected setStringValue:@"All"];
    }
    else{
        
        tableRowHoldOperation = rowIndex;
        
        if (tableRowHoldOperation != 0){
            selectedTreatName = arrayTreatmentStatus [(rowIndex-1)*9];
            [treatSelected setStringValue:@(selectedTreatName.c_str())];
        }
        else [treatSelected setStringValue:@"All"];
    }
    
    return YES;
}

//**********Option operation array********
//1. Setting condition (0: None, 1:Auto, 2:TLRmv (remove))
//2. Remove Status (0: nil, 1:Not Ready, 2: Ready, 5. Done
//3. Redo Status (0: nil, 1:Proceed-redo, 2:Proceed (when this is set, remove TL when auto Processing starts), 3:Cancel, 4:Done)
//4. 1:Allow, 2:Not Allow

-(IBAction)autoSet:(id)sender{
    if (tableRowHoldOperation >= 1){
        if (arrayOperationData [(tableRowHoldOperation-1)*4+3] == 1 && arrayOperationData [(tableRowHoldOperation-1)*4+1] <= 1){
            arrayOperationData [(tableRowHoldOperation-1)*4] = 1;
            arrayOperationData [(tableRowHoldOperation-1)*4+1] = 1;
            arrayOperationData [(tableRowHoldOperation-1)*4+2] = 0;
            arrayOperationData [(tableRowHoldOperation-1)*4+3] = 1;
            
            string optionPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*Option.dat";
            
            ofstream oin;
            oin.open(optionPath.c_str(), ios::out);
            
            for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
                oin<<arrayOperationData [counter1*4]<<endl;
                oin<<arrayOperationData [counter1*4+1]<<endl;
                oin<<arrayOperationData [counter1*4+2]<<endl;
                oin<<arrayOperationData [counter1*4+3]<<endl;
            }
            
            oin<<"End"<<endl;
            oin.close();
            
            [timeViewOperation reloadData];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            if (arrayOperationData [counter1*4+3] == 1){
                arrayOperationData [counter1*4] = 1;
                arrayOperationData [counter1*4+1] = 1;
                arrayOperationData [counter1*4+2] = 0;
                arrayOperationData [counter1*4+3] = 1;
            }
        }
        
        string optionPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*Option.dat";
        
        ofstream oin;
        oin.open(optionPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            oin<<arrayOperationData [counter1*4]<<endl;
            oin<<arrayOperationData [counter1*4+1]<<endl;
            oin<<arrayOperationData [counter1*4+2]<<endl;
            oin<<arrayOperationData [counter1*4+3]<<endl;
        }
        
        oin<<"End"<<endl;
        oin.close();
        
        [timeViewOperation reloadData];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)removeTLSet:(id)sender{
    if (tableRowHoldOperation >= 1){
        if (arrayOperationData [(tableRowHoldOperation-1)*4+3] == 1 && arrayOperationData [(tableRowHoldOperation-1)*4+1] <= 1){
            arrayOperationData [(tableRowHoldOperation-1)*4] = 2;
            arrayOperationData [(tableRowHoldOperation-1)*4+1] = 1;
            arrayOperationData [(tableRowHoldOperation-1)*4+2] = 0;
            arrayOperationData [(tableRowHoldOperation-1)*4+3] = 1;
            
            string optionPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*Option.dat";
            
            ofstream oin;
            oin.open(optionPath.c_str(), ios::out);
            
            for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
                oin<<arrayOperationData [counter1*4]<<endl;
                oin<<arrayOperationData [counter1*4+1]<<endl;
                oin<<arrayOperationData [counter1*4+2]<<endl;
                oin<<arrayOperationData [counter1*4+3]<<endl;
            }
            
            oin<<"End"<<endl;
            oin.close();
            
            [timeViewOperation reloadData];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            if (arrayOperationData [counter1*4+3] == 1){
                arrayOperationData [counter1*4] = 2;
                arrayOperationData [counter1*4+1] = 1;
                arrayOperationData [counter1*4+2] = 0;
                arrayOperationData [counter1*4+3] = 1;
            }
        }
        
        string optionPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*Option.dat";
        
        ofstream oin;
        oin.open(optionPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            oin<<arrayOperationData [counter1*4]<<endl;
            oin<<arrayOperationData [counter1*4+1]<<endl;
            oin<<arrayOperationData [counter1*4+2]<<endl;
            oin<<arrayOperationData [counter1*4+3]<<endl;
        }
        
        oin<<"End"<<endl;
        oin.close();
        
        [timeViewOperation reloadData];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)noneSet:(id)sender{
    if (tableRowHoldOperation >= 1){
        if (arrayOperationData [(tableRowHoldOperation-1)*4+3] == 1 && arrayOperationData [(tableRowHoldOperation-1)*4+1] <= 1){
            arrayOperationData [(tableRowHoldOperation-1)*4] = 0;
            arrayOperationData [(tableRowHoldOperation-1)*4+1] = 0;
            arrayOperationData [(tableRowHoldOperation-1)*4+2] = 0;
            arrayOperationData [(tableRowHoldOperation-1)*4+3] = 1;
            
            string optionPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*Option.dat";
            
            ofstream oin;
            oin.open(optionPath.c_str(), ios::out);
            
            for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
                oin<<arrayOperationData [counter1*4]<<endl;
                oin<<arrayOperationData [counter1*4+1]<<endl;
                oin<<arrayOperationData [counter1*4+2]<<endl;
                oin<<arrayOperationData [counter1*4+3]<<endl;
            }
            
            oin<<"End"<<endl;
            oin.close();
            
            [timeViewOperation reloadData];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            if (arrayOperationData [counter1*4+3] == 1){
                arrayOperationData [counter1*4] = 0;
                arrayOperationData [counter1*4+1] = 0;
                arrayOperationData [counter1*4+2] = 0;
                arrayOperationData [counter1*4+3] = 1;
            }
        }
        
        string optionPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*Option.dat";
        
        ofstream oin;
        oin.open(optionPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            oin<<arrayOperationData [counter1*4]<<endl;
            oin<<arrayOperationData [counter1*4+1]<<endl;
            oin<<arrayOperationData [counter1*4+2]<<endl;
            oin<<arrayOperationData [counter1*4+3]<<endl;
        }
        
        oin<<"End"<<endl;
        oin.close();
        
        [timeViewOperation reloadData];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)removeTLRedoSet:(id)sender{
    if (tableRowHoldOperation >= 1){
        if (arrayOperationData [(tableRowHoldOperation-1)*4] == 2 && arrayOperationData [(tableRowHoldOperation-1)*4+3] == 1 && arrayOperationData [(tableRowHoldOperation-1)*4+1] == 2){
            arrayOperationData [(tableRowHoldOperation-1)*4+2] = 1;
            
            string optionPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*Option.dat";
            
            ofstream oin;
            oin.open(optionPath.c_str(), ios::out);
            
            for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
                oin<<arrayOperationData [counter1*4]<<endl;
                oin<<arrayOperationData [counter1*4+1]<<endl;
                oin<<arrayOperationData [counter1*4+2]<<endl;
                oin<<arrayOperationData [counter1*4+3]<<endl;
            }
            
            oin<<"End"<<endl;
            oin.close();
            
            //for (int counterA = 0; counterA < treatmentStatusCount/9; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayOperationData [counterA*4+counterB];
            //    cout<<" arrayOperationData "<<counterA<<endl;
            //}
            
            [timeViewOperation reloadData];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            if (arrayOperationData [counter1*4] == 2 && arrayOperationData [counter1*4+3] == 1 && arrayOperationData [counter1*4+1] == 2){
                arrayOperationData [counter1*4+2] = 1;
            }
        }
        
        string optionPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*Option.dat";
        
        ofstream oin;
        oin.open(optionPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            oin<<arrayOperationData [counter1*4]<<endl;
            oin<<arrayOperationData [counter1*4+1]<<endl;
            oin<<arrayOperationData [counter1*4+2]<<endl;
            oin<<arrayOperationData [counter1*4+3]<<endl;
        }
        
        oin<<"End"<<endl;
        oin.close();
        
        [timeViewOperation reloadData];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)proceedSet:(id)sender{
    if (tableRowHoldOperation >= 1){
        if (arrayOperationData [(tableRowHoldOperation-1)*4] == 2 && arrayOperationData [(tableRowHoldOperation-1)*4+3] == 1 && arrayOperationData [(tableRowHoldOperation-1)*4+1] == 2){
            arrayOperationData [(tableRowHoldOperation-1)*4+2] = 2;
            
            string optionPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*Option.dat";
            
            ofstream oin;
            oin.open(optionPath.c_str(), ios::out);
            
            for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
                oin<<arrayOperationData [counter1*4]<<endl;
                oin<<arrayOperationData [counter1*4+1]<<endl;
                oin<<arrayOperationData [counter1*4+2]<<endl;
                oin<<arrayOperationData [counter1*4+3]<<endl;
            }
            
            oin<<"End"<<endl;
            oin.close();
            
            [timeViewOperation reloadData];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            if (arrayOperationData [counter1*4] == 2 && arrayOperationData [counter1*4+3] == 1 && arrayOperationData [counter1*4+1] == 2){
                arrayOperationData [counter1*4+2] = 2;
            }
        }
        
        string optionPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*Option.dat";
        
        ofstream oin;
        oin.open(optionPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            oin<<arrayOperationData [counter1*4]<<endl;
            oin<<arrayOperationData [counter1*4+1]<<endl;
            oin<<arrayOperationData [counter1*4+2]<<endl;
            oin<<arrayOperationData [counter1*4+3]<<endl;
        }
        
        oin<<"End"<<endl;
        oin.close();
        
        [timeViewOperation reloadData];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)cancelSet:(id)sender{
    if (tableRowHoldOperation >= 1){
        if (arrayOperationData [(tableRowHoldOperation-1)*4] == 2 && arrayOperationData [(tableRowHoldOperation-1)*4+3] == 1 && arrayOperationData [(tableRowHoldOperation-1)*4+1] == 2){
            arrayOperationData [(tableRowHoldOperation-1)*4+2] = 3;
            
            string optionPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*Option.dat";
            
            ofstream oin;
            oin.open(optionPath.c_str(), ios::out);
            
            for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
                oin<<arrayOperationData [counter1*4]<<endl;
                oin<<arrayOperationData [counter1*4+1]<<endl;
                oin<<arrayOperationData [counter1*4+2]<<endl;
                oin<<arrayOperationData [counter1*4+3]<<endl;
            }
            
            oin<<"End"<<endl;
            oin.close();
            
            [timeViewOperation reloadData];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            if (arrayOperationData [counter1*4] == 2 && arrayOperationData [counter1*4+3] == 1 && arrayOperationData [counter1*4+1] == 2){
                arrayOperationData [counter1*4+2] = 3;
            }
        }
        
        string optionPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*Option.dat";
        
        ofstream oin;
        oin.open(optionPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            oin<<arrayOperationData [counter1*4]<<endl;
            oin<<arrayOperationData [counter1*4+1]<<endl;
            oin<<arrayOperationData [counter1*4+2]<<endl;
            oin<<arrayOperationData [counter1*4+3]<<endl;
        }
        
        oin<<"End"<<endl;
        oin.close();
        
        [timeViewOperation reloadData];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToOptionOperations object:nil];
}

@end
