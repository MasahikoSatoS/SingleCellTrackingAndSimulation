//
//  FluorescentQuantitationTable.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 3/12/17.
//
//

#import "FluorescentQuantitationTable.h"

NSString *notificationToFluorescentQuantitationTable = @"notificationExecutionFluorescentQuantitationTable";

@implementation FluorescentQuantitationTable

-(id)init{
    self = [super init];
    
    if (self != nil){
        fluorescentOperationTableCount = 0;
        rowfluorescentOperationTable = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToFluorescentQuantitationTable object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [fluorescentQuantOpTableControle setDataSource:self];
    [fluorescentQuantOpTableControle reloadData];
    
    for (NSTableColumn* column in [fluorescentQuantOpTableControle tableColumns]) {
        if ([[column identifier] isEqualToString:@"COL1"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Time" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL2"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Channel" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL3"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"No. Levels" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL4"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Merge" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
    }
    
    fluorescentQuantOpTableTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    //-----Table View for search-----
    if (fluorescentOperationTableCount == 1){
        fluorescentOperationTableCount = 0;
        rowfluorescentOperationTable = fluorescentOpOperationTableCurrentRow;
    }
    
    if (fluorescentOperationTableCount > 1) fluorescentOperationTableCount = 0;
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = 0;
    tableViewContent = fluorescentOpInformationCount/4;
    
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
    
    if (fluorescentOpInformationCount/4 > rowIndex){
        int statusFlag = 0;
        
        string entryNumber1 = to_string(fluorescentOpInformationHold [rowIndex*4]);
        string entryNumber2 = to_string(fluorescentOpInformationHold [rowIndex*4+1]);
        
        if (entryNumber2 == "9") entryNumber2 = "OR";
        
        string entryNumber3 = to_string(fluorescentOpInformationHold [rowIndex*4+2]);
        
        if (entryNumber3 == "9") entryNumber3 = "OR";
        
        string entryNumber4;
        if (fluorescentOpInformationHold [rowIndex*4+3] == 0) entryNumber4 = "-";
        else entryNumber4 = "M";
        
        if (fluorescentOpInformationHold [rowIndex*4+3] == 0) statusFlag = 0;
        else statusFlag = 1;
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusFlag == 0){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusFlag == 1){
            [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusFlag == 0){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusFlag == 1){
            [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusFlag == 0){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber3.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusFlag == 1){
            [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber3.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"] && statusFlag == 0){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber4.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"] && statusFlag == 1){
            [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber4.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    fluorescentOperationTableCount++;
    fluorescentOpOperationTableCurrentRow = rowIndex;
    
    if (fluorescentOperationTableCount == 2){
        fluorescentOpOperationTableCurrentRow = rowfluorescentOperationTable;
    }
    else fluorescentOpOperationTableCurrentRow = rowIndex;
    
    return YES;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToFluorescentQuantitationTable object:nil];
}

@end
