//
//  DataRepair2.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-05-28.
//

#import "DataRepair2.h"

@implementation DataRepair2

-(IBAction)dataRepair3:(id)sender{
    //-----Remove orphan from lineage data-----
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (checkList [repairOperationTableCurrentRow*8+2] != 0 && checkList [repairOperationTableCurrentRow*8+5] == 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert addButtonWithTitle:@"Cancel"];
            [alert setMessageText:@"Remove One Cell/Time, Use Delete Function or Fix Link To Remove All Progeny"];
            [alert setAlertStyle:NSAlertStyleWarning];
            
            if ([alert runModal] == NSAlertFirstButtonReturn){
                [self dataProcessRepair3];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)dataProcessRepair3{
    nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
    string revisedMapPath;
    string connectStatusDataPath;
    string connectRelationPath;
    string extension;
    
    int stepCount = 0;
    int finData [25];
    
    unsigned long readPosition = 0;
    
    lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+ analysisID+"_"+nameStringRep+"_LineageData";
    
    struct stat sizeOfFile;
    
    long sizeForCopy = 0;
    long size1 = 0;
    long size2 = 0;
    int checkFlag = 0;
    
    for (int counter4 = 0; counter4 < 6; counter4++){
        sizeForCopy = 0;
        
        if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (sizeForCopy != 0){
            if (counter4 == 0) size1 = sizeForCopy;
            else if (counter4 == 1) size2 = sizeForCopy;
            else if (counter4 == 2){
                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                    checkFlag = 1;
                    break;
                }
                else{
                    
                    size1 = 0;
                    size2 = 0;
                    usleep (50000);
                }
            }
            else if (counter4 == 3) size1 = sizeForCopy;
            else if (counter4 == 4) size2 = sizeForCopy;
            else if (counter4 == 5){
                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                    checkFlag = 1;
                }
            }
        }
    }
    
    int *arrayLineageRepairData2 = new int [sizeForCopy+50];
    int lineageDataRepairCount2 = 0;
    
    //-----Lineage data upload-----
    arrayLineageRepairData = new int [sizeForCopy+50];
    lineageDataRepairCount = 0;
    
    int returnValue2 = 0;
    
    if (checkFlag == 1){
        int processType2 = -1;
        
        dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
        returnValue2 = [dataRepairReadWrite lineageDataSetList:sizeForCopy:processType2];
    }
    
    if (returnValue2 == 0){
        ifstream fin;
        
        int timeStart = 0;
        int timeEnd = 0;
        
        for (int counter1 = 0; counter1 < lineageDataRepairCount/8; counter1++){
            if (arrayLineageRepairData [counter1*8+6] != checkList [repairOperationTableCurrentRow*8+2] || arrayLineageRepairData [counter1*8+5] != checkList [repairOperationTableCurrentRow*8+3]){
                arrayLineageRepairData2 [lineageDataRepairCount2] = arrayLineageRepairData [counter1*8], lineageDataRepairCount2++;
                arrayLineageRepairData2 [lineageDataRepairCount2] = arrayLineageRepairData [counter1*8+1], lineageDataRepairCount2++;
                arrayLineageRepairData2 [lineageDataRepairCount2] = arrayLineageRepairData [counter1*8+2], lineageDataRepairCount2++;
                arrayLineageRepairData2 [lineageDataRepairCount2] = arrayLineageRepairData [counter1*8+3], lineageDataRepairCount2++;
                arrayLineageRepairData2 [lineageDataRepairCount2] = arrayLineageRepairData [counter1*8+4], lineageDataRepairCount2++;
                arrayLineageRepairData2 [lineageDataRepairCount2] = arrayLineageRepairData [counter1*8+5], lineageDataRepairCount2++;
                arrayLineageRepairData2 [lineageDataRepairCount2] = arrayLineageRepairData [counter1*8+6], lineageDataRepairCount2++;
                arrayLineageRepairData2 [lineageDataRepairCount2] = arrayLineageRepairData [counter1*8+7], lineageDataRepairCount2++;
            }
            else{
                
                if (timeStart == 0){
                    timeStart = arrayLineageRepairData [counter1*8+2];
                    timeEnd = arrayLineageRepairData [counter1*8+2];
                }
                else timeEnd = arrayLineageRepairData [counter1*8+2];
            }
        }
        
        lineageDataRepairCount = 0;
        
        for (int counter1 = 0; counter1 < lineageDataRepairCount2; counter1++) arrayLineageRepairData [lineageDataRepairCount] = arrayLineageRepairData2 [counter1], lineageDataRepairCount++;
        
        //-----Lineage Data Save-----
        dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
        [dataRepairReadWrite lineageDataSave];
        
        string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+analysisID+"_"+nameStringRep+"_LineageStartEnd";
        
        sizeForCopy = 0;
        
        if (stat(connectStartEndPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        int *lineageStartEndTemp = new int [sizeForCopy+50];
        int lineageStartEndTempCount = 0;
        int lineageStartEndTempLimit = (int)sizeForCopy+50;
        
        if (sizeForCopy != 0){
            int cellNumberStart = -1;
            int lineageNumberStart = 0;
            int firstEntryFind = 0;
            
            for (int counter1 = 0; counter1 < lineageDataRepairCount2/8; counter1++){
                if ((arrayLineageRepairData2 [counter1*8+6] != lineageNumberStart || arrayLineageRepairData2 [counter1*8+5] != cellNumberStart) && firstEntryFind == 0){
                    lineageNumberStart = arrayLineageRepairData2 [counter1*8+6];
                    cellNumberStart = arrayLineageRepairData2 [counter1*8+5];
                    
                    lineageStartEndTemp [lineageStartEndTempCount] = lineageNumberStart, lineageStartEndTempCount++;
                    lineageStartEndTemp [lineageStartEndTempCount] = cellNumberStart, lineageStartEndTempCount++;
                    lineageStartEndTemp [lineageStartEndTempCount] = arrayLineageRepairData2 [counter1*8], lineageStartEndTempCount++;
                    lineageStartEndTemp [lineageStartEndTempCount] = arrayLineageRepairData2 [counter1*8+1], lineageStartEndTempCount++;
                    lineageStartEndTemp [lineageStartEndTempCount] = counter1, lineageStartEndTempCount++;
                    lineageStartEndTemp [lineageStartEndTempCount] = arrayLineageRepairData2 [counter1*8+2], lineageStartEndTempCount++;
                    
                    firstEntryFind = 1;
                }
                else if ((arrayLineageRepairData2 [counter1*8+6] != lineageNumberStart || arrayLineageRepairData2 [counter1*8+5] != cellNumberStart) && firstEntryFind == 1){
                    lineageNumberStart = arrayLineageRepairData2 [counter1*8+6];
                    cellNumberStart = arrayLineageRepairData2 [counter1*8+5];
                    
                    lineageStartEndTemp [lineageStartEndTempCount] = counter1-1, lineageStartEndTempCount++;
                    lineageStartEndTemp [lineageStartEndTempCount] = arrayLineageRepairData2 [(counter1-1)*8+2], lineageStartEndTempCount++;
                    lineageStartEndTemp [lineageStartEndTempCount] = lineageNumberStart, lineageStartEndTempCount++;
                    lineageStartEndTemp [lineageStartEndTempCount] = cellNumberStart, lineageStartEndTempCount++;
                    lineageStartEndTemp [lineageStartEndTempCount] = arrayLineageRepairData2 [counter1*8], lineageStartEndTempCount++;
                    lineageStartEndTemp [lineageStartEndTempCount] = arrayLineageRepairData2 [counter1*8+1], lineageStartEndTempCount++;
                    lineageStartEndTemp [lineageStartEndTempCount] = counter1, lineageStartEndTempCount++;
                    lineageStartEndTemp [lineageStartEndTempCount] = arrayLineageRepairData2 [counter1*8+2], lineageStartEndTempCount++;
                }
                
                if (counter1 == lineageDataRepairCount2/8-1){
                    lineageStartEndTemp [lineageStartEndTempCount] = counter1, lineageStartEndTempCount++;
                    lineageStartEndTemp [lineageStartEndTempCount] = arrayLineageRepairData2 [counter1*8+2], lineageStartEndTempCount++;
                }
                
                if (lineageStartEndTempCount+24 > lineageStartEndTempLimit){
                    int *arrayUpDate = new int [lineageStartEndTempCount+10];
                    
                    for (int counter2 = 0; counter2 < lineageStartEndTempCount; counter2++) arrayUpDate [counter2] = lineageStartEndTemp [counter2];
                    
                    delete [] lineageStartEndTemp;
                    lineageStartEndTemp = new int [lineageStartEndTempLimit+5000];
                    lineageStartEndTempLimit = lineageStartEndTempLimit+5000;
                    
                    for (int counter2 = 0; counter2 < lineageStartEndTempCount; counter2++) lineageStartEndTemp [counter2] = arrayUpDate [counter2];
                    delete [] arrayUpDate;
                }
            }
            
            //for (int counterA = 0; counterA < lineageStartEndAutoCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageStartEndAuto [counterA*8 +counterB];
            //    cout<<" lineageStartEndAuto "<<counterA<<endl;
            //}
            
            if (lineageStartEndTempCount != 0){
                char *mainDataEntry = new char [lineageStartEndTempCount*7+10];
                int totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < lineageStartEndTempCount; counter1++){
                    extension = to_string(lineageStartEndTemp [counter1]);
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile2 (connectStartEndPath.c_str(), ofstream::binary);
                outfile2.write (mainDataEntry, totalEntryCount);
                outfile2.close();
                
                delete [] mainDataEntry;
            }
        }
        
        //-----Master Rev and Status process-----
        string imagePositionString;
        int expandFluLineTempCount = 0;
        int expandFluAreaTempCount = 0;
        int expandFluLineTempCount2 = 0;
        int expandFluAreaTempCount2 = 0;
        int timeSelectedVerCount = 0;
        int connectLineageRelVerCount = 0;
        int entryCount = 0;
        int connectNoVer = 0;
        int connectNumberTemp = 0;
        int findFlag = 0;
        int masterDataLoadingErrorCheck = 0;
        int readingError = 0;
        
        for (int counter1 = timeStart; counter1 <= timeEnd; counter1++){
            imagePositionString = to_string(counter1);
            
            if (imagePositionString.length() == 1) imagePositionString = "000"+imagePositionString;
            else if (imagePositionString.length() == 2) imagePositionString = "00"+imagePositionString;
            else if (imagePositionString.length() == 3) imagePositionString = "0"+imagePositionString;
            
            masterDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+imagePositionString+"_"+analysisID+"_"+nameStringRep+"_MasterDataRevise";
            
            size1 = 0;
            size2 = 0;
            checkFlag = 0;
            
            for (int counter4 = 0; counter4 < 6; counter4++){
                sizeForCopy = 0;
                
                if (stat(masterDataRevPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter4 == 0) size1 = sizeForCopy;
                    else if (counter4 == 1) size2 = sizeForCopy;
                    else if (counter4 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter4 == 3) size1 = sizeForCopy;
                    else if (counter4 == 4) size2 = sizeForCopy;
                    else if (counter4 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            arrayPositionReviseVer = new int [sizeForCopy+50];
            positionReviseVerCount = 0;
            
            arrayGravityCenterVerRev = new int [sizeForCopy+50];
            gravityCenterRevVerCount = 0;
            
            arrayRepairDataHoldVerRev = new int [sizeForCopy+50];
            repairDataHoldVerCount = 0;
            
            returnValue2 = 0;
            
            if (checkFlag == 1){
                int processType2 = -1;
                int dataType = -1;
                
                dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                returnValue2 = [dataRepairReadWrite masterDataSetList:sizeForCopy:processType2:dataType];
            }
            
            if (returnValue2 == 0){
                //-----Master Data Status UpLoad-----
                connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+imagePositionString+"_"+analysisID+"_"+nameStringRep+"_Status";
                
                sizeForCopy = 0;
                
                if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                int *arrayTimeSelectedVer = new int [sizeForCopy+50];
                timeSelectedVerCount = 0;
                
                if (sizeForCopy != 0){
                    fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        readPosition = 0;
                        stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                                finData [7] = uploadTemp [readPosition], readPosition++;
                                finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                                finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                                finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                                finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                                finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                                finData [13] = uploadTemp [readPosition], readPosition++;
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                                finData [16] = uploadTemp [readPosition], readPosition++;
                                finData [17] = uploadTemp [readPosition], readPosition++;
                                finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                                
                                finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [8] = finData [7]*256+finData [8];
                                finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                                finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                                
                                if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                                else{
                                    
                                    arrayTimeSelectedVer [timeSelectedVerCount] = finData [0], timeSelectedVerCount++; //-----Selected, removed, eliminated status-----
                                    arrayTimeSelectedVer [timeSelectedVerCount] = finData [3], timeSelectedVerCount++; //-----When new line is created, enter line number which creates-----
                                    arrayTimeSelectedVer [timeSelectedVerCount] = finData [6], timeSelectedVerCount++; //-----PositionRevise Start-----
                                    arrayTimeSelectedVer [timeSelectedVerCount] = finData [8], timeSelectedVerCount++; //-----Cut line number-----
                                    arrayTimeSelectedVer [timeSelectedVerCount] = finData [9], timeSelectedVerCount++; //-----X Start-----
                                    arrayTimeSelectedVer [timeSelectedVerCount] = finData [10], timeSelectedVerCount++; //-----X End-----
                                    arrayTimeSelectedVer [timeSelectedVerCount] = finData [11], timeSelectedVerCount++; //-----Y Start-----
                                    arrayTimeSelectedVer [timeSelectedVerCount] = finData [12], timeSelectedVerCount++; //-----Y End-----
                                    arrayTimeSelectedVer [timeSelectedVerCount] = finData [15], timeSelectedVerCount++; //-----Connect-----
                                    arrayTimeSelectedVer [timeSelectedVerCount] = finData [18], timeSelectedVerCount++; //-----Lineage-----
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                    }
                }
                
                //    for (int counterA = 0; counterA < timeSelectedVerCount/10; counterA++){
                //        for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelectedVer [counterA*10+counterB];
                //        cout<<" arrayTimeSelectedVer "<<counterA<<endl;
                //    }
                
                connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+imagePositionString+"_"+analysisID+"_"+nameStringRep+"_ConnectLineageRel";
                
                sizeForCopy = 0;
                
                if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                int *arrayConnectLineageRelVer = new int [sizeForCopy+50];
                connectLineageRelVerCount = 0;
                
                if (sizeForCopy != 0){
                    fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        readPosition = 0;
                        stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                                finData [3] = uploadTemp [readPosition], readPosition++;
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                                finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                                finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                                finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                                finData [7] = finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                else{
                                    
                                    arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [2], connectLineageRelVerCount++;
                                    arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [5], connectLineageRelVerCount++;
                                    arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [7], connectLineageRelVerCount++;
                                    arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [12], connectLineageRelVerCount++;
                                    arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [13], connectLineageRelVerCount++;
                                    arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [14], connectLineageRelVerCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                    }
                }
                
                //-----Position revise process-----
                findFlag = 0;
                
                for (int counter2 = 0; counter2 < positionReviseVerCount/7; counter2++){
                    if (arrayPositionReviseVer [counter2*7+4] == checkList [repairOperationTableCurrentRow*8+3] && arrayPositionReviseVer [counter2*7+6] == checkList [repairOperationTableCurrentRow*8+2]){
                        findFlag = 1;
                        connectNoVer = arrayPositionReviseVer [counter2*7+3];
                        break;
                    }
                }
                
                if (connectNoVer != 0){
                    if (findFlag == 1){
                        for (int counter2 = 0; counter2 < positionReviseVerCount/7; counter2++){
                            if (arrayPositionReviseVer [counter2*7+4] == checkList [repairOperationTableCurrentRow*8+3] && arrayPositionReviseVer [counter2*7+6] == checkList [repairOperationTableCurrentRow*8+2]){
                                arrayPositionReviseVer [counter2*7+4] = 0;
                                arrayPositionReviseVer [counter2*7+5] = 0;
                                arrayPositionReviseVer [counter2*7+6] = 0;
                            }
                        }
                        
                        dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                        [dataRepairReadWrite masterDataSave];
                    }
                    
                    //-----RE process-----
                    findFlag = 0;
                    
                    for (int counter2 = 0; counter2 < connectLineageRelVerCount/6; counter2++){
                        if (arrayConnectLineageRelVer [counter2*6+1] == connectNoVer){
                            findFlag = 1;
                            break;
                        }
                    }
                    
                    if (findFlag == 1){
                        entryCount = 0;
                        
                        int *arrayConnectLineageRelVerTemp = new int [connectLineageRelVerCount+50];
                        
                        for (int counter2 = 0; counter2 < connectLineageRelVerCount/6; counter2++){
                            if (arrayConnectLineageRelVer [counter2*6+1] != connectNoVer){
                                arrayConnectLineageRelVerTemp [entryCount] = arrayConnectLineageRelVer [counter2*6], entryCount++;
                                arrayConnectLineageRelVerTemp [entryCount] = arrayConnectLineageRelVer [counter2*6+1], entryCount++;
                                arrayConnectLineageRelVerTemp [entryCount] = arrayConnectLineageRelVer [counter2*6+2], entryCount++;
                                arrayConnectLineageRelVerTemp [entryCount] = arrayConnectLineageRelVer [counter2*6+3], entryCount++;
                                arrayConnectLineageRelVerTemp [entryCount] = arrayConnectLineageRelVer [counter2*6+4], entryCount++;
                                arrayConnectLineageRelVerTemp [entryCount] = arrayConnectLineageRelVer [counter2*6+5], entryCount++;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < entryCount/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRelVerTemp [counterA*6+counterB];
                        //    cout<<" arrayConnectLineageRelVerTemp "<<counterA<<endl;
                        //}
                        
                        if (entryCount != 0){
                            char *writingArray = new char [entryCount/6*16+16];
                            
                            int indexCount = 0;
                            int readBit [4];
                            int dataTemp = 0;
                            
                            for (int counter2 = 0; counter2 < entryCount/6; counter2++){
                                dataTemp = arrayConnectLineageRelVerTemp [counter2*6];
                                readBit [0] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [1] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [2] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                
                                dataTemp = arrayConnectLineageRelVerTemp [counter2*6+1];
                                readBit [0] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [1] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [2] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                
                                dataTemp = arrayConnectLineageRelVerTemp [counter2*6+2];
                                readBit [0] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [1] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                
                                if (arrayConnectLineageRelVerTemp [counter2*6+3] < 0){
                                    writingArray [indexCount] = 1, indexCount++;
                                    dataTemp = arrayConnectLineageRelVerTemp [counter2*6+3]*-1;
                                }
                                else{
                                    
                                    writingArray [indexCount] = 0, indexCount++;
                                    dataTemp = arrayConnectLineageRelVerTemp [counter2*6+3];
                                }
                                
                                readBit [0] = dataTemp/16777216;
                                dataTemp = dataTemp%16777216;
                                readBit [1] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [2] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [3] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                writingArray [indexCount] = (char)readBit [3], indexCount++;
                                
                                writingArray [indexCount] = 0, indexCount++;
                                
                                writingArray [indexCount] = (char)arrayConnectLineageRelVerTemp [counter2*6+5], indexCount++;
                            }
                            
                            for (int counter2 = 0; counter2 < 15; counter2++) writingArray [indexCount] = 0, indexCount++;
                            
                            ofstream outfile2 (connectRelationPath.c_str(), ofstream::binary);
                            outfile2.write ((char*) writingArray, indexCount);
                            outfile2.close();
                            
                            delete [] writingArray;
                        }
                        
                        delete [] arrayConnectLineageRelVerTemp;
                    }
                    
                    //-----Status process-----
                    findFlag = 0;
                    
                    for (int counter2 = 0; counter2 < timeSelectedVerCount/6; counter2++){
                        if (arrayTimeSelectedVer [counter2*10+9] == checkList [repairOperationTableCurrentRow*8+2] && arrayTimeSelectedVer [counter2*10+8] == connectNoVer){
                            findFlag = 1;
                            break;
                        }
                    }
                    
                    if (findFlag == 1){
                        for (int counter2 = 0; counter2 < timeSelectedVerCount/6; counter2++){
                            if (arrayTimeSelectedVer [counter2*10+9] == checkList [repairOperationTableCurrentRow*8+2] && arrayTimeSelectedVer [counter2*10+8] == connectNoVer){
                                arrayTimeSelectedVer [counter2*10] = 0;
                                arrayTimeSelectedVer [counter2*10+9] = 0;
                                break;
                            }
                        }
                    }
                    
                    if (findFlag == 1){
                        int indexCount = 0;
                        int readBit [4];
                        int dataTemp = 0;
                        
                        char *writingArray = new char [timeSelectedVerCount/10*19+20];
                        
                        for (int counter3 = 0; counter3 < timeSelectedVerCount/10; counter3++){
                            writingArray [indexCount] = (char)arrayTimeSelectedVer [counter3*10], indexCount++;
                            writingArray [indexCount] = 0, indexCount++;
                            writingArray [indexCount] = 0, indexCount++;
                            writingArray [indexCount] = 0, indexCount++;
                            
                            dataTemp = arrayTimeSelectedVer [counter3*10+2];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            writingArray [indexCount] = 0, indexCount++;
                            writingArray [indexCount] = 0, indexCount++;
                            
                            writingArray [indexCount] = (char)arrayTimeSelectedVer [counter3*10+4], indexCount++;
                            writingArray [indexCount] = (char)arrayTimeSelectedVer [counter3*10+5], indexCount++;
                            writingArray [indexCount] = (char)arrayTimeSelectedVer [counter3*10+6], indexCount++;
                            writingArray [indexCount] = (char)arrayTimeSelectedVer [counter3*10+7], indexCount++;
                            
                            dataTemp = arrayTimeSelectedVer [counter3*10+8];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            if (arrayTimeSelectedVer [counter3*10] == 3 || arrayTimeSelectedVer [counter3*10] == 4) connectNumberTemp = 0;
                            else connectNumberTemp = arrayTimeSelectedVer [counter3*10+9];
                            
                            dataTemp = connectNumberTemp;
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                        }
                        
                        for (int counter3 = 0; counter3 < 19; counter3++) writingArray [indexCount] = 0, indexCount++;
                        
                        ofstream outfile2 (connectStatusDataPath.c_str(), ofstream::binary);
                        outfile2.write ((char*) writingArray, indexCount);
                        outfile2.close();
                        
                        delete [] writingArray;
                    }
                    
                    //for (int counterA = 0; counterA < modifyDataTempCount2/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<modifyDataTemp2 [counterA*6+counterB];
                    //    cout<<" modifyDataTemp2 "<<counterA<<endl;
                    //}
                    
                    //-----Fluorescent deletion-----
                    connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+imagePositionString+"_"+analysisID+"_"+nameStringRep+"_ExtendLineData";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter4 = 0; counter4 < 6; counter4++){
                        sizeForCopy = 0;
                        
                        if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter4 == 0) size1 = sizeForCopy;
                            else if (counter4 == 1) size2 = sizeForCopy;
                            else if (counter4 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter4 == 3) size1 = sizeForCopy;
                            else if (counter4 == 4) size2 = sizeForCopy;
                            else if (counter4 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    if (checkFlag == 1){
                        int *arrayExpandFluorescentLineTemp = new int [sizeForCopy+50];
                        expandFluLineTempCount = 0;
                        
                        readingError = 0;
                        
                        fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                        readingError = 1;
                                    }
                                }
                            }
                            
                            fin.close();
                            
                            if (readingError == 0){
                                readPosition = 0;
                                stepCount = 0;
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                                        finData [2] = uploadTemp [readPosition], readPosition++;
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                                        finData [4] = uploadTemp [readPosition], readPosition++;
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                        
                                        finData [1] = finData [0]*256+finData [1];
                                        finData [3] = finData [2]*256+finData [3];
                                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                        
                                        if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                        else{
                                            
                                            arrayExpandFluorescentLineTemp [expandFluLineTempCount] = finData [1], expandFluLineTempCount++;
                                            arrayExpandFluorescentLineTemp [expandFluLineTempCount] = finData [3], expandFluLineTempCount++;
                                            arrayExpandFluorescentLineTemp [expandFluLineTempCount] = finData [6], expandFluLineTempCount++;
                                            arrayExpandFluorescentLineTemp [expandFluLineTempCount] = finData [7], expandFluLineTempCount++;
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                            }
                            
                            delete [] uploadTemp;
                        }
                        
                        if (checkFlag == 1 && readingError == 0){
                            int *arrayExpandFluorescentLineTemp2 = new int [sizeForCopy+50];
                            expandFluLineTempCount2 = 0;
                            
                            for (int counter2 = 0; counter2 < expandFluLineTempCount/4; counter2++){
                                if (arrayExpandFluorescentLineTemp [counter2*4+2] != connectNoVer){
                                    arrayExpandFluorescentLineTemp2 [expandFluLineTempCount2] = arrayExpandFluorescentLineTemp [counter2*4], expandFluLineTempCount2++;
                                    arrayExpandFluorescentLineTemp2 [expandFluLineTempCount2] = arrayExpandFluorescentLineTemp [counter2*4+1], expandFluLineTempCount2++;
                                    arrayExpandFluorescentLineTemp2 [expandFluLineTempCount2] = arrayExpandFluorescentLineTemp [counter2*4+2], expandFluLineTempCount2++;
                                    arrayExpandFluorescentLineTemp2 [expandFluLineTempCount2] = arrayExpandFluorescentLineTemp [counter2*4+3], expandFluLineTempCount2++;
                                }
                            }
                            
                            if (expandFluLineTempCount2 != 0){
                                int indexCount = 0;
                                int readBit [4];
                                int dataTemp = 0;
                                
                                char *writingArray = new char [expandFluLineTempCount2*2+200];
                                
                                for (int counter2 = 0; counter2 < expandFluLineTempCount2/4; counter2++){
                                    dataTemp = arrayExpandFluorescentLineTemp2 [counter2*4];
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    dataTemp = arrayExpandFluorescentLineTemp2 [counter2*4+1];
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    dataTemp = arrayExpandFluorescentLineTemp2 [counter2*4+2];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)arrayExpandFluorescentLineTemp2 [counter2*4+3], indexCount++;
                                }
                                
                                for (int counter2 = 0; counter2 < 8; counter2++) writingArray [indexCount] = 0, indexCount++;
                                
                                ofstream outfile3 (connectRelationPath.c_str(), ofstream::binary);
                                outfile3.write ((char*)writingArray, indexCount);
                                outfile3.close();
                                
                                delete [] writingArray;
                            }
                            else remove(connectRelationPath.c_str());
                            
                            delete [] arrayExpandFluorescentLineTemp2;
                        }
                        
                        delete [] arrayExpandFluorescentLineTemp;
                        
                        connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+imagePositionString+"_"+analysisID+"_"+nameStringRep+"_ExtendAreaData";
                        
                        sizeForCopy = 0;
                        
                        if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            int *arrayExpandFluorescentAreaTemp = new int [sizeForCopy+50];
                            expandFluAreaTempCount = 0;
                            
                            fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                readPosition = 0;
                                stepCount = 0;
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++;
                                        finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                        finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                                        
                                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                        
                                        if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                        else{
                                            
                                            arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = finData [2], expandFluAreaTempCount++;
                                            arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = finData [3], expandFluAreaTempCount++;
                                            arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = finData [4], expandFluAreaTempCount++;
                                            arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = finData [7], expandFluAreaTempCount++;
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                                
                                delete [] uploadTemp;
                            }
                            
                            int *arrayExpandFluorescentAreaTemp2 = new int [expandFluAreaTempCount+50];
                            expandFluAreaTempCount2 = 0;
                            
                            for (int counter2 = 0; counter2 < expandFluAreaTempCount/4; counter2++){
                                if (arrayExpandFluorescentAreaTemp [counter2*4] != connectNoVer){
                                    arrayExpandFluorescentAreaTemp2 [expandFluAreaTempCount2] = arrayExpandFluorescentAreaTemp [counter2*4], expandFluAreaTempCount2++;
                                    arrayExpandFluorescentAreaTemp2 [expandFluAreaTempCount2] = arrayExpandFluorescentAreaTemp [counter2*4+1], expandFluAreaTempCount2++;
                                    arrayExpandFluorescentAreaTemp2 [expandFluAreaTempCount2] = arrayExpandFluorescentAreaTemp [counter2*4+2], expandFluAreaTempCount2++;
                                    arrayExpandFluorescentAreaTemp2 [expandFluAreaTempCount2] = arrayExpandFluorescentAreaTemp [counter2*4+3], expandFluAreaTempCount2++;
                                }
                            }
                            
                            delete [] arrayExpandFluorescentAreaTemp;
                            
                            if (expandFluAreaTempCount2 != 0){
                                int indexCount = 0;
                                int readBit [4];
                                int dataTemp = 0;
                                
                                char *writingArray = new char [expandFluAreaTempCount2*2+20];
                                
                                for (int counter2 = 0; counter2 < expandFluAreaTempCount2/4; counter2++){
                                    dataTemp = arrayExpandFluorescentAreaTemp2 [counter2*4];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)arrayExpandFluorescentAreaTemp2 [counter2*4+1], indexCount++;
                                    writingArray [indexCount] = (char)arrayExpandFluorescentAreaTemp2 [counter2*4+2], indexCount++;
                                    
                                    dataTemp = arrayExpandFluorescentAreaTemp2 [counter2*4+3];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                }
                                
                                for (int counter2 = 0; counter2 < 8; counter2++) writingArray [indexCount] = 0, indexCount++;
                                
                                ofstream outfile3 (connectRelationPath.c_str(), ofstream::binary);
                                outfile3.write ((char*)writingArray, indexCount);
                                outfile3.close();
                                
                                delete [] writingArray;
                            }
                            else remove(connectRelationPath.c_str());
                            
                            delete [] arrayExpandFluorescentAreaTemp2;
                        }
                    }
                }
                
                delete [] arrayTimeSelectedVer;
                delete [] arrayConnectLineageRelVer;
            }
            
            delete [] arrayPositionReviseVer;
            delete [] arrayGravityCenterVerRev;
            delete [] arrayRepairDataHoldVerRev;
            
            if (returnValue2 == -1){
                
                masterDataLoadingErrorCheck = 1;
                break;
            }
        }
        
        //=========Queue List creation==========
        //for (int counterA = 0; counterA < queueListCount/6; counterA++){
        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
        //    cout<<" arrayQueueList "<<counterA<<endl;
        //}
        
        if (masterDataLoadingErrorCheck == 0){
            
            string cellLineageString = to_string(checkList [repairOperationTableCurrentRow*8+2]);
            
            if (cellLineageString.length() == 1) cellLineageString = "L0000"+cellLineageString;
            else if (cellLineageString.length() == 2) cellLineageString = "L000"+cellLineageString;
            else if (cellLineageString.length() == 3) cellLineageString = "L00"+cellLineageString;
            else if (cellLineageString.length() == 4) cellLineageString = "L0"+cellLineageString;
            else if (cellLineageString.length() == 5) cellLineageString = "L"+cellLineageString;
            
            string cellNumberString = to_string(checkList [repairOperationTableCurrentRow*8+3]);
            
            if (checkList [repairOperationTableCurrentRow*8+3] >= 0){
                if (cellNumberString.length() == 1) cellNumberString = "C00000000"+cellNumberString;
                else if (cellNumberString.length() == 2) cellNumberString = "C0000000"+cellNumberString;
                else if (cellNumberString.length() == 3) cellNumberString = "C000000"+cellNumberString;
                else if (cellNumberString.length() == 4) cellNumberString = "C00000"+cellNumberString;
                else if (cellNumberString.length() == 5) cellNumberString = "C0000"+cellNumberString;
                else if (cellNumberString.length() == 6) cellNumberString = "C000"+cellNumberString;
                else if (cellNumberString.length() == 7) cellNumberString = "C00"+cellNumberString;
                else if (cellNumberString.length() == 8) cellNumberString = "C0"+cellNumberString;
                else if (cellNumberString.length() == 9) cellNumberString = "C"+cellNumberString;
            }
            else{
                
                cellNumberString = cellNumberString.substr(1);
                
                if (cellNumberString.length() == 1) cellNumberString = "C-00000000"+cellNumberString;
                else if (cellNumberString.length() == 2) cellNumberString = "C-0000000"+cellNumberString;
                else if (cellNumberString.length() == 3) cellNumberString = "C-000000"+cellNumberString;
                else if (cellNumberString.length() == 4) cellNumberString = "C-00000"+cellNumberString;
                else if (cellNumberString.length() == 5) cellNumberString = "C-0000"+cellNumberString;
                else if (cellNumberString.length() == 6) cellNumberString = "C-000"+cellNumberString;
                else if (cellNumberString.length() == 7) cellNumberString = "C-00"+cellNumberString;
                else if (cellNumberString.length() == 8) cellNumberString = "C-0"+cellNumberString;
                else if (cellNumberString.length() == 9) cellNumberString = "C-"+cellNumberString;
            }
            
            string *modifyDataStringTemp = new string [queueListCount+50];
            int modifyDataStringTempCount = 0;
            
            for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                if (arrayQueueList [counter1*6] != nameStringRep || arrayQueueList [counter1*6+1] != cellLineageString || arrayQueueList [counter1*6+2] != cellNumberString){
                    modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6], modifyDataStringTempCount++;
                    modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6+1], modifyDataStringTempCount++;
                    modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6+2], modifyDataStringTempCount++;
                    modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6+3], modifyDataStringTempCount++;
                    modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6+4], modifyDataStringTempCount++;
                    modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6+5], modifyDataStringTempCount++;
                }
            }
            
            queueListCount = 0;
            
            for (int counter1 = 0; counter1 < modifyDataStringTempCount; counter1++) arrayQueueList [queueListCount] = modifyDataStringTemp [counter1], queueListCount++;
            
            string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
            
            if (queueListCount != 0){
                char *mainDataEntry = new char [queueListCount*12+10];
                int totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < queueListCount; counter1++){
                    extension = arrayQueueList [counter1];
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile3 (queueListPath.c_str(), ofstream::binary);
                outfile3.write (mainDataEntry, totalEntryCount);
                outfile3.close();
                
                delete [] mainDataEntry;
            }
            
            //for (int counterA = 0; counterA < queueListCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
            //    cout<<" arrayQueueList "<<counterA<<endl;
            //}
            
            delete [] modifyDataStringTemp;
            
            //for (int counterA = 0; counterA < doneListCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
            //    cout<<" arrayDoneList "<<counterA<<endl;
            //}
            
            //=========Done List UpDate==========
            //-----1. Treatment name, 2. Lineage No, 3. Cell number/Whole image, 4. Image number, 5. Check status-----
            //-----Check Status: OK, LST, CFU, CDD, CTD, CHD, UN-----
            
            modifyDataStringTemp = new string [doneListCount+50];
            modifyDataStringTempCount = 0;
            
            for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                if (arrayDoneList [counter1*5] != nameStringRep || arrayDoneList [counter1*5+1] != cellLineageString || arrayDoneList [counter1*5+2] != cellNumberString){
                    modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter1*5], modifyDataStringTempCount++;
                    modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter1*5+1], modifyDataStringTempCount++;
                    modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter1*5+2], modifyDataStringTempCount++;
                    modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter1*5+3], modifyDataStringTempCount++;
                    modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter1*5+4], modifyDataStringTempCount++;
                }
            }
            
            doneListCount = 0;
            for (int counter1 = 0; counter1 < modifyDataStringTempCount; counter1++) arrayDoneList [doneListCount] = modifyDataStringTemp [counter1], doneListCount++;
            
            string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
            
            if (doneListCount != 0){
                char *mainDataEntry = new char [doneListCount*10+10];
                int totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < doneListCount; counter1++){
                    extension = arrayDoneList [counter1];
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile5 (doneListPath.c_str(), ofstream::binary);
                outfile5.write (mainDataEntry, totalEntryCount);
                outfile5.close();
                
                delete [] mainDataEntry;
            }
            
            delete [] modifyDataStringTemp;
            
            string lineageFolderPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Treat/"+cellLineageString+"/"+analysisID+"_"+cellLineageString+"_CellStatus";
            
            sizeForCopy = 0;
            
            if (stat(lineageFolderPath2.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            int *masterReadForCellInfo = new int [sizeForCopy+50];
            int masterReadForCellInfoCount = 0;
            int *masterReadForCellInfo2 = new int [sizeForCopy+50];
            int masterReadForCellInfoCount2 = 0;
            
            if (sizeForCopy != 0){
                fin.open(lineageFolderPath2.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    char *uploadTemp = new char [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    string dataString = "";
                    readPosition = 0;
                    
                    do{
                        
                        if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                        else if (dataString != "End"){
                            masterReadForCellInfo [masterReadForCellInfoCount] = atoi(dataString.c_str()), masterReadForCellInfoCount++;
                            dataString = "";
                        }
                        
                        readPosition++;
                        
                    } while (dataString != "End");
                    
                    delete [] uploadTemp;
                }
            }
            
            for (int counter1 = 0; counter1 < masterReadForCellInfoCount/7; counter1++){
                if (masterReadForCellInfo [counter1*7] != checkList [repairOperationTableCurrentRow*8+3]){
                    masterReadForCellInfo2 [masterReadForCellInfoCount2] = masterReadForCellInfo [counter1*7], masterReadForCellInfoCount2++;
                    masterReadForCellInfo2 [masterReadForCellInfoCount2] = masterReadForCellInfo [counter1*7+1], masterReadForCellInfoCount2++;
                    masterReadForCellInfo2 [masterReadForCellInfoCount2] = masterReadForCellInfo [counter1*7+2], masterReadForCellInfoCount2++;
                    masterReadForCellInfo2 [masterReadForCellInfoCount2] = masterReadForCellInfo [counter1*7+3], masterReadForCellInfoCount2++;
                    masterReadForCellInfo2 [masterReadForCellInfoCount2] = masterReadForCellInfo [counter1*7+4], masterReadForCellInfoCount2++;
                    masterReadForCellInfo2 [masterReadForCellInfoCount2] = masterReadForCellInfo [counter1*7+5], masterReadForCellInfoCount2++;
                    masterReadForCellInfo2 [masterReadForCellInfoCount2] = masterReadForCellInfo [counter1*7+6], masterReadForCellInfoCount2++;
                }
            }
            
            char *mainDataEntry = new char [masterReadForCellInfoCount2*7+10];
            int totalEntryCount = 0;
            
            for (int counter1 = 0; counter1 < masterReadForCellInfoCount2; counter1++){
                extension = to_string(masterReadForCellInfo2 [counter1]);
                
                for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
            }
            
            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
            
            ofstream outfile4 (lineageFolderPath2.c_str(), ofstream::binary);
            outfile4.write (mainDataEntry, totalEntryCount);
            outfile4.close();
            
            delete [] mainDataEntry;
            delete [] masterReadForCellInfo;
            delete [] masterReadForCellInfo2;
            
            string lineageFolderPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Treat/"+cellLineageString+"/"+cellNumberString;
            
            DIR *dir;
            struct dirent *dent;
            
            dir = opendir(lineageFolderPath.c_str());
            fileDeleteCount = 0;
            
            if (dir != NULL){
                string entry;
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (fileDeleteCount+5 > fileDeleteLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate fileDeleteUpDate];
                    }
                    
                    arrayFileDelete [fileDeleteCount] = lineageFolderPath+"/"+entry, fileDeleteCount++;
                }
                
                closedir(dir);
            }
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                remove (arrayFileDelete [counter1].c_str());
            }
            
            rmdir (lineageFolderPath.c_str());
            
            //=======Lineage partner line=======
            string cellFusionPartnerPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+analysisID+"_"+nameStringRep+"_FusionPartner";
            
            sizeForCopy = 0;
            
            if (stat(cellFusionPartnerPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (sizeForCopy != 0){
                string *arrayLineagePartnerInfoTemp = new string [sizeForCopy+50];
                int lineagePartnerInfoTempCount = 0;
                
                string *arrayLineagePartnerInfoTemp2 = new string [sizeForCopy+50];
                int lineagePartnerInfoTempCount2 = 0;
                
                fin.open(cellFusionPartnerPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    string treatmentNameGet;
                    string lineageNoGet;
                    string cellNoGet;
                    string imageNoGet;
                    string partnerLingNoGet;
                    string partnerCellNoGet;
                    
                    int terminationFlag = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        getline(fin, treatmentNameGet);
                        
                        if (treatmentNameGet == "") terminationFlag = 0;
                        else{
                            
                            getline(fin, lineageNoGet);
                            getline(fin, cellNoGet);
                            getline(fin, imageNoGet);
                            getline(fin, partnerLingNoGet);
                            getline(fin, partnerCellNoGet);
                            
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = treatmentNameGet, lineagePartnerInfoTempCount++;
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = lineageNoGet, lineagePartnerInfoTempCount++;
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = cellNoGet, lineagePartnerInfoTempCount++;
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = imageNoGet, lineagePartnerInfoTempCount++;
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = partnerLingNoGet, lineagePartnerInfoTempCount++;
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = partnerCellNoGet, lineagePartnerInfoTempCount++;
                        }
                        
                    } while (terminationFlag == 1);
                    
                    fin.close();
                }
                
                string lingNoTemp;
                string cellNoTemp;
                string imageNoTemp;
                
                for (int counter1 = 0; counter1 < lineageDataRepairCount2/8; counter1++){
                    if (arrayLineageRepairData2 [counter1*8+3] == 10){
                        for (int counter2 = 0; counter2 < lineagePartnerInfoTempCount/6; counter2++){
                            lingNoTemp = arrayLineagePartnerInfoTemp [counter2*6+1];
                            cellNoTemp = arrayLineagePartnerInfoTemp [counter2*6+2];
                            imageNoTemp = arrayLineagePartnerInfoTemp [counter2*6+3];
                            
                            if (arrayLineagePartnerInfoTemp [counter2*6] == nameStringRep && atoi(lingNoTemp.c_str()) == arrayLineageRepairData2 [counter1*8+6] && atoi(cellNoTemp.c_str()) == arrayLineageRepairData2 [counter1*8+5] && atoi(imageNoTemp.c_str()) == arrayLineageRepairData2 [counter1*8+2]){
                                arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6], lineagePartnerInfoTempCount2++;
                                arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6+1], lineagePartnerInfoTempCount2++;
                                arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6+2], lineagePartnerInfoTempCount2++;
                                arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6+3], lineagePartnerInfoTempCount2++;
                                arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6+4], lineagePartnerInfoTempCount2++;
                                arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6+5], lineagePartnerInfoTempCount2++;
                            }
                        }
                    }
                }
                
                if (lineagePartnerInfoTempCount2 != 0){
                    ofstream oin;
                    oin.open(cellFusionPartnerPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < lineagePartnerInfoTempCount2; counter1++) oin<<arrayLineagePartnerInfoTemp2 [counter1]<<endl;
                    
                    oin.close();
                }
                else remove (cellFusionPartnerPath.c_str());
                
                delete [] arrayLineagePartnerInfoTemp;
                delete [] arrayLineagePartnerInfoTemp2;
            }
            
            //=======Mitosis Set array=======
            string mitosisStatusPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+ analysisID+"_"+nameStringRep+"_MitosisData";
            
            size1 = 0;
            size2 = 0;
            checkFlag = 0;
            
            for (int counter4 = 0; counter4 < 6; counter4++){
                sizeForCopy = 0;
                
                if (stat(mitosisStatusPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter4 == 0) size1 = sizeForCopy;
                    else if (counter4 == 1) size2 = sizeForCopy;
                    else if (counter4 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter4 == 3) size1 = sizeForCopy;
                    else if (counter4 == 4) size2 = sizeForCopy;
                    else if (counter4 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            int *arrayMitosisTemp = new int [sizeForCopy+50];
            int mitosisTempCount = 0;
            int *arrayMitosisTemp2 = new int [sizeForCopy+50];
            int mitosisTempCount2 = 0;
            int *arrayMitosisTemp3 = new int [sizeForCopy+50];
            int mitosisTempCount3 = 0;
            
            if (checkFlag == 1){
                fin.open(mitosisStatusPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    string lineageNoGet;
                    string cellNoGet;
                    string imageNoGet;
                    string setTypeGet;
                    
                    int terminationFlag = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        getline(fin, lineageNoGet);
                        
                        if (lineageNoGet == "") terminationFlag = 0;
                        else{
                            
                            getline(fin, cellNoGet);
                            getline(fin, imageNoGet);
                            getline(fin, setTypeGet);
                            
                            arrayMitosisTemp [mitosisTempCount] = atoi(lineageNoGet.c_str()), mitosisTempCount++;
                            arrayMitosisTemp [mitosisTempCount] = atoi(cellNoGet.c_str()), mitosisTempCount++;
                            arrayMitosisTemp [mitosisTempCount] = atoi(imageNoGet.c_str()), mitosisTempCount++;
                            arrayMitosisTemp [mitosisTempCount] = atoi(setTypeGet.c_str()), mitosisTempCount++;
                        }
                        
                    } while (terminationFlag == 1);
                    
                    fin.close();
                }
            }
            
            int mitosisSetFind = 0;
            int lineageFirstPoint = 0;
            int lineageLastPoint = 0;
            
            for (int counter1 = 0; counter1 < lineageDataRepairCount2/8; counter1++){
                if (arrayLineageRepairData2 [counter1*8+6] == checkList [repairOperationTableCurrentRow*8+2] && arrayLineageRepairData2 [counter1*8+5] == checkList [repairOperationTableCurrentRow*8+3]){
                    if (arrayLineageRepairData2 [counter1*8+3] == 6) mitosisSetFind = arrayLineageRepairData2 [counter1*8+2];
                    if (lineageLastPoint < arrayLineageRepairData2 [counter1*8+2]) lineageLastPoint = arrayLineageRepairData2 [counter1*8+2];
                    if (lineageFirstPoint == 0) lineageFirstPoint = arrayLineageRepairData2 [counter1*8+2];
                }
            }
            
            for (int counter1 = 0; counter1 < mitosisTempCount/4; counter1++){
                if (arrayMitosisTemp [counter1*4] != checkList [repairOperationTableCurrentRow*8+2] || arrayMitosisTemp [counter1*4+1] != checkList [repairOperationTableCurrentRow*8+3]){
                    arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4], mitosisTempCount2++;
                    arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+1], mitosisTempCount2++;
                    arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+2], mitosisTempCount2++;
                    arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+3], mitosisTempCount2++;
                }
                else{
                    
                    arrayMitosisTemp3 [mitosisTempCount3] = arrayMitosisTemp [counter1*4], mitosisTempCount3++;
                    arrayMitosisTemp3 [mitosisTempCount3] = arrayMitosisTemp [counter1*4+1], mitosisTempCount3++;
                    arrayMitosisTemp3 [mitosisTempCount3] = arrayMitosisTemp [counter1*4+2], mitosisTempCount3++;
                    arrayMitosisTemp3 [mitosisTempCount3] = arrayMitosisTemp [counter1*4+3], mitosisTempCount3++;
                }
            }
            
            int *arrayMitosisTemp4 = new int [(lineageLastPoint-lineageFirstPoint+1)*4+50];
            int mitosisTempCount4 = 0;
            
            for (int counter1 = lineageFirstPoint; counter1 <= lineageLastPoint; counter1++){
                arrayMitosisTemp4 [mitosisTempCount4] = checkList [repairOperationTableCurrentRow*8+2], mitosisTempCount4++;
                arrayMitosisTemp4 [mitosisTempCount4] = checkList [repairOperationTableCurrentRow*8+3], mitosisTempCount4++;
                arrayMitosisTemp4 [mitosisTempCount4] = counter1, mitosisTempCount4++;
                
                if (mitosisSetFind != 0 && mitosisSetFind == counter1) arrayMitosisTemp4 [mitosisTempCount4] = 10, mitosisTempCount4++;
                else arrayMitosisTemp4 [mitosisTempCount4] = 0, mitosisTempCount4++;
            }
            
            if (mitosisSetFind == 0){
                int prevFirstPoint = 0;
                int prevLastPoint = 0;
                
                for (int counter1 = 0; counter1 < mitosisTempCount3/4; counter1++){
                    if (prevFirstPoint == 0) prevFirstPoint = arrayMitosisTemp3 [counter1*4+2];
                    
                    prevLastPoint = arrayMitosisTemp3 [counter1*4+2];
                }
                
                if (prevFirstPoint < lineageFirstPoint) prevFirstPoint = lineageFirstPoint;
                if (prevLastPoint > lineageLastPoint) prevLastPoint = lineageLastPoint;
                
                if (prevFirstPoint > lineageLastPoint || prevLastPoint < lineageFirstPoint) prevFirstPoint = 0;
                
                if (prevFirstPoint != 0){
                    int prevFind = 0;
                    int prevCount = 0;
                    
                    for (int counter1 = 0; counter1 < mitosisTempCount4/4; counter1++){
                        if (prevLastPoint > prevFirstPoint){
                            if (arrayMitosisTemp4 [counter1*4+2] == prevFirstPoint){
                                if (arrayMitosisTemp3 [prevCount*4+3] == 10) arrayMitosisTemp3 [prevCount*4+3] = 0;
                                
                                arrayMitosisTemp4 [counter1*4+3] = arrayMitosisTemp3 [prevCount*4+3];
                                prevFind = 1;
                                prevCount++;
                            }
                            else if (arrayMitosisTemp4 [counter1*4+2] == prevLastPoint){
                                if (arrayMitosisTemp3 [prevCount*4+3] == 10) arrayMitosisTemp3 [prevCount*4+3] = 0;
                                
                                arrayMitosisTemp4 [counter1*4+3] = arrayMitosisTemp3 [prevCount*4+3];
                                prevFind = 0;
                            }
                            else if (prevFind == 1){
                                if (arrayMitosisTemp3 [prevCount*4+3] == 10) arrayMitosisTemp3 [prevCount*4+3] = 0;
                                
                                arrayMitosisTemp4 [counter1*4+3] = arrayMitosisTemp3 [prevCount*4+3];
                                prevCount++;
                            }
                        }
                        
                        if (arrayMitosisTemp4 [counter1*4] == prevFirstPoint && prevLastPoint == prevFirstPoint){
                            if (arrayMitosisTemp3 [prevCount*4+3] == 10) arrayMitosisTemp3 [prevCount*4+3] = 0;
                            
                            arrayMitosisTemp4 [counter1*4+3] = arrayMitosisTemp3 [prevCount*4+3];
                        }
                    }
                }
                
                ofstream oin;
                oin.open(mitosisStatusPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < mitosisTempCount2; counter1++) oin<<arrayMitosisTemp2 [counter1]<<endl;
                for (int counter1 = 0; counter1 < mitosisTempCount4; counter1++) oin<<arrayMitosisTemp4 [counter1]<<endl;
                
                oin.close();
            }
            
            delete [] arrayMitosisTemp;
            delete [] arrayMitosisTemp2;
            delete [] arrayMitosisTemp3;
            delete [] arrayMitosisTemp4;
            
            if (nameStringRep == treatmentNameHold){
                lineageDataCount = 0;
                
                for (int counter1 = 0; counter1 < lineageDataRepairCount2; counter1++) arrayLineageData [lineageDataCount] = arrayLineageRepairData2 [counter1], lineageDataCount++;
                
                lineageStartEndCount = 0;
                
                for (int counter1 = 0; counter1 < lineageStartEndTempCount; counter1++)  arrayLineageStartEnd [lineageStartEndCount] = lineageStartEndTemp [counter1], lineageStartEndCount++;
            }
            
            dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
            [dataRepairReadWrite lineageRelDataSet];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Master Data Read Error"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        
        delete [] lineageStartEndTemp;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Read Error"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    
    delete [] arrayLineageRepairData;
    delete [] arrayLineageRepairData2;
}

-(IBAction)dataRepair4:(id)sender{
    //-----Find end of cell Lineage, then if amend line is mission, create-----
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0){
        int returnStatus = 0;
        
        dataRepairProcess = [[DataRepairProcess alloc] init];
        returnStatus = [dataRepairProcess lineageProcessMain];
        
        if (returnStatus == -1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Read Error"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

@end
