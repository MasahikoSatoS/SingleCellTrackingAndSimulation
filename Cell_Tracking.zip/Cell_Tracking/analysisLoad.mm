//
// analysisLoad.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 13/08/09.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "analysisLoad.h"

NSString *notificationToAnalysisLoad = @"notificationExecuteAnalysisLoad";

@implementation analysisLoad

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToAnalysisLoad object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    analysisLoadWindController = [[NSWindowController alloc] initWithWindowNibName:@"AnalysisLoad"];
    [analysisLoadWindController showWindow:self];
    analysisImageNameSelect = "";
    analysisIDSelect = "";
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [analysisLoad frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [analysisLoad setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [analysisLoadBrowser setTarget:self];
    [analysisLoadBrowser setDoubleAction:@selector(browserDoubleClick:)];
    [analysisViewList setDataSource:self];
    
    for (NSTableColumn* column in [analysisViewList tableColumns]) {
        if ([[column identifier] isEqualToString:@"COL1"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Treat" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL2"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"T.One" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL3"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"T.End" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL4"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"T.Max" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL5"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"IF" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL6"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Last" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
    }
}

-(int)browser:(NSBrowser *)sender numberOfRowsInColumn:(int)column{
    directoryInfoCount = 0;
    
    string entry;
    
    DIR *dir;
    struct dirent *dent;
    
    if (column == 0){
        dir = opendir(trackDataFolderPath.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if ((int)entry.find("_Series") != -1){
                        if (directoryInfoCount+2 > directoryInfoLimit){
                            string *arrayUpDate = new string [directoryInfoCount+10];
                            
                            for (int counter1 = 0; counter1 < directoryInfoCount; counter1++) arrayUpDate [counter1] = arrayDirectoryInfo [counter1];
                            
                            delete [] arrayDirectoryInfo;
                            arrayDirectoryInfo = new string [directoryInfoLimit+500];
                            directoryInfoLimit = directoryInfoLimit+500;
                            
                            for (int counter1 = 0; counter1 < directoryInfoCount; counter1++) arrayDirectoryInfo [counter1] = arrayUpDate [counter1];
                            delete [] arrayUpDate;
                        }
                        
                        arrayDirectoryInfo [directoryInfoCount] = entry.substr(0, entry.find("_Series")), directoryInfoCount++;
                    }
                }
            }
            
            closedir(dir);
            
            //-----Directory Sort-----
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
            }
        }
    }
    
    if (column == 1){
        NSString *path;
        path = [sender path];
        
        string analysisFolderPath = trackDataFolderPath+[path UTF8String]+"_Series";
        string analysisFolderPath2 = "";
        string analysisFolderPath3 = "";
        string analysisNameTemp = [path UTF8String];
        
        if (analysisNameTemp != ""){
            ifstream fin;
            
            int shortFormatFind = 0;
            
            analysisNameTemp = analysisNameTemp.substr(1);
            
            if ((int)analysisNameTemp.find("/") != -1) analysisNameTemp = analysisNameTemp.substr(0, analysisNameTemp.find("/"));
            
            analysisImageNameSelect = analysisNameTemp;
            [analysisSeriesDisplay setStringValue:@(analysisImageNameSelect.c_str())];
            
            dir = opendir(analysisFolderPath.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if ((int)entry.find("_TrackData") != -1){
                            analysisFolderPath3 = analysisFolderPath+"/"+entry+"/*ShortForm.dat";
                            shortFormatFind = 0;
                            
                            fin.open(analysisFolderPath3.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                shortFormatFind = 1;
                                fin.close();
                            }
                            
                            if (directoryInfoCount+2 > directoryInfoLimit){
                                string *arrayUpDate = new string [directoryInfoCount+10];
                                
                                for (int counter1 = 0; counter1 < directoryInfoCount; counter1++) arrayUpDate [counter1] = arrayDirectoryInfo [counter1];
                                
                                delete [] arrayDirectoryInfo;
                                arrayDirectoryInfo = new string [directoryInfoLimit+500];
                                directoryInfoLimit = directoryInfoLimit+500;
                                
                                for (int counter1 = 0; counter1 < directoryInfoCount; counter1++) arrayDirectoryInfo [counter1] = arrayUpDate [counter1];
                                delete [] arrayUpDate;
                            }
                            
                            if (shortFormatFind == 0) arrayDirectoryInfo [directoryInfoCount] = entry.substr(0, entry.find("_TrackData")), directoryInfoCount++;
                            else arrayDirectoryInfo [directoryInfoCount] = "*"+entry.substr(0, entry.find("_TrackData")), directoryInfoCount++;
                        }
                    }
                }
                
                closedir(dir);
                
                //-----Directory Sort-----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                    [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
        }
    }
    
    return directoryInfoCount;
}

-(void)browser:(NSBrowser *)sender willDisplayCell:(id)cell atRow:(int)row column:(int)column{
    if (column == 0){
        string folderName = arrayDirectoryInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLoaded:YES];
    }
    
    if (column == 1){
        string folderName = arrayDirectoryInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLeaf:YES];
    }
}

-(IBAction)browserDoubleClick:(id)browser{
    NSString *nodePath = [browser path];
    string nodePathString = [nodePath UTF8String];
    
    if (nodePathString != ""){
        nodePathString = nodePathString.substr(1);
        
        if ((int)nodePathString.find("/") != -1){
            analysisIDSelect = nodePathString.substr(nodePathString.find("/")+1);
            
            if ((int)analysisIDSelect.find("*") == -1){
                [analysisIDDisplay setStringValue:@(analysisIDSelect.c_str())];
                [setAnalysisIDForOption setStringValue:@(analysisIDSelect.c_str())];
            }
            else analysisIDSelect = "";
        }
    }
}

-(IBAction)setData:(id)sender{
    if (analysisImageNameSelect != "" && analysisIDSelect != ""){
        if (analysisSavingInProgress == 0){
            string loadAnalysisPath = trackDataFolderPath+"/"+analysisImageNameSelect+"_Series"+"/"+analysisIDSelect+"_TrackData"+"/*TrackingSetting.dat";
            string destinationNameTemp = [[setAnalysisIDForOption stringValue] UTF8String];
            
            if (destinationNameTemp == analysisIDSelect) [setAnalysisIDForOption setStringValue:@""];
            
            treatmentStatusCount = 0;
            
            string getString;
            
            ifstream fin;
            fin.open(loadAnalysisPath.c_str(), ios::in);
            
            if (fin.is_open()){
                getline(fin, getString), analysisImageName = getString;
                getline(fin, getString), analysisID = getString;
                getline(fin, getString), autoExpand = atoi(getString.c_str());
                getline(fin, getString), autoExpandLine = atoi(getString.c_str());
                getline(fin, getString), trackingCheckInterval = atoi(getString.c_str());
                getline(fin, getString), queueDisplayOptions = atoi(getString.c_str());
                getline(fin, getString), doneDisplayOptions = atoi(getString.c_str());
                getline(fin, getString), imageReturnPosition = atoi(getString.c_str());
                getline(fin, getString), fluorescentEntryCount = atoi(getString.c_str());
                getline(fin, getString), fluorescentNo1 = atoi(getString.c_str());
                getline(fin, getString), fluorescentNo2 = atoi(getString.c_str());
                getline(fin, getString), fluorescentNo3 = atoi(getString.c_str());
                getline(fin, getString), fluorescentNo4 = atoi(getString.c_str());
                getline(fin, getString), fluorescentNo5 = atoi(getString.c_str());
                getline(fin, getString), fluorescentNo6 = atoi(getString.c_str());
                getline(fin, getString);
                
                if (getString == "nil") fluorescentName1 = "";
                else fluorescentName1 = getString;
                
                getline(fin, getString);
                
                if (getString == "nil") fluorescentName2 = "";
                else fluorescentName2 = getString;
                
                getline(fin, getString);
                
                if (getString == "nil") fluorescentName3 = "";
                else fluorescentName3 = getString;
                
                getline(fin, getString);
                
                if (getString == "nil") fluorescentName4 = "";
                else fluorescentName4 = getString;
                
                getline(fin, getString);
                
                if (getString == "nil") fluorescentName5 = "";
                else fluorescentName5 = getString;
                
                getline(fin, getString);
                
                if (getString == "nil") fluorescentName6 = "";
                else fluorescentName6 = getString;
                
                for (int counter1 = 0; counter1 < 16; counter1++){
                    getline(fin, getString);
                    
                    if (getString != "IFDATA"){
                        arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                        getline(fin, getString);
                        arrayTreatmentStatus [treatmentStatusCount] = "0", treatmentStatusCount++;
                        getline(fin, getString);
                        arrayTreatmentStatus [treatmentStatusCount] = "0", treatmentStatusCount++;
                        getline(fin, getString);
                        arrayTreatmentStatus [treatmentStatusCount] = "0", treatmentStatusCount++;
                        getline(fin, getString);
                        arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                        getline(fin, getString);
                        arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                        getline(fin, getString);
                        arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                        getline(fin, getString);
                        arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                        getline(fin, getString);
                        arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                    }
                    else{
                        
                        break;
                    }
                }
                
                //for (int counterA = 0; counterA < treatmentStatusCount/9; counterA++){
                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayTreatmentStatus [counterA*9+counterB];
                //    cout<<" arrayTreatmentStatus "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < 450; counter1++) arrayIFDataHold [counter1] = "nil";
                
                int ifDataHoldCount = 0;
                
                for (int counter1 = 0; counter1 < 450; counter1 = counter1+15){
                    getline(fin, getString);
                    
                    if (getString != "END"){
                        arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                        getline(fin, getString);
                        arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                        getline(fin, getString);
                        arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                        getline(fin, getString);
                        arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                        getline(fin, getString);
                        arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                        getline(fin, getString);
                        arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                        getline(fin, getString);
                        arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                        getline(fin, getString);
                        arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                        getline(fin, getString);
                        arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                        getline(fin, getString);
                        arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                        getline(fin, getString);
                        arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                        getline(fin, getString);
                        arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                        getline(fin, getString);
                        arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                        getline(fin, getString);
                        arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                        getline(fin, getString);
                        arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                    }
                    else{
                        
                        break;
                    }
                }
                
                fin.close();
            }
            
            string extension;
            string nameString;
            string lineageFilePath;
            
            int findFlag1 = 0;
            
            for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
                extension = arrayTreatmentStatus [counter1*9+4];
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                nameString = arrayTreatmentStatus [counter1*9];
                findFlag1 = 0;
                
                lineageFilePath = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData/"+nameString+"_Connect/"+analysisID+"_"+nameString+"_LineageData";
                fin.open(lineageFilePath.c_str(), ios::in);
                
                if (fin.is_open()) arrayTreatmentStatus [counter1*9+1] = "1", fin.close();
                else arrayTreatmentStatus [counter1*9+1] = "0";
                
                lineageFilePath = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData/"+nameString+"_Connect/"+analysisID+"_"+nameString+"_LineageStatus";
                fin.open(lineageFilePath.c_str(), ios::in);
                
                if (fin.is_open()) arrayTreatmentStatus [counter1*9+2] = "1", fin.close();
                else arrayTreatmentStatus [counter1*9+2] = "0";
                
                if (fin.is_open()) fin.close();
                else findFlag1 = 1;
                
                lineageFilePath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+nameString+"_Processed/"+extension+"_"+analysisImageName+"_"+nameString+"_Map";
                fin.open(lineageFilePath.c_str(), ios::in);
                
                if (fin.is_open()) fin.close();
                else findFlag1 = 1;
                
                lineageFilePath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+nameString+"_Processed/"+extension+"_"+analysisImageName+"_"+nameString+"_MasterData";
                fin.open(lineageFilePath.c_str(), ios::in);
                
                if (fin.is_open()) fin.close();
                else findFlag1 = 1;
                
                if (findFlag1 == 0) arrayTreatmentStatus [counter1*9+3] = "1";
                else arrayTreatmentStatus [counter1*9+3] = "0";
            }
            
            [analysisIDDisplay setStringValue:@(analysisID.c_str())];
            [analysisCurrent setStringValue:@(analysisImageName.c_str())];
            [analysisIDCurrent setStringValue:@(analysisID.c_str())];
            
            string savedDataPath = trackDataFolderPath+"/*LineageTrackingCurrent.dat";
            
            struct stat sizeOfFile;
            
            long sizeForCopy = 0;
            
            if (stat(loadAnalysisPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                ifstream infile (loadAnalysisPath.c_str(), ifstream::binary);
                ofstream outfile (savedDataPath.c_str(), ofstream::binary);
                
                char* buffer = new char[sizeForCopy];
                infile.read (buffer, sizeForCopy);
                outfile.write (buffer, sizeForCopy);
                delete[] buffer;
                
                outfile.close();
                infile.close();
            }
            
            [analysisViewList reloadData];
            setStatus1 = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Save/Load In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    string trackDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series";
    int tableViewContent = 0;
    
    if (analysisIDSelect == "") tableViewContent = 0;
    else tableViewContent = treatmentStatusCount/9;
    
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    string trackName = arrayTreatmentStatus [rowIndex*9];
    string timeOneSet = arrayTreatmentStatus [rowIndex*9+4];
    string timeEndSet = arrayTreatmentStatus [rowIndex*9+5];
    string timeMaxSet = arrayTreatmentStatus [rowIndex*9+6];
    string firstIFSet = arrayTreatmentStatus [rowIndex*9+7];
    string lastImageSet = arrayTreatmentStatus [rowIndex*9+8];
    
    //for (int counterA = 0; counterA < treatmentStatusCount/9; counterA++){
    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayTreatmentStatus [counterA*9+counterB];
    //    cout<<" arrayTreatmentStatus "<<counterA<<endl;
    //}
    
    NSAttributedString *attrStr;
    
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
    
    if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(trackName.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
        [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(timeOneSet.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL3"]){
        [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(timeEndSet.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL4"]){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(timeMaxSet.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL5"]){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(firstIFSet.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL6"]){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(lastImageSet.c_str()) attributes:attributes];
    }
    else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    
    return attrStr;
}

-(IBAction)closeWindow:(id)sender{
    if (analysisSavingInProgress == 0){
        [analysisLoad orderOut:self];
        analysisLoadOperation = 2;
        analysisLoadTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Save/Load In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)reDisplayWindow{
    if (analysisLoadOperation == 3){
        [analysisLoad makeKeyAndOrderFront:self];
        analysisLoadOperation = 1;
        [analysisLoadTimer invalidate];
    }
}

-(IBAction)duplicate:(id)sender{
    destinationName = [[setAnalysisIDForOption stringValue] UTF8String];
    
    if (analysisSavingInProgress == 0){
        if (destinationName != "" && analysisIDSelect != ""){
            fileUpdate = [[FileUpdate alloc] init];
            int returnResults = [fileUpdate nameCheck];
            
            if (returnResults == 0){
                string analysisIDPath = trackDataFolderPath+"/"+analysisImageNameSelect+"_Series";
                destinationAnalysisPath = trackDataFolderPath+"/"+analysisImageNameSelect+"_Series"+"/"+destinationName+"_TrackData";
                sourceAnalysisPath = trackDataFolderPath+"/"+analysisImageNameSelect+"_Series"+"/"+analysisIDSelect+"_TrackData";
                
                DIR *dir;
                struct dirent *dent;
                
                //-----Check whether same ID exist-----
                int proceedingFlag = 0, proceedingFlag2 = 0;
                string checkName = destinationName+"_TrackData";
                string checkName2 = analysisIDSelect+"_TrackData";
                
                string entry;
                
                dir = opendir(analysisIDPath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if (checkName == entry) proceedingFlag = 1;
                            if (checkName2 == entry) proceedingFlag2 = 1;
                        }
                    }
                    
                    closedir(dir);
                }
                else proceedingFlag = 1;
                
                //-----If it exists, proceed-----
                if (proceedingFlag == 0 && proceedingFlag2 == 1){
                    int typeSet = 1;
                    [self folderCopyMain:typeSet];
                    [analysisLoadBrowser reloadColumn:1];
                    [setAnalysisIDForOption setStringValue:@""];
                }
                else{
                    
                    [setAnalysisIDForOption setStringValue:@""];
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"ID Mismatch"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                [setAnalysisIDForOption setStringValue:@""];
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Illegal Characters Found"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [setAnalysisIDForOption setStringValue:@""];
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"ID Mismatch"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Save/Load In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)folderCopyMain:(int)typeSet{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        analysisSavingInProgress = 1;
        
        progressTiming = 6;
        
        DIR *dir;
        struct dirent *dent;
        DIR *dir2;
        struct dirent *dent2;
        DIR *dir3;
        struct dirent *dent3;
        DIR *dir4;
        struct dirent *dent4;
        
        unsigned long folderSize = 0;
        
        NSArray *contents;
        NSEnumerator *enumerator;
        NSString *path;
        contents = [[NSFileManager defaultManager] subpathsAtPath:@(sourceAnalysisPath.c_str())];
        enumerator = [contents objectEnumerator];
        
        while (path = [enumerator nextObject]){
            NSDictionary *fileAttributes = [[NSFileManager defaultManager] attributesOfItemAtPath:[@(sourceAnalysisPath.c_str()) stringByAppendingPathComponent:path] error:nil];
            folderSize +=[fileAttributes fileSize];
        }
        
        string stringExtract;
        string sizeCheckPath = "";
        
        if ((int)destinationAnalysisPath.find("/Volumes") != -1){
            stringExtract = destinationAnalysisPath.substr(8);
            
            if ((int)stringExtract.find("/") != -1){
                stringExtract = stringExtract.substr(1);
                stringExtract = stringExtract.substr(0, stringExtract.find("/"));
                sizeCheckPath = "/Volumes/"+stringExtract+"/";
            }
        }
        else sizeCheckPath = "/";
        
        NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(sizeCheckPath.c_str()) error:nil];
        
        unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
        unsigned long refSize = (unsigned long)2097152000+folderSize;
        
        if (freeSize > refSize){
            self->incrementSize = 0;
            
            //-----Create destination folder-----
            mkdir(destinationAnalysisPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string entry;
            string entry2;
            string destAnalysisPath2;
            string sourceAnalysisPath2;
            string copyFilePath;
            string destinationFilePath;
            string destAnalysisPath3;
            string sourceAnalysisPath3;
            string entry3;
            string entry4;
            string destAnalysisPath4;
            string sourceAnalysisPath4;
            string frontTemp;
            string behindTemp;
            
            int sourceNameLength = (int)analysisIDSelect.length();
            int findString1 = 0;
            
            long sizeForCopy = 0;
            
            struct stat sizeOfFile;
            
            //-----Copy start-----
            dir = opendir(sourceAnalysisPath.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        findString1 = (int)entry.find("_Connect");
                        
                        //-----Connect copy-----
                        if (findString1 != -1){
                            destAnalysisPath2 = destinationAnalysisPath+"/"+entry;
                            sourceAnalysisPath2 = sourceAnalysisPath+"/"+entry;
                            
                            if (typeSet == 1 || typeSet == 3){
                                //-----Create Connect folder-----
                                mkdir(destAnalysisPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                
                                dir2 = opendir(sourceAnalysisPath2.c_str());
                                
                                if (dir2 != NULL){
                                    while ((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                            copyFilePath = sourceAnalysisPath2+"/"+entry2;
                                            
                                            if (destinationName != analysisIDSelect){
                                                if (analysisIDSelect != "" && entry2.find(analysisIDSelect) == 0){
                                                    behindTemp = entry2.substr((unsigned long)sourceNameLength);
                                                    destinationFilePath = destAnalysisPath2+"/"+destinationName+behindTemp;
                                                }
                                                else{
                                                    
                                                    frontTemp = entry2.substr(0, 5);
                                                    behindTemp = entry2.substr(5+(unsigned long)sourceNameLength);
                                                    destinationFilePath = destAnalysisPath2+"/"+frontTemp+destinationName+behindTemp;
                                                }
                                            }
                                            else destinationFilePath = destAnalysisPath2+"/"+entry2;
                                            
                                            if (stat(copyFilePath.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                                
                                                ifstream infile (copyFilePath.c_str(), ifstream::binary);
                                                ofstream outfile (destinationFilePath.c_str(), ofstream::binary);
                                                
                                                char* buffer = new char[sizeForCopy];
                                                infile.read (buffer, sizeForCopy);
                                                outfile.write (buffer, sizeForCopy);
                                                delete[] buffer;
                                                
                                                outfile.close();
                                                infile.close();
                                            }
                                        }
                                    }
                                    
                                    closedir (dir2);
                                }
                            }
                            else if (typeSet == 2){
                                //-----Create Connect folder-----
                                mkdir(destAnalysisPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                
                                dir2 = opendir(sourceAnalysisPath2.c_str());
                                
                                if (dir2 != NULL){
                                    while ((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                            copyFilePath = sourceAnalysisPath2+"/"+entry2;
                                            destinationFilePath = destAnalysisPath2+"/"+entry2;
                                            
                                            if (stat(copyFilePath.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                                
                                                ifstream infile (copyFilePath.c_str(), ifstream::binary);
                                                ofstream outfile (destinationFilePath.c_str(), ofstream::binary);
                                                
                                                char* buffer = new char[sizeForCopy];
                                                infile.read (buffer, sizeForCopy);
                                                outfile.write (buffer, sizeForCopy);
                                                delete[] buffer;
                                                
                                                outfile.close();
                                                infile.close();
                                            }
                                        }
                                    }
                                    
                                    closedir (dir2);
                                }
                            }
                        }
                        
                        if ((int)entry.find("_Treat") != -1){
                            destAnalysisPath2 = destinationAnalysisPath+"/"+entry;
                            sourceAnalysisPath2 = sourceAnalysisPath+"/"+entry;
                            
                            if (typeSet == 1 || typeSet == 3){
                                //-----Create Treat Folder-----
                                mkdir(destAnalysisPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                
                                dir2 = opendir(sourceAnalysisPath2.c_str());
                                
                                if (dir2 != NULL){
                                    while ((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                            destAnalysisPath3 = destAnalysisPath2+"/"+entry2;
                                            sourceAnalysisPath3 = sourceAnalysisPath2+"/"+entry2;
                                            
                                            //-----Create Lineage Folder-----
                                            mkdir(destAnalysisPath3.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                            
                                            dir3 = opendir(sourceAnalysisPath3.c_str());
                                            
                                            if (dir3 != NULL){
                                                while ((dent3 = readdir(dir3))){
                                                    entry3 = dent3 -> d_name;
                                                    
                                                    if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store"){
                                                        if ((int)entry3.find("C") != -1 && (int)entry3.find("CellStatus") == -1){
                                                            destAnalysisPath4 = destAnalysisPath3+"/"+entry3;
                                                            sourceAnalysisPath4 = sourceAnalysisPath3+"/"+entry3;
                                                            
                                                            //-----Create Cell Folder-----
                                                            mkdir(destAnalysisPath4.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                                            
                                                            dir4 = opendir(sourceAnalysisPath4.c_str());
                                                            
                                                            if (dir4 != NULL){
                                                                while ((dent4 = readdir(dir4))){
                                                                    entry4 = dent4 -> d_name;
                                                                    
                                                                    if (entry4 != "." && entry4 != ".." && entry4 != ".DS_Store"){
                                                                        copyFilePath = sourceAnalysisPath4+"/"+entry4;
                                                                        
                                                                        if (destinationName != analysisIDSelect){
                                                                            if (entry4.find(analysisIDSelect) == 0){
                                                                                behindTemp = entry4.substr((unsigned long)sourceNameLength);
                                                                                destinationFilePath = destAnalysisPath4+"/"+destinationName+behindTemp;
                                                                            }
                                                                            else destinationFilePath = destAnalysisPath4+"/"+entry4;
                                                                        }
                                                                        else destinationFilePath = destAnalysisPath4+"/"+entry4;
                                                                        
                                                                        if (stat(copyFilePath.c_str(), &sizeOfFile) == 0){
                                                                            sizeForCopy = sizeOfFile.st_size;
                                                                            
                                                                            ifstream infile (copyFilePath.c_str(), ifstream::binary);
                                                                            ofstream outfile (destinationFilePath.c_str(), ofstream::binary);
                                                                            
                                                                            char* buffer = new char[sizeForCopy];
                                                                            infile.read (buffer, sizeForCopy);
                                                                            outfile.write (buffer, sizeForCopy);
                                                                            delete[] buffer;
                                                                            
                                                                            outfile.close();
                                                                            infile.close();
                                                                        }
                                                                    }
                                                                }
                                                                closedir (dir4);
                                                            }
                                                        }
                                                        
                                                        if ((int)entry3.find("C") != -1 && (int)entry3.find("CellStatus") != -1){
                                                            copyFilePath = sourceAnalysisPath3+"/"+entry3;
                                                            
                                                            if (destinationName != analysisIDSelect){
                                                                if ((int)entry3.find(analysisIDSelect) == 0){
                                                                    behindTemp = entry3.substr((unsigned long)sourceNameLength);
                                                                    destinationFilePath = destAnalysisPath3+"/"+destinationName+behindTemp;
                                                                }
                                                                else destinationFilePath = destAnalysisPath3+"/"+entry3;
                                                            }
                                                            else destinationFilePath = destAnalysisPath3+"/"+entry3;
                                                            
                                                            if (stat(copyFilePath.c_str(), &sizeOfFile) == 0){
                                                                sizeForCopy = sizeOfFile.st_size;
                                                                
                                                                ifstream infile (copyFilePath.c_str(), ifstream::binary);
                                                                ofstream outfile (destinationFilePath.c_str(), ofstream::binary);
                                                                
                                                                char* buffer = new char[sizeForCopy];
                                                                infile.read (buffer, sizeForCopy);
                                                                outfile.write (buffer, sizeForCopy);
                                                                delete[] buffer;
                                                                
                                                                outfile.close();
                                                                infile.close();
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                closedir (dir3);
                                            }
                                        }
                                    }
                                    
                                    closedir (dir2);
                                }
                            }
                            else if (typeSet == 2){
                                //-----Create Treat Folder-----
                                mkdir(destAnalysisPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                
                                dir2 = opendir(sourceAnalysisPath2.c_str());
                                
                                if (dir2 != NULL){
                                    while ((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                            destAnalysisPath3 = destAnalysisPath2+"/"+entry2;
                                            sourceAnalysisPath3 = sourceAnalysisPath2+"/"+entry2;
                                            
                                            //-----Create Lineage Folder-----
                                            mkdir(destAnalysisPath3.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                            
                                            dir3 = opendir(sourceAnalysisPath3.c_str());
                                            
                                            if (dir3 != NULL){
                                                while ((dent3 = readdir(dir3))){
                                                    entry3 = dent3 -> d_name;
                                                    
                                                    if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store"){
                                                        if ((int)entry3.find("C") != -1 && (int)entry3.find("CellStatus") == -1){
                                                            destAnalysisPath4 = destAnalysisPath3+"/"+entry3;
                                                            sourceAnalysisPath4 = sourceAnalysisPath3+"/"+entry3;
                                                            
                                                            //-----Create Cell Folder-----
                                                            mkdir(destAnalysisPath4.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                                            
                                                            dir4 = opendir(sourceAnalysisPath4.c_str());
                                                            
                                                            if (dir4 != NULL){
                                                                while ((dent4 = readdir(dir4))){
                                                                    entry4 = dent4 -> d_name;
                                                                    
                                                                    if (entry4 != "." && entry4 != ".." && entry4 != ".DS_Store"){
                                                                        copyFilePath = sourceAnalysisPath4+"/"+entry4;
                                                                        destinationFilePath = destAnalysisPath4+"/"+entry4;
                                                                        
                                                                        if (stat(copyFilePath.c_str(), &sizeOfFile) == 0){
                                                                            sizeForCopy = sizeOfFile.st_size;
                                                                            
                                                                            ifstream infile (copyFilePath.c_str(), ifstream::binary);
                                                                            ofstream outfile (destinationFilePath.c_str(), ofstream::binary);
                                                                            
                                                                            char* buffer = new char[sizeForCopy];
                                                                            infile.read (buffer, sizeForCopy);
                                                                            outfile.write (buffer, sizeForCopy);
                                                                            delete[] buffer;
                                                                            
                                                                            outfile.close();
                                                                            infile.close();
                                                                        }
                                                                    }
                                                                }
                                                                
                                                                closedir (dir4);
                                                            }
                                                        }
                                                        
                                                        if ((int)entry3.find("C") != -1 && (int)entry3.find("CellStatus") != -1){
                                                            copyFilePath = sourceAnalysisPath3+"/"+entry3;
                                                            
                                                            if (destinationName != analysisIDSelect){
                                                                if ((int)entry3.find(analysisIDSelect) == 0){
                                                                    behindTemp = entry3.substr((unsigned long)sourceNameLength);
                                                                    destinationFilePath = destAnalysisPath3+"/"+destinationName+behindTemp;
                                                                }
                                                                else destinationFilePath = destAnalysisPath3+"/"+entry3;
                                                            }
                                                            else destinationFilePath = destAnalysisPath3+"/"+entry3;
                                                            
                                                            if (stat(copyFilePath.c_str(), &sizeOfFile) == 0){
                                                                sizeForCopy = sizeOfFile.st_size;
                                                                
                                                                ifstream infile (copyFilePath.c_str(), ifstream::binary);
                                                                ofstream outfile (destinationFilePath.c_str(), ofstream::binary);
                                                                
                                                                char* buffer = new char[sizeForCopy];
                                                                infile.read (buffer, sizeForCopy);
                                                                outfile.write (buffer, sizeForCopy);
                                                                delete[] buffer;
                                                                
                                                                outfile.close();
                                                                infile.close();
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                closedir (dir3);
                                            }
                                        }
                                    }
                                    
                                    closedir (dir2);
                                }
                            }
                        }
                        
                        if (typeSet == 1 ){
                            if ((int)entry.find("dat") != -1 && (int)entry.find("TrackingSetting.dat") == -1 && (int)entry.find("LineageDataAddition") == -1){
                                copyFilePath = sourceAnalysisPath+"/"+entry;
                                destinationFilePath = destinationAnalysisPath+"/"+entry;
                                
                                if (stat(copyFilePath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    ifstream infile (copyFilePath.c_str(), ifstream::binary);
                                    ofstream outfile (destinationFilePath.c_str(), ofstream::binary);
                                    
                                    char* buffer = new char[sizeForCopy];
                                    infile.read (buffer, sizeForCopy);
                                    outfile.write (buffer, sizeForCopy);
                                    delete[] buffer;
                                    
                                    outfile.close();
                                    infile.close();
                                }
                            }
                        }
                        else if (typeSet == 3){
                            if ((int)entry.find("dat") != -1 && (int)entry.find("TrackingSetting.dat") == -1){
                                copyFilePath = sourceAnalysisPath+"/"+entry;
                                destinationFilePath = destinationAnalysisPath+"/"+entry;
                                
                                if (stat(copyFilePath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    ifstream infile (copyFilePath.c_str(), ifstream::binary);
                                    ofstream outfile (destinationFilePath.c_str(), ofstream::binary);
                                    
                                    char* buffer = new char[sizeForCopy];
                                    infile.read (buffer, sizeForCopy);
                                    outfile.write (buffer, sizeForCopy);
                                    delete[] buffer;
                                    
                                    outfile.close();
                                    infile.close();
                                }
                            }
                        }
                        else if (typeSet == 2){
                            if ((int)entry.find("dat") != -1){
                                copyFilePath = sourceAnalysisPath+"/"+entry;
                                destinationFilePath = destinationAnalysisPath+"/"+entry;
                                
                                if (stat(copyFilePath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    ifstream infile (copyFilePath.c_str(), ifstream::binary);
                                    ofstream outfile (destinationFilePath.c_str(), ofstream::binary);
                                    
                                    char* buffer = new char[sizeForCopy];
                                    infile.read (buffer, sizeForCopy);
                                    outfile.write (buffer, sizeForCopy);
                                    delete[] buffer;
                                    
                                    outfile.close();
                                    infile.close();
                                }
                            }
                        }
                        
                        if (typeSet == 1 || typeSet == 3){
                            string *trackingBaseDataTemp = new string [treatmentStatusCount+500];
                            int trackingBaseDataTempCount = 0;
                            
                            ifstream fin;
                            
                            string trackingBaseDataPath = trackDataFolderPath+"/"+analysisImageNameSelect+"_Series"+"/"+analysisIDSelect+"_TrackData"+"/*TrackingSetting.dat";
                            string getString;
                            
                            fin.open(trackingBaseDataPath.c_str(), ios::in);
                            
                            if (fin.is_open()){
                                getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                
                                if (typeSet == 1){
                                    getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = destinationName, trackingBaseDataTempCount++;
                                }
                                else{
                                    
                                    getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                }
                                
                                getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                
                                getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                getline(fin, getString), trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                
                                for (int counter1 = 0; counter1 < 16; counter1++){
                                    getline(fin, getString);
                                    
                                    if (getString != "IFDATA"){
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                    }
                                    else{
                                        
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        break;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < 450; counter1 = counter1+15){
                                    getline(fin, getString);
                                    
                                    if (getString != "END"){
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                        getline(fin, getString);
                                        trackingBaseDataTemp [trackingBaseDataTempCount] = getString, trackingBaseDataTempCount++;
                                    }
                                    else{
                                        
                                        break;
                                    }
                                }
                                
                                fin.close();
                            }
                            
                            trackingBaseDataTemp [1] = destinationName;
                            
                            string trackingSaveDataPath = destinationAnalysisPath+"/*TrackingSetting.dat";
                            
                            ofstream oin;
                            oin.open(trackingSaveDataPath.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < trackingBaseDataTempCount; counter1++) oin<<trackingBaseDataTemp [counter1]<<endl;
                            
                            oin<<"END"<<endl;
                            oin.close();
                            
                            delete [] trackingBaseDataTemp;
                        }
                    }
                }
                
                closedir(dir);
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Folder Not Found"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [self->setAnalysisIDForOption setStringValue:@""];
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Low Disk Space"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        
        progressTiming = 8;
        analysisSavingInProgress = 0;
    });
}

-(IBAction)deleteAnalysis:(id)sender{
    destinationName = [[setAnalysisIDForOption stringValue] UTF8String];
    
    if (analysisSavingInProgress == 0){
        if (((analysisID != "" && destinationName != "" && analysisID != destinationName) || analysisID == "") && analysisSavingInProgress == 0){
            string analysisIDPath = trackDataFolderPath+"/"+analysisImageNameSelect+"_Series";
            sourceAnalysisPath = trackDataFolderPath+"/"+analysisImageNameSelect+"_Series"+"/"+destinationName+"_TrackData";
            
            DIR *dir;
            struct dirent *dent;
            DIR *dir2;
            struct dirent *dent2;
            DIR *dir3;
            struct dirent *dent3;
            DIR *dir4;
            struct dirent *dent4;
            
            //-----Check whether source exist-----
            int proceedingFlag = 0;
            int remainingNumberOfAnalysis = 0;
            string checkName = destinationName+"_TrackData";
            string entry;
            
            dir = opendir(analysisIDPath.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        remainingNumberOfAnalysis++;
                        
                        if (checkName == entry){
                            proceedingFlag = 1;
                            break;
                        }
                    }
                    
                    if (proceedingFlag == 1){
                        break;
                    }
                }
                
                closedir(dir);
            }
            else proceedingFlag = 0;
            
            if (proceedingFlag == 1){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert addButtonWithTitle:@"Cancel"];
                [alert setMessageText:@"Delete Analysis?"];
                [alert setInformativeText:@"Deleted Analysis cannot be restored"];
                [alert setAlertStyle:NSAlertStyleWarning];
                
                if ([alert runModal] == NSAlertFirstButtonReturn){
                    progressTiming = 6;
                    
                    if (analysisIDSelect == destinationName){
                        analysisIDSelect = "";
                        [analysisIDDisplay setStringValue:@"nil"];
                    }
                    
                    string entry2;
                    string entry3;
                    string entry4;
                    string sourceAnalysisPath2;
                    string sourceAnalysisPath3;
                    string sourceAnalysisPath4;
                    string sourceAnalysisPath5;
                    
                    dir = opendir(sourceAnalysisPath.c_str());
                    fileDeleteCount = 0;
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                sourceAnalysisPath2 = sourceAnalysisPath+"/"+entry;
                                
                                dir2 = opendir(sourceAnalysisPath2.c_str());
                                
                                if (dir2 != NULL){
                                    while ((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                            sourceAnalysisPath3 = sourceAnalysisPath2+"/"+entry2;
                                            
                                            dir3 = opendir(sourceAnalysisPath3.c_str());
                                            
                                            if (dir3 != NULL){
                                                while ((dent3 = readdir(dir3))){
                                                    entry3 = dent3 -> d_name;
                                                    
                                                    if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store"){
                                                        sourceAnalysisPath4 = sourceAnalysisPath3+"/"+entry3;
                                                        
                                                        dir4 = opendir(sourceAnalysisPath4.c_str());
                                                        
                                                        if (dir4 != NULL){
                                                            while ((dent4 = readdir(dir4))){
                                                                entry4 = dent4 -> d_name;
                                                                
                                                                if (fileDeleteCount+5 > fileDeleteLimit){
                                                                    fileUpdate = [[FileUpdate alloc] init];
                                                                    [fileUpdate fileDeleteUpDate];
                                                                }
                                                                
                                                                arrayFileDelete [fileDeleteCount] = sourceAnalysisPath4+"/"+entry4, fileDeleteCount++;
                                                            }
                                                            
                                                            closedir(dir4);
                                                        }
                                                    }
                                                }
                                                
                                                closedir(dir3);
                                            }
                                        }
                                    }
                                    
                                    closedir(dir2);
                                }
                            }
                        }
                        
                        closedir (dir);
                    }
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                        remove (arrayFileDelete [counter1].c_str());
                    }
                    
                    dir = opendir(sourceAnalysisPath.c_str());
                    fileDeleteCount = 0;
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                sourceAnalysisPath2 = sourceAnalysisPath+"/"+entry;
                                
                                dir2 = opendir(sourceAnalysisPath2.c_str());
                                
                                if (dir2 != NULL){
                                    while ((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                            sourceAnalysisPath3 = sourceAnalysisPath2+"/"+entry2;
                                            
                                            dir3 = opendir(sourceAnalysisPath3.c_str());
                                            
                                            if (dir3 != NULL){
                                                while ((dent3 = readdir(dir3))){
                                                    entry3 = dent3 -> d_name;
                                                    
                                                    if (fileDeleteCount+5 > fileDeleteLimit){
                                                        fileUpdate = [[FileUpdate alloc] init];
                                                        [fileUpdate fileDeleteUpDate];
                                                    }
                                                    
                                                    arrayFileDelete [fileDeleteCount] = sourceAnalysisPath3+"/"+entry3, fileDeleteCount++;
                                                }
                                                
                                                closedir(dir3);
                                            }
                                        }
                                    }
                                    
                                    closedir(dir2);
                                }
                            }
                        }
                        
                        closedir (dir);
                    }
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                        remove (arrayFileDelete [counter1].c_str());
                        rmdir (arrayFileDelete [counter1].c_str());
                    }
                    
                    dir = opendir(sourceAnalysisPath.c_str());
                    fileDeleteCount = 0;
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                sourceAnalysisPath2 = sourceAnalysisPath+"/"+entry;
                                
                                dir2 = opendir(sourceAnalysisPath2.c_str());
                                
                                if (dir2 != NULL){
                                    while ((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (fileDeleteCount+5 > fileDeleteLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate fileDeleteUpDate];
                                        }
                                        
                                        arrayFileDelete [fileDeleteCount] = sourceAnalysisPath2+"/"+entry2, fileDeleteCount++;
                                    }
                                    
                                    closedir(dir2);
                                }
                            }
                        }
                        
                        closedir (dir);
                    }
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                        remove (arrayFileDelete [counter1].c_str());
                        rmdir (arrayFileDelete [counter1].c_str());
                    }
                    
                    fileDeleteCount = 0;
                    
                    dir = opendir(sourceAnalysisPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (fileDeleteCount+5 > fileDeleteLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate fileDeleteUpDate];
                            }
                            
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                        
                        closedir(dir);
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            sourceAnalysisPath2 = sourceAnalysisPath+"/"+arrayFileDelete [counter1];
                            remove (sourceAnalysisPath2.c_str());
                            rmdir (sourceAnalysisPath2.c_str());
                        }
                        
                        rmdir (sourceAnalysisPath.c_str());
                    }
                    
                    if (remainingNumberOfAnalysis == 1) rmdir (checkName.c_str());
                    
                    [analysisLoadBrowser reloadColumn:1];
                    
                    [setAnalysisIDForOption setStringValue:@""];
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    progressTiming = 8;
                }
            }
            else{
                
                [setAnalysisIDForOption setStringValue:@""];
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"ID Mismatch"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [setAnalysisIDForOption setStringValue:@""];
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"ID Mismatch/Cannot delete current analysis"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Save/Load In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)saveSelectedAnalysis:(id)sender{
    NSSavePanel *save = [NSSavePanel savePanel];
    
    if (analysisSavingInProgress == 0){
        long int result2 = [save runModal];
        
        if (result2 == NSModalResponseOK){
            NSURL *files = [save URL];
            NSString *selectedFile = files.path;
            
            string extractedID = [selectedFile UTF8String];
            string directoryPath = [selectedFile UTF8String];
            
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                if ((int)extractedID.find("/") != -1) extractedID = extractedID.substr(extractedID.find("/")+1);
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            unsigned long findString1 = directoryPath.find (extractedID);
            directoryPath = directoryPath.substr (0, findString1);
            
            if (extractedID != "" && analysisIDSelect != ""){
                destinationName = extractedID;
                
                fileUpdate = [[FileUpdate alloc] init];
                int returnResults = [fileUpdate nameCheck];
                
                if (returnResults == 0){
                    destinationAnalysisPath = directoryPath+extractedID+"_TrackData";
                    sourceAnalysisPath = trackDataFolderPath+"/"+analysisImageNameSelect+"_Series"+"/"+analysisIDSelect+"_TrackData";
                    
                    DIR *dir;
                    struct dirent *dent;
                    
                    //-----Check whether same ID exist-----
                    int proceedingFlag = 0;
                    string checkName = destinationName+"_TrackData";
                    
                    string entry;
                    
                    dir = opendir(directoryPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if (checkName == entry){
                                    proceedingFlag = 1;
                                    break;
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    else proceedingFlag = 1;
                    
                    //-----If it exists, proceed-----
                    if (proceedingFlag == 0){
                        int typeSet = 3;
                        [self folderCopyMain:typeSet];
                        [analysisLoadBrowser reloadColumn:1];
                        [setAnalysisIDForOption setStringValue:@""];
                    }
                    else{
                        
                        [setAnalysisIDForOption setStringValue:@""];
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"ID Mismatch"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    [setAnalysisIDForOption setStringValue:@""];
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Illegal Characters Found"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                [setAnalysisIDForOption setStringValue:@""];
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"ID Mismatch"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Save/Load In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)loadAnalysis:(id)sender{
    NSOpenPanel *openDlg = [NSOpenPanel openPanel];
    [openDlg setCanChooseFiles:NO];
    [openDlg setCanChooseDirectories:YES];
    
    if (analysisSavingInProgress == 0){
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            string directoryPathExtract = [fileName UTF8String];
            
            int findString1 = (int)directoryPathExtract.find("/Users/");
            if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
            
            unsigned long directoryLength = directoryPathExtract.length();
            
            string extractedID = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
            string directoryPath = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
            
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                if ((int)extractedID.find("/") != -1) extractedID = extractedID.substr(extractedID.find("/")+1);
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            directoryPath = directoryPath.substr (0, directoryPath.find (extractedID));
            
            if (extractedID != "" && (int)extractedID.find("_TrackData") != -1 && analysisImageNameSelect != ""){
                destinationName = extractedID.substr (0, extractedID.find("_TrackData"));
                
                fileUpdate = [[FileUpdate alloc] init];
                int returnResults = [fileUpdate nameCheck];
                
                string extractedID2;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)extractedID.find("%20") != -1){
                        extractedID2 = destinationName.substr(0, (unsigned long)findString1);
                        destinationName = destinationName.substr((unsigned long)findString1+3);
                        destinationName = extractedID2+" "+extractedID;
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                if (returnResults == 0){
                    destinationAnalysisPath = trackDataFolderPath+"/"+analysisImageNameSelect+"_Series"+"/"+destinationName+"_TrackData";
                    sourceAnalysisPath = directoryPath+destinationName+"_TrackData";
                    
                    DIR *dir;
                    struct dirent *dent;
                    
                    //-----Check whether same ID exist-----
                    int proceedingFlag = 0;
                    string checkRefPath = trackDataFolderPath+"/"+analysisImageNameSelect+"_Series";
                    string checkName = destinationName+"_TrackData";
                    
                    string entry;
                    
                    dir = opendir(checkRefPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if (checkName == entry){
                                    proceedingFlag = 1;
                                    break;
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    else proceedingFlag = 1;
                    
                    if (proceedingFlag == 0){
                        int typeSet = 2;
                        [self folderCopyMain:typeSet];
                        [analysisLoadBrowser reloadColumn:1];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Analysis ID Duplicate"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Illegal Characters Found"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                if (extractedID == "" || (int)extractedID.find("_TrackData") != -1){
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"No Track Data Folder"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else if (analysisImageName == ""){
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Set Analysis Name"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Save/Load In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToAnalysisLoad object:nil];
}

@end
