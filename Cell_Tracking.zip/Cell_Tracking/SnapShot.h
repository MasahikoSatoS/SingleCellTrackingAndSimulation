//
//  SnapShot.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2015-03-13.
//
//

#ifndef SNAPSHOT_H
#define SNAPSHOT_H
#import "Controller.h" 
#endif

@interface SnapShot : NSObject {
}

-(void)snapShotMain:(int)saveType :(int)saveImageNo :(int)saveLingNo :(int)saveCellNo;

@end
