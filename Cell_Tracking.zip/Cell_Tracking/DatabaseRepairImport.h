//
//  DatabaseRepairImport.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-05-29.
//

#ifndef DATAREPAIRIMPORT_H
#define DATAREPAIRIMPORT_H
#import "Controller.h"
#endif

@interface DatabaseRepairImport : NSObject{
    IBOutlet NSTextField *lingNoSetDisplay;
    
    id dataRepairReadWrite;
}

-(IBAction)lineageImport:(id)sender;
-(IBAction)lineageImportAll:(id)sender;
-(IBAction)mapImport:(id)sender;
-(IBAction)queueImport:(id)sender;
-(IBAction)doneImport:(id)sender;

@end
