//
// AreaCircleCutTrack.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 29/09/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "AreaCircleCutTrack.h"

@implementation AreaCircleCutTrack

-(int)circleCut:(int)processType{
    //-----First circle process-----
    
    mergeSelectCount = 0;
    string cellLineageExtract = cellLineageNoHold.substr(1);
    string cellNumberExtract = "";
    
    cellNumberExtract = cellNoHold.substr(1);
    
    int cellLineageTempInt = atoi(cellLineageExtract.c_str());
    int cellNumberTempInt = atoi(cellNumberExtract.c_str());
    
    string lineageNoExtension = to_string(imageNumberTrackForDisplay);
    
    if (lineageNoExtension.length() == 1) lineageNoExtension = "000"+lineageNoExtension;
    else if (lineageNoExtension.length() == 2) lineageNoExtension = "00"+lineageNoExtension;
    else if (lineageNoExtension.length() == 3) lineageNoExtension = "0"+lineageNoExtension;
    
    //-----Division case process-----
    connectNoTemp = 0;
    
    if (divisionTypeHold == 0 || (divisionTypeHold >= 2 && cellDivisionSetCount == 0)){
        for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
            if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt) connectNoTemp = arrayConnectLineageRel [counter1*6+1];
        }
    }
    
    if (autoExpandLine == 1){
        merge = [[Merge alloc] init];
        [merge mergeExtendTrack];
    }
    
    int resultsType1 = 0;
    int maxPointDimX = 0;
    int maxPointDimY = 0;
    int minPointDimX = 1000000;
    int minPointDimY = 1000000;
    
    for (int counter1 = 0; counter1 < lineDataProcessingCount/2; counter1++){
        if (maxPointDimX < arrayLineDataProcessing [counter1*2]) maxPointDimX = arrayLineDataProcessing [counter1*2];
        if (minPointDimX > arrayLineDataProcessing [counter1*2]) minPointDimX = arrayLineDataProcessing [counter1*2];
        if (maxPointDimY < arrayLineDataProcessing [counter1*2+1]) maxPointDimY = arrayLineDataProcessing [counter1*2+1];
        if (minPointDimY > arrayLineDataProcessing [counter1*2+1]) minPointDimY = arrayLineDataProcessing [counter1*2+1];
    }
    
    //-----Determine the dimension of cell-----
    int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
    int verticalLength = (maxPointDimY-minPointDimY)/2*2;
    int dimension = 0;
    
    if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
    if (horizontalLength < verticalLength) dimension = verticalLength+30;
    
    dimension = (dimension/2)*2;
    
    int horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
    int verticalStart = minPointDimY-(dimension-verticalLength)/2;
    
    //cout<<horizontalStart<<" "<<verticalStart<<" "<<dimension<<" hol-ver-dim"<<endl;
    
    connectivityMap = new int *[dimension+1];
    
    for (int counter1 = 0; counter1 < dimension+1; counter1++) connectivityMap [counter1] = new int [dimension+1];
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++) connectivityMap [counterY][counterX] = 0;
    }
    
    for (int counter1 = 0; counter1 < lineDataProcessingCount/2; counter1++){
        if (arrayLineDataProcessing [counter1*2]-horizontalStart >= 0 && arrayLineDataProcessing [counter1*2]-horizontalStart < dimension && arrayLineDataProcessing [counter1*2+1]-verticalStart >= 0 && arrayLineDataProcessing [counter1*2+1]-verticalStart < dimension) connectivityMap [arrayLineDataProcessing [counter1*2+1]-verticalStart][arrayLineDataProcessing [counter1*2]-horizontalStart] = 1;
    }
    
    //for (int counterA = 0; counterA < dimension; counterA++){
    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
    //    cout<<" connectivityMap "<<counterA<<endl;
    //}
    
    int connectivityNumber = 0;
    int connectAnalysisCount = 0;
    int terminationFlag = 0;
    int connectAnalysisTempCount = 0;
    int xSource = 0;
    int ySource = 0;
    
    //-----Fill inside-----
    int *connectAnalysisX = new int [dimension*4];
    int *connectAnalysisY = new int [dimension*4];
    int *connectAnalysisTempX = new int [dimension*4];
    int *connectAnalysisTempY = new int [dimension*4];
    
    connectivityNumber = -3;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMap [counterY][counterX] == 0){
                connectivityNumber = connectivityNumber+2;
                connectAnalysisCount = 0;
                
                if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMap [counterY][counterX] = connectivityNumber;
                if (counterY-1 >= 0 && connectivityMap [counterY-1][counterX] == 0){
                    connectivityMap [counterY-1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterX+1 < dimension && connectivityMap [counterY][counterX+1] == 0){
                    connectivityMap [counterY][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && connectivityMap [counterY+1][counterX] == 0){
                    connectivityMap [counterY+1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterX-1 >= 0 && connectivityMap [counterY][counterX-1] == 0){
                    connectivityMap [counterY][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                
                if (connectAnalysisCount != 0){
                    do{
                        
                        terminationFlag = 1;
                        connectAnalysisTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                            
                            if (ySource-1 >= 0 && connectivityMap [ySource-1][xSource] == 0){
                                connectivityMap [ySource-1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (xSource+1 < dimension && connectivityMap [ySource][xSource+1] == 0){
                                connectivityMap [ySource][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < dimension && connectivityMap [ySource+1][xSource] == 0){
                                connectivityMap [ySource+1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (xSource-1 >= 0 && connectivityMap [ySource][xSource-1] == 0){
                                connectivityMap [ySource][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                        }
                        
                        connectAnalysisCount = connectAnalysisTempCount;
                        
                        if (connectAnalysisCount == 0) terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                }
            }
        }
    }
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMap [counterY][counterX] == -1) connectivityMap [counterY][counterX] = 0;
            else connectivityMap [counterY][counterX] = 1;
        }
    }
    
    //for (int counterA = 0; counterA < dimension; counterA++){
    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
    //    cout<<" connectivityMap "<<counterA<<endl;
    //}
    
    int maxConnectNumberList = timeSelectedCount/10;
    
    int *overLapListTemp = new int [maxConnectNumberList+2];
    
    for (int counter1 = 0; counter1 <= maxConnectNumberList; counter1++) overLapListTemp [counter1] = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] != 0){
                if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0) overLapListTemp [revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart]]++;
            }
        }
    }
    
    overLapListTemp [connectNoTemp] = 1;
    
    //for (int counterA = 1; counterA <= maxConnectNumberList; counterA++) cout<<counterA<<" "<<overLapListTemp [counterA]<<" Overlap"<<endl;
    
    for (int counter1 = 0; counter1 < dimension+1; counter1++) delete [] connectivityMap [counter1];
    
    delete [] connectivityMap;
    
    for (int counter1 = 1; counter1 <= maxConnectNumberList; counter1++){
        if (overLapListTemp [counter1] != 0){
            if (arrayTimeSelected [(counter1-1)*10] != 3 && arrayTimeSelected [(counter1-1)*10] != 4){
                for (int counter2 = arrayTimeSelected [(counter1-1)*10+2]; counter2 < positionReviseCount/7; counter2++){
                    if (arrayPositionRevise [counter2*7+3] == counter1){
                        if (maxPointDimX < arrayPositionRevise [counter2*7]) maxPointDimX = arrayPositionRevise [counter2*7];
                        if (minPointDimX > arrayPositionRevise [counter2*7]) minPointDimX = arrayPositionRevise [counter2*7];
                        if (maxPointDimY < arrayPositionRevise [counter2*7+1]) maxPointDimY = arrayPositionRevise [counter2*7+1];
                        if (minPointDimY > arrayPositionRevise [counter2*7+1]) minPointDimY = arrayPositionRevise [counter2*7+1];
                    }
                    else{
                        
                        break;
                    }
                }
            }
        }
    }
    
    int startPointFind = 0;
    
    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
        if (arrayTimeSelected [counter1*10] == 0 || arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7 || arrayTimeSelected [counter1*10] == 2){
            if (arrayPositionRevise [arrayTimeSelected [counter1*10+2]*7+5] == 1 && arrayPositionRevise [arrayTimeSelected [counter1*10+2]*7+4] == cellNumberTempInt && arrayPositionRevise [arrayTimeSelected [counter1*10+2]*7+6] == cellLineageTempInt){
                
                startPointFind = 1;
                break;
            }
        }
    }
    
    delete [] overLapListTemp;
    
    horizontalLength = (maxPointDimX-minPointDimX)/2*2;
    verticalLength = (maxPointDimY-minPointDimY)/2*2;
    dimension = 0;
    
    if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
    if (horizontalLength < verticalLength) dimension = verticalLength+30;
    
    dimension = (dimension/2)*2;
    
    horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
    verticalStart = minPointDimY-(dimension-verticalLength)/2;
    
    internalZeroMap = new int *[dimension+1];
    targetMap = new int *[dimension+1];
    connectivityMap = new int *[dimension+1];
    
    for (int counter1 = 0; counter1 < dimension+1; counter1++){
        connectivityMap [counter1] = new int [dimension+1];
        internalZeroMap [counter1] = new int [dimension+1];
        targetMap [counter1] = new int [dimension+1];
    }
    
    //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
    //	cout<<" arrayConnectLineageRel "<<counterA+1<<endl;
    //}
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++) connectivityMap [counterY][counterX] = 0;
    }
    
    for (int counter1 = 0; counter1 < lineDataProcessingCount/2; counter1++){
        if (arrayLineDataProcessing [counter1*2]-horizontalStart >= 0 && arrayLineDataProcessing [counter1*2]-horizontalStart < dimension && arrayLineDataProcessing [counter1*2+1]-verticalStart >= 0 && arrayLineDataProcessing [counter1*2+1]-verticalStart < dimension) connectivityMap [arrayLineDataProcessing [counter1*2+1]-verticalStart][arrayLineDataProcessing [counter1*2]-horizontalStart] = 1;
    }
    
    delete [] connectAnalysisX;
    delete [] connectAnalysisY;
    delete [] connectAnalysisTempX;
    delete [] connectAnalysisTempY;
    
    //-----Fill inside-----
    connectAnalysisX = new int [(dimension+2)*4];
    connectAnalysisY = new int [(dimension+2)*4];
    connectAnalysisTempX = new int [(dimension+2)*4];
    connectAnalysisTempY = new int [(dimension+2)*4];
    
    connectivityNumber = -3;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMap [counterY][counterX] == 0){
                connectivityNumber = connectivityNumber+2;
                connectAnalysisCount = 0;
                
                if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMap [counterY][counterX] = connectivityNumber;
                
                if (counterY-1 >= 0 && connectivityMap [counterY-1][counterX] == 0){
                    connectivityMap [counterY-1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterX+1 < dimension && connectivityMap [counterY][counterX+1] == 0){
                    connectivityMap [counterY][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && connectivityMap [counterY+1][counterX] == 0){
                    connectivityMap [counterY+1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterX-1 >= 0 && connectivityMap [counterY][counterX-1] == 0){
                    connectivityMap [counterY][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                
                if (connectAnalysisCount != 0){
                    do{
                        
                        terminationFlag = 1;
                        connectAnalysisTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                            
                            if (ySource-1 >= 0 && connectivityMap [ySource-1][xSource] == 0){
                                connectivityMap [ySource-1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (xSource+1 < dimension && connectivityMap [ySource][xSource+1] == 0){
                                connectivityMap [ySource][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < dimension && connectivityMap [ySource+1][xSource] == 0){
                                connectivityMap [ySource+1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (xSource-1 >= 0 && connectivityMap [ySource][xSource-1] == 0){
                                connectivityMap [ySource][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                        }
                        
                        connectAnalysisCount = connectAnalysisTempCount;
                        
                        if (connectAnalysisCount == 0) terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                }
            }
        }
    }
    
    int connectMapAreaOriginal = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMap [counterY][counterX] == -1) connectivityMap [counterY][counterX] = 0;
            else{
                
                connectivityMap [counterY][counterX] = -1;
                connectMapAreaOriginal++;
            }
        }
    }
    
    //-----Background image set-----
    int **rangeMatrix = new int *[dimension+4];
    
    for (int counter1 = 0; counter1 < dimension+4; counter1++){
        rangeMatrix [counter1] = new int [dimension+4];
    }
    
    int currentCutValue = 0;
    
    if (forceSetStatus == 1) currentCutValue = 10;
    else currentCutValue = cutStatusDic;
    
    connectivityNumber = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                if (forceSetStatus == 0 && sourceImage [counterY+verticalStart][counterX+horizontalStart] == 100) rangeMatrix [counterY][counterX] = 0;
                else if (sourceImage [counterY+verticalStart][counterX+horizontalStart] < currentCutValue) rangeMatrix [counterY][counterX] = 0;
                else rangeMatrix [counterY][counterX] = -150;
            }
            else rangeMatrix [counterY][counterX] = 0;
        }
    }
    
    forceSetStatus = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (rangeMatrix [counterY][counterX] == -150){
                connectivityNumber++;
                rangeMatrix [counterY][counterX] = connectivityNumber;
                connectAnalysisCount = 0;
                
                if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrix [counterY-1][counterX-1] == -150){
                    rangeMatrix [counterY-1][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterY-1 >= 0 && rangeMatrix [counterY-1][counterX] == -150){
                    rangeMatrix [counterY-1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterY-1 >= 0 && counterX+1 < dimension && rangeMatrix [counterY-1][counterX+1] == -150){
                    rangeMatrix [counterY-1][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterX+1 < dimension && rangeMatrix [counterY][counterX+1] == -150){
                    rangeMatrix [counterY][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && counterX+1 < dimension && rangeMatrix [counterY+1][counterX+1] == -150){
                    rangeMatrix [counterY+1][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && rangeMatrix [counterY+1][counterX] == -150){
                    rangeMatrix [counterY+1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && counterX-1 >= 0 && rangeMatrix [counterY+1][counterX-1] == -150){
                    rangeMatrix [counterY+1][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterX-1 >= 0 && rangeMatrix [counterY][counterX-1] == -150){
                    rangeMatrix [counterY][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                
                if (connectAnalysisCount != 0){
                    do{
                        
                        terminationFlag = 1;
                        connectAnalysisTempCount = 0;
                        
                        for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                            xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                            
                            if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrix [ySource-1][xSource-1] == -150){
                                rangeMatrix [ySource-1][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (ySource-1 >= 0 && rangeMatrix [ySource-1][xSource] == -150){
                                rangeMatrix [ySource-1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (ySource-1 >= 0 && xSource+1 < dimension && rangeMatrix [ySource-1][xSource+1] == -150){
                                rangeMatrix [ySource-1][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (xSource+1 < dimension && rangeMatrix [ySource][xSource+1] == -150){
                                rangeMatrix [ySource][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                            if (ySource+1 > dimension && xSource+1 < dimension && rangeMatrix [ySource+1][xSource+1] == -150){
                                rangeMatrix [ySource+1][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < dimension && rangeMatrix [ySource+1][xSource] == -150){
                                rangeMatrix [ySource+1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < dimension && xSource-1 >= 0 && rangeMatrix [ySource+1][xSource-1] == -150){
                                rangeMatrix [ySource+1][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (xSource-1 >= 0 && rangeMatrix [ySource][xSource-1] == -150){
                                rangeMatrix [ySource][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                            connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                        }
                        
                        connectAnalysisCount = connectAnalysisTempCount;
                        
                        if (connectAnalysisCount == 0) terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                }
            }
        }
    }
    
    //-----Determine number of pixels-----
    int *connectedPix = new int [connectivityNumber+50];
    
    for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPix [counter2] = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (rangeMatrix [counterY][counterX] != 0) connectedPix [rangeMatrix [counterY][counterX]]++;
        }
    }
    
    //-----Map up-date-----
    int connectTemp = 1;
    
    for (int counter2 = 1; counter2 <= connectivityNumber; counter2++){
        if (connectedPix [counter2] < 10) connectedPix [counter2] = 0;
        else{
            
            connectedPix [counter2] = connectTemp;
            connectTemp++;
        }
    }
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if ((connectTemp = rangeMatrix [counterY][counterX]) != 0) rangeMatrix [counterY][counterX] = connectedPix [connectTemp];
            else rangeMatrix [counterY][counterX] = 0;
        }
    }
    
    delete [] connectedPix;
    
    //for (int counterA = 0; counterA < dimension; counterA++){
    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<rangeMatrix [counterA][counterB];
    //    cout<<" rangeMatrix "<<counterA<<endl;
    //}
    
    int cancelFlag = 0;
    
    if (divisionTypeHold == 2 && cellDivisionSetCount >= 1){
        string connectDivString1 = cellNoHoldDiv1.substr(1);
        string connectDivString2 = cellNoHoldDiv2.substr(1);
        int connectDivInt1 = atoi(connectDivString1.c_str());
        int connectDivInt2 = atoi(connectDivString2.c_str());
        
        int connectDivTemp1 = 0;
        int connectDivTemp2 = 0;
        int connectDivCountTemp1 = 0;
        int connectDivCountTemp2 = 0;
        int connectDivWholeCount1 = 0;
        int connectDivWholeCount2 = 0;
        int changeFlag = 0;
        
        for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
            if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt1) connectDivTemp1 = arrayConnectLineageRel [counter1*6+1];
            if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt2) connectDivTemp2 = arrayConnectLineageRel [counter1*6+1];
        }
        
        if (cellDivisionSetCount == 1 || cellDivisionSetCount == 2){
            int valueTemp = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                        valueTemp = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart];
                        
                        if (connectivityMap [counterY][counterX] != 0){
                            if (valueTemp != 0){
                                if (valueTemp == connectDivTemp1) connectDivCountTemp1++;
                                if (valueTemp == connectDivTemp2) connectDivCountTemp2++;
                            }
                        }
                        
                        if (valueTemp == connectDivTemp1) connectDivWholeCount1++;
                        if (valueTemp == connectDivTemp2) connectDivWholeCount2++;
                    }
                }
            }
            
            if (cellDivisionSetCount >= 1){
                if (connectDivCountTemp1 > connectDivCountTemp2 && connectDivCountTemp1 >= 50 && connectDivCountTemp1/(double)connectDivWholeCount1 > 0.5){
                    connectNoTemp = connectDivTemp1;
                    cellNumberTempInt = connectDivInt1;
                    
                    if (cellDivisionSetCount != 1){
                        cellDivisionSetCount = 1;
                        changeFlag = 1;
                    }
                }
                else if (connectDivCountTemp2 > connectDivCountTemp1 && connectDivCountTemp2 >= 50 && connectDivCountTemp2/(double)connectDivWholeCount2 > 0.5){
                    connectNoTemp = connectDivTemp2;
                    cellNumberTempInt = connectDivInt2;
                    
                    if (cellDivisionSetCount != 2){
                        cellDivisionSetCount = 2;
                        changeFlag = 1;
                    }
                }
                else if (connectDivTemp2 == 0){
                    connectNoTemp = connectDivTemp2;
                    cellNumberTempInt = connectDivInt2;
                    
                    if (eventSequenceCount+4 > eventSequenceLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate eventSequenceUpDate];
                    }
                    
                    arrayEventSequence [eventSequenceCount] = imageNumberTrackForDisplay, eventSequenceCount++;
                    arrayEventSequence [eventSequenceCount] = 33, eventSequenceCount++;
                    arrayEventSequence [eventSequenceCount] = arrayEventSequence [2], eventSequenceCount++;
                    arrayEventSequence [eventSequenceCount] = cellNumberTempInt, eventSequenceCount++;
                    
                    if (cellDivisionSetCount != 2){
                        cellDivisionSetCount = 2;
                        changeFlag = 1;
                    }
                    
                    eventSequenceHoldCount = 0;
                    
                    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4], eventSequenceHoldCount++;
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+1], eventSequenceHoldCount++;
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+2], eventSequenceHoldCount++;
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+3], eventSequenceHoldCount++;
                        }
                    }
                }
                else cancelFlag = 1;
            }
            
            if (changeFlag == 1 || cancelFlag == 0){
                targetHoldCount = 0;
                targetHoldInfoCount = 0;
                
                for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                    arrayTimeSelected [counter1*10+1] = 0;
                    arrayTimeSelected [counter1*10+3] = 0;
                }
                
                if (cellDivisionSetCount == 1){
                    for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt1) arrayConnectLineageRel [counter1*6+4] = 1;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt2) arrayConnectLineageRel [counter1*6+4] = 0;
                    }
                }
                if (cellDivisionSetCount == 2){
                    for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt1) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt2) arrayConnectLineageRel [counter1*6+4] = 1;
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
        //	cout<<" arrayConnectLineageRel "<<counterA+1<<endl;
        //}
    }
    if (divisionTypeHold == 3 && cellDivisionSetCount >= 1){
        string connectDivString1 = cellNoHoldDiv1.substr(1);
        string connectDivString2 = cellNoHoldDiv2.substr(1);
        string connectDivString3 = cellNoHoldDiv3.substr(1);
        int connectDivInt1 = atoi(connectDivString1.c_str());
        int connectDivInt2 = atoi(connectDivString2.c_str());
        int connectDivInt3 = atoi(connectDivString3.c_str());
        
        int connectDivTemp1 = 0;
        int connectDivTemp2 = 0;
        int connectDivTemp3 = 0;
        int connectDivCountTemp1 = 0;
        int connectDivCountTemp2 = 0;
        int connectDivCountTemp3 = 0;
        int connectDivWholeCount1 = 0;
        int connectDivWholeCount2 = 0;
        int connectDivWholeCount3 = 0;
        int changeFlag = 0;
        
        for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
            if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt1) connectDivTemp1 = arrayConnectLineageRel [counter1*6+1];
            if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt2) connectDivTemp2 = arrayConnectLineageRel [counter1*6+1];
            if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt3) connectDivTemp3 = arrayConnectLineageRel [counter1*6+1];
        }
        
        if (cellDivisionSetCount == 1 || cellDivisionSetCount == 2 || cellDivisionSetCount == 3){
            int valueTemp = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                        valueTemp = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart];
                        
                        if (connectivityMap [counterY][counterX] != 0){
                            if (valueTemp != 0){
                                if (valueTemp == connectDivTemp1) connectDivCountTemp1++;
                                if (valueTemp == connectDivTemp2) connectDivCountTemp2++;
                                if (valueTemp == connectDivTemp3) connectDivCountTemp3++;
                            }
                        }
                        
                        if (valueTemp == connectDivTemp1) connectDivWholeCount1++;
                        if (valueTemp == connectDivTemp2) connectDivWholeCount2++;
                        if (valueTemp == connectDivTemp3) connectDivWholeCount3++;
                    }
                }
            }
            
            if (cellDivisionSetCount >= 1){
                if (connectDivCountTemp1 > connectDivCountTemp2 && connectDivCountTemp1 > connectDivCountTemp3 && connectDivCountTemp1 >= 50 && connectDivCountTemp1/(double)connectDivWholeCount1 > 0.5){
                    connectNoTemp = connectDivTemp1;
                    cellNumberTempInt = connectDivInt1;
                    
                    if (cellDivisionSetCount != 1){
                        cellDivisionSetCount = 1;
                        changeFlag = 1;
                    }
                }
                else if (connectDivCountTemp2 > connectDivCountTemp1 && connectDivCountTemp2 > connectDivCountTemp3 && connectDivCountTemp2 >= 50 && connectDivCountTemp2/(double)connectDivWholeCount2 > 0.5){
                    connectNoTemp = connectDivTemp2;
                    cellNumberTempInt = connectDivInt2;
                    
                    if (cellDivisionSetCount != 2){
                        cellDivisionSetCount = 2;
                        changeFlag = 1;
                    }
                }
                else if (connectDivCountTemp3 > connectDivCountTemp1 && connectDivCountTemp3 > connectDivCountTemp2 && connectDivCountTemp3 >= 50 && connectDivCountTemp3/(double)connectDivWholeCount3 > 0.5){
                    connectNoTemp = connectDivTemp3;
                    cellNumberTempInt = connectDivInt3;
                    
                    if (cellDivisionSetCount != 3){
                        cellDivisionSetCount = 3;
                        changeFlag = 1;
                    }
                }
                else if (connectDivTemp2 == 0){
                    connectNoTemp = connectDivTemp2;
                    cellNumberTempInt = connectDivInt2;
                    
                    if (eventSequenceCount+4 > eventSequenceLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate eventSequenceUpDate];
                    }
                    
                    arrayEventSequence [eventSequenceCount] = imageNumberTrackForDisplay, eventSequenceCount++;
                    arrayEventSequence [eventSequenceCount] = 43, eventSequenceCount++;
                    arrayEventSequence [eventSequenceCount] = arrayEventSequence [2], eventSequenceCount++;
                    arrayEventSequence [eventSequenceCount] = cellNumberTempInt, eventSequenceCount++;
                    
                    if (cellDivisionSetCount != 2){
                        cellDivisionSetCount = 2;
                        changeFlag = 1;
                    }
                    
                    eventSequenceHoldCount = 0;
                    
                    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4], eventSequenceHoldCount++;
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+1], eventSequenceHoldCount++;
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+2], eventSequenceHoldCount++;
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+3], eventSequenceHoldCount++;
                        }
                    }
                }
                else if (connectDivTemp3 == 0){
                    connectNoTemp = connectDivTemp3;
                    cellNumberTempInt = connectDivInt3;
                    
                    if (eventSequenceCount+4 > eventSequenceLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate eventSequenceUpDate];
                    }
                    
                    arrayEventSequence [eventSequenceCount] = imageNumberTrackForDisplay, eventSequenceCount++;
                    arrayEventSequence [eventSequenceCount] = 44, eventSequenceCount++;
                    arrayEventSequence [eventSequenceCount] = arrayEventSequence [2], eventSequenceCount++;
                    arrayEventSequence [eventSequenceCount] = cellNumberTempInt, eventSequenceCount++;
                    
                    if (cellDivisionSetCount != 3){
                        cellDivisionSetCount = 3;
                        changeFlag = 1;
                    }
                    
                    eventSequenceHoldCount = 0;
                    
                    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4], eventSequenceHoldCount++;
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+1], eventSequenceHoldCount++;
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+2], eventSequenceHoldCount++;
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+3], eventSequenceHoldCount++;
                        }
                    }
                }
                else cancelFlag = 1;
            }
            
            if (changeFlag == 1 || cancelFlag == 0){
                targetHoldCount = 0;
                targetHoldInfoCount = 0;
                
                for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                    arrayTimeSelected [counter1*10+1] = 0;
                    arrayTimeSelected [counter1*10+3] = 0;
                }
                
                if (cellDivisionSetCount == 1){
                    for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt1) arrayConnectLineageRel [counter1*6+4] = 1;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt2) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt3) arrayConnectLineageRel [counter1*6+4] = 0;
                    }
                }
                if (cellDivisionSetCount == 2){
                    for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt1) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt2) arrayConnectLineageRel [counter1*6+4] = 1;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt3) arrayConnectLineageRel [counter1*6+4] = 0;
                    }
                }
                if (cellDivisionSetCount == 3){
                    for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt1) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt2) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt3) arrayConnectLineageRel [counter1*6+4] = 1;
                    }
                }
            }
        }
    }
    if (divisionTypeHold == 4 && cellDivisionSetCount >= 1){
        string connectDivString1 = cellNoHoldDiv1.substr(1);
        string connectDivString2 = cellNoHoldDiv2.substr(1);
        string connectDivString3 = cellNoHoldDiv3.substr(1);
        string connectDivString4 = cellNoHoldDiv4.substr(1);
        int connectDivInt1 = atoi(connectDivString1.c_str());
        int connectDivInt2 = atoi(connectDivString2.c_str());
        int connectDivInt3 = atoi(connectDivString3.c_str());
        int connectDivInt4 = atoi(connectDivString4.c_str());
        
        int connectDivTemp1 = 0;
        int connectDivTemp2 = 0;
        int connectDivTemp3 = 0;
        int connectDivTemp4 = 0;
        int connectDivCountTemp1 = 0;
        int connectDivCountTemp2 = 0;
        int connectDivCountTemp3 = 0;
        int connectDivCountTemp4 = 0;
        int connectDivWholeCount1 = 0;
        int connectDivWholeCount2 = 0;
        int connectDivWholeCount3 = 0;
        int connectDivWholeCount4 = 0;
        int changeFlag = 0;
        
        for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
            if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt1) connectDivTemp1 = arrayConnectLineageRel [counter1*6+1];
            if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt2) connectDivTemp2 = arrayConnectLineageRel [counter1*6+1];
            if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt3) connectDivTemp3 = arrayConnectLineageRel [counter1*6+1];
            if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt4) connectDivTemp4 = arrayConnectLineageRel [counter1*6+1];
        }
        
        if (cellDivisionSetCount == 1 || cellDivisionSetCount == 2 || cellDivisionSetCount == 3 || cellDivisionSetCount == 4){
            int valueTemp = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                        valueTemp = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart];
                        
                        if (connectivityMap [counterY][counterX] != 0){
                            if (valueTemp != 0){
                                if (valueTemp == connectDivTemp1) connectDivCountTemp1++;
                                if (valueTemp == connectDivTemp2) connectDivCountTemp2++;
                                if (valueTemp == connectDivTemp3) connectDivCountTemp3++;
                                if (valueTemp == connectDivTemp4) connectDivCountTemp4++;
                            }
                        }
                        
                        if (valueTemp == connectDivTemp1) connectDivWholeCount1++;
                        if (valueTemp == connectDivTemp2) connectDivWholeCount2++;
                        if (valueTemp == connectDivTemp3) connectDivWholeCount3++;
                        if (valueTemp == connectDivTemp4) connectDivWholeCount4++;
                    }
                }
            }
            
            if (cellDivisionSetCount >= 1){
                if (connectDivCountTemp1 > connectDivCountTemp2 && connectDivCountTemp1 > connectDivCountTemp3 && connectDivCountTemp1 > connectDivCountTemp4 && connectDivCountTemp1 >= 50 && connectDivCountTemp1/(double)connectDivWholeCount1 > 0.5){
                    connectNoTemp = connectDivTemp1;
                    cellNumberTempInt = connectDivInt1;
                    
                    if (cellDivisionSetCount != 1){
                        cellDivisionSetCount = 1;
                        changeFlag = 1;
                    }
                }
                else if (connectDivCountTemp2 > connectDivCountTemp1 && connectDivCountTemp2 > connectDivCountTemp3 && connectDivCountTemp2 > connectDivCountTemp4 && connectDivCountTemp2 >= 50 && connectDivCountTemp2/(double)connectDivWholeCount2 > 0.5){
                    connectNoTemp = connectDivTemp2;
                    cellNumberTempInt = connectDivInt2;
                    
                    if (cellDivisionSetCount != 2){
                        cellDivisionSetCount = 2;
                        changeFlag = 1;
                    }
                }
                else if (connectDivCountTemp3 > connectDivCountTemp1 && connectDivCountTemp3 > connectDivCountTemp2 && connectDivCountTemp3 > connectDivCountTemp4 && connectDivCountTemp3 >= 50 && connectDivCountTemp3/(double)connectDivWholeCount3 > 0.5){
                    connectNoTemp = connectDivTemp3;
                    cellNumberTempInt = connectDivInt3;
                    
                    if (cellDivisionSetCount != 3){
                        cellDivisionSetCount = 3;
                        changeFlag = 1;
                    }
                }
                else if (connectDivCountTemp4 > connectDivCountTemp1 && connectDivCountTemp4 > connectDivCountTemp2 && connectDivCountTemp4 > connectDivCountTemp3 && connectDivCountTemp4 >= 50 && connectDivCountTemp4/(double)connectDivWholeCount4 > 0.5){
                    connectNoTemp = connectDivTemp4;
                    cellNumberTempInt = connectDivInt4;
                    
                    if (cellDivisionSetCount != 4){
                        cellDivisionSetCount = 4;
                        changeFlag = 1;
                    }
                }
                else if (connectDivTemp2 == 0){
                    connectNoTemp = connectDivTemp2;
                    cellNumberTempInt = connectDivInt2;
                    
                    if (eventSequenceCount+4 > eventSequenceLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate eventSequenceUpDate];
                    }
                    
                    arrayEventSequence [eventSequenceCount] = imageNumberTrackForDisplay, eventSequenceCount++;
                    arrayEventSequence [eventSequenceCount] = 53, eventSequenceCount++;
                    arrayEventSequence [eventSequenceCount] = arrayEventSequence [2], eventSequenceCount++;
                    arrayEventSequence [eventSequenceCount] = cellNumberTempInt, eventSequenceCount++;
                    
                    if (cellDivisionSetCount != 2){
                        cellDivisionSetCount = 2;
                        changeFlag = 1;
                    }
                    
                    eventSequenceHoldCount = 0;
                    
                    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4], eventSequenceHoldCount++;
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+1], eventSequenceHoldCount++;
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+2], eventSequenceHoldCount++;
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+3], eventSequenceHoldCount++;
                        }
                    }
                }
                else if (connectDivTemp3 == 0){
                    connectNoTemp = connectDivTemp3;
                    cellNumberTempInt = connectDivInt3;
                    
                    if (eventSequenceCount+4 > eventSequenceLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate eventSequenceUpDate];
                    }
                    
                    arrayEventSequence [eventSequenceCount] = imageNumberTrackForDisplay, eventSequenceCount++;
                    arrayEventSequence [eventSequenceCount] = 54, eventSequenceCount++;
                    arrayEventSequence [eventSequenceCount] = arrayEventSequence [2], eventSequenceCount++;
                    arrayEventSequence [eventSequenceCount] = cellNumberTempInt, eventSequenceCount++;
                    
                    if (cellDivisionSetCount != 3){
                        cellDivisionSetCount = 3;
                        changeFlag = 1;
                    }
                    
                    eventSequenceHoldCount = 0;
                    
                    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4], eventSequenceHoldCount++;
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+1], eventSequenceHoldCount++;
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+2], eventSequenceHoldCount++;
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+3], eventSequenceHoldCount++;
                        }
                    }
                }
                else if (connectDivTemp4 == 0){
                    connectNoTemp = connectDivTemp4;
                    cellNumberTempInt = connectDivInt4;
                    
                    if (eventSequenceCount+4 > eventSequenceLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate eventSequenceUpDate];
                    }
                    
                    arrayEventSequence [eventSequenceCount] = imageNumberTrackForDisplay, eventSequenceCount++;
                    arrayEventSequence [eventSequenceCount] = 55, eventSequenceCount++;
                    arrayEventSequence [eventSequenceCount] = arrayEventSequence [2], eventSequenceCount++;
                    arrayEventSequence [eventSequenceCount] = cellNumberTempInt, eventSequenceCount++;
                    
                    if (cellDivisionSetCount != 4){
                        cellDivisionSetCount = 4;
                        changeFlag = 1;
                    }
                    
                    eventSequenceHoldCount = 0;
                    
                    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4], eventSequenceHoldCount++;
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+1], eventSequenceHoldCount++;
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+2], eventSequenceHoldCount++;
                            arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+3], eventSequenceHoldCount++;
                        }
                    }
                }
                else cancelFlag = 1;
            }
            
            if (changeFlag == 1 || cancelFlag == 0){
                targetHoldCount = 0;
                targetHoldInfoCount = 0;
                
                for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                    arrayTimeSelected [counter1*10+1] = 0;
                    arrayTimeSelected [counter1*10+3] = 0;
                }
                
                if (cellDivisionSetCount == 1){
                    for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt1) arrayConnectLineageRel [counter1*6+4] = 1;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt2) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt3) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt4) arrayConnectLineageRel [counter1*6+4] = 0;
                    }
                }
                if (cellDivisionSetCount == 2){
                    for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt1) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt2) arrayConnectLineageRel [counter1*6+4] = 1;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt3) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt4) arrayConnectLineageRel [counter1*6+4] = 0;
                    }
                }
                if (cellDivisionSetCount == 3){
                    for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt1) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt2) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt3) arrayConnectLineageRel [counter1*6+4] = 1;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt4) arrayConnectLineageRel [counter1*6+4] = 0;
                    }
                }
                if (cellDivisionSetCount == 4){
                    for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt1) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt2) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt3) arrayConnectLineageRel [counter1*6+4] = 0;
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == connectDivInt4) arrayConnectLineageRel [counter1*6+4] = 1;
                    }
                }
            }
        }
    }
    
    //for (int counterA = 0; counterA < targetHoldCount/3; counterA++){
    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayTargetHold [counterA*3+counterB];
    //	cout<<" arrayTargetHold "<<counterA<<endl;
    //}
    
    //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
    //	cout<<" arrayConnectLineageRel "<<counterA<<endl;
    //}
    
    //for (int counterA = 0; counterA < dimension; counterA++){
    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
    //	cout<<" connectivityMap "<<counterA<<endl;
    //}
    
    //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
    //    cout<<" arrayEventSeque "<<counterA<<endl;
    //}
    
    //-----Get original connect No, use to check when new connect is not overlapped with original-----
    originalNoTemp = 0;
    
    for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt){
            originalNoTemp = arrayConnectLineageRel [counter1*6+1];
            break;
        }
    }
    
    //cout<<originalNoTemp<<" Original"<<endl;
    
    if (originalNoTemp != 0){
        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
            if (arrayTimeSelected [counter1*10+8] == originalNoTemp){
                if (arrayTimeSelected [counter1*10] == 3 || arrayTimeSelected [counter1*10] == 4){
                    originalNoTemp = 0;
                    break;
                }
            }
        }
    }
    
    //-----Overlap analysis-----
    int abortFlag = 0;
    
    if (cancelFlag == 0 && fusionOperation == 0){
        maxConnectNumberList = timeSelectedCount/10;
        
        int *overlapList = new int [maxConnectNumberList+2];
        int *overlapList2 = new int [maxConnectNumberList+2];
        int overlapListCount2 = 0;
        int *overlapList3 = new int [maxConnectNumberList+2];
        
        for (int counter1 = 0; counter1 < maxConnectNumberList+1; counter1++){
            overlapList [counter1] = 0;
            overlapList2 [counter1] = 0;
            overlapList3 [counter1] = 0;
        }
        
        //int TEST [dimension][dimension];
        
        //for (int counterY = 0; counterY < dimension; counterY++){
        //	for (int counterX = 0; counterX < dimension; counterX++) TEST [counterY][counterX] = 0;
        //}
        
        //int TEST2 [dimension][dimension];
        
        //for (int counterY = 0; counterY < dimension; counterY++){
        //	for (int counterX = 0; counterX < dimension; counterX++) TEST2 [counterY][counterX] = 0;
        //}
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] != 0){
                    if (rangeMatrix [counterY][counterX] == 0) connectivityMap [counterY][counterX] = 0;
                }
            }
        }
        
        connectivityNumber = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMap [counterY][counterX] == -1){
                    connectivityNumber++;
                    connectAnalysisCount = 0;
                    
                    if (connectivityNumber >= 1) connectivityMap [counterY][counterX] = connectivityNumber;
                    
                    if (counterY-1 >= 0 && connectivityMap [counterY-1][counterX] == -1){
                        connectivityMap [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension && connectivityMap [counterY][counterX+1] == -1){
                        connectivityMap [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && connectivityMap [counterY+1][counterX] == -1){
                        connectivityMap [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && connectivityMap [counterY][counterX-1] == -1){
                        connectivityMap [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && connectivityMap [ySource-1][xSource] == -1){
                                    connectivityMap [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension && connectivityMap [ySource][xSource+1] == -1){
                                    connectivityMap [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && connectivityMap [ySource+1][xSource] == -1){
                                    connectivityMap [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && connectivityMap [ySource][xSource-1] == -1){
                                    connectivityMap [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        int *mainConnectFindList = new int [connectivityNumber+2];
        
        for (int counter1 = 0; counter1 < connectivityNumber+2; counter1++) mainConnectFindList [counter1] = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                mainConnectFindList [connectivityMap [counterY][counterX]]++;
            }
        }
        
        //for (int counterA = 1; counterA <= connectivityNumber; counterA++) cout<<counterA<<" "<<mainConnectFindList [counterA]<<"  List"<<endl;
        
        int largestConnect = 0;
        int refConnectNo = 0;
        
        for (int counter1 = 1; counter1 < connectivityNumber+1; counter1++){
            if (mainConnectFindList [counter1] > largestConnect){
                largestConnect = mainConnectFindList [counter1];
                refConnectNo = counter1;
            }
        }
        
        delete [] mainConnectFindList;
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
        //    cout<<" connectivityMap "<<counterA<<endl;
        //}
        
        if (refConnectNo != 0){
            int connectivityMapArea = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMap [counterY][counterX] != 0 && connectivityMap [counterY][counterX] != refConnectNo) connectivityMap [counterY][counterX] = 0;
                    else if (connectivityMap [counterY][counterX] != 0){
                        connectivityMap [counterY][counterX] = 1;
                        connectivityMapArea++;
                    }
                }
            }
            
            int **connectivityUpdate5 = new int *[dimension+4];
            
            for (int counter1 = 0; counter1 < dimension+4; counter1++) connectivityUpdate5 [counter1] = new int [dimension+4];
            
            //-----Zero Fill-----
            for (int counterX = 0; counterX < dimension+2; counterX++){
                for (int counterY = 0; counterY < dimension+2; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = connectivityMap [counterY][counterX];
            }
            
            connectivityNumber = 0;
            
            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                    if (connectivityUpdate5 [counterY2][counterX2] == 0){
                        connectivityNumber--;
                        connectAnalysisCount = 0;
                        
                        connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                        
                        if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                            connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                        }
                        if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                            connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                            connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                        }
                        if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                            connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                        connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                        connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                        connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                        connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension+2; counterA++){
            //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
            //	cout<<" connectivityUpdate5 "<<counterA<<endl;
            //}
            
            int connectTemp2 = 0;
            
            if (connectivityNumber < -1){
                int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                
                for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
                
                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                        connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                        
                        if (connectTemp2 < -1){
                            connectTemp2 = connectTemp2*-1;
                            
                            if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                        }
                    }
                }
                
                int zeroFillFlag = 0;
                
                for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                    if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
                }
                
                //for (int counterA = 0; counterA < dimension+2; counterA++){
                //    for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                //    cout<<" connectivityUpdate5 "<<counterA<<endl;
                //}
                
                if (zeroFillFlag == 1){
                    for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                            connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                            
                            if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                        }
                    }
                    
                    for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                            if (connectivityUpdate5 [counterY2][counterX2] > 0) connectivityMap [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                        }
                    }
                }
                
                delete [] connectCheckArray;
            }
            
            for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] connectivityUpdate5 [counter1];
            
            delete [] connectivityUpdate5;
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
            //    cout<<" connectivityMap "<<counterA<<endl;
            //}
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    
                    //if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                    //    TEST [counterY][counterX] = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart];
                    //}
                    
                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] != 0){
                        
                        if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0){
                            overlapList [revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart]]++;
                            overlapList3 [revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart]] = rangeMatrix [counterY][counterX];
                        }
                        
                        if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0 && connectNoTemp == revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart]) abortFlag = 1;
                        if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0){
                            for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                                if (arrayConnectLineageRel [counter1*6+1] == revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] && arrayConnectLineageRel [counter1*6+4] == 0){
                                    connectivityMap [counterY][counterX] = 0;
                                    overlapList [revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart]] = 0;
                                    break;
                                }
                            }
                        }
                    }
                    else connectivityMap [counterY][counterX] = 0;
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
            //    cout<<" connectivityMap "<<counterA<<endl;
            //}
            
            //======internal zero check======
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++) internalZeroMap [counterY][counterX] = connectivityMap [counterY][counterX];
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<internalZeroMap [counterA][counterB];
            //    cout<<" internalZeroMap "<<counterA<<endl;
            //}
            
            connectivityNumber = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (internalZeroMap [counterY2][counterX2] == 0){
                        connectivityNumber--;
                        connectAnalysisCount = 0;
                        
                        internalZeroMap [counterY2][counterX2] = connectivityNumber;
                        
                        if (counterY2-1 >= 0 && internalZeroMap [counterY2-1][counterX2] == 0){
                            internalZeroMap [counterY2-1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                        }
                        if (counterX2+1 < dimension && internalZeroMap [counterY2][counterX2+1] == 0){
                            internalZeroMap [counterY2][counterX2+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        if (counterY2+1 < dimension && internalZeroMap [counterY2+1][counterX2] == 0){
                            internalZeroMap [counterY2+1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                        }
                        if (counterX2-1 >= 0 && internalZeroMap [counterY2][counterX2-1] == 0){
                            internalZeroMap [counterY2][counterX2-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && internalZeroMap [ySource-1][xSource] == 0){
                                        internalZeroMap [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && internalZeroMap [ySource][xSource+1] == 0){
                                        internalZeroMap [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && internalZeroMap [ySource+1][xSource] == 0){
                                        internalZeroMap [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && internalZeroMap [ySource][xSource-1] == 0){
                                        internalZeroMap [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<internalZeroMap [counterA][counterB];
            //	cout<<" internalZeroMap "<<counterA<<endl;
            //}
            
            //=====internal zero map========
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (internalZeroMap [counterY][counterX] >= -1) internalZeroMap [counterY][counterX] = 0;
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<internalZeroMap [counterA][counterB];
            //    cout<<" internalZeroMap "<<counterA<<endl;
            //}
            
            //cout<<connectNoTemp<<" "<<abortFlag<<" Abort"<<endl;
            
            //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
            //	cout<<" arrayConnectLineageRel "<<counterA+1<<endl;
            //}
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<TEST [counterA][counterB];
            //	cout<<" TEST "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<TEST2 [counterA][counterB];
            //	cout<<" TEST2 "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
            //	cout<<" connectivityMap "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < maxConnectNumberList+1; counterA++){
            //	cout<<counterA<<" "<<overlapList [counterA]<<" "<<overlapList3 [counterA]<<" Overlap"<<endl;
            //}
            
            int lostMarkSet = 0;
            
            if (processType == 2 || processType == 3){
                //=======Auto advance find next main=====
                
                int *overlapList4 = new int [maxConnectNumberList+2];
                int *overlapList5 = new int [maxConnectNumberList+2];
                int *overlapList6 = new int [maxConnectNumberList+2];
                
                for (int counter1 = 0; counter1 < maxConnectNumberList+1; counter1++){
                    overlapList4 [counter1] = 0;
                    overlapList5 [counter1] = 0;
                    overlapList6 [counter1] = 0;
                }
                
                int mainTarget = 0;
                int mainTargetCount = 0;
                int mainTargetValue = 0;
                
                for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                    if (mainTargetCount < overlapList [counter1]){
                        mainTarget = counter1;
                        mainTargetCount = overlapList [counter1];
                    }
                }
                
                refConnectNo = overlapList3 [mainTarget];
                
                for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
                    if (overlapList [counter1] != 0 && overlapList3 [counter1] == refConnectNo) overlapList2 [overlapListCount2] = counter1, overlapListCount2++;
                }
                
                for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                    for (int counter2 = 0; counter2 < overlapListCount2; counter2++){
                        if (arrayGravityCenterRev [counter1*6+4] == overlapList2 [counter2]){
                            overlapList4 [counter2] = arrayGravityCenterRev [counter1*6+2];
                            overlapList6 [counter2] = arrayGravityCenterRev [counter1*6+3];
                        }
                        
                        if (arrayGravityCenterRev [counter1*6+4] == mainTargetCount) mainTargetValue = arrayGravityCenterRev [counter1*6+3];
                    }
                }
                
                //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
                //	cout<<" arrayGravityCenterRev "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < overlapListCount2; counterA++){
                //    cout<<overlapList2 [counterA]<<"  "<<overlapList4 [counterA]<<"  "<<overlapList5 [counterA]<<" "<<overlapList6 [counterA]<<" List"<<endl;
                //}
                
                int pixelAreaCount = 0;
                
                int **revisedMapTemp = new int *[imageDimension+1];
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) revisedMapTemp [counter1] = new int [imageDimension+1];
                
                for (int counterY = 0; counterY < imageDimension; counterY++){
                    for (int counterX = 0; counterX < imageDimension; counterX++) revisedMapTemp [counterY][counterX] = 0;
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] != 0){
                            pixelAreaCount++;
                            revisedMapTemp [counterY+verticalStart][counterX+horizontalStart] = 1;
                        }
                    }
                }
                
                //for (int counterA = 250; counterA < 350; counterA++){
                //	for (int counterB = 950; counterB < 1050; counterB++) cout<<" "<<revisedMapTemp [counterA][counterB];
                //	cout<<" revisedMapTemp "<<counterA<<endl;
                //}
                
                if (pixelAreaCount > 10){
                    pixelAreaCount = 0;
                    
                    for (int counterY = 0; counterY < imageDimension; counterY++){
                        for (int counterX = 0; counterX < imageDimension; counterX++){
                            if (revisedWorkingMap [counterY][counterX] != 0){
                                for (int counter1 = 0; counter1 < overlapListCount2; counter1++){
                                    if (revisedWorkingMap [counterY][counterX] == overlapList2 [counter1]){
                                        pixelAreaCount++;
                                        
                                        if (revisedMapTemp [counterY][counterX] != 1) revisedMapTemp [counterY][counterX] = overlapList2 [counter1]*-1;
                                    }
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < overlapListCount2; counterA++){
                    //    cout<<overlapList2 [counterA]<<" "<<overlapList4 [counterA]<<" overlapList"<<endl;
                    //}
                    
                    if (pixelAreaCount > 10){
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++) connectivityMap [counterY][counterX] = 0;
                        }
                        
                        int **sourceImageTemp = new int *[dimension+1];
                        for (int counter1 = 0; counter1 < dimension+1; counter1++) sourceImageTemp [counter1] = new int [dimension+1];
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                    if (revisedMapTemp [counterY+verticalStart][counterX+horizontalStart] != 0) connectivityMap [counterY][counterX] = revisedMapTemp [counterY+verticalStart][counterX+horizontalStart];
                                    sourceImageTemp [counterY][counterX] = sourceImage [counterY+verticalStart][counterX+horizontalStart];
                                }
                            }
                        }
                        
                        pixelAreaCount = 0;
                        int connectivityMapArea3 = 0;
                        
                        int **connectivityMap2 = new int *[dimension+1];
                        int **connectivityMap3 = new int *[dimension+1];
                        
                        for (int counter1 = 0; counter1 < dimension+1; counter1++){
                            connectivityMap2 [counter1] = new int [dimension+1];
                            connectivityMap3 [counter1] = new int [dimension+1];
                        }
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                connectivityMap2 [counterY][counterX] = connectivityMap [counterY][counterX];
                                
                                if (connectivityMap [counterY][counterX] == 1 && sourceImageTemp [counterY][counterX] != 100){
                                    mainTargetValue = mainTargetValue+sourceImageTemp [counterY][counterX];
                                    pixelAreaCount++;
                                }
                                
                                if (connectivityMap [counterY][counterX] == 1){
                                    connectivityMap3 [counterY][counterX] = 1;
                                    connectivityMapArea3++;
                                }
                                else connectivityMap3 [counterY][counterX] = 0;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<sourceImageTemp [counterA][counterB];
                        //	cout<<" sourceImageTemp "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap3 [counterA][counterB];
                        //	cout<<" connectivityMap3 "<<counterA<<endl;
                        //}
                        
                        int areaCount = 0;
                        int areaAddCount = 0;
                        int roundCount = 0;
                        double areaLimitFactor = 0;
                        
                        mainTargetValue = (int)(mainTargetValue/(double)pixelAreaCount);
                        
                        if (connectMapAreaOriginal*0.5 > pixelAreaCount) areaLimitFactor = 1.1;
                        else areaLimitFactor = 0.8;
                        
                        do{
                            
                            terminationFlag = 1;
                            areaCount = 0;
                            roundCount++;
                            areaAddCount = 0;
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (connectivityMap [counterY][counterX] == 1){
                                        if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMap [counterY-1][counterX-1] < 0){
                                            connectivityMap2 [counterY-1][counterX-1] = 1;
                                            areaAddCount++;
                                        }
                                        if (counterY-1 >= 0 && connectivityMap [counterY-1][counterX] < 0){
                                            connectivityMap2 [counterY-1][counterX] = 1;
                                            areaAddCount++;
                                        }
                                        if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMap [counterY-1][counterX+1] < 0){
                                            connectivityMap2 [counterY-1][counterX+1] = 1;
                                            areaAddCount++;
                                        }
                                        if (counterX+1 < dimension && connectivityMap [counterY][counterX+1] < 0){
                                            connectivityMap2 [counterY][counterX+1] = 1;
                                            areaAddCount++;
                                        }
                                        if (counterY+1 < dimension && counterX+1 < dimension && connectivityMap [counterY+1][counterX+1] < 0){
                                            connectivityMap2 [counterY+1][counterX+1] = 1;
                                            areaAddCount++;
                                        }
                                        if (counterY+1 < dimension && connectivityMap [counterY+1][counterX] < 0){
                                            connectivityMap2 [counterY+1][counterX] = 1;
                                            areaAddCount++;
                                        }
                                        if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMap [counterY+1][counterX-1] < 0){
                                            connectivityMap2 [counterY+1][counterX-1] = 1;
                                            areaAddCount++;
                                        }
                                        if (counterX-1 >= 0 && connectivityMap [counterY][counterX-1] < 0){
                                            connectivityMap2 [counterY][counterX-1] = 1;
                                            areaAddCount++;
                                        }
                                    }
                                }
                            }
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    connectivityMap [counterY][counterX] = connectivityMap2 [counterY][counterX];
                                    
                                    if (connectivityMap [counterY][counterX] == 1) areaCount++;
                                }
                            }
                            
                            //cout<<roundCount<<" "<<connectMapAreaOriginal*areaLimitFactor<<" "<<areaCount<<" Status"<<endl;
                            
                            if ((roundCount >= 3 && connectMapAreaOriginal*areaLimitFactor < areaCount) || areaAddCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (connectivityMap [counterY][counterX] < 0){
                                    for (int counter1 = 0; counter1 < overlapListCount2; counter1++){
                                        if (overlapList2 [counter1] == connectivityMap [counterY][counterX]*-1){
                                            overlapList5 [counter1]++;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < overlapListCount2; counter1++){
                            if (overlapList6 [counter1] < mainTargetValue-20 || overlapList6 [counter1] > mainTargetValue+40) overlapList2 [counter1] = 0;
                            else if (overlapList5 [counter1]/(double)overlapList4 [counter1] > 0.7) overlapList2 [counter1] = 0;
                        }
                        
                        //for (int counterA = 0; counterA < overlapListCount2; counterA++){
                        //    cout<<overlapList2 [counterA]<<"  "<<overlapList4 [counterA]<<"  "<<overlapList5 [counterA]<<" "<<overlapList6 [counterA]<<" List2"<<endl;
                        //}
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (connectivityMap [counterY][counterX] < 0){
                                    for (int counter1 = 0; counter1 < overlapListCount2; counter1++){
                                        if (overlapList2 [counter1] != 0) connectivityMap [counterY][counterX] = 1;
                                        else connectivityMap [counterY][counterX] = 0;
                                    }
                                }
                                else if (connectivityMap [counterY][counterX] == 1) connectivityMap [counterY][counterX] = 1;
                            }
                        }
                        
                        if (connectivityMapArea3 > connectivityMapArea*0.5){
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++) connectivityMap2 [counterY][counterX] = 0;
                            }
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (connectivityMap3 [counterY][counterX] == 1) connectivityMap2 [counterY][counterX] = 1;
                                    if (connectivityMap [counterY][counterX] == 1 && connectivityMap3 [counterY][counterX] == 0) connectivityMap3 [counterY][counterX] = 2;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < 2; counter1++){
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++){
                                        if (connectivityMap3 [counterY][counterX] == 1){
                                            if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMap3 [counterY-1][counterX-1] == 2) connectivityMap2 [counterY-1][counterX-1] = 1;
                                            if (counterY-1 >= 0 && connectivityMap3 [counterY-1][counterX] == 2) connectivityMap2 [counterY-1][counterX] = 1;
                                            if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMap3 [counterY-1][counterX+1] == 2) connectivityMap2 [counterY-1][counterX+1] = 1;
                                            if (counterX+1 < dimension && connectivityMap3 [counterY][counterX+1] == 2) connectivityMap2 [counterY][counterX+1] = 1;
                                            if (counterY+1 < dimension && counterX+1 < dimension && connectivityMap3 [counterY+1][counterX+1] == 2) connectivityMap2 [counterY+1][counterX+1] = 1;
                                            if (counterY+1 < dimension && connectivityMap3 [counterY+1][counterX] == 2) connectivityMap2 [counterY+1][counterX] = 1;
                                            if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMap3 [counterY+1][counterX-1] == 2) connectivityMap2 [counterY+1][counterX-1] = 1;
                                            if (counterX-1 >= 0 && connectivityMap3 [counterY][counterX-1] == 2) connectivityMap2 [counterY][counterX-1] = 1;
                                        }
                                    }
                                }
                                
                                for (int counterY = 0; counterY < dimension; counterY++){
                                    for (int counterX = 0; counterX < dimension; counterX++) connectivityMap3 [counterY][counterX] = connectivityMap2 [counterY][counterX];
                                }
                            }
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (connectivityMap [counterY][counterX] == 1 && connectivityMap3 [counterY][counterX] == 0) connectivityMap [counterY][counterX] = 0;
                                }
                            }
                        }
                        
                        connectivityUpdate5 = new int *[dimension+4];
                        
                        for (int counter1 = 0; counter1 < dimension+4; counter1++) connectivityUpdate5 [counter1] = new int [dimension+4];
                        
                        //-----Zero Fill-----
                        for (int counterX = 0; counterX < dimension+2; counterX++){
                            for (int counterY = 0; counterY < dimension+2; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
                        }
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = connectivityMap [counterY][counterX];
                        }
                        
                        connectivityNumber = 0;
                        
                        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                if (connectivityUpdate5 [counterY2][counterX2] == 0){
                                    connectivityNumber--;
                                    connectAnalysisCount = 0;
                                    
                                    connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                                    
                                    if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                                        connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                    }
                                    if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                        connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                    }
                                    if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                        connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                    }
                                    if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                        connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                    }
                                    
                                    if (connectAnalysisCount != 0){
                                        do{
                                            
                                            terminationFlag = 1;
                                            connectAnalysisTempCount = 0;
                                            
                                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                                
                                                if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                                    connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                                    connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                                    connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                                    connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                            }
                                            
                                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                            }
                                            
                                            connectAnalysisCount = connectAnalysisTempCount;
                                            
                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension+2; counterA++){
                        //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                        //	cout<<" connectivityUpdate5 "<<counterA<<endl;
                        //}
                        
                        if (connectivityNumber < -1){
                            int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                            
                            for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
                            
                            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                    connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                                    
                                    if (connectTemp2 < -1){
                                        connectTemp2 = connectTemp2*-1;
                                        
                                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                        if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                        }
                                    }
                                }
                            }
                            
                            int zeroFillFlag = 0;
                            
                            for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                                if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
                            }
                            
                            //for (int counterA = 0; counterA < dimension+2; counterA++){
                            //    for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                            //    cout<<" connectivityUpdate5 "<<counterA<<endl;
                            //}
                            
                            if (zeroFillFlag == 1){
                                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                        connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                                        
                                        if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                                    }
                                }
                                
                                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                        if (connectivityUpdate5 [counterY2][counterX2] > 0) connectivityMap [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                                    }
                                }
                            }
                            
                            delete [] connectCheckArray;
                        }
                        
                        for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] connectivityUpdate5 [counter1];
                        
                        delete [] connectivityUpdate5;
                        
                        for (int counter1 = 0; counter1 < dimension+1; counter1++){
                            delete [] connectivityMap2 [counter1];
                            delete [] connectivityMap3 [counter1];
                            delete [] sourceImageTemp [counter1];
                        }
                        
                        delete [] connectivityMap2;
                        delete [] connectivityMap3;
                        delete [] sourceImageTemp;
                    }
                    else{
                        
                        if (processType != 3){
                            if (targetLostMark == ""){
                                targetLostMark = "Lost-"+to_string (imageNumberTrackForDisplay);
                                lostMarkSet = 1;
                            }
                            
                            if (startPointFind == 0){
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                            
                            if (startPointFind == 1 && lostMarkSet == 1){
                                targetLostMark = "";
                            }
                        }
                        
                        cancelFlag = 1;
                    }
                }
                else{
                    
                    if (processType != 3){
                        if (targetLostMark == ""){
                            targetLostMark = "Lost-"+to_string (imageNumberTrackForDisplay);
                            lostMarkSet = 1;
                        }
                        
                        if (startPointFind == 0){
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                        
                        if (startPointFind == 1 && lostMarkSet == 1){
                            targetLostMark = "";
                        }
                    }
                    
                    cancelFlag = 1;
                }
                
                if (lostMarkSet == 1 && processType != 3){
                    int lineageEntryFind = 0;
                    
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+2] == imageNumberTrackForDisplay && arrayLineageData [counter1*8+5] == cellNumberTempInt && arrayLineageData [counter1*8+6] == cellLineageTempInt){
                            lineageEntryFind = 1;
                            break;
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay && lineageEntryFind == 0) arrayEventSequence [counter1*4] = 0;
                    }
                }
                
                //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
                //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
                //	cout<<" arrayEventSequence "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] revisedMapTemp [counter1];
                delete [] revisedMapTemp;
                
                delete [] overlapList4;
                delete [] overlapList5;
                delete [] overlapList6;
            }
        }
        else cancelFlag = 1;
        
        delete [] overlapList;
        delete [] overlapList2;
        delete [] overlapList3;
    }
    
    //for (int counterA = 0; counterA < dimension; counterA++){
    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
    //    cout<<" connectivityMap "<<counterA<<endl;
    //}
    
    int fusionPartnerOriginalConn = 0;
    
    if (fusionOperation == 1){
        //=========1. Lineage No, 2. connect No, 3. image number, 4. cell no, 5. target (0: non-target, 1: target), 6. reserve=========
        maxConnectNumberList = timeSelectedCount/10;
        
        int *overlapList = new int [maxConnectNumberList+2];
        int *overlapList2 = new int [maxConnectNumberList+2];
        int *overlapList3 = new int [maxConnectNumberList+2];
        
        for (int counter1 = 0; counter1 < maxConnectNumberList+1; counter1++){
            overlapList [counter1] = 0;
            overlapList2 [counter1] = 0;
            overlapList3 [counter1] = 0;
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] != 0){
                    overlapList [revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart]]++;
                }
            }
        }
        
        //for (int counterA = 1; counterA < maxConnectNumberList+1; counterA++) cout<<counterA<<" "<< overlapList [counterA] <<" OverLap"<<endl;
        
        int connectMatchFind = 0;
        int cellNoMatchFind = 0;
        
        for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
            if (overlapList [counter1] != 0 && counter1 != cellLineageTempInt){
                connectMatchFind = 0;
                cellNoMatchFind = 0;
                
                for (int counter2 = 0; counter2 < connectLineageRelCount/6; counter2++){
                    if (arrayConnectLineageRel [counter2*6+1] == counter1 && arrayConnectLineageRel [counter2*6+4] != 1){
                        connectMatchFind = arrayConnectLineageRel [counter2*6];
                        cellNoMatchFind = arrayConnectLineageRel [counter2*6+3];
                    }
                }
                
                if (connectMatchFind != 0){
                    overlapList2 [counter1] = connectMatchFind;
                    overlapList3 [counter1] = cellNoMatchFind;
                }
            }
        }
        
        int maxAreaConnect = 0;
        int maxAreaCount = 0;
        int maxAreaConnectCellNo = -1;
        
        for (int counter1 = 1; counter1 < maxConnectNumberList+1; counter1++){
            if (overlapList2 [counter1] != 0){
                if (overlapList [counter1] > maxAreaConnect){
                    maxAreaConnect = overlapList [counter1];
                    maxAreaCount = overlapList2 [counter1];
                    maxAreaConnectCellNo = overlapList3 [counter1];
                }
            }
        }
        
        if (maxAreaCount == 0) cancelFlag = 1;
        else{
            
            fusionPartnerLin = maxAreaCount;
            fusionPartnerCellNo = maxAreaConnectCellNo;
            fusionStatusFollow = 1;
            
            //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
            //    cout<<" arrayConnectLineageRel "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                if (arrayConnectLineageRel [counter1*6] == fusionPartnerLin && arrayConnectLineageRel [counter1*6+3] == fusionPartnerCellNo) fusionPartnerOriginalConn = arrayConnectLineageRel [counter1*6+1];
            }
            
            int lineageEnd = 0; //-----Image no-----
            
            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                if (arrayLineageStartEnd [counter1*8] == fusionPartnerLin && arrayLineageStartEnd [counter1*8+1] == fusionPartnerCellNo){
                    lineageEnd = arrayLineageStartEnd [counter1*8+7];
                    break;
                }
            }
            
            if (imageNumberTrackForDisplay != lineageEnd){
                targetHoldCount = 0;
                targetHoldInfoCount = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] != 0){
                            if (rangeMatrix [counterY][counterX] == 0) connectivityMap [counterY][counterX] = 0;
                        }
                    }
                }
                
                connectivityNumber = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMap [counterY][counterX] == -1){
                            connectivityNumber++;
                            connectAnalysisCount = 0;
                            
                            if (connectivityNumber >= 1) connectivityMap [counterY][counterX] = connectivityNumber;
                            
                            if (counterY-1 >= 0 && connectivityMap [counterY-1][counterX] == -1){
                                connectivityMap [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension && connectivityMap [counterY][counterX+1] == -1){
                                connectivityMap [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && connectivityMap [counterY+1][counterX] == -1){
                                connectivityMap [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && connectivityMap [counterY][counterX-1] == -1){
                                connectivityMap [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                        xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                        
                                        if (ySource-1 >= 0 && connectivityMap [ySource-1][xSource] == -1){
                                            connectivityMap [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension && connectivityMap [ySource][xSource+1] == -1){
                                            connectivityMap [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && connectivityMap [ySource+1][xSource] == -1){
                                            connectivityMap [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && connectivityMap [ySource][xSource-1] == -1){
                                            connectivityMap [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                        connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                int *mainConnectFindList = new int [connectivityNumber+2];
                
                for (int counter1 = 0; counter1 < connectivityNumber+2; counter1++) mainConnectFindList [counter1] = 0;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        mainConnectFindList [connectivityMap [counterY][counterX]]++;
                    }
                }
                
                int largestConnect = 0;
                int refConnectNo = 0;
                
                for (int counter1 = 1; counter1 < connectivityNumber+1; counter1++){
                    if (mainConnectFindList [counter1] > largestConnect){
                        largestConnect = mainConnectFindList [counter1];
                        refConnectNo = counter1;
                    }
                }
                
                delete [] mainConnectFindList;
                
                if (refConnectNo != 0){
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMap [counterY][counterX] != 0 && connectivityMap [counterY][counterX] != refConnectNo) connectivityMap [counterY][counterX] = 0;
                            else if (connectivityMap [counterY][counterX] != 0) connectivityMap [counterY][counterX] = 1;
                        }
                    }
                    
                    int **connectivityUpdate5 = new int *[dimension+4];
                    
                    for (int counter1 = 0; counter1 < dimension+4; counter1++) connectivityUpdate5 [counter1] = new int [dimension+4];
                    
                    //-----Zero Fill-----
                    for (int counterX = 0; counterX < dimension+2; counterX++){
                        for (int counterY = 0; counterY < dimension+2; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = connectivityMap [counterY][counterX];
                    }
                    
                    connectivityNumber = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                            if (connectivityUpdate5 [counterY2][counterX2] == 0){
                                connectivityNumber--;
                                connectAnalysisCount = 0;
                                
                                connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                                
                                if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                                    connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                }
                                if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                    connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                    connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                }
                                if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                    connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                            
                                            if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                                connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                                connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                                connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                                connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension+2; counterA++){
                    //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                    //	cout<<" connectivityUpdate5 "<<counterA<<endl;
                    //}
                    
                    int connectTemp2 = 0;
                    
                    if (connectivityNumber < -1){
                        int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                        
                        for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
                        
                        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                                
                                if (connectTemp2 < -1){
                                    connectTemp2 = connectTemp2*-1;
                                    
                                    if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                }
                            }
                        }
                        
                        int zeroFillFlag = 0;
                        
                        for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                            if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
                        }
                        
                        //for (int counterA = 0; counterA < dimension+2; counterA++){
                        //    for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                        //    cout<<" connectivityUpdate5 "<<counterA<<endl;
                        //}
                        
                        if (zeroFillFlag == 1){
                            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                    connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                                    
                                    if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                                }
                            }
                            
                            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                    if (connectivityUpdate5 [counterY2][counterX2] > 0) connectivityMap [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                                }
                            }
                        }
                        
                        delete [] connectCheckArray;
                    }
                    
                    for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] connectivityUpdate5 [counter1];
                    
                    delete [] connectivityUpdate5;
                    
                    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                        arrayTimeSelected [counter1*10+1] = 0;
                        arrayTimeSelected [counter1*10+3] = 0;
                    }
                    for (int counter1 = 0; counter1 < maxConnectNumberList+1; counter1++) overlapList [counter1] = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] != 0){
                                overlapList [revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart]]++;
                                
                                if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0){
                                    for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                                        if (arrayConnectLineageRel [counter1*6+1] == revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] && arrayConnectLineageRel [counter1*6+4] == 0 && (arrayConnectLineageRel [counter1*6] != fusionPartnerLin || arrayConnectLineageRel [counter1*6+3] != fusionPartnerCellNo)){
                                            connectivityMap [counterY][counterX] = 0;
                                            overlapList [revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart]] = 0;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    //======internal zero check======
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) internalZeroMap [counterY][counterX] = connectivityMap [counterY][counterX];
                    }
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<internalZeroMap [counterA][counterB];
                    //    cout<<" internalZeroMap "<<counterA<<endl;
                    //}
                    
                    connectivityNumber = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (internalZeroMap [counterY2][counterX2] == 0){
                                connectivityNumber--;
                                connectAnalysisCount = 0;
                                
                                internalZeroMap [counterY2][counterX2] = connectivityNumber;
                                
                                if (counterY2-1 >= 0 && internalZeroMap [counterY2-1][counterX2] == 0){
                                    internalZeroMap [counterY2-1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                }
                                if (counterX2+1 < dimension && internalZeroMap [counterY2][counterX2+1] == 0){
                                    internalZeroMap [counterY2][counterX2+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                if (counterY2+1 < dimension && internalZeroMap [counterY2+1][counterX2] == 0){
                                    internalZeroMap [counterY2+1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                }
                                if (counterX2-1 >= 0 && internalZeroMap [counterY2][counterX2-1] == 0){
                                    internalZeroMap [counterY2][counterX2-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                            
                                            if (ySource-1 >= 0 && internalZeroMap [ySource-1][xSource] == 0){
                                                internalZeroMap [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && internalZeroMap [ySource][xSource+1] == 0){
                                                internalZeroMap [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && internalZeroMap [ySource+1][xSource] == 0){
                                                internalZeroMap [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && internalZeroMap [ySource][xSource-1] == 0){
                                                internalZeroMap [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<internalZeroMap [counterA][counterB];
                    //    cout<<" internalZeroMap "<<counterA<<endl;
                    //}
                    
                    //=====internal zero map========
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (internalZeroMap [counterY][counterX] >= -1) internalZeroMap [counterY][counterX] = 0;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
                    //	cout<<" connectivityMap "<<counterA<<endl;
                    //}
                    
                    //-----Check whether fusion partner is occupied by other marks-----
                    int occupyCheck = 0;
                    
                    for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                        if (fusionPartnerLin == arrayLineageStartEnd [counter1*8] && fusionPartnerCellNo == arrayLineageStartEnd [counter1*8+1]){
                            for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                                if (arrayLineageData [counter2*8+2] == imageNumberTrackForDisplay && (arrayLineageData [counter2*8+3] == 2 || arrayLineageData [counter2*8+3] == 10)){
                                    occupyCheck = 1;
                                    break;
                                }
                            }
                        }
                        if (occupyCheck == 1){
                            break;
                        }
                    }
                    
                    //cout<<occupyCheck<<" OccupyCheck"<<endl;
                    
                    if (occupyCheck == 0){
                        fusionOperation = 0;
                        fusionPartnerLin = 0;
                        fusionPartnerCellNo = -1;
                        fusionStatusFollow = 0;
                        keyLockON = 0;
                        divisionWarning = "FU_Occupied";
                        divisionWarningType = 2;
                        cancelFlag = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    fusionOperation = 0;
                    fusionPartnerLin = 0;
                    fusionPartnerCellNo = -1;
                    fusionStatusFollow = 0;
                    keyLockON = 0;
                    divisionWarning = "FU_NoCount.";
                    divisionWarningType = 2;
                    cancelFlag = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                fusionOperation = 0;
                fusionPartnerLin = 0;
                fusionPartnerCellNo = -1;
                fusionStatusFollow = 0;
                keyLockON = 0;
                divisionWarning = "FU_LineEnd";
                divisionWarningType = 2;
                cancelFlag = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        delete [] overlapList;
        delete [] overlapList2;
        delete [] overlapList3;
    }
    
    //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
    //    cout<<" arrayEventSequence "<<counterA<<endl;
    //}
    
    if (cancelFlag == 1 || (abortFlag == 0 && (firstModificationPoint == imageNumberTrackForDisplay || firstModificationPoint == 10000))){
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            delete [] connectivityMap [counter1];
            delete [] internalZeroMap [counter1];
            delete [] targetMap [counter1];
        }
        
        delete [] connectivityMap;
        delete [] internalZeroMap;
        delete [] targetMap;
    }
    else if (abortFlag == 1 || firstModificationPoint != imageNumberTrackForDisplay){
        int type = 1;
        int valueTemp = 1;
        resultsType1 = [self areaProcess:type:dimension:valueTemp:horizontalStart:verticalStart:processType:startPointFind]; //-----ResultsType1: Hold target Connect No-----
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        // 	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
        // 	cout<<" connectivityMap "<<counterA<<endl;
        //}
        
        int *connectNumber = new int [dimension*dimension+50];
        int connectNumberCount = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] != 0 && revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0 && internalZeroMap [counterY][counterX] == 0) connectNumber [connectNumberCount] = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart], connectNumberCount++;
            }
        }
        
        if (resultsType1 != 0){
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] != 0 && internalZeroMap [counterY][counterX] == 0) revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] = connectivityMap [counterY][counterX];
                }
            }
        }
        
        //==========
        //int **sourceImageAAA = new int *[dimension+1]; //=======For check
        
        //for (int counterA = 0; counterA < dimension+1; counterA++){
        //    sourceImageAAA [counterA] = new int [dimension+1];
        //}
        
        //for (int counterY = 0; counterY < dimension; counterY++){
        //    for (int counterX = 0; counterX < dimension; counterX++){
        //        sourceImageAAA [counterY][counterX] = 0;
        //    }
        //}
        
        //for (int counterY = 0; counterY < imageDimension; counterY++){
        //    for (int counterX = 0; counterX < imageDimension; counterX++){
        //        if (counterY-verticalStart >= 0 && counterY-verticalStart < dimension && counterX-horizontalStart >= 0 && counterX-horizontalStart < dimension){
        //            if (revisedWorkingMap [counterY][counterX] != 0){
        //                sourceImageAAA [counterY-verticalStart][counterX-horizontalStart] = revisedWorkingMap [counterY][counterX];
        //            }
        //        }
        //    }
        //}
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<sourceImageAAA [counterA][counterB];
        //    cout<<" sourceImageA "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < dimension+1; counterA++){
        //    delete [] sourceImageAAA [counterA];
        //}
        
        //delete [] sourceImageAAA;
        //==========
        
        if (resultsType1 != 0){
            int numberOfRemaining = 0;
            
            int *connectSort = new int [connectNumberCount+4];
            int *connectNumberList = new int [connectNumberCount+4];
            
            if (connectNumberCount != 0){
                int valueTemp3 = 0;
                
                for (int counter1 = 0; counter1 < connectNumberCount; counter1++){
                    connectSort [counter1] = 0;
                    connectNumberList [counter1] = connectNumber [counter1];
                }
                
                for (int counter1 = 0; counter1 < connectNumberCount-1; counter1++){
                    if (connectSort [counter1] == 0) valueTemp3 = connectNumberList [counter1];
                    
                    for (int counter2 = counter1+1; counter2 < connectNumberCount; counter2++){
                        if (connectNumberList [counter2] == valueTemp3) connectSort [counter2] = 1;
                    }
                }
                
                //for (int counterA = 0; counterA < counterMax; counterA++){
                //	cout<<counterA<<" "<<connectSort [counterA]<<" "<<connectNumberList [counterA]<<" ConnectList"<<endl;
                //}
                
                for (int counter1 = 0; counter1 < connectNumberCount; counter1++){
                    if (connectSort [counter1] == 0) numberOfRemaining++;
                }
            }
            
            int *connectProcessList = new int [numberOfRemaining+10];
            
            if (connectNumberCount != 0){
                int entryCount = 0; //-----List of connect that to be processed-----
                
                for (int counter1 = 0; counter1 < connectNumberCount; counter1++){
                    if (connectSort [counter1] == 0) connectProcessList [entryCount] = connectNumberList [counter1], entryCount++;
                }
                
                int originalNoTempFind = 0;
                
                for (int counter1 = 0; counter1 < numberOfRemaining; counter1++){
                    if (connectProcessList [counter1] == originalNoTemp) originalNoTempFind = 1;
                }
                
                if (originalNoTempFind == 0 && originalNoTemp != 0){
                    numberOfRemaining++;
                    connectProcessList [entryCount] = originalNoTemp;
                }
                
                //for (int counterA = 0; counterA < numberOfRemaining; counterA++){
                //	cout<<counterA<<" "<<connectProcessList [counterA]<<" ConnectProcessList"<<endl;
                //}
            }
            
            if (connectNumberCount == 0 && originalNoTemp != 0){
                numberOfRemaining++;
                connectProcessList [0] = originalNoTemp;
            }
            
            //for (int counterA = 0; counterA < numberOfRemaining; counterA++){
            //	cout<<counterA<<" "<<connectProcessList [counterA]<<" ConnectProcessList2"<<endl;
            //}
            
            //cout<<numberOfRemaining<<" "<<originalNoTemp<<" "<<connectNumberCount<<" Proceed"<<endl;
            
            delete [] connectSort;
            delete [] connectNumberList;
            
            if (numberOfRemaining != 0){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) targetMap [counterY][counterX] = connectivityMap [counterY][counterX];
                }
                
                int zeroFillFlag = 0;
                int maxConnectNumberList2 = 0;
                int insideFind = 0;
                int edgeCheck = 0;
                int connectTemp2 = 0;
                
                for (int counter1 = 0; counter1 < numberOfRemaining; counter1++){
                    valueTemp = connectProcessList [counter1];
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) connectivityMap [counterY][counterX] = 0;
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] == valueTemp && rangeMatrix [counterY][counterX] != 0){
                                connectivityMap [counterY][counterX] = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart];
                            }
                        }
                    }
                    
                    //========zero fill=========
                    int **connectivityUpdate5 = new int *[dimension+4];
                    
                    for (int counter2 = 0; counter2 < dimension+4; counter2++) connectivityUpdate5 [counter2] = new int [dimension+4];
                    
                    //-----Zero Fill-----
                    for (int counterX = 0; counterX < dimension+2; counterX++){
                        for (int counterY = 0; counterY < dimension+2; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = connectivityMap [counterY][counterX];
                    }
                    
                    connectivityNumber = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                            if (connectivityUpdate5 [counterY2][counterX2] == 0){
                                connectivityNumber--;
                                connectAnalysisCount = 0;
                                
                                connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                                
                                if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                                    connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                }
                                if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                    connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                    connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                }
                                if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                    connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                            xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                            
                                            if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                                connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                                connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                                connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                                connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                            connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension+2; counterA++){
                    //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
                    //	cout<<" connectivityUpdate5 "<<counterA<<endl;
                    //}
                    
                    if (connectivityNumber < -1){
                        int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                        
                        for (int counter2 = 0; counter2 < connectivityNumber*-1*2+5; counter2++) connectCheckArray [counter2] = 0;
                        
                        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                                
                                if (connectTemp2 < -1){
                                    connectTemp2 = connectTemp2*-1;
                                    
                                    if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                    if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                        if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                        else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                                    }
                                }
                            }
                        }
                        
                        zeroFillFlag = 0;
                        
                        for (int counter2 = 2; counter2 <= connectivityNumber*-1; counter2++){
                            if (connectCheckArray [counter2*2] != 0 && connectCheckArray [counter2*2+1] == 0) zeroFillFlag = 1;
                        }
                        
                        if (zeroFillFlag == 1){
                            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                    connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                                    
                                    if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                                }
                            }
                            
                            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                                    if (connectivityUpdate5 [counterY2][counterX2] > 0) connectivityMap [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                                }
                            }
                        }
                        
                        delete [] connectCheckArray;
                    }
                    
                    for (int counter2 = 0; counter2 < dimension+4; counter2++) delete [] connectivityUpdate5 [counter2];
                    
                    delete [] connectivityUpdate5;
                    
                    //======inside check=====
                    int **insideCheckMap = new int *[dimension+1];
                    
                    for (int counter2 = 0; counter2 < dimension+1; counter2++) insideCheckMap [counter2] = new int [dimension+1];
                    
                    for (int counterY = 0; counterY < dimension+1; counterY++){
                        for (int counterX = 0; counterX < dimension+1; counterX++) insideCheckMap [counterY][counterX] = 0;
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) insideCheckMap [counterY][counterX] = 0;
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] != 0){
                                insideCheckMap [counterY][counterX] = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart];
                            }
                        }
                    }
                    
                    maxConnectNumberList2 = timeSelectedCount/10;
                    
                    int *insideCheck = new int [maxConnectNumberList2*2+5];
                    
                    for (int counter2 = 0; counter2 < maxConnectNumberList2*2+5; counter2++) insideCheck [counter2] = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMap [counterY][counterX] != 0 && insideCheckMap [counterY][counterX] != 0){
                                insideCheck [insideCheckMap [counterY][counterX]*2]++;
                            }
                            else if (connectivityMap [counterY][counterX] == 0 && insideCheckMap [counterY][counterX] != 0){
                                insideCheck [insideCheckMap [counterY][counterX]*2+1]++;
                            }
                            
                            edgeCheck = 0;
                            
                            if (connectivityMap [counterY][counterX] != 0){
                                if (counterY-1 >= 0 && connectivityMap [counterY-1][counterX] == 0) edgeCheck++;
                                if (counterX+1 < dimension && connectivityMap [counterY][counterX+1] == 0) edgeCheck++;
                                if (counterY+1 < dimension && connectivityMap [counterY+1][counterX] == 0) edgeCheck++;
                                if (counterX-1 >= 0 && connectivityMap [counterY][counterX-1] == 0) edgeCheck++;
                                
                                if (edgeCheck != 0 && revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0){
                                    insideCheck [revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart]*2+1]++;
                                }
                            }
                        }
                    }
                    
                    insideCheck [valueTemp*2] = 0;
                    
                    insideFind = 0;
                    
                    for (int counter2 = 1; counter2 <= maxConnectNumberList2; counter2++){
                        if (insideCheck [counter2*2] != 0 && insideCheck [counter2*2+1] == 0) insideFind = 1;
                        else if (insideCheck [counter2*2] != 0 && insideCheck [counter2*2+1] != 0) insideCheck [counter2*2] = 0;
                    }
                    
                    if (insideFind == 1){
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++) internalZeroMap [counterY][counterX] = 0;
                        }
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (insideCheckMap [counterY][counterX] != 0){
                                    for (int counter2 = 1; counter2 <= maxConnectNumberList2; counter2++){
                                        if (insideCheck [counter2*2] != 0 && insideCheckMap [counterY][counterX] == counter2){
                                            internalZeroMap [counterY][counterX] = 1;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    delete [] insideCheck;
                    
                    for (int counter2 = 0; counter2 < dimension+1; counter2++) delete [] insideCheckMap [counter2];
                    
                    delete [] insideCheckMap;
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
                    //	cout<<" connectivityMap "<<counterA<<endl;
                    //}
                    
                    type = 2;
                    [self areaProcess:type:dimension:valueTemp:horizontalStart:verticalStart:processType:startPointFind];
                    
                    //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                    //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                    //	cout<<" arrayTimeSelected "<<counterA+1<<endl;
                    //}
                }
            }
            
            delete [] connectProcessList;
        }
        
        delete [] connectNumber;
        
        for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
            if (arrayPositionRevise [counter1*7+6] < 0) arrayPositionRevise [counter1*7+6] = arrayPositionRevise [counter1*7+6]*-1;
        }
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            delete [] connectivityMap [counter1];
            delete [] internalZeroMap [counter1];
            delete [] targetMap [counter1];
        }
        
        delete [] connectivityMap;
        delete [] internalZeroMap;
        delete [] targetMap;
    }
    
    if (resultsType1 != 0){
        referenceLineCount = 0;
        
        for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
            if (arrayPositionRevise [counter1*7+4] == cellNumberTempInt && arrayPositionRevise [counter1*7+6] == cellLineageTempInt){
                if (referenceLineCount+4 > referenceLineLimit){
                    fileUpdate = [[FileUpdate alloc] init];
                    [fileUpdate referenceLineCountUpDate];
                }
                
                arrayReferenceLine [referenceLineCount] = arrayPositionRevise [counter1*7], referenceLineCount++;
                arrayReferenceLine [referenceLineCount] = arrayPositionRevise [counter1*7+1], referenceLineCount++;
            }
        }
    }
    
    if (ifStartHold != 0 && ifStartHold-1 == imageNumberTrackForDisplay && originalNoTemp != 0 && (processType == 1 || processType == 2)){
        ifConnectNoUpDate = originalNoTemp;
        ifConnectNoCurrent = resultsType1;
        
        string extension;
        ifstream fin;
        
        int expandFluorescentOutlineTempCount = 0;
        int stepCount = 0;
        int finData [8];
        int findMatch = 0;
        int readBit [3];
        int dataTemp = 0;
        unsigned long readPosition = 0;
        unsigned long indexCount = 0;
        long sizeForCopy = 0;
        long size1 = 0;
        long size2 = 0;
        int checkFlag = 0;
        int readingError = 0;
        
        struct stat sizeOfFile;
        
        for (int counter1 = ifStartHold; counter1 <= imageEndHold; counter1++){
            extension = to_string(counter1);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            string expandDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ExtendLineDataTemp";
            
            size1 = 0;
            size2 = 0;
            checkFlag = 0;
            readingError = 0;
            
            for (int counter2 = 0; counter2 < 6; counter2++){
                sizeForCopy = 0;
                
                if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter2 == 0) size1 = sizeForCopy;
                    else if (counter2 == 1) size2 = sizeForCopy;
                    else if (counter2 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter2 == 3) size1 = sizeForCopy;
                    else if (counter2 == 4) size2 = sizeForCopy;
                    else if (counter2 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            if (checkFlag == 1){
                int *expandFluorescentOutlineTemp = new int [sizeForCopy+50];
                expandFluorescentOutlineTempCount = 0;
                
                fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        readPosition = 0;
                        stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                else{
                                    
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = finData [1], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = finData [3], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = finData [6], expandFluorescentOutlineTempCount++;
                                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = finData [7], expandFluorescentOutlineTempCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                    
                    findMatch = 0;
                    
                    for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount/4; counter2++){
                        if (expandFluorescentOutlineTemp [counter2*4+2] == ifConnectNoUpDate){
                            expandFluorescentOutlineTemp [counter2*4+2] = ifConnectNoCurrent;
                            findMatch = 1;
                        }
                    }
                    
                    if (findMatch == 1){
                        indexCount = 0;
                        
                        char *writingArray = new char [expandFluorescentOutlineTempCount*2+200];
                        
                        for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount/4; counter2++){
                            dataTemp = expandFluorescentOutlineTemp [counter2*4];
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            dataTemp = expandFluorescentOutlineTemp [counter2*4+1];
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            dataTemp = expandFluorescentOutlineTemp [counter2*4+2];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            writingArray [indexCount] = (char)expandFluorescentOutlineTemp [counter2*4+3], indexCount++;
                        }
                        
                        for (int counter2 = 0; counter2 < 8; counter2++) writingArray [indexCount] = 0, indexCount++;
                        
                        ofstream outfile (expandDataPath.c_str(), ofstream::binary);
                        outfile.write ((char*)writingArray, indexCount);
                        outfile.close();
                        
                        delete [] writingArray;
                    }
                }
                
                delete [] expandFluorescentOutlineTemp;
            }
            
            expandDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaDataTemp";
            
            sizeForCopy = 0;
            
            if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (sizeForCopy != 0){
                int *expandFluorescentOutlineTemp = new int [sizeForCopy+50];
                expandFluorescentOutlineTempCount = 0;
                
                fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    readPosition = 0;
                    stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            
                            if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                            else{
                                
                                expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = finData [2], expandFluorescentOutlineTempCount++;
                                expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = finData [3], expandFluorescentOutlineTempCount++;
                                expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = finData [4], expandFluorescentOutlineTempCount++;
                                expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = finData [7], expandFluorescentOutlineTempCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                    
                    findMatch = 0;
                    
                    for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount/4; counter2++){
                        if (expandFluorescentOutlineTemp [counter2*4] == ifConnectNoUpDate){
                            expandFluorescentOutlineTemp [counter2*4] = ifConnectNoCurrent;
                            findMatch = 1;
                        }
                    }
                    
                    if (findMatch == 1){
                        indexCount = 0;
                        
                        char *writingArray = new char [expandFluorescentOutlineTempCount*2+20];
                        
                        for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount/4; counter2++){
                            dataTemp = expandFluorescentOutlineTemp [counter2*4];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            writingArray [indexCount] = (char)expandFluorescentOutlineTemp [counter2*4+1], indexCount++;
                            writingArray [indexCount] = (char)expandFluorescentOutlineTemp [counter2*4+2], indexCount++;
                            
                            dataTemp = expandFluorescentOutlineTemp [counter2*4+3];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                        }
                        
                        for (int counter2 = 0; counter2 < 8; counter2++) writingArray [indexCount] = 0, indexCount++;
                        
                        ofstream outfile2 (expandDataPath.c_str(), ofstream::binary);
                        outfile2.write ((char*)writingArray, indexCount);
                        outfile2.close();
                        
                        delete [] writingArray;
                    }
                }
                
                delete [] expandFluorescentOutlineTemp;
            }
        }
    }
    else if (ifStartHold != 0 && ifStartHold-1 == imageNumberTrackForDisplay && originalNoTemp == 0 && (processType == 1 || processType == 2)){
        ifConnectNoUpDate = resultsType1;
        ifConnectNoCurrent = resultsType1;
    }
    
    //cout<<ifConnectNoUpDate<<" "<<ifConnectNoCurrent <<" Connect"<<endl;
    
    //for (int counterA = 0; counterA < expandFluorescentOutlineCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentOutline [counterA*4+counterB];
    //    cout<<" expandFluorescentOutline "<<counterA<<endl;
    //}
    
    if (resultsType1 != 0 && fluorescentDetectionDisplay == 1){
        //for (int counterA = 0; counterA < expandFluorescentDataCount/4; counterA++){
        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentData [counterA*4+counterB];
        //    cout<<" expandFluorescentData "<<counterA<<endl;
        //}
        
        int *arrayExpandTemp = new int [expandFluorescentOutlineCount+50];
        int expandTempCount = 0;
        
        for (int counter1 = 0; counter1 < expandFluorescentOutlineCount/4; counter1++){
            if (expandFluorescentOutline [counter1*4+2] != originalNoTemp){
                arrayExpandTemp [expandTempCount] = expandFluorescentOutline [counter1*4], expandTempCount++;
                arrayExpandTemp [expandTempCount] = expandFluorescentOutline [counter1*4+1], expandTempCount++;
                arrayExpandTemp [expandTempCount] = expandFluorescentOutline [counter1*4+2], expandTempCount++;
                arrayExpandTemp [expandTempCount] = expandFluorescentOutline [counter1*4+3], expandTempCount++;
            }
        }
        
        //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
        //    cout<<" arrayConnectLineageRel "<<counterA<<endl;
        //}
        
        if (fusionOperation == 1){
            int *arrayExpandTemp4 = new int [expandTempCount+50];
            int expandTempCount4 = 0;
            
            for (int counter1 = 0; counter1 < expandTempCount/4; counter1++){
                if (arrayExpandTemp [counter1*4+2] != fusionPartnerOriginalConn){
                    arrayExpandTemp4 [expandTempCount4] = arrayExpandTemp [counter1*4], expandTempCount4++;
                    arrayExpandTemp4 [expandTempCount4] = arrayExpandTemp [counter1*4+1], expandTempCount4++;
                    arrayExpandTemp4 [expandTempCount4] = arrayExpandTemp [counter1*4+2], expandTempCount4++;
                    arrayExpandTemp4 [expandTempCount4] = arrayExpandTemp [counter1*4+3], expandTempCount4++;
                }
            }
            
            expandTempCount = 0;
            for (int counter1 = 0; counter1 < expandTempCount4; counter1++) arrayExpandTemp [expandTempCount] = arrayExpandTemp4 [counter1], expandTempCount++;
            
            delete [] arrayExpandTemp4;
        }
        
        //for (int counterA = 0; counterA < expandFluorescentDataCount/4; counterA++){
        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentData [counterA*4+counterB];
        //    cout<<" expandFluorescentData "<<counterA<<endl;
        //}
        
        expandFluorescentOutlineCount = 0;
        for (int counter1 = 0; counter1 < expandTempCount; counter1++) expandFluorescentOutline [expandFluorescentOutlineCount] = arrayExpandTemp [counter1], expandFluorescentOutlineCount++;
        
        delete [] arrayExpandTemp;
        
        int *arrayExpandDataTemp = new int [expandFluorescentDataCount+50];
        int expandDataTempCount = 0;
        
        for (int counter1 = 0; counter1 < expandFluorescentDataCount/4; counter1++){
            if (expandFluorescentData [counter1*4] != originalNoTemp){
                arrayExpandDataTemp [expandDataTempCount] = expandFluorescentData [counter1*4], expandDataTempCount++;
                arrayExpandDataTemp [expandDataTempCount] = expandFluorescentData [counter1*4+1], expandDataTempCount++;
                arrayExpandDataTemp [expandDataTempCount] = expandFluorescentData [counter1*4+2], expandDataTempCount++;
                arrayExpandDataTemp [expandDataTempCount] = expandFluorescentData [counter1*4+3], expandDataTempCount++;
            }
        }
        
        if (fusionOperation == 1){
            int *arrayExpandDataTemp4 = new int [expandDataTempCount+50];
            int expandDataTempCount4 = 0;
            
            for (int counter1 = 0; counter1 < expandDataTempCount/4; counter1++){
                if (arrayExpandDataTemp [counter1*4] != fusionPartnerOriginalConn){
                    arrayExpandDataTemp4 [expandDataTempCount4] = arrayExpandDataTemp [counter1*4], expandDataTempCount4++;
                    arrayExpandDataTemp4 [expandDataTempCount4] = arrayExpandDataTemp [counter1*4+1], expandDataTempCount4++;
                    arrayExpandDataTemp4 [expandDataTempCount4] = arrayExpandDataTemp [counter1*4+2], expandDataTempCount4++;
                    arrayExpandDataTemp4 [expandDataTempCount4] = arrayExpandDataTemp [counter1*4+3], expandDataTempCount4++;
                }
            }
            
            expandDataTempCount = 0;
            for (int counter1 = 0; counter1 < expandDataTempCount4; counter1++) arrayExpandDataTemp [expandDataTempCount] = arrayExpandDataTemp4 [counter1], expandDataTempCount++;
            
            delete [] arrayExpandDataTemp4;
        }
        
        expandFluorescentDataCount = 0;
        for (int counter1 = 0; counter1 < expandDataTempCount; counter1++) expandFluorescentData [expandFluorescentDataCount] = arrayExpandDataTemp [counter1], expandFluorescentDataCount++;
        
        delete [] arrayExpandDataTemp;
        
        int returnData = 0;
        
        //for (int counterA = 0; counterA < expandFluorescentDataCount/4; counterA++){
        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentData [counterA*4+counterB];
        //    cout<<" expandFluorescentData "<<counterA<<endl;
        //}
        
        if (autoExpand == 1 && processType == 1){
            expandLine = [[ExpandLine alloc] init];
            returnData = [expandLine lineExtendTrackType1:resultsType1];
        }
        else if (autoExpand == 1 && (processType == 2 || processType == 3)){
            expandLine = [[ExpandLine alloc] init];
            returnData = [expandLine lineExtendTrackType2:resultsType1];
        }
        
        if ((fluorescentDetectionDisplay == 1 && autoExpand == 0) || (fluorescentDetectionDisplay == 1 && autoExpand == 1 && returnData == 1)){
            int startPosition = arrayTimeSelected [(resultsType1-1)*10+2]; //====PS
            
            for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                if (arrayPositionRevise [counter1*7+3] == arrayTimeSelected [(resultsType1-1)*10+8]){
                    if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate expandFluorescentOutlineUpDate];
                    }
                    
                    expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                    expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                    expandFluorescentOutline [expandFluorescentOutlineCount] = resultsType1, expandFluorescentOutlineCount++;
                    expandFluorescentOutline [expandFluorescentOutlineCount] = 1, expandFluorescentOutlineCount++;
                }
                else{
                    
                    break;
                }
            }
            
            if (fluorescentEntryCount >= 2){
                for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                    if (arrayPositionRevise [counter1*7+3] == arrayTimeSelected [(resultsType1-1)*10+8]){
                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate expandFluorescentOutlineUpDate];
                        }
                        
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = resultsType1, expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = 2, expandFluorescentOutlineCount++;
                    }
                    else{
                        
                        break;
                    }
                }
            }
            
            if (fluorescentEntryCount >= 3){
                for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                    if (arrayPositionRevise [counter1*7+3] == arrayTimeSelected [(resultsType1-1)*10+8]){
                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate expandFluorescentOutlineUpDate];
                        }
                        
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = resultsType1, expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = 3, expandFluorescentOutlineCount++;
                    }
                    else{
                        
                        break;
                    }
                }
            }
            
            if (fluorescentEntryCount >= 4){
                for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                    if (arrayPositionRevise [counter1*7+3] == arrayTimeSelected [(resultsType1-1)*10+8]){
                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate expandFluorescentOutlineUpDate];
                        }
                        
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = resultsType1, expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = 4, expandFluorescentOutlineCount++;
                    }
                    else{
                        
                        break;
                    }
                }
            }
            
            if (fluorescentEntryCount >= 5){
                for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                    if (arrayPositionRevise [counter1*7+3] == arrayTimeSelected [(resultsType1-1)*10+8]){
                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate expandFluorescentOutlineUpDate];
                        }
                        
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = resultsType1, expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = 5, expandFluorescentOutlineCount++;
                    }
                    else{
                        
                        break;
                    }
                }
            }
            
            if (fluorescentEntryCount >= 6){
                for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                    if (arrayPositionRevise [counter1*7+3] == arrayTimeSelected [(resultsType1-1)*10+8]){
                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate expandFluorescentOutlineUpDate];
                        }
                        
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = resultsType1, expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = 6, expandFluorescentOutlineCount++;
                    }
                    else{
                        
                        break;
                    }
                }
            }
            
            int pixelValueTemp = 0;
            int pixelAreaTemp = 0;
            int pixelValueTemp2 = 0;
            int pixelAreaTemp2 = 0;
            int pixelValueTemp3 = 0;
            int pixelAreaTemp3 = 0;
            int pixelValueTemp4 = 0;
            int pixelAreaTemp4 = 0;
            int pixelValueTemp5 = 0;
            int pixelAreaTemp5 = 0;
            int pixelValueTemp6 = 0;
            int pixelAreaTemp6 = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                        if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] == resultsType1){
                            if (fluorescentEntryCount >= 1){
                                if (fluorescentCutOff1 >= fluorescentMap1 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap1 [counterX+horizontalStart][counterX+horizontalStart];
                                pixelAreaTemp++;
                            }
                            if (fluorescentEntryCount >= 2){
                                if (fluorescentCutOff2 >= fluorescentMap2 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp2 = pixelValueTemp2+fluorescentMap2 [counterX+horizontalStart][counterX+horizontalStart];
                                pixelAreaTemp2++;
                            }
                            if (fluorescentEntryCount >= 3){
                                if (fluorescentCutOff3 >= fluorescentMap3 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp3 = pixelValueTemp3+fluorescentMap3 [counterX+horizontalStart][counterX+horizontalStart];
                                pixelAreaTemp3++;
                            }
                            if (fluorescentEntryCount >= 4){
                                if (fluorescentCutOff4 >= fluorescentMap4 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp4 = pixelValueTemp4+fluorescentMap4 [counterX+horizontalStart][counterX+horizontalStart];
                                pixelAreaTemp4++;
                            }
                            if (fluorescentEntryCount >= 5){
                                if (fluorescentCutOff5 >= fluorescentMap5 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp5 = pixelValueTemp5+fluorescentMap5 [counterX+horizontalStart][counterX+horizontalStart];
                                pixelAreaTemp5++;
                            }
                            if (fluorescentEntryCount >= 6){
                                if (fluorescentCutOff6 >= fluorescentMap6 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp6 = pixelValueTemp6+fluorescentMap6 [counterX+horizontalStart][counterX+horizontalStart];
                                pixelAreaTemp6++;
                            }
                        }
                    }
                }
            }
            
            double averageArea = pixelValueTemp/(double)pixelAreaTemp;
            
            if (expandFluorescentDataCount+20 > expandFluorescentDataLimit){
                fileUpdate = [[FileUpdate alloc] init];
                [fileUpdate expandFluorescentDataUpDate];
            }
            
            expandFluorescentData [expandFluorescentDataCount] = resultsType1, expandFluorescentDataCount++;
            expandFluorescentData [expandFluorescentDataCount] = 1, expandFluorescentDataCount++;
            expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
            expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp, expandFluorescentDataCount++;
            
            if (fluorescentEntryCount >= 2){
                averageArea = pixelValueTemp2/(double)pixelAreaTemp2;
                
                expandFluorescentData [expandFluorescentDataCount] = resultsType1, expandFluorescentDataCount++;
                expandFluorescentData [expandFluorescentDataCount] = 2, expandFluorescentDataCount++;
                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp2, expandFluorescentDataCount++;
            }
            
            if (fluorescentEntryCount >= 3){
                averageArea = pixelValueTemp3/(double)pixelAreaTemp3;
                
                expandFluorescentData [expandFluorescentDataCount] = resultsType1, expandFluorescentDataCount++;
                expandFluorescentData [expandFluorescentDataCount] = 3, expandFluorescentDataCount++;
                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp3, expandFluorescentDataCount++;
            }
            
            if (fluorescentEntryCount >= 4){
                averageArea = pixelValueTemp4/(double)pixelAreaTemp4;
                
                expandFluorescentData [expandFluorescentDataCount] = resultsType1, expandFluorescentDataCount++;
                expandFluorescentData [expandFluorescentDataCount] = 4, expandFluorescentDataCount++;
                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp4, expandFluorescentDataCount++;
            }
            
            if (fluorescentEntryCount >= 5){
                averageArea = pixelValueTemp5/(double)pixelAreaTemp5;
                
                expandFluorescentData [expandFluorescentDataCount] = resultsType1, expandFluorescentDataCount++;
                expandFluorescentData [expandFluorescentDataCount] = 5, expandFluorescentDataCount++;
                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp5, expandFluorescentDataCount++;
            }
            
            if (fluorescentEntryCount >= 6){
                averageArea = pixelValueTemp6/(double)pixelAreaTemp6;
                
                expandFluorescentData [expandFluorescentDataCount] = resultsType1, expandFluorescentDataCount++;
                expandFluorescentData [expandFluorescentDataCount] = 6, expandFluorescentDataCount++;
                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp6, expandFluorescentDataCount++;
            }
        }
        
        //for (int counterA = 0; counterA < expandFluorescentOutlineCount/4; counterA++){
        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentOutline [counterA*4+counterB];
        //    cout<<" expandFluorescentOutline "<<counterA<<endl;
        //}
        
        
        //for (int counterA = 0; counterA < expandFluorescentDataCount/4; counterA++){
        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentData [counterA*4+counterB];
        //    cout<<" expandFluorescentData "<<counterA<<endl;
        //}
    }
    
    delete [] connectAnalysisX;
    delete [] connectAnalysisY;
    delete [] connectAnalysisTempX;
    delete [] connectAnalysisTempY;
    
    //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
    //	cout<<" arrayPositionRevise "<<counterA<<endl;
    //}
    
    //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
    //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
    //	cout<<" arrayTimeSelected "<<counterA+1<<endl;
    //}
    
    //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
    //	cout<<" arrayConnectLineageRel "<<counterA+1<<endl;
    //}
    
    //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
    //    cout<<" arrayEventSequence "<<counterA<<endl;
    //}
    
    for (int counter1 = 0; counter1 < dimension+4; counter1++){
        delete [] rangeMatrix [counter1];
    }
    
    delete [] rangeMatrix;
    
    return resultsType1;
}

-(int)areaProcess:(int)type :(int)dimension :(int)valueTemp :(int)horizontalStart :(int)verticalStart :(int)processType :(int)startPointFind{
    int lineEntryNumber;
    int results = 0;
    
    if (targetHoldCount != 0) lineEntryNumber = arrayTargetHold [(targetHoldCount/3-1)*3+2];
    else lineEntryNumber = 0;
    
    lineEntryNumber++;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMap [counterY][counterX] != 0) connectivityMap [counterY][counterX] = connectivityMap [counterY][counterX]*-1;
        }
    }
    
    //for (int counterA = 0; counterA < dimension; counterA++){
    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
    //	cout<<" connectivityMap "<<counterA<<endl;
    //}
    
    int *connectAnalysisX = new int [dimension*4];
    int *connectAnalysisY = new int [dimension*4];
    int *connectAnalysisTempX = new int [dimension*4];
    int *connectAnalysisTempY = new int [dimension*4];
    
    int connectivityNumber = 0;
    int connectAnalysisCount = 0;
    int terminationFlag = 0;
    int connectAnalysisTempCount = 0;
    int xSource = 0;
    int ySource = 0;
    int lostMarkSet = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMap [counterY][counterX] < 0){
                connectivityNumber++;
                connectivityMap [counterY][counterX] = connectivityNumber;
                connectAnalysisCount = 0;
                
                if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMap [counterY-1][counterX-1] < 0){
                    connectivityMap [counterY-1][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterY-1 >= 0 && connectivityMap [counterY-1][counterX] < 0){
                    connectivityMap [counterY-1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMap [counterY-1][counterX+1] < 0){
                    connectivityMap [counterY-1][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                }
                if (counterX+1 < dimension && connectivityMap [counterY][counterX+1] < 0){
                    connectivityMap [counterY][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && counterX+1 < dimension && connectivityMap [counterY+1][counterX+1] < 0){
                    connectivityMap [counterY+1][counterX+1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && connectivityMap [counterY+1][counterX] < 0){
                    connectivityMap [counterY+1][counterX] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMap [counterY+1][counterX-1] < 0){
                    connectivityMap [counterY+1][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                }
                if (counterX-1 >= 0 && connectivityMap [counterY][counterX-1] < 0){
                    connectivityMap [counterY][counterX-1] = connectivityNumber;
                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                }
                
                if (connectAnalysisCount != 0){
                    do{
                        
                        terminationFlag = 1;
                        connectAnalysisTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                            xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                            
                            if (ySource-1 >= 0 && xSource-1 >= 0 && connectivityMap [ySource-1][xSource-1] < 0){
                                connectivityMap [ySource-1][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (ySource-1 >= 0 && connectivityMap [ySource-1][xSource] < 0){
                                connectivityMap [ySource-1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (ySource-1 >= 0 && xSource+1 < dimension && connectivityMap [ySource-1][xSource+1] < 0){
                                connectivityMap [ySource-1][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                            }
                            if (xSource+1 < dimension && connectivityMap [ySource][xSource+1] < 0){
                                connectivityMap [ySource][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                            if (ySource+1 > dimension && xSource+1 < dimension && connectivityMap [ySource+1][xSource+1] < 0){
                                connectivityMap [ySource+1][xSource+1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < dimension && connectivityMap [ySource+1][xSource] < 0){
                                connectivityMap [ySource+1][xSource] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (ySource+1 < dimension && xSource-1 >= 0 && connectivityMap [ySource+1][xSource-1] < 0){
                                connectivityMap [ySource+1][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                            }
                            if (xSource-1 >= 0 && connectivityMap [ySource][xSource-1] < 0){
                                connectivityMap [ySource][xSource-1] = connectivityNumber;
                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                            connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                        }
                        
                        connectAnalysisCount = connectAnalysisTempCount;
                        
                        if (connectAnalysisCount == 0) terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                }
            }
        }
    }
    
    //for (int counterA = 0; counterA < dimension; counterA++){
    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
    //	cout<<" connectivityMap "<<counterA<<endl;
    //}
    
    //-----Determine number of pixels-----
    int *connectedPix = new int [connectivityNumber+50];
    
    for (int counter1 = 0; counter1 <= connectivityNumber; counter1++) connectedPix [counter1] = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMap [counterY][counterX] != 0) connectedPix [connectivityMap [counterY][counterX]]++;
        }
    }
    
    //-----Map up-date-----
    int connectTemp = 1;
    
    for (int counter1 = 1; counter1 <= connectivityNumber; counter1++){
        if (connectedPix [counter1] < 10) connectedPix [counter1] = 0;
        else{
            
            connectedPix [counter1] = connectTemp;
            connectTemp++;
        }
    }
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if ((connectTemp = connectivityMap [counterY][counterX]) != 0) connectivityMap [counterY][counterX] = connectedPix [connectTemp];
        }
    }
    
    delete [] connectedPix;
    
    //for (int counterA = 0; counterA < dimension; counterA++){
    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
    //	cout<<" connectivityMap "<<counterA<<endl;
    //}
    
    int maxConnectivityNumber = 0;
    int newConnectLineNo = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMap [counterY][counterX] > maxConnectivityNumber) maxConnectivityNumber = connectivityMap [counterY][counterX];
        }
    }
    
    int **outlineMap = new int *[dimension+1];
    int **outlineMap2 = new int *[dimension+1];
    int **outlineMap3 = new int *[dimension+1];
    
    for (int counter1 = 0; counter1 < dimension+1; counter1++){
        outlineMap [counter1] = new int [dimension+1];
        outlineMap2 [counter1] = new int [dimension+1];
        outlineMap3 [counter1] = new int [dimension+1];
    }
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++) outlineMap3 [counterY][counterX] = 0;
    }
    
    int *outlineDataSet = new int [1000];
    int outlineDataSetCount = 0;
    int outlineDataSetLimit = 1000;
    int largestConnect = 0;
    int largestConnectNo = 0;
    int xPositionTempStart = 0;
    int yPositionTempStart = 0;
    int lineSize = 0;
    int constructedLineCount = 0;
    int findFlag = 0;
    int terminationFlag2 = 0;
    
    for (int counter1 = 1; counter1 <= maxConnectivityNumber; counter1++){
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMap [counterY][counterX] == counter1) outlineMap [counterY][counterX] = 1;
                else outlineMap [counterY][counterX] = 0;
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<outlineMap [counterA][counterB];
        //    cout<<" outlineMap "<<counterA<<endl;
        //}
        
        do{
            
            terminationFlag = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (outlineMap [counterY][counterX] != 0){
                        if (counterX+1 < dimension && outlineMap [counterY][counterX+1] == 0) outlineMap [counterY][counterX] = -1;
                        else if (counterY+1 < dimension && outlineMap [counterY+1][counterX] == 0) outlineMap [counterY][counterX] = -1;
                        else if (counterX-1 >= 0 && outlineMap [counterY][counterX-1] == 0) outlineMap [counterY][counterX] = -1;
                        else if (counterY-1 >= 0 && outlineMap [counterY-1][counterX] == 0) outlineMap [counterY][counterX] = -1;
                    }
                }
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (outlineMap [counterY][counterX] > 0) outlineMap [counterY][counterX] = 0;
                    if (outlineMap [counterY][counterX] < 0) outlineMap [counterY][counterX] = 1;
                }
            }
            
            connectivityNumber = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (outlineMap [counterY2][counterX2] == 0){
                        connectivityNumber--;
                        connectAnalysisCount = 0;
                        
                        outlineMap [counterY2][counterX2] = connectivityNumber;
                        
                        if (counterY2-1 >= 0 && outlineMap [counterY2-1][counterX2] == 0){
                            outlineMap [counterY2-1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                        }
                        if (counterX2+1 < dimension && outlineMap [counterY2][counterX2+1] == 0){
                            outlineMap [counterY2][counterX2+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        if (counterY2+1 < dimension && outlineMap [counterY2+1][counterX2] == 0){
                            outlineMap [counterY2+1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                        }
                        if (counterX2-1 >= 0 && outlineMap [counterY2][counterX2-1] == 0){
                            outlineMap [counterY2][counterX2-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                    xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                    
                                    if (ySource-1 >= 0 && outlineMap [ySource-1][xSource] == 0){
                                        outlineMap [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && outlineMap [ySource][xSource+1] == 0){
                                        outlineMap [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && outlineMap [ySource+1][xSource] == 0){
                                        outlineMap [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && outlineMap [ySource][xSource-1] == 0){
                                        outlineMap [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                    connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //-----Determine number of pixels-----
            connectivityNumber = connectivityNumber*-1;
            
            int *connectedPix2 = new int [connectivityNumber+50];
            
            for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPix2 [counter2] = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (outlineMap [counterY2][counterX2] < -1) connectedPix2 [outlineMap [counterY2][counterX2]*-1]++;
                }
            }
            
            largestConnect = 0;
            largestConnectNo = 0;
            
            for (int counter2 = 2; counter2 <= connectivityNumber; counter2++){
                if (connectedPix2 [counter2] > largestConnect){
                    largestConnect = connectedPix2 [counter2];
                    largestConnectNo = counter2;
                }
            }
            
            delete [] connectedPix2;
            
            if (largestConnectNo == 0 || largestConnect < 20) terminationFlag = 1;
            else{
                
                int **newConnectivityMapTemp = new int *[dimension+4];
                for (int counter2 = 0; counter2 < dimension+4; counter2++) newConnectivityMapTemp [counter2] = new int [dimension+4];
                
                for (int counterY = 0; counterY < dimension+4; counterY++){
                    for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
                }
                
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                        if (outlineMap [counterY2][counterX2] == largestConnectNo*-1){
                            if (counterY2-1 >= 0 && counterX2-1 >= 0 && outlineMap [counterY2-1][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                                outlineMap [counterY2-1][counterX2-1] = 0;
                            }
                            if (counterY2-1 >= 0 && outlineMap [counterY2-1][counterX2] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                                outlineMap [counterY2-1][counterX2] = 0;
                            }
                            if (counterY2-1 >= 0 && counterX2+1 < dimension && outlineMap [counterY2-1][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                                outlineMap [counterY2-1][counterX2+1] = 0;
                            }
                            if (counterX2+1 < dimension && outlineMap [counterY2][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                                outlineMap [counterY2][counterX2+1] = 0;
                            }
                            if (counterY2+1 < dimension && counterX2+1 < dimension && outlineMap [counterY2+1][counterX2+1] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                                outlineMap [counterY2+1][counterX2+1] = 0;
                            }
                            if (counterY2+1 < dimension && outlineMap [counterY2+1][counterX2] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                                outlineMap [counterY2+1][counterX2] = 0;
                            }
                            if (counterY2+1 < dimension && counterX2-1 >= 0 && outlineMap [counterY2+1][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                                outlineMap [counterY2+1][counterX2-1] = 0;
                            }
                            if (counterX2-1 >= 0 && outlineMap [counterY2][counterX2-1] == 1){
                                newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                                outlineMap [counterY2][counterX2-1] = 0;
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<newConnectivityMapTemp [counterA][counterB];
                //    cout<<" newConnectivityMapTemp "<<counterA<<endl;
                //}
                
                xPositionTempStart = 0;
                yPositionTempStart = 0;
                lineSize = 0;
                
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++) outlineMap2 [counterY2][counterX2] = 0;
                }
                
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                        if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                            outlineMap2 [counterY2][counterX2] = 1;
                            xPositionTempStart = counterX2;
                            yPositionTempStart = counterY2;
                            lineSize++;
                        }
                    }
                }
                
                for (int counter2 = 0; counter2 < dimension+4; counter2++) delete [] newConnectivityMapTemp [counter2];
                delete [] newConnectivityMapTemp;
                
                constructedLineCount = 0;
                
                int *arrayNewLines = new int [lineSize*2+50];
                
                outlineMap2 [yPositionTempStart][xPositionTempStart] = -1;
                arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                
                do{
                    
                    findFlag = 0;
                    terminationFlag2 = 0;
                    
                    if (xPositionTempStart+1 < dimension){
                        if (outlineMap2 [yPositionTempStart][xPositionTempStart+1] == 1){
                            outlineMap2 [yPositionTempStart][xPositionTempStart+1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart+1, terminationFlag2 = 1, findFlag = 1;
                        }
                    }
                    if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                        if (outlineMap2 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                            outlineMap2 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag2 = 1, findFlag = 1;
                        }
                    }
                    if (yPositionTempStart+1 < dimension && findFlag == 0){
                        if (outlineMap2 [yPositionTempStart+1][xPositionTempStart] == 1){
                            outlineMap2 [yPositionTempStart+1][xPositionTempStart] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                            yPositionTempStart = yPositionTempStart+1, terminationFlag2 = 1, findFlag = 1;
                        }
                    }
                    if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                        if (outlineMap2 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                            outlineMap2 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag2 = 1, findFlag = 1;
                        }
                    }
                    if (xPositionTempStart-1 >= 0 && findFlag == 0){
                        if (outlineMap2 [yPositionTempStart][xPositionTempStart-1] == 1){
                            outlineMap2 [yPositionTempStart][xPositionTempStart-1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart-1, terminationFlag2 = 1, findFlag = 1;
                        }
                    }
                    if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                        if (outlineMap2 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                            outlineMap2 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag2 = 1, findFlag = 1;
                        }
                    }
                    if (yPositionTempStart-1 >= 0 && findFlag == 0){
                        if (outlineMap2 [yPositionTempStart-1][xPositionTempStart] == 1){
                            outlineMap2 [yPositionTempStart-1][xPositionTempStart] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                            yPositionTempStart = yPositionTempStart-1, terminationFlag2 = 1, findFlag = 1;
                        }
                    }
                    if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                        if (outlineMap2 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                            outlineMap2 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                            arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                            arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                            xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag2 = 1;
                        }
                    }
                    
                } while (terminationFlag2 == 1);
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<outlineMap2 [counterA][counterB];
                //    cout<<" outlineMap2 "<<counterA<<endl;
                //}
                
                newConnectLineNo++;
                
                for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                    if (outlineDataSetCount+3 > outlineDataSetLimit){
                        int *arrayUpDate = new int [outlineDataSetCount+10];
                        
                        for (int counter3 = 0; counter3 < outlineDataSetCount; counter3++) arrayUpDate [counter3] = outlineDataSet [counter3];
                        
                        delete [] outlineDataSet;
                        outlineDataSet = new int [outlineDataSetLimit+5000];
                        outlineDataSetLimit = outlineDataSetLimit+5000;
                        
                        for (int counter3 = 0; counter3 < outlineDataSetCount; counter3++) outlineDataSet [counter3] = arrayUpDate [counter3];
                        delete [] arrayUpDate;
                    }
                    
                    outlineDataSet [outlineDataSetCount] = newConnectLineNo, outlineDataSetCount++; //-----Vector no-----
                    outlineDataSet [outlineDataSetCount] = arrayNewLines [counter2*2], outlineDataSetCount++; //-----X Position-----
                    outlineDataSet [outlineDataSetCount] = arrayNewLines [counter2*2+1], outlineDataSetCount++; //-----Y Position-----
                }
                
                delete [] arrayNewLines;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (outlineMap2 [counterY][counterX] == -1) outlineMap2 [counterY][counterX] = outlineMap2 [counterY][counterX]*-1;
                    }
                }
                
                connectivityNumber = -3;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (outlineMap2 [counterY][counterX] == 0){
                            connectivityNumber = connectivityNumber+2;
                            outlineMap2 [counterY][counterX] = connectivityNumber;
                            
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && outlineMap2 [counterY-1][counterX] == 0){
                                outlineMap2 [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension && outlineMap2 [counterY][counterX+1] == 0){
                                outlineMap2 [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && outlineMap2 [counterY+1][counterX] == 0){
                                outlineMap2 [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && outlineMap2 [counterY][counterX-1] == 0){
                                outlineMap2 [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                        
                                        if (ySource-1 >= 0 && outlineMap2 [ySource-1][xSource] == 0){
                                            outlineMap2 [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension && outlineMap2 [ySource][xSource+1] == 0){
                                            outlineMap2 [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && outlineMap2 [ySource+1][xSource] == 0){
                                            outlineMap2 [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && outlineMap2 [ySource][xSource-1] == 0){
                                            outlineMap2 [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<outlineMap2 [counterA][counterB];
                //    cout<<" outlineMap2 "<<counterA<<endl;
                //}
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (outlineMap2 [counterY][counterX] == -1) outlineMap2 [counterY][counterX] = 0;
                        else outlineMap2 [counterY][counterX] = newConnectLineNo;
                    }
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (outlineMap2 [counterY][counterX] != 0){
                            outlineMap [counterY][counterX] = 0;
                            outlineMap3 [counterY][counterX] = outlineMap2 [counterY][counterX];
                        }
                        
                        if (outlineMap [counterY][counterX] != 0) outlineMap [counterY][counterX] = 0;
                    }
                }
            }
            
        } while (terminationFlag == 0);
    }
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++) connectivityMap [counterY][counterX] = outlineMap3 [counterY][counterX];
    }
    
    //for (int counterA = 0; counterA < outlineDataSetCount/3; counterA++){
    //    cout<<counterA<<" "<<outlineDataSet [counterA*3]<<" "<<outlineDataSet [counterA*3+1]<<" "<<outlineDataSet [counterA*3+2]<<" Outline "<<endl;
    //}
    
    for (int counter1 = 0; counter1 < dimension+1; counter1++){
        delete [] outlineMap [counter1];
        delete [] outlineMap2 [counter1];
        delete [] outlineMap3 [counter1];
    }
    
    delete [] outlineMap;
    delete [] outlineMap2;
    delete [] outlineMap3;
    
    //-----Determine number of pixels-----
    connectedPix = new int [newConnectLineNo+50];
    
    for (int counter1 = 0; counter1 <= newConnectLineNo; counter1++) connectedPix [counter1] = 0;
    
    for (int counterY = 0; counterY < dimension; counterY++){
        for (int counterX = 0; counterX < dimension; counterX++){
            if (connectivityMap [counterY][counterX] != 0) connectedPix [connectivityMap [counterY][counterX]]++;
        }
    }
    
    //for (int counterA = 1; counterA <= newConnectLineNo; counterA++){
    //    cout<<counterA<<" "<<connectedPix [counterA]<<" pix"<<endl;
    //}
    
    //-----Map up-date-----
    int *connectedPixConnectNo = new int [newConnectLineNo+2];
    int *pixNumberRef = new int [newConnectLineNo+2];
    
    for (int counter1 = 0; counter1 < newConnectLineNo+1; counter1++){
        connectedPixConnectNo [counter1] = 0;
        pixNumberRef [counter1] = 0;
    }
    
    if (firstModificationPoint == imageNumberTrackForDisplay || firstModificationPoint == 10000){
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] != 0){
                    if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] == connectNoTemp && connectedPix [connectivityMap [counterY][counterX]] != 0) connectedPixConnectNo [connectivityMap [counterY][counterX]]++;
                }
            }
        }
    }
    
    int largestTargetConnect = 0;
    int targetEntryConnectNo = 0;
    
    if (firstModificationPoint == imageNumberTrackForDisplay || firstModificationPoint == 10000){
        for (int counter1 = 1; counter1 < newConnectLineNo+1; counter1++){
            if (connectedPixConnectNo [counter1] > largestTargetConnect){
                largestTargetConnect = connectedPixConnectNo [counter1];
                targetEntryConnectNo = counter1;
            }
        }
    }
    else{
        
        for (int counter1 = 1; counter1 < newConnectLineNo+1; counter1++){
            if (connectedPix [counter1] > largestTargetConnect){
                largestTargetConnect = connectedPix [counter1];
                targetEntryConnectNo = counter1;
            }
        }
    }
    
    delete [] connectedPixConnectNo;
    delete [] connectAnalysisX;
    delete [] connectAnalysisY;
    delete [] connectAnalysisTempX;
    delete [] connectAnalysisTempY;
    
    if (type == 1 && newConnectLineNo == 0 && processType != 3){
        lostMarkSet = 0;
        
        if (targetLostMark == ""){
            targetLostMark = "Lost-"+to_string (imageNumberTrackForDisplay);
            lostMarkSet = 1;
        }
        
        results = 0;
        
        if (divisionTypeHold == 0 && startPointFind == 0){
            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay) arrayEventSequence [counter1*4] = 0;
            }
        }
        
        if (startPointFind == 0){
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        
        if (startPointFind == 1 && lostMarkSet == 1){
            targetLostMark = "";
        }
    }
    else{
        
        if (type == 1 && (newConnectLineNo == 0 || targetEntryConnectNo == 0) && (firstModificationPoint == imageNumberTrackForDisplay || firstModificationPoint == 10000)) results = 0;
        else{
            
            results = 1;
            
            string cellLineageExtract = cellLineageNoHold.substr(1);
            string cellNoExtract = "";
            int lineageAmendTemp = atoi(cellLineageExtract.c_str());
            int cellAmendTemp = 0;
            
            string cellNoExtractOriginal = cellNoHold.substr(1);
            int cellAmendOriginal = atoi(cellNoExtractOriginal.c_str());
            
            if (divisionTypeHold == 0 && cellDivisionSetCount == 0){
                cellNoExtract = cellNoHold.substr(1);
                cellAmendTemp = atoi(cellNoExtract.c_str());
            }
            if (divisionTypeHold >= 2 && (cellDivisionSetCount == 0 || cellDivisionSetCount == 1)){
                cellNoExtract = cellNoHoldDiv1.substr(1);
                cellAmendTemp = atoi(cellNoExtract.c_str());
            }
            if (divisionTypeHold >= 2 && cellDivisionSetCount == 2){
                cellNoExtract = cellNoHoldDiv2.substr(1);
                cellAmendTemp = atoi(cellNoExtract.c_str());
            }
            if (divisionTypeHold >= 3 && cellDivisionSetCount == 3){
                cellNoExtract = cellNoHoldDiv3.substr(1);
                cellAmendTemp = atoi(cellNoExtract.c_str());
            }
            if (divisionTypeHold == 4 && cellDivisionSetCount == 4){
                cellNoExtract = cellNoHoldDiv4.substr(1);
                cellAmendTemp = atoi(cellNoExtract.c_str());
            }
            
            if (fusionOperation == 1){
                lineageAmendTemp = fusionPartnerLin;
                cellAmendTemp = fusionPartnerCellNo;
            }
            
            if (newConnectLineNo == 0 && type == 2){
                //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                //	cout<<" arrayTimeSelected "<<counterA+1<<endl;
                //}
                
                int *arrayTimeOneTemp = new int [positionReviseCount+50];
                int timeOneTempCount = 0;
                
                for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                    if (arrayPositionRevise [counter1*7+3] == valueTemp){
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+1], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+2], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+3], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+4], timeOneTempCount++;
                        
                        if (arrayPositionRevise [counter1*7+5] == 0) arrayTimeOneTemp [timeOneTempCount] = 2, timeOneTempCount++;
                        else if (arrayPositionRevise [counter1*7+5] == 1) arrayTimeOneTemp [timeOneTempCount] = 3, timeOneTempCount++;
                        else arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+5], timeOneTempCount++;
                        
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+6], timeOneTempCount++;
                    }
                    else{
                        
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+1], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+2], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+3], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+4], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+5], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter1*7+6], timeOneTempCount++;
                    }
                }
                
                positionReviseCount = 0;
                for (int counter1 = 0; counter1 < timeOneTempCount; counter1++) arrayPositionRevise [positionReviseCount] = arrayTimeOneTemp [counter1], positionReviseCount++;
                delete [] arrayTimeOneTemp;
                
                arrayTimeOneTemp = new int [timeSelectedCount+50];
                timeOneTempCount = 0;
                
                //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                //    cout<<" arrayTimeSelected "<<counterA+1<<endl;
                //}
                
                for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                    if (counter1+1 == valueTemp && arrayTimeSelected [counter1*10] != 3 && arrayTimeSelected [counter1*10] != 4){
                        if (arrayTimeSelected [counter1*10] == 0) arrayTimeOneTemp [timeOneTempCount] = 3, timeOneTempCount++;
                        else if (arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7 || arrayTimeSelected [counter1*10] == 2) arrayTimeOneTemp [timeOneTempCount] = 4, timeOneTempCount++;
                        
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+1], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+2], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = lineEntryNumber, timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+4], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+5], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+6], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+7], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+8], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+9], timeOneTempCount++;
                    }
                    else{
                        
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+1], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+2], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+3], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+4], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+5], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+6], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+7], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+8], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter1*10+9], timeOneTempCount++;
                    }
                }
                
                timeSelectedCount = 0;
                for (int counter1 = 0; counter1 < timeOneTempCount; counter1++) arrayTimeSelected [timeSelectedCount] = arrayTimeOneTemp [counter1],timeSelectedCount++;
                delete [] arrayTimeOneTemp;
                
                //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                //    cout<<" arrayTimeSelected "<<counterA+1<<endl;
                //}
                
                for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                    if (arrayPositionRevise [counter1*7+6] == lineageAmendTemp && arrayPositionRevise [counter1*7+4] == cellAmendTemp){
                        arrayPositionRevise [counter1*7+6] = 0;
                        arrayPositionRevise [counter1*7+4] = 0;
                    }
                }
                
                //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
                //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
                //	cout<<" arrayPositionRevise "<<counterA<<endl;
                //}
                
                for (int counterY = 0; counterY < imageDimension; counterY++){
                    for (int counterX = 0; counterX < imageDimension; counterX++){
                        if (revisedWorkingMap [counterY][counterX] == valueTemp) revisedWorkingMap [counterY][counterX] = 0;
                    }
                }
                
                int *arrayFluOutlineTemp = new int [expandFluorescentOutlineCount+50];
                int fluOutlineTempCount = 0;
                
                for (int counter2 = 0; counter2 < expandFluorescentOutlineCount/4; counter2++){
                    if (expandFluorescentOutline [counter2*4+2] != valueTemp){
                        arrayFluOutlineTemp [fluOutlineTempCount] = expandFluorescentOutline [counter2*4], fluOutlineTempCount++;
                        arrayFluOutlineTemp [fluOutlineTempCount] = expandFluorescentOutline [counter2*4+1], fluOutlineTempCount++;
                        arrayFluOutlineTemp [fluOutlineTempCount] = expandFluorescentOutline [counter2*4+2], fluOutlineTempCount++;
                        arrayFluOutlineTemp [fluOutlineTempCount] = expandFluorescentOutline [counter2*4+3], fluOutlineTempCount++;
                    }
                }
                
                expandFluorescentOutlineCount = 0;
                for (int counter2 = 0; counter2 < fluOutlineTempCount; counter2++) expandFluorescentOutline [expandFluorescentOutlineCount] = arrayFluOutlineTemp [counter2], expandFluorescentOutlineCount++;
                
                delete [] arrayFluOutlineTemp;
                
                int *arrayFluAreaTemp = new int [expandFluorescentDataCount+50];
                int fluAreaTempCount = 0;
                
                for (int counter2 = 0; counter2 < expandFluorescentDataCount/4; counter2++){
                    if (expandFluorescentData [counter2*4] != valueTemp){
                        arrayFluAreaTemp [fluAreaTempCount] = expandFluorescentData [counter2*4], fluAreaTempCount++;
                        arrayFluAreaTemp [fluAreaTempCount] = expandFluorescentData [counter2*4+1], fluAreaTempCount++;
                        arrayFluAreaTemp [fluAreaTempCount] = expandFluorescentData [counter2*4+2], fluAreaTempCount++;
                        arrayFluAreaTemp [fluAreaTempCount] = expandFluorescentData [counter2*4+3], fluAreaTempCount++;
                    }
                }
                
                expandFluorescentDataCount = 0;
                for (int counter2 = 0; counter2 < fluAreaTempCount; counter2++) expandFluorescentData [expandFluorescentDataCount] = arrayFluAreaTemp [counter2], expandFluorescentDataCount++;
                
                delete [] arrayFluAreaTemp;
            }
            
            if (newConnectLineNo > 0){
                int currentStatus = 0;
                int entryCount = 0;
                int gravityCenter1 [4];
                int maxVectorNumber = 0;
                
                if (gravityCenterRevCount!= 0) maxVectorNumber = arrayGravityCenterRev [(gravityCenterRevCount/6-1)*6+4];
                
                int xGravityImageTemp = 0;
                int yGravityImageTemp = 0;
                int gravityX1 = 0;
                int gravityY1 = 0;
                int totalGRCount = 0;
                int averageIntensity = 0;
                int timeOneTempCount = 0;
                int divisionSetFlag = 0;
                int lastConnectPosition = 0;
                int connectNoTemp2 = 0;
                int lineageGRCurrentCountTemp = 0;
                int connectLineageRelTempCount = 0;
                int eventFind = 0;
                
                // for (int counter1 = 1; counter1 < maxConnectivityNumber+1; counter1++) cout<<counter1<<" "<<connectedPix [counter1]<<" PixNo"<<endl;
                
                //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
                //    cout<<" arrayPositionRevise "<<counterA<<endl;
                // }
                
                //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                //    cout<<" arrayTimeSelected "<<counterA+1<<" "<<endl;
                //}
                
                for (int counter1 = 1; counter1 < newConnectLineNo+1; counter1++){
                    if (connectedPix [counter1] != 0){
                        gravityCenter1 [0] = 0;
                        gravityCenter1 [1] = 0;
                        gravityCenter1 [2] = 0;
                        gravityCenter1 [3] = 0;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (connectivityMap [counterY][counterX] == counter1){
                                    gravityCenter1 [0] = gravityCenter1 [0]+counterX;
                                    gravityCenter1 [1] = gravityCenter1 [1]+counterY;
                                    gravityCenter1 [2]++;
                                    
                                    xGravityImageTemp = counterX+horizontalStart;
                                    yGravityImageTemp = counterY+verticalStart;
                                    
                                    if (xGravityImageTemp > imageDimension) xGravityImageTemp = imageDimension-1;
                                    if (xGravityImageTemp < 0) xGravityImageTemp = 0;
                                    if (yGravityImageTemp > imageDimension) yGravityImageTemp = imageDimension-1;
                                    if (yGravityImageTemp < 0) yGravityImageTemp = 0;
                                    
                                    gravityCenter1 [3] = gravityCenter1 [3]+sourceImage [yGravityImageTemp][xGravityImageTemp];
                                }
                            }
                        }
                        
                        //cout<<gravityCenter1 [0]<<" "<<gravityCenter1 [1]<<" "<<gravityCenter1 [2]<<" "<<gravityCenter1 [3]<<" GRData"<<endl;
                        
                        averageIntensity = (int)(gravityCenter1 [3]/(double)gravityCenter1 [2]);
                        
                        //cout<<gravityX1<<" "<<gravityY1<<" "<<averageIntensity<<" "<<entryCount<<" GRCenter"<<endl;
                        
                        //-----First Connect Get and Set required data-----
                        if (entryCount == 0){
                            entryCount = 1;
                            
                            if (type == 2){
                                int *arrayTimeOneTemp = new int [timeSelectedCount+50];
                                timeOneTempCount = 0;
                                
                                //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                                //    cout<<" arrayTimeSelected "<<counterA+1<<" "<<endl;
                                //}
                                
                                for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                                    if (counter2+1 == valueTemp && arrayTimeSelected [counter2*10] != 3 && arrayTimeSelected [counter2*10] != 4){
                                        if (arrayTimeSelected [counter2*10] == 0) arrayTimeOneTemp [timeOneTempCount] = 3, timeOneTempCount++;
                                        else if (arrayTimeSelected [counter2*10] == 1 || arrayTimeSelected [counter2*10] == 7 || arrayTimeSelected [counter2*10] == 2) arrayTimeOneTemp [timeOneTempCount] = 4, timeOneTempCount++;
                                        
                                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+1], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+2], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = lineEntryNumber, timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+4], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+5], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+6], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+7], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+8], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+9], timeOneTempCount++;
                                    }
                                    else{
                                        
                                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+1], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+2], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+3], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+4], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+5], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+6], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+7], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+8], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+9], timeOneTempCount++;
                                    }
                                }
                                
                                timeSelectedCount = 0;
                                for (int counter2 = 0; counter2 < timeOneTempCount; counter2++) arrayTimeSelected [timeSelectedCount] = arrayTimeOneTemp [counter2], timeSelectedCount++;
                                delete [] arrayTimeOneTemp;
                                
                                //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                                //    cout<<" arrayTimeSelected "<<counterA+1<<" "<<endl;
                                //}
                                
                                arrayTimeOneTemp = new int [positionReviseCount+50];
                                timeOneTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < positionReviseCount/7; counter2++){
                                    if (arrayPositionRevise [counter2*7+3] == valueTemp){
                                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+1], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+2], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+3], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+4], timeOneTempCount++;
                                        
                                        if (currentStatus == 0) currentStatus = arrayPositionRevise [counter2*7+5];
                                        
                                        if (currentStatus == 0) arrayTimeOneTemp [timeOneTempCount] = 2, timeOneTempCount++;
                                        else if (currentStatus == 1) arrayTimeOneTemp [timeOneTempCount] = 3, timeOneTempCount++;
                                        else arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+5], timeOneTempCount++;
                                        
                                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+6], timeOneTempCount++;
                                    }
                                    else{
                                        
                                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+1], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+2], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+3], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+4], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+5], timeOneTempCount++;
                                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+6], timeOneTempCount++;
                                    }
                                }
                                
                                positionReviseCount = 0;
                                for (int counter2 = 0; counter2 < timeOneTempCount; counter2++) arrayPositionRevise [positionReviseCount] = arrayTimeOneTemp [counter2], positionReviseCount++;
                                delete [] arrayTimeOneTemp;
                                
                                //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
                                //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
                                //	cout<<" arrayPositionRevise "<<counterA<<endl;
                                //}
                                
                                for (int counterY = 0; counterY < imageDimension; counterY++){
                                    for (int counterX = 0; counterX < imageDimension; counterX++){
                                        if (revisedWorkingMap [counterY][counterX] == valueTemp) revisedWorkingMap [counterY][counterX] = 0;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < positionReviseCount/7; counter2++){
                                    if (arrayPositionRevise [counter2*7+6] == lineageAmendTemp && arrayPositionRevise [counter2*7+4] == cellAmendTemp){
                                        arrayPositionRevise [counter2*7+6] = 0;
                                        arrayPositionRevise [counter2*7+4] = 0;
                                    }
                                }
                                
                                int *arrayFluOutlineTemp = new int [expandFluorescentOutlineCount+50];
                                int fluOutlineTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentOutlineCount/4; counter2++){
                                    if (expandFluorescentOutline [counter2*4+2] != valueTemp){
                                        arrayFluOutlineTemp [fluOutlineTempCount] = expandFluorescentOutline [counter2*4], fluOutlineTempCount++;
                                        arrayFluOutlineTemp [fluOutlineTempCount] = expandFluorescentOutline [counter2*4+1], fluOutlineTempCount++;
                                        arrayFluOutlineTemp [fluOutlineTempCount] = expandFluorescentOutline [counter2*4+2], fluOutlineTempCount++;
                                        arrayFluOutlineTemp [fluOutlineTempCount] = expandFluorescentOutline [counter2*4+3], fluOutlineTempCount++;
                                    }
                                }
                                
                                expandFluorescentOutlineCount = 0;
                                for (int counter2 = 0; counter2 < fluOutlineTempCount; counter2++) expandFluorescentOutline [expandFluorescentOutlineCount] = arrayFluOutlineTemp [counter2], expandFluorescentOutlineCount++;
                                
                                delete [] arrayFluOutlineTemp;
                                
                                int *arrayFluAreaTemp = new int [expandFluorescentDataCount+50];
                                int fluAreaTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentDataCount/4; counter2++){
                                    if (expandFluorescentData [counter2*4] != valueTemp){
                                        arrayFluAreaTemp [fluAreaTempCount] = expandFluorescentData [counter2*4], fluAreaTempCount++;
                                        arrayFluAreaTemp [fluAreaTempCount] = expandFluorescentData [counter2*4+1], fluAreaTempCount++;
                                        arrayFluAreaTemp [fluAreaTempCount] = expandFluorescentData [counter2*4+2], fluAreaTempCount++;
                                        arrayFluAreaTemp [fluAreaTempCount] = expandFluorescentData [counter2*4+3], fluAreaTempCount++;
                                    }
                                }
                                
                                expandFluorescentDataCount = 0;
                                for (int counter2 = 0; counter2 < fluAreaTempCount; counter2++) expandFluorescentData [expandFluorescentDataCount] = arrayFluAreaTemp [counter2], expandFluorescentDataCount++;
                                
                                delete [] arrayFluAreaTemp;
                            }
                        }
                        
                        //-----Process Connect pixels-----
                        maxVectorNumber++;
                        pixNumberRef [counter1] = maxVectorNumber;
                        
                        if (type == 1 && counter1 == targetEntryConnectNo) results = maxVectorNumber; //----Return Vector No to process Fluorescent-----
                        
                        if (positionReviseCount+outlineDataSetCount*3 > positionReviseLimit){
                            positionReviseAddition = outlineDataSetCount*3;
                            
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate positionRevSelectedUpDate];
                        }
                        
                        lastConnectPosition = positionReviseCount/7;
                        
                        for (int counter2 = 0; counter2 < outlineDataSetCount/3; counter2++){
                            if (outlineDataSet [counter2*3] == counter1){
                                arrayPositionRevise [positionReviseCount] = outlineDataSet [counter2*3+1]+horizontalStart, positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = outlineDataSet [counter2*3+2]+verticalStart, positionReviseCount++;
                                
                                if (outlineDataSet [counter2*3+2]+verticalStart >= 0 && outlineDataSet [counter2*3+2]+verticalStart < imageDimension && outlineDataSet [counter2*3+1]+horizontalStart >= 0 && outlineDataSet [counter2*3+1]+horizontalStart < imageDimension){
                                    arrayPositionRevise [positionReviseCount] = sourceImage [outlineDataSet [counter2*3+2]+verticalStart][outlineDataSet [counter2*3+1]+horizontalStart], positionReviseCount++;
                                }
                                else arrayPositionRevise [positionReviseCount] = 100, positionReviseCount++;
                                
                                arrayPositionRevise [positionReviseCount] = maxVectorNumber, positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
                        //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
                        //	cout<<" arrayPositionRevise "<<counterA<<endl;
                        //}
                        
                        if (type == 2){
                            gravityX1 = 0;
                            gravityY1 = 0;
                            totalGRCount = 0;
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] == counter1 && targetMap [counterY][counterX] == 0 && internalZeroMap [counterY][counterX] == 0){
                                        revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] = maxVectorNumber;
                                        
                                        gravityX1 = gravityX1+counterX+horizontalStart;
                                        gravityY1 = gravityY1+counterY+verticalStart;
                                        totalGRCount++;
                                    }
                                }
                            }
                            
                            gravityX1 = (int)(gravityX1/(double)totalGRCount);
                            gravityY1 = (int)(gravityY1/(double)totalGRCount);
                        }
                        else{
                            
                            gravityX1 = 0;
                            gravityY1 = 0;
                            totalGRCount = 0;
                            
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] == counter1 && internalZeroMap [counterY][counterX] == 0){
                                        gravityX1 = gravityX1+counterX+horizontalStart;
                                        gravityY1 = gravityY1+counterY+verticalStart;
                                        totalGRCount++;
                                    }
                                }
                            }
                            
                            gravityX1 = (int)(gravityX1/(double)totalGRCount);
                            gravityY1 = (int)(gravityY1/(double)totalGRCount);
                        }
                        
                        divisionSetFlag = 0;
                        
                        if (type == 1 && counter1 == targetEntryConnectNo){
                            for (int counter2 = 0; counter2 < positionReviseCount/7; counter2++){
                                if (arrayPositionRevise [counter2*7+3] == maxVectorNumber){
                                    arrayPositionRevise [counter2*7+6] = lineageAmendTemp*-1;
                                    arrayPositionRevise [counter2*7+5] = 1;
                                    arrayPositionRevise [counter2*7+4] = cellAmendTemp;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
                            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
                            //	cout<<" arrayPositionRevise "<<counterA<<endl;
                            //}
                            
                            connectNoTemp2 = -1;
                            
                            for (int counter2 = 0; counter2 < lineageGRCurrentCount/4; counter2++){
                                if ((divisionTypeHold == 2 && cellDivisionSetCount == 0) || (divisionTypeHold == 3 && cellDivisionSetCount == 0) || (divisionTypeHold == 4 && cellDivisionSetCount == 0)){
                                    if (arrayLineageGRCurrent [counter2*4] == imageNumberTrackForDisplay){
                                        connectNoTemp2 = counter2*4;
                                        break;
                                    }
                                }
                                else if (fusionOperation == 1){
                                    if (arrayLineageGRCurrent [counter2*4] == imageNumberTrackForDisplay){
                                        connectNoTemp2 = counter2*4;
                                        break;
                                    }
                                }
                                else if (arrayLineageGRCurrent [counter2*4] == imageNumberTrackForDisplay && arrayLineageGRCurrent [counter2*4+3] == cellAmendTemp){
                                    connectNoTemp2 = counter2*4;
                                    break;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < lineageGRCurrentCount/4; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrent [counterA*4+counterB];
                            //    cout<<" arrayLineageGRCurrent " <<counterA<<endl;
                            //}
                            
                            if (connectNoTemp2 == -1 && lineageGRCurrentCount+4 > lineageGRCurrentLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate lineageGRCurrentUpDate];
                            }
                            
                            if (connectNoTemp2 == -1) lineageGRCurrentCountTemp = lineageGRCurrentCount;
                            else lineageGRCurrentCountTemp = connectNoTemp2;
                            
                            arrayLineageGRCurrent [lineageGRCurrentCountTemp] = imageNumberTrackForDisplay, lineageGRCurrentCountTemp++;
                            arrayLineageGRCurrent [lineageGRCurrentCountTemp] = gravityX1, lineageGRCurrentCountTemp++;
                            arrayLineageGRCurrent [lineageGRCurrentCountTemp] = gravityY1, lineageGRCurrentCountTemp++;
                            arrayLineageGRCurrent [lineageGRCurrentCountTemp] = cellAmendTemp, lineageGRCurrentCountTemp++;
                            
                            //for (int counterA = 0; counterA < lineageGRCurrentCount/4; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrent [counterA*4+counterB];
                            //    cout<<" arrayLineageGRCurrent "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < lineageGravityCenterCurrentHoldCount/4; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGravityCenterCurrentHold [counterA*4+counterB];
                            //    cout<<" arrayLineageGravityCenterCurrentHold "<<counterA<<endl;
                            //}
                            
                            lineageGravityCenterCurrentHoldCount = 0;
                            
                            for (int counter2 = 0; counter2 < lineageGRCurrentCountTemp/4; counter2++){
                                if (arrayLineageGRCurrent [counter2*4] == imageNumberTrackForDisplay){
                                    arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter2*4], lineageGravityCenterCurrentHoldCount++;
                                    arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter2*4+1], lineageGravityCenterCurrentHoldCount++;
                                    arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter2*4+2], lineageGravityCenterCurrentHoldCount++;
                                    arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter2*4+3], lineageGravityCenterCurrentHoldCount++;
                                }
                            }
                            
                            if (connectNoTemp2 == -1) lineageGRCurrentCount = lineageGRCurrentCountTemp;
                            
                            if ((divisionTypeHold == 2 && cellDivisionSetCount == 0) || (divisionTypeHold == 3 && cellDivisionSetCount == 0) || (divisionTypeHold == 4 && cellDivisionSetCount == 0)){
                                cellDivisionSetCount = 1, divisionSetFlag = 1;
                                
                                for (int counter2 = 0; counter2 < eventSequenceCount/4; counter2++){
                                    if (arrayEventSequence [counter2*4] == imageNumberTrackForDisplay){
                                        if (divisionTypeHold == 2){
                                            arrayEventSequence [counter2*4+1] = 32;
                                            arrayEventSequence [counter2*4+3] = cellAmendTemp;
                                        }
                                        if (divisionTypeHold == 3){
                                            arrayEventSequence [counter2*4+1] = 42;
                                            arrayEventSequence [counter2*4+3] = cellAmendTemp;
                                        }
                                        if (divisionTypeHold == 4){
                                            arrayEventSequence [counter2*4+1] = 52;
                                            arrayEventSequence [counter2*4+3] = cellAmendTemp;
                                        }
                                        break;
                                    }
                                }
                                
                                eventSequenceHoldCount = 0;
                                
                                for (int counter2 = 0; counter2 < eventSequenceCount/4; counter2++){
                                    if (arrayEventSequence [counter2*4] == imageNumberTrackForDisplay){
                                        arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter2*4], eventSequenceHoldCount++;
                                        arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter2*4+1], eventSequenceHoldCount++;
                                        arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter2*4+2], eventSequenceHoldCount++;
                                        arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter2*4+3], eventSequenceHoldCount++;
                                    }
                                }
                            }
                            else if (fusionOperation == 1){
                                for (int counter2 = 0; counter2 < eventSequenceCount/4; counter2++){
                                    if (arrayEventSequence [counter2*4] == imageNumberTrackForDisplay){
                                        arrayEventSequence [counter2*4+1] = 91;
                                        arrayEventSequence [counter2*4+2] = lineageAmendTemp;
                                        arrayEventSequence [counter2*4+3] = cellAmendTemp;
                                        break;
                                    }
                                }
                                
                                eventSequenceHoldCount = 0;
                                
                                for (int counter2 = 0; counter2 < eventSequenceCount/4; counter2++){
                                    if (arrayEventSequence [counter2*4] == imageNumberTrackForDisplay){
                                        arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter2*4], eventSequenceHoldCount++;
                                        arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter2*4+1], eventSequenceHoldCount++;
                                        arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter2*4+2], eventSequenceHoldCount++;
                                        arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter2*4+3], eventSequenceHoldCount++;
                                    }
                                }
                            }
                            else if ((int)targetLostMark.find("Lost") != -1){
                                if (eventSequenceCount+4 > eventSequenceLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate eventSequenceUpDate];
                                }
                                
                                eventFind = 0;
                                
                                for (int counter2 = 0; counter2 < eventSequenceCount/4; counter2++){
                                    if (arrayEventSequence [counter2*4] == imageNumberTrackForDisplay && arrayEventSequence [counter2*4+1] != 0 && arrayEventSequence [counter2*4+2] == lineageAmendTemp && arrayEventSequence [counter2*4+3] == cellAmendTemp){
                                        eventFind = 1;
                                    }
                                }
                                
                                if (eventFind == 0){
                                    arrayEventSequence [eventSequenceCount] = imageNumberTrackForDisplay, eventSequenceCount++;
                                    arrayEventSequence [eventSequenceCount] = 2, eventSequenceCount++;
                                    arrayEventSequence [eventSequenceCount] = lineageAmendTemp, eventSequenceCount++;
                                    arrayEventSequence [eventSequenceCount] = cellAmendTemp, eventSequenceCount++;
                                }
                                
                                eventSequenceHoldCount = 0;
                                
                                for (int counter2 = 0; counter2 < eventSequenceCount/4; counter2++){
                                    if (arrayEventSequence [counter2*4] == imageNumberTrackForDisplay){
                                        arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter2*4], eventSequenceHoldCount++;
                                        arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter2*4+1], eventSequenceHoldCount++;
                                        arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter2*4+2], eventSequenceHoldCount++;
                                        arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter2*4+3], eventSequenceHoldCount++;
                                    }
                                }
                            }
                            
                            if (divisionTypeHold == 0 || fusionOperation == 1 || (divisionTypeHold >= 2 && cellDivisionSetCount == 1)){
                                gravityCenterXHold1 = gravityX1;
                                gravityCenterYHold1 = gravityY1;
                                gravityAverageHold1 = averageIntensity;
                                gravityCellNo1 = cellAmendTemp;
                            }
                            else if ((divisionTypeHold >= 2 && cellDivisionSetCount == 2)){
                                gravityCenterXHold2 = gravityX1;
                                gravityCenterYHold2 = gravityY1;
                                gravityAverageHold2 = averageIntensity;
                                gravityCellNo2 = cellAmendTemp;
                            }
                            else if ((divisionTypeHold >= 3 && cellDivisionSetCount == 3)){
                                gravityCenterXHold3 = gravityX1;
                                gravityCenterYHold3 = gravityY1;
                                gravityAverageHold3 = averageIntensity;
                                gravityCellNo3 = cellAmendTemp;
                            }
                            else if ((divisionTypeHold >= 4 && cellDivisionSetCount == 4)){
                                gravityCenterXHold4 = gravityX1;
                                gravityCenterYHold4 = gravityY1;
                                gravityAverageHold4 = averageIntensity;
                                gravityCellNo4 = cellAmendTemp;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
                        //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
                        //	cout<<" arrayEventSequence "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < lineageGRCurrentCount/4; counterA++){
                        //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrent [counterA*4+counterB];
                        //	cout<<" arrayLineageGRCurrent"<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
                        //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
                        //	cout<<" arrayPositionRevise "<<counterA<<endl;
                        //}
                        
                        if (gravityCenterRevCount+12 > gravityCenterRevLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate gravityCenterRevUpDate];
                        }
                        
                        arrayGravityCenterRev [gravityCenterRevCount] = gravityX1, gravityCenterRevCount++;
                        arrayGravityCenterRev [gravityCenterRevCount] = gravityY1, gravityCenterRevCount++;
                        arrayGravityCenterRev [gravityCenterRevCount] = gravityCenter1 [2], gravityCenterRevCount++;
                        arrayGravityCenterRev [gravityCenterRevCount] = averageIntensity, gravityCenterRevCount++;
                        arrayGravityCenterRev [gravityCenterRevCount] = maxVectorNumber, gravityCenterRevCount++;
                        arrayGravityCenterRev [gravityCenterRevCount] = 0, gravityCenterRevCount++;
                        
                        //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
                        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
                        //	cout<<" arrayGravityCenterRev "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                        //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                        //	cout<<" arrayTimeSelected "<<counterA+1<<" "<<counter1<<endl;
                        //}
                        
                        if (associateDataCount+12 > associateDataLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate associateDataUpDate];
                        }
                        
                        arrayAssociateData [associateDataCount] = maxVectorNumber, associateDataCount++;
                        arrayAssociateData [associateDataCount] = 0, associateDataCount++;
                        arrayAssociateData [associateDataCount] = 0, associateDataCount++;
                        arrayAssociateData [associateDataCount] = 0, associateDataCount++;
                        arrayAssociateData [associateDataCount] = 0, associateDataCount++;
                        arrayAssociateData [associateDataCount] = 0, associateDataCount++;
                        
                        if (timeSelectedCount+10 > timeSelectedLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate timeSelectedUpDate];
                        }
                        
                        if (type == 1 && counter1 == targetEntryConnectNo) arrayTimeSelected [timeSelectedCount] = 7, timeSelectedCount++;
                        else arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                        
                        arrayTimeSelected [timeSelectedCount] = lineEntryNumber, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = lastConnectPosition, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = maxVectorNumber, timeSelectedCount++;
                        
                        if (type == 1 && counter1 == targetEntryConnectNo){
                            arrayTimeSelected [timeSelectedCount] = lineageAmendTemp, timeSelectedCount++;
                        }
                        else arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                        
                        //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                        //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                        //	cout<<" arrayTimeSelected "<<counterA+1<<" "<<counter1<<endl;
                        //}
                        
                        if (type == 1 && counter1 == targetEntryConnectNo){
                            //=========1. Lineage No, 2. connect No, 3. image number, 4. cell no, 5. target (0: non-target, 1: target), 6. reserve=========
                            
                            //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
                            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
                            //	cout<<" arrayConnectLineageRel "<<counterA+1<<" "<<counter1<<endl;
                            //}
                            
                            if (connectLineageRelCount+6 > connectLineageRelLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate connectLineageRelUpDate];
                            }
                            
                            if (connectLineageRelCount == 0){
                                arrayConnectLineageRel [connectLineageRelCount] = lineageAmendTemp, connectLineageRelCount++;
                                arrayConnectLineageRel [connectLineageRelCount] = timeSelectedCount/10, connectLineageRelCount++;
                                arrayConnectLineageRel [connectLineageRelCount] = imageNumberTrackForDisplay, connectLineageRelCount++;
                                arrayConnectLineageRel [connectLineageRelCount] = cellAmendTemp, connectLineageRelCount++;
                                arrayConnectLineageRel [connectLineageRelCount] = 1, connectLineageRelCount++;
                                arrayConnectLineageRel [connectLineageRelCount] = 0, connectLineageRelCount++;
                            }
                            else if (connectLineageRelCount > 0){
                                int *arrayConnectLineageRelTemp = new int [connectLineageRelCount+50];
                                connectLineageRelTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < connectLineageRelCount/6; counter2++){
                                    if ((((divisionTypeHold == 2 && divisionSetFlag == 1) || (divisionTypeHold == 3 && divisionSetFlag == 1) || (divisionTypeHold == 4 && divisionSetFlag == 1)) && arrayConnectLineageRel [counter2*6] == lineageAmendTemp && arrayConnectLineageRel [counter2*6+3] == cellAmendOriginal) || (arrayConnectLineageRel [counter2*6] == lineageAmendTemp && arrayConnectLineageRel [counter2*6+3] == cellAmendTemp)){
                                    }
                                    else{
                                        
                                        arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRel [counter2*6], connectLineageRelTempCount++;
                                        arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRel [counter2*6+1], connectLineageRelTempCount++;
                                        arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRel [counter2*6+2], connectLineageRelTempCount++;
                                        arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRel [counter2*6+3], connectLineageRelTempCount++;
                                        arrayConnectLineageRelTemp [connectLineageRelTempCount] = 0, connectLineageRelTempCount++;
                                        arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRel [counter2*6+5], connectLineageRelTempCount++;
                                    }
                                }
                                
                                arrayConnectLineageRelTemp [connectLineageRelTempCount] = lineageAmendTemp, connectLineageRelTempCount++;
                                arrayConnectLineageRelTemp [connectLineageRelTempCount] = timeSelectedCount/10, connectLineageRelTempCount++;
                                arrayConnectLineageRelTemp [connectLineageRelTempCount] = imageNumberTrackForDisplay, connectLineageRelTempCount++;
                                arrayConnectLineageRelTemp [connectLineageRelTempCount] = cellAmendTemp, connectLineageRelTempCount++;
                                arrayConnectLineageRelTemp [connectLineageRelTempCount] = 1, connectLineageRelTempCount++;
                                arrayConnectLineageRelTemp [connectLineageRelTempCount] = 0, connectLineageRelTempCount++;
                                
                                // for (int counterA = 0; counterA < connectLineageRelTempCount/6; counterA++){
                                //     for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRelTemp [counterA*6+counterB];
                                //     cout<<" arrayConnectLineageRelTemp "<<counterA+1<<" "<<counter1<<endl;
                                //}
                                
                                connectLineageRelCount = 0;
                                
                                for (int counter2 = 0; counter2 < connectLineageRelTempCount; counter2++) arrayConnectLineageRel [connectLineageRelCount] = arrayConnectLineageRelTemp [counter2], connectLineageRelCount++;
                                
                                delete [] arrayConnectLineageRelTemp;
                                
                                arrayConnectLineageRelTemp = new int [connectLineageRelCount+50];
                                connectLineageRelTempCount = 0;
                                
                                for (int counter2 = 1; counter2 < maxVectorNumber+1; counter2++){
                                    for (int counter3 = 0; counter3 < connectLineageRelCount/6; counter3++){
                                        if (arrayConnectLineageRel [counter3*6+1] == counter2){
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRel [counter3*6], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRel [counter3*6+1], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRel [counter3*6+2], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRel [counter3*6+3], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRel [counter3*6+4], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = arrayConnectLineageRel [counter3*6+5], connectLineageRelTempCount++;
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < connectLineageRelTempCount/6; counterA++){
                                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRelTemp [counterA*6+counterB];
                                //    cout<<" arrayConnectLineageRelTemp "<<counterA+1<<" "<<counter1<<endl;
                                //}
                                
                                connectLineageRelCount = 0;
                                
                                for (int counter2 = 0; counter2 < connectLineageRelTempCount; counter2++) arrayConnectLineageRel [connectLineageRelCount] = arrayConnectLineageRelTemp [counter2], connectLineageRelCount++;
                                
                                delete [] arrayConnectLineageRelTemp;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < lineageGRCurrentCount/4; counterA++){
                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrent [counterA*4+counterB];
                        //    cout<<" arrayLineageGRCurrent "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
                        //		for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
                        //		cout<<" arrayConnectLineageRel "<<counterA+1<<" "<<counter1<<endl;
                        //}
                    }
                }
                
                if (type == 1){
                    int **mapTemp = new int *[dimension+1];
                    for (int counter1 = 0; counter1 < dimension+1; counter1++) mapTemp [counter1] = new int [dimension+1];
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) mapTemp [counterY][counterX] = 0;
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMap [counterY][counterX] != 0){
                                mapTemp [counterY][counterX] = pixNumberRef [connectivityMap [counterY][counterX]];
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            connectivityMap [counterY][counterX] = 0;
                            connectivityMap [counterY][counterX] = mapTemp [counterY][counterX];
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
                    //	cout<<" connectivityMap "<<counterA<<endl;
                    // }
                    
                    for (int counter1 = 0; counter1 < dimension+1; counter1++) delete [] mapTemp [counter1];
                    delete [] mapTemp;
                }
                
                //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
                //    cout<<" arrayPositionRevise "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                //    cout<<" arrayTimeSelected "<<counterA+1<<" "<<endl;
                //}
            }
        }
    }
    
    //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
    //    cout<<" eventSequence "<<counterA<<endl;
    //}
    
    delete [] pixNumberRef;
    delete [] outlineDataSet;
    delete [] connectedPix;
    
    return results;
}

@end
