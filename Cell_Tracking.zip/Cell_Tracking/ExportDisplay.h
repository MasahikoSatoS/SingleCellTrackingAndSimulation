//
//  ExportDisplay.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2018-01-23.
//
//

#ifndef EXPORTDIAPLAY_H
#define EXPORTDIAPLAY_H
#import "Controller.h" 
#endif

@interface ExportDisplay : NSView{
    int mouseDragFlag; //Window control
    int magnificationExport; //Magnification fold
    int clickFlag; //Click flag
    int displayModeSelect; //Display mode selection
    int timingCount; //Timing count
    int imageNoCount; //Image no count
    int imageNoWrite; //Image no write
    double xPositionAdjustExport; //X Position Magnification Adjust
    double yPositionAdjustExport; //Y Position Magnification Adjust
    double xPointDownExport; //X Position Mouse Down
    double yPointDownExport; //Y Position Mouse Down
    double xPointDragExport; //X Position Mouse drag
    double yPointDragExport; //Y Position mouse drag
    double xPositionMoveExport; //X Position Total Move by Drag
    double yPositionMoveExport; //Y Position Total Move by Drag
    
    int exportColorStatus; //Export color status
    int imageWidthExport; //Image width hold
    int imageNumberExportForDisplay; //Image NO
    int colorNoExport; //Color no hold for export
    int channelNoOfExportImage; //Export image channel no
    int motilityStatusHold; //Motility status
    
    double xPositionExport; //X Position Image Origin
    double yPositionExport; //Y Position Image Origin
    double windowWidthExport; //Window width
    double windowHeightExport; //Window hight
    double boxStartX; //Box draw start X
    double boxStartY; //Box draw start Y
    double boxEndX; //Box draw end X
    double boxEndY; //Box draw end Y
    
    IBOutlet NSWindow *exportMainWindow;
    
    NSImage *exportImage;
    
    NSTimer *exportMainTimer2;
    
    id ascIIconversion;
    id fileUpdate;
}

-(void)display;

@end
