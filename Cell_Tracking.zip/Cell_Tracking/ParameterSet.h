//
//  ParameterSet.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2016-02-18.
//
//

#ifndef PARAMETERSET_H
#define PARAMETERSET_H
#import "Controller.h"
#endif

@interface ParameterSet : NSObject <NSTextFieldDelegate>{
    IBOutlet NSTextField *sdIntervalDisplay;
    IBOutlet NSTextField *valueIntervalDisplay;
    IBOutlet NSTextField *distanceIntervalDisplay;
    IBOutlet NSTextField *areaDisplay;
    IBOutlet NSTextField *relativeLowDisplay;
    IBOutlet NSTextField *relativeHighDisplay;
    IBOutlet NSTextField *overlapPercent;
    
    IBOutlet NSTextField *firstColDisplay;
    IBOutlet NSTextField *secondColDisplay;
    IBOutlet NSTextField *thirdColDisplay;
    IBOutlet NSTextField *typeDisplay;
    
    IBOutlet NSTextField *jumpAllowDisplay;
    IBOutlet NSTextField *expandAllowDisplay;
    IBOutlet NSTextField *mapMergeDisplay;
    IBOutlet NSTextField *cgCenterDisplay;
    IBOutlet NSTextField *mitosisOnOffDisplay;
    IBOutlet NSTextField *fusionMarkOnOffDisplay;
    
    IBOutlet NSTextField *autoCheckDistanceDisplay;
    IBOutlet NSTextField *autoCheckDistanceFoldDisplay;
    IBOutlet NSTextField *autoCheckAreaDisplay;
    IBOutlet NSTextField *autoCheckDivisionDisplay;
    IBOutlet NSTextField *autoCheckIntensityDisplay;
    IBOutlet NSTextField *optionalSearchPercentDisplay;
    
    IBOutlet NSStepper *stepperSDInterval;
    IBOutlet NSStepper *stepperValueInterval;
    IBOutlet NSStepper *stepperDistanceInterval;
    IBOutlet NSStepper *stepperArea;
    IBOutlet NSStepper *stepperRelativeLow;
    IBOutlet NSStepper *stepperRelativeHigh;
    IBOutlet NSStepper *stepperOverlap;
    
    IBOutlet NSStepper *stepperAutoCheckDistance;
    IBOutlet NSStepper *stepperAutoCheckDistanceFold;
    IBOutlet NSStepper *stepperAutoCheckArea;
    IBOutlet NSStepper *stepperAutoCheckDivision;
    IBOutlet NSStepper *stepperAutoCheckIntensity;
    IBOutlet NSStepper *stepperOptionalSearchPercent;
    
    IBOutlet NSWindow *parameterSetWindow;
    
    NSTimer *parameterSetTimer;
    
    NSWindowController *parameterSetWindowController;
    
    id dataSaveRead;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;

-(IBAction)closeWindow:(id)sender;
-(IBAction)switchMode:(id)sender;
-(IBAction)stepperActionSDInterval:(id)sender;
-(IBAction)stepperActionValueInterval:(id)sender;
-(IBAction)stepperActionDistanceInterval:(id)sender;
-(IBAction)stepperActionArea:(id)sender;
-(IBAction)stepperActionRelativeLow:(id)sender;
-(IBAction)stepperActionRelativeHigh:(id)sender;
-(IBAction)jumpAllowSet:(id)sender;
-(IBAction)expandAllowSet:(id)sender;
-(IBAction)mergeSet:(id)sender;
-(IBAction)cGCenterLimitSet:(id)sender;
-(IBAction)stepperActionOverlap:(id)sender;
-(IBAction)stepperAutoCheckDistanceSet:(id)sender;
-(IBAction)stepperAutoCheckDistanceFoldSet:(id)sender;
-(IBAction)stepperAutoCheckAreaSet:(id)sender;
-(IBAction)stepperAutoCheckDivisionSet:(id)sender;
-(IBAction)stepperAutoCheckIntensitySet:(id)sender;
-(IBAction)stepperOptionalSearchPercentSet:(id)sender;
-(IBAction)mitosisOnSet:(id)sender;
-(IBAction)fusionMarkOnSet:(id)sender;

@end
