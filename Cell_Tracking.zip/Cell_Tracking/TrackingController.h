//
// TrackingController.h
// Cell_Tracking
//
// Created by Masahiko Sato on 13/08/09.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef TRACKINGCONTROLLER_H
#define TRACKINGCONTROLLER_H
#import "Controller.h" 
#endif

@interface TrackingController : NSObject <NSTextFieldDelegate, NSToolbarItemValidation>{
    int lineSetErrorFlag; //Line set error
    int listLoadingStart; //List loading status
    
    IBOutlet NSTextField *patternTypeDisplay;
    IBOutlet NSTextField *inputData;
    IBOutlet NSTextField *inputDisplayData;
    IBOutlet NSTextField *jumpDisplay;
    IBOutlet NSTextField *jumpImageDisplay;
    IBOutlet NSTextField *areaLimitDisplay;
    IBOutlet NSTextField *backForwardDisplay;
    IBOutlet NSTextField *stepperValueDisplay;
    IBOutlet NSTextField *errorExplanationDisplay;
    IBOutlet NSTextField *fluorescentModeDisplay;
    IBOutlet NSTextField *fluorescentRangeDiv;
    IBOutlet NSTextField *fluorescentMaxDisplay;
    IBOutlet NSStepper *stepperLimit;
    
    IBOutlet NSWindow *trackingControllerWindow;
    IBOutlet NSWindow *displayControllerWindow;
    IBOutlet NSWindow *listViewControllerWindow;
    
    IBOutlet NSProgressIndicator *backSave;
    
    NSWindowController *listViewWindControllerTC;
    NSWindowController *displayWindControllerTC;
    NSWindowController *imageEditWindControllerTC;
    
    NSTimer *trackControlTimer;
    NSTimer *trackControlTimer2;
    NSTimer *trackWindowTimer;
    NSTimer *navigationWindowTimer;
    NSTimer *listWindowTimer;
    
    id trackingSet;
    id lineSet;
    id addDelete;
    id trackRecord;
    id snapShot;
    id folderCopy;
    id fileUpdate;
    id dataSaveRead;
}

-(id)init;
-(void)dealloc;
-(void)statusMonitor;
-(void)statusMonitor2;
-(void)reDisplayTrackingWindow;
-(void)reDisplayNavigationWindow;

-(void)lineageListCreation;
-(void)cellListCreation;
-(void)lineSelectProcess;
-(void)imageNoSet:(int)setNumber;
-(int)lineExtend:(int)groupNoMerge;
-(void)saveDataMain;
-(void)deleteProgeniesMain;
-(void)checkOKMain;
-(void)listDataUploading;

-(IBAction)saveData:(id)sender;
-(IBAction)closeWindowTracking:(id)sender;
-(IBAction)closeWindowNavigation:(id)sender;
-(IBAction)closeWindowList:(id)sender;
-(IBAction)areaSelect:(id)sender;
-(IBAction)lineSelect:(id)sender;
-(IBAction)lineSet:(id)sender;
-(IBAction)listDisplay:(id)sender;
-(IBAction)listRemove:(id)sender;
-(IBAction)reviseLineDone:(id)sender;
-(IBAction)displaySynchro:(id)sender;
-(IBAction)displayListSwitch:(id)sender;
-(IBAction)shotTake:(id)sender;
-(IBAction)shotDelete:(id)sender;
-(IBAction)characterDisplaySet:(id)sender;
-(IBAction)characterDisplayNavSet:(id)sender;
-(IBAction)deleteProgenies:(id)sender;
-(IBAction)imageJump:(id)sender;
-(IBAction)imageDisplayJump:(id)sender;
-(IBAction)areaLimit:(id)sender;
-(IBAction)areaDelete:(id)sender;
-(IBAction)cutSetDIC1:(id)sender;
-(IBAction)cutSetDIC2:(id)sender;
-(IBAction)cutSetDIC3:(id)sender;
-(IBAction)cutSetDIC4:(id)sender;
-(IBAction)cutSetDIC5:(id)sender;
-(IBAction)cutSetDIC6:(id)sender;
-(IBAction)cutSetDIC7:(id)sender;
-(IBAction)cutChangeDIC:(id)sender;
-(IBAction)cutChangeFLU:(id)sender;
-(IBAction)backForwardSet:(id)sender;
-(IBAction)checkOK:(id)sender;
-(IBAction)listOnOff:(id)sender;
-(IBAction)stepperAction:(id)sender;
-(IBAction)forceAreaSet:(id)sender;
-(IBAction)imageSeqStart:(id)sender;
-(IBAction)fluorescentDisplayMode:(id)sender;
-(IBAction)fluorescentDisplayStep:(id)sender;

-(BOOL)validateToolbarItem:(NSToolbarItem *)item;

@end
