//
//  ImageDisplay2.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2/2/17.
//
//

#ifndef IMAGEDISPLAY2_H
#define IMAGEDISPLAY2_H
#import "Controller.h" 
#endif

@interface ImageDisplay2 : NSView {
    IBOutlet NSImage *seqImage2;
    
    id merge;
    id lineSet;
    id dataSaveRead;
}

-(void)keyDown:(NSEvent *)event;
-(void)mouseDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
