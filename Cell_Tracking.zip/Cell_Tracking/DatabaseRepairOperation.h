//
//  DatabaseRepairOperation.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 12/6/16.
//
//

#ifndef DATABASEREPAIROPERATION_H
#define DATABASEREPAIROPERATION_H
#import "Controller.h" 
#endif

@interface DatabaseRepairOperation : NSObject<NSTableViewDataSource>{
    int repairOperationTableCount; //Operation Table read count
    int rowRepairOperationTable; //Table row no. hold
    
    IBOutlet NSTextField *errorNoDisplay;
    
    IBOutlet NSTableView *tableViewDatabaseRepair;
    
    NSTimer *databaseRepairDisplayTimer;
    
    id fileUpdate;
    id dataSaveRead;
}

-(void)display;
-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

@end
