//
//  FluorescentQuantitationController.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 3/12/17.
//
//

#import "FluorescentQuantitationController.h"

NSString *notificationToFluoresentQuantOptions = @"notificationExecuteFluoresentQuantOptions";

@implementation FluorescentQuantitationController

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToFluoresentQuantOptions object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    fluorescentQuantOptionsController = [[NSWindowController alloc] initWithWindowNibName:@"FluorescentDivSet"];
    [fluorescentQuantOptionsController showWindow:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentQuantitationTable object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [fluorescentQuantOptionsWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [fluorescentQuantOptionsWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
}

-(void)reDisplayWindow{
    if (fluorescentOptionOperation == 3){
        [fluorescentQuantOptionsWindow makeKeyAndOrderFront:self];
        fluorescentOptionOperation = 1;
        [fluorescentQuantOptionsTimer invalidate];
    }
}

-(IBAction)mergeOpData:(id)sender{
    if (fluorescentOpInformationStatus == 1 && fluorescentOpInformationCount != 0){
        string extension = to_string(fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4]);
        
        if (extension.length() == 1) extension = "000"+extension;
        else if (extension.length() == 2) extension = "00"+extension;
        else if (extension.length() == 3) extension = "0"+extension;
        
        string mergeFilePath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_IFLevelData~"+extension+"="+to_string(fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4+1])+"_"+to_string(fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4+2])+"="+to_string(fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4+3]);
        
        string originalFilePath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_IFLevelData~"+extension+"=9"+"_9"+"=0";
        
        int originalFindFlag = 0;
        
        ifstream fin;
        
        fin.open(originalFilePath.c_str(), ios::in | ios::binary);
        
        if (fin.is_open()){
            fin.close();
            
            originalFindFlag = 1;
        }
        
        string connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
        
        struct stat sizeOfFile;
        long sizeForCopy = 0;
        
        if (originalFindFlag == 0){
            sizeForCopy = 0;
            
            if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            int *fluorescentLevelDataHoldTemp = new int [sizeForCopy+50];
            int fluorescentLevelDataTempCount = 0;
            
            if (sizeForCopy != 0){
                fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    int finData [8];
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            
                            if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                            else{
                                
                                fluorescentLevelDataHoldTemp [fluorescentLevelDataTempCount] = finData [2], fluorescentLevelDataTempCount++;
                                fluorescentLevelDataHoldTemp [fluorescentLevelDataTempCount] = finData [3], fluorescentLevelDataTempCount++;
                                fluorescentLevelDataHoldTemp [fluorescentLevelDataTempCount] = finData [4], fluorescentLevelDataTempCount++;
                                fluorescentLevelDataHoldTemp [fluorescentLevelDataTempCount] = finData [7], fluorescentLevelDataTempCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                    
                    if (fluorescentLevelDataTempCount != 0){
                        int readBit [3];
                        unsigned long indexCount = 0;
                        int dataTemp = 0;
                        char *writingArray = new char [fluorescentLevelDataTempCount*2+20];
                        
                        for (int counter1 = 0; counter1 < fluorescentLevelDataTempCount/4; counter1++){
                            dataTemp = fluorescentLevelDataHoldTemp [counter1*4];
                            
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            writingArray [indexCount] = (char)fluorescentLevelDataHoldTemp [counter1*4+1], indexCount++;
                            writingArray [indexCount] = (char)fluorescentLevelDataHoldTemp [counter1*4+2], indexCount++;
                            
                            dataTemp = fluorescentLevelDataHoldTemp [counter1*4+3];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                        }
                        
                        for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                        
                        ofstream outfile2 (originalFilePath.c_str(), ofstream::binary);
                        outfile2.write ((char*)writingArray, indexCount);
                        outfile2.close();
                        
                        delete [] writingArray;
                    }
                }
            }
            
            delete [] fluorescentLevelDataHoldTemp;
            
            fluorescentOpInformationHold [fluorescentOpInformationCount] = fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4], fluorescentOpInformationCount++;
            fluorescentOpInformationHold [fluorescentOpInformationCount] = 9, fluorescentOpInformationCount++;
            fluorescentOpInformationHold [fluorescentOpInformationCount] = 9, fluorescentOpInformationCount++;
            fluorescentOpInformationHold [fluorescentOpInformationCount] = 0, fluorescentOpInformationCount++;
        }
        
        sizeForCopy = 0;
        
        if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        int *fluorescentLevelDataHoldTemp = new int [sizeForCopy+50];
        int fluorescentLevelDataTempCount = 0;
        
        if (sizeForCopy != 0){
            fin.open(connectDataPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                fin.close();
                
                unsigned long readPosition = 0;
                int stepCount = 0;
                int finData [8];
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++;
                        finData [1] = uploadTemp [readPosition], readPosition++;
                        finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                        finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                        finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++;
                        finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                        
                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                        
                        if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                        else{
                            
                            fluorescentLevelDataHoldTemp [fluorescentLevelDataTempCount] = finData [2], fluorescentLevelDataTempCount++;
                            fluorescentLevelDataHoldTemp [fluorescentLevelDataTempCount] = finData [3], fluorescentLevelDataTempCount++;
                            fluorescentLevelDataHoldTemp [fluorescentLevelDataTempCount] = finData [4], fluorescentLevelDataTempCount++;
                            fluorescentLevelDataHoldTemp [fluorescentLevelDataTempCount] = finData [7], fluorescentLevelDataTempCount++;
                        }
                    }
                    
                } while (stepCount != 3);
                
                delete [] uploadTemp;
                
                sizeForCopy = 0;
                
                if (stat(mergeFilePath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                int *fluorescentLevelDataSourceTemp = new int [sizeForCopy+50];
                int fluorescentLevelDataSourceCount = 0;
                
                if (sizeForCopy != 0){
                    fin.open(mergeFilePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        readPosition = 0;
                        stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                else{
                                    
                                    fluorescentLevelDataSourceTemp [fluorescentLevelDataSourceCount] = finData [2], fluorescentLevelDataSourceCount++;
                                    fluorescentLevelDataSourceTemp [fluorescentLevelDataSourceCount] = finData [3], fluorescentLevelDataSourceCount++;
                                    fluorescentLevelDataSourceTemp [fluorescentLevelDataSourceCount] = finData [4], fluorescentLevelDataSourceCount++;
                                    fluorescentLevelDataSourceTemp [fluorescentLevelDataSourceCount] = finData [7], fluorescentLevelDataSourceCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                        
                        for (int counter1 = 0; counter1 < fluorescentLevelDataSourceCount/4; counter1++){
                            for (int counter2 = 0; counter2 < fluorescentLevelDataTempCount/4; counter2++){
                                if (fluorescentLevelDataSourceTemp [counter1*4] == fluorescentLevelDataHoldTemp [counter2*4] && fluorescentLevelDataSourceTemp [counter1*4+1] == fluorescentLevelDataHoldTemp [counter2*4+1]){
                                    if (fluorescentLevelDataSourceTemp [counter2*4+2] == 10) fluorescentLevelDataHoldTemp [counter1*4+2] = 0;
                                    else fluorescentLevelDataHoldTemp [counter1*4+2] = fluorescentLevelDataSourceTemp [counter2*4+2];
                                    
                                    break;
                                }
                            }
                        }
                        
                        if (fluorescentLevelDataTempCount != 0){
                            int readBit [3];
                            unsigned long indexCount = 0;
                            int dataTemp = 0;
                            char *writingArray = new char [fluorescentLevelDataTempCount*2+20];
                            
                            for (int counter1 = 0; counter1 < fluorescentLevelDataTempCount/4; counter1++){
                                dataTemp = fluorescentLevelDataHoldTemp [counter1*4];
                                
                                readBit [0] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [1] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [2] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                
                                writingArray [indexCount] = (char)fluorescentLevelDataHoldTemp [counter1*4+1], indexCount++;
                                writingArray [indexCount] = (char)fluorescentLevelDataHoldTemp [counter1*4+2], indexCount++;
                                
                                dataTemp = fluorescentLevelDataHoldTemp [counter1*4+3];
                                readBit [0] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [1] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [2] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                            }
                            
                            for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                            
                            ofstream outfile2 (connectDataPath.c_str(), ofstream::binary);
                            outfile2.write ((char*)writingArray, indexCount);
                            outfile2.close();
                            
                            delete [] writingArray;
                        }
                        
                        string mergeFilePath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_IFLevelData~"+extension+"="+to_string(fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4+1])+"_"+to_string(fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4+2])+"=1";
                        
                        if (mergeFilePath2 != mergeFilePath){
                            rename(mergeFilePath.c_str(), mergeFilePath2.c_str());
                            fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4+3] = 1;
                        }
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentQuantitationTable object:self];
                    }
                }
                
                delete [] fluorescentLevelDataSourceTemp;
            }
        }
        
        delete [] fluorescentLevelDataHoldTemp;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Fluorescent Level Data"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)restoreOriginalData:(id)sender{
    if (fluorescentOpInformationStatus == 1 && fluorescentOpInformationCount != 0){
        string extension = to_string(fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4]);
        
        if (extension.length() == 1) extension = "000"+extension;
        else if (extension.length() == 2) extension = "00"+extension;
        else if (extension.length() == 3) extension = "0"+extension;
        
        string restoreFilePath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_IFLevelData~"+extension+"="+to_string(fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4+1])+"_"+to_string(fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4+2])+"="+to_string(fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4+3]);
        
        string originalFilePath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_IFLevelData~"+extension+"=9_9"+"=0";
        
        if (restoreFilePath == originalFilePath){
            string connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
            
            remove(connectDataPath.c_str());
            rename(originalFilePath.c_str(), connectDataPath.c_str());
            
            string fluorescentFilePath;
            string fluorescentFilePath2;
            
            for (int counter1 = 1; counter1 <= 6; counter1++){
                for (int counter2 = 1; counter2 <= 4; counter2++){
                    fluorescentFilePath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_IFLevelData~"+extension+"="+to_string(counter1)+"_"+to_string(counter2)+"=1";
                    fluorescentFilePath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_IFLevelData~"+extension+"="+to_string(counter1)+"_"+to_string(counter2)+"=0";
                    
                    rename(fluorescentFilePath.c_str(), fluorescentFilePath2.c_str());
                }
            }
            
            int *fluorescentOpInformationHoldTemp = new int [fluorescentOpInformationCount+10];
            int fluorescentOpInformationHoldTempCount = 0;
            
            for (int counter1 = 0; counter1 < fluorescentOpInformationCount/4; counter1++){
                if (fluorescentOpInformationHold [counter1*4] != fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4] || fluorescentOpInformationHold [counter1*4+1] != 9 || fluorescentOpInformationHold [counter1*4+2] != 9){
                    fluorescentOpInformationHoldTemp [fluorescentOpInformationHoldTempCount] = fluorescentOpInformationHold [counter1*4], fluorescentOpInformationHoldTempCount++;
                    fluorescentOpInformationHoldTemp [fluorescentOpInformationHoldTempCount] = fluorescentOpInformationHold [counter1*4+1], fluorescentOpInformationHoldTempCount++;
                    fluorescentOpInformationHoldTemp [fluorescentOpInformationHoldTempCount] = fluorescentOpInformationHold [counter1*4+2], fluorescentOpInformationHoldTempCount++;
                    fluorescentOpInformationHoldTemp [fluorescentOpInformationHoldTempCount] = fluorescentOpInformationHold [counter1*4+3], fluorescentOpInformationHoldTempCount++;
                }
            }
            
            fluorescentOpInformationCount = 0;
            
            for (int counter1 = 0; counter1 < fluorescentOpInformationHoldTempCount; counter1++) fluorescentOpInformationHold [fluorescentOpInformationCount] = fluorescentOpInformationHoldTemp [counter1], fluorescentOpInformationCount++;
            
            delete [] fluorescentOpInformationHoldTemp;
            
            
            for (int counter1 = 0; counter1 < fluorescentOpInformationCount/4; counter1++){
                if (fluorescentOpInformationHold [counter1*4] == fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4]){
                    fluorescentOpInformationHold [counter1*4+3] = 0;
                }
            }
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentQuantitationTable object:self];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Original File Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Fluorescent Level Data"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clearSelectedData:(id)sender{
    if (fluorescentOpInformationStatus == 1 && fluorescentOpInformationCount != 0){
        string extension = to_string(fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4]);
        
        if (extension.length() == 1) extension = "000"+extension;
        else if (extension.length() == 2) extension = "00"+extension;
        else if (extension.length() == 3) extension = "0"+extension;
        
        if (fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4+2] != 9){
            string fluorescentFilePath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_IFLevelData~"+extension+"="+to_string(fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4+1])+"_"+to_string(fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4+2])+"="+to_string(fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4+3]);
            
            remove(fluorescentFilePath.c_str());
            
            int *fluorescentOpInformationHoldTemp = new int [fluorescentOpInformationCount+10];
            int fluorescentOpInformationHoldTempCount = 0;
            
            for (int counter1 = 0; counter1 < fluorescentOpInformationCount/4; counter1++){
                if (fluorescentOpInformationHold [counter1*4] != fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4] || fluorescentOpInformationHold [counter1*4+1] != fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4+1] || fluorescentOpInformationHold [counter1*4+2] != fluorescentOpInformationHold [fluorescentOpOperationTableCurrentRow*4+3]){
                    
                    fluorescentOpInformationHoldTemp [fluorescentOpInformationHoldTempCount] = fluorescentOpInformationHold [counter1*4], fluorescentOpInformationHoldTempCount++;
                    fluorescentOpInformationHoldTemp [fluorescentOpInformationHoldTempCount] = fluorescentOpInformationHold [counter1*4+1], fluorescentOpInformationHoldTempCount++;
                    fluorescentOpInformationHoldTemp [fluorescentOpInformationHoldTempCount] = fluorescentOpInformationHold [counter1*4+2], fluorescentOpInformationHoldTempCount++;
                    fluorescentOpInformationHoldTemp [fluorescentOpInformationHoldTempCount] = fluorescentOpInformationHold [counter1*4+3], fluorescentOpInformationHoldTempCount++;
                }
            }
            
            fluorescentOpInformationCount = 0;
            
            for (int counter1 = 0; counter1 < fluorescentOpInformationHoldTempCount; counter1++) fluorescentOpInformationHold [fluorescentOpInformationCount] = fluorescentOpInformationHoldTemp [counter1], fluorescentOpInformationCount++;
            
            delete [] fluorescentOpInformationHoldTemp;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentQuantitationTable object:self];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Original File"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Fluorescent Level Data"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)closeWindow:(id)sender{
    [fluorescentQuantOptionsWindow orderOut:self];
    fluorescentOptionOperation = 2;
    fluorescentQuantOptionsTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToFluoresentQuantOptions object:nil];
}

@end
