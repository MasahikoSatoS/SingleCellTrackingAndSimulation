//
// trackRecord.h
// Cell_Tracking
//
// Created by Masahiko Sato on 03/11/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef TRACKRECORD_H
#define TRACKRECORD_H
#import "Controller.h" 
#endif

@interface TrackRecord : NSObject {
    id addDelete;
    id trackingDataSave;
    id snapShot;
    id mitosisSD;
    id fileUpdate;
}

-(int)trackDataSaveMain:(int)recordType;

@end
