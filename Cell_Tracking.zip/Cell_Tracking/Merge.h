//
//  Merge.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2015-01-12.
//
//

#ifndef MERGE_H
#define MERGE_H
#import "Controller.h"
#endif

@interface Merge : NSObject {
    id fileUpdate;
}

-(void)mergeMain:(int)groupNoMerge :(int)numberOfEntry;
-(void)mergeConnect;
-(int)mergeAttach;
-(void)mergeExtendTrack;
-(void)mergeSelected;

@end
