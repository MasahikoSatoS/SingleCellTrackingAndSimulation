//
//  ImageDisplay3.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2/2/17.
//
//

#ifndef IMAGEDISPLAY3_H
#define IMAGEDISPLAY3_H
#import "Controller.h" 
#endif

@interface ImageDisplay3 : NSView {
    IBOutlet NSImage *seqImage3;
    
    id merge;
    id lineSet;
    id dataSaveRead;
}

-(void)keyDown:(NSEvent *)event;
-(void)mouseDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
