//
// NewAreaCreationTrack.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 13/10/11.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "NewAreaCreationTrack.h"

@implementation NewAreaCreationTrack

-(int)newAreaLineCut{
    int results = 0;
    mergeSelectCount = 0;
    
    string cellLineageExtract = cellLineageNoHold.substr(1);
    string cellNumberExtract = cellNoHold.substr(1);
    int cellLineageTempInt = atoi(cellLineageExtract.c_str());
    int cellNumberTempInt = atoi(cellNumberExtract.c_str());
    
    //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
    //	cout<<" arrayConnectLineageRel "<<counterA+1<<" "<<counter1<<endl;
    //}
    
    int connectNoTemp = 0;
    
    for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt) connectNoTemp = arrayConnectLineageRel [counter1*6+1];
    }
    
    int *connectNumber = new int [lineDataProcessingCount+50];
    int connectNumberCount = 0;
    
    //-----Find overlap connect-----
    for (int counter1 = 0; counter1 < lineDataProcessingCount/2; counter1++){
        int xPositionTemp = arrayLineDataProcessing [counter1*2];
        int yPositionTemp = arrayLineDataProcessing [counter1*2+1];
        
        if (revisedWorkingMap [yPositionTemp][xPositionTemp] == connectNoTemp) connectNumberCount++;
    }
    
    if (connectNumberCount > 0 && (connectNoTemp-1)*10+2 < timeSelectedCount && connectNoTemp != 0){
        int lineEntryNumber = 0;
        
        if (targetHoldCount != 0) lineEntryNumber = arrayTargetHold [(targetHoldCount/3-1)*3+2];
        else lineEntryNumber = 0;
        
        lineEntryNumber++;
        
        //-----Each connect process-----
        int *connectLineData = new int [positionReviseCount+50];
        int connectLineDataCount = 0;
        
        for (int counter1 = arrayTimeSelected [(connectNoTemp-1)*10+2]; counter1 < positionReviseCount/7; counter1++){
            if (arrayPositionRevise [counter1*7+3] == arrayTimeSelected [(connectNoTemp-1)*10+8]){
                connectLineData [connectLineDataCount] = arrayPositionRevise [counter1*7], connectLineDataCount++;
                connectLineData [connectLineDataCount] = arrayPositionRevise [counter1*7+1], connectLineDataCount++;
                connectLineData [connectLineDataCount] = arrayPositionRevise [counter1*7+2], connectLineDataCount++;
                connectLineData [connectLineDataCount] = arrayPositionRevise [counter1*7+3], connectLineDataCount++;
                connectLineData [connectLineDataCount] = arrayPositionRevise [counter1*7+4], connectLineDataCount++;
                connectLineData [connectLineDataCount] = arrayPositionRevise [counter1*7+5], connectLineDataCount++;
            }
            else{
                
                break;
            }
        }
        
        //for (int counterA = 0; counterA < connectLineDataCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<connectLineData [counterA*6+counterB];
        //	cout<<" connectLineData "<<counterA<<endl;
        //}
        
        int maxPointDimX = 0;
        int maxPointDimY = 0;
        int minPointDimX = 1000000;
        int minPointDimY = 1000000;
        
        for (int counter1 = 0; counter1 < connectLineDataCount/6; counter1++){
            if (maxPointDimX < connectLineData [counter1*6]) maxPointDimX = connectLineData [counter1*6];
            if (minPointDimX > connectLineData [counter1*6]) minPointDimX = connectLineData [counter1*6];
            if (maxPointDimY < connectLineData [counter1*6+1]) maxPointDimY = connectLineData [counter1*6+1];
            if (minPointDimY > connectLineData [counter1*6+1]) minPointDimY = connectLineData [counter1*6+1];
        }
        
        //-----Determine the dimension of cell-----
        int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
        int verticalLength = (maxPointDimY-minPointDimY)/2*2;
        int dimension = 0;
        
        if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
        if (horizontalLength < verticalLength) dimension = verticalLength+30;
        
        dimension = (dimension/2)*2;
        
        int horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
        int verticalStart = minPointDimY-(dimension-verticalLength)/2;
        
        //cout<<horizontalStart<<" "<<verticalStart<<" "<<dimension<<" hol-ver-dim"<<endl;
        
        if (dimension >= 10){
            connectivityMap = new int *[dimension+1];
            for (int counter1 = 0; counter1 < dimension+1; counter1++) connectivityMap [counter1] = new int [dimension+1];
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++) connectivityMap [counterY][counterX] = 0;
            }
            
            for (int counter1 = 0; counter1 < connectLineDataCount/6; counter1++){
                connectivityMap [connectLineData [counter1*6+1]-verticalStart][connectLineData [counter1*6]-horizontalStart] = 1;
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
            //	cout<<" connectivityMap "<<counterA<<endl;
            //}
            
            //-----Fill inside-----
            int *connectAnalysisX = new int [dimension*4];
            int *connectAnalysisY = new int [dimension*4];
            int *connectAnalysisTempX = new int [dimension*4];
            int *connectAnalysisTempY = new int [dimension*4];
            
            int connectivityNumber = -3;
            int connectAnalysisCount = 0;
            int terminationFlag = 0;
            int connectAnalysisTempCount = 0;
            int xSource = 0;
            int ySource = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMap [counterY][counterX] == 0){
                        connectivityNumber = connectivityNumber+2;
                        connectAnalysisCount = 0;
                        
                        if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMap [counterY][counterX] = connectivityNumber;
                        
                        if (counterY-1 >= 0 && connectivityMap [counterY-1][counterX] == 0){
                            connectivityMap [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && connectivityMap [counterY][counterX+1] == 0){
                            connectivityMap [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && connectivityMap [counterY+1][counterX] == 0){
                            connectivityMap [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && connectivityMap [counterY][counterX-1] == 0){
                            connectivityMap [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && connectivityMap [ySource-1][xSource] == 0){
                                        connectivityMap [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && connectivityMap [ySource][xSource+1] == 0){
                                        connectivityMap [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && connectivityMap [ySource+1][xSource] == 0){
                                        connectivityMap [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMap [ySource][xSource-1] == 0){
                                        connectivityMap [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
            //	cout<<" connectivityMap "<<counterA<<endl;
            //}
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMap [counterY][counterX] == -1) connectivityMap [counterY][counterX] = 0;
                    else connectivityMap [counterY][counterX] = 1;
                }
            }
            
            for (int counter1 = 0; counter1 < lineDataProcessingCount/2; counter1++){
                if (arrayLineDataProcessing [counter1*2]-horizontalStart > 0 && arrayLineDataProcessing [counter1*2]-horizontalStart < dimension && arrayLineDataProcessing [counter1*2+1]-verticalStart >= 0 && arrayLineDataProcessing [counter1*2+1]-verticalStart < dimension) connectivityMap [arrayLineDataProcessing [counter1*2+1]-verticalStart][arrayLineDataProcessing [counter1*2]-horizontalStart] = 0;
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
            //	cout<<" connectivityMap "<<counterA<<endl;
            //}
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMap [counterY][counterX] != 0) connectivityMap [counterY][counterX] = connectivityMap [counterY][counterX]*-1;
                }
            }
            
            connectivityNumber = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMap [counterY][counterX] < 0){
                        connectivityNumber++;
                        connectivityMap [counterY][counterX] = connectivityNumber;
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMap [counterY-1][counterX-1] < 0){
                            connectivityMap [counterY-1][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && connectivityMap [counterY-1][counterX] < 0){
                            connectivityMap [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMap [counterY-1][counterX+1] < 0){
                            connectivityMap [counterY-1][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && connectivityMap [counterY][counterX+1] < 0){
                            connectivityMap [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && counterX+1 < dimension && connectivityMap [counterY+1][counterX+1] < 0){
                            connectivityMap [counterY+1][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && connectivityMap [counterY+1][counterX] < 0){
                            connectivityMap [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMap [counterY+1][counterX-1] < 0){
                            connectivityMap [counterY+1][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && connectivityMap [counterY][counterX-1] < 0){
                            connectivityMap [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && xSource-1 >= 0 && connectivityMap [ySource-1][xSource-1] < 0){
                                        connectivityMap [ySource-1][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && connectivityMap [ySource-1][xSource] < 0){
                                        connectivityMap [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && xSource+1 < dimension && connectivityMap [ySource-1][xSource+1] < 0){
                                        connectivityMap [ySource-1][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && connectivityMap [ySource][xSource+1] < 0){
                                        connectivityMap [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 > dimension && xSource+1 < dimension && connectivityMap [ySource+1][xSource+1] < 0){
                                        connectivityMap [ySource+1][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && connectivityMap [ySource+1][xSource] < 0){
                                        connectivityMap [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && xSource-1 >= 0 && connectivityMap [ySource+1][xSource-1] < 0){
                                        connectivityMap [ySource+1][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMap [ySource][xSource-1] < 0){
                                        connectivityMap [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
            //	cout<<" connectivityMapB2 "<<counterA<<endl;
            //}
            
            //-----Determine number of pixels-----
            int *connectedPix = new int [connectivityNumber+50];
            
            for (int counter1 = 0; counter1 <= connectivityNumber; counter1++) connectedPix [counter1] = 0;
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMap [counterY][counterX] != 0) connectedPix [connectivityMap [counterY][counterX]]++;
                }
            }
            
            //-----Map up-date-----
            int connectTemp = 1;
            
            for (int counter1 = 1; counter1 <= connectivityNumber; counter1++){
                if (connectedPix [counter1] < 10) connectedPix [counter1] = 0;
                else{
                    
                    connectedPix [counter1] = connectTemp;
                    connectTemp++;
                }
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if ((connectTemp = connectivityMap [counterY][counterX]) != 0) connectivityMap [counterY][counterX] = connectedPix [connectTemp];
                }
            }
            
            delete [] connectedPix;
            
            int maxConnectivityNumber = 0;
            int newConnectLineNo = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMap [counterY][counterX] > maxConnectivityNumber) maxConnectivityNumber = connectivityMap [counterY][counterX];
                }
            }
            
            int **outlineMap = new int *[dimension+1];
            int **outlineMap2 = new int *[dimension+1];
            int **outlineMap3 = new int *[dimension+1];
            int **internalConnectMap = new int *[dimension+1];
            
            for (int counter1 = 0; counter1 < dimension+1; counter1++){
                outlineMap [counter1] = new int [dimension+1];
                outlineMap2 [counter1] = new int [dimension+1];
                outlineMap3 [counter1] = new int [dimension+1];
                internalConnectMap [counter1] = new int [dimension+1];
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    outlineMap3 [counterY][counterX] = 0;
                    internalConnectMap [counterY][counterX] = 0;
                }
            }
            
            int *outlineDataSet = new int [1000];
            int outlineDataSetCount = 0;
            int outlineDataSetLimit = 1000;
            int largestConnect = 0;
            int largestConnectNo = 0;
            int xPositionTempStart = 0;
            int yPositionTempStart = 0;
            int lineSize = 0;
            int constructedLineCount = 0;
            int findFlag = 0;
            int terminationFlag2 = 0;
            int insideFind = 0;
            int maxInsideCheck = 0;
            
            for (int counter1 = 1; counter1 <= maxConnectivityNumber; counter1++){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMap [counterY][counterX] == counter1) outlineMap [counterY][counterX] = 1;
                        else outlineMap [counterY][counterX] = 0;
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<outlineMap [counterA][counterB];
                //    cout<<" outlineMap "<<counterA<<endl;
                //}
                
                do{
                    
                    terminationFlag = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (outlineMap [counterY][counterX] != 0){
                                if (counterX+1 < dimension && outlineMap [counterY][counterX+1] == 0) outlineMap [counterY][counterX] = -1;
                                else if (counterY+1 < dimension && outlineMap [counterY+1][counterX] == 0) outlineMap [counterY][counterX] = -1;
                                else if (counterX-1 >= 0 && outlineMap [counterY][counterX-1] == 0) outlineMap [counterY][counterX] = -1;
                                else if (counterY-1 >= 0 && outlineMap [counterY-1][counterX] == 0) outlineMap [counterY][counterX] = -1;
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (outlineMap [counterY][counterX] > 0) outlineMap [counterY][counterX] = 0;
                            if (outlineMap [counterY][counterX] < 0) outlineMap [counterY][counterX] = 1;
                        }
                    }
                    
                    connectivityNumber = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (outlineMap [counterY2][counterX2] == 0){
                                connectivityNumber--;
                                connectAnalysisCount = 0;
                                
                                outlineMap [counterY2][counterX2] = connectivityNumber;
                                
                                if (counterY2-1 >= 0 && outlineMap [counterY2-1][counterX2] == 0){
                                    outlineMap [counterY2-1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                }
                                if (counterX2+1 < dimension && outlineMap [counterY2][counterX2+1] == 0){
                                    outlineMap [counterY2][counterX2+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                if (counterY2+1 < dimension && outlineMap [counterY2+1][counterX2] == 0){
                                    outlineMap [counterY2+1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                }
                                if (counterX2-1 >= 0 && outlineMap [counterY2][counterX2-1] == 0){
                                    outlineMap [counterY2][counterX2-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                            xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                            
                                            if (ySource-1 >= 0 && outlineMap [ySource-1][xSource] == 0){
                                                outlineMap [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && outlineMap [ySource][xSource+1] == 0){
                                                outlineMap [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && outlineMap [ySource+1][xSource] == 0){
                                                outlineMap [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && outlineMap [ySource][xSource-1] == 0){
                                                outlineMap [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                            connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    //-----Determine number of pixels-----
                    connectivityNumber = connectivityNumber*-1;
                    
                    int *connectedPix2 = new int [connectivityNumber+50];
                    
                    for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPix2 [counter2] = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (outlineMap [counterY2][counterX2] < -1) connectedPix2 [outlineMap [counterY2][counterX2]*-1]++;
                        }
                    }
                    
                    largestConnect = 0;
                    largestConnectNo = 0;
                    
                    for (int counter2 = 2; counter2 <= connectivityNumber; counter2++){
                        if (connectedPix2 [counter2] > largestConnect){
                            largestConnect = connectedPix2 [counter2];
                            largestConnectNo = counter2;
                        }
                    }
                    
                    delete [] connectedPix2;
                    
                    if (largestConnectNo == 0 || largestConnect < 20) terminationFlag = 1;
                    else{
                        
                        int **newConnectivityMapTemp = new int *[dimension+4];
                        for (int counter2 = 0; counter2 < dimension+4; counter2++) newConnectivityMapTemp [counter2] = new int [dimension+4];
                        
                        for (int counterY = 0; counterY < dimension+4; counterY++){
                            for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
                        }
                        
                        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                if (outlineMap [counterY2][counterX2] == largestConnectNo*-1){
                                    if (counterY2-1 >= 0 && counterX2-1 >= 0 && outlineMap [counterY2-1][counterX2-1] == 1){
                                        newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                                        outlineMap [counterY2-1][counterX2-1] = 0;
                                    }
                                    if (counterY2-1 >= 0 && outlineMap [counterY2-1][counterX2] == 1){
                                        newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                                        outlineMap [counterY2-1][counterX2] = 0;
                                    }
                                    if (counterY2-1 >= 0 && counterX2+1 < dimension && outlineMap [counterY2-1][counterX2+1] == 1){
                                        newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                                        outlineMap [counterY2-1][counterX2+1] = 0;
                                    }
                                    if (counterX2+1 < dimension && outlineMap [counterY2][counterX2+1] == 1){
                                        newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                                        outlineMap [counterY2][counterX2+1] = 0;
                                    }
                                    if (counterY2+1 < dimension && counterX2+1 < dimension && outlineMap [counterY2+1][counterX2+1] == 1){
                                        newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                                        outlineMap [counterY2+1][counterX2+1] = 0;
                                    }
                                    if (counterY2+1 < dimension && outlineMap [counterY2+1][counterX2] == 1){
                                        newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                                        outlineMap [counterY2+1][counterX2] = 0;
                                    }
                                    if (counterY2+1 < dimension && counterX2-1 >= 0 && outlineMap [counterY2+1][counterX2-1] == 1){
                                        newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                                        outlineMap [counterY2+1][counterX2-1] = 0;
                                    }
                                    if (counterX2-1 >= 0 && outlineMap [counterY2][counterX2-1] == 1){
                                        newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                                        outlineMap [counterY2][counterX2-1] = 0;
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<newConnectivityMapTemp [counterA][counterB];
                        //    cout<<" newConnectivityMapTemp "<<counterA<<endl;
                        //}
                        
                        xPositionTempStart = 0;
                        yPositionTempStart = 0;
                        lineSize = 0;
                        
                        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension; counterX2++) outlineMap2 [counterY2][counterX2] = 0;
                        }
                        
                        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                                    outlineMap2 [counterY2][counterX2] = 1;
                                    xPositionTempStart = counterX2;
                                    yPositionTempStart = counterY2;
                                    lineSize++;
                                }
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < dimension+4; counter2++) delete [] newConnectivityMapTemp [counter2];
                        delete [] newConnectivityMapTemp;
                        
                        constructedLineCount = 0;
                        
                        int *arrayNewLines = new int [lineSize*2+50];
                        
                        outlineMap2 [yPositionTempStart][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                        
                        do{
                            
                            findFlag = 0;
                            terminationFlag2 = 0;
                            
                            if (xPositionTempStart+1 < dimension){
                                if (outlineMap2 [yPositionTempStart][xPositionTempStart+1] == 1){
                                    outlineMap2 [yPositionTempStart][xPositionTempStart+1] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                    xPositionTempStart = xPositionTempStart+1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                                    outlineMap2 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                    xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (yPositionTempStart+1 < dimension && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart+1][xPositionTempStart] == 1){
                                    outlineMap2 [yPositionTempStart+1][xPositionTempStart] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                    yPositionTempStart = yPositionTempStart+1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                                    outlineMap2 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                    xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (xPositionTempStart-1 >= 0 && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart][xPositionTempStart-1] == 1){
                                    outlineMap2 [yPositionTempStart][xPositionTempStart-1] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                    xPositionTempStart = xPositionTempStart-1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                                    outlineMap2 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                    xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (yPositionTempStart-1 >= 0 && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart-1][xPositionTempStart] == 1){
                                    outlineMap2 [yPositionTempStart-1][xPositionTempStart] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                    yPositionTempStart = yPositionTempStart-1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                                    outlineMap2 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                    xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag2 = 1;
                                }
                            }
                            
                        } while (terminationFlag2 == 1);
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<outlineMap2 [counterA][counterB];
                        //    cout<<" outlineMap2 "<<counterA<<endl;
                        //}
                        
                        newConnectLineNo++;
                        
                        for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                            if (outlineDataSetCount+3 > outlineDataSetLimit){
                                int *arrayUpDate = new int [outlineDataSetCount+10];
                                
                                for (int counter3 = 0; counter3 < outlineDataSetCount; counter3++) arrayUpDate [counter3] = outlineDataSet [counter3];
                                
                                delete [] outlineDataSet;
                                outlineDataSet = new int [outlineDataSetLimit+5000];
                                outlineDataSetLimit = outlineDataSetLimit+5000;
                                
                                for (int counter3 = 0; counter3 < outlineDataSetCount; counter3++) outlineDataSet [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            outlineDataSet [outlineDataSetCount] = newConnectLineNo, outlineDataSetCount++; //-----Vector no-----
                            outlineDataSet [outlineDataSetCount] = arrayNewLines [counter2*2], outlineDataSetCount++; //-----X Position-----
                            outlineDataSet [outlineDataSetCount] = arrayNewLines [counter2*2+1], outlineDataSetCount++; //-----Y Position-----
                        }
                        
                        delete [] arrayNewLines;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (outlineMap2 [counterY][counterX] == -1) outlineMap2 [counterY][counterX] = outlineMap2 [counterY][counterX]*-1;
                            }
                        }
                        
                        connectivityNumber = -3;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (outlineMap2 [counterY][counterX] == 0){
                                    connectivityNumber = connectivityNumber+2;
                                    outlineMap2 [counterY][counterX] = connectivityNumber;
                                    
                                    connectAnalysisCount = 0;
                                    
                                    if (counterY-1 >= 0 && outlineMap2 [counterY-1][counterX] == 0){
                                        outlineMap2 [counterY-1][counterX] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                    }
                                    if (counterX+1 < dimension && outlineMap2 [counterY][counterX+1] == 0){
                                        outlineMap2 [counterY][counterX+1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    if (counterY+1 < dimension && outlineMap2 [counterY+1][counterX] == 0){
                                        outlineMap2 [counterY+1][counterX] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                    }
                                    if (counterX-1 >= 0 && outlineMap2 [counterY][counterX-1] == 0){
                                        outlineMap2 [counterY][counterX-1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    
                                    if (connectAnalysisCount != 0){
                                        do{
                                            
                                            terminationFlag = 1;
                                            connectAnalysisTempCount = 0;
                                            
                                            for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                
                                                if (ySource-1 >= 0 && outlineMap2 [ySource-1][xSource] == 0){
                                                    outlineMap2 [ySource-1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (xSource+1 < dimension && outlineMap2 [ySource][xSource+1] == 0){
                                                    outlineMap2 [ySource][xSource+1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 < dimension && outlineMap2 [ySource+1][xSource] == 0){
                                                    outlineMap2 [ySource+1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (xSource-1 >= 0 && outlineMap2 [ySource][xSource-1] == 0){
                                                    outlineMap2 [ySource][xSource-1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                            }
                                            
                                            for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                            }
                                            
                                            connectAnalysisCount = connectAnalysisTempCount;
                                            
                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                    }
                                }
                            }
                        }
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (outlineMap2 [counterY][counterX] == -1) outlineMap2 [counterY][counterX] = 0;
                                else outlineMap2 [counterY][counterX] = newConnectLineNo;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<outlineMap2 [counterA][counterB];
                        //    cout<<" outlineMap2 "<<counterA<<endl;
                        //}
                        
                        //======inside check=====
                        maxInsideCheck = timeSelectedCount/10;
                        int edgeCheck = 0;
                        
                        int *insideCheck = new int [maxInsideCheck*2+5];
                        
                        for (int counter2 = 0; counter2 < maxInsideCheck*2+5; counter2++) insideCheck [counter2] = 0;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                    if (outlineMap2 [counterY][counterX] != 0 && revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0){
                                        int tempValue = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart];
                                        insideCheck [tempValue*2]++;
                                    }
                                    else if (outlineMap2 [counterY][counterX] == 0 && revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0){
                                        int tempValue = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart];
                                        insideCheck [tempValue*2+1]++;
                                    }
                                    
                                    edgeCheck = 0;
                                    
                                    if (outlineMap2 [counterY][counterX] != 0){
                                        if (counterY-1 >= 0 && outlineMap2 [counterY-1][counterX] == 0) edgeCheck++;
                                        if (counterX+1 < dimension && outlineMap2 [counterY][counterX+1] == 0) edgeCheck++;
                                        if (counterY+1 < dimension && outlineMap2 [counterY+1][counterX] == 0) edgeCheck++;
                                        if (counterX-1 >= 0 && outlineMap2 [counterY][counterX-1] == 0) edgeCheck++;
                                        
                                        if (edgeCheck != 0 && revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0){
                                            insideCheck [revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart]*2+1]++;
                                        }
                                    }
                                }
                            }
                        }
                        
                        insideFind = 0;
                        
                        for (int counter2 = 1; counter2 <= maxInsideCheck; counter2++){
                            if (insideCheck [counter2*2] != 0 && insideCheck [counter2*2+1] == 0) insideFind = 1;
                            else if (insideCheck [counter2*2] != 0 && insideCheck [counter2*2+1] != 0) insideCheck [counter2*2] = 0;
                        }
                        
                        if (insideFind == 1){
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                        if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0){
                                            for (int counter2 = 1; counter2 <= maxInsideCheck; counter2++){
                                                if (insideCheck [counter2*2] != 0 && revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] == counter2){
                                                    internalConnectMap [counterY][counterX] = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart];
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        
                        delete [] insideCheck;
                        //============================================
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (outlineMap2 [counterY][counterX] != 0){
                                    outlineMap [counterY][counterX] = 0;
                                    outlineMap3 [counterY][counterX] = outlineMap2 [counterY][counterX];
                                }
                                
                                if (outlineMap [counterY][counterX] != 0) outlineMap [counterY][counterX] = 0;
                            }
                        }
                    }
                    
                } while (terminationFlag == 0);
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++) connectivityMap [counterY][counterX] = outlineMap3 [counterY][counterX];
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
            //    cout<<" connectivityMap "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<internalConnectMap [counterA][counterB];
            //    cout<<" internalConnectMap "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < outlineDataSetCount/3; counterA++){
            //    cout<<counterA<<" "<<outlineDataSet [counterA*3]<<" "<<outlineDataSet [counterA*3+1]<<" "<<outlineDataSet [counterA*3+2]<<" Outline "<<endl;
            // }
            
            for (int counter1 = 0; counter1 < dimension+1; counter1++){
                delete [] outlineMap [counter1];
                delete [] outlineMap2 [counter1];
                delete [] outlineMap3 [counter1];
            }
            
            delete [] outlineMap;
            delete [] outlineMap2;
            delete [] outlineMap3;
            
            delete [] connectAnalysisX;
            delete [] connectAnalysisY;
            delete [] connectAnalysisTempX;
            delete [] connectAnalysisTempY;
            
            //-----Determine number of pixels-----
            connectedPix = new int [newConnectLineNo+50];
            
            for (int counter1 = 0; counter1 <= newConnectLineNo; counter1++) connectedPix [counter1] = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMap [counterY][counterX] != 0) connectedPix [connectivityMap [counterY][counterX]]++;
                }
            }
            
            int largestTargetConnect = 0;
            int targetEntryConnectNo = 0;
            
            for (int counter1 = 1; counter1 < maxConnectivityNumber+1; counter1++){
                if (connectedPix [counter1] > largestTargetConnect){
                    largestTargetConnect = connectedPix [counter1];
                    targetEntryConnectNo = counter1;
                }
            }
            
            if (newConnectLineNo > 0){
                int currentStatus = 0;
                int entryCount = 0;
                int gravityCenter1 [4];
                int maxVectorNumber = 0;
                
                if (gravityCenterRevCount != 0) maxVectorNumber = arrayGravityCenterRev [(gravityCenterRevCount/6-1)*6+4];
                
                int vectorNoForTarget = 0;
                
                results = 1;
                
                int xGravityImageTemp = 0;
                int yGravityImageTemp = 0;
                int gravityX1 = 0;
                int gravityY1 = 0;
                int totalGRCount = 0;
                int averageIntensity = 0;
                int timeOneTempCount = 0;
                int lastConnectPosition = 0;
                int connectNoTemp2 = 0;
                int lineageGRCurrentCountTemp = 0;
                
                for (int counter1 = 1; counter1 < newConnectLineNo+1; counter1++){
                    if (connectedPix [counter1] != 0){
                        gravityCenter1 [0] = 0;
                        gravityCenter1 [1] = 0;
                        gravityCenter1 [2] = 0;
                        gravityCenter1 [3] = 0;
                        
                        //cout<<horizontalStart<<" "<<verticalStart<<" "<<dimension<<" hol-ver-dim"<<endl;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (connectivityMap [counterY][counterX] == counter1){
                                    gravityCenter1 [0] = gravityCenter1 [0]+counterX;
                                    gravityCenter1 [1] = gravityCenter1 [1]+counterY;
                                    gravityCenter1 [2]++;
                                    
                                    xGravityImageTemp = counterX+horizontalStart;
                                    yGravityImageTemp = counterY+verticalStart;
                                    
                                    if (xGravityImageTemp > imageDimension) xGravityImageTemp = imageDimension-1;
                                    if (xGravityImageTemp < 0) xGravityImageTemp = 0;
                                    if (yGravityImageTemp > imageDimension) yGravityImageTemp = imageDimension-1;
                                    if (yGravityImageTemp < 0) yGravityImageTemp = 0;
                                    
                                    gravityCenter1 [3] = gravityCenter1 [3]+sourceImage [yGravityImageTemp][xGravityImageTemp];
                                }
                            }
                        }
                        
                        //cout<<gravityCenter1 [0]<<" "<<gravityCenter1 [1]<<" "<<gravityCenter1 [2]<<" "<<gravityCenter1 [3]<<" GRData"<<endl;
                        
                        averageIntensity = (int)(gravityCenter1 [3]/(double)gravityCenter1 [2]);
                        
                        //cout<<gravityX1<<" "<<gravityY1<<" "<<averageIntensity<<" "<<entryCount<<" GRCenter"<<endl;
                        
                        //-----First Connect Get and Set required data: remove data related to the original connect-----
                        if (entryCount == 0){
                            entryCount = 1;
                            
                            int *arrayTimeOneTemp = new int [timeSelectedCount+50];
                            timeOneTempCount = 0;
                            
                            for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                                if (counter2+1 == connectNoTemp){
                                    if (arrayTimeSelected [counter2*10] == 0 || arrayTimeSelected [counter2*10] == 2) arrayTimeOneTemp [timeOneTempCount] = 3, timeOneTempCount++;
                                    else if (arrayTimeSelected [counter2*10] == 1 || arrayTimeSelected [counter2*10] == 7) arrayTimeOneTemp [timeOneTempCount] = 4, timeOneTempCount++;
                                    
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+1], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+2], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = lineEntryNumber, timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+4], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+5], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+6], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+7], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+8], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+9], timeOneTempCount++;
                                }
                                else{
                                    
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+1], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+2], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+3], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+4], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+5], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+6], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+7], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+8], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+9], timeOneTempCount++;
                                }
                            }
                            
                            timeSelectedCount = 0;
                            for (int counter2 = 0; counter2 < timeOneTempCount; counter2++) arrayTimeSelected [timeSelectedCount] = arrayTimeOneTemp [counter2], timeSelectedCount++;
                            
                            delete [] arrayTimeOneTemp;
                            
                            int *arrayReviseTemp = new int [positionReviseCount+50];
                            int reviseTempCount = 0;
                            
                            for (int counter2 = 0; counter2 < positionReviseCount/7; counter2++){
                                if (arrayPositionRevise [counter2*7+3] == connectNoTemp){
                                    arrayReviseTemp [reviseTempCount] = arrayPositionRevise [counter2*7], reviseTempCount++;
                                    arrayReviseTemp [reviseTempCount] = arrayPositionRevise [counter2*7+1], reviseTempCount++;
                                    arrayReviseTemp [reviseTempCount] = arrayPositionRevise [counter2*7+2], reviseTempCount++;
                                    arrayReviseTemp [reviseTempCount] = arrayPositionRevise [counter2*7+3], reviseTempCount++;
                                    arrayReviseTemp [reviseTempCount] = arrayPositionRevise [counter2*7+4], reviseTempCount++;
                                    
                                    if (currentStatus == 0) currentStatus = arrayPositionRevise [counter2*7+5];
                                    
                                    if (currentStatus == 0) arrayReviseTemp [reviseTempCount] = 2, reviseTempCount++;
                                    else if (currentStatus == 1) arrayReviseTemp [reviseTempCount] = 3, reviseTempCount++;
                                    else arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+5], timeOneTempCount++;
                                    
                                    arrayReviseTemp [reviseTempCount] = arrayPositionRevise [counter2*7+6], reviseTempCount++;
                                }
                                else{
                                    
                                    arrayReviseTemp [reviseTempCount] = arrayPositionRevise [counter2*7], reviseTempCount++;
                                    arrayReviseTemp [reviseTempCount] = arrayPositionRevise [counter2*7+1], reviseTempCount++;
                                    arrayReviseTemp [reviseTempCount] = arrayPositionRevise [counter2*7+2], reviseTempCount++;
                                    arrayReviseTemp [reviseTempCount] = arrayPositionRevise [counter2*7+3], reviseTempCount++;
                                    arrayReviseTemp [reviseTempCount] = arrayPositionRevise [counter2*7+4], reviseTempCount++;
                                    arrayReviseTemp [reviseTempCount] = arrayPositionRevise [counter2*7+5], reviseTempCount++;
                                    arrayReviseTemp [reviseTempCount] = arrayPositionRevise [counter2*7+6], reviseTempCount++;
                                }
                            }
                            
                            positionReviseCount = 0;
                            for (int counter2 = 0; counter2 < reviseTempCount; counter2++) arrayPositionRevise [positionReviseCount] = arrayReviseTemp [counter2], positionReviseCount++;
                            
                            delete [] arrayReviseTemp;
                            
                            for (int counter2 = 0; counter2 < positionReviseCount/7; counter2++){
                                if (arrayPositionRevise [counter2*7+6] == cellLineageTempInt && arrayPositionRevise [counter2*7+4] == cellNumberTempInt){
                                    arrayPositionRevise [counter2*7+6] = 0;
                                    arrayPositionRevise [counter2*7+4] = 0;
                                }
                            }
                            
                            for (int counterY = 0; counterY < imageDimension; counterY++){
                                for (int counterX = 0; counterX < imageDimension; counterX++){
                                    if (revisedWorkingMap [counterY][counterX] == connectNoTemp) revisedWorkingMap [counterY][counterX] = 0;
                                }
                            }
                            
                            int *arrayFluOutlineTemp = new int [expandFluorescentOutlineCount+50];
                            int fluOutlineTempCount = 0;
                            
                            for (int counter2 = 0; counter2 < expandFluorescentOutlineCount/4; counter2++){
                                if (expandFluorescentOutline [counter2*4+2] != connectNoTemp){
                                    arrayFluOutlineTemp [fluOutlineTempCount] = expandFluorescentOutline [counter2*4], fluOutlineTempCount++;
                                    arrayFluOutlineTemp [fluOutlineTempCount] = expandFluorescentOutline [counter2*4+1], fluOutlineTempCount++;
                                    arrayFluOutlineTemp [fluOutlineTempCount] = expandFluorescentOutline [counter2*4+2], fluOutlineTempCount++;
                                    arrayFluOutlineTemp [fluOutlineTempCount] = expandFluorescentOutline [counter2*4+3], fluOutlineTempCount++;
                                }
                            }
                            
                            expandFluorescentOutlineCount = 0;
                            for (int counter2 = 0; counter2 < fluOutlineTempCount; counter2++) expandFluorescentOutline [expandFluorescentOutlineCount] = arrayFluOutlineTemp [counter2], expandFluorescentOutlineCount++;
                            
                            delete [] arrayFluOutlineTemp;
                            
                            int *arrayFluAreaTemp = new int [expandFluorescentDataCount+50];
                            int fluAreaTempCount = 0;
                            
                            for (int counter2 = 0; counter2 < expandFluorescentDataCount/4; counter2++){
                                if (expandFluorescentData [counter2*4] != connectNoTemp){
                                    arrayFluAreaTemp [fluAreaTempCount] = expandFluorescentData [counter2*4], fluAreaTempCount++;
                                    arrayFluAreaTemp [fluAreaTempCount] = expandFluorescentData [counter2*4+1], fluAreaTempCount++;
                                    arrayFluAreaTemp [fluAreaTempCount] = expandFluorescentData [counter2*4+2], fluAreaTempCount++;
                                    arrayFluAreaTemp [fluAreaTempCount] = expandFluorescentData [counter2*4+3], fluAreaTempCount++;
                                }
                            }
                            
                            expandFluorescentDataCount = 0;
                            for (int counter2 = 0; counter2 < fluAreaTempCount; counter2++) expandFluorescentData [expandFluorescentDataCount] = arrayFluAreaTemp [counter2], expandFluorescentDataCount++;
                            
                            delete [] arrayFluAreaTemp;
                        }
                        
                        //-----Add new Process Connect Data-----
                        maxVectorNumber++;
                        
                        if (positionReviseCount+outlineDataSetCount*3 > positionReviseLimit){
                            positionReviseAddition = outlineDataSetCount*3;
                            
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate positionRevSelectedUpDate];
                        }
                        
                        lastConnectPosition = positionReviseCount/7;
                        
                        for (int counter2 = 0; counter2 < outlineDataSetCount/3; counter2++){
                            if (outlineDataSet [counter2*3] == counter1){
                                arrayPositionRevise [positionReviseCount] = outlineDataSet [counter2*3+1]+horizontalStart, positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = outlineDataSet [counter2*3+2]+verticalStart, positionReviseCount++;
                                
                                if (outlineDataSet [counter2*3+2]+verticalStart >= 0 && outlineDataSet [counter2*3+2]+verticalStart < imageDimension && outlineDataSet [counter2*3+1]+horizontalStart >= 0 && outlineDataSet [counter2*3+1]+horizontalStart < imageDimension){
                                    arrayPositionRevise [positionReviseCount] = sourceImage [outlineDataSet [counter2*3+2]+verticalStart][outlineDataSet [counter2*3+1]+horizontalStart], positionReviseCount++;
                                }
                                else arrayPositionRevise [positionReviseCount] = 100, positionReviseCount++;
                                
                                arrayPositionRevise [positionReviseCount] = maxVectorNumber, positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++;
                            }
                        }
                        
                        gravityX1 = 0;
                        gravityY1 = 0;
                        totalGRCount = 0;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] == counter1 && internalConnectMap [counterY][counterX] == 0){
                                    revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] = maxVectorNumber;
                                    
                                    gravityX1 = gravityX1+counterX+horizontalStart;
                                    gravityY1 = gravityY1+counterY+verticalStart;
                                    totalGRCount++;
                                }
                            }
                        }
                        
                        gravityX1 = (int)(gravityX1/(double)totalGRCount);
                        gravityY1 = (int)(gravityY1/(double)totalGRCount);
                        
                        //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
                        //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
                        //	cout<<" arrayPositionRevise "<<counterA<<endl;
                        //}
                        
                        if (counter1 == targetEntryConnectNo){ //-----Process Main Connect-----
                            for (int counter2 = 0; counter2 < positionReviseCount/7; counter2++){
                                if (arrayPositionRevise [counter2*7+3] == maxVectorNumber){
                                    arrayPositionRevise [counter2*7+6] = cellLineageTempInt*-1;
                                    arrayPositionRevise [counter2*7+5] = 1;
                                    arrayPositionRevise [counter2*7+4] = cellNumberTempInt;
                                }
                            }
                            
                            connectNoTemp2 = -1;
                            
                            for (int counter2 = 0; counter2 < lineageGRCurrentCount/4; counter2++){
                                if (arrayLineageGRCurrent [counter2*4] == imageNumberTrackForDisplay){
                                    connectNoTemp2 = counter2*4;
                                    break;
                                }
                            }
                            
                            if (connectNoTemp2 == -1 && lineageGRCurrentCount+4 > lineageGRCurrentLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate lineageGRCurrentUpDate];
                            }
                            if (connectNoTemp2 == -1) lineageGRCurrentCountTemp = lineageGRCurrentCount;
                            else lineageGRCurrentCountTemp = connectNoTemp2;
                            
                            arrayLineageGRCurrent [lineageGRCurrentCountTemp] = imageNumberTrackForDisplay, lineageGRCurrentCountTemp++;
                            arrayLineageGRCurrent [lineageGRCurrentCountTemp] = gravityX1, lineageGRCurrentCountTemp++;
                            arrayLineageGRCurrent [lineageGRCurrentCountTemp] = gravityY1, lineageGRCurrentCountTemp++;
                            arrayLineageGRCurrent [lineageGRCurrentCountTemp] = cellNumberTempInt, lineageGRCurrentCountTemp++;
                            
                            if (connectNoTemp2 == -1) lineageGRCurrentCount = lineageGRCurrentCountTemp;
                            
                            vectorNoForTarget = maxVectorNumber;
                            
                            gravityCenterXHold1 = gravityX1;
                            gravityCenterYHold1 = gravityY1;
                            gravityAverageHold1 = averageIntensity;
                            gravityCellNo1 = cellNumberTempInt;
                        }
                        
                        if (gravityCenterRevCount+12 > gravityCenterRevLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate gravityCenterRevUpDate];
                        }
                        
                        arrayGravityCenterRev [gravityCenterRevCount] = gravityX1, gravityCenterRevCount++;
                        arrayGravityCenterRev [gravityCenterRevCount] = gravityY1, gravityCenterRevCount++;
                        arrayGravityCenterRev [gravityCenterRevCount] = gravityCenter1 [2], gravityCenterRevCount++;
                        arrayGravityCenterRev [gravityCenterRevCount] = averageIntensity, gravityCenterRevCount++;
                        arrayGravityCenterRev [gravityCenterRevCount] = maxVectorNumber, gravityCenterRevCount++;
                        arrayGravityCenterRev [gravityCenterRevCount] = 0, gravityCenterRevCount++;
                        
                        //for (int counterA = 0; counterA < timeOneGravityCenterRevCount/6; counterA++){
                        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayTimeOneGravityCenterRev [counterA*6+counterB];
                        //	cout<<" arrayTimeOneGravityCenterRev "<<counterA<<endl;
                        //}
                        
                        if (associateDataCount+12 > associateDataLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate associateDataUpDate];
                        }
                        
                        arrayAssociateData [associateDataCount] = maxVectorNumber, associateDataCount++;
                        arrayAssociateData [associateDataCount] = 0, associateDataCount++;
                        arrayAssociateData [associateDataCount] = 0, associateDataCount++;
                        arrayAssociateData [associateDataCount] = 0, associateDataCount++;
                        arrayAssociateData [associateDataCount] = 0, associateDataCount++;
                        arrayAssociateData [associateDataCount] = 0, associateDataCount++;
                        
                        if (timeSelectedCount+10 > timeSelectedLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate timeSelectedUpDate];
                        }
                        
                        if (counter1 == targetEntryConnectNo) arrayTimeSelected [timeSelectedCount] = 7, timeSelectedCount++;
                        else arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                        
                        arrayTimeSelected [timeSelectedCount] = lineEntryNumber, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = lastConnectPosition, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = maxVectorNumber, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = cellLineageTempInt, timeSelectedCount++;
                        
                        if (counter1 == targetEntryConnectNo){
                            if (connectLineageRelCount+6 > connectLineageRelLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate connectLineageRelUpDate];
                            }
                            
                            for (int counter2 = 0; counter2 < connectLineageRelCount/6; counter2++){
                                if (arrayConnectLineageRel [counter2*6] == cellLineageTempInt && arrayConnectLineageRel [counter2*6+3] == cellNumberTempInt){
                                    arrayConnectLineageRel [counter2*6+1] = maxVectorNumber;
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                        //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                        //	cout<<" arrayTimeSelected "<<counterA+1<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
                        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
                        //	cout<<" arrayConnectLineageRel "<<counterA+1<<" "<<counter1<<endl;
                        //}
                    }
                }
                
                for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                    if (arrayPositionRevise [counter1*7+6] < 0) arrayPositionRevise [counter1*7+6] = arrayPositionRevise [counter1*7+6]*-1;
                }
                
                referenceLineCount = 0;
                
                for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                    if (arrayPositionRevise [counter1*7+4] == cellNumberTempInt && arrayPositionRevise [counter1*7+6] == cellLineageTempInt){
                        if (referenceLineCount+4 > referenceLineLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate referenceLineCountUpDate];
                        }
                        
                        arrayReferenceLine [referenceLineCount] = arrayPositionRevise [counter1*7], referenceLineCount++;
                        arrayReferenceLine [referenceLineCount] = arrayPositionRevise [counter1*7+1], referenceLineCount++;
                    }
                }
                
                if (ifStartHold != 0 && ifStartHold-1 == imageNumberTrackForDisplay && connectNoTemp != 0){
                    ifConnectNoUpDate = connectNoTemp;
                    ifConnectNoCurrent = vectorNoForTarget;
                    
                    int expandFluorescentOutlineTempCount = 0;
                    
                    long sizeForCopy = 0;
                    long size1 = 0;
                    long size2 = 0;
                    int checkFlag = 0;
                    int readingError = 0;
                    
                    struct stat sizeOfFile;
                    
                    string extension;
                    string expandDataPath;
                    
                    ifstream fin;
                    
                    for (int counter1 = ifStartHold; counter1 <= imageEndHold; counter1++){
                        extension = to_string(counter1);
                        
                        if (extension.length() == 1) extension = "000"+extension;
                        else if (extension.length() == 2) extension = "00"+extension;
                        else if (extension.length() == 3) extension = "0"+extension;
                        
                        expandDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ExtendLineDataTemp";
                        
                        size1 = 0;
                        size2 = 0;
                        checkFlag = 0;
                        readingError = 0;
                        
                        for (int counter2 = 0; counter2 < 6; counter2++){
                            sizeForCopy = 0;
                            
                            if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            if (sizeForCopy != 0){
                                if (counter2 == 0) size1 = sizeForCopy;
                                else if (counter2 == 1) size2 = sizeForCopy;
                                else if (counter2 == 2){
                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                        checkFlag = 1;
                                        break;
                                    }
                                    else{
                                        
                                        size1 = 0;
                                        size2 = 0;
                                        usleep (50000);
                                    }
                                }
                                else if (counter2 == 3) size1 = sizeForCopy;
                                else if (counter2 == 4) size2 = sizeForCopy;
                                else if (counter2 == 5){
                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                        checkFlag = 1;
                                    }
                                }
                            }
                        }
                        
                        if (checkFlag == 1){
                            int *expandFluorescentOutlineTemp = new int [sizeForCopy+50];
                            expandFluorescentOutlineTempCount = 0;
                            
                            fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                int finData [8];
                                
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                        usleep(50000);
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                            readingError = 1;
                                        }
                                    }
                                }
                                
                                fin.close();
                                
                                if (readingError == 0){
                                    unsigned long readPosition = 0;
                                    int stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTemp [readPosition], readPosition++;
                                            finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                                            finData [2] = uploadTemp [readPosition], readPosition++;
                                            finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                                            finData [4] = uploadTemp [readPosition], readPosition++;
                                            finData [5] = uploadTemp [readPosition], readPosition++;
                                            finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                            finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                            
                                            finData [1] = finData [0]*256+finData [1];
                                            finData [3] = finData [2]*256+finData [3];
                                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                            
                                            if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                            else{
                                                
                                                expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = finData [1], expandFluorescentOutlineTempCount++;
                                                expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = finData [3], expandFluorescentOutlineTempCount++;
                                                expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = finData [6], expandFluorescentOutlineTempCount++;
                                                expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = finData [7], expandFluorescentOutlineTempCount++;
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                }
                                
                                delete [] uploadTemp;
                                
                                int findMatch = 0;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount/4; counter2++){
                                    if (expandFluorescentOutlineTemp [counter2*4+2] == ifConnectNoUpDate){
                                        expandFluorescentOutlineTemp [counter2*4+2] = ifConnectNoCurrent;
                                        findMatch = 1;
                                    }
                                }
                                
                                if (findMatch == 1){
                                    int readBit [3];
                                    int dataTemp = 0;
                                    unsigned long indexCount = 0;
                                    char *writingArray = new char [expandFluorescentOutlineTempCount*2+200];
                                    
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount/4; counter2++){
                                        dataTemp = expandFluorescentOutlineTemp [counter2*4];
                                        readBit [0] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [1] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        
                                        dataTemp = expandFluorescentOutlineTemp [counter2*4+1];
                                        readBit [0] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [1] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        
                                        dataTemp = expandFluorescentOutlineTemp [counter2*4+2];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        writingArray [indexCount] = (char)expandFluorescentOutlineTemp [counter2*4+3], indexCount++;
                                    }
                                    
                                    for (int counter2 = 0; counter2 < 8; counter2++) writingArray [indexCount] = 0, indexCount++;
                                    
                                    ofstream outfile (expandDataPath.c_str(), ofstream::binary);
                                    outfile.write ((char*)writingArray, indexCount);
                                    outfile.close();
                                    
                                    delete [] writingArray;
                                }
                            }
                            
                            delete [] expandFluorescentOutlineTemp;
                        }
                        
                        expandDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaDataTemp";
                        
                        sizeForCopy = 0;
                        
                        if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            int *expandFluorescentOutlineTemp = new int [sizeForCopy+50];
                            expandFluorescentOutlineTempCount = 0;
                            
                            fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                unsigned long readPosition = 0;
                                int stepCount = 0;
                                int finData [8];
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++;
                                        finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                        finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                                        
                                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                        
                                        if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                        else{
                                            
                                            expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = finData [2], expandFluorescentOutlineTempCount++;
                                            expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = finData [3], expandFluorescentOutlineTempCount++;
                                            expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = finData [4], expandFluorescentOutlineTempCount++;
                                            expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = finData [7], expandFluorescentOutlineTempCount++;
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                                
                                delete [] uploadTemp;
                                
                                int findMatch = 0;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount/4; counter2++){
                                    if (expandFluorescentOutlineTemp [counter2*4] == ifConnectNoUpDate){
                                        expandFluorescentOutlineTemp [counter2*4] = ifConnectNoCurrent;
                                        findMatch = 1;
                                    }
                                }
                                
                                if (findMatch == 1){
                                    int readBit [3];
                                    int dataTemp = 0;
                                    unsigned long indexCount = 0;
                                    char *writingArray = new char [expandFluorescentOutlineTempCount*2+20];
                                    
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount/4; counter2++){
                                        dataTemp = expandFluorescentOutlineTemp [counter2*4];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        writingArray [indexCount] = (char)expandFluorescentOutlineTemp [counter2*4+1], indexCount++;
                                        writingArray [indexCount] = (char)expandFluorescentOutlineTemp [counter2*4+2], indexCount++;
                                        
                                        dataTemp = expandFluorescentOutlineTemp [counter2*4+3];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    }
                                    
                                    for (int counter2 = 0; counter2 < 8; counter2++) writingArray [indexCount] = 0, indexCount++;
                                    
                                    ofstream outfile2 (expandDataPath.c_str(), ofstream::binary);
                                    outfile2.write ((char*)writingArray, indexCount);
                                    outfile2.close();
                                    
                                    delete [] writingArray;
                                }
                            }
                            
                            delete [] expandFluorescentOutlineTemp;
                        }
                    }
                }
                
                if (fluorescentDetectionDisplay == 1){
                    int *arrayExpandTemp = new int [expandFluorescentOutlineCount+50];
                    int expandTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < expandFluorescentOutlineCount/4; counter1++){
                        if (expandFluorescentOutline [counter1*4+2] != connectNoTemp){
                            arrayExpandTemp [expandTempCount] = expandFluorescentOutline [counter1*4], expandTempCount++;
                            arrayExpandTemp [expandTempCount] = expandFluorescentOutline [counter1*4+1], expandTempCount++;
                            arrayExpandTemp [expandTempCount] = expandFluorescentOutline [counter1*4+2], expandTempCount++;
                            arrayExpandTemp [expandTempCount] = expandFluorescentOutline [counter1*4+3], expandTempCount++;
                        }
                    }
                    
                    expandFluorescentOutlineCount = 0;
                    for (int counter1 = 0; counter1 < expandTempCount; counter1++) expandFluorescentOutline [expandFluorescentOutlineCount] = arrayExpandTemp [counter1], expandFluorescentOutlineCount++;
                    
                    delete [] arrayExpandTemp;
                    
                    int *arrayExpandDataTemp = new int [expandFluorescentDataCount+50];
                    int expandDataTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < expandFluorescentDataCount/4; counter1++){
                        if (expandFluorescentData [counter1*4] != connectNoTemp){
                            arrayExpandDataTemp [expandDataTempCount] = expandFluorescentData [counter1*4], expandDataTempCount++;
                            arrayExpandDataTemp [expandDataTempCount] = expandFluorescentData [counter1*4+1], expandDataTempCount++;
                            arrayExpandDataTemp [expandDataTempCount] = expandFluorescentData [counter1*4+2], expandDataTempCount++;
                            arrayExpandDataTemp [expandDataTempCount] = expandFluorescentData [counter1*4+3], expandDataTempCount++;
                        }
                    }
                    
                    expandFluorescentDataCount = 0;
                    for (int counter1 = 0; counter1 < expandDataTempCount; counter1++) expandFluorescentData [expandFluorescentDataCount] = arrayExpandDataTemp [counter1], expandFluorescentDataCount++;
                    
                    delete [] arrayExpandDataTemp;
                    
                    int returnData = 0;
                    
                    if (autoExpand == 1){
                        expandLine = [[ExpandLine alloc] init];
                        returnData = [expandLine lineExtendTrackType1:vectorNoForTarget];
                    }
                    
                    if ((fluorescentDetectionDisplay == 1 && autoExpand == 0) || (fluorescentDetectionDisplay == 1 && autoExpand == 1 && returnData == 1)){
                        for (int counter1 = arrayTimeSelected [(vectorNoForTarget-1)*10+2]; counter1 < positionReviseCount/7; counter1++){
                            if (arrayPositionRevise [counter1*7+3] == vectorNoForTarget){
                                if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate expandFluorescentOutlineUpDate];
                                }
                                
                                expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = vectorNoForTarget, expandFluorescentOutlineCount++;
                                expandFluorescentOutline [expandFluorescentOutlineCount] = 1, expandFluorescentOutlineCount++;
                            }
                            else{
                                
                                break;
                            }
                        }
                        
                        if (fluorescentEntryCount >= 2){
                            for (int counter1 = arrayTimeSelected [(vectorNoForTarget-1)*10+2]; counter1 < positionReviseCount/7; counter1++){
                                if (arrayPositionRevise [counter1*7+3] == vectorNoForTarget){
                                    if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate expandFluorescentOutlineUpDate];
                                    }
                                    
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = vectorNoForTarget, expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = 2, expandFluorescentOutlineCount++;
                                }
                                else{
                                    
                                    break;
                                }
                            }
                        }
                        
                        if (fluorescentEntryCount >= 3){
                            for (int counter1 = arrayTimeSelected [(vectorNoForTarget-1)*10+2]; counter1 < positionReviseCount/7; counter1++){
                                if (arrayPositionRevise [counter1*7+3] == vectorNoForTarget){
                                    if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate expandFluorescentOutlineUpDate];
                                    }
                                    
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = vectorNoForTarget, expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = 3, expandFluorescentOutlineCount++;
                                }
                                else{
                                    
                                    break;
                                }
                            }
                        }
                        
                        if (fluorescentEntryCount >= 4){
                            for (int counter1 = arrayTimeSelected [(vectorNoForTarget-1)*10+2]; counter1 < positionReviseCount/7; counter1++){
                                if (arrayPositionRevise [counter1*7+3] == vectorNoForTarget){
                                    if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate expandFluorescentOutlineUpDate];
                                    }
                                    
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = vectorNoForTarget, expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = 4, expandFluorescentOutlineCount++;
                                }
                                else{
                                    
                                    break;
                                }
                            }
                        }
                        
                        if (fluorescentEntryCount >= 5){
                            for (int counter1 = arrayTimeSelected [(vectorNoForTarget-1)*10+2]; counter1 < positionReviseCount/7; counter1++){
                                if (arrayPositionRevise [counter1*7+3] == vectorNoForTarget){
                                    if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate expandFluorescentOutlineUpDate];
                                    }
                                    
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = vectorNoForTarget, expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = 5, expandFluorescentOutlineCount++;
                                }
                                else{
                                    
                                    break;
                                }
                            }
                        }
                        
                        if (fluorescentEntryCount >= 6){
                            for (int counter1 = arrayTimeSelected [(vectorNoForTarget-1)*10+2]; counter1 < positionReviseCount/7; counter1++){
                                if (arrayPositionRevise [counter1*7+3] == vectorNoForTarget){
                                    if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate expandFluorescentOutlineUpDate];
                                    }
                                    
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = vectorNoForTarget, expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = 6, expandFluorescentOutlineCount++;
                                }
                                else{
                                    
                                    break;
                                }
                            }
                        }
                        
                        int pixelValueTemp = 0;
                        int pixelAreaTemp = 0;
                        int pixelValueTemp2 = 0;
                        int pixelAreaTemp2 = 0;
                        int pixelValueTemp3 = 0;
                        int pixelAreaTemp3 = 0;
                        int pixelValueTemp4 = 0;
                        int pixelAreaTemp4 = 0;
                        int pixelValueTemp5 = 0;
                        int pixelAreaTemp5 = 0;
                        int pixelValueTemp6 = 0;
                        int pixelAreaTemp6 = 0;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                    if (revisedWorkingMap [counterY][counterX] == vectorNoForTarget){
                                        if (fluorescentEntryCount >= 1){
                                            if (fluorescentCutOff1 >= fluorescentMap1 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap1 [counterX+horizontalStart][counterX+horizontalStart];
                                            pixelAreaTemp++;
                                        }
                                        if (fluorescentEntryCount >= 2){
                                            if (fluorescentCutOff2 >= fluorescentMap2 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp2 = pixelValueTemp2+fluorescentMap2 [counterX+horizontalStart][counterX+horizontalStart];
                                            pixelAreaTemp2++;
                                        }
                                        if (fluorescentEntryCount >= 3){
                                            if (fluorescentCutOff3 >= fluorescentMap3 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp3 = pixelValueTemp3+fluorescentMap3 [counterX+horizontalStart][counterX+horizontalStart];
                                            pixelAreaTemp3++;
                                        }
                                        if (fluorescentEntryCount >= 4){
                                            if (fluorescentCutOff4 >= fluorescentMap4 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp4 = pixelValueTemp4+fluorescentMap4 [counterX+horizontalStart][counterX+horizontalStart];
                                            pixelAreaTemp4++;
                                        }
                                        if (fluorescentEntryCount >= 5){
                                            if (fluorescentCutOff5 >= fluorescentMap5 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp5 = pixelValueTemp5+fluorescentMap5 [counterX+horizontalStart][counterX+horizontalStart];
                                            pixelAreaTemp5++;
                                        }
                                        if (fluorescentEntryCount >= 6){
                                            if (fluorescentCutOff6 >= fluorescentMap6 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp6 = pixelValueTemp6+fluorescentMap6 [counterX+horizontalStart][counterX+horizontalStart];
                                            pixelAreaTemp6++;
                                        }
                                    }
                                }
                            }
                        }
                        
                        double averageArea = pixelValueTemp/(double)pixelAreaTemp;
                        
                        if (expandFluorescentDataCount+20 > expandFluorescentDataLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate expandFluorescentDataUpDate];
                        }
                        
                        expandFluorescentData [expandFluorescentDataCount] = vectorNoForTarget, expandFluorescentDataCount++;
                        expandFluorescentData [expandFluorescentDataCount] = 1, expandFluorescentDataCount++;
                        expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                        expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp, expandFluorescentDataCount++;
                        
                        if (fluorescentEntryCount >= 2){
                            averageArea = pixelValueTemp2/(double)pixelAreaTemp2;
                            
                            expandFluorescentData [expandFluorescentDataCount] = vectorNoForTarget, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = 2, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp2, expandFluorescentDataCount++;
                        }
                        
                        if (fluorescentEntryCount >= 3){
                            averageArea = pixelValueTemp3/(double)pixelAreaTemp3;
                            
                            expandFluorescentData [expandFluorescentDataCount] = vectorNoForTarget, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = 3, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp3, expandFluorescentDataCount++;
                        }
                        
                        if (fluorescentEntryCount >= 4){
                            averageArea = pixelValueTemp4/(double)pixelAreaTemp4;
                            
                            expandFluorescentData [expandFluorescentDataCount] = vectorNoForTarget, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = 4, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp4, expandFluorescentDataCount++;
                        }
                        
                        if (fluorescentEntryCount >= 5){
                            averageArea = pixelValueTemp5/(double)pixelAreaTemp5;
                            
                            expandFluorescentData [expandFluorescentDataCount] = vectorNoForTarget, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = 5, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp5, expandFluorescentDataCount++;
                        }
                        
                        if (fluorescentEntryCount >= 6){
                            averageArea = pixelValueTemp6/(double)pixelAreaTemp6;
                            
                            expandFluorescentData [expandFluorescentDataCount] = vectorNoForTarget, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = 6, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp6, expandFluorescentDataCount++;
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < expandFluorescentOutlineCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentOutline [counterA*4+counterB];
            //    cout<<" expandFluorescentOutline "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < dimension+1; counter1++){
                delete [] connectivityMap [counter1];
                delete [] internalConnectMap [counter1];
            }
            
            delete [] connectivityMap;
            delete [] internalConnectMap;
            
            delete [] connectedPix;
            delete [] outlineDataSet;
        }
        
        delete [] connectLineData;
    }
    
    delete [] connectNumber;
    
    //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
    //	cout<<" arrayPositionRevise "<<counterA<<endl;
    //}
    
    //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
    //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
    //	cout<<" arrayTimeSelected "<<counterA+1<<endl;
    //}
    
    //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
    //	cout<<" arrayConnectLineageRel "<<counterA+1<<" "<<counter1<<endl;
    //}
    
    return results;
}

@end
