//
// AreaCircleCutTrack.h
// Cell_Tracking
//
// Created by Masahiko Sato on 29/09/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef AREACIRCLECUTTRACK_H
#define AREACIRCLECUTTRACK_H
#import "Controller.h"
#endif

@interface AreaCircleCutTrack : NSObject {
    int connectNoTemp; //Connect no
    int originalNoTemp; //Original connect no
    
    id expandLine;
    id merge;
    id fileUpdate;
}

-(int)circleCut:(int)processType;
-(int)areaProcess:(int)type :(int)dimension :(int)valueTemp :(int)horizontalStart :(int)verticalStart :(int)processType :(int)startPointFind;

@end
