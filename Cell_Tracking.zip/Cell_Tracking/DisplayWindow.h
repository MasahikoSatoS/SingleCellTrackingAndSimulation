//
// DisplayWindow.h
// Cell_Tracking
//
// Created by Masahiko Sato on 11/08/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef DISPLAYWINDOW_H
#define DISPLAYWINDOW_H
#import "Controller.h" 
#endif

@interface DisplayWindow : NSView {
    int mouseDragFlag; //Window control
    int previousValue; //Previous value
    int previousImageNumber; //Previous image number
    double xPositionAdjustDisplay; //X Position Magnification Adjust
    double yPositionAdjustDisplay; //Y Position Magnification Adjust
    double xPointDownDisplay; //X Position Mouse Down
    double yPointDownDisplay; //Y Position Mouse Down
    double xPointDragDisplay; //X Position Mouse drag
    double yPointDragDisplay; //Y Position mouse drag
    double xPositionMoveDisplay; //X Position Total Move by Drag
    double yPositionMoveDisplay; //Y Position Total Move by Drag
    
    int silhouetteSwitchStatus; //Display mode/ image/ Silhouette for Display
    int connectDisplayStatus; //Connect data display status
    
    IBOutlet NSWindow *displayImageWindow;
    
    NSImage *displayImage;
    
    id trackingSet;
}

-(void)dealloc;
-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDragged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;

-(BOOL)acceptsFirstResponder;

@end
