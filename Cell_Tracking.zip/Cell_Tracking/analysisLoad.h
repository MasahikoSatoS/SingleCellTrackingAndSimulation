//
// analysisLoad.h
// Cell_Tracking
//
// Created by Masahiko Sato on 13/08/09.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef ANALYSIS_H
#define ANALYSIS_H
#import "Controller.h"
#endif

@interface analysisLoad : NSObject <NSTableViewDataSource> {
    unsigned long incrementSize; //Increment
    
    IBOutlet NSTextField *analysisSeriesDisplay;
    IBOutlet NSTextField *analysisIDDisplay;
    IBOutlet NSTextField *analysisCurrent;
    IBOutlet NSTextField *analysisIDCurrent;
    IBOutlet NSTextField *setAnalysisIDForOption;
    
    IBOutlet NSWindow *analysisLoad;
    
    IBOutlet NSBrowser *analysisLoadBrowser;
    IBOutlet NSTableView *analysisViewList;
    
    NSWindowController *analysisLoadWindController;
    
    NSTimer *analysisLoadTimer;
    
    id fileUpdate;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;
-(void)folderCopyMain:(int)typeSet;

-(IBAction)setData:(id)sender;
-(IBAction)closeWindow:(id)sender;
-(IBAction)browserDoubleClick:(id)browser;
-(IBAction)duplicate:(id)sender;
-(IBAction)deleteAnalysis:(id)sender;
-(IBAction)saveSelectedAnalysis:(id)sender;
-(IBAction)loadAnalysis:(id)sender;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

@end
