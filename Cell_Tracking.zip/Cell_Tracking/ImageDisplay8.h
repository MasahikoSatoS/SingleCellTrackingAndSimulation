//
//  ImageDisplay8.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2/5/17.
//
//

#ifndef IMAGEDISPLAY8_H
#define IMAGEDISPLAY8_H
#import "Controller.h" 
#endif

@interface ImageDisplay8 : NSView {
    IBOutlet NSImage *seqImage8;
    
    id merge;
    id lineSet;
    id dataSaveRead;
}

-(void)keyDown:(NSEvent *)event;
-(void)mouseDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
