//
//  ImageDisplay9.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2/5/17.
//
//

#import "ImageDisplay9.h"

NSString *notificationToImageDisplay9 = @"notificationImageDisplay9";

@implementation ImageDisplay9

- (id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self) {
        seqImage9 = [[NSImage alloc] initWithContentsOfFile:@""];
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToImageDisplay9 object:nil];
    }
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    string extension = to_string(seqImageNoSet9);
    
    int xPositionSeq = 0;
    int yPositionSeq = 0;
    int findFlag = 0;
    
    for (int counter1 = 0; counter1 < xyPositionListCount/5; counter1++){
        xPositionSeq = arrayXYPositionList [counter1*5+2];
        yPositionSeq = arrayXYPositionList [counter1*5+3];
        
        if (arrayXYPositionList [counter1*5] == seqImageNoSet9){
            xPositionSeq = arrayXYPositionList [counter1*5+2];
            yPositionSeq = arrayXYPositionList [counter1*5+3];
            findFlag = 1;
            break;
        }
    }
    
    if (extension.length() == 1) extension = "000"+extension;
    else if (extension.length() == 2) extension = "00"+extension;
    else if (extension.length() == 3) extension = "0"+extension;
    
    string sourceImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+exType;
    
    struct stat sizeOfFile;
    
    long sizeForCopy = 0;
    
    if (stat(sourceImagePath.c_str(), &sizeOfFile) == 0){
        sizeForCopy = sizeOfFile.st_size;
        
        ifstream fin;
        
        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
        fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
        
        if (fin.is_open()){
            if (exType == ".tif"){
                fin.read((char*)uploadTemp, sizeForCopy+50);
                fin.close();
                
                int dataConversion [4];
                int endianType = 0;
                int value0 = 0;
                int value1 = 0;
                int value2 = 0;
                
                unsigned long headPosition = 0;
                
                dataConversion [0] = uploadTemp [0];
                dataConversion [1] = uploadTemp [1];
                
                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                else endianType = 0;
                
                headPosition = 0;
                
                if (endianType == 1){
                    dataConversion [0] = uploadTemp [7];
                    dataConversion [1] = uploadTemp [6];
                    dataConversion [2] = uploadTemp [5];
                    dataConversion [3] = uploadTemp [4];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                else if (endianType == 0){
                    dataConversion [0] = uploadTemp [4];
                    dataConversion [1] = uploadTemp [5];
                    dataConversion [2] = uploadTemp [6];
                    dataConversion [3] = uploadTemp [7];
                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                }
                
                if (tifImageColorGray == 0){
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageWidthSeq pixelsHigh:imageWidthSeq bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageWidthSeq bitsPerPixel:8];
                    
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    int horizontalCount = 0;
                    int verticalCount = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                        if (verticalCount >= yPositionSeq-imageWidthSeq/2 && verticalCount < yPositionSeq+imageWidthSeq/2){
                            if (horizontalCount >= xPositionSeq-imageWidthSeq/2 && horizontalCount < xPositionSeq+imageWidthSeq/2){
                                if (verticalCount < 0 || verticalCount > imageDimension-1 || horizontalCount < 0 || horizontalCount > imageDimension-1){
                                    *bitmapData++ = 0;
                                }
                                else if (verticalCount < yPositionSeq+5 && verticalCount > yPositionSeq-5 && horizontalCount > xPositionSeq-5 && horizontalCount < xPositionSeq+5 && findFlag == 1){
                                    *bitmapData++ = 0;
                                }
                                else *bitmapData++ = uploadTemp [counter1];
                            }
                        }
                        
                        horizontalCount++;
                        
                        if (horizontalCount == imageDimension){
                            horizontalCount = 0;
                            verticalCount++;
                        }
                    }
                    
                    seqImage9 = [[NSImage alloc] initWithSize:NSMakeSize(imageWidthSeq, imageWidthSeq)];
                    [seqImage9 addRepresentation:bitmapReps];
                }
                else if (tifImageColorGray == 1){
                    NSBitmapImageRep *bitmapReps = nil;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageWidthSeq pixelsHigh:imageWidthSeq bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageWidthSeq*4 bitsPerPixel:32];
                    
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    int horizontalCount = 0;
                    int verticalCount = 0;
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                        if (verticalCount >= yPositionSeq-imageWidthSeq/2 && verticalCount < yPositionSeq+imageWidthSeq/2){
                            if (horizontalCount >= xPositionSeq-imageWidthSeq/2 && horizontalCount < xPositionSeq+imageWidthSeq/2){
                                if (verticalCount < 0 || verticalCount > imageDimension-1 || horizontalCount < 0 || horizontalCount > imageDimension-1){
                                    *bitmapData++ = 0;
                                    *bitmapData++ = 0;
                                    *bitmapData++ = 0;
                                    *bitmapData++ = 0;
                                }
                                else if (verticalCount < yPositionSeq+5 && verticalCount > yPositionSeq-5 && horizontalCount > xPositionSeq-5 && horizontalCount < xPositionSeq+5 && findFlag == 1){
                                    *bitmapData++ = 0;
                                    *bitmapData++ = 0;
                                    *bitmapData++ = 0;
                                    *bitmapData++ = 0;
                                }
                                else{
                                    
                                    value0 = uploadTemp [counter1];
                                    value1 = uploadTemp [counter1+1];
                                    value2 = uploadTemp [counter1+2];
                                    
                                    *bitmapData++ = (unsigned char)value0;
                                    *bitmapData++ = (unsigned char)value1;
                                    *bitmapData++ = (unsigned char)value2;
                                    *bitmapData++ = 0;
                                }
                            }
                        }
                        
                        horizontalCount++;
                        
                        if (horizontalCount == imageDimension){
                            horizontalCount = 0;
                            verticalCount++;
                        }
                    }
                    
                    seqImage9 = [[NSImage alloc] initWithSize:NSMakeSize(imageWidthSeq, imageWidthSeq)];
                    [seqImage9 addRepresentation:bitmapReps];
                }
            }
            else if (exType == ".bmp"){
                fin.read((char*)uploadTemp, sizeForCopy+50);
                fin.close();
                
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageWidthSeq pixelsHigh:imageWidthSeq bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageWidthSeq bitsPerPixel:8];
                
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                for (int counter1 = imageDimension-1-yPositionSeq+imageWidthSeq/2; counter1 >= imageDimension-1-yPositionSeq-imageWidthSeq/2; counter1--){
                    for (int counter2 = xPositionSeq-imageWidthSeq/2; counter2 < xPositionSeq+imageWidthSeq/2; counter2++){
                        if (counter1 < 0 || counter1 > imageDimension-1 || counter2 < 0 || counter2 > imageDimension-1){
                            *bitmapData++ = 0;
                        }
                        else if (counter1 < imageDimension-1-yPositionSeq+5 && counter1 > imageDimension-1-yPositionSeq-5 && counter2 > xPositionSeq-5 && counter2 < xPositionSeq+5 && findFlag == 1){
                            *bitmapData++ = 0;
                        }
                        else *bitmapData++ = uploadTemp [1078+counter1*imageDimension+counter2];
                    }
                }
                
                seqImage9 = [[NSImage alloc] initWithSize:NSMakeSize(imageWidthSeq, imageWidthSeq)];
                [seqImage9 addRepresentation:bitmapReps];
            }
        }
        
        delete [] uploadTemp;
    }
    
    [self setNeedsDisplay:YES];
}

-(void)mouseDown:(NSEvent *)event{
    seqImageClick = 9;
}

-(void)keyDown:(NSEvent *)event{
    if (seqImageCheck != 0 && cleaningProgress == 0){
        int keyCode = [event keyCode];
        
        //-----Save short cut "`"-----
        if (keyCode == 50 && timeOneStatus == 0 && trackingOn == 3){
            saveShortCutNumber = 1;
        }
        
        //-----Line set short cut "1"-----
        if (keyCode == 18 && timeOneStatus == 0 && trackingOn == 3){
            saveShortCutNumber = 2;
        }
        
        //-----Save rem/end short cut "2"-----
        if (keyCode == 19 && timeOneStatus == 0 && trackingOn == 3){
            saveShortCutNumber = 3;
        }
        
        //-----Save OK short cut "3"-----
        if (keyCode == 20 && timeOneStatus == 0 && trackingOn == 1){
            saveShortCutNumber = 4;
        }
        
        //-----Quick Line Set "="-----
        if (keyCode == 24 && timeOneStatus == 0 && trackingOn == 1){
            quickLineSetCall = 1;
        }
        
        //-----Track move forward "0"-----
        if (keyCode == 29 && timeOneStatus == 0){
            trackForwardControl = 1;
        }
        
        //-----Merge connect "B"-----
        if (keyCode == 11 && timeOneStatus == 0 && trackingOn == 3){
            string cellLineageExtract = cellLineageNoHold.substr(1);
            string cellNumberExtract = cellNoHold.substr(1);
            
            int cellLineageTempInt = atoi(cellLineageExtract.c_str());
            int cellNumberTempInt = atoi(cellNumberExtract.c_str());
            
            string lineageNoExtension = to_string(imageNumberTrackForDisplay);
            
            if (lineageNoExtension.length() == 1) lineageNoExtension = "000"+lineageNoExtension;
            else if (lineageNoExtension.length() == 2) lineageNoExtension = "00"+lineageNoExtension;
            else if (lineageNoExtension.length() == 3) lineageNoExtension = "0"+lineageNoExtension;
            
            //-----Division case process-----
            currentConnectNo = 0;
            
            for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt) currentConnectNo = arrayConnectLineageRel [counter1*6+1];
            }
            
            if (currentConnectNo != 0){
                merge = [[Merge alloc] init];
                int mergeResult = [merge mergeAttach];
                
                if (mergeResult != 0){
                    int lineDrawStatus = 0;
                    
                    if (lineDraw == 0){
                        lineDraw = 1;
                        lineDrawStatus = 1;
                    }
                    
                    int processType = 2;
                    lineSet = [[LineSet alloc] init];
                    [lineSet lineSetProcess:processType];
                    
                    if (lineDrawStatus == 1) lineDraw = 0;
                    
                    mergeAllFlag = 0;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
        }
        
        //-----Forward-----
        if (keyCode == 124 && timeOneStatus == 0){
            int seqImageTopTemp = seqImageTop;
            
            if (noOfSeqDisplay == 0) seqImageTop = seqImageTop+6;
            else if (noOfSeqDisplay == 1) seqImageTop = seqImageTop+9;
            
            if (seqImageTop <= seqImageLast){
                seqImageNoSet1 = 0;
                seqImageNoSet2 = 0;
                seqImageNoSet3 = 0;
                seqImageNoSet4 = 0;
                seqImageNoSet5 = 0;
                seqImageNoSet6 = 0;
                seqImageNoSet7 = 0;
                seqImageNoSet8 = 0;
                seqImageNoSet9 = 0;
                seqImageNoSet10 = 0;
                
                seqImageNoSet1 = seqImageTop;
                if (timeEndHold >= seqImageTop+1) seqImageNoSet2 = seqImageTop+1;
                if (timeEndHold >= seqImageTop+2) seqImageNoSet3 = seqImageTop+2;
                if (timeEndHold >= seqImageTop+3) seqImageNoSet4 = seqImageTop+3;
                if (timeEndHold >= seqImageTop+4) seqImageNoSet5 = seqImageTop+4;
                if (timeEndHold >= seqImageTop+5) seqImageNoSet6 = seqImageTop+5;
                if (timeEndHold >= seqImageTop+6) seqImageNoSet7 = seqImageTop+6;
                if (timeEndHold >= seqImageTop+7 && noOfSeqDisplay == 1) seqImageNoSet8 = seqImageTop+7;
                if (timeEndHold >= seqImageTop+8 && noOfSeqDisplay == 1) seqImageNoSet9 = seqImageTop+8;
                if (timeEndHold >= seqImageTop+9 && noOfSeqDisplay == 1) seqImageNoSet10 = seqImageTop+9;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay1 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay2 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay3 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay4 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay5 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay6 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay7 object:self];
                
                if (noOfSeqDisplay == 1){
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay8 object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay9 object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay10 object:self];
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                seqImageTop = seqImageTopTemp;
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        //-----Reverse-----
        if (keyCode == 123 && timeOneStatus == 0){
            int seqImageTopTemp = seqImageTop;
            
            if (noOfSeqDisplay == 0) seqImageTop = seqImageTop-6;
            else if (noOfSeqDisplay == 1) seqImageTop = seqImageTop-9;
            
            if (seqImageTopTemp != seqImageFirst && seqImageTop < seqImageFirst) seqImageTop = seqImageFirst;
            
            if (seqImageTop >= seqImageFirst){
                seqImageNoSet1 = 0;
                seqImageNoSet2 = 0;
                seqImageNoSet3 = 0;
                seqImageNoSet4 = 0;
                seqImageNoSet5 = 0;
                seqImageNoSet6 = 0;
                seqImageNoSet7 = 0;
                seqImageNoSet8 = 0;
                seqImageNoSet9 = 0;
                seqImageNoSet10 = 0;
                
                seqImageNoSet1 = seqImageTop;
                if (timeEndHold >= seqImageTop+1) seqImageNoSet2 = seqImageTop+1;
                if (timeEndHold >= seqImageTop+2) seqImageNoSet3 = seqImageTop+2;
                if (timeEndHold >= seqImageTop+3) seqImageNoSet4 = seqImageTop+3;
                if (timeEndHold >= seqImageTop+4) seqImageNoSet5 = seqImageTop+4;
                if (timeEndHold >= seqImageTop+5) seqImageNoSet6 = seqImageTop+5;
                if (timeEndHold >= seqImageTop+6) seqImageNoSet7 = seqImageTop+6;
                if (timeEndHold >= seqImageTop+7 && noOfSeqDisplay == 1) seqImageNoSet8 = seqImageTop+7;
                if (timeEndHold >= seqImageTop+8 && noOfSeqDisplay == 1) seqImageNoSet9 = seqImageTop+8;
                if (timeEndHold >= seqImageTop+9 && noOfSeqDisplay == 1) seqImageNoSet10 = seqImageTop+9;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay1 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay2 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay3 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay4 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay5 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay6 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay7 object:self];
                
                if (noOfSeqDisplay == 1){
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay8 object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay9 object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay10 object:self];
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                seqImageTop = seqImageTopTemp;
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        //-----Jump to Mitosis-----
        if (keyCode == 46 && timeOneStatus == 0){
            if (seqImageMitosis != 0){
                seqImageTop = seqImageMitosis;
                
                seqImageNoSet1 = 0;
                seqImageNoSet2 = 0;
                seqImageNoSet3 = 0;
                seqImageNoSet4 = 0;
                seqImageNoSet5 = 0;
                seqImageNoSet6 = 0;
                seqImageNoSet7 = 0;
                seqImageNoSet8 = 0;
                seqImageNoSet9 = 0;
                seqImageNoSet10 = 0;
                
                seqImageNoSet1 = seqImageTop;
                if (timeEndHold >= seqImageTop+1) seqImageNoSet2 = seqImageTop+1;
                if (timeEndHold >= seqImageTop+2) seqImageNoSet3 = seqImageTop+2;
                if (timeEndHold >= seqImageTop+3) seqImageNoSet4 = seqImageTop+3;
                if (timeEndHold >= seqImageTop+4) seqImageNoSet5 = seqImageTop+4;
                if (timeEndHold >= seqImageTop+5) seqImageNoSet6 = seqImageTop+5;
                if (timeEndHold >= seqImageTop+6) seqImageNoSet7 = seqImageTop+6;
                if (timeEndHold >= seqImageTop+7 && noOfSeqDisplay == 1) seqImageNoSet8 = seqImageTop+7;
                if (timeEndHold >= seqImageTop+8 && noOfSeqDisplay == 1) seqImageNoSet9 = seqImageTop+8;
                if (timeEndHold >= seqImageTop+9 && noOfSeqDisplay == 1) seqImageNoSet10 = seqImageTop+9;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay1 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay2 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay3 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay4 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay5 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay6 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay7 object:self];
                
                if (noOfSeqDisplay == 1){
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay8 object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay9 object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay10 object:self];
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        
        //-----Jump to Fusion mark-----
        if (keyCode == 3 && timeOneStatus == 0){
            if (seqImageFusionMark != 0){
                seqImageTop = seqImageFusionMark;
                
                seqImageNoSet1 = 0;
                seqImageNoSet2 = 0;
                seqImageNoSet3 = 0;
                seqImageNoSet4 = 0;
                seqImageNoSet5 = 0;
                seqImageNoSet6 = 0;
                seqImageNoSet7 = 0;
                seqImageNoSet8 = 0;
                seqImageNoSet9 = 0;
                seqImageNoSet10 = 0;
                
                seqImageNoSet1 = seqImageTop;
                if (timeEndHold >= seqImageTop+1) seqImageNoSet2 = seqImageTop+1;
                if (timeEndHold >= seqImageTop+2) seqImageNoSet3 = seqImageTop+2;
                if (timeEndHold >= seqImageTop+3) seqImageNoSet4 = seqImageTop+3;
                if (timeEndHold >= seqImageTop+4) seqImageNoSet5 = seqImageTop+4;
                if (timeEndHold >= seqImageTop+5) seqImageNoSet6 = seqImageTop+5;
                if (timeEndHold >= seqImageTop+6) seqImageNoSet7 = seqImageTop+6;
                if (timeEndHold >= seqImageTop+7 && noOfSeqDisplay == 1) seqImageNoSet8 = seqImageTop+7;
                if (timeEndHold >= seqImageTop+8 && noOfSeqDisplay == 1) seqImageNoSet9 = seqImageTop+8;
                if (timeEndHold >= seqImageTop+9 && noOfSeqDisplay == 1) seqImageNoSet10 = seqImageTop+9;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay1 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay2 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay3 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay4 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay5 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay6 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay7 object:self];
                
                if (noOfSeqDisplay == 1){
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay8 object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay9 object:self];
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay10 object:self];
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        
        //-----Next List-----
        if (keyCode == 25 && timeOneStatus == 0){
            long sizeForCopy = 0;
            struct stat sizeOfFile;
            
            if (tableListSwitch == 1 && trackingOn == 1){
                if (tableCurrentRowHold < doneListDisplayCount/5){
                    string treatmentNameStringTemp = arrayDoneListDisplay [tableCurrentRowHold*5];
                    string cellLineageStringTemp = arrayDoneListDisplay [tableCurrentRowHold*5+1];
                    string cellNumberStringTemp = arrayDoneListDisplay [tableCurrentRowHold*5+2];
                    
                    int fileCheck = 0;
                    
                    ifstream fin;
                    
                    string connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageData";
                    string connectDataStatus = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageStatus";
                    string connectDataStatus2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Treat/"+cellLineageStringTemp+"/"+analysisID+"_"+cellLineageStringTemp+"_CellStatus";
                    string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageStartEnd";
                    
                    fin.open(connectDataPath.c_str(), ios::in);
                    if (fin.is_open()) fin.close(), fileCheck++;
                    
                    fin.open(connectDataStatus.c_str(), ios::in);
                    if (fin.is_open()) fin.close(), fileCheck++;
                    
                    fin.open(connectDataStatus2.c_str(), ios::in);
                    if (fin.is_open()) fin.close(), fileCheck++;
                    
                    fin.open(connectStartEndPath.c_str(), ios::in);
                    if (fin.is_open()) fin.close(), fileCheck++;
                    
                    if (fileCheck == 4){
                        string imageNumberLast = "";
                        string imageCheckTime = "";
                        string treatmentNameHoldPrev = treatmentNameHold;
                        
                        treatmentNameHold = arrayDoneListDisplay [tableCurrentRowHold*5];
                        cellLineageNoHold = arrayDoneListDisplay [tableCurrentRowHold*5+1];
                        cellNoHold = arrayDoneListDisplay [tableCurrentRowHold*5+2];
                        
                        imageNumberLast = arrayDoneListDisplay [tableCurrentRowHold*5+3];
                        if ((int)imageNumberLast.find(":") != -1) imageNumberLast = imageNumberLast.substr(0, imageNumberLast.find(":"));
                        
                        imageCheckTime = arrayDoneListDisplay [tableCurrentRowHold*5+3];
                        if ((int)imageCheckTime.find(":") != -1) imageCheckTime = imageCheckTime.substr(imageCheckTime.find(":")+1);
                        
                        if (imageReturnPosition == 0){
                            imageNumber = atoi(imageNumberLast.c_str());
                            imageReturnPositionSet = 1;
                        }
                        else{
                            
                            imageNumber = atoi(imageCheckTime.c_str());
                            imageReturnPositionSet = 2;
                        }
                        
                        errorInfoFlag = arrayDoneListDisplay [tableCurrentRowHold*5+4];
                        
                        if (treatmentNameHoldPrev != treatmentNameHold){
                            saveInfo = treatmentNameStringTemp;
                            
                            dataSaveRead = [[DataSaveRead alloc] init];
                            [dataSaveRead lineageDataRead];
                            
                            sizeForCopy = 0;
                            
                            if (stat(connectDataStatus.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            if (cellLineageInfoStatus == 0){
                                arrayCellLineageInfo = new int [sizeForCopy*2+50];
                                cellLineageInfoLimit = (int)sizeForCopy*2+50;
                                cellLineageInfoStatus = 1;
                            }
                            else if (sizeForCopy*2 > cellLineageInfoCount){
                                delete [] arrayCellLineageInfo;
                                arrayCellLineageInfo = new int [sizeForCopy*2+50];
                                cellLineageInfoLimit = (int)sizeForCopy*2+50;
                            }
                            
                            cellLineageInfoCount = 0;
                            
                            fin.open(connectDataStatus.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                char *uploadTemp = new char [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                string dataString = "";
                                int readPosition = 0;
                                
                                do{
                                    
                                    if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                    else if (dataString != "End") arrayCellLineageInfo [cellLineageInfoCount] = atoi(dataString.c_str()), cellLineageInfoCount++, dataString = "";
                                    
                                    readPosition++;
                                    
                                } while (dataString != "End");
                                
                                delete [] uploadTemp;
                            }
                            
                            //for (int counterA = 0; counterA < cellLineageInfoCount/3; counterA++){
                            //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayCellLineageInfo [counterA*3+counterB];
                            //    cout<<" arrayCellLineageInfo "<<counterA<<endl;
                            //}
                            
                            sizeForCopy = 0;
                            
                            if (stat(connectStartEndPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            if (lineageStartEndStatus == 0){
                                arrayLineageStartEnd = new int [sizeForCopy+50];
                                lineageStartEndLimit = (int)sizeForCopy+50;
                                lineageStartEndStatus = 1;
                            }
                            else if (sizeForCopy > lineageStartEndCount){
                                delete [] arrayLineageStartEnd;
                                arrayLineageStartEnd = new int [sizeForCopy+50];
                                lineageStartEndLimit = (int)sizeForCopy+50;
                            }
                            
                            lineageStartEndCount = 0;
                            
                            fin.open(connectStartEndPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                char *uploadTemp = new char [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                string dataString = "";
                                int readPosition = 0;
                                
                                do{
                                    
                                    if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                    else if (dataString != "End"){
                                        arrayLineageStartEnd [lineageStartEndCount] = atoi(dataString.c_str()), lineageStartEndCount++;
                                        dataString = "";
                                    }
                                    
                                    readPosition++;
                                    
                                } while (dataString != "End");
                                
                                delete [] uploadTemp;
                            }
                        }
                        
                        sizeForCopy = 0;
                        
                        if (stat(connectDataStatus2.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (cellNumberInfoStatus == 1) delete [] arrayCellNumberInfo;
                        arrayCellNumberInfo = new int [sizeForCopy*2+50];
                        cellNumberInfoCount = 0;
                        cellNumberInfoLimit = (int)sizeForCopy*2+50;
                        cellNumberInfoStatus = 1;
                        
                        fin.open(connectDataStatus2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            char *uploadTemp = new char [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            string dataString = "";
                            int readPosition = 0;
                            
                            do{
                                
                                if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                else if (dataString != "End"){
                                    arrayCellNumberInfo [cellNumberInfoCount] = atoi(dataString.c_str()), cellNumberInfoCount++;
                                    dataString = "";
                                }
                                
                                readPosition++;
                                
                            } while (dataString != "End");
                            
                            delete [] uploadTemp;
                        }
                        
                        if (seqOpenFlag == 1 && imageSeqOperation == 1){
                            seqImageFirst = 0;
                            seqImageLast = atoi(imageNumberLast.c_str());
                            seqImageCheck = atoi(imageCheckTime.c_str());
                            seqImageMitosis = 0;
                            seqImageFusionMark = 0;
                            seqImageTop = atoi(imageCheckTime.c_str());
                            
                            seqImageNoSet1 = 0;
                            seqImageNoSet2 = 0;
                            seqImageNoSet3 = 0;
                            seqImageNoSet4 = 0;
                            seqImageNoSet5 = 0;
                            seqImageNoSet6 = 0;
                            seqImageNoSet7 = 0;
                            seqImageNoSet8 = 0;
                            seqImageNoSet9 = 0;
                            seqImageNoSet10 = 0;
                        }
                        
                        listCrickMonitor = 1;
                        
                        //for (int counterA = 0; counterA < lineageStartEndCount/8; counterA++){
                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageStartEnd [counterA*8 +counterB];
                        //    cout<<" arrayLineageStartEnd "<<counterA<<endl;
                        //}
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                }
            }
            if (tableListSwitch == 2 && trackingOn == 1){
                if (tableCurrentRowHold+1 < queueListDisplayCount/6){
                    string treatmentNameStringTemp = arrayQueueListDisplay [tableCurrentRowHold*6];
                    string cellLineageStringTemp = arrayQueueListDisplay [tableCurrentRowHold*6+1];
                    string cellNumberStringTemp = arrayQueueListDisplay [tableCurrentRowHold*6+2];
                    
                    int fileCheck = 0;
                    
                    ifstream fin;
                    
                    string connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageData";
                    string connectDataStatus = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageStatus";
                    string connectDataStatus2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Treat/"+cellLineageStringTemp+"/"+analysisID+"_"+cellLineageStringTemp+"_CellStatus";
                    string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageStartEnd";
                    
                    fin.open(connectDataPath.c_str(), ios::in);
                    if (fin.is_open()) fin.close(), fileCheck++;
                    
                    fin.open(connectDataStatus.c_str(), ios::in);
                    if (fin.is_open()) fin.close(), fileCheck++;
                    
                    fin.open(connectDataStatus2.c_str(), ios::in);
                    if (fin.is_open()) fin.close(), fileCheck++;
                    
                    fin.open(connectDataStatus2.c_str(), ios::in);
                    if (fin.is_open()) fin.close(), fileCheck++;
                    
                    string imageNumberLast = "";
                    string imageCheckTime = "";
                    
                    if (fileCheck == 4){
                        string treatmentNameHoldPrev = treatmentNameHold;
                        
                        treatmentNameHold = arrayQueueListDisplay [tableCurrentRowHold*6];
                        cellLineageNoHold = arrayQueueListDisplay [tableCurrentRowHold*6+1];
                        cellNoHold = arrayQueueListDisplay [tableCurrentRowHold*6+2];
                        
                        imageNumberLast = arrayQueueListDisplay [tableCurrentRowHold*6+3];
                        if ((int)imageNumberLast.find(":") != -1) imageNumberLast = imageNumberLast.substr(0, imageNumberLast.find(":"));
                        
                        imageCheckTime = arrayQueueListDisplay [tableCurrentRowHold*6+3];
                        if ((int)imageCheckTime.find(":") != -1) imageCheckTime = imageCheckTime.substr(imageCheckTime.find(":")+1);
                        
                        if (imageReturnPosition == 0){
                            imageNumber = atoi(imageNumberLast.c_str());
                            imageReturnPositionSet = 1;
                        }
                        else{
                            
                            imageNumber = atoi(imageCheckTime.c_str());
                            imageReturnPositionSet = 2;
                        }
                        
                        if (treatmentNameHoldPrev != treatmentNameHold){
                            saveInfo = treatmentNameStringTemp;
                            
                            dataSaveRead = [[DataSaveRead alloc] init];
                            [dataSaveRead lineageDataRead];
                            
                            sizeForCopy = 0;
                            
                            if (stat(connectDataStatus.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            if (cellLineageInfoStatus == 0){
                                arrayCellLineageInfo = new int [sizeForCopy*2+50];
                                cellLineageInfoLimit = (int)sizeForCopy*2+50;
                                cellLineageInfoStatus = 1;
                            }
                            else if (sizeForCopy*2 > cellLineageInfoCount){
                                delete [] arrayCellLineageInfo;
                                arrayCellLineageInfo = new int [sizeForCopy*2+50];
                                cellLineageInfoLimit = (int)sizeForCopy*2+50;
                            }
                            
                            cellLineageInfoCount = 0;
                            
                            fin.open(connectDataStatus.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                char *uploadTemp = new char [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                string dataString = "";
                                int readPosition = 0;
                                
                                do{
                                    
                                    if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                    else if (dataString != "End") arrayCellLineageInfo [cellLineageInfoCount] = atoi(dataString.c_str()), cellLineageInfoCount++, dataString = "";
                                    
                                    readPosition++;
                                    
                                } while (dataString != "End");
                                
                                delete [] uploadTemp;
                            }
                            
                            //for (int counterA = 0; counterA < cellLineageInfoCount/3; counterA++){
                            //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayCellLineageInfo [counterA*3+counterB];
                            //    cout<<" arrayCellLineageInfo "<<counterA<<endl;
                            //}
                            
                            sizeForCopy = 0;
                            
                            if (stat(connectStartEndPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            if (lineageStartEndStatus == 0){
                                arrayLineageStartEnd = new int [sizeForCopy+50];
                                lineageStartEndLimit = (int)sizeForCopy+50;
                                lineageStartEndStatus = 1;
                            }
                            else if (sizeForCopy > lineageStartEndCount){
                                delete [] arrayLineageStartEnd;
                                arrayLineageStartEnd = new int [sizeForCopy+50];
                                lineageStartEndLimit = (int)sizeForCopy+50;
                            }
                            
                            lineageStartEndCount = 0;
                            
                            fin.open(connectStartEndPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                char *uploadTemp = new char [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                string dataString = "";
                                int readPosition = 0;
                                
                                do{
                                    
                                    if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                    else if (dataString != "End"){
                                        arrayLineageStartEnd [lineageStartEndCount] = atoi(dataString.c_str()), lineageStartEndCount++;
                                        dataString = "";
                                    }
                                    
                                    readPosition++;
                                    
                                } while (dataString != "End");
                                
                                delete [] uploadTemp;
                            }
                        }
                        
                        sizeForCopy = 0;
                        
                        if (stat(connectDataStatus2.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (cellNumberInfoStatus == 1) delete [] arrayCellNumberInfo;
                        arrayCellNumberInfo = new int [sizeForCopy*2+50];
                        cellNumberInfoCount = 0;
                        cellNumberInfoLimit = (int)sizeForCopy*2+50;
                        cellNumberInfoStatus = 1;
                        
                        fin.open(connectDataStatus2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            char *uploadTemp = new char [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            string dataString = "";
                            int readPosition = 0;
                            
                            do{
                                
                                if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                else if (dataString != "End"){
                                    arrayCellNumberInfo [cellNumberInfoCount] = atoi(dataString.c_str()), cellNumberInfoCount++;
                                    dataString = "";
                                }
                                
                                readPosition++;
                                
                            } while (dataString != "End");
                            
                            delete [] uploadTemp;
                        }
                        
                        if (seqOpenFlag == 1 && imageSeqOperation == 1){
                            seqImageFirst = 0;
                            seqImageLast = atoi(imageNumberLast.c_str());
                            seqImageCheck = atoi(imageCheckTime.c_str());
                            seqImageMitosis = 0;
                            seqImageFusionMark = 0;
                            seqImageTop = atoi(imageCheckTime.c_str());
                            
                            seqImageNoSet1 = 0;
                            seqImageNoSet2 = 0;
                            seqImageNoSet3 = 0;
                            seqImageNoSet4 = 0;
                            seqImageNoSet5 = 0;
                            seqImageNoSet6 = 0;
                            seqImageNoSet7 = 0;
                            seqImageNoSet8 = 0;
                            seqImageNoSet9 = 0;
                            seqImageNoSet10 = 0;
                        }
                        
                        errorInfoFlag = "nil";
                        listCrickMonitor = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                }
            }
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect{
    [[NSColor blackColor] set];
    
    NSBezierPath *path;
    path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, imageWidthSeq, imageWidthSeq)];
    [path stroke];
    
    NSRect srcRect;
    srcRect.origin.x = 0;
    srcRect.origin.y = 0;
    srcRect.size.width = imageWidthSeq;
    srcRect.size.height = imageWidthSeq;
    
    [seqImage9 drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
    
    NSPoint pointA;
    NSAttributedString *attrStrA;
    NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
    string extension2 = to_string(seqImageNoSet9);
    
    [attributesA setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
    [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
    
    if (seqImageMitosis == seqImageNoSet9){
        [attributesA setObject:[NSColor cyanColor] forKey: NSForegroundColorAttributeName];
    }
    else if (seqImageFusionMark == seqImageNoSet9){
        [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
    }
    else if (seqImageCheck == seqImageNoSet9){
        [attributesA setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
    }
    else if (seqImageLast < seqImageNoSet9){
        [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
    }
    else [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
    
    attrStrA = [[NSAttributedString alloc] initWithString:@(extension2.c_str()) attributes:attributesA];
    pointA.x = 5;
    pointA.y = 115;
    [attrStrA drawAtPoint:pointA];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToImageDisplay9 object:nil];
}

@end
