//
//  DataRepairProcess.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-05-28.
//

#ifndef DATAREPAIRPROCESS_H
#define DATAREPAIRPROCESS_H
#import "Controller.h"
#endif

@interface DataRepairProcess : NSObject{
    id fileUpdate;
    id dataRepairReadWrite;
}

-(int)lineageProcessMain;

@end
