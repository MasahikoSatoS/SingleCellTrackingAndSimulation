//
//  FileUpdate.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-03-31.
//

#import "FileUpdate.h"

@implementation FileUpdate

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)expandFluorescentDataUpDate{
    int *arrayUpDate = new int [expandFluorescentDataCount+10];
    
    for (int counter1 = 0; counter1 < expandFluorescentDataCount; counter1++) arrayUpDate [counter1] = expandFluorescentData [counter1];
    
    delete [] expandFluorescentData;
    expandFluorescentData = new int [expandFluorescentDataLimit+10000];
    expandFluorescentDataLimit = expandFluorescentDataLimit+10000;
    
    for (int counter1 = 0; counter1 < expandFluorescentDataCount; counter1++) expandFluorescentData [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)expandFluorescentOutlineUpDate{
    int *arrayUpDate = new int [expandFluorescentOutlineCount+10];
    
    for (int counter1 = 0; counter1 < expandFluorescentOutlineCount; counter1++) arrayUpDate [counter1] = expandFluorescentOutline [counter1];
    
    delete [] expandFluorescentOutline;
    expandFluorescentOutline = new int [expandFluorescentOutlineLimit+10000];
    expandFluorescentOutlineLimit = expandFluorescentOutlineLimit+10000;
    
    for (int counter1 = 0; counter1 < expandFluorescentOutlineCount; counter1++) expandFluorescentOutline [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)lineageStartEndUpDate{
    int *arrayUpDate = new int [lineageStartEndCount+10];
    
    for (int counter1 = 0; counter1 < lineageStartEndCount; counter1++) arrayUpDate [counter1] = arrayLineageStartEnd [counter1];
    
    delete [] arrayLineageStartEnd;
    arrayLineageStartEnd = new int [lineageStartEndLimit+5000];
    lineageStartEndLimit = lineageStartEndLimit+5000;
    
    for (int counter1 = 0; counter1 < lineageStartEndCount; counter1++) arrayLineageStartEnd [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)queueListUpDate{
    string *arrayUpDate = new string [queueListCount+10];
    
    for (int counter1 = 0; counter1 < queueListCount; counter1++) arrayUpDate [counter1] = arrayQueueList [counter1];
    
    delete [] arrayQueueList;
    arrayQueueList = new string [queueListLimit+6000];
    queueListLimit = queueListLimit+6000;
    
    for (int counter1 = 0; counter1 < queueListCount; counter1++) arrayQueueList [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)doneListUpDate{
    string *arrayUpDate = new string [doneListCount+10];
    
    for (int counter1 = 0; counter1 < doneListCount; counter1++) arrayUpDate [counter1] = arrayDoneList [counter1];
    
    delete [] arrayDoneList;
    arrayDoneList = new string [doneListLimit+6000];
    doneListLimit = doneListLimit+6000;
    
    for (int counter1 = 0; counter1 < doneListCount; counter1++) arrayDoneList [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)gravityCenterRevUpDate{
    int *arrayUpDate = new int [gravityCenterRevCount+10];
    
    for (int counter1 = 0; counter1 < gravityCenterRevCount; counter1++) arrayUpDate [counter1] = arrayGravityCenterRev [counter1];
    
    delete [] arrayGravityCenterRev;
    arrayGravityCenterRev = new int [gravityCenterRevLimit+2000];
    gravityCenterRevLimit = gravityCenterRevLimit+2000;
    
    for (int counter1 = 0; counter1 < gravityCenterRevCount; counter1++) arrayGravityCenterRev [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)associateDataUpDate{
    int *arrayUpDate = new int [associateDataCount+10];
    
    for (int counter1 = 0; counter1 < associateDataCount; counter1++) arrayUpDate [counter1] = arrayAssociateData [counter1];
    
    delete [] arrayAssociateData;
    arrayAssociateData = new int [associateDataLimit+2000];
    associateDataLimit = associateDataLimit+2000;
    
    for (int counter1 = 0; counter1 < associateDataCount; counter1++) arrayAssociateData [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)lineageExtractionUpDate{
    int *arrayUpDate = new int [lineageExtractionCount+10];
    
    for (int counter1 = 0; counter1 < lineageExtractionCount; counter1++) arrayUpDate [counter1] = arrayLineageExtraction [counter1];
    
    delete [] arrayLineageExtraction;
    arrayLineageExtraction = new int [lineageExtractionLimit+10000];
    lineageExtractionLimit = lineageExtractionLimit+10000;
    
    for (int counter1 = 0; counter1 < lineageExtractionCount; counter1++) arrayLineageExtraction [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)referenceLineCountUpDate{
    int *arrayUpDate = new int [referenceLineCount+10];
    
    for (int counter1 = 0; counter1 < referenceLineCount; counter1++) arrayUpDate [counter1] = arrayReferenceLine [counter1];
    
    delete [] arrayReferenceLine;
    arrayReferenceLine = new int [referenceLineLimit+5000];
    referenceLineLimit = referenceLineLimit+5000;
    
    for (int counter1 = 0; counter1 < referenceLineCount; counter1++) arrayReferenceLine [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)eventSequenceUpDate{
    int *arrayUpDate = new int [eventSequenceCount+10];
    
    for (int counter1 = 0; counter1 < eventSequenceCount; counter1++) arrayUpDate [counter1] = arrayEventSequence [counter1];
    
    delete [] arrayEventSequence;
    arrayEventSequence = new int [eventSequenceLimit+500];
    eventSequenceLimit = eventSequenceLimit+500;
    
    for (int counter1 = 0; counter1 < eventSequenceCount; counter1++) arrayEventSequence [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)lineageGRCurrentUpDate{
    int *arrayUpDate = new int [lineageGRCurrentCount+10];
    
    for (int counter1 = 0; counter1 < lineageGRCurrentCount; counter1++) arrayUpDate [counter1] = arrayLineageGRCurrent [counter1];
    
    delete [] arrayLineageGRCurrent;
    arrayLineageGRCurrent = new int [lineageGRCurrentLimit+5000];
    lineageGRCurrentLimit = lineageGRCurrentLimit+5000;
    
    for (int counter1 = 0; counter1 < lineageGRCurrentCount; counter1++) arrayLineageGRCurrent [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)masterLineGCUpDate{
    int *arrayUpDate = new int [masterLineGravityCenterCount+10];
    
    for (int counter1 = 0; counter1 < masterLineGravityCenterCount; counter1++) arrayUpDate [counter1] = arrayMasterLineGravityCenter [counter1];
    
    delete [] arrayMasterLineGravityCenter;
    arrayMasterLineGravityCenter = new int [masterLineGravityCenterLimit+2000];
    masterLineGravityCenterLimit = masterLineGravityCenterLimit+2000;
    
    for (int counter1 = 0; counter1 < masterLineGravityCenterCount; counter1++) arrayMasterLineGravityCenter [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)masterLineSelectedUpDate{
    int *arrayUpDate = new int [masterLineSelectedCount+10];
    
    for (int counter1 = 0; counter1 < masterLineSelectedCount; counter1++) arrayUpDate [counter1] = arrayMasterLineSelected [counter1];
    
    delete [] arrayMasterLineSelected;
    arrayMasterLineSelected = new int [masterLineSelectedLimit+masterLineSelectedAddition+2000];
    masterLineSelectedLimit = masterLineSelectedLimit+masterLineSelectedAddition+2000;
    
    for (int counter1 = 0; counter1 < masterLineSelectedCount; counter1++) arrayMasterLineSelected [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)masterLineSelectedDisplayUpDate{
    int *arrayUpDate = new int [masterLineSelectedDisplayCount+10];
    
    for (int counter1 = 0; counter1 < masterLineSelectedDisplayCount; counter1++) arrayUpDate [counter1] = arrayMasterLineSelectedDisplay [counter1];
    
    delete [] arrayMasterLineSelectedDisplay;
    arrayMasterLineSelectedDisplay = new int [masterLineSelectedDisplayLimit+masterLineSelectedDisplayAddition+2000];
    masterLineSelectedDisplayLimit = masterLineSelectedDisplayLimit+masterLineSelectedDisplayAddition+2000;
    
    for (int counter1 = 0; counter1 < masterLineSelectedDisplayCount; counter1++) arrayMasterLineSelectedDisplay [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)masterLineGCDisplayUpDate{
    int *arrayUpDate = new int [masterLineGCDisplayCount+10];
    
    for (int counter1 = 0; counter1 < masterLineGCDisplayCount; counter1++) arrayUpDate [counter1] = arrayMasterLineGravityCenterDisplay [counter1];
    
    delete [] arrayMasterLineGravityCenterDisplay;
    arrayMasterLineGravityCenterDisplay = new int [masterLineGCDisplayLimit+2000];
    masterLineGCDisplayLimit = masterLineGCDisplayLimit+2000;
    
    for (int counter1 = 0; counter1 < masterLineGCDisplayCount; counter1++) arrayMasterLineGravityCenterDisplay [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)positionRevSelectedUpDate{
    int *arrayUpDate = new int [positionReviseCount+10];
    
    for (int counter1 = 0; counter1 < positionReviseCount; counter1++) arrayUpDate [counter1] = arrayPositionRevise [counter1];
    
    delete [] arrayPositionRevise;
    arrayPositionRevise = new int [positionReviseLimit+positionReviseAddition+5000];
    positionReviseLimit = positionReviseLimit+positionReviseAddition+5000;
    
    for (int counter1 = 0; counter1 < positionReviseCount; counter1++) arrayPositionRevise [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)timeSelectedUpDate{
    int *arrayUpDate = new int [timeSelectedCount+10];
    
    for (int counter1 = 0; counter1 < timeSelectedCount; counter1++) arrayUpDate [counter1] = arrayTimeSelected [counter1];
    
    delete [] arrayTimeSelected;
    arrayTimeSelected = new int [timeSelectedLimit+2000];
    timeSelectedLimit = timeSelectedLimit+2000;
    
    for (int counter1 = 0; counter1 < timeSelectedCount; counter1++) arrayTimeSelected [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)connectLineageRelUpDate{
    int *arrayUpDate = new int [connectLineageRelCount+10];
    
    for (int counter1 = 0; counter1 < connectLineageRelCount; counter1++) arrayUpDate [counter1] = arrayConnectLineageRel [counter1];
    
    delete [] arrayConnectLineageRel;
    arrayConnectLineageRel = new int [connectLineageRelLimit+500];
    connectLineageRelLimit = connectLineageRelLimit+500;
    
    for (int counter1 = 0; counter1 < connectLineageRelCount; counter1++) arrayConnectLineageRel [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(int)nameCheck{
    int errorFlag = 0;
    string newAnalysisID = destinationName;
    
    if (newAnalysisID.length() < 4 || newAnalysisID.length() > 15) errorFlag = 1;
    if ((int)newAnalysisID.find(" ") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(",") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(".") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("/") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(",") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(":") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("<") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(">") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("'") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("[") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("]") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("=") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("+") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("{") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("}") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(")") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("(") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("*") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("&") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("^") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("%") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("$") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("#") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("@") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("!") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("`") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("~") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("|") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("-") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("_") >= 0) errorFlag = 1;
    
    return errorFlag;
}

@end
